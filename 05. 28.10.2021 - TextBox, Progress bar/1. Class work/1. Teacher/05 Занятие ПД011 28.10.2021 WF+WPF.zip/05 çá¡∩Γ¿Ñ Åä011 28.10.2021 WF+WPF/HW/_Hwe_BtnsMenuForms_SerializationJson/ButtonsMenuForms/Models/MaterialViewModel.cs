﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ButtonsMenuForms.Models
{
    // данные по материалу для получения и отображения плотности
    internal class MaterialViewModel
    {
        // название материала
        public string Name { get; set; }
        
        // плотность матераила, кг/м3
        public double Density { get; set; }
        
        // имя файла изображения материала
        public string ImageFile { get; set; }
    } // class MaterialViewModel
}
