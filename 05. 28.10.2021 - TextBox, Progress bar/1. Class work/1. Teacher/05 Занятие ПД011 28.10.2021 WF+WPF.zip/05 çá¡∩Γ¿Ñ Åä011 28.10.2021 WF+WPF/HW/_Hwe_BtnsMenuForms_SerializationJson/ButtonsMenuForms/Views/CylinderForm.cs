﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using ButtonsMenuForms.Models;

/*
 * Форма для работы с цилиндром
 */
namespace ButtonsMenuForms.Views
{
    public partial class CylinderForm : Form
    {
        // модель для формы
        private Cylinder _cylinder;

        // представление для пустой строки результата
        private const string EmptyResult = "---''---";

        // конструктор формы
        public CylinderForm() {
            InitializeComponent();

            // создать модель для работы формы
            _cylinder = new Cylinder();

            // запомнить ссылки на ErrorProvider в поле Tag строк ввода
            TxbRadius.Tag = ErpNumber1;
            TxbHeight.Tag = ErpNumber2;

            // хардкодим :( 
            // установить соответствующую радиокнопку и изображение по плотности
            // по умолчанию плотность - плотность стали
            RbtSteel.Checked = true;
            PcbMaterial.Image = Image.FromFile(@"..\..\Images\Materials\" + Materials.Data["steel"].ImageFile);

            // начальное значение полей ввода TextBox
            TxbRadius.Text = $"{_cylinder.Radius:f3}";
            TxbHeight.Text     = $"{_cylinder.Height:f3}";
            TxbDensity.Text    = $"{_cylinder.Density:f3}";

            // начальное значение меток вывода результата
            LblAreaResult.Text = LblVolumeResult.Text = LblMassResult.Text = EmptyResult;
        } // ConoidForm


        // вычисление параметров конуса по заданию
        private void BtnCalc_Click(object sender, EventArgs e) {
            // получить текущие данные из полей ввода
            _cylinder.Radius = double.Parse(TxbRadius.Text);
            _cylinder.Height = double.Parse(TxbHeight.Text);

            // плотность получаем из события клика по радиокнопке, следующую строку
            // можем даже удалить :)
            // _cylinder.Density = double.Parse(TxbDensity.Text);

            // вычисление параметров, если это задано
            LblAreaResult.Text   = ChbArea.Checked   ? $"{_cylinder.Area:n3}" : "Расчет не требуется";
            LblVolumeResult.Text = ChbVolume.Checked ? $"{_cylinder.Volume:n3}" : "Расчет не требуется";
            LblMassResult.Text   = ChbMass.Checked   ? $"{_cylinder.Mass:n3}" : "Расчет не требуется";
        } // BtnCalc_Click


        // при вводе данных:
        // a) очищаем элемент отображения ошибки (ссылка на элемент отображения
        //    ошибки должна быть записана в поле Tag строки ввода)
        // b) очищаем поле вывода результата
        private void Txb_TextChanged(object sender, EventArgs e) {
            TextBox textBox = sender as TextBox;

            // очистка признака ошибки
            ErrorProvider errorProvider = (ErrorProvider)textBox.Tag;
            errorProvider.Clear();

            // очистка поля вывода результатов
            LblAreaResult.Text = LblVolumeResult.Text = LblMassResult.Text = EmptyResult;
        } // Txb_TextChanged


        // проверяем, что вводится вещественное число, большее нуля
        private void Txb_Validating(object sender, CancelEventArgs e) {
            TextBox textBox = sender as TextBox;
            ErrorProvider errorProvider = (ErrorProvider)textBox.Tag;

            bool result = double.TryParse(textBox.Text, out double temp);
            if (result) {
                if (temp <= 0)
                    errorProvider.SetError(textBox, "Отрицательное или нулевое значение не допустимо");
            } else {
                errorProvider.SetError(textBox, "Введено не число");
            }// if


            // разрешение кнопки "Вычислить" только при корректных параметрах 
            // в строках ввода
            BtnCalc.Enabled = errorProvider.GetError(TxbRadius).Length == 0 &&
                              errorProvider.GetError(TxbHeight).Length == 0;
        } // Txb_Validating

        // обработчик кликов по радиокнопкам выбора материала, из которого создано тело
        private void RbtMaterial_Click(object sender, EventArgs e) {
            RadioButton rbt = sender as RadioButton;
            MaterialViewModel viewModel = Materials.Data[(string)rbt.Tag];

            // задать картинку материала
            PcbMaterial.Image = Image.FromFile(@"..\..\Images\Materials\" + viewModel?.ImageFile);

            // задать плотность материала
            _cylinder.Density = viewModel.Density;

            // отобразить плотность материала в TextBox
            TxbDensity.Text = $"{_cylinder.Density:f3}";
            TxbDensity.SelectionLength = 0;

            // т.к. данные для расчета изменились, очищаем поле вывода результата
            LblAreaResult.Text = LblVolumeResult.Text = LblMassResult.Text = EmptyResult;
        } // RbtMaterial_Click
    } // class CylinderForm
}
