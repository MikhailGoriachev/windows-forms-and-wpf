﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

// модели приложения ткт
using ButtonsMenuForms.Models;

/*
 * Форма для работы с усеченным конусом
 */
namespace ButtonsMenuForms.Views
{
    public partial class ConoidForm : Form
    {
        // модель для формы
        private Conoid _conoid;

        // представление для пустой строки результата
        private const string EmptyResult = "---''---";

        // конструктор формы
        public ConoidForm() {
            InitializeComponent();

            // создать модель для работы формы
            _conoid = new Conoid();

            // запомнить ссылки на ErrorProvider в поле Tag строк ввода
            TxbRadiusDown.Tag = ErpNumber1;
            TxbRadiusUp.Tag   = ErpNumber2;
            TxbHeight.Tag     = ErpNumber3;

            // хардкодим :( 
            // установить соответствующую радиокнопку и изображение по плотности
            // по умолчанию плотность - плотность стали
            RbtSteel.Checked = true;
            PcbMaterial.Image = Image.FromFile(@"..\..\Images\Materials\" + Materials.Data["steel"].ImageFile);

            // начальное значение полей ввода TextBox
            TxbRadiusDown.Text = $"{_conoid.RadiusDown:f3}";
            TxbRadiusUp.Text   = $"{_conoid.RadiusUp:f3}";
            TxbHeight.Text     = $"{_conoid.Height:f3}";
            TxbDensity.Text    = $"{_conoid.Density:f3}";

            // начальное значение меток вывода результата
            LblAreaResult.Text = LblVolumeResult.Text = LblMassResult.Text = EmptyResult;
        } // ConoidForm


        // вычисление параметров конуса по заданию
        private void BtnCalc_Click(object sender, EventArgs e) {
            try {
                // получить текущие данные из полей ввода
                _conoid.RadiusDown = double.Parse(TxbRadiusDown.Text);
                _conoid.RadiusUp = double.Parse(TxbRadiusUp.Text);
                _conoid.Height = double.Parse(TxbHeight.Text);

                // плотность получаем по в обработчике события клика по радиокнопке, 
                // эту строку можем даже удалить
                // _conoid.Density = double.Parse(TxbDensity.Text);

                // проверка на уровне модели
                if (_conoid.RadiusDown <= _conoid.RadiusUp) 
                    throw new InvalidDataException($"Нижнее основание конуса меньше или равно верхнему");

                // вычисление параметров, если это задано
                LblAreaResult.Text = ChbArea.Checked ? $"{_conoid.Area:n3}" : "Расчет не требуется";
                LblVolumeResult.Text = ChbVolume.Checked ? $"{_conoid.Volume:n3}" : "Расчет не требуется";
                LblMassResult.Text = ChbMass.Checked ? $"{_conoid.Mass:n3}" : "Расчет не требуется";

            } catch (Exception ex) {
                // обработка ошибки уровня модели 

                // начальное значение меток вывода результата
                LblAreaResult.Text = LblVolumeResult.Text = LblMassResult.Text = EmptyResult;

                // запрет кнопки вычисления
                BtnCalc.Enabled = false;

                // сообщить об ошибке
                MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                
                // Передать фокус ввода на первое поле ввода, убрать выделение
                // после получения фокуса ввода
                TxbRadiusDown.Focus();
                TxbRadiusDown.SelectionLength = 0;
            } // try-catch
        } // BtnCalc_Click


        // при вводе данных:
        // a) очищаем элемент отображения ошибки (ссылка на элемент отображения
        //    ошибки должна быть записана в поле Tag строки ввода)
        // b) очищаем поле вывода результата
        private void Txb_TextChanged(object sender, EventArgs e) {
            TextBox textBox = sender as TextBox;

            // очистка признака ошибки
            ErrorProvider errorProvider = (ErrorProvider)textBox.Tag;
            errorProvider.Clear();

            // очистка поля вывода результатов
            LblAreaResult.Text = LblVolumeResult.Text = LblMassResult.Text = EmptyResult;
        } // Txb_TextChanged


        // проверяем, что вводится вещественное число, большее нуля
        private void Txb_Validating(object sender, CancelEventArgs e) {
            TextBox textBox = sender as TextBox;
            ErrorProvider errorProvider = (ErrorProvider) textBox.Tag;

            bool result = double.TryParse(textBox.Text, out double temp);
            if (result) {
                if (temp <= 0)
                    errorProvider.SetError(textBox, "Отрицательное или нулевое значение не допустимо");
            } else {
                errorProvider.SetError(textBox, "Введено не число");
            }// if

            // разрешение кнопки "Вычислить" только при корректных параметрах 
            // в строках ввода
            BtnCalc.Enabled = errorProvider.GetError(TxbRadiusDown).Length == 0 &&
                              errorProvider.GetError(TxbRadiusUp).Length == 0 &&
                              errorProvider.GetError(TxbHeight).Length == 0;
        } // Txb_Validating


        // обработчик кликов по радиокнопкам выбора материала, из которого создано тело
        private void RbtMaterial_Click(object sender, EventArgs e) {
            RadioButton rbt = sender as RadioButton;
            MaterialViewModel viewModel = Materials.Data[(string) rbt.Tag];
            
            // задать картинку материала
            PcbMaterial.Image = Image.FromFile(@"..\..\Images\Materials\" + viewModel?.ImageFile);

            // задать плотность материала
            _conoid.Density = viewModel.Density;

            // отобразить плотность материала в TextBox
            TxbDensity.Text = $"{_conoid.Density:f3}";
            TxbDensity.SelectionLength = 0;

            // т.к. данные для расчета изменились, очищаем поле вывода результата
            LblAreaResult.Text = LblVolumeResult.Text = LblMassResult.Text = EmptyResult;
        } // RbtMaterial_Click
    } // class ConoidForm
}
