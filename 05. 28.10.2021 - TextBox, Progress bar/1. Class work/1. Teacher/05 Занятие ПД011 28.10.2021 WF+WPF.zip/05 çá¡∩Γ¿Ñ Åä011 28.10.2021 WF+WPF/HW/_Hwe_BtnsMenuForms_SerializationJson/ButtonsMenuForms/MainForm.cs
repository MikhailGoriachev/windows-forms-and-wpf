﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ButtonsMenuForms.Views;

namespace ButtonsMenuForms
{
    public partial class MainForm : Form
    {
        // конструктор формы
        public MainForm() {
            InitializeComponent();
        } // MainForm


        // выход из приложения
        private void BtnQuit_Click(object sender, EventArgs e) => Application.Exit();


        // отображение формы со сведениями о программе
        private void BtnAbout_Click(object sender, EventArgs e) {
            AboutForm aboutForm = new AboutForm();
            aboutForm.ShowDialog();
        } // BtnAbout_Click


        // отображение формы для расчета усеченного конуса
        private void BtnConiod_Click(object sender, EventArgs e) {
            ConoidForm conoidForm = new ConoidForm();
            conoidForm.ShowDialog();
        } // BtnConoid_Click


        // отображение формы для расчета сферы
        private void BtnSphere_Click(object sender, EventArgs e) {
            SphereForm sphereForm = new SphereForm();
            sphereForm.ShowDialog();
        } // BtnSphere_Click


        // отображение формы для расчета цилиндра
        private void BtnCylinder_Click(object sender, EventArgs e) {
            CylinderForm cylinderForm = new CylinderForm();
            cylinderForm.ShowDialog();
        } // BtnCylinder_Click


        // отображение формы для расчета прямоугольного параллелепипеда
        private void BtnParallelepiped_Click(object sender, EventArgs e) {
            ParallelepipedForm parallelepipedForm = new ParallelepipedForm();
            parallelepipedForm.ShowDialog();
        } // BtnParallelepiped_Click
    } // class MAinForm
}
