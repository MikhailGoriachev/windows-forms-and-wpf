﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


// модели приложения ткт
using ButtonsMenuForms.Models;

/*
 * Форма для работы с прямоугольным параллелепипедом
 */
namespace ButtonsMenuForms.Views
{
    public partial class ParallelepipedForm : Form
    {
        // модель для формы
        private Parallelepiped _parallelepiped;

        // представление для пустой строки результата
        private const string EmptyResult = "---''---";

        // конструктор формы
        public ParallelepipedForm() {
            InitializeComponent();

            // создать модель для работы формы
            _parallelepiped = new Parallelepiped();

            // запомнить ссылки на ErrorProvider в поле Tag строк ввода
            TxbSideA.Tag = ErpNumber1;
            TxbSideB.Tag = ErpNumber2;
            TxbSideC.Tag = ErpNumber3;

            // хардкодим :( 
            // установить соответствующую радиокнопку и изображение по плотности
            // по умолчанию плотность - плотность стали
            RbtSteel.Checked = true;
            PcbMaterial.Image = Image.FromFile(@"..\..\Images\Materials\" + Materials.Data["steel"].ImageFile);

            // начальное значение полей ввода TextBox
            TxbSideA.Text = $"{_parallelepiped.C:f3}";
            TxbSideB.Text = $"{_parallelepiped.B:f3}";
            TxbSideC.Text = $"{_parallelepiped.C:f3}";
            TxbDensity.Text = $"{_parallelepiped.Density:f3}";

            // начальное значение меток вывода результата
            LblAreaResult.Text = LblVolumeResult.Text = LblMassResult.Text = EmptyResult;
        } // ParallelepipedForm


        // вычисление параметров прямоугольного параллелепипеда по заданию
        private void BtnCalc_Click(object sender, EventArgs e) {
            // ошибок уровня модели на прямоугольном параллелепипеде нет
            
            // получить текущие данные из полей ввода
            _parallelepiped.A = double.Parse(TxbSideA.Text);
            _parallelepiped.B = double.Parse(TxbSideB.Text);
            _parallelepiped.C = double.Parse(TxbSideC.Text);
            
            // плотность получаем из радио-кнопок, следующую строку вообще
            // можем удалить :) 
            // _parallelepiped.Density = double.Parse(TxbDensity.Text);

            // вычисление параметров, если это задано
            LblAreaResult.Text   = ChbArea.Checked   ? $"{_parallelepiped.Area:n3}" : "Расчет не требуется";
            LblVolumeResult.Text = ChbVolume.Checked ? $"{_parallelepiped.Volume:n3}" : "Расчет не требуется";
            LblMassResult.Text   = ChbMass.Checked   ? $"{_parallelepiped.Mass:n3}" : "Расчет не требуется";
        } // BtnCalc_Click


        // при вводе данных:
        // a) очищаем элемент отображения ошибки (ссылка на элемент отображения
        //    ошибки должна быть записана в поле Tag строки ввода)
        // b) очищаем поле вывода результата
        private void Txb_TextChanged(object sender, EventArgs e) {
            TextBox textBox = sender as TextBox;

            // очистка признака ошибки
            ErrorProvider errorProvider = (ErrorProvider)textBox.Tag;
            errorProvider.Clear();

            // очистка поля вывода результатов
            LblAreaResult.Text = LblVolumeResult.Text = LblMassResult.Text = EmptyResult;
        } // Txb_TextChanged


        // проверяем, что вводится вещественное число, большее нуля
        private void Txb_Validating(object sender, CancelEventArgs e) {
            TextBox textBox = sender as TextBox;
            ErrorProvider errorProvider = (ErrorProvider)textBox.Tag;

            bool result = double.TryParse(textBox.Text, out double temp);
            if (result) {
                if (temp <= 0)
                    errorProvider.SetError(textBox, "Отрицательное или нулевое значение не допустимо");
            } else {
                errorProvider.SetError(textBox, "Введено не число");
            }// if


            // разрешение кнопки "Вычислить" только при корректных параметрах 
            // в строках ввода
            BtnCalc.Enabled = errorProvider.GetError(TxbSideA).Length == 0 &&
                              errorProvider.GetError(TxbSideB).Length == 0 &&
                              errorProvider.GetError(TxbSideC).Length == 0;
        } // Txb_Validating



        // обработчик кликов по радиокнопкам выбора материала, из которого создано тело
        private void RbtMaterial_Click(object sender, EventArgs e) {
            RadioButton rbt = sender as RadioButton;
            MaterialViewModel viewModel = Materials.Data[(string)rbt.Tag];

            // задать картинку материала
            PcbMaterial.Image = Image.FromFile(@"..\..\Images\Materials\" + viewModel?.ImageFile);

            // задать плотность материала
            _parallelepiped.Density = viewModel.Density;

            // отобразить плотность материала в TextBox
            TxbDensity.Text = $"{_parallelepiped.Density:f3}";
            TxbDensity.SelectionLength = 0;

            // т.к. данные для расчета изменились, очищаем поле вывода результата
            LblAreaResult.Text = LblVolumeResult.Text = LblMassResult.Text = EmptyResult;
        } // RbtMaterial_Click
    }
}
