﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

using SerializationJson.Helpers;
using SerializationJson.Models;

namespace SerializationJson.App
{
    // Общая часть приложения, создание объекта для выполнения задания
    internal partial class Application
    {
        // коллекция для обработки
        private BookingOffice _bookingOffice;

        // имя файла для сериализации
        private string _bookingOfficeFileName;

        // конструкторы - по умолчанию, с внедрением параметров 
        public Application() : this(new BookingOffice(), @"..\..\booking.json") {
            _bookingOffice.Initialize();
            _bookingOffice.Name = "Закажи сегодня";
        } // Application

        public Application(BookingOffice bookingOffice, string bookingOfficeFileName) {
            _bookingOffice = bookingOffice;
            _bookingOfficeFileName = bookingOfficeFileName;
        } // Application
    } // class Application
}
