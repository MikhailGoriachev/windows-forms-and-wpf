﻿using System;
using System.Collections.Generic;
using System.Linq;

using System.Text;
using System.Threading.Tasks;

// для атрибутов сериализации
// добавить сборку System.Runtime.Serialization.dll. 
using System.Runtime.Serialization;

namespace SerializationJson.Models
{
    // модель для сериализации в формате JSON
    [DataContract]
    public class SerializeModel
    {
        // название фирмы, занимающейся заказами авиабилетов
        [DataMember]
        public string Name { get; set; }

        // коллекция авиабилетов для сериализации
        [DataMember]
        public List<Ticket> Tickets { get; set; }

        // по правилам, требуется явно указать конструктор по умолчанию
        // практика показывает, что код может работать и без этого конструктора 
        public SerializeModel() {}
    } // SerializeModel
}
