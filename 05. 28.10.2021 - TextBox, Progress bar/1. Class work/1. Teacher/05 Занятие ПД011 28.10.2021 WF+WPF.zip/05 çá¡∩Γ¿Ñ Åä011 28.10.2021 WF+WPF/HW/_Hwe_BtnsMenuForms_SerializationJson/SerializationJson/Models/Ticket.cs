﻿using System;
using System.CodeDom;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using SerializationJson.Helpers;

namespace SerializationJson.Models
{
    // Заявка на авибилет содержит:
    //     • номер заявки,
    //     • пункт назначения,
    //     • номер рейса,
    //     • фамилию и инициалы пассажира,
    //     • желаемую дату вылета.
    [Serializable]
    public class Ticket
    {
        // номер заявки
        private int _number;
        public int Number {
            get => _number;
            set {
                if (value <= 0)
                    throw new ArgumentOutOfRangeException("Ticket. Недопутимое значение номера заявки");
                _number = value;
            } // set
        } // Number

        // пункт назначения
        private string _destination;
        public string Destination {
            get => _destination;
            set {
                if (string.IsNullOrWhiteSpace(value))
                    throw new ArgumentNullException("Ticket. Не указан пункт назначения");
                _destination = value;
            }
        } // Destination

        // номер рейса
        private string _flight;
        public string Flight {
            get => _flight;
            set {
                if (string.IsNullOrWhiteSpace(value))
                    throw new ArgumentNullException("Ticket. Не указан номер рейса");
                _flight = value;
            }
        } // Destination

        // фамилия и инициалы пассажира
        private string _paxFullName;
        public string PaxFullName {
            get => _paxFullName;
            set {
                if (string.IsNullOrWhiteSpace(value))
                    throw new ArgumentNullException("Ticket. Не указан номер рейса");
                _paxFullName = value;
            }
        } // PaxFullName

        // желаемая дата вылета
        private DateTime _departureDate;
        public DateTime DepartureDate {
            get => _departureDate; 
            set => _departureDate = value;
        }

        // конструкторы
        public Ticket():this(1, "Моспино", "А4", "Иванов В.А.", 
            DateTime.Now) {
        }

        public Ticket(int number, string destination, string flight, string paxFullName, DateTime departureDate) {
            _number = number;
            _destination = destination;
            _flight = flight;
            _paxFullName = paxFullName;

            _departureDate = departureDate;
        }

        // фабричный метод для формирования заявки на авиабилет
        public static Ticket Generate() {
            string[] fullNames = {
                "Семенов Р.М.",   "Дунаев В.Б.",   "Харламова Ю.В.", "Олегова И.В.", 
                "Янковский В.В.", "Абалкин Л.Ж.",  "Горбовски Д.В.", "Каммерер М.А.",
                "Романова П.В.",  "Воликова И.А.", "Жукова Р.Б.",    "Денисова Д.А.",    
                "Соколов Д.В.",   "Лебедев К.К."

            };
            (string flightNumber, string destination)[] flights = {
                ("АФ4567", "Сочи"),               ("FL91AS", "Геленджик"),      ("PB9812", "Воронеж"),               
                ("ALF081", "Берлин"),             ("PB9231", "Саратов"),        ("AFL002", "Иваново"),
                ("PB1233", "Шарм-эш-Шейх"),       ("FL98AS", "Ростов-на-дону"), ("AFL033", "Париж, шарль де-Голль"), 
                ("АФ9811", "Москва, Внуково"),    ("АФ0011", "Владивосток"),    ("AFL021", "Париж, Орли"), 
                ("АФ9821", "Москва, Домодедово"), ("PB0911", "Симферополь"),    ("PB7812", "Ярославль"), 
                ("PB2271", "Астрахань")
            };

            int indexFlight = Utils.GetRandom(0, flights.Length - 1);
            return new Ticket {
                _number = Utils.GetRandom(10000, 99999),
                _flight = flights[indexFlight].flightNumber,
                _destination = flights[indexFlight].destination,
                _paxFullName = fullNames[Utils.GetRandom(0, fullNames.Length-1)],
                DepartureDate = new DateTime(
                    Utils.GetRandom(2021, 2022),
                    Utils.GetRandom(1, 12),
                    Utils.GetRandom(1, 28))
            };
        } // Generate

        // строковое представление заявки на авиабилет
        public override string ToString() =>
            $"заявка {_number}: {_flight} -> {_destination}, {DepartureDate}, {_paxFullName}";

        // вывод данных о заявке на авиабилет в формате строки таблицы
        public string ToTableRow(int row) =>
            $"│ {row, 3} │ {_number,-6} │ {_flight,-12} │ {_destination,-26} " +
            $"│ {DepartureDate:dd/MM/yyyy}  │ {_paxFullName, -22} │";


        // статический метод для вывода шапки таблицы
        public static string Header(int indent) {
            string spaces = " ".PadRight(indent);
            string str =
                $"{spaces}┌─────┬────────┬──────────────┬────────────────────────────┬─────────────┬────────────────────────┐\n" +
                $"{spaces}│  N  │ Номер  │ Номер        │ Пункт                      │  Желаемая   │ Фамилия И.О.           │\n" +
                $"{spaces}│ п/п │ заявки │        рейса │       назначения           │ дата вылета │              пассажира │\n" +
                $"{spaces}├─────┼────────┼──────────────┼────────────────────────────┼─────────────┼────────────────────────┤\n";
            return str;
        } // Header

        // статический метод для вывода подвала таблицы
        public static string Footer(int indent) =>
            $"{" ".PadRight(indent)}" +
            $"└─────┴────────┴──────────────┴────────────────────────────┴─────────────┴────────────────────────┘";
    } // class Ticket
}
