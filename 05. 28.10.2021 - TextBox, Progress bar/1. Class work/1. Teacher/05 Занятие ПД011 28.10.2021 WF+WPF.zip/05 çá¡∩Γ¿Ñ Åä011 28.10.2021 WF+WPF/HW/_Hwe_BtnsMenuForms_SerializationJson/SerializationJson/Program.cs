﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualBasic;

using SerializationJson.Helpers;
using SerializationJson.Models;
using SerializationJson.App;

/*
 * Напишите консольное приложение для учета заявок на авиабилеты. Каждая заявка
 * содержит: номер заявки, пункт назначения, номер рейса, фамилию и инициалы
 * пассажира, желаемую дату вылета. Для хранения данных использовать класс
 * List<>.
 * Приложение должно обеспечивать выбор с помощью меню и выполнение одной из
 * следующих функций:
 *     • формирование коллекции заявок, сериализация коллекции в формате JSON
 *     • десериализаця из файла в формате JSON в список заявок
 *     • вывод всех заявок из коллекции в консоль
 *     • выборка в еще один список заявок по заданному номеру рейса и дате
 *       вылета при помощи именованного итератора;
 *     • добавление заявки в список, сериализация коллекции в формате JSON;
 *     • удаление заявок из списка по номеру заявки, сериализация коллекции
 *       в формате JSON;
 *     • удаление всех заявок из списка, сериализация коллекции в формате
 *       JSON;
 *     • упорядочивание списка заявок по номеру рейса, сериализация коллекции
 *       в формате JSON
 *     • упорядочивание списка заявок по желаемой дате рейса, сериализация
 *       коллекции в формате JSON
 * 
 */
namespace SerializationJson
{
    internal class Program
    {
        static void Main(string[] args) {
            Console.Title = "Задание на 28.10.2021 - коллекции, именованные итераторы, сериализация JSON";

            // простейшее меню приложения
            MenuItem[] menu = new[] {
                //----------------------------------------------------------------------------------------------
                new MenuItem {HotKey = ConsoleKey.Q, Text = "Заполнение коллекции заявок на авиабилеты начальными данными" },
                new MenuItem {HotKey = ConsoleKey.W, Text = "Вывод в консоль коллекции заявок на авиабилеты" },
                new MenuItem {HotKey = ConsoleKey.E, Text = "Выборка заявок по номеру рейса и желаемой дате вылета" },
                new MenuItem {HotKey = ConsoleKey.R, Text = "Добавление заявки на авиабилет в коллекцию" },
                new MenuItem {HotKey = ConsoleKey.T, Text = "Удаление заявки на авиабилет по номеру заявки" },
                new MenuItem {HotKey = ConsoleKey.Y, Text = "Удаление всех заявок на авиабилеты из коллекции" },
                new MenuItem {HotKey = ConsoleKey.U, Text = "Сортировка коллекции заявок на авиабилеты по номеру рейса" },
                new MenuItem {HotKey = ConsoleKey.I, Text = "Сортировка коллекции заявок на авиабилеты по желаемой дате вылета" },
                new MenuItem {HotKey = ConsoleKey.O, Text = "Для проверки. Сериализация коллекции заявок в формате JSON" },
                new MenuItem {HotKey = ConsoleKey.P, Text = "Для проверки. Десериализация коллекции заявок из формата JSON" },
                //----------------------------------------------------------------------------------------------
                new MenuItem {HotKey = ConsoleKey.Z, Text = "Выход" },
            };

            // Создание экземпляра класса приложения
            Application app = new Application();

            // главный цикл приложения
            while (true) {
                try {
                    // настройка цветового оформления
                    (Console.ForegroundColor, Console.BackgroundColor) = (ConsoleColor.Gray, ConsoleColor.DarkGray);
                    Console.Clear();
                    Console.CursorVisible = false;

                    Utils.ShowNavBarTask("  C# - именованные итераторы, бинарная сериализация, XML-сериализация");
                    Utils.ShowMenu(12, 5, "Меню приложения для работы с коллекцией объектов, итераторами, сериализацией", menu);

                    // получить код нажатой клавиши, не отображать символ клавиши
                    Console.BackgroundColor = ConsoleColor.Gray;
                    string msg = "  Нажмите выделенную цветом клавишу для выбора пункта меню".PadRight(Console.WindowWidth - 1);
                    Utils.WriteXY(0, Console.WindowHeight - 1, msg, ConsoleColor.Black);

                    ConsoleKey key = Console.ReadKey(true).Key;
                    (Console.ForegroundColor, Console.BackgroundColor) = (ConsoleColor.Gray, ConsoleColor.DarkGray);
                    Console.Clear();

                    switch (key) {
                        // ------------------------------------------------------------
                        // пункты меню, относящиеся к задаче 1
                        #region Задача 1
                        // Заполнение коллекции заявок на авиабилеты начальными данными
                        case ConsoleKey.Q:
                            app.InitializeAndShow();
                            break;

                        // Вывод в консоль коллекции заявок на авиабилеты
                        case ConsoleKey.W:
                            app.Show();
                            break;

                        // Выборка заявок по номеру рейса и желаемой дате вылета
                        case ConsoleKey.E:
                            app.EnumerateByFlightNumberAndDepartureDate();
                            break;

                        // Добавление заявки на авиабилет в коллекцию
                        case ConsoleKey.R:
                            app.AddTicket();
                            break;

                        // Удаление заявки на авиабилет по номеру заявки
                        case ConsoleKey.T:
                            app.RemoveTicketByFlightNumber();
                            break;

                        // Удаление всех заявок на авиабилеты из коллекции
                        case ConsoleKey.Y:
                            app.RemoveAllTickets();
                            break;

                        // Сортировка коллекции заявок на авиабилеты по номеру рейса
                        case ConsoleKey.U:
                            app.OrderByFlightNumber();
                            break;

                        // Сортировка коллекции заявок на авиабилеты по желаемой дате вылета
                        case ConsoleKey.I:
                            app.OrderByDepartureDate();
                            break;

                        // Для проверки. Сериализация коллекции заявок в формате JSON
                        case ConsoleKey.O:
                            app.SerializatonByJson();
                            break;

                        // Для проверки. Десериализация коллекции заявок из формата JSON
                        case ConsoleKey.P:
                            app.DeserializatonByJson();
                            break;
                        #endregion

                        // Выход из приложения назначен на клавишу F10 или клавишу Z или клавишу Escape
                        case ConsoleKey.F10:
                        case ConsoleKey.Escape:
                        case ConsoleKey.Z:
                            Console.ResetColor();   // сброс цветового сочетания к исходному
                            Console.Clear();
                            Utils.WriteXY(0, Console.WindowHeight - 1, "Нажмите любую клавишу...", ConsoleColor.Gray);
                            Console.CursorVisible = true;
                            return;

                        default:
                            throw new Exception("Нет такой команды меню");
                    } // switch

                    // Ожидать нажатия любой клавиши по окончании работы пункта меню
                    Console.CursorVisible = true;
                    Console.BackgroundColor = ConsoleColor.Gray;
                    msg = "  Нажмите любую клавишу...".PadRight(Console.WindowWidth - 1);
                    Utils.WriteXY(0, Console.WindowHeight - 1, msg, ConsoleColor.Black);
                    Console.ReadKey(true);
                } // try

                // обработка исключений - просто вывести сообщение
                catch (Exception ex) {
                    Interaction.MsgBox(ex.Message, MsgBoxStyle.Critical | MsgBoxStyle.OkOnly, "Ошибка");
                } // try-catch

            } // while
        } // Main
    } // class Program
}
