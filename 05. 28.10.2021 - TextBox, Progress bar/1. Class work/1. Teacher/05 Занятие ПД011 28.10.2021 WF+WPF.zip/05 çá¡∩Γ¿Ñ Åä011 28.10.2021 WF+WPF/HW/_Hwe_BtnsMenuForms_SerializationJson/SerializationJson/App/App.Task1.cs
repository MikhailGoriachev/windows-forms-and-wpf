﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

using SerializationJson.Helpers;
using SerializationJson.Models;

namespace SerializationJson.App
{
    /*
     * Методы для решения задачи 1 
     */
    internal partial class Application
    {
        // Заполнение коллекции заявок на авиабилеты начальными данными
        // сериализация коллекции в JSON
        public void InitializeAndShow() {
            Utils.ShowNavBarTask("  Заполнение коллекции заявок на авиабилеты начальными данными");

            _bookingOffice.Initialize();
            _bookingOffice.SerializeJson(_bookingOfficeFileName);

            Console.WriteLine(_bookingOffice.ToTable("\t    Данные сформированы, сериализация в JSON выполнена ", 12));
        } // InitializeAndShow


        // Вывод в консоль коллекции заявок на авиабилеты        
        public void Show() {
            Utils.ShowNavBarTask("   Вывод в консоль коллекции заявок на авиабилеты");

            Console.WriteLine(_bookingOffice.ToTable("\t    Коллекция заявок на авиабилеты. ", 12));
        } // Show


        // При помощи именованного итератора вывести в список и консоль
        // заявки по номеру рейса и желаемой дате вылета
        public void EnumerateByFlightNumberAndDepartureDate() {
            Utils.ShowNavBarTask("  Выборка записей с заданным номером рейса и желаемой датой вылета " +
                                 "именованным итератором");

            // сформируем номер рейса для выборки из коллекции 
            // !!! тут использован индексатр !!!
            int index = Utils.GetRandom(0, _bookingOffice.Count - 1);
            string flight = _bookingOffice[index].Flight;
            DateTime departureDate = _bookingOffice[index].DepartureDate;

            // список заявок на авиабилеты с заданным номером рейса и желаемой дате вылета
            List<Ticket> list = new List<Ticket>();
            foreach (Ticket ticket in _bookingOffice.GetByFlightNumberAndDepartureDate(flight, departureDate))
                list.Add(ticket);

            // вывести список отобранных заявок на авиабилеты
            Console.WriteLine(_bookingOffice.ToTable(
                $"\tЗаявки на авиабилеты, рейс {flight} на дату {departureDate:dd/MM/yyyy}:",
                12, list));
        } // EnumerateBySurname


        // Добавление заявки на авиабилет в коллекцию
        // сериализация модифицированной коллекции в JSON
        public void AddTicket() {
            string txt = "  Добавление заявки на авиабилет в коллекцию";
            Utils.ShowNavBarTask(txt);

            // добавляемая заявка
            Ticket ticket = Ticket.Generate();

            Console.WriteLine(_bookingOffice.ToTable(
                $"\t   Заявки на авиабилеты до добавления заявки с номером {ticket.Number}"));
            Console.ReadKey(true);

            Console.Clear();
            Utils.ShowNavBarTask(txt);

            _bookingOffice.Add(ticket);
            _bookingOffice.SerializeJson(_bookingOfficeFileName);

            Console.WriteLine(_bookingOffice.ToTable(
                $"\t   Заявки на авиабилеты после добавления заявки с номером {ticket.Number}, " +
                $"выполнена сериализация"));
        } // AddTicket


        // Удаление заявки на авиабилет по номеру заявки
        // сериализация модифицированной коллекции в JSON
        public void RemoveTicketByFlightNumber() {
            string txt = "  Удаление заявки на авиабилет по номеру заявки";
            Utils.ShowNavBarTask(txt);

            // получить номер заявки для удаления
            // !!! тут использован индексатр !!!
            int number = _bookingOffice[Utils.GetRandom(0, _bookingOffice.Count - 1)].Number;
            Console.WriteLine(_bookingOffice.ToTable(
                $"\t   Заявки на авиабилеты до удаления заявки с номером {number}"));

            _bookingOffice.RemoveByNumber(number);
            _bookingOffice.SerializeJson(_bookingOfficeFileName);
            Console.ReadKey(true);

            Console.Clear();
            Utils.ShowNavBarTask(txt);
            Console.WriteLine(_bookingOffice.ToTable(
                $"\t    Удалена заявка на авиабилет с номером {number}, выполнена сериализация"));
        } // RemoveTicketByFlightNumber


        // Удаление всех заявок на авиабилеты из коллекции
        // сериализация модифицированной коллекции в JSON
        public void RemoveAllTickets() {
            string txt = "  Удаление всех заявок на авиабилеты из коллекции";
            Utils.ShowNavBarTask(txt);

            Console.WriteLine(_bookingOffice.ToTable($"\t   Заявки на авиабилеты до удаления"));
            Console.ReadKey(true);

            Console.Clear();
            Utils.ShowNavBarTask(txt);

            _bookingOffice.RemoveAll();
            _bookingOffice.SerializeJson(_bookingOfficeFileName);

            Console.WriteLine(_bookingOffice.ToTable(
                "\t    Все заявки на авиабилеты удалены, сериализация выполнена"));
        } // RemoveAllTickets


        // Сортировка коллекции заявок на авиабилеты по номеру рейса,
        // сериализация модифицированной коллекции в JSON
        public void OrderByFlightNumber() {
            Utils.ShowNavBarTask("  Сортировка коллекции заявок на авиабилеты по номеру рейса");

            _bookingOffice.OrderByFlight();
            _bookingOffice.SerializeJson(_bookingOfficeFileName);

            Console.WriteLine(_bookingOffice.ToTable(
                "\t    Заявки на авиабилеты, упорядоченные по номеру рейса, " +
                "выполнена сериализация"));
        } // OrderByFlightNumber


        // Сортировка коллекции заявок на авиабилеты по желаемой дате вылета, бинарная
        // сериализация модифицированной коллекции в JSON
        public void OrderByDepartureDate() {
            Utils.ShowNavBarTask("  Вывод записей, упорядоченных по желаемой дате вылета");

            _bookingOffice.OrderByDepartureDate();
            _bookingOffice.SerializeJson(_bookingOfficeFileName);

            Console.WriteLine(_bookingOffice.ToTable(
                "\t    Заявки на авиабилеты, упорядоченные по желаемой дате вылета, " +
                "выполнена сериализация"));
        } // OrderByDepartureDate


        // Для проверки. Сериализация коллекции заявок на авиабилеты в формате JSON
        public void SerializatonByJson() {
            Utils.ShowNavBarTask("  Сериализация коллекции заявок на авиабилеты в формате XML");

            _bookingOffice.SerializeJson(_bookingOfficeFileName);

            // Path - для работы с путями :)
            // Path.GetFileName() - получить только имя файла из полного имени файла
            Console.WriteLine(
                _bookingOffice.ToTable($"\t    Данные, сериализованы в файл " +
                                       $"{Path.GetFileName(_bookingOfficeFileName)} в формате JSON"));
        } // SerializatonByJson


        // Для проверки. Десериализация коллекции заявок на авиабилеты из формата JSON
        public void DeserializatonByJson() {
            Utils.ShowNavBarTask("  Десериализация коллекции заявок на авиабилеты в формате JSON");

            // если файла данных нет - выброс исключения
            if (!File.Exists(_bookingOfficeFileName))
                throw new Exception("Не найден файл данных. Выполните сериализацию в JSON.");

            _bookingOffice.RemoveAll();
            _bookingOffice = BookingOffice.DeserializeJson(_bookingOfficeFileName);

            // Path.GetFileName() - получить только имя файла из полного имени файла
            Console.WriteLine(
                _bookingOffice.ToTable($"\t    Данные, десериализованные из файла " +
                                       $"{Path.GetFileName(_bookingOfficeFileName)} в формате JSON"));
        } // SerializatonByJson

    } // class Application
}