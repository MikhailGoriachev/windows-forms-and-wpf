﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace H_W22C_.Models
{
    // Класс для учета заявок на авиабилеты.
    // Каждая заявка содержит:
    // *номер заявки,
    // *пункт назначения,
    // *номер рейса,
    // *фамилию и инициалы пассажира,
    // *желаемую дату вылета.
    [DataContract]  // для JSON
    public class RequestAirTicket
    {
        // номер заявки
        private int _numberRequest;
        [DataMember]
        public int NumberRequest
        {
            get => _numberRequest;
            set {
                if (value <= 0)
                        throw new ArgumentException($"RequestAirTicket: Недопустимое значение номера заявки: {value}");
                _numberRequest = value;
            }
        }// NumberRequest

        // пункт назначения
        private string _destination;
        [DataMember]
        public string Destination
        {
            get => _destination;
            set {
                if (string.IsNullOrWhiteSpace(value))
                    throw new ArgumentException("RequestAirTicket: Не верно задан пункт назначения или задан пустой строкой");
                _destination = value;
            }
        }// Destination

        // номер рейса
        private string _flightNumber;
        [DataMember]
        public string FlightNumber
        {
            get => _flightNumber;
            set {
                if (string.IsNullOrWhiteSpace(value))
                    throw new ArgumentException("RequestAirTicket: Не верно задан номер рейса или задан пустой строкой");
                _flightNumber = value;
            }
        }// FlightNumber

        // фамилию и инициалы пассажира
        private string _fullName;
        [DataMember]
        public string FullName
        {
            get => _fullName;
            set {
                if (string.IsNullOrWhiteSpace(value))
                    throw new ArgumentException("RequestAirTicket: Не верно заданы ФИО пассажира или задан пустой строкой");
                _fullName = value;
            }
        }// FullName

        // желаемая дата вылета
        private DateTime _departureDate;
        [DataMember]
        public DateTime DepartureDate
        {
            get => _departureDate;
            set {
                if (value < DateTime.Now)
                    throw new Exception("RequestAirTicket: Некорректная дата вылета");
                _departureDate = value;
            }
        }// DepartureDate

        // конструкторы
        public RequestAirTicket(int nRequest, string destination, string flightNum, string name, DateTime date)
        {
            _numberRequest = nRequest;
            _destination   = destination;
            _flightNumber  = flightNum;
            _fullName      = name;
            _departureDate = date;
        }// RequestAirTicket

        public RequestAirTicket() { }

        // шапка таблицы, статическое свойство
        public static string Header()
        {
            return
            $"\t┌────────┬────────────────────┬─────────┬────────────────┬──────────────┐\n" +
            $"\t│ Номер  │   Пункт            │ Номер   │      ФИО       │  Дата        │\n" +
            $"\t│ заявки │       назначения   │   рейса │   пассажира    │      вылета  │\n" +
            $"\t├────────┼────────────────────┼─────────┼────────────────┼──────────────┤\n";
        } // Header

        // подвал таблицы, статическое свойство
        public static string Footer() =>
            $"\t└────────┴────────────────────┴─────────┴────────────────┴──────────────┘\n";

        // вывод данных о заявке в формате строки таблицы
        public string ToTableRow() =>
           $"│ {_numberRequest,6} │ {_destination,-18} │ {_flightNumber,7} │ {_fullName,-14} │ {_departureDate,12:dd.MM.yyyy} │";

        // для вывода данных о заявке в строковом формате
        public override string ToString() =>
            $"│ {_numberRequest,6} │ {_destination,-18} │ {_flightNumber,7} │ {_fullName,-14} │ {_departureDate, 12:dd.MM.yyyy} │";

    }// class RequestAirTicket
}
