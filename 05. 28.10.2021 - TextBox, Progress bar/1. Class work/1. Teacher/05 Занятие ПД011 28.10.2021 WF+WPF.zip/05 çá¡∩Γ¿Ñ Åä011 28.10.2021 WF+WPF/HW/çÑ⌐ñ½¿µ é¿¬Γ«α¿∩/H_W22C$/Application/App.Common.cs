﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using H_W22C_.Models;

namespace H_W22C_.Application
{
    internal partial class App
    {
        // название файла для хранения данных в JSON формате
        private string _filenameRequest;
        private CollectionRequest _requests;

        public App(): this("../../request.json", new CollectionRequest()) { }

        public App(string filenameReq, CollectionRequest requests)
        {
            _filenameRequest = filenameReq;
            _requests        = requests;
        } // App


    }// class App
}
