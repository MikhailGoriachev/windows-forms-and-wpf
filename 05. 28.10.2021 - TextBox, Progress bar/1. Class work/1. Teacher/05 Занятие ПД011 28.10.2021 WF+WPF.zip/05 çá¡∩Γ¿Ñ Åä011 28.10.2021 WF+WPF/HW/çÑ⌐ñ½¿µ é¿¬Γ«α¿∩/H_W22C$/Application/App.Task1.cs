﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using H_W22C_.Models;

namespace H_W22C_.Application
{
    // решение для задачи 
    internal partial class App
    {
        // Формирование коллекции заявок, сериализация коллекции в формате JSON
        public void InitializeSerialize()
        {
            Utils.ShowNavBarTask("    Формирование коллекции заявок, сериализация коллекции в формате JSON");
            _requests.Initialize();
            _requests.SerializationJson(_filenameRequest);

        }// InitializeSerialize

        // Десериализаця из файла в формате JSON в список заявок
        public void CollectionDeserialize()
        {
            Utils.ShowNavBarTask("   Десериализаця из файла в формате JSON в список заявок");

            _requests.RemoveAllRequest();
            _requests.DeserializeJson(_filenameRequest);
        }// CollectionDeserialize

        // Вывод всех заявок из коллекции в консоль
        public void ShowCollection()
        {
            Utils.ShowNavBarTask("   Вывод всех заявок из коллекции в консоль");

            _requests.ShowList("\n\n\tКоллекция заявок:");

        }// ShowCollection

        // Выборка заявок по заданному номеру рейса и дате вылета при помощи именованного итератора
        public void EnumerateByFlightNum()
        {
            Utils.ShowNavBarTask("   Выборка заявок по заданному номеру рейса и дате вылета");

            int index = Utils.Random.Next(0, _requests.Count - 1);
            string flightnum = _requests.Requests[index].FlightNumber;
            DateTime date = _requests.Requests[index].DepartureDate;

            Console.WriteLine($"\n\t    Заданный номер рейса: {flightnum}\n\t    Заданная дата вылета: {date:dd.MM.yyyy}");

            // список заявок по номеру рейса и дате вылета
            List<RequestAirTicket> list = new List<RequestAirTicket>();
            foreach (RequestAirTicket req in _requests.GetFlightNumberDate(flightnum, date))
                list.Add(req);

            Show("\n\t Заявки по заданному номеру рейса и дате вылета : ", list);
        }// EnumerateByFlightNum

        // Добавление заявки в список, сериализация коллекции в формате JSON
        public void AddRequestAirTicket()
        {
            Utils.ShowNavBarTask("   Добавление заявки в список, сериализация коллекции в формате JSON");

            RequestAirTicket req = new RequestAirTicket(88, "Москва", "KL382", "Иванов И.И.", new DateTime(2022, 01, 10));
            _requests.Add(req);

            _requests.SerializationJson(_filenameRequest);
        }// AddRequestAirTicket

        // Удаление заявок из списка по номеру заявки, сериализация коллекции в формате JSON
        public void RemoveRequestAirTicket()
        {
            Utils.ShowNavBarTask("   Удаление заявок из списка по номеру заявки, сериализация коллекции в формате JSON");

            _requests.ShowList("\n\t Коллекция для удаления заявки:");

            Console.CursorVisible = true;
            Console.Write("\tВведите номер заявки для удаления: ");
            string str = Console.ReadLine();
            Console.CursorVisible = false;

            if (!int.TryParse(str, out int nRequest)) throw new Exception("Некорректный ввод!");
            _requests.Remove(req => req.NumberRequest == nRequest);
            _requests.SerializationJson(_filenameRequest);

        }// RemoveRequestAirTicket

        // Удаление всех заявок из списка, сериализация коллекции в формате JSON
        public void RemoveAllCollectionRequest()
        {
            Utils.ShowNavBarTask("   Удаление всех заявок из списка, сериализация коллекции в формате JSON");

            _requests.RemoveAllRequest();

            Console.WriteLine($"\n\n{" ".PadLeft(12)}Данные успешно удалены.");
            _requests.SerializationJson(_filenameRequest);

        }// RemoveAllCollectionRequest

        // Упорядочивание списка заявок по номеру рейса, сериализация коллекции в формате JSON
        public void SortCollectionByFlightNumber()
        {
            Utils.ShowNavBarTask("   Упорядочивание списка заявок по номеру рейса, сериализация коллекции в формате JSON");

            _requests.SortByFlightNumber();
            Console.Write($"\n\n{" ".PadLeft(8)}Заявки отсортированы по номеру рейса.");
            _requests.SerializationJson(_filenameRequest);
            
        }// SortCollectionByFlightNumber


        // Упорядочивание списка заявок по желаемой дате рейса, сериализация коллекции в формате JSON
        public void SortCollectionByDateFlight()
        {
            Utils.ShowNavBarTask("   Упорядочивание списка заявок по желаемой дате рейса, сериализация коллекции в формате JSON");

            _requests.SortByDepartureDate();
            Console.Write($"\n\n{" ".PadLeft(8)}Заявки отсортированы по желаемой дате вылета.");
            _requests.SerializationJson(_filenameRequest);
        }// SortCollectionByDateFlight



        // Вывод заявок сформированных итератором списка
        private void Show(string title, IEnumerable<RequestAirTicket> users)
        {            
            Console.Write($"{title}\n{RequestAirTicket.Header()}");

            foreach (var user in users) {
                Console.WriteLine($"\t{user.ToTableRow()}");
            } // foreach

            Console.WriteLine($"{RequestAirTicket.Footer()}");
        } // Show

    }// class App
}
