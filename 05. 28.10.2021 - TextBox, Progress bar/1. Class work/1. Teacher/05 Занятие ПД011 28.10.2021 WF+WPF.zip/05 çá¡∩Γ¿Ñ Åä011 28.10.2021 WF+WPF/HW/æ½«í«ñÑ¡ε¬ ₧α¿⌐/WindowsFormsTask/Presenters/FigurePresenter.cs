﻿using System;
using System.ComponentModel;
using System.Windows.Forms;
using FluentValidation;
using WindowsFormsTask.Helpers;
using WindowsFormsTask.Models;
using WindowsFormsTask.Models.Validators;
using WindowsFormsTask.Views;


namespace WindowsFormsTask.Presenters
{
	public sealed class FigurePresenter
	{
		private readonly IFigureFormView _view;
		private readonly IFigure _figure;
		private SolverOptions _options;
		private FigureValidator _validator;


		public FigurePresenter(IFigureFormView view, IFigure figure)
		{
			_view = view;
			_figure = figure;

			var info = FigureInfo.InfoBasedOnFigureType(_figure);

			_validator = FigureInfo.Validator;
			_view.SetFigureControl(info);
			_view.Area = _view.Volume = _view.Mass = 0;
		}


		private bool Validate()
		{
			var results = _validator.Validate(_figure);

			if (!results.IsValid)
			{
				MessageBox.Show(results.ToString("\n\n"),
					"Ошибка валидации", MessageBoxButtons.OK, MessageBoxIcon.Error);

				return false;
			}

			return true;
		}


		public void AreaCheckbox() => _options ^= SolverOptions.Area;

		public void VolumeCheckbox() => _options ^= SolverOptions.Volume;

		public void MassCheckbox() => _options ^= SolverOptions.Mass;


		public void Solve()
		{
			if (!Validate())
				return;

			_view.Area = _view.Volume = _view.Mass = 0;

			if (_options.HasFlagFast(SolverOptions.Area))
				_view.Area = _figure.Area();

			if (_options.HasFlagFast(SolverOptions.Volume))
				_view.Volume = _figure.Volume();

			if (_options.HasFlagFast(SolverOptions.Mass))
				_view.Mass = _figure.Mass();
		}


		public void DensityChange(RadioButton sender) => 
			_figure.Density = double.Parse((string)sender.Tag);
	}
}