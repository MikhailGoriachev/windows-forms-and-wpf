﻿namespace WindowsFormsTask.Views
{
	internal interface IMenuFormView { }
}