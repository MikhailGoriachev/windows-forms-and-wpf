﻿
namespace WindowsFormsTask.Controls
{
	sealed partial class CylinderInputControl
	{
		/// <summary> 
		/// Обязательная переменная конструктора.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary> 
		/// Освободить все используемые ресурсы.
		/// </summary>
		/// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Код, автоматически созданный конструктором компонентов

		/// <summary> 
		/// Требуемый метод для поддержки конструктора — не изменяйте 
		/// содержимое этого метода с помощью редактора кода.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			this.MainGrid = new System.Windows.Forms.TableLayoutPanel();
			this.RadiusTextBox = new System.Windows.Forms.TextBox();
			this.RadiusLabel = new System.Windows.Forms.Label();
			this.HeightLabel = new System.Windows.Forms.Label();
			this.HeightTextBox = new System.Windows.Forms.TextBox();
			this.MainErrorProvider = new System.Windows.Forms.ErrorProvider(this.components);
			this.MainGrid.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.MainErrorProvider)).BeginInit();
			this.SuspendLayout();
			// 
			// MainGrid
			// 
			this.MainGrid.ColumnCount = 2;
			this.MainGrid.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 43.20713F));
			this.MainGrid.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 56.79287F));
			this.MainGrid.Controls.Add(this.RadiusTextBox, 1, 2);
			this.MainGrid.Controls.Add(this.RadiusLabel, 0, 2);
			this.MainGrid.Controls.Add(this.HeightLabel, 0, 1);
			this.MainGrid.Controls.Add(this.HeightTextBox, 1, 1);
			this.MainGrid.Dock = System.Windows.Forms.DockStyle.Fill;
			this.MainGrid.Location = new System.Drawing.Point(0, 0);
			this.MainGrid.Name = "MainGrid";
			this.MainGrid.RowCount = 3;
			this.MainGrid.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 24.34211F));
			this.MainGrid.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 36.18421F));
			this.MainGrid.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 39.47368F));
			this.MainGrid.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
			this.MainGrid.Size = new System.Drawing.Size(449, 304);
			this.MainGrid.TabIndex = 1;
			// 
			// RadiusTextBox
			// 
			this.RadiusTextBox.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
			this.RadiusTextBox.Location = new System.Drawing.Point(197, 187);
			this.RadiusTextBox.Name = "RadiusTextBox";
			this.RadiusTextBox.Size = new System.Drawing.Size(249, 29);
			this.RadiusTextBox.TabIndex = 5;
			this.RadiusTextBox.Validating += new System.ComponentModel.CancelEventHandler(this.TextBox_Validating);
			// 
			// RadiusLabel
			// 
			this.RadiusLabel.Dock = System.Windows.Forms.DockStyle.Top;
			this.RadiusLabel.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
			this.RadiusLabel.Location = new System.Drawing.Point(3, 184);
			this.RadiusLabel.Name = "RadiusLabel";
			this.RadiusLabel.Size = new System.Drawing.Size(188, 34);
			this.RadiusLabel.TabIndex = 4;
			this.RadiusLabel.Text = "Радиус";
			this.RadiusLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// HeightLabel
			// 
			this.HeightLabel.Dock = System.Windows.Forms.DockStyle.Top;
			this.HeightLabel.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
			this.HeightLabel.Location = new System.Drawing.Point(3, 74);
			this.HeightLabel.Name = "HeightLabel";
			this.HeightLabel.Size = new System.Drawing.Size(188, 34);
			this.HeightLabel.TabIndex = 2;
			this.HeightLabel.Text = "Высота";
			this.HeightLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// HeightTextBox
			// 
			this.HeightTextBox.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
			this.HeightTextBox.Location = new System.Drawing.Point(197, 77);
			this.HeightTextBox.Name = "HeightTextBox";
			this.HeightTextBox.Size = new System.Drawing.Size(249, 29);
			this.HeightTextBox.TabIndex = 3;
			this.HeightTextBox.Validating += new System.ComponentModel.CancelEventHandler(this.TextBox_Validating);
			// 
			// MainErrorProvider
			// 
			this.MainErrorProvider.ContainerControl = this;
			this.MainErrorProvider.RightToLeft = true;
			// 
			// CylinderInputControl
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.Controls.Add(this.MainGrid);
			this.Name = "CylinderInputControl";
			this.Size = new System.Drawing.Size(449, 304);
			this.MainGrid.ResumeLayout(false);
			this.MainGrid.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.MainErrorProvider)).EndInit();
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.TableLayoutPanel MainGrid;
		private System.Windows.Forms.TextBox RadiusTextBox;
		private System.Windows.Forms.Label RadiusLabel;
		private System.Windows.Forms.Label HeightLabel;
		private System.Windows.Forms.TextBox HeightTextBox;
		private System.Windows.Forms.ErrorProvider MainErrorProvider;
	}
}
