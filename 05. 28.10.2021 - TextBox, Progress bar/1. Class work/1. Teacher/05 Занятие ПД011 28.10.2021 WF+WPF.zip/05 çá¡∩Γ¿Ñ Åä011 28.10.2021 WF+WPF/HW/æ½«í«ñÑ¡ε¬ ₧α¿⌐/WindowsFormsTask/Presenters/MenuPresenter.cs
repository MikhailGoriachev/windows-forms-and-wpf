﻿using WindowsFormsTask.Models;
using WindowsFormsTask.Views;


namespace WindowsFormsTask.Presenters
{
	internal sealed class MenuPresenter
	{
		private readonly IMenuFormView _form;


		public MenuPresenter(IMenuFormView form) => _form = form;


		public void StartCylinder() => new FigureForm(new Cylinder()).ShowDialog();

		public void StartSphere() => new FigureForm(new Sphere()).ShowDialog();

		public void StartParallelepiped() => new FigureForm(new Parallelepiped()).ShowDialog();

		public void StartTruncatedConoid() => new FigureForm(new TruncatedConoid()).ShowDialog();

		public void StartAboutProgram() => new AboutProgram().ShowDialog();
	}
}