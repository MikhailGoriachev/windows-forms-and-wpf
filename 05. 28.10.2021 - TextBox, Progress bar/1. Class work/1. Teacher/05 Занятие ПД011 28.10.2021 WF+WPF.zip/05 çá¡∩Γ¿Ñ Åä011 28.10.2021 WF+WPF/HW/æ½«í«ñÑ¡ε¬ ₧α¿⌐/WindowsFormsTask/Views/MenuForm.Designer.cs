﻿
namespace WindowsFormsTask.Views
{
	sealed partial class MenuForm
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MenuForm));
			this.TruncatedConoidButton = new System.Windows.Forms.Button();
			this.SphereButton = new System.Windows.Forms.Button();
			this.CylinderButton = new System.Windows.Forms.Button();
			this.ParallelepipedButton = new System.Windows.Forms.Button();
			this.AboutButton = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// TruncatedConoidButton
			// 
			this.TruncatedConoidButton.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
			this.TruncatedConoidButton.Location = new System.Drawing.Point(99, 48);
			this.TruncatedConoidButton.Name = "TruncatedConoidButton";
			this.TruncatedConoidButton.Size = new System.Drawing.Size(236, 64);
			this.TruncatedConoidButton.TabIndex = 0;
			this.TruncatedConoidButton.Text = "Усеченный конус";
			this.TruncatedConoidButton.UseVisualStyleBackColor = true;
			this.TruncatedConoidButton.Click += new System.EventHandler(this.TruncatedConoidButton_Click);
			// 
			// SphereButton
			// 
			this.SphereButton.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
			this.SphereButton.Location = new System.Drawing.Point(97, 128);
			this.SphereButton.Name = "SphereButton";
			this.SphereButton.Size = new System.Drawing.Size(236, 64);
			this.SphereButton.TabIndex = 1;
			this.SphereButton.Text = "Сфера";
			this.SphereButton.UseVisualStyleBackColor = true;
			this.SphereButton.Click += new System.EventHandler(this.SphereButton_Click);
			// 
			// CylinderButton
			// 
			this.CylinderButton.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
			this.CylinderButton.Location = new System.Drawing.Point(99, 208);
			this.CylinderButton.Name = "CylinderButton";
			this.CylinderButton.Size = new System.Drawing.Size(236, 64);
			this.CylinderButton.TabIndex = 2;
			this.CylinderButton.Text = "Цилиндр";
			this.CylinderButton.UseVisualStyleBackColor = true;
			this.CylinderButton.Click += new System.EventHandler(this.CylinderButton_Click);
			// 
			// ParallelepipedButton
			// 
			this.ParallelepipedButton.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
			this.ParallelepipedButton.Location = new System.Drawing.Point(97, 288);
			this.ParallelepipedButton.Name = "ParallelepipedButton";
			this.ParallelepipedButton.Size = new System.Drawing.Size(236, 64);
			this.ParallelepipedButton.TabIndex = 3;
			this.ParallelepipedButton.Text = "Прямоугольный параллелепипед";
			this.ParallelepipedButton.UseVisualStyleBackColor = true;
			this.ParallelepipedButton.Click += new System.EventHandler(this.ParallelepipedButton_Click);
			// 
			// AboutButton
			// 
			this.AboutButton.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
			this.AboutButton.Location = new System.Drawing.Point(98, 440);
			this.AboutButton.Name = "AboutButton";
			this.AboutButton.Size = new System.Drawing.Size(236, 64);
			this.AboutButton.TabIndex = 4;
			this.AboutButton.Text = "О Программе";
			this.AboutButton.UseVisualStyleBackColor = true;
			this.AboutButton.Click += new System.EventHandler(this.AboutButton_Click);
			// 
			// MenuForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(433, 513);
			this.Controls.Add(this.AboutButton);
			this.Controls.Add(this.ParallelepipedButton);
			this.Controls.Add(this.CylinderButton);
			this.Controls.Add(this.SphereButton);
			this.Controls.Add(this.TruncatedConoidButton);
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Name = "MenuForm";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Меню";
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.Button TruncatedConoidButton;
		private System.Windows.Forms.Button SphereButton;
		private System.Windows.Forms.Button CylinderButton;
		private System.Windows.Forms.Button ParallelepipedButton;
		private System.Windows.Forms.Button AboutButton;
	}
}