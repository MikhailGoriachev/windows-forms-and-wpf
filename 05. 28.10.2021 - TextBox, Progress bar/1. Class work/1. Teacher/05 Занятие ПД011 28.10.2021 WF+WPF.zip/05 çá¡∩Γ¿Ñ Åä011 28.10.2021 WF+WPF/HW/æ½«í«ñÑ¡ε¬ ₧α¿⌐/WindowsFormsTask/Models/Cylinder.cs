﻿using System;


namespace WindowsFormsTask.Models
{
	public sealed class Cylinder : IFigure
	{
		public double Height { get; set; }

		public double Radius { get; set; }

		public double Density { get; set; }


		public double Area()
		{
			double foundation = 2 * Math.PI * (Radius * Radius);
			double side = 2d * Math.PI * Radius * Height;

			return foundation + side;
		}


		public double Volume() => Math.PI * (Radius * Radius) * Height;
	}
}