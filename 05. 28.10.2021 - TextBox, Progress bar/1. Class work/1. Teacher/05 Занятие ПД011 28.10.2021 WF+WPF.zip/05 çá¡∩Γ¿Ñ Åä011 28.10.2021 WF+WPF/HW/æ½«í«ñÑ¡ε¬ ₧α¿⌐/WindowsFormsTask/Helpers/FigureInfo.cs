﻿using System;
using System.Drawing;
using System.Windows.Forms;
using WindowsFormsTask.Controls;
using WindowsFormsTask.Models;
using WindowsFormsTask.Models.Validators;
using WindowsFormsTask.Properties;


namespace WindowsFormsTask.Helpers
{
	public readonly struct FigureInfo
	{
		public UserControl Input { get; }

		public Bitmap Image { get; }

		public string Title { get; }

		public static FigureValidator Validator => new();


		public FigureInfo(UserControl input, Bitmap image, string title)
		{
			Input = input;
			Image = image;
			Title = title;
		}


		internal static FigureInfo InfoBasedOnFigureType(IFigure f) =>
			f switch
			{
				TruncatedConoid cone => new(new TruncatedConoidInputControl(cone),
					Resources.TruncatedConoid, "Усеченный конус"),

				Sphere s => new(new SphereInputControl(s), Resources.Sphere, "Сфера"),

				Parallelepiped p => new(new ParallelepipedInputControl(p), Resources.Parallelepiped,
					"Прямоугольный параллелепипед"),

				Cylinder c => new(new CylinderInputControl(c), Resources.Cylinder, "Цилиндр"),

				_ => throw new ArgumentException($"Фигура с типом {f.GetType().Name} не зарегистрирована",
						 nameof(f))
			};
	}
}