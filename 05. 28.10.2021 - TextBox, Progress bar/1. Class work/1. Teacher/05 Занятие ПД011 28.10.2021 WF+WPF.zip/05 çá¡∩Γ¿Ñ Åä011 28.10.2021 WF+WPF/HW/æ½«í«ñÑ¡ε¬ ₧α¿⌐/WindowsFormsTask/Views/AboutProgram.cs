﻿using System;
using System.Windows.Forms;


namespace WindowsFormsTask.Views
{
	public sealed partial class AboutProgram : Form
	{
		public AboutProgram() => InitializeComponent();


		private void MainTimer_Tick(object sender, EventArgs e) => Close();
	}
}