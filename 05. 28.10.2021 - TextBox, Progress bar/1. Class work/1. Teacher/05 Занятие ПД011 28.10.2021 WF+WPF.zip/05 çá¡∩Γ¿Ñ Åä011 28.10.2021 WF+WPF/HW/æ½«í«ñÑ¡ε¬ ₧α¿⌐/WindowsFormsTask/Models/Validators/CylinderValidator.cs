﻿using FluentValidation;


namespace WindowsFormsTask.Models.Validators
{
	internal sealed class CylinderValidator : AbstractValidator<Cylinder>
	{
		public CylinderValidator()
		{
			RuleFor(c => c.Radius)
				.Must(FigureValidator.Positive)
				.WithMessage("Радиус не может быть нулевым или отрицательным"); ;

			RuleFor(c => c.Height)
				.Must(FigureValidator.Positive)
				.WithMessage("Высота не может быть нулевой или отрицательной"); ;

			FigureValidator.CheckDensity(this);
		}
	}
}