﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsFormsTask.Models;


namespace WindowsFormsTask.Controls
{
	public partial class ParallelepipedInputControl : UserControl
	{
		public ParallelepipedInputControl(Parallelepiped par)
		{
			InitializeComponent();

			ASideTextBox
				.DataBindings
				.Add("Text", par, "A");

			BSideTextBox
				.DataBindings
				.Add("Text", par, "B");

			CSideTextBox
				.DataBindings
				.Add("Text", par, "C");
		}


		private void TextBox_Validating(object sender, CancelEventArgs e)
		{
			OnValidating(e);

			ControlsHelpers.Validating(sender as TextBox, MainErrorProvider, e);
		}
	}
}
