﻿using System;
using System.Windows.Forms;
using WindowsFormsTask.Helpers;
using WindowsFormsTask.Models;
using WindowsFormsTask.Presenters;


namespace WindowsFormsTask.Views
{
	public sealed partial class FigureForm : Form, IFigureFormView
	{
		private readonly FigurePresenter _presenter;


		public FigureForm(IFigure figure)
		{
			InitializeComponent();

			_presenter = new(this, figure);

			
		}


		private static void SetResult(Control result, double value) =>
			result.Text = $"{value:F}";


		double IFigureFormView.Area
		{
			set => SetResult(AreaResult, value);
		}

		double IFigureFormView.Volume
		{
			set => SetResult(VolumeResult, value);
		}

		double IFigureFormView.Mass
		{
			set => SetResult(MassResult, value);
		}


		public void SetFigureControl(FigureInfo info)
		{
			MainGrid.Controls.Add(info.Input, 0, 0);
			FigurePictureBox.Image = info.Image;
			Text = info.Title;
		}


		private void SolveButton_Click(object sender, EventArgs e) =>
			_presenter.Solve();


		private void AreaCheckbox_CheckedChanged(object sender, EventArgs e) =>
			_presenter.AreaCheckbox();


		private void VolumeCheckbox_CheckedChanged(object sender, EventArgs e) =>
			_presenter.VolumeCheckbox();


		private void MassCheckbox_CheckedChanged(object sender, EventArgs e) =>
			_presenter.MassCheckbox();


		private void RadioButton_CheckedChanged(object sender, EventArgs e) => 
			_presenter.DensityChange(sender as RadioButton);
	}
}