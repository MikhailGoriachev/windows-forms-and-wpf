﻿
namespace WindowsFormsTask.Views
{
	sealed partial class FigureForm
	{
		/// <summary>
		///  Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		///  Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		///  Required method for Designer support - do not modify
		///  the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FigureForm));
			this.MainGrid = new System.Windows.Forms.TableLayoutPanel();
			this.SolvePanel = new System.Windows.Forms.Panel();
			this.SolveButton = new System.Windows.Forms.Button();
			this.AreaCheckbox = new System.Windows.Forms.CheckBox();
			this.VolumeCheckbox = new System.Windows.Forms.CheckBox();
			this.MassCheckbox = new System.Windows.Forms.CheckBox();
			this.ResultsTable = new System.Windows.Forms.TableLayoutPanel();
			this.MassResult = new System.Windows.Forms.Label();
			this.MassInfo = new System.Windows.Forms.Label();
			this.VolumeInfo = new System.Windows.Forms.Label();
			this.VolumeResult = new System.Windows.Forms.Label();
			this.AreaResult = new System.Windows.Forms.Label();
			this.AreaInfo = new System.Windows.Forms.Label();
			this.FigurePictureBox = new System.Windows.Forms.PictureBox();
			this.MaterialGroupBox = new System.Windows.Forms.GroupBox();
			this.GraniteRadioButton = new System.Windows.Forms.RadioButton();
			this.WaterIceRadioButton = new System.Windows.Forms.RadioButton();
			this.CopperRadioButton = new System.Windows.Forms.RadioButton();
			this.SteelRadioButton = new System.Windows.Forms.RadioButton();
			this.MainGrid.SuspendLayout();
			this.SolvePanel.SuspendLayout();
			this.ResultsTable.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.FigurePictureBox)).BeginInit();
			this.MaterialGroupBox.SuspendLayout();
			this.SuspendLayout();
			// 
			// MainGrid
			// 
			this.MainGrid.AutoSize = true;
			this.MainGrid.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
			this.MainGrid.ColumnCount = 3;
			this.MainGrid.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 37.82961F));
			this.MainGrid.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 37.7282F));
			this.MainGrid.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 24.44219F));
			this.MainGrid.Controls.Add(this.SolvePanel, 1, 1);
			this.MainGrid.Controls.Add(this.ResultsTable, 0, 1);
			this.MainGrid.Controls.Add(this.FigurePictureBox, 1, 0);
			this.MainGrid.Controls.Add(this.MaterialGroupBox, 2, 0);
			this.MainGrid.Dock = System.Windows.Forms.DockStyle.Fill;
			this.MainGrid.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
			this.MainGrid.Location = new System.Drawing.Point(0, 0);
			this.MainGrid.Name = "MainGrid";
			this.MainGrid.RowCount = 2;
			this.MainGrid.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 65.82569F));
			this.MainGrid.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 34.17431F));
			this.MainGrid.Size = new System.Drawing.Size(986, 459);
			this.MainGrid.TabIndex = 0;
			// 
			// SolvePanel
			// 
			this.SolvePanel.AutoSize = true;
			this.SolvePanel.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
			this.SolvePanel.Controls.Add(this.SolveButton);
			this.SolvePanel.Controls.Add(this.AreaCheckbox);
			this.SolvePanel.Controls.Add(this.VolumeCheckbox);
			this.SolvePanel.Controls.Add(this.MassCheckbox);
			this.SolvePanel.Dock = System.Windows.Forms.DockStyle.Fill;
			this.SolvePanel.Location = new System.Drawing.Point(375, 305);
			this.SolvePanel.Name = "SolvePanel";
			this.SolvePanel.Size = new System.Drawing.Size(366, 151);
			this.SolvePanel.TabIndex = 0;
			// 
			// SolveButton
			// 
			this.SolveButton.Anchor = System.Windows.Forms.AnchorStyles.None;
			this.SolveButton.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
			this.SolveButton.Location = new System.Drawing.Point(111, 84);
			this.SolveButton.Name = "SolveButton";
			this.SolveButton.Size = new System.Drawing.Size(144, 48);
			this.SolveButton.TabIndex = 0;
			this.SolveButton.Text = "Вычислить";
			this.SolveButton.UseVisualStyleBackColor = true;
			this.SolveButton.Click += new System.EventHandler(this.SolveButton_Click);
			// 
			// AreaCheckbox
			// 
			this.AreaCheckbox.Anchor = System.Windows.Forms.AnchorStyles.None;
			this.AreaCheckbox.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
			this.AreaCheckbox.Location = new System.Drawing.Point(243, 28);
			this.AreaCheckbox.Name = "AreaCheckbox";
			this.AreaCheckbox.Size = new System.Drawing.Size(100, 32);
			this.AreaCheckbox.TabIndex = 3;
			this.AreaCheckbox.Text = "Площадь";
			this.AreaCheckbox.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.AreaCheckbox.UseVisualStyleBackColor = true;
			this.AreaCheckbox.CheckedChanged += new System.EventHandler(this.AreaCheckbox_CheckedChanged);
			// 
			// VolumeCheckbox
			// 
			this.VolumeCheckbox.Anchor = System.Windows.Forms.AnchorStyles.None;
			this.VolumeCheckbox.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
			this.VolumeCheckbox.Location = new System.Drawing.Point(23, 28);
			this.VolumeCheckbox.Name = "VolumeCheckbox";
			this.VolumeCheckbox.Size = new System.Drawing.Size(100, 32);
			this.VolumeCheckbox.TabIndex = 2;
			this.VolumeCheckbox.Text = "Объем";
			this.VolumeCheckbox.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.VolumeCheckbox.UseVisualStyleBackColor = true;
			this.VolumeCheckbox.CheckedChanged += new System.EventHandler(this.VolumeCheckbox_CheckedChanged);
			// 
			// MassCheckbox
			// 
			this.MassCheckbox.Anchor = System.Windows.Forms.AnchorStyles.None;
			this.MassCheckbox.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
			this.MassCheckbox.Location = new System.Drawing.Point(133, 28);
			this.MassCheckbox.Name = "MassCheckbox";
			this.MassCheckbox.Size = new System.Drawing.Size(100, 32);
			this.MassCheckbox.TabIndex = 1;
			this.MassCheckbox.Text = "Масса";
			this.MassCheckbox.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.MassCheckbox.UseVisualStyleBackColor = true;
			this.MassCheckbox.CheckedChanged += new System.EventHandler(this.MassCheckbox_CheckedChanged);
			// 
			// ResultsTable
			// 
			this.ResultsTable.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
			this.ResultsTable.ColumnCount = 2;
			this.ResultsTable.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 35.2459F));
			this.ResultsTable.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 64.7541F));
			this.ResultsTable.Controls.Add(this.MassResult, 1, 2);
			this.ResultsTable.Controls.Add(this.MassInfo, 0, 2);
			this.ResultsTable.Controls.Add(this.VolumeInfo, 0, 1);
			this.ResultsTable.Controls.Add(this.VolumeResult, 1, 1);
			this.ResultsTable.Controls.Add(this.AreaResult, 1, 0);
			this.ResultsTable.Controls.Add(this.AreaInfo, 0, 0);
			this.ResultsTable.Dock = System.Windows.Forms.DockStyle.Fill;
			this.ResultsTable.Location = new System.Drawing.Point(3, 305);
			this.ResultsTable.Name = "ResultsTable";
			this.ResultsTable.RowCount = 3;
			this.ResultsTable.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
			this.ResultsTable.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
			this.ResultsTable.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
			this.ResultsTable.Size = new System.Drawing.Size(366, 151);
			this.ResultsTable.TabIndex = 2;
			// 
			// MassResult
			// 
			this.MassResult.AutoSize = true;
			this.MassResult.Dock = System.Windows.Forms.DockStyle.Fill;
			this.MassResult.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
			this.MassResult.Location = new System.Drawing.Point(132, 99);
			this.MassResult.Name = "MassResult";
			this.MassResult.Size = new System.Drawing.Size(230, 51);
			this.MassResult.TabIndex = 5;
			this.MassResult.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// MassInfo
			// 
			this.MassInfo.AutoSize = true;
			this.MassInfo.Dock = System.Windows.Forms.DockStyle.Fill;
			this.MassInfo.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
			this.MassInfo.Location = new System.Drawing.Point(4, 99);
			this.MassInfo.Name = "MassInfo";
			this.MassInfo.Size = new System.Drawing.Size(121, 51);
			this.MassInfo.TabIndex = 4;
			this.MassInfo.Text = "Масса: ";
			this.MassInfo.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// VolumeInfo
			// 
			this.VolumeInfo.AutoSize = true;
			this.VolumeInfo.Dock = System.Windows.Forms.DockStyle.Fill;
			this.VolumeInfo.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
			this.VolumeInfo.Location = new System.Drawing.Point(4, 50);
			this.VolumeInfo.Name = "VolumeInfo";
			this.VolumeInfo.Size = new System.Drawing.Size(121, 48);
			this.VolumeInfo.TabIndex = 3;
			this.VolumeInfo.Text = "Объем:";
			this.VolumeInfo.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// VolumeResult
			// 
			this.VolumeResult.AutoSize = true;
			this.VolumeResult.Dock = System.Windows.Forms.DockStyle.Fill;
			this.VolumeResult.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
			this.VolumeResult.Location = new System.Drawing.Point(132, 50);
			this.VolumeResult.Name = "VolumeResult";
			this.VolumeResult.Size = new System.Drawing.Size(230, 48);
			this.VolumeResult.TabIndex = 2;
			this.VolumeResult.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// AreaResult
			// 
			this.AreaResult.AutoSize = true;
			this.AreaResult.Dock = System.Windows.Forms.DockStyle.Fill;
			this.AreaResult.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
			this.AreaResult.Location = new System.Drawing.Point(132, 1);
			this.AreaResult.Name = "AreaResult";
			this.AreaResult.Size = new System.Drawing.Size(230, 48);
			this.AreaResult.TabIndex = 1;
			this.AreaResult.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// AreaInfo
			// 
			this.AreaInfo.AutoSize = true;
			this.AreaInfo.Dock = System.Windows.Forms.DockStyle.Fill;
			this.AreaInfo.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
			this.AreaInfo.Location = new System.Drawing.Point(4, 1);
			this.AreaInfo.Name = "AreaInfo";
			this.AreaInfo.Size = new System.Drawing.Size(121, 48);
			this.AreaInfo.TabIndex = 0;
			this.AreaInfo.Text = "Площадь:";
			this.AreaInfo.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// FigurePictureBox
			// 
			this.FigurePictureBox.Dock = System.Windows.Forms.DockStyle.Fill;
			this.FigurePictureBox.Location = new System.Drawing.Point(387, 15);
			this.FigurePictureBox.Margin = new System.Windows.Forms.Padding(15);
			this.FigurePictureBox.Name = "FigurePictureBox";
			this.FigurePictureBox.Size = new System.Drawing.Size(342, 272);
			this.FigurePictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
			this.FigurePictureBox.TabIndex = 3;
			this.FigurePictureBox.TabStop = false;
			this.FigurePictureBox.WaitOnLoad = true;
			// 
			// MaterialGroupBox
			// 
			this.MaterialGroupBox.Controls.Add(this.GraniteRadioButton);
			this.MaterialGroupBox.Controls.Add(this.WaterIceRadioButton);
			this.MaterialGroupBox.Controls.Add(this.CopperRadioButton);
			this.MaterialGroupBox.Controls.Add(this.SteelRadioButton);
			this.MaterialGroupBox.Dock = System.Windows.Forms.DockStyle.Fill;
			this.MaterialGroupBox.Location = new System.Drawing.Point(759, 15);
			this.MaterialGroupBox.Margin = new System.Windows.Forms.Padding(15);
			this.MaterialGroupBox.Name = "MaterialGroupBox";
			this.MainGrid.SetRowSpan(this.MaterialGroupBox, 2);
			this.MaterialGroupBox.Size = new System.Drawing.Size(212, 429);
			this.MaterialGroupBox.TabIndex = 4;
			this.MaterialGroupBox.TabStop = false;
			this.MaterialGroupBox.Text = "Материал";
			// 
			// GraniteRadioButton
			// 
			this.GraniteRadioButton.AutoSize = true;
			this.GraniteRadioButton.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
			this.GraniteRadioButton.Location = new System.Drawing.Point(16, 335);
			this.GraniteRadioButton.Name = "GraniteRadioButton";
			this.GraniteRadioButton.Size = new System.Drawing.Size(78, 25);
			this.GraniteRadioButton.TabIndex = 3;
			this.GraniteRadioButton.TabStop = true;
			this.GraniteRadioButton.Tag = "2700";
			this.GraniteRadioButton.Text = "Гранит";
			this.GraniteRadioButton.UseVisualStyleBackColor = true;
			this.GraniteRadioButton.CheckedChanged += new System.EventHandler(this.RadioButton_CheckedChanged);
			// 
			// WaterIceRadioButton
			// 
			this.WaterIceRadioButton.AutoSize = true;
			this.WaterIceRadioButton.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
			this.WaterIceRadioButton.Location = new System.Drawing.Point(16, 246);
			this.WaterIceRadioButton.Name = "WaterIceRadioButton";
			this.WaterIceRadioButton.Size = new System.Drawing.Size(119, 25);
			this.WaterIceRadioButton.TabIndex = 2;
			this.WaterIceRadioButton.TabStop = true;
			this.WaterIceRadioButton.Tag = "900";
			this.WaterIceRadioButton.Text = "Водяной лед";
			this.WaterIceRadioButton.UseVisualStyleBackColor = true;
			this.WaterIceRadioButton.CheckedChanged += new System.EventHandler(this.RadioButton_CheckedChanged);
			// 
			// CopperRadioButton
			// 
			this.CopperRadioButton.AutoSize = true;
			this.CopperRadioButton.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
			this.CopperRadioButton.Location = new System.Drawing.Point(17, 157);
			this.CopperRadioButton.Name = "CopperRadioButton";
			this.CopperRadioButton.Size = new System.Drawing.Size(67, 25);
			this.CopperRadioButton.TabIndex = 1;
			this.CopperRadioButton.TabStop = true;
			this.CopperRadioButton.Tag = "920";
			this.CopperRadioButton.Text = "Медь";
			this.CopperRadioButton.UseVisualStyleBackColor = true;
			this.CopperRadioButton.CheckedChanged += new System.EventHandler(this.RadioButton_CheckedChanged);
			// 
			// SteelRadioButton
			// 
			this.SteelRadioButton.AutoSize = true;
			this.SteelRadioButton.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
			this.SteelRadioButton.Location = new System.Drawing.Point(17, 68);
			this.SteelRadioButton.Name = "SteelRadioButton";
			this.SteelRadioButton.Size = new System.Drawing.Size(187, 25);
			this.SteelRadioButton.TabIndex = 0;
			this.SteelRadioButton.TabStop = true;
			this.SteelRadioButton.Tag = "7800";
			this.SteelRadioButton.Text = "Сталь (нержавеющая)";
			this.SteelRadioButton.UseVisualStyleBackColor = true;
			this.SteelRadioButton.CheckedChanged += new System.EventHandler(this.RadioButton_CheckedChanged);
			// 
			// FigureForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
			this.ClientSize = new System.Drawing.Size(986, 459);
			this.Controls.Add(this.MainGrid);
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Name = "FigureForm";
			this.ShowInTaskbar = false;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.MainGrid.ResumeLayout(false);
			this.MainGrid.PerformLayout();
			this.SolvePanel.ResumeLayout(false);
			this.ResultsTable.ResumeLayout(false);
			this.ResultsTable.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.FigurePictureBox)).EndInit();
			this.MaterialGroupBox.ResumeLayout(false);
			this.MaterialGroupBox.PerformLayout();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.TableLayoutPanel MainGrid;
		private System.Windows.Forms.Panel SolvePanel;
		private System.Windows.Forms.Button SolveButton;
		private System.Windows.Forms.CheckBox AreaCheckbox;
		private System.Windows.Forms.CheckBox VolumeCheckbox;
		private System.Windows.Forms.CheckBox MassCheckbox;
		private System.Windows.Forms.TableLayoutPanel ResultsTable;
		private System.Windows.Forms.Label MassResult;
		private System.Windows.Forms.Label MassInfo;
		private System.Windows.Forms.Label VolumeInfo;
		private System.Windows.Forms.Label VolumeResult;
		private System.Windows.Forms.Label AreaResult;
		private System.Windows.Forms.Label AreaInfo;
		private System.Windows.Forms.PictureBox FigurePictureBox;
		private System.Windows.Forms.GroupBox MaterialGroupBox;
		private System.Windows.Forms.RadioButton GraniteRadioButton;
		private System.Windows.Forms.RadioButton WaterIceRadioButton;
		private System.Windows.Forms.RadioButton CopperRadioButton;
		private System.Windows.Forms.RadioButton SteelRadioButton;
	}
}

