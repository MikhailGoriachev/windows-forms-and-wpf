﻿using FluentValidation;


namespace WindowsFormsTask.Models.Validators
{
	internal sealed class ParallelepipedValidator : AbstractValidator<Parallelepiped>
	{
		public ParallelepipedValidator()
		{
			RuleFor(x => x.A)
				.Must(FigureValidator.Positive)
				.WithMessage("Сторона \"A\" не может быть нулевой или отрицательной");

			RuleFor(x => x.B)
				.Must(FigureValidator.Positive)
				.WithMessage("Сторона \"B\" не может быть нулевой или отрицательной");

			RuleFor(x => x.C)
				.Must(FigureValidator.Positive)
				.WithMessage("Сторона \"С\" не может быть нулевой или отрицательной");

			FigureValidator.CheckDensity(this);
		}
	}
}