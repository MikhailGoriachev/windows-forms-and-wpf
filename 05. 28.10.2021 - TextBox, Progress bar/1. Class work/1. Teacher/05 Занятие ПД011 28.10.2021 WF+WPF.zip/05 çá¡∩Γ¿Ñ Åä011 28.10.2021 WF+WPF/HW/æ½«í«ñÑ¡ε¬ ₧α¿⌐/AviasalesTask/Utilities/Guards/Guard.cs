﻿namespace AviasalesTask.Utilities.Guards
{
	public static class Guard
	{
		public static Guardian Against { get; } = new();
	}
}