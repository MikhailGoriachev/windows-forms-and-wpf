﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using AviasalesTask.Utilities;
using AviasalesTask.Utilities.TableFormatter;
using Newtonsoft.Json;


namespace AviasalesTask
{
	public sealed class Controller
	{
		private List<Ticket> _tickets = new();
		private readonly Range<int> _sizeRange;
		private readonly string _jsonPath;


		public Controller(Range<int> sizeRange, string jsonPath)
		{
			_sizeRange = sizeRange;
			_jsonPath = jsonPath;
		}


		public void Fill()
		{
			_tickets.Clear();

			TicketFactory factory = new();

			int size = _tickets.Capacity = _sizeRange.RandomBetween;
			for (int i = 0; i < size; i++)
				_tickets.Add(factory.Create());

			Save();
		}


		public void Show() => Show(_tickets);


		public void Show(IEnumerable<Ticket> tickets, Action<Ticket> coloring = null) =>
			new TableFormatter<Ticket>().Show(tickets);


		public IEnumerable<Ticket> Where(Func<Ticket, bool> predicate) => _tickets.Where(predicate);


		public void Save()
		{
			var stream = File.Create(_jsonPath);

			using var json = new JsonTextWriter(new StreamWriter(stream));

			new JsonSerializer
			{
				Formatting = Formatting.Indented,
				DateFormatString = "d"
			}.Serialize(json, _tickets);
		}


		private List<Ticket> LoadItems()
		{
			var stream = File.Open(_jsonPath, FileMode.Open);

			using var json = new JsonTextReader(new StreamReader(stream));

			return new JsonSerializer().Deserialize<List<Ticket>>(json);
		}


		public void Load() => _tickets = LoadItems();


		public void Add(Ticket ticket)
		{
			_tickets.Add(ticket);

			Save();
		}


		public void Remove(string code)
		{
			_tickets.RemoveAll(t => t.Code.Equals(code, StringComparison.CurrentCulture));

			Save();
		}


		public void Replace(IEnumerable<Ticket> tickets)
		{
			_tickets = tickets as List<Ticket> ?? tickets.ToList();

			Save();
		}


		public void Clear()
		{
			_tickets.Clear();

			File.Delete(_jsonPath);
		}


		public IEnumerable<Ticket> OrderBy<TKey>(Func<Ticket, TKey> selector) => _tickets.OrderBy(selector);
	}
}