﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualBasic;   // для доступа к возможностям класса Interaction
using JSONserialization.Helpers;
using JSONserialization.Application;

using System.Runtime.Serialization;

namespace JSONserialization
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Задание на 28.10.2021";

            // простейшее меню приложения
            MenuItem[] menu = new[] {
                new MenuItem { HotKey = ConsoleKey.Q, Text = "Формирование коллекции заявок" },
                new MenuItem { HotKey = ConsoleKey.W, Text = "Десериализаця из файла в формате JSON" },
                new MenuItem { HotKey = ConsoleKey.E, Text = "Вывод всех заявок из коллекции в консоль" },
                new MenuItem { HotKey = ConsoleKey.R, Text = "Выборка заявок по заданному номеру рейса и дате вылета" },
                new MenuItem { HotKey = ConsoleKey.T, Text = "Добавление заявки в список" },
                new MenuItem { HotKey = ConsoleKey.Y, Text = "Удаление заявки из списка" },
                new MenuItem { HotKey = ConsoleKey.A, Text = "Удаление всех заявок из списка" },
                new MenuItem { HotKey = ConsoleKey.S, Text = "Упорядочить заявки по номеру рейса" },
                new MenuItem { HotKey = ConsoleKey.D, Text = "Упорядочить заявки по желаемой дате рейса" },
                //--------------------------------------------------------------------------------------------------------------------------
                new MenuItem { HotKey = ConsoleKey.Z, Text = "Выход" },
            };
            // Создание экземпляра класса приложения
            App app = new App();

            // главный цикл приложения
            while (true) {
                try {

                    // настройка цветового оформления
                    Console.ForegroundColor = ConsoleColor.Gray;
                    Console.BackgroundColor = ConsoleColor.DarkGray;
                    Utils.SaveColor();
                    Console.Clear();
                    Console.CursorVisible = false;

                    Utils.ShowNavBarTask("  Задание на 28.10.2021");
                    Utils.ShowMenu(12, 5, "Главное меню приложения", menu);

                    // получить код нажатой клавиши, не отображать символ клавиши
                    ConsoleKey key = Console.ReadKey(true).Key;
                    Console.Clear();

                    switch (key) {
                        // Формирование коллекции заявок
                        case ConsoleKey.Q:
                            app.RequestsInitialize();
                            break;

                        // Десериализаця из файла в формате JSON
                        case ConsoleKey.W:
                            app.DemoJSONDeserialize();
                            break;

                        // Вывод всех заявок из коллекции в консоль
                        case ConsoleKey.E:
                            app.ShowRequests();
                            break;

                        // Выборка заявок по заданному номеру рейса и дате вылета
                        case ConsoleKey.R:
                            app.SelectByFlightNumAndDate();
                            break;

                        // Добавление заявки в список
                        case ConsoleKey.T:
                            app.AddRequest();
                            break;

                        // Удаление заявки из списка
                        case ConsoleKey.Y:
                            app.RemoveRequest();
                            break;

                        // Удаление всех заявок из списка
                        case ConsoleKey.A:
                            app.RemoveAllRequests();
                            break;


                        // Упорядочить заявки по номеру рейса
                        case ConsoleKey.S:
                            app.DemoOrderByFlightNum();
                            break;

                        // Упорядочить заявки по желаемой дате рейса
                        case ConsoleKey.D:
                            app.DemoOrderByDate();
                            break;


                        // выход из приложения назначен на клавишу F10 или кавишу Z
                        case ConsoleKey.F10:
                        case ConsoleKey.Z:
                            Console.ResetColor();   // сброс цветового сочетания к исходному
                            Console.Clear();
                            Utils.WriteXY(0, Console.WindowHeight - 1, "", ConsoleColor.Gray);
                            Console.CursorVisible = true;
                            return;

                        default:
                            throw new Exception("Такого пункта нет в меню!");
                    } // switch

                }
                catch (Exception ex) {
                    Console.Clear();
                    ConsoleColor oldColor = Console.BackgroundColor;
                    Console.BackgroundColor = ConsoleColor.Red;
                    Utils.WriteXY(20, 9, "                                                                                        \n", ConsoleColor.White);
                    Utils.WriteXY(20, 10, "  ************************************************************************************  \n", ConsoleColor.White);
                    Utils.WriteXY(20, 11, "  *                                   Исключение.                                    *  \n", ConsoleColor.White);
                    Utils.WriteXY(20, 12, $"  * {ex.Message, -79}  *  \n", ConsoleColor.White);
                    Utils.WriteXY(20, 13, "  *                                                                                  *  \n", ConsoleColor.White);
                    Utils.WriteXY(20, 14, "  ************************************************************************************  \n", ConsoleColor.White);
                    Utils.WriteXY(20, 15, "                                                                                        \n", ConsoleColor.White);
                    Console.BackgroundColor = oldColor;
                }
                finally { 
                    // Ожидать нажатия любой клавиши по окончании работы пункта меню
                    Console.CursorVisible = true;
                    Utils.WriteXY(0, Console.WindowHeight - 1, "Нажмите любую клавишу...", ConsoleColor.Gray);
                    Console.ReadKey(true);
                }
            } // while
        } // Main
    }
}
