﻿
namespace _001_Figures
{
    partial class InformationForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.BtnOk = new System.Windows.Forms.Button();
            this.LblDeveloperInformation = new System.Windows.Forms.Label();
            this.LblProgramInformation = new System.Windows.Forms.Label();
            this.tmr = new System.Windows.Forms.Timer(this.components);
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.BtnOk);
            this.groupBox1.Controls.Add(this.LblDeveloperInformation);
            this.groupBox1.Controls.Add(this.LblProgramInformation);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(373, 232);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = " О программе: ";
            // 
            // BtnOk
            // 
            this.BtnOk.Location = new System.Drawing.Point(256, 183);
            this.BtnOk.Name = "BtnOk";
            this.BtnOk.Size = new System.Drawing.Size(102, 32);
            this.BtnOk.TabIndex = 2;
            this.BtnOk.Text = "Ok";
            this.BtnOk.UseVisualStyleBackColor = true;
            this.BtnOk.Click += new System.EventHandler(this.BtnOk_Click);
            // 
            // LblDeveloperInformation
            // 
            this.LblDeveloperInformation.Font = new System.Drawing.Font("Tahoma", 10F);
            this.LblDeveloperInformation.Location = new System.Drawing.Point(19, 127);
            this.LblDeveloperInformation.Name = "LblDeveloperInformation";
            this.LblDeveloperInformation.Size = new System.Drawing.Size(253, 20);
            this.LblDeveloperInformation.TabIndex = 1;
            this.LblDeveloperInformation.Text = "Разработчик: Дубина Алиса, ПД011";
            // 
            // LblProgramInformation
            // 
            this.LblProgramInformation.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblProgramInformation.Location = new System.Drawing.Point(18, 36);
            this.LblProgramInformation.Name = "LblProgramInformation";
            this.LblProgramInformation.Size = new System.Drawing.Size(281, 96);
            this.LblProgramInformation.TabIndex = 0;
            this.LblProgramInformation.Text = "Приложение Windows Forms для вычислений параметров объемных геометрических фигур " +
    "по выбору пользователя";
            // 
            // tmr
            // 
            this.tmr.Interval = 10000;
            this.tmr.Tick += new System.EventHandler(this.tmr_Tick);
            // 
            // InformationForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(397, 256);
            this.Controls.Add(this.groupBox1);
            this.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.MaximizeBox = false;
            this.Name = "InformationForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "О программе";
            this.groupBox1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button BtnOk;
        private System.Windows.Forms.Label LblDeveloperInformation;
        private System.Windows.Forms.Label LblProgramInformation;
        private System.Windows.Forms.Timer tmr;
    }
}