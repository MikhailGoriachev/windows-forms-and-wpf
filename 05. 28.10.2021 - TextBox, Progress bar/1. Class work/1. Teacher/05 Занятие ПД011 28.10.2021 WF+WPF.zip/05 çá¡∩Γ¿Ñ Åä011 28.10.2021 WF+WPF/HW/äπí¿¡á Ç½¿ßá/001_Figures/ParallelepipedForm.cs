﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using _001_Figures.Models;

namespace _001_Figures
{
    public partial class ParallelepipedForm : Form
    {
        // Данные для обработки
        private Parallelepiped _parallelepiped;
        public ParallelepipedForm() {
            InitializeComponent();
            _parallelepiped = new Parallelepiped { Density = Program.steelDensity};
        } // ParallelepipedForm

        private void btnExit_Click(object sender, EventArgs e) => Close();

        private void btnCalculate_Click(object sender, EventArgs e) {
            double area;    // площадь 
            double massa;   // масса 
            double volume;  // объем 

            // Получить исходные данные для расчета
            _parallelepiped.A = MainForm.ParseValue(TbxSideA, ErpSideA  , out bool res1);
            _parallelepiped.B = MainForm.ParseValue(TbxSideB, ErpSideB  , out bool res2);
            _parallelepiped.C = MainForm.ParseValue(TbxHeight, ErpHeight, out bool res3);

            // расчет объема
            if (chbVolume.Checked) {
                volume = _parallelepiped.CalcVolume();
                lblVolume.Text = $"Объем параллелепипеда: {volume:n3}";
            }
            else
                lblVolume.Text = "Объем параллелепипеда: расчет не требуется";

            // расчет площади
            if (chbArea.Checked) {
                area = _parallelepiped.CalcArea();
                LblArea.Text = $"Площадь параллелепипеда: {area:n3}";
            }
            else
                LblArea.Text = "Площадь параллелепипеда: расчет не требуется";

            // расчет массы
            if (chbMassa.Checked) {
                massa = _parallelepiped.CalcMassa();
                LblMassa.Text = $"Масса параллелепипеда: {massa:n3}";
            }
            else
                LblMassa.Text = "Масса параллелепипеда: расчет не требуется";

            if (!res1 || !res2 || !res3) ClearResult();
        } // btnCalculate_Click

        private void ClearResult() {
            lblVolume.Text = "Объем параллелепипеда: ";
            LblArea.Text = "Площадь параллелепипеда: ";
            LblMassa.Text = "Масса параллелепипеда: ";
        } // ClearResult

        private void TbxSideA_TextChanged(object sender, EventArgs e) {
            ErpSideA.SetError(TbxSideA, "");
            ClearResult();
        } // TbxSideA_TextChanged

        private void TbxSideB_TextChanged(object sender, EventArgs e) {
            ErpSideB.SetError(TbxSideB, "");
            ClearResult();
        } // TbxSideB_TextChanged

        private void TbxHeight_TextChanged(object sender, EventArgs e) {
            ErpHeight.SetError(TbxHeight, "");
            ClearResult();
        } // TbxHeight_TextChanged


        private void RbtSteel_CheckedChanged(object sender, EventArgs e) {
            _parallelepiped.Density = Program.steelDensity;
            // смена картинки 
            PcbMaterial.Image = Properties.Resources.steel;
        } // RbtSteel_CheckedChanged

        private void RbtCopper_CheckedChanged(object sender, EventArgs e) {
            _parallelepiped.Density = Program.copperDensity;
            // смена картинки 
            PcbMaterial.Image = Properties.Resources.copper;
        } // RbtCopper_CheckedChanged

        private void RbtIce_CheckedChanged(object sender, EventArgs e) {
            _parallelepiped.Density = Program.iceDensity;
            // смена картинки 
            PcbMaterial.Image = Properties.Resources.ice;
        } // RbtIce_CheckedChanged

        private void RbtGranite_CheckedChanged(object sender, EventArgs e) {
            _parallelepiped.Density = Program.graniteDensity;
            // смена картинки 
            PcbMaterial.Image = Properties.Resources.granite;
        } // RbtGranite_CheckedChanged
    }
}
