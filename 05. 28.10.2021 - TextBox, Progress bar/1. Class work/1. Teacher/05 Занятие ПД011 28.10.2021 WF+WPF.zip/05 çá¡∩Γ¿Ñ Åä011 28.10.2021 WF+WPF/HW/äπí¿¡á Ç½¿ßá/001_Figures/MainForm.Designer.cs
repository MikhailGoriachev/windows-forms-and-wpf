﻿
namespace _001_Figures
{
    partial class MainForm
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.BtnOuit = new System.Windows.Forms.Button();
            this.BtnInformation = new System.Windows.Forms.Button();
            this.BtnParallelepiped = new System.Windows.Forms.Button();
            this.BtnCylinder = new System.Windows.Forms.Button();
            this.BtnSphere = new System.Windows.Forms.Button();
            this.BtnConoid = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.SystemColors.Control;
            this.label1.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(12, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(279, 30);
            this.label1.TabIndex = 4;
            this.label1.Text = "Выберите фигуру для вычислений:";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // BtnOuit
            // 
            this.BtnOuit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.BtnOuit.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BtnOuit.Location = new System.Drawing.Point(151, 341);
            this.BtnOuit.Name = "BtnOuit";
            this.BtnOuit.Size = new System.Drawing.Size(123, 39);
            this.BtnOuit.TabIndex = 5;
            this.BtnOuit.Text = "Выход";
            this.BtnOuit.UseVisualStyleBackColor = false;
            this.BtnOuit.Click += new System.EventHandler(this.BtnOuit_Click);
            // 
            // BtnInformation
            // 
            this.BtnInformation.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BtnInformation.Location = new System.Drawing.Point(27, 341);
            this.BtnInformation.Name = "BtnInformation";
            this.BtnInformation.Size = new System.Drawing.Size(123, 39);
            this.BtnInformation.TabIndex = 6;
            this.BtnInformation.Text = "О программе";
            this.BtnInformation.UseVisualStyleBackColor = true;
            this.BtnInformation.Click += new System.EventHandler(this.BtnInformation_Click);
            // 
            // BtnParallelepiped
            // 
            this.BtnParallelepiped.Image = global::_001_Figures.Properties.Resources.Parallelepiped;
            this.BtnParallelepiped.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnParallelepiped.Location = new System.Drawing.Point(27, 270);
            this.BtnParallelepiped.Name = "BtnParallelepiped";
            this.BtnParallelepiped.Size = new System.Drawing.Size(247, 63);
            this.BtnParallelepiped.TabIndex = 3;
            this.BtnParallelepiped.Text = "Прямоугольный параллелепипед";
            this.BtnParallelepiped.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.BtnParallelepiped.UseVisualStyleBackColor = true;
            this.BtnParallelepiped.Click += new System.EventHandler(this.BtnParallelepiped_Click);
            // 
            // BtnCylinder
            // 
            this.BtnCylinder.Image = global::_001_Figures.Properties.Resources.Cylinder;
            this.BtnCylinder.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnCylinder.Location = new System.Drawing.Point(27, 199);
            this.BtnCylinder.Name = "BtnCylinder";
            this.BtnCylinder.Size = new System.Drawing.Size(247, 63);
            this.BtnCylinder.TabIndex = 2;
            this.BtnCylinder.Text = "Цилиндр";
            this.BtnCylinder.UseVisualStyleBackColor = true;
            this.BtnCylinder.Click += new System.EventHandler(this.BtnCylinder_Click);
            // 
            // BtnSphere
            // 
            this.BtnSphere.Image = global::_001_Figures.Properties.Resources.Sphere;
            this.BtnSphere.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnSphere.Location = new System.Drawing.Point(27, 128);
            this.BtnSphere.Name = "BtnSphere";
            this.BtnSphere.Size = new System.Drawing.Size(247, 63);
            this.BtnSphere.TabIndex = 1;
            this.BtnSphere.Text = "Сфера";
            this.BtnSphere.UseVisualStyleBackColor = true;
            this.BtnSphere.Click += new System.EventHandler(this.BtnSphere_Click);
            // 
            // BtnConoid
            // 
            this.BtnConoid.Image = global::_001_Figures.Properties.Resources.Conoid;
            this.BtnConoid.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnConoid.Location = new System.Drawing.Point(27, 57);
            this.BtnConoid.Name = "BtnConoid";
            this.BtnConoid.Size = new System.Drawing.Size(247, 63);
            this.BtnConoid.TabIndex = 0;
            this.BtnConoid.Text = "Усеченный конус";
            this.BtnConoid.UseVisualStyleBackColor = true;
            this.BtnConoid.Click += new System.EventHandler(this.BtnConoid_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(303, 403);
            this.Controls.Add(this.BtnInformation);
            this.Controls.Add(this.BtnOuit);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.BtnParallelepiped);
            this.Controls.Add(this.BtnCylinder);
            this.Controls.Add(this.BtnSphere);
            this.Controls.Add(this.BtnConoid);
            this.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.MaximizeBox = false;
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Задание на 28.10.2021";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button BtnConoid;
        private System.Windows.Forms.Button BtnSphere;
        private System.Windows.Forms.Button BtnParallelepiped;
        private System.Windows.Forms.Button BtnCylinder;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button BtnInformation;
        private System.Windows.Forms.Button BtnOuit;
    }
}

