﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _001_Figures.Models
{
    // Прямоугольный параллелепипед
    class Parallelepiped {
         // сторона А
        private double _a;
        public double A {
            get => _a;
            set {
                if (value <= 0)
                    throw new ArgumentException("Parallelepiped. Отрицательная или нулевая сторона A");
                _a = value;
            } // set
        } // A


        // сторона B
        private double _b;
        public double B {
            get => _b;
            set {
                if (value <= 0)
                    throw new ArgumentException("Parallelepiped. Отрицательная или нулевая сторона B");
                _b = value;
            } // set
        } // B


        // сторона C
        private double _c;
        public double C {
            get => _c;
            set {
                if (value <= 0)
                    throw new ArgumentException("Parallelepiped. Отрицательная или нулевая сторона C");
                _c = value;
            } // set
        } // C

        // плотность материала
        private double _density;
        public double Density {
            get => _density;
            set {
                if (value <= 0)
                    throw new ArgumentException("Parallelepiped. Отрицательная или нулевая плотность материала");
                _density = value;
            } // set
        } // Density

        // Вычисление площади параллелепипеда
        public double CalcArea() => _a * _b * _c;

        // Вычисление объема параллелепипеда
        public double CalcVolume() => 2d * (_a * _b + _a * _c + _c * _b);

        // Вычисление массы параллелепипеда
        public double CalcMassa() =>
            CalcVolume() * Density;
    } // Parallelepiped
}
