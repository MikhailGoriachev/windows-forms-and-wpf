﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using _001_Figures.Models;

namespace _001_Figures
{
    public partial class ConoidForm : Form
    {

        // Данные для обработки
        private Conoid _conoid;
        public ConoidForm() {
            InitializeComponent();
            _conoid = new Conoid { Density = Program.steelDensity};

        } // ConoidForm

        private void btnExit_Click(object sender, EventArgs e) => Close();

        private void btnCalculate_Click(object sender, EventArgs e) {
            double area;   // площадь конуса
            double massa;   // масса конуса
            double volume;  // объем конус

            // Получить исходные данные для расчета
            _conoid.Radius1 = MainForm.ParseValue(TbxRadius1, ErpRadius1, out bool res1);
            _conoid.Radius2 = MainForm.ParseValue(TbxRadius2, ErpRadius2, out bool res2);
            _conoid.Height = MainForm.ParseValue(TbxHeight, ErpHeight   , out bool res3);

            // расчет объема
            if (chbVolume.Checked) {
                volume = _conoid.CalcVolume();
                lblVolume.Text = $"Объем усеченного конуса: {volume:n3}";
            }
            else
                lblVolume.Text = "Объем усеченного конуса: расчет не требуется";

            // расчет площади
            if (chbArea.Checked){
                area = _conoid.CalcArea();
                LblArea.Text = $"Площадь усеченного конуса: {area:n3}";
            }
            else
                LblArea.Text = "Площадь усеченного конуса: расчет не требуется";

            // расчет массы
            if (chbMassa.Checked) {
                massa = _conoid.CalcMassa();
                LblMassa.Text = $"Масса усеченного конуса: {massa:n3}";
            }
            else 
                LblMassa.Text = "Масса усеченного конуса: расчет не требуется";

            if (!res1 || !res2 || !res3) ClearResult();
        } // btnCalculate_Click

        private void ClearResult() {
            lblVolume.Text = "Объем усеченного конуса: ";
            LblArea.Text = "Площадь усеченного конуса: ";
            LblMassa.Text = "Масса усеченного конуса: ";
        } // ClearResult

        private void TbxRadius1_TextChanged(object sender, EventArgs e) {
            ErpRadius1.SetError(TbxRadius1, "");
            ClearResult();
        } // TbxRadius1_TextChanged
        private void TbxRadius2_TextChanged(object sender, EventArgs e) {
            ErpRadius2.SetError(TbxRadius2, "");
            ClearResult();
        } // TbxRadius2_TextChanged
        private void TbxHeight_TextChanged(object sender, EventArgs e) {
            ErpHeight.SetError(TbxHeight, "");
            ClearResult();
        } // TbxHeight_TextChanged
        private void RbtSteel_CheckedChanged(object sender, EventArgs e) {
            _conoid.Density = Program.steelDensity;
            // смена картинки 
            PcbMaterial.Image = Properties.Resources.steel;
        } // RbtSteel_CheckedChanged

        private void RbtCopper_CheckedChanged(object sender, EventArgs e) {
            _conoid.Density = Program.copperDensity;
            // смена картинки 
            PcbMaterial.Image = Properties.Resources.copper;
        } // RbtCopper_CheckedChanged

        private void RbtIce_CheckedChanged(object sender, EventArgs e) {
            _conoid.Density = Program.iceDensity;
            // смена картинки 
            PcbMaterial.Image = Properties.Resources.ice;
        } // RbtIce_CheckedChanged

        private void RbtGranite_CheckedChanged(object sender, EventArgs e) {
            _conoid.Density = Program.graniteDensity;
            // смена картинки 
            PcbMaterial.Image = Properties.Resources.granite;
        } // RbtGranite_CheckedChanged


    }
}
