﻿
namespace _001_Figures
{
    partial class ConoidForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.grbData = new System.Windows.Forms.GroupBox();
            this.TbxHeight = new System.Windows.Forms.TextBox();
            this.LblHeight = new System.Windows.Forms.Label();
            this.TbxRadius2 = new System.Windows.Forms.TextBox();
            this.TbxRadius1 = new System.Windows.Forms.TextBox();
            this.LblRadius2 = new System.Windows.Forms.Label();
            this.LblRadius1 = new System.Windows.Forms.Label();
            this.chbVolume = new System.Windows.Forms.CheckBox();
            this.chbArea = new System.Windows.Forms.CheckBox();
            this.chbMassa = new System.Windows.Forms.CheckBox();
            this.grbResult = new System.Windows.Forms.GroupBox();
            this.LblMassa = new System.Windows.Forms.Label();
            this.LblArea = new System.Windows.Forms.Label();
            this.lblVolume = new System.Windows.Forms.Label();
            this.btnCalculate = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.ErpRadius1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.ErpRadius2 = new System.Windows.Forms.ErrorProvider(this.components);
            this.ErpHeight = new System.Windows.Forms.ErrorProvider(this.components);
            this.PcbConoid = new System.Windows.Forms.PictureBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.PcbMaterial = new System.Windows.Forms.PictureBox();
            this.RbtGranite = new System.Windows.Forms.RadioButton();
            this.RbtIce = new System.Windows.Forms.RadioButton();
            this.RbtCopper = new System.Windows.Forms.RadioButton();
            this.RbtSteel = new System.Windows.Forms.RadioButton();
            this.grbData.SuspendLayout();
            this.grbResult.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ErpRadius1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ErpRadius2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ErpHeight)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PcbConoid)).BeginInit();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PcbMaterial)).BeginInit();
            this.SuspendLayout();
            // 
            // grbData
            // 
            this.grbData.Controls.Add(this.TbxHeight);
            this.grbData.Controls.Add(this.LblHeight);
            this.grbData.Controls.Add(this.TbxRadius2);
            this.grbData.Controls.Add(this.TbxRadius1);
            this.grbData.Controls.Add(this.LblRadius2);
            this.grbData.Controls.Add(this.LblRadius1);
            this.grbData.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.grbData.Location = new System.Drawing.Point(26, 12);
            this.grbData.Name = "grbData";
            this.grbData.Size = new System.Drawing.Size(346, 139);
            this.grbData.TabIndex = 1;
            this.grbData.TabStop = false;
            this.grbData.Text = " Исходные данные: ";
            // 
            // TbxHeight
            // 
            this.TbxHeight.Location = new System.Drawing.Point(180, 105);
            this.TbxHeight.Name = "TbxHeight";
            this.TbxHeight.Size = new System.Drawing.Size(142, 23);
            this.TbxHeight.TabIndex = 7;
            this.TbxHeight.Text = "2,50";
            this.TbxHeight.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.TbxHeight.TextChanged += new System.EventHandler(this.TbxHeight_TextChanged);
            // 
            // LblHeight
            // 
            this.LblHeight.AutoSize = true;
            this.LblHeight.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblHeight.Location = new System.Drawing.Point(8, 108);
            this.LblHeight.Name = "LblHeight";
            this.LblHeight.Size = new System.Drawing.Size(98, 16);
            this.LblHeight.TabIndex = 6;
            this.LblHeight.Text = "Высота конуса:";
            // 
            // TbxRadius2
            // 
            this.TbxRadius2.Location = new System.Drawing.Point(180, 70);
            this.TbxRadius2.Name = "TbxRadius2";
            this.TbxRadius2.Size = new System.Drawing.Size(142, 23);
            this.TbxRadius2.TabIndex = 4;
            this.TbxRadius2.Text = "1,00";
            this.TbxRadius2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.TbxRadius2.TextChanged += new System.EventHandler(this.TbxRadius2_TextChanged);
            // 
            // TbxRadius1
            // 
            this.TbxRadius1.Location = new System.Drawing.Point(180, 38);
            this.TbxRadius1.Name = "TbxRadius1";
            this.TbxRadius1.Size = new System.Drawing.Size(142, 23);
            this.TbxRadius1.TabIndex = 3;
            this.TbxRadius1.Text = "1,50";
            this.TbxRadius1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.TbxRadius1.TextChanged += new System.EventHandler(this.TbxRadius1_TextChanged);
            // 
            // LblRadius2
            // 
            this.LblRadius2.AutoSize = true;
            this.LblRadius2.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblRadius2.Location = new System.Drawing.Point(8, 73);
            this.LblRadius2.Name = "LblRadius2";
            this.LblRadius2.Size = new System.Drawing.Size(180, 16);
            this.LblRadius2.TabIndex = 1;
            this.LblRadius2.Text = "Радиус верхнего основания: ";
            // 
            // LblRadius1
            // 
            this.LblRadius1.AutoSize = true;
            this.LblRadius1.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblRadius1.Location = new System.Drawing.Point(8, 41);
            this.LblRadius1.Name = "LblRadius1";
            this.LblRadius1.Size = new System.Drawing.Size(177, 16);
            this.LblRadius1.TabIndex = 0;
            this.LblRadius1.Text = "Радиус нижнего основания: ";
            // 
            // chbVolume
            // 
            this.chbVolume.AutoSize = true;
            this.chbVolume.Checked = true;
            this.chbVolume.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chbVolume.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.chbVolume.Location = new System.Drawing.Point(412, 214);
            this.chbVolume.Name = "chbVolume";
            this.chbVolume.Size = new System.Drawing.Size(168, 20);
            this.chbVolume.TabIndex = 2;
            this.chbVolume.Text = "Рассчитывать объем";
            this.chbVolume.UseVisualStyleBackColor = true;
            // 
            // chbArea
            // 
            this.chbArea.AutoSize = true;
            this.chbArea.Checked = true;
            this.chbArea.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chbArea.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.chbArea.Location = new System.Drawing.Point(412, 271);
            this.chbArea.Name = "chbArea";
            this.chbArea.Size = new System.Drawing.Size(189, 20);
            this.chbArea.TabIndex = 3;
            this.chbArea.Text = "Рассчитывать площадь ";
            this.chbArea.UseVisualStyleBackColor = true;
            // 
            // chbMassa
            // 
            this.chbMassa.AutoSize = true;
            this.chbMassa.Checked = true;
            this.chbMassa.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chbMassa.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.chbMassa.Location = new System.Drawing.Point(412, 328);
            this.chbMassa.Name = "chbMassa";
            this.chbMassa.Size = new System.Drawing.Size(164, 20);
            this.chbMassa.TabIndex = 4;
            this.chbMassa.Text = "Рассчитывать массу";
            this.chbMassa.UseVisualStyleBackColor = true;
            // 
            // grbResult
            // 
            this.grbResult.Controls.Add(this.LblMassa);
            this.grbResult.Controls.Add(this.LblArea);
            this.grbResult.Controls.Add(this.lblVolume);
            this.grbResult.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.grbResult.Location = new System.Drawing.Point(26, 390);
            this.grbResult.Name = "grbResult";
            this.grbResult.Size = new System.Drawing.Size(346, 139);
            this.grbResult.TabIndex = 5;
            this.grbResult.TabStop = false;
            this.grbResult.Text = " Результаты расчета: ";
            // 
            // LblMassa
            // 
            this.LblMassa.AutoSize = true;
            this.LblMassa.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblMassa.Location = new System.Drawing.Point(9, 99);
            this.LblMassa.Name = "LblMassa";
            this.LblMassa.Size = new System.Drawing.Size(166, 16);
            this.LblMassa.TabIndex = 8;
            this.LblMassa.Text = "Масса усеченного конуса: ";
            // 
            // LblArea
            // 
            this.LblArea.AutoSize = true;
            this.LblArea.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblArea.Location = new System.Drawing.Point(9, 69);
            this.LblArea.Name = "LblArea";
            this.LblArea.Size = new System.Drawing.Size(184, 16);
            this.LblArea.TabIndex = 7;
            this.LblArea.Text = "Площадь усеченного конуса: ";
            // 
            // lblVolume
            // 
            this.lblVolume.AutoSize = true;
            this.lblVolume.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblVolume.Location = new System.Drawing.Point(9, 39);
            this.lblVolume.Name = "lblVolume";
            this.lblVolume.Size = new System.Drawing.Size(168, 16);
            this.lblVolume.TabIndex = 6;
            this.lblVolume.Text = "Объем усеченного конуса: ";
            // 
            // btnCalculate
            // 
            this.btnCalculate.Location = new System.Drawing.Point(412, 414);
            this.btnCalculate.Name = "btnCalculate";
            this.btnCalculate.Size = new System.Drawing.Size(189, 31);
            this.btnCalculate.TabIndex = 6;
            this.btnCalculate.Text = "Рассчитать";
            this.btnCalculate.UseVisualStyleBackColor = true;
            this.btnCalculate.Click += new System.EventHandler(this.btnCalculate_Click);
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btnExit.Location = new System.Drawing.Point(412, 479);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(189, 31);
            this.btnExit.TabIndex = 7;
            this.btnExit.Text = "Выход";
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // ErpRadius1
            // 
            this.ErpRadius1.ContainerControl = this;
            // 
            // ErpRadius2
            // 
            this.ErpRadius2.ContainerControl = this;
            // 
            // ErpHeight
            // 
            this.ErpHeight.ContainerControl = this;
            // 
            // PcbConoid
            // 
            this.PcbConoid.Image = global::_001_Figures.Properties.Resources.Picture_Conoid;
            this.PcbConoid.Location = new System.Drawing.Point(385, 7);
            this.PcbConoid.Name = "PcbConoid";
            this.PcbConoid.Size = new System.Drawing.Size(235, 174);
            this.PcbConoid.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.PcbConoid.TabIndex = 0;
            this.PcbConoid.TabStop = false;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.PcbMaterial);
            this.groupBox1.Controls.Add(this.RbtGranite);
            this.groupBox1.Controls.Add(this.RbtIce);
            this.groupBox1.Controls.Add(this.RbtCopper);
            this.groupBox1.Controls.Add(this.RbtSteel);
            this.groupBox1.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.groupBox1.Location = new System.Drawing.Point(26, 163);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(346, 215);
            this.groupBox1.TabIndex = 8;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = " Выбор материала: ";
            // 
            // PcbMaterial
            // 
            this.PcbMaterial.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.PcbMaterial.Image = global::_001_Figures.Properties.Resources.steel;
            this.PcbMaterial.Location = new System.Drawing.Point(180, 51);
            this.PcbMaterial.Name = "PcbMaterial";
            this.PcbMaterial.Size = new System.Drawing.Size(142, 121);
            this.PcbMaterial.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PcbMaterial.TabIndex = 9;
            this.PcbMaterial.TabStop = false;
            // 
            // RbtGranite
            // 
            this.RbtGranite.AutoSize = true;
            this.RbtGranite.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.RbtGranite.Location = new System.Drawing.Point(26, 170);
            this.RbtGranite.Name = "RbtGranite";
            this.RbtGranite.Size = new System.Drawing.Size(67, 20);
            this.RbtGranite.TabIndex = 3;
            this.RbtGranite.Text = "Гранит";
            this.RbtGranite.UseVisualStyleBackColor = true;
            this.RbtGranite.CheckedChanged += new System.EventHandler(this.RbtGranite_CheckedChanged);
            // 
            // RbtIce
            // 
            this.RbtIce.AutoSize = true;
            this.RbtIce.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.RbtIce.Location = new System.Drawing.Point(26, 129);
            this.RbtIce.Name = "RbtIce";
            this.RbtIce.Size = new System.Drawing.Size(49, 20);
            this.RbtIce.TabIndex = 2;
            this.RbtIce.Text = "Лёд";
            this.RbtIce.UseVisualStyleBackColor = true;
            this.RbtIce.CheckedChanged += new System.EventHandler(this.RbtIce_CheckedChanged);
            // 
            // RbtCopper
            // 
            this.RbtCopper.AutoSize = true;
            this.RbtCopper.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.RbtCopper.Location = new System.Drawing.Point(26, 88);
            this.RbtCopper.Name = "RbtCopper";
            this.RbtCopper.Size = new System.Drawing.Size(57, 20);
            this.RbtCopper.TabIndex = 1;
            this.RbtCopper.Text = "Медь";
            this.RbtCopper.UseVisualStyleBackColor = true;
            this.RbtCopper.CheckedChanged += new System.EventHandler(this.RbtCopper_CheckedChanged);
            // 
            // RbtSteel
            // 
            this.RbtSteel.AutoSize = true;
            this.RbtSteel.Checked = true;
            this.RbtSteel.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.RbtSteel.Location = new System.Drawing.Point(26, 47);
            this.RbtSteel.Name = "RbtSteel";
            this.RbtSteel.Size = new System.Drawing.Size(61, 20);
            this.RbtSteel.TabIndex = 0;
            this.RbtSteel.TabStop = true;
            this.RbtSteel.Text = "Сталь";
            this.RbtSteel.UseVisualStyleBackColor = true;
            this.RbtSteel.CheckedChanged += new System.EventHandler(this.RbtSteel_CheckedChanged);
            // 
            // ConoidForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(632, 552);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnCalculate);
            this.Controls.Add(this.grbResult);
            this.Controls.Add(this.chbMassa);
            this.Controls.Add(this.chbArea);
            this.Controls.Add(this.chbVolume);
            this.Controls.Add(this.grbData);
            this.Controls.Add(this.PcbConoid);
            this.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.MaximizeBox = false;
            this.Name = "ConoidForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Conoid";
            this.grbData.ResumeLayout(false);
            this.grbData.PerformLayout();
            this.grbResult.ResumeLayout(false);
            this.grbResult.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ErpRadius1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ErpRadius2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ErpHeight)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PcbConoid)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PcbMaterial)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox PcbConoid;
        private System.Windows.Forms.GroupBox grbData;
        private System.Windows.Forms.CheckBox chbVolume;
        private System.Windows.Forms.CheckBox chbArea;
        private System.Windows.Forms.CheckBox chbMassa;
        private System.Windows.Forms.GroupBox grbResult;
        private System.Windows.Forms.Button btnCalculate;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Label LblRadius2;
        private System.Windows.Forms.Label LblRadius1;
        private System.Windows.Forms.TextBox TbxRadius2;
        private System.Windows.Forms.TextBox TbxRadius1;
        private System.Windows.Forms.Label lblVolume;
        private System.Windows.Forms.Label LblMassa;
        private System.Windows.Forms.Label LblArea;
        private System.Windows.Forms.TextBox TbxHeight;
        private System.Windows.Forms.Label LblHeight;
        private System.Windows.Forms.ErrorProvider ErpRadius1;
        private System.Windows.Forms.ErrorProvider ErpRadius2;
        private System.Windows.Forms.ErrorProvider ErpHeight;
        private System.Windows.Forms.PictureBox PcbMaterial;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton RbtGranite;
        private System.Windows.Forms.RadioButton RbtIce;
        private System.Windows.Forms.RadioButton RbtCopper;
        private System.Windows.Forms.RadioButton RbtSteel;
    }
}