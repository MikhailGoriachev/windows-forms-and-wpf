﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _001_Figures.Models {
    // Сфера
    class Sphere {
         // радиус 
        private double _radius;
        public double Radius {
            get => _radius;
            set {
                if (value <= 0)
                    throw new ArgumentException("Sphere. Отрицательный или нулевой радиус");
                _radius = value;
            } // set
        }
        
        // плотность материала
        private double _density;
        public double Density {
            get => _density;
            set {
                if (value <= 0)
                    throw new ArgumentException("Sphere. Отрицательная или нулевая плотность материала");
                _density = value;
            } // set
        }

        // Вычисление площади сферы
        public double CalcArea() => 4d * Math.PI * _radius * _radius;

        // Вычисление объема сферы
        public double CalcVolume() => 4d * Math.PI * _radius * _radius * _radius / 3d;

        // Вычисление массы сферы
        public double CalcMassa() =>
            CalcVolume() * Density;
    }
}
