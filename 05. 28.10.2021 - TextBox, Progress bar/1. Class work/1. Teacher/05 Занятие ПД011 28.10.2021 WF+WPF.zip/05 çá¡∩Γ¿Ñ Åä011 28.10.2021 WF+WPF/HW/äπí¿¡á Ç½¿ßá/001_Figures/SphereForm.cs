﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using _001_Figures.Models;

namespace _001_Figures
{
    public partial class SphereForm : Form
    {
        // Данные для обработки
        private Sphere _sphere;
        public SphereForm() {
            InitializeComponent();
            _sphere = new Sphere { Density = Program.steelDensity};
        } // SphereForm

        private void btnExit_Click(object sender, EventArgs e) => Close();

        private void btnCalculate_Click(object sender, EventArgs e) {
            double area;   // площадь 
            double massa;   // масса 
            double volume;  // объем 

            // Получить исходные данные для расчета
            _sphere.Radius = MainForm.ParseValue(TbxRadius, ErpRadius, out bool res);

            // расчет объема
            if (chbVolume.Checked) {
                volume = _sphere.CalcVolume();
                lblVolume.Text = $"Объем сферы: {volume:n3}";
            }
            else
                lblVolume.Text = "Объем сферы: расчет не требуется";

            // расчет площади
            if (chbArea.Checked) {
                area = _sphere.CalcArea();
                LblArea.Text = $"Площадь сферы: {area:n3}";
            }
            else
                LblArea.Text = "Площадь сферы: расчет не требуется";

            // расчет массы
            if (chbMassa.Checked) {
                massa = _sphere.CalcMassa();
                LblMassa.Text = $"Масса сферы: {massa:n3}";
            }
            else
                LblMassa.Text = "Масса сферы: расчет не требуется";

            if (!res) ClearResult();
        } // btnCalculate_Click

        private void ClearResult() {
            lblVolume.Text = "Объем сферы: ";
            LblArea.Text = "Площадь сферы: ";
            LblMassa.Text = "Масса сферы: ";
        } // ClearResult

        private void TbxRadius_TextChanged(object sender, EventArgs e) {
            ErpRadius.SetError(TbxRadius, "");
            ClearResult();
        } // TbxRadius_TextChanged

        private void RbtSteel_CheckedChanged(object sender, EventArgs e) {
            _sphere.Density = Program.steelDensity;
            // смена картинки 
            PcbMaterial.Image = Properties.Resources.steel;
        } // RbtSteel_CheckedChanged

        private void RbtCopper_CheckedChanged(object sender, EventArgs e) {
            _sphere.Density = Program.copperDensity;
            // смена картинки 
            PcbMaterial.Image = Properties.Resources.copper;
        } // RbtCopper_CheckedChanged

        private void RbtIce_CheckedChanged(object sender, EventArgs e) {
            _sphere.Density = Program.iceDensity;
            // смена картинки 
            PcbMaterial.Image = Properties.Resources.ice;
        } // RbtIce_CheckedChanged

        private void RbtGranite_CheckedChanged(object sender, EventArgs e) {
            _sphere.Density = Program.graniteDensity;
            // смена картинки 
            PcbMaterial.Image = Properties.Resources.granite;
        } // RbtGranite_CheckedChanged
        
    }
}
