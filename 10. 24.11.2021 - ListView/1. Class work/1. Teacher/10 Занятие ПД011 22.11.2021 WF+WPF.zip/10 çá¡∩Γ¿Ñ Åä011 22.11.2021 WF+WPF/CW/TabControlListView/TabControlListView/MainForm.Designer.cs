﻿
namespace TabControlListView
{
    partial class MainForm
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            System.Windows.Forms.ListViewItem listViewItem1 = new System.Windows.Forms.ListViewItem("Первый", "book.ico");
            System.Windows.Forms.ListViewItem listViewItem2 = new System.Windows.Forms.ListViewItem("Второй", 1);
            System.Windows.Forms.ListViewItem listViewItem3 = new System.Windows.Forms.ListViewItem("Третий", 2);
            System.Windows.Forms.ListViewItem listViewItem4 = new System.Windows.Forms.ListViewItem("Четвертый", 3);
            System.Windows.Forms.ListViewItem listViewItem5 = new System.Windows.Forms.ListViewItem("Пятый", 4);
            System.Windows.Forms.ListViewItem listViewItem6 = new System.Windows.Forms.ListViewItem("Шестой", 5);
            System.Windows.Forms.ListViewItem listViewItem7 = new System.Windows.Forms.ListViewItem("Первый", "book.ico");
            System.Windows.Forms.ListViewItem listViewItem8 = new System.Windows.Forms.ListViewItem("Второй", 1);
            System.Windows.Forms.ListViewItem listViewItem9 = new System.Windows.Forms.ListViewItem("Третий", 2);
            System.Windows.Forms.ListViewItem listViewItem10 = new System.Windows.Forms.ListViewItem("Четвертый", 3);
            System.Windows.Forms.ListViewItem listViewItem11 = new System.Windows.Forms.ListViewItem("Пятый", 4);
            System.Windows.Forms.ListViewItem listViewItem12 = new System.Windows.Forms.ListViewItem("Шестой", 5);
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.afqkToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.выходToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.вкладкиToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.добавитьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripSeparator();
            this.наПервуюToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.наПоследнююToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripSeparator();
            this.удалитьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.окноToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.свернутьВТрейToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripButton2 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton3 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton5 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton6 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton7 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton8 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton4 = new System.Windows.Forms.ToolStripButton();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.StlMain = new System.Windows.Forms.ToolStripStatusLabel();
            this.TbcMain = new System.Windows.Forms.TabControl();
            this.TbpListView = new System.Windows.Forms.TabPage();
            this.LblSelected2 = new System.Windows.Forms.Label();
            this.LblSelected1 = new System.Windows.Forms.Label();
            this.LsvDemo2 = new System.Windows.Forms.ListView();
            this.ImlLarge = new System.Windows.Forms.ImageList(this.components);
            this.ImlSmall = new System.Windows.Forms.ImageList(this.components);
            this.LsvDemo1 = new System.Windows.Forms.ListView();
            this.TbpListViewTable = new System.Windows.Forms.TabPage();
            this.label1 = new System.Windows.Forms.Label();
            this.NtiMain = new System.Windows.Forms.NotifyIcon(this.components);
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem4 = new System.Windows.Forms.ToolStripSeparator();
            this.вToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripButton9 = new System.Windows.Forms.ToolStripButton();
            this.menuStrip1.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.TbcMain.SuspendLayout();
            this.TbpListView.SuspendLayout();
            this.TbpListViewTable.SuspendLayout();
            this.contextMenuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.afqkToolStripMenuItem,
            this.вкладкиToolStripMenuItem,
            this.окноToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 29);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // afqkToolStripMenuItem
            // 
            this.afqkToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.выходToolStripMenuItem});
            this.afqkToolStripMenuItem.Name = "afqkToolStripMenuItem";
            this.afqkToolStripMenuItem.Size = new System.Drawing.Size(59, 25);
            this.afqkToolStripMenuItem.Text = "Файл";
            // 
            // выходToolStripMenuItem
            // 
            this.выходToolStripMenuItem.Name = "выходToolStripMenuItem";
            this.выходToolStripMenuItem.Size = new System.Drawing.Size(125, 26);
            this.выходToolStripMenuItem.Text = "Выход";
            this.выходToolStripMenuItem.Click += new System.EventHandler(this.Exit_Command);
            // 
            // вкладкиToolStripMenuItem
            // 
            this.вкладкиToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.добавитьToolStripMenuItem,
            this.toolStripMenuItem1,
            this.наПервуюToolStripMenuItem,
            this.наПоследнююToolStripMenuItem,
            this.toolStripMenuItem2,
            this.удалитьToolStripMenuItem});
            this.вкладкиToolStripMenuItem.Name = "вкладкиToolStripMenuItem";
            this.вкладкиToolStripMenuItem.Size = new System.Drawing.Size(81, 25);
            this.вкладкиToolStripMenuItem.Text = "Вкладки";
            // 
            // добавитьToolStripMenuItem
            // 
            this.добавитьToolStripMenuItem.Name = "добавитьToolStripMenuItem";
            this.добавитьToolStripMenuItem.Size = new System.Drawing.Size(188, 26);
            this.добавитьToolStripMenuItem.Text = "Добавить";
            this.добавитьToolStripMenuItem.Click += new System.EventHandler(this.TabPageAdd_Command);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(185, 6);
            // 
            // наПервуюToolStripMenuItem
            // 
            this.наПервуюToolStripMenuItem.Name = "наПервуюToolStripMenuItem";
            this.наПервуюToolStripMenuItem.Size = new System.Drawing.Size(188, 26);
            this.наПервуюToolStripMenuItem.Text = "На первую";
            this.наПервуюToolStripMenuItem.Click += new System.EventHandler(this.FirstTab_Command);
            // 
            // наПоследнююToolStripMenuItem
            // 
            this.наПоследнююToolStripMenuItem.Name = "наПоследнююToolStripMenuItem";
            this.наПоследнююToolStripMenuItem.Size = new System.Drawing.Size(188, 26);
            this.наПоследнююToolStripMenuItem.Text = "На последнюю";
            this.наПоследнююToolStripMenuItem.Click += new System.EventHandler(this.LastTab_Comamnd);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(185, 6);
            // 
            // удалитьToolStripMenuItem
            // 
            this.удалитьToolStripMenuItem.Name = "удалитьToolStripMenuItem";
            this.удалитьToolStripMenuItem.Size = new System.Drawing.Size(188, 26);
            this.удалитьToolStripMenuItem.Text = "Удалить";
            this.удалитьToolStripMenuItem.Click += new System.EventHandler(this.RemoveTab_Command);
            // 
            // окноToolStripMenuItem
            // 
            this.окноToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.свернутьВТрейToolStripMenuItem});
            this.окноToolStripMenuItem.Name = "окноToolStripMenuItem";
            this.окноToolStripMenuItem.Size = new System.Drawing.Size(60, 25);
            this.окноToolStripMenuItem.Text = "Окно";
            // 
            // свернутьВТрейToolStripMenuItem
            // 
            this.свернутьВТрейToolStripMenuItem.Name = "свернутьВТрейToolStripMenuItem";
            this.свернутьВТрейToolStripMenuItem.Size = new System.Drawing.Size(196, 26);
            this.свернутьВТрейToolStripMenuItem.Text = "Свернуть в трей";
            this.свернутьВТрейToolStripMenuItem.Click += new System.EventHandler(this.ToTray_Command);
            // 
            // toolStrip1
            // 
            this.toolStrip1.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButton2,
            this.toolStripButton1,
            this.toolStripButton3,
            this.toolStripSeparator1,
            this.toolStripButton5,
            this.toolStripButton6,
            this.toolStripButton7,
            this.toolStripButton8,
            this.toolStripButton9,
            this.toolStripButton4});
            this.toolStrip1.Location = new System.Drawing.Point(0, 29);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(800, 28);
            this.toolStrip1.TabIndex = 1;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // toolStripButton2
            // 
            this.toolStripButton2.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton2.Image")));
            this.toolStripButton2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton2.Name = "toolStripButton2";
            this.toolStripButton2.Size = new System.Drawing.Size(82, 25);
            this.toolStripButton2.Text = "Первая";
            this.toolStripButton2.Click += new System.EventHandler(this.FirstTab_Command);
            // 
            // toolStripButton1
            // 
            this.toolStripButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton1.Image")));
            this.toolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.Size = new System.Drawing.Size(107, 25);
            this.toolStripButton1.Text = "Последняя";
            this.toolStripButton1.Click += new System.EventHandler(this.LastTab_Comamnd);
            // 
            // toolStripButton3
            // 
            this.toolStripButton3.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton3.Image")));
            this.toolStripButton3.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton3.Name = "toolStripButton3";
            this.toolStripButton3.Size = new System.Drawing.Size(76, 25);
            this.toolStripButton3.Text = "В трей";
            this.toolStripButton3.Click += new System.EventHandler(this.ToTray_Command);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 28);
            // 
            // toolStripButton5
            // 
            this.toolStripButton5.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButton5.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton5.Image")));
            this.toolStripButton5.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton5.Name = "toolStripButton5";
            this.toolStripButton5.Size = new System.Drawing.Size(82, 25);
            this.toolStripButton5.Text = "LargeIcon";
            this.toolStripButton5.Click += new System.EventHandler(this.LargeIcon_Command);
            // 
            // toolStripButton6
            // 
            this.toolStripButton6.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButton6.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton6.Image")));
            this.toolStripButton6.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton6.Name = "toolStripButton6";
            this.toolStripButton6.Size = new System.Drawing.Size(82, 25);
            this.toolStripButton6.Text = "SmallIcon";
            this.toolStripButton6.Click += new System.EventHandler(this.SmaillIcon_Command);
            // 
            // toolStripButton7
            // 
            this.toolStripButton7.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButton7.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton7.Image")));
            this.toolStripButton7.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton7.Name = "toolStripButton7";
            this.toolStripButton7.Size = new System.Drawing.Size(38, 25);
            this.toolStripButton7.Text = "List";
            this.toolStripButton7.Click += new System.EventHandler(this.List_Command);
            // 
            // toolStripButton8
            // 
            this.toolStripButton8.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButton8.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton8.Image")));
            this.toolStripButton8.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton8.Name = "toolStripButton8";
            this.toolStripButton8.Size = new System.Drawing.Size(38, 25);
            this.toolStripButton8.Text = "Tile";
            this.toolStripButton8.ToolTipText = "Tile";
            this.toolStripButton8.Click += new System.EventHandler(this.Tile_Command);
            // 
            // toolStripButton4
            // 
            this.toolStripButton4.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButton4.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton4.Image")));
            this.toolStripButton4.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton4.Name = "toolStripButton4";
            this.toolStripButton4.Size = new System.Drawing.Size(61, 25);
            this.toolStripButton4.Text = "Details";
            this.toolStripButton4.ToolTipText = "Tile";
            this.toolStripButton4.Click += new System.EventHandler(this.Detail_Command);
            // 
            // statusStrip1
            // 
            this.statusStrip1.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.StlMain});
            this.statusStrip1.Location = new System.Drawing.Point(0, 424);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(800, 26);
            this.statusStrip1.TabIndex = 2;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // StlMain
            // 
            this.StlMain.Name = "StlMain";
            this.StlMain.Size = new System.Drawing.Size(785, 21);
            this.StlMain.Spring = true;
            this.StlMain.Text = "Готово";
            this.StlMain.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // TbcMain
            // 
            this.TbcMain.Controls.Add(this.TbpListView);
            this.TbcMain.Controls.Add(this.TbpListViewTable);
            this.TbcMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TbcMain.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TbcMain.Location = new System.Drawing.Point(0, 57);
            this.TbcMain.Name = "TbcMain";
            this.TbcMain.SelectedIndex = 0;
            this.TbcMain.Size = new System.Drawing.Size(800, 367);
            this.TbcMain.TabIndex = 3;
            // 
            // TbpListView
            // 
            this.TbpListView.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TbpListView.Controls.Add(this.LblSelected2);
            this.TbpListView.Controls.Add(this.LblSelected1);
            this.TbpListView.Controls.Add(this.LsvDemo2);
            this.TbpListView.Controls.Add(this.LsvDemo1);
            this.TbpListView.Location = new System.Drawing.Point(4, 27);
            this.TbpListView.Name = "TbpListView";
            this.TbpListView.Padding = new System.Windows.Forms.Padding(3);
            this.TbpListView.Size = new System.Drawing.Size(792, 336);
            this.TbpListView.TabIndex = 0;
            this.TbpListView.Text = "ListView";
            this.TbpListView.UseVisualStyleBackColor = true;
            // 
            // LblSelected2
            // 
            this.LblSelected2.Location = new System.Drawing.Point(592, 72);
            this.LblSelected2.Name = "LblSelected2";
            this.LblSelected2.Size = new System.Drawing.Size(168, 40);
            this.LblSelected2.TabIndex = 4;
            this.LblSelected2.Text = "Вывод выбранного элемента";
            // 
            // LblSelected1
            // 
            this.LblSelected1.Location = new System.Drawing.Point(592, 16);
            this.LblSelected1.Name = "LblSelected1";
            this.LblSelected1.Size = new System.Drawing.Size(168, 40);
            this.LblSelected1.TabIndex = 3;
            this.LblSelected1.Text = "Вывод выбранного элемента";
            // 
            // LsvDemo2
            // 
            this.LsvDemo2.HideSelection = false;
            this.LsvDemo2.Items.AddRange(new System.Windows.Forms.ListViewItem[] {
            listViewItem1,
            listViewItem2,
            listViewItem3,
            listViewItem4,
            listViewItem5,
            listViewItem6});
            this.LsvDemo2.LargeImageList = this.ImlLarge;
            this.LsvDemo2.Location = new System.Drawing.Point(328, 16);
            this.LsvDemo2.MultiSelect = false;
            this.LsvDemo2.Name = "LsvDemo2";
            this.LsvDemo2.Size = new System.Drawing.Size(248, 296);
            this.LsvDemo2.SmallImageList = this.ImlSmall;
            this.LsvDemo2.TabIndex = 2;
            this.LsvDemo2.UseCompatibleStateImageBehavior = false;
            this.LsvDemo2.SelectedIndexChanged += new System.EventHandler(this.LsvDemo2_SelectedIndexChanged);
            // 
            // ImlLarge
            // 
            this.ImlLarge.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("ImlLarge.ImageStream")));
            this.ImlLarge.TransparentColor = System.Drawing.Color.Transparent;
            this.ImlLarge.Images.SetKeyName(0, "book.ico");
            this.ImlLarge.Images.SetKeyName(1, "book_add.ico");
            this.ImlLarge.Images.SetKeyName(2, "book_addresses.ico");
            this.ImlLarge.Images.SetKeyName(3, "book_delete.ico");
            this.ImlLarge.Images.SetKeyName(4, "book_edit.ico");
            this.ImlLarge.Images.SetKeyName(5, "book_error.ico");
            this.ImlLarge.Images.SetKeyName(6, "book_go.ico");
            this.ImlLarge.Images.SetKeyName(7, "book_keeping.ico");
            this.ImlLarge.Images.SetKeyName(8, "book_key.ico");
            this.ImlLarge.Images.SetKeyName(9, "book_link.ico");
            this.ImlLarge.Images.SetKeyName(10, "book_next.ico");
            this.ImlLarge.Images.SetKeyName(11, "book_open.ico");
            this.ImlLarge.Images.SetKeyName(12, "book_picture.ico");
            this.ImlLarge.Images.SetKeyName(13, "book_previous.ico");
            this.ImlLarge.Images.SetKeyName(14, "books_stack.ico");
            this.ImlLarge.Images.SetKeyName(15, "bookshelf.ico");
            // 
            // ImlSmall
            // 
            this.ImlSmall.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("ImlSmall.ImageStream")));
            this.ImlSmall.TransparentColor = System.Drawing.Color.Transparent;
            this.ImlSmall.Images.SetKeyName(0, "book_next.ico");
            this.ImlSmall.Images.SetKeyName(1, "book_open.ico");
            this.ImlSmall.Images.SetKeyName(2, "book_picture.ico");
            this.ImlSmall.Images.SetKeyName(3, "book_previous.ico");
            this.ImlSmall.Images.SetKeyName(4, "book_spelling.ico");
            this.ImlSmall.Images.SetKeyName(5, "bookmark.ico");
            this.ImlSmall.Images.SetKeyName(6, "bookmark_red.ico");
            this.ImlSmall.Images.SetKeyName(7, "books.ico");
            this.ImlSmall.Images.SetKeyName(8, "books_infront.ico");
            // 
            // LsvDemo1
            // 
            this.LsvDemo1.HideSelection = false;
            this.LsvDemo1.Items.AddRange(new System.Windows.Forms.ListViewItem[] {
            listViewItem7,
            listViewItem8,
            listViewItem9,
            listViewItem10,
            listViewItem11,
            listViewItem12});
            this.LsvDemo1.LargeImageList = this.ImlLarge;
            this.LsvDemo1.Location = new System.Drawing.Point(40, 16);
            this.LsvDemo1.MultiSelect = false;
            this.LsvDemo1.Name = "LsvDemo1";
            this.LsvDemo1.Size = new System.Drawing.Size(248, 296);
            this.LsvDemo1.SmallImageList = this.ImlSmall;
            this.LsvDemo1.TabIndex = 1;
            this.LsvDemo1.UseCompatibleStateImageBehavior = false;
            this.LsvDemo1.SelectedIndexChanged += new System.EventHandler(this.LsvDemo1_SelectedIndexChanged);
            // 
            // TbpListViewTable
            // 
            this.TbpListViewTable.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.TbpListViewTable.Controls.Add(this.label1);
            this.TbpListViewTable.Location = new System.Drawing.Point(4, 27);
            this.TbpListViewTable.Name = "TbpListViewTable";
            this.TbpListViewTable.Padding = new System.Windows.Forms.Padding(3);
            this.TbpListViewTable.Size = new System.Drawing.Size(792, 336);
            this.TbpListViewTable.TabIndex = 1;
            this.TbpListViewTable.Text = "ListView Table";
            this.TbpListViewTable.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(16, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(659, 18);
            this.label1.TabIndex = 1;
            this.label1.Text = "На занятии 24.11.2021 разместим в этой вкладке ListView в табличном режиме отобра" +
    "жения";
            // 
            // NtiMain
            // 
            this.NtiMain.ContextMenuStrip = this.contextMenuStrip1;
            this.NtiMain.Icon = ((System.Drawing.Icon)(resources.GetObject("NtiMain.Icon")));
            this.NtiMain.Text = "Приложение свернуто в трей";
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem3,
            this.toolStripMenuItem4,
            this.вToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(192, 54);
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(191, 22);
            this.toolStripMenuItem3.Text = "Восстановить из трея";
            this.toolStripMenuItem3.Click += new System.EventHandler(this.FromTray_Command);
            // 
            // toolStripMenuItem4
            // 
            this.toolStripMenuItem4.Name = "toolStripMenuItem4";
            this.toolStripMenuItem4.Size = new System.Drawing.Size(188, 6);
            // 
            // вToolStripMenuItem
            // 
            this.вToolStripMenuItem.Name = "вToolStripMenuItem";
            this.вToolStripMenuItem.Size = new System.Drawing.Size(191, 22);
            this.вToolStripMenuItem.Text = "Выход";
            this.вToolStripMenuItem.Click += new System.EventHandler(this.Exit_Command);
            // 
            // toolStripButton9
            // 
            this.toolStripButton9.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.toolStripButton9.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton9.Image")));
            this.toolStripButton9.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton9.Name = "toolStripButton9";
            this.toolStripButton9.Size = new System.Drawing.Size(75, 25);
            this.toolStripButton9.Text = "Выход";
            this.toolStripButton9.ToolTipText = "Tile";
            this.toolStripButton9.Click += new System.EventHandler(this.Exit_Command);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.TbcMain);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.menuStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Занятие 22.11.2021 - вкладки, NotifyIcon, ListView ";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.TbcMain.ResumeLayout(false);
            this.TbpListView.ResumeLayout(false);
            this.TbpListViewTable.ResumeLayout(false);
            this.TbpListViewTable.PerformLayout();
            this.contextMenuStrip1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripMenuItem afqkToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem выходToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem вкладкиToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem добавитьToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem наПервуюToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem наПоследнююToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem удалитьToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem окноToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem свернутьВТрейToolStripMenuItem;
        private System.Windows.Forms.ToolStripButton toolStripButton2;
        private System.Windows.Forms.ToolStripButton toolStripButton1;
        private System.Windows.Forms.ToolStripButton toolStripButton3;
        private System.Windows.Forms.ToolStripStatusLabel StlMain;
        private System.Windows.Forms.TabControl TbcMain;
        private System.Windows.Forms.TabPage TbpListView;
        private System.Windows.Forms.TabPage TbpListViewTable;
        private System.Windows.Forms.NotifyIcon NtiMain;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem3;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem4;
        private System.Windows.Forms.ToolStripMenuItem вToolStripMenuItem;
        private System.Windows.Forms.ImageList ImlLarge;
        private System.Windows.Forms.ImageList ImlSmall;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripButton toolStripButton5;
        private System.Windows.Forms.ToolStripButton toolStripButton6;
        private System.Windows.Forms.ToolStripButton toolStripButton7;
        private System.Windows.Forms.ToolStripButton toolStripButton4;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ListView LsvDemo2;
        private System.Windows.Forms.ListView LsvDemo1;
        private System.Windows.Forms.ToolStripButton toolStripButton8;
        private System.Windows.Forms.Label LblSelected1;
        private System.Windows.Forms.Label LblSelected2;
        private System.Windows.Forms.ToolStripButton toolStripButton9;
    }
}

