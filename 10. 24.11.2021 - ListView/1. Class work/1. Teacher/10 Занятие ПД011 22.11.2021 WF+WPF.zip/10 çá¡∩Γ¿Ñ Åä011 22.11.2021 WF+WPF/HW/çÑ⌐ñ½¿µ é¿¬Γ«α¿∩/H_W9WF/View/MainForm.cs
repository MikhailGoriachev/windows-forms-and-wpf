﻿using H_W9WF.Models;
using H_W9WF.View;
using H_W9WF.Views;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace H_W9WF
{
    public partial class MainForm : Form
    {
        // контроллер для работы с коллекцией телевизоров
        private RepairShop _televisionsController;
        // название файла для хранения данных в JSON формате
        private string _filenameRepairShop;

        /// <summary>
        /// Конструкторы формы, с возможностью внедрения зависимостей
        /// </summary>
        public MainForm() : this("../../repairShop.json", new RepairShop()) { } // MainForm

        public MainForm(string filenameRep, RepairShop televisionsController)
        {
            InitializeComponent();

            _televisionsController = televisionsController;
            _filenameRepairShop = filenameRep;

            // привязка ListBox к коллекции
            BindCollection();
        } // MainForm

        // выполнение привязки коллекции
        private void BindCollection()
        {
            // остановить привязку
            LbxTelevisions.DataSource = null;

            // задать привязку
            LbxTelevisions.DataSource = _televisionsController.Televisions;

            LbxTelevisions.DisplayMember = "TableRow";
        } // BindCollection

        // команда заверешния работы приложения
        private void Exit_Command(object sender, EventArgs e) => Application.Exit();

        private void MainForm_Load(object sender, EventArgs e)
        {
            Text = _televisionsController.Name + ". Адрес: " + _televisionsController.Address;

            // вывод в строку состояния
            StlMain.Text = $"Сформировано телевизоров: {_televisionsController.Count}";
        }// MainForm_Load

        // команда отображения окна сведений о программе
        private void About_Command(object sender, EventArgs e)
        {
            AboutForm aboutForm = new AboutForm();
            aboutForm.ShowDialog();
        }// About_Command

        private void NewCollection_Command(object sender, EventArgs e)
        {
            _televisionsController.Inizialize();

            BindCollection();

            // обновить строку состояния
            StlMain.Text = $"Коллекция данных сформирована. Текущее количество телевизоров: {_televisionsController.Count}";
        }// NewCollection_Command

        // добавление телевизора в коллекцию
        private void AddTelevision_Command(object sender, EventArgs e)
        {
            TelevisionForm televisionForm = new TelevisionForm();

            DialogResult dialogResult = televisionForm.ShowDialog();

            // если окно закрыто не по кнопке "Добавить" - молча уходим
            if (dialogResult != DialogResult.OK) return;

            // получить данные из свойства формы
            Television television = televisionForm.Tv;
            _televisionsController.AddTelevizion(television);

            // сериализация данных
            _televisionsController.SerializationJson(_filenameRepairShop);

            BindCollection();
            // обновить строку состояния
            StlMain.Text = $"Данные добавлены. Текущее количество телевизоров: {_televisionsController.Count}";
          
        }// AddTelevision_Command

        // yдаление телевизора из коллекции – выдача телевизора владельцу после ремонта, сериализация данных
        private void RemoveTelevision_Command(object sender, EventArgs e)
        {
            if (LbxTelevisions.SelectedIndex < 0)
                return;

            // удаление записи данных 
            _televisionsController.RemoveAt(LbxTelevisions.SelectedIndex);

            // сериализация данных
            _televisionsController.SerializationJson(_filenameRepairShop);

            BindCollection();
            // обновить строку состояния
            StlMain.Text = $"Данные удалены. Текущее количество телевизоров: {_televisionsController.Count}";
        }// RemoveTelevision_Command


        private void OrderbyTvBrand_Command(object sender, EventArgs e)
        {
            _televisionsController.OrderbyTvBrand();

            BindCollection();

            // обновить строку состояния
            StlMain.Text = $"Коллекция телевизоров упорядочена по бренду. Текущее количество телевизоров: {_televisionsController.Count}";
        }// OrderbyTvBrand_Command

        private void OrderbyDiagonal_Command(object sender, EventArgs e)
        {
            _televisionsController.OrderbyDiagonal();

            BindCollection();

            // обновить строку состояния
            StlMain.Text = $"Коллекция телевизоров упорядочена по убыванию диагонали. Текущее количество телевизоров: {_televisionsController.Count}";
        }// OrderbyDiagonal_Command

        private void OrderbyFullnameMaster_Command(object sender, EventArgs e)
        {
            _televisionsController.OrderbyFullnameMaster();

            BindCollection();

            // обновить строку состояния
            StlMain.Text = $"Коллекция телевизоров упорядочена по ФИО мастера. Текущее количество телевизоров: {_televisionsController.Count}";
        }// OrderbyFullnameMaster_Command

        private void OrderbyFullnameOwner_Command(object sender, EventArgs e)
        {
            _televisionsController.OrderbyFullnameOwner();

            BindCollection();

            // обновить строку состояния
            StlMain.Text = $"Коллекция телевизоров упорядочена по ФИО владельца. Текущее количество телевизоров: {_televisionsController.Count}";
        }// OrderbyFullnameOwner_Command


        private void OrderbyPriceRepair_Command(object sender, EventArgs e)
        {
            _televisionsController.OrderbyPrice();

            BindCollection();

            // обновить строку состояния
            StlMain.Text = $"Коллекция телевизоров упорядочена по стоимости ремонта. Текущее количество телевизоров: {_televisionsController.Count}";
        }// OrderbyPriceRepair_Command


        // pедактирование выбранного телевизора в отдельной форме
        private void TVEdit_Command(object sender, EventArgs e)
        {
            if (LbxTelevisions.SelectedIndex < 0)
                return;

            // передача данных в форму
            TelevisionForm televisionForm = new TelevisionForm("Редактировать данные о телевизоре", "Сохранить");
            televisionForm.Tv = _televisionsController[LbxTelevisions.SelectedIndex];

            if (televisionForm.ShowDialog() != DialogResult.OK) return;

            // получить данные
            _televisionsController[LbxTelevisions.SelectedIndex] = televisionForm.Tv;

            // сериализация данных
            _televisionsController.SerializationJson(_filenameRepairShop);

            // обновить привязку
            BindCollection();

            // обновить строку состояния
            StlMain.Text = $"Данные обновлены. Текущее количество телевизоров: {_televisionsController.Count}";
        }// TVEdit_Command


        // pедактирование данных о мастерской в отдельной форме
        private void RepairShopEdit_Command(object sender, EventArgs e)
        {
            RepairShopEditForm repairShop =
                new RepairShopEditForm(_televisionsController.Name, _televisionsController.Address);

            if (repairShop.ShowDialog() != DialogResult.OK) return;

            _televisionsController.Name = repairShop.Name;
            _televisionsController.Address = repairShop.Address;

            // сериализация данных
            _televisionsController.SerializationJson(_filenameRepairShop);

            Text = _televisionsController.Name + ". Адрес: " + _televisionsController.Address;
        }// RepairShopEdit_Command


        // выборка и вывод в отдельной форме коллекции телевизоров с минимальной стоимостью ремонта
        private void SelectMinPrice_Command(object sender, EventArgs e)
        {
            List<Television> minPriceList = _televisionsController.GetTVsEqualsMinCost();

            SelectForm selectionsForm =
                new SelectForm(minPriceList, "Телевизоры с минимальной стоимостью ремонта");
            selectionsForm.ShowDialog();
        }// SelectMinPrice_Command

        // выборка и вывод в отдельной форме коллекции телевизоров, ремонтируемых выбранным мастером
        private void SelectRepairMaster_Command(object sender, EventArgs e)
        {
            // получить список фамилий из коллекции ремонтов
            List<string> masters = _televisionsController.GetMasters;

            ChoiceForm choiceForm = new ChoiceForm(masters);

            if (choiceForm.ShowDialog() != DialogResult.OK) return;
            // выбор мастера произведен, получим мастера, построим выборку
            SelectMaster(choiceForm.Names);

        }// SelectRepairMaster_Command

        // выборка и вывод в отдельной форме коллекции телевизоров, заданного владельца
        private void SelectRepairOwner_Command(object sender, EventArgs e)
        {
            // получить список фамилий из коллекции ремонтов
            List<string> owners = _televisionsController.GetOwners;

            ChoiceForm choiceForm = new ChoiceForm(owners);

            if (choiceForm.ShowDialog() != DialogResult.OK) return;
            // выбор владельца произведен, получим владельца, построим выборку
            SelectOwner(choiceForm.Names);
        }// SelectRepairOwner_Command

        // выборка и вывод в отдельной форме коллекции телевизоров, с заданной диагональю экрана 
        private void SelectDiagonal_Command(object sender, EventArgs e)
        {
            // получить список диагоналей из коллекции ремонтов
            List<string> diagonals = _televisionsController.GetDiagonals;

            ChoiceForm choiceForm = new ChoiceForm(diagonals);

            if (choiceForm.ShowDialog() != DialogResult.OK) return;

            SelectDiagonal(choiceForm.Names);
        }// SelectDiagonal_Command


        private void SelectMaster(string master)
        {
            // выбрать ремонты заданного мастера
            List<Television> list = _televisionsController.GetTVsEqualsRepairer(master);

            SelectForm selectionsForm =
                new SelectForm(list, $"Телевизоры, ремонтируемые мастером {master}");
            selectionsForm.ShowDialog();
        }// SelectMaster


        private void SelectOwner(string owner)
        {
            // выбрать ремонты заданного мастера
            List<Television> list = _televisionsController.GetTVsEqualsOwner(owner);

            SelectForm selectionsForm =
                new SelectForm(list, $"Телевизоры, выбранного владельца {owner}");
            selectionsForm.ShowDialog();
        }// SelectOwner


        private void SelectDiagonal(string diagonal)
        {
            // выбрать телевизоры с заданной диагональю
            List<Television> list = _televisionsController.GetTVsEqualsDiagonal(int.Parse(diagonal.ToString()));

            SelectForm selectionsForm =
                new SelectForm(list, $"Телевизоры, с заданной диагональю: {diagonal} дюйма.");
            selectionsForm.ShowDialog();
        }// SelectDiagonal

        // вызов диалога открытия файла
        private void Open_Click(object sender, EventArgs e)
        {
            if (OfdMain.ShowDialog() == DialogResult.OK)
            {
                _televisionsController.DeserializeJson(_filenameRepairShop);
                //TxbText.Text = File.ReadAllText(OfdMain.FileName);
                LbxTelevisions.Text = File.ReadAllText(OfdMain.FileName);
                StlMain.Text = OfdMain.FileName;

            } // if
        } // Open_Click

        // вызов диалога сохранения файла
        private void Save_Click(object sender, EventArgs e)
        {
            _televisionsController.SerializationJson(_filenameRepairShop);
            SfdMain.Title = "Сохранение результатов";
            //SfdMain.InitialDirectory = "../../repairShop.json";
            SfdMain.Filter = "Текстовые файлы (*.txt)|*.txt|Файлы JSON(*.json)|*.json|Файлы XML (*.xml)|*.xml|Все файлы (*.*)|*.*d";
            //SfdMain.FilterIndex = 1;

            if (SfdMain.ShowDialog() == DialogResult.OK)
            {
                File.WriteAllText(SfdMain.FileName, LbxTelevisions.Text);
                StlMain.Text = SfdMain.FileName;

            } // if
        } // Save_Click


        // вызов диалога выбора шрифта
        private void Font_Click(object sender, EventArgs e)
        {
            FdlTextFont.ShowColor = true;
            if (FdlTextFont.ShowDialog() == DialogResult.OK)
            {
                LbxTelevisions.Font = FdlTextFont.Font;

            } // if
        } // Font_Click


        // Вызов диалога выбора цвета текста
        private void Color_Click(object sender, EventArgs e)
        {
            if (CdlBackColor.ShowDialog() == DialogResult.OK)
            {
                LbxTelevisions.ForeColor = CdlBackColor.Color;
            } // if
        } // Color_Click


    }// class MainForm
}
