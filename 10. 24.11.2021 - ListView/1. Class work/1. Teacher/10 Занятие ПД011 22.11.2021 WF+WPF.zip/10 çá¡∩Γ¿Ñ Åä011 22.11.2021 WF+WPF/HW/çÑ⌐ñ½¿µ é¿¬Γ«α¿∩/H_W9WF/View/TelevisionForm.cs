﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using H_W9WF.Models;

namespace H_W9WF.Views
{
	public partial class TelevisionForm : Form
	{
		private Television _tv;

		public Television Tv
		{
			get => _tv;
			set
			{
				_tv = value;

				CmbTvBrend.Text = _tv.TvBrand;
				TxbDefect.Text = _tv.TvDefect;
				CmbMaster.Text = _tv.FullnameMaster;
				TxbOwner.Text = _tv.FullnameOwner;
				NudDiagonal.Text = _tv.Diagonal.ToString();
				NudPrice.Text = _tv.CostRepair.ToString();
			}
		}

		// конструктор для формы в режиме добавления нового телевизора
		public TelevisionForm()
		{
			InitializeComponent();
			_tv = new Television();
		}

        // конструктор для формы в режиме редкатирования данных телевизора
		public TelevisionForm(string formTitle, string btnTitle)
		{
			InitializeComponent();
			_tv = new Television();

			// Заголовок формы
			Text = formTitle;
			BtnAdd.Text = btnTitle;
		}

		// Обработчик кнопки "Добавить"/"Сохранить" - собрать данные из элементов
		// интерфейса
		private void BtnAdd_Click(object sender, EventArgs e)
		{
			if (IsEmptyFields()) return;

			_tv = new Television()
			{
				TvBrand = CmbTvBrend.Text,
				TvDefect = TxbDefect.Text,
				Diagonal = int.Parse(NudDiagonal.Text),
				FullnameOwner = TxbOwner.Text,
				CostRepair = int.Parse(NudPrice.Text),
				FullnameMaster = CmbMaster.Text
			};

		}

		// Не даём закрыться окну, если есть пустые поля
		private void TVForm_FormClosing(object sender, FormClosingEventArgs e)
		{
			if ((DialogResult == DialogResult.OK) & IsEmptyFields())
			{
				MessageBox.Show("Не все данные заполнены", "Ошибка",
					MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				e.Cancel = true;
			}
		}
		public bool IsEmptyFields() =>
			string.IsNullOrWhiteSpace(CmbTvBrend.Text) ||
			string.IsNullOrWhiteSpace(TxbDefect.Text) ||
			string.IsNullOrWhiteSpace(TxbOwner.Text) ||
			string.IsNullOrWhiteSpace(CmbMaster.Text) ||
			string.IsNullOrWhiteSpace(NudDiagonal.Text) ||
			string.IsNullOrWhiteSpace(NudPrice.Text);

    }
}
