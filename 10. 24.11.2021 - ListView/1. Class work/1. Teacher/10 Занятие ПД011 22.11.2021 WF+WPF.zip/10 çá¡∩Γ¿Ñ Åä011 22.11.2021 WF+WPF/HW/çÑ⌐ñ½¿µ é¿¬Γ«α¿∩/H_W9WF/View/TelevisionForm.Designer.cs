﻿
namespace H_W9WF.Views
{
    partial class TelevisionForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.GrbInfo = new System.Windows.Forms.GroupBox();
            this.CmbTvBrend = new System.Windows.Forms.ComboBox();
            this.NudPrice = new System.Windows.Forms.NumericUpDown();
            this.NudDiagonal = new System.Windows.Forms.NumericUpDown();
            this.LblPrice = new System.Windows.Forms.Label();
            this.LblDiagonal = new System.Windows.Forms.Label();
            this.LblOwner = new System.Windows.Forms.Label();
            this.LblRepairer = new System.Windows.Forms.Label();
            this.LblDefect = new System.Windows.Forms.Label();
            this.LblBrandType = new System.Windows.Forms.Label();
            this.TxbOwner = new System.Windows.Forms.TextBox();
            this.TxbDefect = new System.Windows.Forms.TextBox();
            this.BtnAdd = new System.Windows.Forms.Button();
            this.BtnClose = new System.Windows.Forms.Button();
            this.CmbMaster = new System.Windows.Forms.ComboBox();
            this.GrbInfo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.NudPrice)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NudDiagonal)).BeginInit();
            this.SuspendLayout();
            // 
            // GrbInfo
            // 
            this.GrbInfo.BackColor = System.Drawing.Color.Lavender;
            this.GrbInfo.Controls.Add(this.CmbMaster);
            this.GrbInfo.Controls.Add(this.CmbTvBrend);
            this.GrbInfo.Controls.Add(this.NudPrice);
            this.GrbInfo.Controls.Add(this.NudDiagonal);
            this.GrbInfo.Controls.Add(this.LblPrice);
            this.GrbInfo.Controls.Add(this.LblDiagonal);
            this.GrbInfo.Controls.Add(this.LblOwner);
            this.GrbInfo.Controls.Add(this.LblRepairer);
            this.GrbInfo.Controls.Add(this.LblDefect);
            this.GrbInfo.Controls.Add(this.LblBrandType);
            this.GrbInfo.Controls.Add(this.TxbOwner);
            this.GrbInfo.Controls.Add(this.TxbDefect);
            this.GrbInfo.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.GrbInfo.Location = new System.Drawing.Point(20, 16);
            this.GrbInfo.Name = "GrbInfo";
            this.GrbInfo.Size = new System.Drawing.Size(342, 352);
            this.GrbInfo.TabIndex = 0;
            this.GrbInfo.TabStop = false;
            this.GrbInfo.Text = "Данные о телевизоре";
            // 
            // CmbTvBrend
            // 
            this.CmbTvBrend.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CmbTvBrend.FormattingEnabled = true;
            this.CmbTvBrend.Items.AddRange(new object[] {
            "Hisense",
            "LG",
            "Philips",
            "Samsung",
            "Sony",
            "TCL"});
            this.CmbTvBrend.Location = new System.Drawing.Point(165, 48);
            this.CmbTvBrend.Name = "CmbTvBrend";
            this.CmbTvBrend.Size = new System.Drawing.Size(171, 26);
            this.CmbTvBrend.Sorted = true;
            this.CmbTvBrend.TabIndex = 12;
            // 
            // NudPrice
            // 
            this.NudPrice.Increment = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.NudPrice.Location = new System.Drawing.Point(165, 281);
            this.NudPrice.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.NudPrice.Minimum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.NudPrice.Name = "NudPrice";
            this.NudPrice.Size = new System.Drawing.Size(171, 24);
            this.NudPrice.TabIndex = 11;
            this.NudPrice.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.NudPrice.Value = new decimal(new int[] {
            10,
            0,
            0,
            0});
            // 
            // NudDiagonal
            // 
            this.NudDiagonal.Location = new System.Drawing.Point(165, 84);
            this.NudDiagonal.Maximum = new decimal(new int[] {
            130,
            0,
            0,
            0});
            this.NudDiagonal.Minimum = new decimal(new int[] {
            17,
            0,
            0,
            0});
            this.NudDiagonal.Name = "NudDiagonal";
            this.NudDiagonal.Size = new System.Drawing.Size(171, 24);
            this.NudDiagonal.TabIndex = 10;
            this.NudDiagonal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.NudDiagonal.Value = new decimal(new int[] {
            17,
            0,
            0,
            0});
            // 
            // LblPrice
            // 
            this.LblPrice.Location = new System.Drawing.Point(6, 283);
            this.LblPrice.Name = "LblPrice";
            this.LblPrice.Size = new System.Drawing.Size(160, 24);
            this.LblPrice.TabIndex = 9;
            this.LblPrice.Text = "Стоимость ремонта:";
            // 
            // LblDiagonal
            // 
            this.LblDiagonal.Location = new System.Drawing.Point(13, 85);
            this.LblDiagonal.Name = "LblDiagonal";
            this.LblDiagonal.Size = new System.Drawing.Size(114, 24);
            this.LblDiagonal.TabIndex = 8;
            this.LblDiagonal.Text = "Диагональ TV:";
            // 
            // LblOwner
            // 
            this.LblOwner.Location = new System.Drawing.Point(13, 119);
            this.LblOwner.Name = "LblOwner";
            this.LblOwner.Size = new System.Drawing.Size(114, 24);
            this.LblOwner.TabIndex = 7;
            this.LblOwner.Text = "Владелец TV:";
            // 
            // LblRepairer
            // 
            this.LblRepairer.Location = new System.Drawing.Point(6, 233);
            this.LblRepairer.Name = "LblRepairer";
            this.LblRepairer.Size = new System.Drawing.Size(160, 24);
            this.LblRepairer.TabIndex = 6;
            this.LblRepairer.Text = "Мастер по ремонту:";
            // 
            // LblDefect
            // 
            this.LblDefect.Location = new System.Drawing.Point(6, 163);
            this.LblDefect.Name = "LblDefect";
            this.LblDefect.Size = new System.Drawing.Size(164, 24);
            this.LblDefect.TabIndex = 5;
            this.LblDefect.Text = "Описание деффекта:";
            // 
            // LblBrandType
            // 
            this.LblBrandType.Location = new System.Drawing.Point(13, 51);
            this.LblBrandType.Name = "LblBrandType";
            this.LblBrandType.Size = new System.Drawing.Size(107, 24);
            this.LblBrandType.TabIndex = 4;
            this.LblBrandType.Text = "Модель TV:";
            // 
            // TxbOwner
            // 
            this.TxbOwner.Location = new System.Drawing.Point(165, 118);
            this.TxbOwner.Name = "TxbOwner";
            this.TxbOwner.Size = new System.Drawing.Size(171, 24);
            this.TxbOwner.TabIndex = 3;
            // 
            // TxbDefect
            // 
            this.TxbDefect.Location = new System.Drawing.Point(9, 190);
            this.TxbDefect.Name = "TxbDefect";
            this.TxbDefect.Size = new System.Drawing.Size(327, 24);
            this.TxbDefect.TabIndex = 1;
            // 
            // BtnAdd
            // 
            this.BtnAdd.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.BtnAdd.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.BtnAdd.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BtnAdd.Location = new System.Drawing.Point(20, 384);
            this.BtnAdd.Name = "BtnAdd";
            this.BtnAdd.Size = new System.Drawing.Size(152, 40);
            this.BtnAdd.TabIndex = 12;
            this.BtnAdd.Text = "Добавить";
            this.BtnAdd.UseVisualStyleBackColor = false;
            this.BtnAdd.Click += new System.EventHandler(this.BtnAdd_Click);
            // 
            // BtnClose
            // 
            this.BtnClose.BackColor = System.Drawing.Color.CadetBlue;
            this.BtnClose.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.BtnClose.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BtnClose.Location = new System.Drawing.Point(212, 384);
            this.BtnClose.Name = "BtnClose";
            this.BtnClose.Size = new System.Drawing.Size(152, 40);
            this.BtnClose.TabIndex = 13;
            this.BtnClose.Text = "Отмена";
            this.BtnClose.UseVisualStyleBackColor = false;
            // 
            // CmbMaster
            // 
            this.CmbMaster.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CmbMaster.FormattingEnabled = true;
            this.CmbMaster.Items.AddRange(new object[] {
            "Воронин Л.А.",
            "Ковалёв М.А.",
            "Лужко С.Л.",
            "Тюрин О.А."});
            this.CmbMaster.Location = new System.Drawing.Point(165, 230);
            this.CmbMaster.Name = "CmbMaster";
            this.CmbMaster.Size = new System.Drawing.Size(171, 26);
            this.CmbMaster.Sorted = true;
            this.CmbMaster.TabIndex = 13;
            // 
            // TelevisionForm
            // 
            this.AcceptButton = this.BtnAdd;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightCyan;
            this.ClientSize = new System.Drawing.Size(380, 437);
            this.Controls.Add(this.BtnClose);
            this.Controls.Add(this.BtnAdd);
            this.Controls.Add(this.GrbInfo);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.MaximizeBox = false;
            this.Name = "TelevisionForm";
            this.ShowInTaskbar = false;
            this.Text = "Добавить телевизор";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.TVForm_FormClosing);
            this.GrbInfo.ResumeLayout(false);
            this.GrbInfo.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.NudPrice)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NudDiagonal)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox GrbInfo;
        private System.Windows.Forms.NumericUpDown NudPrice;
        private System.Windows.Forms.NumericUpDown NudDiagonal;
        private System.Windows.Forms.Label LblPrice;
        private System.Windows.Forms.Label LblDiagonal;
        private System.Windows.Forms.Label LblOwner;
        private System.Windows.Forms.Label LblRepairer;
        private System.Windows.Forms.Label LblDefect;
        private System.Windows.Forms.Label LblBrandType;
        private System.Windows.Forms.TextBox TxbOwner;
        private System.Windows.Forms.TextBox TxbDefect;
        private System.Windows.Forms.Button BtnAdd;
        private System.Windows.Forms.Button BtnClose;
        private System.Windows.Forms.ComboBox CmbTvBrend;
        private System.Windows.Forms.ComboBox CmbMaster;
    }
}