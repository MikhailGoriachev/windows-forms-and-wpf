﻿
namespace H_W9WF.View
{
    partial class SelectForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.LbxTelevisions = new System.Windows.Forms.ListBox();
            this.LblTelevisions = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // LbxTelevisions
            // 
            this.LbxTelevisions.Font = new System.Drawing.Font("Consolas", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LbxTelevisions.FormattingEnabled = true;
            this.LbxTelevisions.ItemHeight = 15;
            this.LbxTelevisions.Location = new System.Drawing.Point(22, 106);
            this.LbxTelevisions.Name = "LbxTelevisions";
            this.LbxTelevisions.ScrollAlwaysVisible = true;
            this.LbxTelevisions.Size = new System.Drawing.Size(625, 244);
            this.LbxTelevisions.TabIndex = 5;
            // 
            // LblTelevisions
            // 
            this.LblTelevisions.BackColor = System.Drawing.SystemColors.Control;
            this.LblTelevisions.Font = new System.Drawing.Font("Verdana", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblTelevisions.Location = new System.Drawing.Point(22, 62);
            this.LblTelevisions.Name = "LblTelevisions";
            this.LblTelevisions.Size = new System.Drawing.Size(625, 41);
            this.LblTelevisions.TabIndex = 6;
            this.LblTelevisions.Text = "  Коллекция телевизоров:\r\n  Бренд    Дюйм      Описание дефекта      ФИО мастера " +
    "   ФИО владельца   Цена";
            // 
            // SelectForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(675, 362);
            this.Controls.Add(this.LblTelevisions);
            this.Controls.Add(this.LbxTelevisions);
            this.MaximizeBox = false;
            this.Name = "SelectForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Выборка данных ";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListBox LbxTelevisions;
        private System.Windows.Forms.Label LblTelevisions;
    }
}