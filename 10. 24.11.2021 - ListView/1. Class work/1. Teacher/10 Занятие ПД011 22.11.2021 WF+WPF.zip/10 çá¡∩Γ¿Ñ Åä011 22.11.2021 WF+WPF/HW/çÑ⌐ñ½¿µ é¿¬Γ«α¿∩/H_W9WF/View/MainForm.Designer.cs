﻿
namespace H_W9WF
{
    partial class MainForm
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.MnuMain = new System.Windows.Forms.MenuStrip();
            this.MniFile = new System.Windows.Forms.ToolStripMenuItem();
            this.MniExit = new System.Windows.Forms.ToolStripMenuItem();
            this.MniEdit = new System.Windows.Forms.ToolStripMenuItem();
            this.MniEditNewCollection = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripSeparator();
            this.MniEditingTV = new System.Windows.Forms.ToolStripMenuItem();
            this.MniEditingMastersk = new System.Windows.Forms.ToolStripMenuItem();
            this.MniSort = new System.Windows.Forms.ToolStripMenuItem();
            this.MniSortBrend = new System.Windows.Forms.ToolStripMenuItem();
            this.MniSortDiag = new System.Windows.Forms.ToolStripMenuItem();
            this.MniSortMaster = new System.Windows.Forms.ToolStripMenuItem();
            this.MniSortOwner = new System.Windows.Forms.ToolStripMenuItem();
            this.MniSample = new System.Windows.Forms.ToolStripMenuItem();
            this.MniSampleMinCost = new System.Windows.Forms.ToolStripMenuItem();
            this.MniSampleMaster = new System.Windows.Forms.ToolStripMenuItem();
            this.MniSampleDiagonal = new System.Windows.Forms.ToolStripMenuItem();
            this.MniHelp = new System.Windows.Forms.ToolStripMenuItem();
            this.MniHelpAbout = new System.Windows.Forms.ToolStripMenuItem();
            this.TsbMain = new System.Windows.Forms.ToolStrip();
            this.TlsNew = new System.Windows.Forms.ToolStripButton();
            this.TstAdd = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.TslRedTv = new System.Windows.Forms.ToolStripButton();
            this.TlsTvRed = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.TlsSort = new System.Windows.Forms.ToolStripButton();
            this.TlsSortD = new System.Windows.Forms.ToolStripButton();
            this.TlsSortFM = new System.Windows.Forms.ToolStripButton();
            this.TlsTO = new System.Windows.Forms.ToolStripButton();
            this.TsbExit = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.TslMinPrice = new System.Windows.Forms.ToolStripButton();
            this.TslMaster = new System.Windows.Forms.ToolStripButton();
            this.TslDiagonal = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.TslHelpAbout = new System.Windows.Forms.ToolStripButton();
            this.StsMain = new System.Windows.Forms.StatusStrip();
            this.StlMain = new System.Windows.Forms.ToolStripStatusLabel();
            this.LbxTelevisions = new System.Windows.Forms.ListBox();
            this.LblTelevisions = new System.Windows.Forms.Label();
            this.OfdMain = new System.Windows.Forms.OpenFileDialog();
            this.tVЗаданногоВладельцаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.TslOwner = new System.Windows.Forms.ToolStripButton();
            this.SfdMain = new System.Windows.Forms.SaveFileDialog();
            this.MniSave = new System.Windows.Forms.ToolStripMenuItem();
            this.MniService = new System.Windows.Forms.ToolStripMenuItem();
            this.MniServiceFont = new System.Windows.Forms.ToolStripMenuItem();
            this.открытьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.FdlTextFont = new System.Windows.Forms.FontDialog();
            this.MniServiceBackColor = new System.Windows.Forms.ToolStripMenuItem();
            this.CdlBackColor = new System.Windows.Forms.ColorDialog();
            this.добавитьТVToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.MniAddTV = new System.Windows.Forms.ToolStripMenuItem();
            this.MniRemoveTV = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripMenuItem4 = new System.Windows.Forms.ToolStripSeparator();
            this.TlsRemoveAtTV = new System.Windows.Forms.ToolStripButton();
            this.TlsSPrice = new System.Windows.Forms.ToolStripButton();
            this.MniSortPrice = new System.Windows.Forms.ToolStripMenuItem();
            this.CmnMain = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.CmnExit = new System.Windows.Forms.ToolStripMenuItem();
            this.CmnAboutProgram = new System.Windows.Forms.ToolStripMenuItem();
            this.CmnProgram = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.CmnNewColl = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem5 = new System.Windows.Forms.ToolStripSeparator();
            this.CmnSort = new System.Windows.Forms.ToolStripMenuItem();
            this.CmnSortModel = new System.Windows.Forms.ToolStripMenuItem();
            this.CmnSortDiagonal = new System.Windows.Forms.ToolStripMenuItem();
            this.CmnSortMaster = new System.Windows.Forms.ToolStripMenuItem();
            this.CmnSortOwner = new System.Windows.Forms.ToolStripMenuItem();
            this.CmnSortPrice = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem6 = new System.Windows.Forms.ToolStripSeparator();
            this.CmnAddTV = new System.Windows.Forms.ToolStripMenuItem();
            this.CmnRemoveAtTV = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem7 = new System.Windows.Forms.ToolStripSeparator();
            this.CmnEditTV = new System.Windows.Forms.ToolStripMenuItem();
            this.CmnEditRepairShop = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem8 = new System.Windows.Forms.ToolStripSeparator();
            this.CmnSelect = new System.Windows.Forms.ToolStripMenuItem();
            this.CmnSelectMinPrice = new System.Windows.Forms.ToolStripMenuItem();
            this.CmnSelectMaster = new System.Windows.Forms.ToolStripMenuItem();
            this.CmnSelectDiagonal = new System.Windows.Forms.ToolStripMenuItem();
            this.CmnSelectOwner = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem9 = new System.Windows.Forms.ToolStripSeparator();
            this.CmnProgramExit = new System.Windows.Forms.ToolStripMenuItem();
            this.MnuMain.SuspendLayout();
            this.TsbMain.SuspendLayout();
            this.StsMain.SuspendLayout();
            this.CmnMain.SuspendLayout();
            this.CmnProgram.SuspendLayout();
            this.SuspendLayout();
            // 
            // MnuMain
            // 
            this.MnuMain.Font = new System.Drawing.Font("Lucida Console", 12F);
            this.MnuMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniFile,
            this.MniService,
            this.MniEdit,
            this.MniSort,
            this.MniSample,
            this.MniHelp});
            this.MnuMain.Location = new System.Drawing.Point(0, 0);
            this.MnuMain.Name = "MnuMain";
            this.MnuMain.Size = new System.Drawing.Size(1006, 24);
            this.MnuMain.TabIndex = 0;
            this.MnuMain.Text = "menuStrip1";
            // 
            // MniFile
            // 
            this.MniFile.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.открытьToolStripMenuItem,
            this.MniSave,
            this.toolStripMenuItem4,
            this.MniExit});
            this.MniFile.Name = "MniFile";
            this.MniFile.Size = new System.Drawing.Size(60, 20);
            this.MniFile.Text = "Файл";
            // 
            // MniExit
            // 
            this.MniExit.Image = ((System.Drawing.Image)(resources.GetObject("MniExit.Image")));
            this.MniExit.Name = "MniExit";
            this.MniExit.Size = new System.Drawing.Size(186, 22);
            this.MniExit.Text = "Выход";
            this.MniExit.Click += new System.EventHandler(this.Exit_Command);
            // 
            // MniEdit
            // 
            this.MniEdit.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.добавитьТVToolStripMenuItem,
            this.MniEditNewCollection,
            this.toolStripMenuItem1,
            this.MniAddTV,
            this.MniRemoveTV,
            this.toolStripMenuItem3,
            this.MniEditingTV,
            this.MniEditingMastersk,
            this.toolStripMenuItem2});
            this.MniEdit.Name = "MniEdit";
            this.MniEdit.Size = new System.Drawing.Size(80, 20);
            this.MniEdit.Text = "Правка";
            // 
            // MniEditNewCollection
            // 
            this.MniEditNewCollection.Image = ((System.Drawing.Image)(resources.GetObject("MniEditNewCollection.Image")));
            this.MniEditNewCollection.Name = "MniEditNewCollection";
            this.MniEditNewCollection.Size = new System.Drawing.Size(406, 22);
            this.MniEditNewCollection.Text = "Новая коллекция";
            this.MniEditNewCollection.Click += new System.EventHandler(this.NewCollection_Command);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(403, 6);
            // 
            // MniEditingTV
            // 
            this.MniEditingTV.Image = ((System.Drawing.Image)(resources.GetObject("MniEditingTV.Image")));
            this.MniEditingTV.Name = "MniEditingTV";
            this.MniEditingTV.Size = new System.Drawing.Size(406, 22);
            this.MniEditingTV.Text = "Редактировать данные TV..";
            this.MniEditingTV.Click += new System.EventHandler(this.TVEdit_Command);
            // 
            // MniEditingMastersk
            // 
            this.MniEditingMastersk.Image = ((System.Drawing.Image)(resources.GetObject("MniEditingMastersk.Image")));
            this.MniEditingMastersk.Name = "MniEditingMastersk";
            this.MniEditingMastersk.Size = new System.Drawing.Size(406, 22);
            this.MniEditingMastersk.Text = "Редактировать данные мастерской..";
            this.MniEditingMastersk.Click += new System.EventHandler(this.RepairShopEdit_Command);
            // 
            // MniSort
            // 
            this.MniSort.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniSortBrend,
            this.MniSortDiag,
            this.MniSortMaster,
            this.MniSortOwner,
            this.MniSortPrice});
            this.MniSort.Name = "MniSort";
            this.MniSort.Size = new System.Drawing.Size(120, 20);
            this.MniSort.Text = "Сортировка";
            // 
            // MniSortBrend
            // 
            this.MniSortBrend.Image = ((System.Drawing.Image)(resources.GetObject("MniSortBrend.Image")));
            this.MniSortBrend.Name = "MniSortBrend";
            this.MniSortBrend.Size = new System.Drawing.Size(276, 22);
            this.MniSortBrend.Text = "По бренду";
            this.MniSortBrend.Click += new System.EventHandler(this.OrderbyTvBrand_Command);
            // 
            // MniSortDiag
            // 
            this.MniSortDiag.Image = ((System.Drawing.Image)(resources.GetObject("MniSortDiag.Image")));
            this.MniSortDiag.Name = "MniSortDiag";
            this.MniSortDiag.Size = new System.Drawing.Size(276, 22);
            this.MniSortDiag.Text = "По диагонали экрана";
            this.MniSortDiag.Click += new System.EventHandler(this.OrderbyDiagonal_Command);
            // 
            // MniSortMaster
            // 
            this.MniSortMaster.Image = ((System.Drawing.Image)(resources.GetObject("MniSortMaster.Image")));
            this.MniSortMaster.Name = "MniSortMaster";
            this.MniSortMaster.Size = new System.Drawing.Size(276, 22);
            this.MniSortMaster.Text = "По ФИО мастера";
            this.MniSortMaster.Click += new System.EventHandler(this.OrderbyFullnameMaster_Command);
            // 
            // MniSortOwner
            // 
            this.MniSortOwner.Image = ((System.Drawing.Image)(resources.GetObject("MniSortOwner.Image")));
            this.MniSortOwner.Name = "MniSortOwner";
            this.MniSortOwner.Size = new System.Drawing.Size(276, 22);
            this.MniSortOwner.Text = "По ФИО владельца";
            this.MniSortOwner.Click += new System.EventHandler(this.OrderbyFullnameOwner_Command);
            // 
            // MniSample
            // 
            this.MniSample.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniSampleMinCost,
            this.MniSampleMaster,
            this.MniSampleDiagonal,
            this.tVЗаданногоВладельцаToolStripMenuItem});
            this.MniSample.Name = "MniSample";
            this.MniSample.Size = new System.Drawing.Size(90, 20);
            this.MniSample.Text = "Выборка";
            // 
            // MniSampleMinCost
            // 
            this.MniSampleMinCost.Font = new System.Drawing.Font("Lucida Console", 10F);
            this.MniSampleMinCost.Name = "MniSampleMinCost";
            this.MniSampleMinCost.Size = new System.Drawing.Size(355, 22);
            this.MniSampleMinCost.Text = "TV с минимальной стоимостью ремонта";
            this.MniSampleMinCost.Click += new System.EventHandler(this.SelectMinPrice_Command);
            // 
            // MniSampleMaster
            // 
            this.MniSampleMaster.Font = new System.Drawing.Font("Lucida Console", 10F);
            this.MniSampleMaster.Name = "MniSampleMaster";
            this.MniSampleMaster.Size = new System.Drawing.Size(355, 22);
            this.MniSampleMaster.Text = "TV ремонтируемых выбранным мастером";
            this.MniSampleMaster.Click += new System.EventHandler(this.SelectRepairMaster_Command);
            // 
            // MniSampleDiagonal
            // 
            this.MniSampleDiagonal.Font = new System.Drawing.Font("Lucida Console", 10F);
            this.MniSampleDiagonal.Name = "MniSampleDiagonal";
            this.MniSampleDiagonal.Size = new System.Drawing.Size(355, 22);
            this.MniSampleDiagonal.Text = "TV с заданной диагональю экрана";
            this.MniSampleDiagonal.Click += new System.EventHandler(this.SelectDiagonal_Command);
            // 
            // MniHelp
            // 
            this.MniHelp.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.MniHelp.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniHelpAbout});
            this.MniHelp.Name = "MniHelp";
            this.MniHelp.Size = new System.Drawing.Size(90, 20);
            this.MniHelp.Text = "Справка";
            // 
            // MniHelpAbout
            // 
            this.MniHelpAbout.Image = ((System.Drawing.Image)(resources.GetObject("MniHelpAbout.Image")));
            this.MniHelpAbout.Name = "MniHelpAbout";
            this.MniHelpAbout.Size = new System.Drawing.Size(206, 22);
            this.MniHelpAbout.Text = "О программе..";
            // 
            // TsbMain
            // 
            this.TsbMain.AutoSize = false;
            this.TsbMain.Font = new System.Drawing.Font("Lucida Console", 12F);
            this.TsbMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.TlsNew,
            this.TstAdd,
            this.TlsRemoveAtTV,
            this.toolStripSeparator1,
            this.TslRedTv,
            this.TlsTvRed,
            this.toolStripSeparator2,
            this.TlsSort,
            this.TlsSortD,
            this.TlsSortFM,
            this.TlsTO,
            this.TsbExit,
            this.TlsSPrice,
            this.toolStripSeparator3,
            this.TslMinPrice,
            this.TslMaster,
            this.TslDiagonal,
            this.TslOwner,
            this.toolStripSeparator4,
            this.TslHelpAbout});
            this.TsbMain.Location = new System.Drawing.Point(0, 24);
            this.TsbMain.Name = "TsbMain";
            this.TsbMain.Size = new System.Drawing.Size(1006, 38);
            this.TsbMain.TabIndex = 1;
            this.TsbMain.Text = "toolStrip1";
            // 
            // TlsNew
            // 
            this.TlsNew.BackColor = System.Drawing.Color.PaleTurquoise;
            this.TlsNew.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TlsNew.Image = ((System.Drawing.Image)(resources.GetObject("TlsNew.Image")));
            this.TlsNew.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TlsNew.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TlsNew.Name = "TlsNew";
            this.TlsNew.Size = new System.Drawing.Size(32, 35);
            this.TlsNew.Text = "Новая коллекция";
            this.TlsNew.ToolTipText = "Сформировать новую коллекцию";
            this.TlsNew.Click += new System.EventHandler(this.NewCollection_Command);
            // 
            // TstAdd
            // 
            this.TstAdd.BackColor = System.Drawing.Color.PowderBlue;
            this.TstAdd.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TstAdd.Image = ((System.Drawing.Image)(resources.GetObject("TstAdd.Image")));
            this.TstAdd.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TstAdd.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TstAdd.Name = "TstAdd";
            this.TstAdd.Size = new System.Drawing.Size(32, 35);
            this.TstAdd.Text = "Добавить данные";
            this.TstAdd.ToolTipText = "Добавить данные нового \r\nтелевизора";
            this.TstAdd.Click += new System.EventHandler(this.AddTelevision_Command);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 38);
            // 
            // TslRedTv
            // 
            this.TslRedTv.BackColor = System.Drawing.Color.PaleTurquoise;
            this.TslRedTv.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TslRedTv.Image = ((System.Drawing.Image)(resources.GetObject("TslRedTv.Image")));
            this.TslRedTv.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TslRedTv.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TslRedTv.Name = "TslRedTv";
            this.TslRedTv.Size = new System.Drawing.Size(32, 35);
            this.TslRedTv.Text = "toolStripButton1";
            this.TslRedTv.ToolTipText = "Редактировать данные\r\nвыбранного телевизора";
            this.TslRedTv.Click += new System.EventHandler(this.TVEdit_Command);
            // 
            // TlsTvRed
            // 
            this.TlsTvRed.BackColor = System.Drawing.Color.PaleTurquoise;
            this.TlsTvRed.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TlsTvRed.Image = ((System.Drawing.Image)(resources.GetObject("TlsTvRed.Image")));
            this.TlsTvRed.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TlsTvRed.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TlsTvRed.Name = "TlsTvRed";
            this.TlsTvRed.Size = new System.Drawing.Size(32, 35);
            this.TlsTvRed.Text = "toolStripButton1";
            this.TlsTvRed.ToolTipText = "Редактирование данные мастерской";
            this.TlsTvRed.Click += new System.EventHandler(this.RepairShopEdit_Command);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 38);
            // 
            // TlsSort
            // 
            this.TlsSort.BackColor = System.Drawing.Color.LightCyan;
            this.TlsSort.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TlsSort.Image = ((System.Drawing.Image)(resources.GetObject("TlsSort.Image")));
            this.TlsSort.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TlsSort.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TlsSort.Name = "TlsSort";
            this.TlsSort.Size = new System.Drawing.Size(32, 35);
            this.TlsSort.Text = "toolStripButton3";
            this.TlsSort.ToolTipText = "Сортировка коллекции по \r\nбренду телевизора";
            this.TlsSort.Click += new System.EventHandler(this.OrderbyTvBrand_Command);
            // 
            // TlsSortD
            // 
            this.TlsSortD.BackColor = System.Drawing.Color.LightCyan;
            this.TlsSortD.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TlsSortD.Image = ((System.Drawing.Image)(resources.GetObject("TlsSortD.Image")));
            this.TlsSortD.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TlsSortD.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TlsSortD.Name = "TlsSortD";
            this.TlsSortD.Size = new System.Drawing.Size(32, 35);
            this.TlsSortD.Text = "toolStripButton1";
            this.TlsSortD.ToolTipText = "Сортировка коллекции по \r\nдиагонали телевизора";
            this.TlsSortD.Click += new System.EventHandler(this.OrderbyDiagonal_Command);
            // 
            // TlsSortFM
            // 
            this.TlsSortFM.BackColor = System.Drawing.Color.LightCyan;
            this.TlsSortFM.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TlsSortFM.Image = ((System.Drawing.Image)(resources.GetObject("TlsSortFM.Image")));
            this.TlsSortFM.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TlsSortFM.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TlsSortFM.Name = "TlsSortFM";
            this.TlsSortFM.Size = new System.Drawing.Size(32, 35);
            this.TlsSortFM.Text = "toolStripButton2";
            this.TlsSortFM.ToolTipText = "Сортировка коллекции по мастеру,\r\nвыполняющему ремонт";
            this.TlsSortFM.Click += new System.EventHandler(this.OrderbyFullnameMaster_Command);
            // 
            // TlsTO
            // 
            this.TlsTO.BackColor = System.Drawing.Color.LightCyan;
            this.TlsTO.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TlsTO.Image = ((System.Drawing.Image)(resources.GetObject("TlsTO.Image")));
            this.TlsTO.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TlsTO.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TlsTO.Name = "TlsTO";
            this.TlsTO.Size = new System.Drawing.Size(32, 35);
            this.TlsTO.Text = "toolStripButton3";
            this.TlsTO.ToolTipText = "Сортировка коллекции по \r\nвладельцу телевизора";
            this.TlsTO.Click += new System.EventHandler(this.OrderbyFullnameOwner_Command);
            // 
            // TsbExit
            // 
            this.TsbExit.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.TsbExit.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbExit.Image = ((System.Drawing.Image)(resources.GetObject("TsbExit.Image")));
            this.TsbExit.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbExit.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbExit.Name = "TsbExit";
            this.TsbExit.Size = new System.Drawing.Size(32, 35);
            this.TsbExit.Text = "toolStripButton1";
            this.TsbExit.ToolTipText = "Завершение работы приложения";
            this.TsbExit.Click += new System.EventHandler(this.Exit_Command);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(6, 38);
            // 
            // TslMinPrice
            // 
            this.TslMinPrice.BackColor = System.Drawing.Color.LightBlue;
            this.TslMinPrice.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TslMinPrice.Image = ((System.Drawing.Image)(resources.GetObject("TslMinPrice.Image")));
            this.TslMinPrice.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TslMinPrice.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TslMinPrice.Name = "TslMinPrice";
            this.TslMinPrice.Size = new System.Drawing.Size(32, 35);
            this.TslMinPrice.Text = "toolStripButton1";
            this.TslMinPrice.ToolTipText = "Выборка телевизоров с\r\nминимальной стоимостью ремонта";
            this.TslMinPrice.Click += new System.EventHandler(this.SelectMinPrice_Command);
            // 
            // TslMaster
            // 
            this.TslMaster.BackColor = System.Drawing.Color.LightBlue;
            this.TslMaster.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TslMaster.Image = ((System.Drawing.Image)(resources.GetObject("TslMaster.Image")));
            this.TslMaster.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TslMaster.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TslMaster.Name = "TslMaster";
            this.TslMaster.Size = new System.Drawing.Size(32, 35);
            this.TslMaster.Text = "toolStripButton2";
            this.TslMaster.ToolTipText = "Выборка телевизоров ремонтируемых\r\nвыбранным мастером";
            this.TslMaster.Click += new System.EventHandler(this.SelectRepairMaster_Command);
            // 
            // TslDiagonal
            // 
            this.TslDiagonal.BackColor = System.Drawing.Color.LightBlue;
            this.TslDiagonal.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TslDiagonal.Image = ((System.Drawing.Image)(resources.GetObject("TslDiagonal.Image")));
            this.TslDiagonal.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TslDiagonal.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TslDiagonal.Name = "TslDiagonal";
            this.TslDiagonal.Size = new System.Drawing.Size(32, 35);
            this.TslDiagonal.Text = "toolStripButton3";
            this.TslDiagonal.ToolTipText = "Выборка телевизоров с\r\n заданной диагональю экрана";
            this.TslDiagonal.Click += new System.EventHandler(this.SelectDiagonal_Command);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(6, 38);
            // 
            // TslHelpAbout
            // 
            this.TslHelpAbout.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TslHelpAbout.Image = ((System.Drawing.Image)(resources.GetObject("TslHelpAbout.Image")));
            this.TslHelpAbout.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TslHelpAbout.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TslHelpAbout.Name = "TslHelpAbout";
            this.TslHelpAbout.Size = new System.Drawing.Size(32, 35);
            this.TslHelpAbout.Text = "toolStripButton1";
            this.TslHelpAbout.ToolTipText = "Вывод свежедений о приложении \r\nи разработчике";
            this.TslHelpAbout.Click += new System.EventHandler(this.About_Command);
            // 
            // StsMain
            // 
            this.StsMain.Font = new System.Drawing.Font("Lucida Console", 10F);
            this.StsMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.StlMain});
            this.StsMain.Location = new System.Drawing.Point(0, 539);
            this.StsMain.Name = "StsMain";
            this.StsMain.Size = new System.Drawing.Size(1006, 22);
            this.StsMain.TabIndex = 2;
            this.StsMain.Text = "StripStatus";
            // 
            // StlMain
            // 
            this.StlMain.Name = "StlMain";
            this.StlMain.Size = new System.Drawing.Size(991, 17);
            this.StlMain.Spring = true;
            this.StlMain.Text = "ToolStripStatusLabel1";
            this.StlMain.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // LbxTelevisions
            // 
            this.LbxTelevisions.ContextMenuStrip = this.CmnProgram;
            this.LbxTelevisions.Font = new System.Drawing.Font("Consolas", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LbxTelevisions.FormattingEnabled = true;
            this.LbxTelevisions.ItemHeight = 19;
            this.LbxTelevisions.Location = new System.Drawing.Point(12, 115);
            this.LbxTelevisions.Name = "LbxTelevisions";
            this.LbxTelevisions.ScrollAlwaysVisible = true;
            this.LbxTelevisions.Size = new System.Drawing.Size(805, 346);
            this.LbxTelevisions.TabIndex = 4;
            // 
            // LblTelevisions
            // 
            this.LblTelevisions.BackColor = System.Drawing.SystemColors.Control;
            this.LblTelevisions.Font = new System.Drawing.Font("Verdana", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblTelevisions.Location = new System.Drawing.Point(12, 71);
            this.LblTelevisions.Name = "LblTelevisions";
            this.LblTelevisions.Size = new System.Drawing.Size(805, 41);
            this.LblTelevisions.TabIndex = 5;
            this.LblTelevisions.Text = "  Коллекция телевизоров:\r\n  Бренд    Диагональ          Описание дефекта         " +
    "     ФИО мастера      ФИО владельца        Цена";
            // 
            // OfdMain
            // 
            this.OfdMain.FileName = "repairShop";
            // 
            // tVЗаданногоВладельцаToolStripMenuItem
            // 
            this.tVЗаданногоВладельцаToolStripMenuItem.Font = new System.Drawing.Font("Lucida Console", 10F);
            this.tVЗаданногоВладельцаToolStripMenuItem.Name = "tVЗаданногоВладельцаToolStripMenuItem";
            this.tVЗаданногоВладельцаToolStripMenuItem.Size = new System.Drawing.Size(355, 22);
            this.tVЗаданногоВладельцаToolStripMenuItem.Text = "TV заданного владельца";
            this.tVЗаданногоВладельцаToolStripMenuItem.Click += new System.EventHandler(this.SelectRepairOwner_Command);
            // 
            // TslOwner
            // 
            this.TslOwner.BackColor = System.Drawing.Color.LightBlue;
            this.TslOwner.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TslOwner.Image = ((System.Drawing.Image)(resources.GetObject("TslOwner.Image")));
            this.TslOwner.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TslOwner.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TslOwner.Name = "TslOwner";
            this.TslOwner.Size = new System.Drawing.Size(32, 35);
            this.TslOwner.Text = "toolStripButton1";
            this.TslOwner.ToolTipText = "Выборка телевизоров \r\nзаданного мастера";
            this.TslOwner.Click += new System.EventHandler(this.SelectRepairOwner_Command);
            // 
            // MniSave
            // 
            this.MniSave.Image = ((System.Drawing.Image)(resources.GetObject("MniSave.Image")));
            this.MniSave.Name = "MniSave";
            this.MniSave.Size = new System.Drawing.Size(186, 22);
            this.MniSave.Text = "Сохранить..";
            this.MniSave.Click += new System.EventHandler(this.Save_Click);
            // 
            // MniService
            // 
            this.MniService.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniServiceFont,
            this.MniServiceBackColor});
            this.MniService.Name = "MniService";
            this.MniService.Size = new System.Drawing.Size(80, 20);
            this.MniService.Text = "Сервис";
            // 
            // MniServiceFont
            // 
            this.MniServiceFont.Name = "MniServiceFont";
            this.MniServiceFont.Size = new System.Drawing.Size(186, 22);
            this.MniServiceFont.Text = "Шрифт..";
            this.MniServiceFont.Click += new System.EventHandler(this.Font_Click);
            // 
            // открытьToolStripMenuItem
            // 
            this.открытьToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("открытьToolStripMenuItem.Image")));
            this.открытьToolStripMenuItem.Name = "открытьToolStripMenuItem";
            this.открытьToolStripMenuItem.Size = new System.Drawing.Size(186, 22);
            this.открытьToolStripMenuItem.Text = "Открыть..";
            this.открытьToolStripMenuItem.Click += new System.EventHandler(this.Open_Click);
            // 
            // MniServiceBackColor
            // 
            this.MniServiceBackColor.Name = "MniServiceBackColor";
            this.MniServiceBackColor.Size = new System.Drawing.Size(186, 22);
            this.MniServiceBackColor.Text = "Цвет фона..";
            this.MniServiceBackColor.Click += new System.EventHandler(this.Color_Click);
            // 
            // CdlBackColor
            // 
            this.CdlBackColor.AnyColor = true;
            this.CdlBackColor.FullOpen = true;
            // 
            // добавитьТVToolStripMenuItem
            // 
            this.добавитьТVToolStripMenuItem.Name = "добавитьТVToolStripMenuItem";
            this.добавитьТVToolStripMenuItem.Size = new System.Drawing.Size(406, 22);
            this.добавитьТVToolStripMenuItem.Text = "Добавить ТV..";
            // 
            // MniAddTV
            // 
            this.MniAddTV.Image = ((System.Drawing.Image)(resources.GetObject("MniAddTV.Image")));
            this.MniAddTV.Name = "MniAddTV";
            this.MniAddTV.Size = new System.Drawing.Size(406, 22);
            this.MniAddTV.Text = "Добавить TV..";
            this.MniAddTV.Click += new System.EventHandler(this.AddTelevision_Command);
            // 
            // MniRemoveTV
            // 
            this.MniRemoveTV.Image = ((System.Drawing.Image)(resources.GetObject("MniRemoveTV.Image")));
            this.MniRemoveTV.Name = "MniRemoveTV";
            this.MniRemoveTV.Size = new System.Drawing.Size(406, 22);
            this.MniRemoveTV.Text = "Выдача TV владельцу..";
            this.MniRemoveTV.Click += new System.EventHandler(this.RemoveTelevision_Command);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(403, 6);
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(403, 6);
            // 
            // toolStripMenuItem4
            // 
            this.toolStripMenuItem4.Name = "toolStripMenuItem4";
            this.toolStripMenuItem4.Size = new System.Drawing.Size(183, 6);
            // 
            // TlsRemoveAtTV
            // 
            this.TlsRemoveAtTV.BackColor = System.Drawing.Color.PowderBlue;
            this.TlsRemoveAtTV.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TlsRemoveAtTV.Image = ((System.Drawing.Image)(resources.GetObject("TlsRemoveAtTV.Image")));
            this.TlsRemoveAtTV.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TlsRemoveAtTV.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TlsRemoveAtTV.Name = "TlsRemoveAtTV";
            this.TlsRemoveAtTV.Size = new System.Drawing.Size(32, 35);
            this.TlsRemoveAtTV.Text = "toolStripButton1";
            this.TlsRemoveAtTV.ToolTipText = "Выдача телевизора владельцу\r\nпосле ремонта";
            this.TlsRemoveAtTV.Click += new System.EventHandler(this.RemoveTelevision_Command);
            // 
            // TlsSPrice
            // 
            this.TlsSPrice.BackColor = System.Drawing.Color.LightCyan;
            this.TlsSPrice.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TlsSPrice.Image = ((System.Drawing.Image)(resources.GetObject("TlsSPrice.Image")));
            this.TlsSPrice.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TlsSPrice.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TlsSPrice.Name = "TlsSPrice";
            this.TlsSPrice.Size = new System.Drawing.Size(32, 35);
            this.TlsSPrice.Text = "toolStripButton1";
            this.TlsSPrice.ToolTipText = "Сортировка коллекции по\r\nстоимости ремонта";
            this.TlsSPrice.Click += new System.EventHandler(this.OrderbyPriceRepair_Command);
            // 
            // MniSortPrice
            // 
            this.MniSortPrice.Image = ((System.Drawing.Image)(resources.GetObject("MniSortPrice.Image")));
            this.MniSortPrice.Name = "MniSortPrice";
            this.MniSortPrice.Size = new System.Drawing.Size(276, 22);
            this.MniSortPrice.Text = "По стоимости ремонта";
            this.MniSortPrice.Click += new System.EventHandler(this.OrderbyPriceRepair_Command);
            // 
            // CmnMain
            // 
            this.CmnMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.CmnExit,
            this.CmnAboutProgram});
            this.CmnMain.Name = "CmnMain";
            this.CmnMain.Size = new System.Drawing.Size(156, 48);
            // 
            // CmnExit
            // 
            this.CmnExit.Image = ((System.Drawing.Image)(resources.GetObject("CmnExit.Image")));
            this.CmnExit.Name = "CmnExit";
            this.CmnExit.Size = new System.Drawing.Size(155, 22);
            this.CmnExit.Text = "Выход";
            this.CmnExit.Click += new System.EventHandler(this.Exit_Command);
            // 
            // CmnAboutProgram
            // 
            this.CmnAboutProgram.Image = ((System.Drawing.Image)(resources.GetObject("CmnAboutProgram.Image")));
            this.CmnAboutProgram.Name = "CmnAboutProgram";
            this.CmnAboutProgram.Size = new System.Drawing.Size(155, 22);
            this.CmnAboutProgram.Text = "О программе..";
            this.CmnAboutProgram.Click += new System.EventHandler(this.About_Command);
            // 
            // CmnProgram
            // 
            this.CmnProgram.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.CmnNewColl,
            this.toolStripMenuItem5,
            this.CmnSort,
            this.toolStripMenuItem6,
            this.CmnAddTV,
            this.CmnRemoveAtTV,
            this.toolStripMenuItem7,
            this.CmnEditTV,
            this.CmnEditRepairShop,
            this.toolStripMenuItem8,
            this.CmnSelect,
            this.toolStripMenuItem9,
            this.CmnProgramExit});
            this.CmnProgram.Name = "CmnProgram";
            this.CmnProgram.Size = new System.Drawing.Size(273, 210);
            // 
            // CmnNewColl
            // 
            this.CmnNewColl.Image = ((System.Drawing.Image)(resources.GetObject("CmnNewColl.Image")));
            this.CmnNewColl.Name = "CmnNewColl";
            this.CmnNewColl.Size = new System.Drawing.Size(272, 22);
            this.CmnNewColl.Text = "Новая коллекция";
            this.CmnNewColl.Click += new System.EventHandler(this.NewCollection_Command);
            // 
            // toolStripMenuItem5
            // 
            this.toolStripMenuItem5.Name = "toolStripMenuItem5";
            this.toolStripMenuItem5.Size = new System.Drawing.Size(269, 6);
            // 
            // CmnSort
            // 
            this.CmnSort.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.CmnSortModel,
            this.CmnSortDiagonal,
            this.CmnSortMaster,
            this.CmnSortOwner,
            this.CmnSortPrice});
            this.CmnSort.Image = ((System.Drawing.Image)(resources.GetObject("CmnSort.Image")));
            this.CmnSort.Name = "CmnSort";
            this.CmnSort.Size = new System.Drawing.Size(272, 22);
            this.CmnSort.Text = "Сортировка";
            // 
            // CmnSortModel
            // 
            this.CmnSortModel.Name = "CmnSortModel";
            this.CmnSortModel.Size = new System.Drawing.Size(200, 22);
            this.CmnSortModel.Text = "по модели TV";
            this.CmnSortModel.Click += new System.EventHandler(this.OrderbyTvBrand_Command);
            // 
            // CmnSortDiagonal
            // 
            this.CmnSortDiagonal.Name = "CmnSortDiagonal";
            this.CmnSortDiagonal.Size = new System.Drawing.Size(200, 22);
            this.CmnSortDiagonal.Text = "по диагонали экрана";
            this.CmnSortDiagonal.Click += new System.EventHandler(this.OrderbyDiagonal_Command);
            // 
            // CmnSortMaster
            // 
            this.CmnSortMaster.Name = "CmnSortMaster";
            this.CmnSortMaster.Size = new System.Drawing.Size(200, 22);
            this.CmnSortMaster.Text = "по ФИО мастера";
            this.CmnSortMaster.Click += new System.EventHandler(this.OrderbyFullnameMaster_Command);
            // 
            // CmnSortOwner
            // 
            this.CmnSortOwner.Name = "CmnSortOwner";
            this.CmnSortOwner.Size = new System.Drawing.Size(200, 22);
            this.CmnSortOwner.Text = "по ФИО владельца";
            this.CmnSortOwner.Click += new System.EventHandler(this.OrderbyFullnameOwner_Command);
            // 
            // CmnSortPrice
            // 
            this.CmnSortPrice.Name = "CmnSortPrice";
            this.CmnSortPrice.Size = new System.Drawing.Size(200, 22);
            this.CmnSortPrice.Text = "по стоимости ремонта";
            this.CmnSortPrice.Click += new System.EventHandler(this.OrderbyPriceRepair_Command);
            // 
            // toolStripMenuItem6
            // 
            this.toolStripMenuItem6.Name = "toolStripMenuItem6";
            this.toolStripMenuItem6.Size = new System.Drawing.Size(269, 6);
            // 
            // CmnAddTV
            // 
            this.CmnAddTV.Image = ((System.Drawing.Image)(resources.GetObject("CmnAddTV.Image")));
            this.CmnAddTV.Name = "CmnAddTV";
            this.CmnAddTV.Size = new System.Drawing.Size(272, 22);
            this.CmnAddTV.Text = "Добавить телевизор";
            this.CmnAddTV.Click += new System.EventHandler(this.AddTelevision_Command);
            // 
            // CmnRemoveAtTV
            // 
            this.CmnRemoveAtTV.Image = ((System.Drawing.Image)(resources.GetObject("CmnRemoveAtTV.Image")));
            this.CmnRemoveAtTV.Name = "CmnRemoveAtTV";
            this.CmnRemoveAtTV.Size = new System.Drawing.Size(272, 22);
            this.CmnRemoveAtTV.Text = "Выдать телевизор";
            this.CmnRemoveAtTV.Click += new System.EventHandler(this.RemoveTelevision_Command);
            // 
            // toolStripMenuItem7
            // 
            this.toolStripMenuItem7.Name = "toolStripMenuItem7";
            this.toolStripMenuItem7.Size = new System.Drawing.Size(269, 6);
            // 
            // CmnEditTV
            // 
            this.CmnEditTV.Image = ((System.Drawing.Image)(resources.GetObject("CmnEditTV.Image")));
            this.CmnEditTV.Name = "CmnEditTV";
            this.CmnEditTV.Size = new System.Drawing.Size(272, 22);
            this.CmnEditTV.Text = "Редактировать телевизор..";
            this.CmnEditTV.Click += new System.EventHandler(this.TVEdit_Command);
            // 
            // CmnEditRepairShop
            // 
            this.CmnEditRepairShop.Image = ((System.Drawing.Image)(resources.GetObject("CmnEditRepairShop.Image")));
            this.CmnEditRepairShop.Name = "CmnEditRepairShop";
            this.CmnEditRepairShop.Size = new System.Drawing.Size(272, 22);
            this.CmnEditRepairShop.Text = "Редактировать данные мастерской..";
            this.CmnEditRepairShop.Click += new System.EventHandler(this.RepairShopEdit_Command);
            // 
            // toolStripMenuItem8
            // 
            this.toolStripMenuItem8.Name = "toolStripMenuItem8";
            this.toolStripMenuItem8.Size = new System.Drawing.Size(269, 6);
            // 
            // CmnSelect
            // 
            this.CmnSelect.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.CmnSelectMinPrice,
            this.CmnSelectMaster,
            this.CmnSelectDiagonal,
            this.CmnSelectOwner});
            this.CmnSelect.Image = ((System.Drawing.Image)(resources.GetObject("CmnSelect.Image")));
            this.CmnSelect.Name = "CmnSelect";
            this.CmnSelect.Size = new System.Drawing.Size(272, 22);
            this.CmnSelect.Text = "Выбрать";
            // 
            // CmnSelectMinPrice
            // 
            this.CmnSelectMinPrice.Name = "CmnSelectMinPrice";
            this.CmnSelectMinPrice.Size = new System.Drawing.Size(304, 22);
            this.CmnSelectMinPrice.Text = "TV с минимальной стоимостью ремонта";
            this.CmnSelectMinPrice.Click += new System.EventHandler(this.SelectMinPrice_Command);
            // 
            // CmnSelectMaster
            // 
            this.CmnSelectMaster.Name = "CmnSelectMaster";
            this.CmnSelectMaster.Size = new System.Drawing.Size(304, 22);
            this.CmnSelectMaster.Text = "TV ремонтируемы выбранным мастером";
            this.CmnSelectMaster.Click += new System.EventHandler(this.SelectRepairMaster_Command);
            // 
            // CmnSelectDiagonal
            // 
            this.CmnSelectDiagonal.Name = "CmnSelectDiagonal";
            this.CmnSelectDiagonal.Size = new System.Drawing.Size(304, 22);
            this.CmnSelectDiagonal.Text = "TV с заданной диагональю";
            this.CmnSelectDiagonal.Click += new System.EventHandler(this.SelectDiagonal_Command);
            // 
            // CmnSelectOwner
            // 
            this.CmnSelectOwner.Name = "CmnSelectOwner";
            this.CmnSelectOwner.Size = new System.Drawing.Size(304, 22);
            this.CmnSelectOwner.Text = "TV заданного владельца";
            this.CmnSelectOwner.Click += new System.EventHandler(this.SelectRepairOwner_Command);
            // 
            // toolStripMenuItem9
            // 
            this.toolStripMenuItem9.Name = "toolStripMenuItem9";
            this.toolStripMenuItem9.Size = new System.Drawing.Size(269, 6);
            // 
            // CmnProgramExit
            // 
            this.CmnProgramExit.Image = ((System.Drawing.Image)(resources.GetObject("CmnProgramExit.Image")));
            this.CmnProgramExit.Name = "CmnProgramExit";
            this.CmnProgramExit.Size = new System.Drawing.Size(272, 22);
            this.CmnProgramExit.Text = "Выход";
            this.CmnProgramExit.Click += new System.EventHandler(this.Exit_Command);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1006, 561);
            this.ContextMenuStrip = this.CmnMain;
            this.Controls.Add(this.LblTelevisions);
            this.Controls.Add(this.LbxTelevisions);
            this.Controls.Add(this.StsMain);
            this.Controls.Add(this.TsbMain);
            this.Controls.Add(this.MnuMain);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.MnuMain;
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(1100, 600);
            this.MinimumSize = new System.Drawing.Size(1022, 566);
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Домашнее задание №9";
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.MnuMain.ResumeLayout(false);
            this.MnuMain.PerformLayout();
            this.TsbMain.ResumeLayout(false);
            this.TsbMain.PerformLayout();
            this.StsMain.ResumeLayout(false);
            this.StsMain.PerformLayout();
            this.CmnMain.ResumeLayout(false);
            this.CmnProgram.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip MnuMain;
        private System.Windows.Forms.ToolStripMenuItem MniFile;
        private System.Windows.Forms.ToolStripMenuItem MniExit;
        private System.Windows.Forms.ToolStrip TsbMain;
        private System.Windows.Forms.StatusStrip StsMain;
        private System.Windows.Forms.ToolStripStatusLabel StlMain;
        private System.Windows.Forms.ToolStripMenuItem MniEdit;
        private System.Windows.Forms.ToolStripMenuItem MniEditNewCollection;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem MniEditingTV;
        private System.Windows.Forms.ToolStripMenuItem MniEditingMastersk;
        private System.Windows.Forms.ToolStripButton TlsNew;
        private System.Windows.Forms.ToolStripButton TstAdd;
        private System.Windows.Forms.ToolStripButton TlsSort;
        private System.Windows.Forms.ListBox LbxTelevisions;
        private System.Windows.Forms.Label LblTelevisions;
        private System.Windows.Forms.ToolStripMenuItem MniSort;
        private System.Windows.Forms.ToolStripMenuItem MniSortBrend;
        private System.Windows.Forms.ToolStripMenuItem MniSortDiag;
        private System.Windows.Forms.ToolStripMenuItem MniSortMaster;
        private System.Windows.Forms.ToolStripMenuItem MniSortOwner;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripButton TlsSortD;
        private System.Windows.Forms.ToolStripButton TlsSortFM;
        private System.Windows.Forms.ToolStripButton TlsTO;
        private System.Windows.Forms.ToolStripMenuItem MniSample;
        private System.Windows.Forms.ToolStripMenuItem MniSampleMinCost;
        private System.Windows.Forms.ToolStripMenuItem MniSampleMaster;
        private System.Windows.Forms.ToolStripMenuItem MniSampleDiagonal;
        private System.Windows.Forms.ToolStripMenuItem MniHelp;
        private System.Windows.Forms.ToolStripMenuItem MniHelpAbout;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripButton TsbExit;
        private System.Windows.Forms.ToolStripButton TslHelpAbout;
        private System.Windows.Forms.ToolStripButton TslRedTv;
        private System.Windows.Forms.ToolStripButton TlsTvRed;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripButton TslMinPrice;
        private System.Windows.Forms.ToolStripButton TslMaster;
        private System.Windows.Forms.ToolStripButton TslDiagonal;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.OpenFileDialog OfdMain;
        private System.Windows.Forms.ToolStripMenuItem tVЗаданногоВладельцаToolStripMenuItem;
        private System.Windows.Forms.ToolStripButton TslOwner;
        private System.Windows.Forms.SaveFileDialog SfdMain;
        private System.Windows.Forms.ToolStripMenuItem MniSave;
        private System.Windows.Forms.ToolStripMenuItem MniService;
        private System.Windows.Forms.ToolStripMenuItem MniServiceFont;
        private System.Windows.Forms.ToolStripMenuItem открытьToolStripMenuItem;
        private System.Windows.Forms.FontDialog FdlTextFont;
        private System.Windows.Forms.ToolStripMenuItem MniServiceBackColor;
        private System.Windows.Forms.ColorDialog CdlBackColor;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem4;
        private System.Windows.Forms.ToolStripMenuItem добавитьТVToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem MniAddTV;
        private System.Windows.Forms.ToolStripMenuItem MniRemoveTV;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem3;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem2;
        private System.Windows.Forms.ToolStripButton TlsRemoveAtTV;
        private System.Windows.Forms.ToolStripButton TlsSPrice;
        private System.Windows.Forms.ToolStripMenuItem MniSortPrice;
        private System.Windows.Forms.ContextMenuStrip CmnMain;
        private System.Windows.Forms.ToolStripMenuItem CmnExit;
        private System.Windows.Forms.ToolStripMenuItem CmnAboutProgram;
        private System.Windows.Forms.ContextMenuStrip CmnProgram;
        private System.Windows.Forms.ToolStripMenuItem CmnNewColl;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem5;
        private System.Windows.Forms.ToolStripMenuItem CmnSort;
        private System.Windows.Forms.ToolStripMenuItem CmnSortModel;
        private System.Windows.Forms.ToolStripMenuItem CmnSortDiagonal;
        private System.Windows.Forms.ToolStripMenuItem CmnSortMaster;
        private System.Windows.Forms.ToolStripMenuItem CmnSortOwner;
        private System.Windows.Forms.ToolStripMenuItem CmnSortPrice;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem6;
        private System.Windows.Forms.ToolStripMenuItem CmnAddTV;
        private System.Windows.Forms.ToolStripMenuItem CmnRemoveAtTV;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem7;
        private System.Windows.Forms.ToolStripMenuItem CmnEditTV;
        private System.Windows.Forms.ToolStripMenuItem CmnEditRepairShop;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem8;
        private System.Windows.Forms.ToolStripMenuItem CmnSelect;
        private System.Windows.Forms.ToolStripMenuItem CmnSelectMinPrice;
        private System.Windows.Forms.ToolStripMenuItem CmnSelectMaster;
        private System.Windows.Forms.ToolStripMenuItem CmnSelectDiagonal;
        private System.Windows.Forms.ToolStripMenuItem CmnSelectOwner;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem9;
        private System.Windows.Forms.ToolStripMenuItem CmnProgramExit;
    }
}

