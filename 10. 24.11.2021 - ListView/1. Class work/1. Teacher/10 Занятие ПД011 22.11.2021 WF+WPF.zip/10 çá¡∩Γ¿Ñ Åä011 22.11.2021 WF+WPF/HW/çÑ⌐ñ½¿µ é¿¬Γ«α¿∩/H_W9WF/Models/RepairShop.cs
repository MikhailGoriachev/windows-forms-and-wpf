﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Json;
using System.Text;
using System.Threading.Tasks;

namespace H_W9WF.Models
{
    /// <summary>
    /// Класс описывающий RepairShop (
    /// *коллекция Television,
    /// *название ремонтной мастерской,
    /// *адрес ремонтной мастерской).
    /// Обработка коллекции телевизоров по заданию:
    /// •	Начальное формирование данных ремонтной
    /// мастерской(коллекция телевизоров от 12 до 15 штук)
    /// •	Добавление телевизора в коллекцию
    /// •	Редактирование выбранного телевизора в отдельной форме
    /// •	Редактирование данных ремонтной мастерской
    /// • Упорядочивание коллекции телевизоров
    /// o   По производителю и типу
    /// o   По убыванию диагонали экрана
    /// o   По мастеру, выполняющему ремонт
    /// o   По владельцу телевизора
    /// o	По стоимости ремонта
    /// • Выборка и вывод в отдельной форме коллекции
    /// телевизоров с минимальной стоимостью ремонта
    /// • Выборка и вывод в отдельной форме коллекции 
    /// телевизоров, ремонтируемых выбранным мастером
    /// • Выборка и вывод в отдельной форме коллекции
    /// телевизоров, с заданной диагональю экрана
    /// • Выборка и вывод в отдельной форме коллекции телевизоров,
    /// заданного владельцa
    /// </summary>
    [DataContract]  // для JSON
    public class RepairShop
    {
        [DataMember]
        // ссылка на коллекцию телевизоров
        private List<Television> _televisions;
        [DataMember]
        public List<Television> Televisions => _televisions;

        // название мастерской
        private string _name;
        [DataMember]
        public string Name {
            get => _name;
            set {
                if (string.IsNullOrWhiteSpace(value))
                    throw new ArgumentException("Television. Пустое название мастерской недопустимо");

                _name = value;
            } // set
        } // Name

        // адрес мастерской
        private string _address;
        [DataMember]
        public string Address {
            get => _address;
            set {
                if (string.IsNullOrWhiteSpace(value))
                    throw new ArgumentException("Television. Пустой адрес мастерской недопустим");

                _address = value;
            } // set
        } // Address

        public RepairShop() : this("Сервисный центр IQS", "ул. Университетская, 75", new List<Television>())
        {
            Inizialize();
        }

        public RepairShop(string name, string address, List<Television> televisions)
        {
            _name        = name;
            _address     = address;
            _televisions = televisions;
        }

        // количестово телевизоров в коллекции
        public int Count => _televisions.Count;

        public void Inizialize() {
            _televisions.Clear();

            _televisions = new List<Television>(new[] {
                new Television{TvBrand = "Samsung", Diagonal = 54, TvDefect = "Повреждение лампы матрицы", FullnameMaster = "Тюрин О.А.",   FullnameOwner = "Митин В.И.",  CostRepair = 970},
                new Television{TvBrand = "LG",      Diagonal = 24, TvDefect = "Проблемы со звуком",        FullnameMaster = "Воронин Л.А.", FullnameOwner = "Зорина В.Ю.", CostRepair = 580},
                new Television{TvBrand = "Philips", Diagonal = 54, TvDefect = "Поломка видеопроцессора",   FullnameMaster = "Тюрин О.А.",   FullnameOwner = "Жуков О.И.",  CostRepair = 1200},
                new Television{TvBrand = "TCL",     Diagonal = 48, TvDefect = "Неисправный пульт упр-ния", FullnameMaster = "Лужко С.Л.",   FullnameOwner = "Зубков В.Р.", CostRepair = 300},
                new Television{TvBrand = "Samsung", Diagonal = 64, TvDefect = "Поломка видеопроцессора",   FullnameMaster = "Воронин Л.А.", FullnameOwner = "Прохоров К.И.",CostRepair = 1200},
                new Television{TvBrand = "Sony",    Diagonal = 54, TvDefect = "Неисправный пульт упр-ния", FullnameMaster = "Лужко С.Л.",   FullnameOwner = "Якубин В.С.", CostRepair = 300},
                new Television{TvBrand = "Philips", Diagonal = 64, TvDefect = "Поломка ресивера",          FullnameMaster = "Ковалёв М.А.", FullnameOwner = "Дудник Д.И.", CostRepair = 300},
                new Television{TvBrand = "Hisense", Diagonal = 48, TvDefect = "Поломка видеопроцессора",   FullnameMaster = "Воронин Л.А.", FullnameOwner = "Павлова В.Л.",CostRepair = 1200},
                new Television{TvBrand = "LG",      Diagonal = 64, TvDefect = "Вертикальные полосы",       FullnameMaster = "Ковалёв М.А.", FullnameOwner = "Кулик О.И.",  CostRepair = 1000},
                new Television{TvBrand = "TCL",     Diagonal = 54, TvDefect = "Поломка ресивера",          FullnameMaster = "Лужко С.Л.",   FullnameOwner = "Ящук В.П.",   CostRepair = 300}
            });

        }// Inizialize


        // сериализация в JSON формате
        public void SerializationJson(string fileName)
        {     // форматтеру передаём тип
            DataContractJsonSerializer jsonFormatter = new DataContractJsonSerializer(typeof(List<Television>));

            using (FileStream fs = new FileStream(fileName, FileMode.Create))
            {
                jsonFormatter.WriteObject(fs, _televisions);
            } // using

        }// SerializationJson

        // десериализация в JSON формате
        public void DeserializeJson(string fileName)
        {    // форматтеру передаём тип
            DataContractJsonSerializer jsonFormatter = new DataContractJsonSerializer(typeof(List<Television>));
            using (FileStream fs = new FileStream(fileName, FileMode.OpenOrCreate))
            {

                _televisions = (List<Television>)jsonFormatter.ReadObject(fs);
            } // using

        }// DeserializeJson

        // добавление телевизора в коллекцию
        public void AddTelevizion(Television tv) => _televisions.Add(tv);

        // удаление выбранного телевизора
        public void RemoveAt(int index) => _televisions.RemoveAt(index);


        // сортировка по производителю и типу
        public void OrderbyTvBrand() =>
            _televisions.Sort((tv1, tv2) => tv1.TvBrand.CompareTo(tv2.TvBrand));

        // сортировка по убыванию диагонали экрана
        public void OrderbyDiagonal() =>
            _televisions.Sort((tv1, tv2) => tv2.Diagonal.CompareTo(tv1.Diagonal));

        // сортировка по мастеру, выполняющему ремонт
        public void OrderbyFullnameMaster() =>
            _televisions.Sort((tv1, tv2) => tv1.FullnameMaster.CompareTo(tv2.FullnameMaster));

        // сортировка по владельцу телевизора
        public void OrderbyFullnameOwner() =>
            _televisions.Sort((tv1, tv2) => tv1.FullnameOwner.CompareTo(tv2.FullnameOwner));

        // сортировка по стоимости ремонта
        public void OrderbyPrice() =>
            _televisions.Sort((tv1, tv2) => tv1.CostRepair.CompareTo(tv2.CostRepair));

        // список фамилий мастеров
        public List<string> GetMasters => _televisions.Select(tv => tv.FullnameMaster).Distinct().ToList();

        // список фамилий владельцев
        public List<string> GetOwners => _televisions.Select(tv => tv.FullnameOwner).Distinct().ToList();
        // список диагоналей
        public List<string> GetDiagonals => _televisions.Select(tv => tv.Diagonal.ToString()).Distinct().ToList();

        // список телевизоров, ремонт которых выполняет определенный мастер
        public List<Television> GetTVsEqualsRepairer(string master) =>
            _televisions.Where(tv => tv.FullnameMaster == master).ToList();

        // список телевизоров, ремонт которых выполняет определенный мастер
        public List<Television> GetTVsEqualsOwner(string owner) =>
            _televisions.Where(tv => tv.FullnameOwner == owner).ToList();

        // список телевизоров с определенной диагональю
        public List<Television> GetTVsEqualsDiagonal(int diagonal) =>
            _televisions.Where(tv => tv.Diagonal == diagonal).ToList();

        // список телевизоров с минимальной стоимостью ремонта
        public List<Television> GetTVsEqualsMinCost()
        {
            int minPrice = _televisions.Min(tv => tv.CostRepair);

            return _televisions.Where(tv => tv.CostRepair == minPrice).ToList();
        }// GetTVsEqualsMinCost

        // индексатор
        public Television this[int index]
        {
            get
            {
                if (index < 0 || index > Count)
                    throw new IndexOutOfRangeException("Попытка доступа к элементу вне диапазона");
                return _televisions[index];
            }
            set
            {
                if (index < 0 || index > Count)
                    throw new IndexOutOfRangeException("Попытка доступа к элементу вне диапазона");

                _televisions[index] = value;
            }
        }


    }// class RepairShop
}
