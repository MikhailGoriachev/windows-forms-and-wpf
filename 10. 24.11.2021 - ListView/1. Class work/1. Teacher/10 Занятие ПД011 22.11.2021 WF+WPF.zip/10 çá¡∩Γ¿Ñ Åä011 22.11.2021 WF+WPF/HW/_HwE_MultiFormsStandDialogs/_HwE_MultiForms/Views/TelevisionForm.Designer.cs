﻿
namespace _HwE_MultiForms.Views
{
    partial class TelevisionForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.LblOwner = new System.Windows.Forms.Label();
            this.CbxBrandModel = new System.Windows.Forms.ComboBox();
            this.LblBrandModel = new System.Windows.Forms.Label();
            this.CbxDiagonal = new System.Windows.Forms.ComboBox();
            this.LblDiagonal = new System.Windows.Forms.Label();
            this.LblDefectDescription = new System.Windows.Forms.Label();
            this.LblArtisan = new System.Windows.Forms.Label();
            this.LblPrice = new System.Windows.Forms.Label();
            this.NudPrice = new System.Windows.Forms.NumericUpDown();
            this.BtnOk = new System.Windows.Forms.Button();
            this.BtnCancel = new System.Windows.Forms.Button();
            this.TxbOwner = new System.Windows.Forms.TextBox();
            this.TxbDefectDescription = new System.Windows.Forms.TextBox();
            this.TxbArtisan = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.NudPrice)).BeginInit();
            this.SuspendLayout();
            // 
            // LblOwner
            // 
            this.LblOwner.AutoSize = true;
            this.LblOwner.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblOwner.Location = new System.Drawing.Point(24, 32);
            this.LblOwner.Name = "LblOwner";
            this.LblOwner.Size = new System.Drawing.Size(81, 21);
            this.LblOwner.TabIndex = 6;
            this.LblOwner.Text = "Владелец:";
            // 
            // CbxBrandModel
            // 
            this.CbxBrandModel.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CbxBrandModel.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.CbxBrandModel.FormattingEnabled = true;
            this.CbxBrandModel.Location = new System.Drawing.Point(432, 28);
            this.CbxBrandModel.Name = "CbxBrandModel";
            this.CbxBrandModel.Size = new System.Drawing.Size(200, 29);
            this.CbxBrandModel.TabIndex = 2;
            // 
            // LblBrandModel
            // 
            this.LblBrandModel.AutoSize = true;
            this.LblBrandModel.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblBrandModel.Location = new System.Drawing.Point(344, 32);
            this.LblBrandModel.Name = "LblBrandModel";
            this.LblBrandModel.Size = new System.Drawing.Size(87, 21);
            this.LblBrandModel.TabIndex = 8;
            this.LblBrandModel.Text = "Телевизор:";
            // 
            // CbxDiagonal
            // 
            this.CbxDiagonal.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CbxDiagonal.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.CbxDiagonal.FormattingEnabled = true;
            this.CbxDiagonal.Location = new System.Drawing.Point(760, 28);
            this.CbxDiagonal.Name = "CbxDiagonal";
            this.CbxDiagonal.Size = new System.Drawing.Size(96, 29);
            this.CbxDiagonal.TabIndex = 3;
            // 
            // LblDiagonal
            // 
            this.LblDiagonal.AutoSize = true;
            this.LblDiagonal.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblDiagonal.Location = new System.Drawing.Point(664, 32);
            this.LblDiagonal.Name = "LblDiagonal";
            this.LblDiagonal.Size = new System.Drawing.Size(89, 21);
            this.LblDiagonal.TabIndex = 10;
            this.LblDiagonal.Text = "Диагональ:";
            // 
            // LblDefectDescription
            // 
            this.LblDefectDescription.AutoSize = true;
            this.LblDefectDescription.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblDefectDescription.Location = new System.Drawing.Point(24, 72);
            this.LblDefectDescription.Name = "LblDefectDescription";
            this.LblDefectDescription.Size = new System.Drawing.Size(147, 21);
            this.LblDefectDescription.TabIndex = 12;
            this.LblDefectDescription.Text = "Описание дефекта:";
            // 
            // LblArtisan
            // 
            this.LblArtisan.AutoSize = true;
            this.LblArtisan.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblArtisan.Location = new System.Drawing.Point(24, 224);
            this.LblArtisan.Name = "LblArtisan";
            this.LblArtisan.Size = new System.Drawing.Size(66, 21);
            this.LblArtisan.TabIndex = 14;
            this.LblArtisan.Text = "Мастер:";
            // 
            // LblPrice
            // 
            this.LblPrice.AutoSize = true;
            this.LblPrice.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblPrice.Location = new System.Drawing.Point(440, 224);
            this.LblPrice.Name = "LblPrice";
            this.LblPrice.Size = new System.Drawing.Size(288, 21);
            this.LblPrice.TabIndex = 16;
            this.LblPrice.Text = "Ориентировочная стоимость ремонта:";
            // 
            // NudPrice
            // 
            this.NudPrice.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.NudPrice.Location = new System.Drawing.Point(736, 220);
            this.NudPrice.Maximum = new decimal(new int[] {
            100000000,
            0,
            0,
            0});
            this.NudPrice.Name = "NudPrice";
            this.NudPrice.Size = new System.Drawing.Size(120, 29);
            this.NudPrice.TabIndex = 6;
            // 
            // BtnOk
            // 
            this.BtnOk.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.BtnOk.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.BtnOk.Location = new System.Drawing.Point(544, 288);
            this.BtnOk.Name = "BtnOk";
            this.BtnOk.Size = new System.Drawing.Size(136, 40);
            this.BtnOk.TabIndex = 7;
            this.BtnOk.Text = "OK";
            this.BtnOk.UseVisualStyleBackColor = true;
            // 
            // BtnCancel
            // 
            this.BtnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.BtnCancel.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.BtnCancel.Location = new System.Drawing.Point(720, 288);
            this.BtnCancel.Name = "BtnCancel";
            this.BtnCancel.Size = new System.Drawing.Size(136, 40);
            this.BtnCancel.TabIndex = 8;
            this.BtnCancel.Text = "Отмена";
            this.BtnCancel.UseVisualStyleBackColor = true;
            // 
            // TxbOwner
            // 
            this.TxbOwner.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.TxbOwner.Location = new System.Drawing.Point(112, 28);
            this.TxbOwner.Name = "TxbOwner";
            this.TxbOwner.Size = new System.Drawing.Size(208, 29);
            this.TxbOwner.TabIndex = 1;
            // 
            // TxbDefectDescription
            // 
            this.TxbDefectDescription.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.TxbDefectDescription.Location = new System.Drawing.Point(24, 96);
            this.TxbDefectDescription.Multiline = true;
            this.TxbDefectDescription.Name = "TxbDefectDescription";
            this.TxbDefectDescription.Size = new System.Drawing.Size(840, 88);
            this.TxbDefectDescription.TabIndex = 4;
            // 
            // TxbArtisan
            // 
            this.TxbArtisan.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.TxbArtisan.Location = new System.Drawing.Point(96, 220);
            this.TxbArtisan.Name = "TxbArtisan";
            this.TxbArtisan.Size = new System.Drawing.Size(208, 29);
            this.TxbArtisan.TabIndex = 5;
            // 
            // TelevisionForm
            // 
            this.AcceptButton = this.BtnOk;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Lavender;
            this.CancelButton = this.BtnCancel;
            this.ClientSize = new System.Drawing.Size(890, 351);
            this.Controls.Add(this.TxbArtisan);
            this.Controls.Add(this.TxbDefectDescription);
            this.Controls.Add(this.TxbOwner);
            this.Controls.Add(this.BtnCancel);
            this.Controls.Add(this.BtnOk);
            this.Controls.Add(this.NudPrice);
            this.Controls.Add(this.LblPrice);
            this.Controls.Add(this.LblArtisan);
            this.Controls.Add(this.LblDefectDescription);
            this.Controls.Add(this.CbxDiagonal);
            this.Controls.Add(this.LblDiagonal);
            this.Controls.Add(this.CbxBrandModel);
            this.Controls.Add(this.LblBrandModel);
            this.Controls.Add(this.LblOwner);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "TelevisionForm";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "TelevisionForm";
            ((System.ComponentModel.ISupportInitialize)(this.NudPrice)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label LblOwner;
        private System.Windows.Forms.ComboBox CbxBrandModel;
        private System.Windows.Forms.Label LblBrandModel;
        private System.Windows.Forms.ComboBox CbxDiagonal;
        private System.Windows.Forms.Label LblDiagonal;
        private System.Windows.Forms.Label LblDefectDescription;
        private System.Windows.Forms.Label LblArtisan;
        private System.Windows.Forms.Label LblPrice;
        private System.Windows.Forms.NumericUpDown NudPrice;
        private System.Windows.Forms.Button BtnOk;
        private System.Windows.Forms.Button BtnCancel;
        private System.Windows.Forms.TextBox TxbOwner;
        private System.Windows.Forms.TextBox TxbDefectDescription;
        private System.Windows.Forms.TextBox TxbArtisan;
    }
}