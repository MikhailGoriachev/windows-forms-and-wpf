﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.SymbolStore;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using _HwE_MultiForms.Models;

namespace _HwE_MultiForms.Views
{
    // форма редактирования названия и адреса ремонтной мастерской
    public partial class RepairShopForm : Form
    {
        // данные для редактирования, т.к. их мало, отдельную модель не строим

        // название мастерской
        public string Title { get; set; }
        
        // адрес мастерской
        public string Address { get; set; }


        // конструктор по умолчанию, вызывается при создании новой
        // мастерской по ремонту телевизоров
        public RepairShopForm() {
            InitializeComponent();
            Text = "Параметры новой мастерской";

            // снять выделение текста
            TxbRepairShopTitle.SelectionStart = 0;
            TxbRepairShopTitle.SelectionLength = 0;
        } // RepairShopForm


        // получить название формы - редактирование или ввод данных и объект для
        // редактирования или ввода новых данных
        public RepairShopForm(string title, string address) {
            InitializeComponent();

            // установить заголовок формы
            Text = "Редактирование параметров ремонтной мастерской";

            // получить объекы для редактирования
            // записать данные объекта в элементы формы для редактирования
            TxbRepairShopTitle.Text = Title = title;
            TxbRepairShopAddress.Text = Address = address;

            // снять выделение текста
            TxbRepairShopTitle.SelectionStart = 0;
            TxbRepairShopTitle.SelectionLength = 0;
        } // RepairShopForm


        // Клик по кнопке ОК - собрать данные в поля объекта
        private void BtnOK_Click(object sender, EventArgs e) {
            Title = TxbRepairShopTitle.Text;
            Address = TxbRepairShopAddress.Text;
        } // BtnOK_Click
    } // class RepairShopForm
}
