﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using _HwE_MultiForms.Helpers;

namespace _HwE_MultiForms.Views
{
    public partial class DiagonalChoiceForm : Form
    {

        public DiagonalChoiceForm(){
            InitializeComponent();

            // Для комбобокса выбора диагонали загрузить массив данных
            Array.ForEach(Utils.Diagonals, d => CbxDiagonal.Items.Add($"{d:f1}\""));
            CbxDiagonal.Text = CbxDiagonal.Items[0].ToString();
        } // ArtisanChoiceForm

        // вернуть выбранную диагональ
        public string Diagonal => CbxDiagonal.Text;
    } // class DiagonalChoiceForm
}
