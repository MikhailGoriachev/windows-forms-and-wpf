﻿
namespace _HwE_MultiForms.Views
{
    partial class RepairShopForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.BtnCancel = new System.Windows.Forms.Button();
            this.BtnOk = new System.Windows.Forms.Button();
            this.LblRepairShopTitle = new System.Windows.Forms.Label();
            this.LblRepairShopAddress = new System.Windows.Forms.Label();
            this.TxbRepairShopTitle = new System.Windows.Forms.TextBox();
            this.TxbRepairShopAddress = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // BtnCancel
            // 
            this.BtnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.BtnCancel.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.BtnCancel.Location = new System.Drawing.Point(384, 168);
            this.BtnCancel.Name = "BtnCancel";
            this.BtnCancel.Size = new System.Drawing.Size(136, 40);
            this.BtnCancel.TabIndex = 4;
            this.BtnCancel.Text = "Отмена";
            this.BtnCancel.UseVisualStyleBackColor = true;
            // 
            // BtnOk
            // 
            this.BtnOk.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.BtnOk.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.BtnOk.Location = new System.Drawing.Point(232, 168);
            this.BtnOk.Name = "BtnOk";
            this.BtnOk.Size = new System.Drawing.Size(136, 40);
            this.BtnOk.TabIndex = 3;
            this.BtnOk.Text = "ОК";
            this.BtnOk.UseVisualStyleBackColor = true;
            this.BtnOk.Click += new System.EventHandler(this.BtnOK_Click);
            // 
            // LblRepairShopTitle
            // 
            this.LblRepairShopTitle.AutoSize = true;
            this.LblRepairShopTitle.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblRepairShopTitle.Location = new System.Drawing.Point(32, 32);
            this.LblRepairShopTitle.Name = "LblRepairShopTitle";
            this.LblRepairShopTitle.Size = new System.Drawing.Size(168, 21);
            this.LblRepairShopTitle.TabIndex = 7;
            this.LblRepairShopTitle.Text = "Название мастерской:";
            // 
            // LblRepairShopAddress
            // 
            this.LblRepairShopAddress.AutoSize = true;
            this.LblRepairShopAddress.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblRepairShopAddress.Location = new System.Drawing.Point(32, 96);
            this.LblRepairShopAddress.Name = "LblRepairShopAddress";
            this.LblRepairShopAddress.Size = new System.Drawing.Size(143, 21);
            this.LblRepairShopAddress.TabIndex = 8;
            this.LblRepairShopAddress.Text = "Адрес мастерской:";
            // 
            // TxbRepairShopTitle
            // 
            this.TxbRepairShopTitle.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.TxbRepairShopTitle.Location = new System.Drawing.Point(216, 32);
            this.TxbRepairShopTitle.Name = "TxbRepairShopTitle";
            this.TxbRepairShopTitle.Size = new System.Drawing.Size(304, 29);
            this.TxbRepairShopTitle.TabIndex = 1;
            // 
            // TxbRepairShopAddress
            // 
            this.TxbRepairShopAddress.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.TxbRepairShopAddress.Location = new System.Drawing.Point(216, 88);
            this.TxbRepairShopAddress.Name = "TxbRepairShopAddress";
            this.TxbRepairShopAddress.Size = new System.Drawing.Size(304, 29);
            this.TxbRepairShopAddress.TabIndex = 2;
            // 
            // RepairShopForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Lavender;
            this.ClientSize = new System.Drawing.Size(551, 235);
            this.Controls.Add(this.TxbRepairShopAddress);
            this.Controls.Add(this.TxbRepairShopTitle);
            this.Controls.Add(this.LblRepairShopAddress);
            this.Controls.Add(this.LblRepairShopTitle);
            this.Controls.Add(this.BtnCancel);
            this.Controls.Add(this.BtnOk);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "RepairShopForm";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "RepairShopForm";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button BtnCancel;
        private System.Windows.Forms.Button BtnOk;
        private System.Windows.Forms.Label LblRepairShopTitle;
        private System.Windows.Forms.Label LblRepairShopAddress;
        private System.Windows.Forms.TextBox TxbRepairShopTitle;
        private System.Windows.Forms.TextBox TxbRepairShopAddress;
    }
}