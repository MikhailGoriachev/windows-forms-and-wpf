﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace _HwE_MultiForms.Views
{
    public partial class ArtisanChoiceForm : Form
    {
        public ArtisanChoiceForm(): this(new List<string>()){ }

        public ArtisanChoiceForm(List<string> artisans) {
            InitializeComponent();

            // привязка к коллекции, выбор первого в списке мастера
            CbxArtisan.DataSource = artisans;
            CbxArtisan.Text = CbxArtisan.Items[0].ToString();
        } // ArtisanChoiceForm
           
        // вернуть выбранного мастера
        public string Artisan => CbxArtisan.Text;
    }
}
