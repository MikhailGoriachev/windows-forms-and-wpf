﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;  // подключить эту сборку для атрибута [DataContract]

namespace _HwE_MultiForms.Models
{
    /*
     * Класс RepairShop (коллекция Television, название ремонтной
     * мастерской, адрес ремонтной мастерской).
     *
     * Требуется обеспечить функционал
     *     • Начальное формирование данных ремонтной мастерской (коллекция
     *       телевизоров от 12 до 15 штук)
     *     • Добавление телевизора в коллекцию
     *     • Удаление телевизора в коллекцию
     *     • Доступ к отдельному телевизору по чтению и записи при помощи
     *       индексатора
     *     • Доступ ко всей коллекции телевизоров
     *     • Обеспечение сортировки коллекции телевизоров
     *     • Обеспечение выборки из коллекции телевизоров
     */
    [DataContract]
    public class RepairShop
    {
        // коллекция Television - телевизоры в ремонте
        [DataMember]
        private List<Television> _televisions;
        public List<Television> Televisions {
            get => _televisions;
            private set => _televisions = value;
        } // Televisions


        // название ремонтной мастерской
        [DataMember]
        private string _title;
        public string Title {
            get => _title;
            set {
                if (string.IsNullOrWhiteSpace(value))
                    throw new ArgumentException("RepairShop. Должно быть задано название ремонтной мастерской");

                _title = value;
            }
        } // Title


        // адрес ремонтной мастерской
        [DataMember]
        private string _address;
        public string Address {
            get => _address;
            set {
                if (string.IsNullOrWhiteSpace(value))
                    throw new ArgumentException("RepairShop. Должен быть задан адрес ремонтной мастерской");

                _address = value;
            }
        } // Address


        // конструкторы
        public RepairShop():this(new List<Television>(), "Ремонт ТВ", "пр. Мира, 13") {
            Initialize();
        } // Repairshop

        public RepairShop(List<Television> televisions, string title, string address) {
            Televisions = televisions;
            Title = title;
            Address = address;
        } // RepairShop


        // формирование коллекции телевизоров в ремонте
        public void Initialize(int n = 12) {
            _televisions.Clear();

            for (int i = 0; i < n; i++) {
                _televisions.Add(Television.Generate());
            } // for i
        } // Initialize


        // индексатор для телевизоров
        public Television this[int index] {
            get => _televisions[index];
            set => _televisions[index] = value;
        } // indexer


        // получение текущего количества телевизоров в коллекции
        public int Count => _televisions.Count;


        // добавление телевизора в коллекцию
        public void Add(Television television) => _televisions.Add(television);


        // удаление телевизора из коллекции
        public void RemoveAt(int index) => _televisions.RemoveAt(index);


        // получить минимальную стоимость ремонта телевизора
        public int MinPrice() {
            int minPrice = _televisions[0].Price;
            _televisions.ForEach(t => minPrice = t.Price < minPrice?t.Price:minPrice);

            return minPrice;
        } // MinPrice


        // получить максимальную стоимость ремонта телевизора
        public int MaxPrice() {
            int maxPrice = _televisions[0].Price;
            _televisions.ForEach(t => maxPrice = t.Price > maxPrice ? t.Price : maxPrice);

            return maxPrice;
        } // MaxPrice


        // упорядочивание коллекции по заданному компаратору
        public void OrderBy(Comparison<Television> comparison) => _televisions.Sort(comparison);
        

        // выборка данных из коллекции по заданному предикату
        public List<Television> Filter(Predicate<Television> predicate) =>
            _televisions.FindAll(predicate);
    } // class RepairShop
}
