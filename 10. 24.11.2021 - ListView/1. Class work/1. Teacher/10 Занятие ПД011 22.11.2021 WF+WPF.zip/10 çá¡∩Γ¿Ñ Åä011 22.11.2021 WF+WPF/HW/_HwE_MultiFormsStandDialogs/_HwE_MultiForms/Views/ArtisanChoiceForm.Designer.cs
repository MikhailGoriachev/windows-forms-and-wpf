﻿
namespace _HwE_MultiForms.Views
{
    partial class ArtisanChoiceForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ArtisanChoiceForm));
            this.LblPrompt = new System.Windows.Forms.Label();
            this.CbxArtisan = new System.Windows.Forms.ComboBox();
            this.BtnOk = new System.Windows.Forms.Button();
            this.BtnCancel = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // LblPrompt
            // 
            this.LblPrompt.AutoSize = true;
            this.LblPrompt.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.LblPrompt.Location = new System.Drawing.Point(24, 24);
            this.LblPrompt.Name = "LblPrompt";
            this.LblPrompt.Size = new System.Drawing.Size(236, 21);
            this.LblPrompt.TabIndex = 0;
            this.LblPrompt.Text = "Мастер для выборки ремонтов:";
            // 
            // CbxArtisan
            // 
            this.CbxArtisan.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CbxArtisan.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.CbxArtisan.FormattingEnabled = true;
            this.CbxArtisan.Location = new System.Drawing.Point(24, 48);
            this.CbxArtisan.Name = "CbxArtisan";
            this.CbxArtisan.Size = new System.Drawing.Size(296, 29);
            this.CbxArtisan.Sorted = true;
            this.CbxArtisan.TabIndex = 1;
            // 
            // BtnOk
            // 
            this.BtnOk.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.BtnOk.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.BtnOk.Location = new System.Drawing.Point(32, 112);
            this.BtnOk.Name = "BtnOk";
            this.BtnOk.Size = new System.Drawing.Size(136, 40);
            this.BtnOk.TabIndex = 2;
            this.BtnOk.Text = "Выбрать";
            this.BtnOk.UseVisualStyleBackColor = true;
            // 
            // BtnCancel
            // 
            this.BtnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.BtnCancel.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.BtnCancel.Location = new System.Drawing.Point(184, 112);
            this.BtnCancel.Name = "BtnCancel";
            this.BtnCancel.Size = new System.Drawing.Size(136, 40);
            this.BtnCancel.TabIndex = 3;
            this.BtnCancel.Text = "Отмена";
            this.BtnCancel.UseVisualStyleBackColor = true;
            // 
            // ArtisanChoiceForm
            // 
            this.AcceptButton = this.BtnOk;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Lavender;
            this.CancelButton = this.BtnCancel;
            this.ClientSize = new System.Drawing.Size(353, 174);
            this.Controls.Add(this.BtnCancel);
            this.Controls.Add(this.BtnOk);
            this.Controls.Add(this.CbxArtisan);
            this.Controls.Add(this.LblPrompt);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "ArtisanChoiceForm";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Выбор мастера";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label LblPrompt;
        private System.Windows.Forms.ComboBox CbxArtisan;
        private System.Windows.Forms.Button BtnOk;
        private System.Windows.Forms.Button BtnCancel;
    }
}