﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HomeWork22._11._21.Views
{
    public partial class SelectChoiseSearch : Form
    {
        private (string repairName, double diagonal) _choice;
        public (string repairName, double diagonal) Choice
        {
            get { return _choice; }
            set { _choice = value; }
        }



        public SelectChoiseSearch(string title, string name)
        {
            InitializeComponent();
            Text = title;
            numericUpDown1.Enabled = false;
        }

        public SelectChoiseSearch(string title, double diagonal)
        {
            InitializeComponent();
            Text = title;
            comboBox1.Enabled = false;
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            _choice.repairName = comboBox1.SelectedItem.ToString();
        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {
            _choice.diagonal = (double)numericUpDown1.Value;
        }
    }
}
