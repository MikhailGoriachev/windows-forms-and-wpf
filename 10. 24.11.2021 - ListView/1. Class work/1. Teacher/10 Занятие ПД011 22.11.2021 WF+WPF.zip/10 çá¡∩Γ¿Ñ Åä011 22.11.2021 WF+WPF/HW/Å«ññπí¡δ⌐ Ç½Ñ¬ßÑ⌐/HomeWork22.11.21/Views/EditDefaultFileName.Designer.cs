﻿
namespace HomeWork22._11._21.Views
{
    partial class EditDefaultFileName
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Lbl_default_file_name = new System.Windows.Forms.Label();
            this.Txb_fileName = new System.Windows.Forms.TextBox();
            this.Btn_ok = new System.Windows.Forms.Button();
            this.Btn_cancel = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Lbl_default_file_name
            // 
            this.Lbl_default_file_name.Location = new System.Drawing.Point(76, 39);
            this.Lbl_default_file_name.Name = "Lbl_default_file_name";
            this.Lbl_default_file_name.Size = new System.Drawing.Size(241, 29);
            this.Lbl_default_file_name.TabIndex = 0;
            this.Lbl_default_file_name.Text = "Введите новое имя для файла автосохранения";
            // 
            // Txb_fileName
            // 
            this.Txb_fileName.Location = new System.Drawing.Point(34, 72);
            this.Txb_fileName.Name = "Txb_fileName";
            this.Txb_fileName.Size = new System.Drawing.Size(325, 26);
            this.Txb_fileName.TabIndex = 1;
            // 
            // Btn_ok
            // 
            this.Btn_ok.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.Btn_ok.Location = new System.Drawing.Point(34, 135);
            this.Btn_ok.Name = "Btn_ok";
            this.Btn_ok.Size = new System.Drawing.Size(154, 29);
            this.Btn_ok.TabIndex = 2;
            this.Btn_ok.Text = "Сохранить";
            this.Btn_ok.UseVisualStyleBackColor = true;
            this.Btn_ok.Click += new System.EventHandler(this.Edit_filename_command);
            // 
            // Btn_cancel
            // 
            this.Btn_cancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.Btn_cancel.Location = new System.Drawing.Point(205, 135);
            this.Btn_cancel.Name = "Btn_cancel";
            this.Btn_cancel.Size = new System.Drawing.Size(154, 29);
            this.Btn_cancel.TabIndex = 3;
            this.Btn_cancel.Text = "Отмена";
            this.Btn_cancel.UseVisualStyleBackColor = true;
            // 
            // EditDefaultFileName
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(397, 201);
            this.Controls.Add(this.Btn_cancel);
            this.Controls.Add(this.Btn_ok);
            this.Controls.Add(this.Txb_fileName);
            this.Controls.Add(this.Lbl_default_file_name);
            this.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "EditDefaultFileName";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Название файла автосохранения";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Lbl_default_file_name;
        private System.Windows.Forms.TextBox Txb_fileName;
        private System.Windows.Forms.Button Btn_ok;
        private System.Windows.Forms.Button Btn_cancel;
    }
}