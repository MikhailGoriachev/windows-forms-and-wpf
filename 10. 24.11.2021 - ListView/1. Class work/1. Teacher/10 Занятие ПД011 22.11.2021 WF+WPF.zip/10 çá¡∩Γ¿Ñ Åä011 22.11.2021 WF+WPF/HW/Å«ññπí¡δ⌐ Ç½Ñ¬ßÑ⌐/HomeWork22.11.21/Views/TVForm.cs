﻿using HomeWork22._11._21.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace HomeWork22._11._21.Views
{
    public partial class TVForm : Form
    {
        private Television _television;

        public Television Television
        {
            get { return _television; }
            set
            {
                _television = value;

                textBox1.Text = _television.Type;
                numericUpDown2.Value = (decimal)_television.Diagonal;
                textBox2.Text = _television.Defect;
                comboBox1.SelectedItem = _television.RepairerName;
                textBox3.Text = _television.OwnerName;
                numericUpDown1.Value = (decimal)_television.RepairCost;
            }
        }


        // конструктор для формы в режиме добавления
        public TVForm()
        {
            InitializeComponent();
            Btn_action.Enabled = false;

            _television = new Television();
        }


        // конструктор для формы в режиме редкатирования
        public TVForm(string formTitle, string btnAction)
        {
            InitializeComponent();


            _television = new Television();
            Text = formTitle;
            Btn_action.Text = btnAction;
        }



        private void textBox1_Validated(object sender, EventArgs e)
        {
            Btn_action.Enabled = !string.IsNullOrWhiteSpace(textBox1.Text) && !string.IsNullOrWhiteSpace(textBox2.Text) && !string.IsNullOrWhiteSpace(textBox3.Text);
        }

        private void Btn_action_Click(object sender, EventArgs e)
        {
            try
            {
                _television.Type = textBox1.Text;
                _television.Diagonal = (double)numericUpDown2.Value;
                _television.Defect = textBox2.Text;
                if (comboBox1.SelectedIndex < 0)
                {
                    _television.RepairerName = (string)comboBox1.Items[Utils.GetRandom(0, comboBox1.Items.Count - 1)];
                }
                else
                {
                    _television.RepairerName = (string)comboBox1.SelectedItem;
                }
                _television.OwnerName = textBox3.Text;
                _television.RepairCost = (double)numericUpDown1.Value;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
