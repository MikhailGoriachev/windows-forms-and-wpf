﻿
namespace HomeWork22._11._21
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.Lbl_status_bar = new System.Windows.Forms.ToolStripStatusLabel();
            this.Lbt_statusBar_address = new System.Windows.Forms.ToolStripStatusLabel();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.файлToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripSeparator();
            this.открытьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.сохранитьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem6 = new System.Windows.Forms.ToolStripSeparator();
            this.выходToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.телевизорыToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.добавитьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.удалитьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.измениитьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripSeparator();
            this.пересобратьКоллекциюДанныхToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.очиститьКоллекциюДанныхToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.сортировкаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.oПоПроизводителюИТипуToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.поУбываниюДиагоналиЭкранаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.поМастеруВыполняющемуРемонтToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.поВладельцуТелевизораToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.поСтоимостиРемонтаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.оКомпанииToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.редактироватьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.оПрограммеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.Lbx_main = new System.Windows.Forms.ListBox();
            this.contextMenuStrip2 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.открытьToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.сохранитьToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem8 = new System.Windows.Forms.ToolStripSeparator();
            this.удалитьToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.добавитьToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.изменитьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripSeparator();
            this.изменитьШрифтToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.изменитьЦветToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem9 = new System.Windows.Forms.ToolStripSeparator();
            this.сортироватьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.поПроизводителюИТипуToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.поУбываниюДиагоналиЭкранаToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.поМастеруВыполняющемуРемонтToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.поВладельцуТелевизораToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem4 = new System.Windows.Forms.ToolStripSeparator();
            this.очиститьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem7 = new System.Windows.Forms.ToolStripSeparator();
            this.оПрограммеToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.выходToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.contextMenuStrip3 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.оПрограммеToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem5 = new System.Windows.Forms.ToolStripSeparator();
            this.выходToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.Lbl_header = new System.Windows.Forms.Label();
            this.Sfd_main = new System.Windows.Forms.SaveFileDialog();
            this.Ofd_main = new System.Windows.Forms.OpenFileDialog();
            this.Cfd_main = new System.Windows.Forms.ColorDialog();
            this.Ffd_main = new System.Windows.Forms.FontDialog();
            this.Stb_saving_bar = new System.Windows.Forms.StatusStrip();
            this.Ssl_default_path = new System.Windows.Forms.ToolStripStatusLabel();
            this.stb_lbl_folder_path = new System.Windows.Forms.ToolStripStatusLabel();
            this.Ssl_default_file_name = new System.Windows.Forms.ToolStripStatusLabel();
            this.stb_lbl_default_name = new System.Windows.Forms.ToolStripStatusLabel();
            this.Ssl_info_default_save_folder = new System.Windows.Forms.ToolStripStatusLabel();
            this.Sst_change_default_path_name = new System.Windows.Forms.ToolStripStatusLabel();
            this.Fbd_main = new System.Windows.Forms.FolderBrowserDialog();
            this.toolStripDropDownButton1 = new System.Windows.Forms.ToolStripDropDownButton();
            this.изменитьИмяФайлаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.изменитьАдресToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton2 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton3 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton4 = new System.Windows.Forms.ToolStripButton();
            this.statusStrip1.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.contextMenuStrip2.SuspendLayout();
            this.contextMenuStrip3.SuspendLayout();
            this.Stb_saving_bar.SuspendLayout();
            this.SuspendLayout();
            // 
            // statusStrip1
            // 
            this.statusStrip1.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.Lbl_status_bar,
            this.Lbt_statusBar_address});
            this.statusStrip1.Location = new System.Drawing.Point(0, 554);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Padding = new System.Windows.Forms.Padding(1, 0, 16, 0);
            this.statusStrip1.Size = new System.Drawing.Size(1372, 22);
            this.statusStrip1.TabIndex = 0;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // Lbl_status_bar
            // 
            this.Lbl_status_bar.Margin = new System.Windows.Forms.Padding(0, 3, 700, 2);
            this.Lbl_status_bar.Name = "Lbl_status_bar";
            this.Lbl_status_bar.Size = new System.Drawing.Size(243, 17);
            this.Lbl_status_bar.Text = "Количество телвизоров в ремноте : ";
            // 
            // Lbt_statusBar_address
            // 
            this.Lbt_statusBar_address.ImageAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.Lbt_statusBar_address.Name = "Lbt_statusBar_address";
            this.Lbt_statusBar_address.Padding = new System.Windows.Forms.Padding(0, 0, 10, 0);
            this.Lbt_statusBar_address.Size = new System.Drawing.Size(153, 17);
            this.Lbt_statusBar_address.Text = "toolStripStatusLabel1";
            // 
            // menuStrip1
            // 
            this.menuStrip1.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.файлToolStripMenuItem,
            this.телевизорыToolStripMenuItem,
            this.сортировкаToolStripMenuItem,
            this.оКомпанииToolStripMenuItem,
            this.оПрограммеToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(7, 2, 0, 2);
            this.menuStrip1.Size = new System.Drawing.Size(1372, 24);
            this.menuStrip1.TabIndex = 2;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // файлToolStripMenuItem
            // 
            this.файлToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem1,
            this.открытьToolStripMenuItem,
            this.сохранитьToolStripMenuItem,
            this.toolStripMenuItem6,
            this.выходToolStripMenuItem});
            this.файлToolStripMenuItem.Name = "файлToolStripMenuItem";
            this.файлToolStripMenuItem.Size = new System.Drawing.Size(53, 20);
            this.файлToolStripMenuItem.Text = "Файл";
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(153, 6);
            // 
            // открытьToolStripMenuItem
            // 
            this.открытьToolStripMenuItem.Name = "открытьToolStripMenuItem";
            this.открытьToolStripMenuItem.Size = new System.Drawing.Size(156, 22);
            this.открытьToolStripMenuItem.Text = "Открыть...";
            this.открытьToolStripMenuItem.Click += new System.EventHandler(this.Open_command);
            // 
            // сохранитьToolStripMenuItem
            // 
            this.сохранитьToolStripMenuItem.Name = "сохранитьToolStripMenuItem";
            this.сохранитьToolStripMenuItem.Size = new System.Drawing.Size(156, 22);
            this.сохранитьToolStripMenuItem.Text = "Сохранить...";
            this.сохранитьToolStripMenuItem.Click += new System.EventHandler(this.Save_command);
            // 
            // toolStripMenuItem6
            // 
            this.toolStripMenuItem6.Name = "toolStripMenuItem6";
            this.toolStripMenuItem6.Size = new System.Drawing.Size(153, 6);
            // 
            // выходToolStripMenuItem
            // 
            this.выходToolStripMenuItem.Name = "выходToolStripMenuItem";
            this.выходToolStripMenuItem.Size = new System.Drawing.Size(156, 22);
            this.выходToolStripMenuItem.Text = "Выход";
            this.выходToolStripMenuItem.Click += new System.EventHandler(this.Exit_Command);
            // 
            // телевизорыToolStripMenuItem
            // 
            this.телевизорыToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.добавитьToolStripMenuItem,
            this.удалитьToolStripMenuItem,
            this.измениитьToolStripMenuItem,
            this.toolStripMenuItem2,
            this.пересобратьКоллекциюДанныхToolStripMenuItem,
            this.очиститьКоллекциюДанныхToolStripMenuItem});
            this.телевизорыToolStripMenuItem.Name = "телевизорыToolStripMenuItem";
            this.телевизорыToolStripMenuItem.Size = new System.Drawing.Size(95, 20);
            this.телевизорыToolStripMenuItem.Text = "Телевизоры";
            // 
            // добавитьToolStripMenuItem
            // 
            this.добавитьToolStripMenuItem.Name = "добавитьToolStripMenuItem";
            this.добавитьToolStripMenuItem.Size = new System.Drawing.Size(287, 22);
            this.добавитьToolStripMenuItem.Text = "Добавить ";
            this.добавитьToolStripMenuItem.Click += new System.EventHandler(this.добавитьToolStripMenuItem_Click);
            // 
            // удалитьToolStripMenuItem
            // 
            this.удалитьToolStripMenuItem.Name = "удалитьToolStripMenuItem";
            this.удалитьToolStripMenuItem.Size = new System.Drawing.Size(287, 22);
            this.удалитьToolStripMenuItem.Text = "Удалить";
            this.удалитьToolStripMenuItem.Click += new System.EventHandler(this.удалитьToolStripMenuItem_Click);
            // 
            // измениитьToolStripMenuItem
            // 
            this.измениитьToolStripMenuItem.Name = "измениитьToolStripMenuItem";
            this.измениитьToolStripMenuItem.Size = new System.Drawing.Size(287, 22);
            this.измениитьToolStripMenuItem.Text = "Измениить";
            this.измениитьToolStripMenuItem.Click += new System.EventHandler(this.измениитьToolStripMenuItem_Click);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(284, 6);
            // 
            // пересобратьКоллекциюДанныхToolStripMenuItem
            // 
            this.пересобратьКоллекциюДанныхToolStripMenuItem.Name = "пересобратьКоллекциюДанныхToolStripMenuItem";
            this.пересобратьКоллекциюДанныхToolStripMenuItem.Size = new System.Drawing.Size(287, 22);
            this.пересобратьКоллекциюДанныхToolStripMenuItem.Text = "Пересобрать коллекцию данных";
            this.пересобратьКоллекциюДанныхToolStripMenuItem.Click += new System.EventHandler(this.пересобратьКоллекциюДанныхToolStripMenuItem_Click);
            // 
            // очиститьКоллекциюДанныхToolStripMenuItem
            // 
            this.очиститьКоллекциюДанныхToolStripMenuItem.Name = "очиститьКоллекциюДанныхToolStripMenuItem";
            this.очиститьКоллекциюДанныхToolStripMenuItem.Size = new System.Drawing.Size(287, 22);
            this.очиститьКоллекциюДанныхToolStripMenuItem.Text = "Очистить коллекцию данных";
            this.очиститьКоллекциюДанныхToolStripMenuItem.Click += new System.EventHandler(this.Clear_Command);
            // 
            // сортировкаToolStripMenuItem
            // 
            this.сортировкаToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.oПоПроизводителюИТипуToolStripMenuItem,
            this.поУбываниюДиагоналиЭкранаToolStripMenuItem,
            this.поМастеруВыполняющемуРемонтToolStripMenuItem,
            this.поВладельцуТелевизораToolStripMenuItem,
            this.поСтоимостиРемонтаToolStripMenuItem});
            this.сортировкаToolStripMenuItem.Name = "сортировкаToolStripMenuItem";
            this.сортировкаToolStripMenuItem.Size = new System.Drawing.Size(97, 20);
            this.сортировкаToolStripMenuItem.Text = "Сортировка";
            // 
            // oПоПроизводителюИТипуToolStripMenuItem
            // 
            this.oПоПроизводителюИТипуToolStripMenuItem.Name = "oПоПроизводителюИТипуToolStripMenuItem";
            this.oПоПроизводителюИТипуToolStripMenuItem.Size = new System.Drawing.Size(306, 22);
            this.oПоПроизводителюИТипуToolStripMenuItem.Text = "По производителю и типу";
            this.oПоПроизводителюИТипуToolStripMenuItem.Click += new System.EventHandler(this.oПоПроизводителюИТипуToolStripMenuItem_Click);
            // 
            // поУбываниюДиагоналиЭкранаToolStripMenuItem
            // 
            this.поУбываниюДиагоналиЭкранаToolStripMenuItem.Name = "поУбываниюДиагоналиЭкранаToolStripMenuItem";
            this.поУбываниюДиагоналиЭкранаToolStripMenuItem.Size = new System.Drawing.Size(306, 22);
            this.поУбываниюДиагоналиЭкранаToolStripMenuItem.Text = "По убыванию диагонали экрана";
            this.поУбываниюДиагоналиЭкранаToolStripMenuItem.Click += new System.EventHandler(this.поУбываниюДиагоналиЭкранаToolStripMenuItem_Click);
            // 
            // поМастеруВыполняющемуРемонтToolStripMenuItem
            // 
            this.поМастеруВыполняющемуРемонтToolStripMenuItem.Name = "поМастеруВыполняющемуРемонтToolStripMenuItem";
            this.поМастеруВыполняющемуРемонтToolStripMenuItem.Size = new System.Drawing.Size(306, 22);
            this.поМастеруВыполняющемуРемонтToolStripMenuItem.Text = "По мастеру, выполняющему ремонт";
            this.поМастеруВыполняющемуРемонтToolStripMenuItem.Click += new System.EventHandler(this.поМастеруВыполняющемуРемонтToolStripMenuItem_Click);
            // 
            // поВладельцуТелевизораToolStripMenuItem
            // 
            this.поВладельцуТелевизораToolStripMenuItem.Name = "поВладельцуТелевизораToolStripMenuItem";
            this.поВладельцуТелевизораToolStripMenuItem.Size = new System.Drawing.Size(306, 22);
            this.поВладельцуТелевизораToolStripMenuItem.Text = "По владельцу телевизора";
            this.поВладельцуТелевизораToolStripMenuItem.Click += new System.EventHandler(this.поВладельцуТелевизораToolStripMenuItem_Click);
            // 
            // поСтоимостиРемонтаToolStripMenuItem
            // 
            this.поСтоимостиРемонтаToolStripMenuItem.Name = "поСтоимостиРемонтаToolStripMenuItem";
            this.поСтоимостиРемонтаToolStripMenuItem.Size = new System.Drawing.Size(306, 22);
            this.поСтоимостиРемонтаToolStripMenuItem.Text = "По стоимости ремонта";
            this.поСтоимостиРемонтаToolStripMenuItem.Click += new System.EventHandler(this.поСтоимостиРемонтаToolStripMenuItem_Click);
            // 
            // оКомпанииToolStripMenuItem
            // 
            this.оКомпанииToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.редактироватьToolStripMenuItem});
            this.оКомпанииToolStripMenuItem.Name = "оКомпанииToolStripMenuItem";
            this.оКомпанииToolStripMenuItem.Size = new System.Drawing.Size(96, 20);
            this.оКомпанииToolStripMenuItem.Text = "О компании";
            // 
            // редактироватьToolStripMenuItem
            // 
            this.редактироватьToolStripMenuItem.Name = "редактироватьToolStripMenuItem";
            this.редактироватьToolStripMenuItem.Size = new System.Drawing.Size(173, 22);
            this.редактироватьToolStripMenuItem.Text = "Редактировать";
            this.редактироватьToolStripMenuItem.Click += new System.EventHandler(this.редактироватьToolStripMenuItem_Click);
            // 
            // оПрограммеToolStripMenuItem
            // 
            this.оПрограммеToolStripMenuItem.Name = "оПрограммеToolStripMenuItem";
            this.оПрограммеToolStripMenuItem.Size = new System.Drawing.Size(103, 20);
            this.оПрограммеToolStripMenuItem.Text = "О программе";
            this.оПрограммеToolStripMenuItem.Click += new System.EventHandler(this.оПрограммеToolStripMenuItem_Click);
            // 
            // toolStrip1
            // 
            this.toolStrip1.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButton1,
            this.toolStripButton2,
            this.toolStripButton3,
            this.toolStripButton4});
            this.toolStrip1.Location = new System.Drawing.Point(0, 24);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(1372, 47);
            this.toolStrip1.TabIndex = 3;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // Lbx_main
            // 
            this.Lbx_main.ContextMenuStrip = this.contextMenuStrip2;
            this.Lbx_main.Font = new System.Drawing.Font("Consolas", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Lbx_main.FormattingEnabled = true;
            this.Lbx_main.ItemHeight = 18;
            this.Lbx_main.Location = new System.Drawing.Point(14, 143);
            this.Lbx_main.Name = "Lbx_main";
            this.Lbx_main.Size = new System.Drawing.Size(1340, 382);
            this.Lbx_main.TabIndex = 4;
            this.Lbx_main.SelectedIndexChanged += new System.EventHandler(this.Lbx_main_SelectedIndexChanged);
            // 
            // contextMenuStrip2
            // 
            this.contextMenuStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.открытьToolStripMenuItem1,
            this.сохранитьToolStripMenuItem1,
            this.toolStripMenuItem8,
            this.удалитьToolStripMenuItem1,
            this.добавитьToolStripMenuItem1,
            this.изменитьToolStripMenuItem,
            this.toolStripMenuItem3,
            this.изменитьШрифтToolStripMenuItem,
            this.изменитьЦветToolStripMenuItem,
            this.toolStripMenuItem9,
            this.сортироватьToolStripMenuItem,
            this.toolStripMenuItem4,
            this.очиститьToolStripMenuItem,
            this.toolStripMenuItem7,
            this.оПрограммеToolStripMenuItem1,
            this.выходToolStripMenuItem1});
            this.contextMenuStrip2.Name = "contextMenuStrip2";
            this.contextMenuStrip2.Size = new System.Drawing.Size(222, 276);
            // 
            // открытьToolStripMenuItem1
            // 
            this.открытьToolStripMenuItem1.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.открытьToolStripMenuItem1.Name = "открытьToolStripMenuItem1";
            this.открытьToolStripMenuItem1.Size = new System.Drawing.Size(221, 22);
            this.открытьToolStripMenuItem1.Text = "Открыть...";
            this.открытьToolStripMenuItem1.Click += new System.EventHandler(this.Open_command);
            // 
            // сохранитьToolStripMenuItem1
            // 
            this.сохранитьToolStripMenuItem1.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.сохранитьToolStripMenuItem1.Name = "сохранитьToolStripMenuItem1";
            this.сохранитьToolStripMenuItem1.Size = new System.Drawing.Size(221, 22);
            this.сохранитьToolStripMenuItem1.Text = "Сохранить...";
            this.сохранитьToolStripMenuItem1.Click += new System.EventHandler(this.Save_command);
            // 
            // toolStripMenuItem8
            // 
            this.toolStripMenuItem8.Name = "toolStripMenuItem8";
            this.toolStripMenuItem8.Size = new System.Drawing.Size(218, 6);
            // 
            // удалитьToolStripMenuItem1
            // 
            this.удалитьToolStripMenuItem1.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.удалитьToolStripMenuItem1.Name = "удалитьToolStripMenuItem1";
            this.удалитьToolStripMenuItem1.Size = new System.Drawing.Size(221, 22);
            this.удалитьToolStripMenuItem1.Text = "Удалить";
            this.удалитьToolStripMenuItem1.Click += new System.EventHandler(this.удалитьToolStripMenuItem_Click);
            // 
            // добавитьToolStripMenuItem1
            // 
            this.добавитьToolStripMenuItem1.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.добавитьToolStripMenuItem1.Name = "добавитьToolStripMenuItem1";
            this.добавитьToolStripMenuItem1.Size = new System.Drawing.Size(221, 22);
            this.добавитьToolStripMenuItem1.Text = "Добавить";
            this.добавитьToolStripMenuItem1.Click += new System.EventHandler(this.добавитьToolStripMenuItem_Click);
            // 
            // изменитьToolStripMenuItem
            // 
            this.изменитьToolStripMenuItem.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.изменитьToolStripMenuItem.Name = "изменитьToolStripMenuItem";
            this.изменитьToolStripMenuItem.Size = new System.Drawing.Size(221, 22);
            this.изменитьToolStripMenuItem.Text = "Изменить";
            this.изменитьToolStripMenuItem.Click += new System.EventHandler(this.измениитьToolStripMenuItem_Click);
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(218, 6);
            // 
            // изменитьШрифтToolStripMenuItem
            // 
            this.изменитьШрифтToolStripMenuItem.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.изменитьШрифтToolStripMenuItem.Name = "изменитьШрифтToolStripMenuItem";
            this.изменитьШрифтToolStripMenuItem.Size = new System.Drawing.Size(221, 22);
            this.изменитьШрифтToolStripMenuItem.Text = "Изменить шрифт...";
            this.изменитьШрифтToolStripMenuItem.Click += new System.EventHandler(this.Edit_font_Command);
            // 
            // изменитьЦветToolStripMenuItem
            // 
            this.изменитьЦветToolStripMenuItem.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.изменитьЦветToolStripMenuItem.Name = "изменитьЦветToolStripMenuItem";
            this.изменитьЦветToolStripMenuItem.Size = new System.Drawing.Size(221, 22);
            this.изменитьЦветToolStripMenuItem.Text = "Изменить цвет фона...";
            this.изменитьЦветToolStripMenuItem.Click += new System.EventHandler(this.Edit_color_background_Command);
            // 
            // toolStripMenuItem9
            // 
            this.toolStripMenuItem9.Name = "toolStripMenuItem9";
            this.toolStripMenuItem9.Size = new System.Drawing.Size(218, 6);
            // 
            // сортироватьToolStripMenuItem
            // 
            this.сортироватьToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.поПроизводителюИТипуToolStripMenuItem,
            this.поУбываниюДиагоналиЭкранаToolStripMenuItem1,
            this.поМастеруВыполняющемуРемонтToolStripMenuItem1,
            this.поВладельцуТелевизораToolStripMenuItem1});
            this.сортироватьToolStripMenuItem.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.сортироватьToolStripMenuItem.Name = "сортироватьToolStripMenuItem";
            this.сортироватьToolStripMenuItem.Size = new System.Drawing.Size(221, 22);
            this.сортироватьToolStripMenuItem.Text = "Сортировать";
            // 
            // поПроизводителюИТипуToolStripMenuItem
            // 
            this.поПроизводителюИТипуToolStripMenuItem.Name = "поПроизводителюИТипуToolStripMenuItem";
            this.поПроизводителюИТипуToolStripMenuItem.Size = new System.Drawing.Size(306, 22);
            this.поПроизводителюИТипуToolStripMenuItem.Text = "По производителю и типу";
            this.поПроизводителюИТипуToolStripMenuItem.Click += new System.EventHandler(this.oПоПроизводителюИТипуToolStripMenuItem_Click);
            // 
            // поУбываниюДиагоналиЭкранаToolStripMenuItem1
            // 
            this.поУбываниюДиагоналиЭкранаToolStripMenuItem1.Name = "поУбываниюДиагоналиЭкранаToolStripMenuItem1";
            this.поУбываниюДиагоналиЭкранаToolStripMenuItem1.Size = new System.Drawing.Size(306, 22);
            this.поУбываниюДиагоналиЭкранаToolStripMenuItem1.Text = "По убыванию диагонали экрана";
            this.поУбываниюДиагоналиЭкранаToolStripMenuItem1.Click += new System.EventHandler(this.поУбываниюДиагоналиЭкранаToolStripMenuItem_Click);
            // 
            // поМастеруВыполняющемуРемонтToolStripMenuItem1
            // 
            this.поМастеруВыполняющемуРемонтToolStripMenuItem1.Name = "поМастеруВыполняющемуРемонтToolStripMenuItem1";
            this.поМастеруВыполняющемуРемонтToolStripMenuItem1.Size = new System.Drawing.Size(306, 22);
            this.поМастеруВыполняющемуРемонтToolStripMenuItem1.Text = "По мастеру, выполняющему ремонт";
            this.поМастеруВыполняющемуРемонтToolStripMenuItem1.Click += new System.EventHandler(this.поМастеруВыполняющемуРемонтToolStripMenuItem_Click);
            // 
            // поВладельцуТелевизораToolStripMenuItem1
            // 
            this.поВладельцуТелевизораToolStripMenuItem1.Name = "поВладельцуТелевизораToolStripMenuItem1";
            this.поВладельцуТелевизораToolStripMenuItem1.Size = new System.Drawing.Size(306, 22);
            this.поВладельцуТелевизораToolStripMenuItem1.Text = "По владельцу телевизора";
            this.поВладельцуТелевизораToolStripMenuItem1.Click += new System.EventHandler(this.поВладельцуТелевизораToolStripMenuItem_Click);
            // 
            // toolStripMenuItem4
            // 
            this.toolStripMenuItem4.Name = "toolStripMenuItem4";
            this.toolStripMenuItem4.Size = new System.Drawing.Size(218, 6);
            // 
            // очиститьToolStripMenuItem
            // 
            this.очиститьToolStripMenuItem.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.очиститьToolStripMenuItem.Name = "очиститьToolStripMenuItem";
            this.очиститьToolStripMenuItem.Size = new System.Drawing.Size(221, 22);
            this.очиститьToolStripMenuItem.Text = "Очистить";
            this.очиститьToolStripMenuItem.Click += new System.EventHandler(this.Clear_Command);
            // 
            // toolStripMenuItem7
            // 
            this.toolStripMenuItem7.Name = "toolStripMenuItem7";
            this.toolStripMenuItem7.Size = new System.Drawing.Size(218, 6);
            // 
            // оПрограммеToolStripMenuItem1
            // 
            this.оПрограммеToolStripMenuItem1.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.оПрограммеToolStripMenuItem1.Name = "оПрограммеToolStripMenuItem1";
            this.оПрограммеToolStripMenuItem1.Size = new System.Drawing.Size(221, 22);
            this.оПрограммеToolStripMenuItem1.Text = "О программе";
            this.оПрограммеToolStripMenuItem1.Click += new System.EventHandler(this.оПрограммеToolStripMenuItem_Click);
            // 
            // выходToolStripMenuItem1
            // 
            this.выходToolStripMenuItem1.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.выходToolStripMenuItem1.Name = "выходToolStripMenuItem1";
            this.выходToolStripMenuItem1.Size = new System.Drawing.Size(221, 22);
            this.выходToolStripMenuItem1.Text = "Выход";
            this.выходToolStripMenuItem1.Click += new System.EventHandler(this.Exit_Command);
            // 
            // contextMenuStrip3
            // 
            this.contextMenuStrip3.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.contextMenuStrip3.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.оПрограммеToolStripMenuItem2,
            this.toolStripMenuItem5,
            this.выходToolStripMenuItem2});
            this.contextMenuStrip3.Name = "contextMenuStrip3";
            this.contextMenuStrip3.Size = new System.Drawing.Size(159, 54);
            // 
            // оПрограммеToolStripMenuItem2
            // 
            this.оПрограммеToolStripMenuItem2.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.оПрограммеToolStripMenuItem2.Name = "оПрограммеToolStripMenuItem2";
            this.оПрограммеToolStripMenuItem2.Size = new System.Drawing.Size(158, 22);
            this.оПрограммеToolStripMenuItem2.Text = "О программе";
            this.оПрограммеToolStripMenuItem2.Click += new System.EventHandler(this.оПрограммеToolStripMenuItem_Click);
            // 
            // toolStripMenuItem5
            // 
            this.toolStripMenuItem5.Name = "toolStripMenuItem5";
            this.toolStripMenuItem5.Size = new System.Drawing.Size(155, 6);
            // 
            // выходToolStripMenuItem2
            // 
            this.выходToolStripMenuItem2.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.выходToolStripMenuItem2.Name = "выходToolStripMenuItem2";
            this.выходToolStripMenuItem2.Size = new System.Drawing.Size(158, 22);
            this.выходToolStripMenuItem2.Text = "Выход";
            this.выходToolStripMenuItem2.Click += new System.EventHandler(this.Exit_Command);
            // 
            // Lbl_header
            // 
            this.Lbl_header.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Lbl_header.Location = new System.Drawing.Point(14, 109);
            this.Lbl_header.Name = "Lbl_header";
            this.Lbl_header.Size = new System.Drawing.Size(1354, 31);
            this.Lbl_header.TabIndex = 7;
            this.Lbl_header.Text = resources.GetString("Lbl_header.Text");
            // 
            // Ofd_main
            // 
            this.Ofd_main.FileName = "openFileDialog1";
            // 
            // Ffd_main
            // 
            this.Ffd_main.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            // 
            // Stb_saving_bar
            // 
            this.Stb_saving_bar.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.Ssl_default_path,
            this.stb_lbl_folder_path,
            this.Ssl_default_file_name,
            this.stb_lbl_default_name,
            this.Ssl_info_default_save_folder,
            this.toolStripDropDownButton1,
            this.Sst_change_default_path_name});
            this.Stb_saving_bar.Location = new System.Drawing.Point(0, 532);
            this.Stb_saving_bar.Name = "Stb_saving_bar";
            this.Stb_saving_bar.Size = new System.Drawing.Size(1372, 22);
            this.Stb_saving_bar.TabIndex = 8;
            this.Stb_saving_bar.Text = "statusStrip2";
            // 
            // Ssl_default_path
            // 
            this.Ssl_default_path.Name = "Ssl_default_path";
            this.Ssl_default_path.Size = new System.Drawing.Size(95, 17);
            this.Ssl_default_path.Text = "Путь к файлу :  ";
            // 
            // stb_lbl_folder_path
            // 
            this.stb_lbl_folder_path.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.stb_lbl_folder_path.Name = "stb_lbl_folder_path";
            this.stb_lbl_folder_path.Size = new System.Drawing.Size(143, 17);
            this.stb_lbl_folder_path.Text = "toolStripStatusLabel1";
            // 
            // Ssl_default_file_name
            // 
            this.Ssl_default_file_name.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Ssl_default_file_name.Name = "Ssl_default_file_name";
            this.Ssl_default_file_name.Size = new System.Drawing.Size(100, 17);
            this.Ssl_default_file_name.Text = "Имя файла :  ";
            // 
            // stb_lbl_default_name
            // 
            this.stb_lbl_default_name.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.stb_lbl_default_name.Name = "stb_lbl_default_name";
            this.stb_lbl_default_name.Size = new System.Drawing.Size(143, 17);
            this.stb_lbl_default_name.Text = "toolStripStatusLabel1";
            // 
            // Ssl_info_default_save_folder
            // 
            this.Ssl_info_default_save_folder.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Ssl_info_default_save_folder.Name = "Ssl_info_default_save_folder";
            this.Ssl_info_default_save_folder.Size = new System.Drawing.Size(469, 17);
            this.Ssl_info_default_save_folder.Text = "Этот адрес используеться для автоматического сохранения файла";
            // 
            // Sst_change_default_path_name
            // 
            this.Sst_change_default_path_name.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Sst_change_default_path_name.Name = "Sst_change_default_path_name";
            this.Sst_change_default_path_name.Size = new System.Drawing.Size(71, 17);
            this.Sst_change_default_path_name.Text = "Изменить";
            // 
            // toolStripDropDownButton1
            // 
            this.toolStripDropDownButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripDropDownButton1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.изменитьИмяФайлаToolStripMenuItem,
            this.изменитьАдресToolStripMenuItem});
            this.toolStripDropDownButton1.Image = global::HomeWork22._11._21.Properties.Resources.glyphicons_halflings_71_adjust;
            this.toolStripDropDownButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripDropDownButton1.Name = "toolStripDropDownButton1";
            this.toolStripDropDownButton1.Size = new System.Drawing.Size(29, 20);
            this.toolStripDropDownButton1.Text = "toolStripDropDownButton1";
            this.toolStripDropDownButton1.ToolTipText = "Изменить имя и путь сохранения";
            // 
            // изменитьИмяФайлаToolStripMenuItem
            // 
            this.изменитьИмяФайлаToolStripMenuItem.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.изменитьИмяФайлаToolStripMenuItem.Name = "изменитьИмяФайлаToolStripMenuItem";
            this.изменитьИмяФайлаToolStripMenuItem.Size = new System.Drawing.Size(223, 22);
            this.изменитьИмяФайлаToolStripMenuItem.Text = "Изменить имя файла";
            this.изменитьИмяФайлаToolStripMenuItem.Click += new System.EventHandler(this.Edit_fileName_command);
            // 
            // изменитьАдресToolStripMenuItem
            // 
            this.изменитьАдресToolStripMenuItem.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.изменитьАдресToolStripMenuItem.Name = "изменитьАдресToolStripMenuItem";
            this.изменитьАдресToolStripMenuItem.Size = new System.Drawing.Size(223, 22);
            this.изменитьАдресToolStripMenuItem.Text = "Изменить адрес файла";
            this.изменитьАдресToolStripMenuItem.Click += new System.EventHandler(this.Chahge_default_folder_command);
            // 
            // toolStripButton1
            // 
            this.toolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton1.Image = global::HomeWork22._11._21.Properties.Resources.glyphicons_halflings_108_save_as_2x;
            this.toolStripButton1.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.Size = new System.Drawing.Size(44, 44);
            this.toolStripButton1.Text = "Коллекция телевизоров с минимальной стоимостью ремонта";
            this.toolStripButton1.Click += new System.EventHandler(this.toolStripButton1_Click);
            // 
            // toolStripButton2
            // 
            this.toolStripButton2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton2.Image = global::HomeWork22._11._21.Properties.Resources.glyphicons_halflings_1_user_2x;
            this.toolStripButton2.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripButton2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton2.Name = "toolStripButton2";
            this.toolStripButton2.Size = new System.Drawing.Size(44, 44);
            this.toolStripButton2.Text = "Коллекция телевизоров, ремонтируемых выбранным мастером";
            this.toolStripButton2.Click += new System.EventHandler(this.toolStripButton2_Click);
            // 
            // toolStripButton3
            // 
            this.toolStripButton3.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton3.Image = global::HomeWork22._11._21.Properties.Resources.glyphicons_halflings_122_fullscreen_2x;
            this.toolStripButton3.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripButton3.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton3.Name = "toolStripButton3";
            this.toolStripButton3.Size = new System.Drawing.Size(44, 44);
            this.toolStripButton3.Text = "Коллекция телевизоров, с заданной диагональю экрана";
            this.toolStripButton3.Click += new System.EventHandler(this.toolStripButton3_Click);
            // 
            // toolStripButton4
            // 
            this.toolStripButton4.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton4.Image = global::HomeWork22._11._21.Properties.Resources.glyphicons_halflings_19_user_group_2x;
            this.toolStripButton4.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripButton4.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton4.Name = "toolStripButton4";
            this.toolStripButton4.Size = new System.Drawing.Size(44, 44);
            this.toolStripButton4.Text = "toolStripButton4";
            this.toolStripButton4.ToolTipText = "Выборка и вывод в отдельной форме коллекции телевизоров, заданного владельцв";
            this.toolStripButton4.Click += new System.EventHandler(this.toolStripButton4_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1372, 576);
            this.ContextMenuStrip = this.contextMenuStrip3;
            this.Controls.Add(this.Stb_saving_bar);
            this.Controls.Add(this.Lbl_header);
            this.Controls.Add(this.Lbx_main);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.menuStrip1);
            this.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "MainForm";
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.contextMenuStrip2.ResumeLayout(false);
            this.contextMenuStrip3.ResumeLayout(false);
            this.Stb_saving_bar.ResumeLayout(false);
            this.Stb_saving_bar.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem файлToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem выходToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem телевизорыToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem сортировкаToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem добавитьToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem удалитьToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem измениитьToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem oПоПроизводителюИТипуToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem поУбываниюДиагоналиЭкранаToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem поМастеруВыполняющемуРемонтToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem поВладельцуТелевизораToolStripMenuItem;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ListBox Lbx_main;
        private System.Windows.Forms.ToolStripStatusLabel Lbl_status_bar;
        private System.Windows.Forms.ToolStripMenuItem оКомпанииToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem редактироватьToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem оПрограммеToolStripMenuItem;
        private System.Windows.Forms.ToolStripStatusLabel Lbt_statusBar_address;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem пересобратьКоллекциюДанныхToolStripMenuItem;
        private System.Windows.Forms.ToolStripButton toolStripButton1;
        private System.Windows.Forms.ToolStripButton toolStripButton2;
        private System.Windows.Forms.ToolStripButton toolStripButton3;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip2;
        private System.Windows.Forms.ToolStripMenuItem удалитьToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem добавитьToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem изменитьToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem сортироватьToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem поПроизводителюИТипуToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem поУбываниюДиагоналиЭкранаToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem поМастеруВыполняющемуРемонтToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem поВладельцуТелевизораToolStripMenuItem1;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem4;
        private System.Windows.Forms.ToolStripMenuItem оПрограммеToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem выходToolStripMenuItem1;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip3;
        private System.Windows.Forms.ToolStripMenuItem оПрограммеToolStripMenuItem2;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem5;
        private System.Windows.Forms.ToolStripMenuItem выходToolStripMenuItem2;
        private System.Windows.Forms.Label Lbl_header;
        private System.Windows.Forms.ToolStripMenuItem открытьToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem сохранитьToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem6;
        private System.Windows.Forms.SaveFileDialog Sfd_main;
        private System.Windows.Forms.OpenFileDialog Ofd_main;
        private System.Windows.Forms.ToolStripMenuItem очиститьКоллекциюДанныхToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem открытьToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem сохранитьToolStripMenuItem1;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem8;
        private System.Windows.Forms.ToolStripMenuItem очиститьToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem7;
        private System.Windows.Forms.ToolStripMenuItem изменитьШрифтToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem изменитьЦветToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem9;
        private System.Windows.Forms.ColorDialog Cfd_main;
        private System.Windows.Forms.FontDialog Ffd_main;
        private System.Windows.Forms.ToolStripButton toolStripButton4;
        private System.Windows.Forms.StatusStrip Stb_saving_bar;
        private System.Windows.Forms.ToolStripStatusLabel stb_lbl_folder_path;
        private System.Windows.Forms.ToolStripDropDownButton toolStripDropDownButton1;
        private System.Windows.Forms.ToolStripMenuItem поСтоимостиРемонтаToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem изменитьИмяФайлаToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem изменитьАдресToolStripMenuItem;
        private System.Windows.Forms.ToolStripStatusLabel Ssl_info_default_save_folder;
        private System.Windows.Forms.ToolStripStatusLabel Ssl_default_path;
        private System.Windows.Forms.ToolStripStatusLabel Ssl_default_file_name;
        private System.Windows.Forms.ToolStripStatusLabel stb_lbl_default_name;
        private System.Windows.Forms.ToolStripStatusLabel Sst_change_default_path_name;
        private System.Windows.Forms.FolderBrowserDialog Fbd_main;
    }
}