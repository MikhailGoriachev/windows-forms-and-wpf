﻿using HomeWork22._11._21.Controllers;
using HomeWork22._11._21.Models;
using HomeWork22._11._21.Views;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HomeWork22._11._21.Views
{
    public partial class SelectForm : Form
    {
        private RepairShop _newList;

        public RepairShop NewList
        {
            get { return _newList; }
            set { _newList = value; }
        }

        public SelectForm(RepairShop List, string title)
        {
            InitializeComponent();
            NewList = new RepairShop();
            NewList.TeleList = List.SelectMinRepairCost();
            Text = title;
            RepairShopBind();
        }

        public SelectForm(RepairShop List, string title, string repairName)
        {
            InitializeComponent();
            NewList = new RepairShop();
            NewList.TeleList = List.SelectRepairName(repairName);
            Text = title;
            RepairShopBind();
        }

        public SelectForm(RepairShop List, string title, double diagonal)
        {
            InitializeComponent();
            NewList = new RepairShop();
            NewList.TeleList = List.SelectDiagonal(diagonal);
            Text = title;
            RepairShopBind();
        }

        public SelectForm(RepairShop List, string title, string ownerName, int n)
        {
            InitializeComponent();
            NewList = new RepairShop();
            NewList.TeleList = List.SelectOwner(ownerName);
            Text = title;
            RepairShopBind();
        }

        // Выполнение привязки к данным для Листбокса         
        private void RepairShopBind()
        {
            Lbx_main.DataSource = null;             // остановить текущую привязку
            Lbx_main.DataSource = _newList.TeleList;    // источник данных - связанная со списком коллекция
            Lbx_main.DisplayMember = "ToTableRow";  // отображаемое в списке свойство/атрибут

        } // 
    }
}
