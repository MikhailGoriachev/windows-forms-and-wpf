﻿
namespace HomeWork22._11._21.Views
{
    partial class AboutCompanyForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Lbl_nameComp = new System.Windows.Forms.Label();
            this.Lbl_addressComp = new System.Windows.Forms.Label();
            this.Txb_nameComp = new System.Windows.Forms.TextBox();
            this.Txb_addressComp = new System.Windows.Forms.TextBox();
            this.Btn_save = new System.Windows.Forms.Button();
            this.Btn_cancel = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Lbl_nameComp
            // 
            this.Lbl_nameComp.AutoSize = true;
            this.Lbl_nameComp.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Lbl_nameComp.Location = new System.Drawing.Point(26, 22);
            this.Lbl_nameComp.Name = "Lbl_nameComp";
            this.Lbl_nameComp.Size = new System.Drawing.Size(175, 18);
            this.Lbl_nameComp.TabIndex = 0;
            this.Lbl_nameComp.Text = "Название компании";
            // 
            // Lbl_addressComp
            // 
            this.Lbl_addressComp.AutoSize = true;
            this.Lbl_addressComp.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Lbl_addressComp.Location = new System.Drawing.Point(26, 112);
            this.Lbl_addressComp.Name = "Lbl_addressComp";
            this.Lbl_addressComp.Size = new System.Drawing.Size(144, 18);
            this.Lbl_addressComp.TabIndex = 1;
            this.Lbl_addressComp.Text = "Адрес компании";
            // 
            // Txb_nameComp
            // 
            this.Txb_nameComp.Location = new System.Drawing.Point(30, 54);
            this.Txb_nameComp.Name = "Txb_nameComp";
            this.Txb_nameComp.Size = new System.Drawing.Size(409, 21);
            this.Txb_nameComp.TabIndex = 2;
            // 
            // Txb_addressComp
            // 
            this.Txb_addressComp.Location = new System.Drawing.Point(30, 161);
            this.Txb_addressComp.Name = "Txb_addressComp";
            this.Txb_addressComp.Size = new System.Drawing.Size(409, 21);
            this.Txb_addressComp.TabIndex = 3;
            // 
            // Btn_save
            // 
            this.Btn_save.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.Btn_save.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Btn_save.Location = new System.Drawing.Point(47, 224);
            this.Btn_save.Name = "Btn_save";
            this.Btn_save.Size = new System.Drawing.Size(143, 49);
            this.Btn_save.TabIndex = 4;
            this.Btn_save.Text = "Сохранить";
            this.Btn_save.UseVisualStyleBackColor = true;
            this.Btn_save.Click += new System.EventHandler(this.Btn_save_Click);
            // 
            // Btn_cancel
            // 
            this.Btn_cancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.Btn_cancel.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Btn_cancel.Location = new System.Drawing.Point(276, 224);
            this.Btn_cancel.Name = "Btn_cancel";
            this.Btn_cancel.Size = new System.Drawing.Size(143, 49);
            this.Btn_cancel.TabIndex = 5;
            this.Btn_cancel.Text = "Отменить";
            this.Btn_cancel.UseVisualStyleBackColor = true;
            // 
            // AboutCompanyForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(471, 306);
            this.Controls.Add(this.Btn_cancel);
            this.Controls.Add(this.Btn_save);
            this.Controls.Add(this.Txb_addressComp);
            this.Controls.Add(this.Txb_nameComp);
            this.Controls.Add(this.Lbl_addressComp);
            this.Controls.Add(this.Lbl_nameComp);
            this.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "AboutCompanyForm";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Редактировать данные о компании";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Lbl_nameComp;
        private System.Windows.Forms.Label Lbl_addressComp;
        private System.Windows.Forms.TextBox Txb_nameComp;
        private System.Windows.Forms.TextBox Txb_addressComp;
        private System.Windows.Forms.Button Btn_save;
        private System.Windows.Forms.Button Btn_cancel;
    }
}