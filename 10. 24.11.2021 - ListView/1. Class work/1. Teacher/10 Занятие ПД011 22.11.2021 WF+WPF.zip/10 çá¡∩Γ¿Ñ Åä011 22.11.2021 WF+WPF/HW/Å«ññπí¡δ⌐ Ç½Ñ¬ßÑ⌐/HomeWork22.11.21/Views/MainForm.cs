﻿using HomeWork22._11._21.Controllers;
using HomeWork22._11._21.Models;
using HomeWork22._11._21.Views;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;


namespace HomeWork22._11._21
{
    public partial class MainForm : Form
    {
        // класс для телемастерской
        //private RepairShop RepairShop = new RepairShop() { RepairShopName = "Электрон", RepairShopAddress="ул.Артема д.12" };

        //public RepairShop GetRepairShop { get; private set; }

        private RepairShop _repairShop;

        public RepairShop RepairShop
        {
            get { return _repairShop; }
            set { _repairShop = value; }
        }

        private string serialiseDefaultName = "Автосохранение.json";
        private string serialiseDefaultPath = "C:\\RepairShop\\";

        public MainForm()
        {
            InitializeComponent();
            _repairShop = new RepairShop() { RepairShopName = "Электрон", RepairShopAddress = "ул.Артема д.12" };
            Text = "Ремонт телевизоров " + RepairShop.RepairShopName;
            RepairShop.CreateTVList();
            RepairShopBind();
            Lbl_status_bar.Text += RepairShop.Count().ToString();
            Lbt_statusBar_address.Text = RepairShop.RepairShopAddress;

            Sfd_main.InitialDirectory = serialiseDefaultPath;          
            stb_lbl_folder_path.Text = serialiseDefaultPath;
            stb_lbl_default_name.Text = serialiseDefaultName;
            Sfd_main.RestoreDirectory = false;
            // назначить обработчик события выбора элемента в ListBox
            Lbx_main.SelectedIndexChanged += Lbx_main_SelectedIndexChanged;

        }

        private void Lbx_main_SelectedIndexChanged(object sender, EventArgs e)
        {
            // возращаем выбраный элемент из коллекции
            Television tv = (Television)Lbx_main.SelectedItem;
        }

        // Выполнение привязки к данным для Листбокса         
        private void RepairShopBind()
        {
            Lbx_main.DataSource = null;             // остановить текущую привязку
            Lbx_main.DataSource = RepairShop.TeleList;    // источник данных - связанная со списком коллекция
            Lbx_main.DisplayMember = "ToTableRow";  // отображаемое в списке свойство/атрибут

        } // 

        // Выполнение привязки к данным для статусбара         
        private void DefaultPathNameBind()
        {
            stb_lbl_folder_path.Text = serialiseDefaultPath;
            stb_lbl_default_name.Text = serialiseDefaultName;

        } // 

        // сохранение и проверка директории
        private void CheckAndSerialize()
        {
            DirectoryInfo dirInfo = new DirectoryInfo(serialiseDefaultPath);
            if (!dirInfo.Exists)
            {
                dirInfo.Create();
            }
            _repairShop.Serialize(serialiseDefaultPath + "\\" + serialiseDefaultName);


        } // 


        private void добавитьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            TVForm tvform = new TVForm();
            DialogResult dialogResult = tvform.ShowDialog();

            // если окно закрыто не по кнопке "Добавить" - молча уходим
            if (dialogResult != DialogResult.OK) return;

            // получить данные из свойства формы
            Television tv = tvform.Television;
            RepairShop.Add(tv);

            // обновить привязку
            RepairShopBind();

            // сохранение
            CheckAndSerialize();


        }

        private void измениитьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // если нет выбранного работника - уходим
            if (Lbx_main.SelectedIndex < 0)
                return;

            // передача данных в форму
            TVForm tvform = new TVForm("Редактировать данные телевизора", "Сохранить");
            tvform.Television = (Television)Lbx_main.SelectedItem;

            if (tvform.ShowDialog() != DialogResult.OK) return;

            // получить данные
            RepairShop.TeleList[Lbx_main.SelectedIndex] = tvform.Television;

            // обновить привязку
            RepairShopBind();

            // сохранение
            CheckAndSerialize();
        }

        private void редактироватьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AboutCompanyForm compForm = new AboutCompanyForm();
            compForm.RepairShop = RepairShop;

            if (compForm.ShowDialog() != DialogResult.OK) return;

            RepairShop.RepairShopName = compForm.RepairShop.RepairShopName;
            RepairShop.RepairShopAddress = compForm.RepairShop.RepairShopAddress;
            Text = "Ремонт телевизоров " + RepairShop.RepairShopName;
            Lbt_statusBar_address.Text = RepairShop.RepairShopAddress;

            // сохранение
            CheckAndSerialize();
        }

        private void oПоПроизводителюИТипуToolStripMenuItem_Click(object sender, EventArgs e)
        {
            RepairShop.SortByType();
            RepairShopBind();

        }

        private void поУбываниюДиагоналиЭкранаToolStripMenuItem_Click(object sender, EventArgs e)
        {
            RepairShop.SortByDiagonal();
            RepairShopBind();

        }

        private void поМастеруВыполняющемуРемонтToolStripMenuItem_Click(object sender, EventArgs e)
        {
            RepairShop.SortByRepairName();
            RepairShopBind();

        }

        private void поВладельцуТелевизораToolStripMenuItem_Click(object sender, EventArgs e)
        {
            RepairShop.SortByOwnerName();
            RepairShopBind();

        }

        private void поСтоимостиРемонтаToolStripMenuItem_Click(object sender, EventArgs e)
        {
            RepairShop.SortByPriceRepair();
            RepairShopBind();

        }

        // пересобрать коллекцию телевизоров
        private void пересобратьКоллекциюДанныхToolStripMenuItem_Click(object sender, EventArgs e)
        {
            RepairShop.CreateTVList();
            RepairShopBind();
        }

        // вызов о программе
        private void оПрограммеToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AboutProgramm aboutprg = new AboutProgramm();
            aboutprg.ShowDialog();  // модальное отображение формы
        }

        // комманда удалить
        private void удалитьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Lbx_main.SelectedIndex < 0)
                return;

            // удаление записи данных 
            RepairShop.TeleList.Remove((Television)Lbx_main.SelectedItem);
            RepairShopBind();

            // сохранение
            CheckAndSerialize();

        }

        // выход
        private void Exit_Command(object sender, EventArgs e) =>
           Application.Exit();

        // очистить данные списка телевизоров
        private void Clear_Command(object sender, EventArgs e)
        {
            _repairShop.Clear();
            // обновить привязку
            RepairShopBind();
        }

        //•	Выборка и вывод в отдельной форме коллекции телевизоров с минимальной стоимостью ремонта
        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            SelectForm selectform = new SelectForm(_repairShop, toolStripButton1.Text);
            DialogResult dialogResult = selectform.ShowDialog();

            // обновить привязку
            RepairShopBind();
        }

        //•	Выборка и вывод в отдельной форме коллекции телевизоров, ремонтируемых выбранным мастером
        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            // непосредственно выбор мастера
            SelectChoiseSearch choiseSearch = new SelectChoiseSearch(toolStripButton2.Text, "default");
            DialogResult dialogResultSearch = choiseSearch.ShowDialog();

            if (choiseSearch.ShowDialog() != DialogResult.OK) return;

            // сама выборка
            SelectForm selectform = new SelectForm(_repairShop, toolStripButton2.Text, choiseSearch.Choice.repairName);
            DialogResult dialogResult = selectform.ShowDialog();

            // обновить привязку
            RepairShopBind();
        }

        //•	Выборка и вывод в отдельной форме коллекции телевизоров, с заданной диагональю экрана 
        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            // значение диагонали
            SelectChoiseSearch choiseSearch = new SelectChoiseSearch(toolStripButton2.Text, 1);
            DialogResult dialogResultSearch = choiseSearch.ShowDialog();

            if (choiseSearch.DialogResult != DialogResult.OK) return;

            // выборка
            SelectForm selectform = new SelectForm(_repairShop, toolStripButton3.Text, choiseSearch.Choice.diagonal);
            DialogResult dialogResult = selectform.ShowDialog();

            // обновить привязку
            RepairShopBind();
        }

        // Выборка и вывод в отдельной форме коллекции телевизоров, заданного владельцв
        private void toolStripButton4_Click(object sender, EventArgs e)
        {
            // значение имени владельца
            SelectOwner choiseSearch = new SelectOwner(Television.ownerNames);
            DialogResult dialogResultSearch = choiseSearch.ShowDialog();

            if (choiseSearch.DialogResult != DialogResult.OK) return;

            // выборка
            SelectForm selectform = new SelectForm(_repairShop, toolStripButton4.Text, choiseSearch.OwnerName, 4);
            DialogResult dialogResult = selectform.ShowDialog();

            // обновить привязку
            RepairShopBind();
        }

        // изменение цвета фона
        private void Edit_color_background_Command(object sender, EventArgs e)
        {
            
            if (Cfd_main.ShowDialog() == DialogResult.OK)
            {
                Lbx_main.BackColor = Cfd_main.Color;
            } 

            // обновить привязку
            RepairShopBind();
        }

        // изменение цвета фона
        private void Edit_font_Command(object sender, EventArgs e)
        {

            Ffd_main.ShowColor = true;
            if (Ffd_main.ShowDialog() == DialogResult.OK)
            {
                Lbx_main.Font = Ffd_main.Font;

               
            } 

            // обновить привязку
            RepairShopBind();
        }

        // сериализация в формате JSON
        private void Save_command(object sender, EventArgs e)
        {
            // вызов диалога сохранения файла
            
                Sfd_main.Title = "Сохранение результатов";
                Sfd_main.InitialDirectory = "..\\..\\";
                Sfd_main.Filter = "Файлы JSON(*.json)|*.json";
                Sfd_main.FilterIndex = 1;

                if (Sfd_main.ShowDialog() == DialogResult.OK)
                {
                    _repairShop.Serialize(Sfd_main.FileName);
                    stb_lbl_folder_path.Text= "Путь для сохранения: ";
                    stb_lbl_folder_path.Text += Sfd_main.FileName;
                } // if

            // обновить привязку
            RepairShopBind();
        }

        // десериализация из формата JSON
        private void Open_command(object sender, EventArgs e)
        {
            // вызов диалога сохранения файла

            Ofd_main.Title = "Открыть ";
            Ofd_main.InitialDirectory = "../../";
            Ofd_main.Filter = "Файлы JSON(*.json)|*.json";
            Ofd_main.FilterIndex = 1;

            _repairShop.Clear();
            if (Ofd_main.ShowDialog() == DialogResult.OK)
            {
                _repairShop = RepairShop.Deserialize(Ofd_main.FileName);
            } // if

            // обновить привязку
            RepairShopBind();

        }

        // дериктория для дефолтной записи
        private void Chahge_default_folder_command(object sender, EventArgs e)
        {
            Fbd_main.Description = "Выберите папку для автосохранения";
           
            if (Fbd_main.ShowDialog() == DialogResult.OK)
            {
                
                serialiseDefaultPath = Fbd_main.SelectedPath;
                // обновить привязку
                DefaultPathNameBind();
                
            } 
                       
        }

        // изменения имени файла для автосохранения
        private void Edit_fileName_command(object sender, EventArgs e)
        {
            EditDefaultFileName editForm = new EditDefaultFileName();
            DialogResult dialogResult = editForm.ShowDialog();

            // если окно закрыто не по кнопке "Добавить" - молча уходим
            if (dialogResult != DialogResult.OK) return;

            // получить данные из свойства формы
            serialiseDefaultName = editForm.NewDefaultFileName;
            serialiseDefaultName += ".json";
            // обновить привязку
            DefaultPathNameBind();
        }



    }
}
