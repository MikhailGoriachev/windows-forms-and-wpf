﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HomeWork22._11._21.Controllers
{
    // Класс для управления телемастерской
    class RepairShopControl
    {

        // Объект мастреской
        private RepairShop _repairShop;

        public RepairShop RepairShop
        {
            get => _repairShop;
            private set => _repairShop = value;
        } // RepairShop


        // конструкторы
        public RepairShopControl() : this(new RepairShop()) { }
        public RepairShopControl(RepairShop repairShop)
        {
            _repairShop = repairShop;
        } 


       









    }
}
