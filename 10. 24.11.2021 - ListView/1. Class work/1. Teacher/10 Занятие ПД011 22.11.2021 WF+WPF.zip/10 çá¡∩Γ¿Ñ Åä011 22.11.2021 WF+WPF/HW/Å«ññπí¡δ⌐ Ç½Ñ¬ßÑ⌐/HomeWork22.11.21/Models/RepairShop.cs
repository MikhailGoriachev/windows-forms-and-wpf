﻿using HomeWork22._11._21.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Json;
using System.Text;
using System.Threading.Tasks;


namespace HomeWork22._11._21.Controllers
{
    // класс ремонтной мастреской 
    [Serializable]
    [DataContract]
    public class RepairShop
    {
        [DataMember]
        public List<Television> TeleList = new List<Television>();

        // название ремонтной мастерской
        [DataMember]
        private string _repairShopName;
        public string RepairShopName
        {
            get { return _repairShopName; }
            set
            {
                if (string.IsNullOrWhiteSpace(value))
                    throw new Exception("RepairShop: ошибка имени мастерской");
                _repairShopName = value;
            }
        }

        // название ремонтной мастерской
        [DataMember]
        private string _repairShopAddress;
        public string RepairShopAddress
        {
            get { return _repairShopAddress; }
            set
            {
                if (string.IsNullOrWhiteSpace(value))
                    throw new Exception("RepairShop: ошибка адреса мастерской");
                _repairShopAddress = value;
            }
        }

        // Начальное формирование данных ремонтной мастерской
     
        public void CreateTVList()
        {
            TeleList.Clear();
            for (int i = 0; i < Utils.GetRandom(12, 16); i++)
                TeleList.Add(Television.CreateTV());
        }


        // Добавление элемента 
        public void Add(Television tv)
        {
            TeleList.Add(tv);
        }

        // размер массива
        public int Count()
        {
            return TeleList.Count();
        }

        // очистка массива
        public void Clear()
        {
             TeleList.Clear();            
        }



        /*
         	Упорядочивание коллекции телевизоров
            	По производителю и типу
            	По убыванию диагонали экрана
            	По мастеру, выполняющему ремонт
            	По владельцу телевизора

         */
        public void SortByType()
        {
            TeleList.Sort((a, b) => a.Type.CompareTo(b.Type));
        }

        public void SortByDiagonal()
        {
            TeleList.Sort((a, b) => b.Diagonal.CompareTo(a.Diagonal));
        }

        public void SortByRepairName()
        {
            TeleList.Sort((a, b) => a.RepairerName.CompareTo(b.RepairerName));
        }

        public void SortByOwnerName()
        {
            TeleList.Sort((a, b) => a.OwnerName.CompareTo(b.OwnerName));
        }

        public void SortByPriceRepair()
        {
            TeleList.Sort((a, b) => b.RepairCost.CompareTo(a.RepairCost));
        }

        // Выборка и вывод в отдельной форме коллекции телевизоров с минимальной стоимостью ремонта
        public List<Television> SelectMinRepairCost()
        {
            double minRepairCost = TeleList.Min(a => a.RepairCost);
            return TeleList.FindAll((a) => a.RepairCost == minRepairCost);
        }

        //	Выборка и вывод в отдельной форме коллекции телевизоров, ремонтируемых выбранным мастером
        public List<Television> SelectRepairName(string repairName)
        {
            return TeleList.FindAll((a) => a.RepairerName == repairName);
        }

        // Выборка и вывод в отдельной форме коллекции телевизоров, с заданной диагональю экрана 
        public List<Television> SelectDiagonal(double diagonal)
        {
            return TeleList.FindAll((a) => a.Diagonal == diagonal);
        }

        // Выборка и вывод в отдельной форме коллекции телевизоров, с заданным владельцем
        public List<Television> SelectOwner(string owner)
        {
            return TeleList.FindAll((a) => a.OwnerName == owner);
        }


        // сериализация
        public void Serialize(string fileName)
        {
            DataContractJsonSerializer jsonFormatter = new DataContractJsonSerializer(typeof(RepairShop));

            using (FileStream fs = new FileStream(fileName, FileMode.Create))
            {
                jsonFormatter.WriteObject(fs, this);
            }
        }

        // десериализация - удобно выполнять статическим методом
        public static RepairShop Deserialize(string fileName)
        {
            DataContractJsonSerializer jsonFormatter = new DataContractJsonSerializer(typeof(RepairShop));
            RepairShop newListrequests = new RepairShop();
            using (FileStream fs = new FileStream(fileName, FileMode.OpenOrCreate))
            {
                newListrequests = (RepairShop)jsonFormatter.ReadObject(fs);
            }

            return newListrequests;

        }



    }
}
