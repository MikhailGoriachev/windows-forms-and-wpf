﻿namespace WF_Televisions.Forms
{
    partial class AddObj_form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.GbxAddEditTV = new System.Windows.Forms.GroupBox();
            this.Cbx_Defect = new System.Windows.Forms.ComboBox();
            this.Tbx_Owner = new System.Windows.Forms.TextBox();
            this.lbl_defect = new System.Windows.Forms.Label();
            this.Cbx_Repairer = new System.Windows.Forms.ComboBox();
            this.LblTvDiagonal = new System.Windows.Forms.Label();
            this.Tbx_Diagonal = new System.Windows.Forms.TextBox();
            this.Cbx_Type = new System.Windows.Forms.ComboBox();
            this.Cbx_Brand = new System.Windows.Forms.ComboBox();
            this.Gbx_ReadyObject = new System.Windows.Forms.GroupBox();
            this.Tbx_EndedObj = new System.Windows.Forms.TextBox();
            this.Gbx_Type = new System.Windows.Forms.GroupBox();
            this.Pcb_Type = new System.Windows.Forms.PictureBox();
            this.label3 = new System.Windows.Forms.Label();
            this.Tbx_Price = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.LblTvType = new System.Windows.Forms.Label();
            this.LblTvBrand = new System.Windows.Forms.Label();
            this.BtnAdd = new System.Windows.Forms.Button();
            this.BtnClose = new System.Windows.Forms.Button();
            this.ErpOwnerField = new System.Windows.Forms.ErrorProvider(this.components);
            this.ErpDiagonal = new System.Windows.Forms.ErrorProvider(this.components);
            this.ErpPrice = new System.Windows.Forms.ErrorProvider(this.components);
            this.GbxAddEditTV.SuspendLayout();
            this.Gbx_ReadyObject.SuspendLayout();
            this.Gbx_Type.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Pcb_Type)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ErpOwnerField)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ErpDiagonal)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ErpPrice)).BeginInit();
            this.SuspendLayout();
            // 
            // GbxAddEditTV
            // 
            this.GbxAddEditTV.Controls.Add(this.Cbx_Defect);
            this.GbxAddEditTV.Controls.Add(this.Tbx_Owner);
            this.GbxAddEditTV.Controls.Add(this.lbl_defect);
            this.GbxAddEditTV.Controls.Add(this.Cbx_Repairer);
            this.GbxAddEditTV.Controls.Add(this.LblTvDiagonal);
            this.GbxAddEditTV.Controls.Add(this.Tbx_Diagonal);
            this.GbxAddEditTV.Controls.Add(this.Cbx_Type);
            this.GbxAddEditTV.Controls.Add(this.Cbx_Brand);
            this.GbxAddEditTV.Controls.Add(this.Gbx_ReadyObject);
            this.GbxAddEditTV.Controls.Add(this.Gbx_Type);
            this.GbxAddEditTV.Controls.Add(this.label3);
            this.GbxAddEditTV.Controls.Add(this.Tbx_Price);
            this.GbxAddEditTV.Controls.Add(this.label2);
            this.GbxAddEditTV.Controls.Add(this.label1);
            this.GbxAddEditTV.Controls.Add(this.LblTvType);
            this.GbxAddEditTV.Controls.Add(this.LblTvBrand);
            this.GbxAddEditTV.Location = new System.Drawing.Point(35, 43);
            this.GbxAddEditTV.Name = "GbxAddEditTV";
            this.GbxAddEditTV.Size = new System.Drawing.Size(732, 568);
            this.GbxAddEditTV.TabIndex = 0;
            this.GbxAddEditTV.TabStop = false;
            this.GbxAddEditTV.Text = "Добавление телевизора";
            // 
            // Cbx_Defect
            // 
            this.Cbx_Defect.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Cbx_Defect.FormattingEnabled = true;
            this.Cbx_Defect.Location = new System.Drawing.Point(34, 232);
            this.Cbx_Defect.Name = "Cbx_Defect";
            this.Cbx_Defect.Size = new System.Drawing.Size(258, 23);
            this.Cbx_Defect.TabIndex = 23;
            this.Cbx_Defect.SelectedIndexChanged += new System.EventHandler(this.Cbx_IndexChanged);
            // 
            // Tbx_Owner
            // 
            this.Tbx_Owner.Location = new System.Drawing.Point(30, 301);
            this.Tbx_Owner.Name = "Tbx_Owner";
            this.Tbx_Owner.Size = new System.Drawing.Size(258, 23);
            this.Tbx_Owner.TabIndex = 21;
            this.Tbx_Owner.Tag = "ErpOwnerField";
            this.Tbx_Owner.Validating += new System.ComponentModel.CancelEventHandler(this.TextBoxOwner_Validating);
            // 
            // lbl_defect
            // 
            this.lbl_defect.Font = new System.Drawing.Font("Consolas", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lbl_defect.Location = new System.Drawing.Point(34, 202);
            this.lbl_defect.Name = "lbl_defect";
            this.lbl_defect.Size = new System.Drawing.Size(259, 27);
            this.lbl_defect.TabIndex = 22;
            this.lbl_defect.Text = "Введите дефект";
            this.lbl_defect.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Cbx_Repairer
            // 
            this.Cbx_Repairer.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Cbx_Repairer.FormattingEnabled = true;
            this.Cbx_Repairer.Location = new System.Drawing.Point(30, 366);
            this.Cbx_Repairer.Name = "Cbx_Repairer";
            this.Cbx_Repairer.Size = new System.Drawing.Size(258, 23);
            this.Cbx_Repairer.TabIndex = 20;
            this.Cbx_Repairer.SelectedIndexChanged += new System.EventHandler(this.Cbx_IndexChanged);
            // 
            // LblTvDiagonal
            // 
            this.LblTvDiagonal.Font = new System.Drawing.Font("Consolas", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblTvDiagonal.Location = new System.Drawing.Point(30, 406);
            this.LblTvDiagonal.Name = "LblTvDiagonal";
            this.LblTvDiagonal.Size = new System.Drawing.Size(259, 27);
            this.LblTvDiagonal.TabIndex = 10;
            this.LblTvDiagonal.Text = "Введите диагональ";
            this.LblTvDiagonal.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Tbx_Diagonal
            // 
            this.Tbx_Diagonal.Location = new System.Drawing.Point(30, 436);
            this.Tbx_Diagonal.Name = "Tbx_Diagonal";
            this.Tbx_Diagonal.Size = new System.Drawing.Size(258, 23);
            this.Tbx_Diagonal.TabIndex = 2;
            this.Tbx_Diagonal.Tag = "ErpDiagonal";
            this.Tbx_Diagonal.TextChanged += new System.EventHandler(this.Tbx_Changed);
            this.Tbx_Diagonal.Validating += new System.ComponentModel.CancelEventHandler(this.TextBoxDouble_Validating);
            // 
            // Cbx_Type
            // 
            this.Cbx_Type.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Cbx_Type.FormattingEnabled = true;
            this.Cbx_Type.Location = new System.Drawing.Point(36, 158);
            this.Cbx_Type.Name = "Cbx_Type";
            this.Cbx_Type.Size = new System.Drawing.Size(258, 23);
            this.Cbx_Type.TabIndex = 18;
            this.Cbx_Type.SelectedIndexChanged += new System.EventHandler(this.Cbx_Type_IndexChanged);
            // 
            // Cbx_Brand
            // 
            this.Cbx_Brand.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Cbx_Brand.FormattingEnabled = true;
            this.Cbx_Brand.Location = new System.Drawing.Point(35, 87);
            this.Cbx_Brand.Name = "Cbx_Brand";
            this.Cbx_Brand.Size = new System.Drawing.Size(258, 23);
            this.Cbx_Brand.TabIndex = 17;
            this.Cbx_Brand.SelectedIndexChanged += new System.EventHandler(this.Cbx_IndexChanged);
            // 
            // Gbx_ReadyObject
            // 
            this.Gbx_ReadyObject.Controls.Add(this.Tbx_EndedObj);
            this.Gbx_ReadyObject.Location = new System.Drawing.Point(364, 267);
            this.Gbx_ReadyObject.Name = "Gbx_ReadyObject";
            this.Gbx_ReadyObject.Size = new System.Drawing.Size(330, 212);
            this.Gbx_ReadyObject.TabIndex = 16;
            this.Gbx_ReadyObject.TabStop = false;
            this.Gbx_ReadyObject.Text = "Сформированный обект";
            // 
            // Tbx_EndedObj
            // 
            this.Tbx_EndedObj.Location = new System.Drawing.Point(22, 30);
            this.Tbx_EndedObj.Multiline = true;
            this.Tbx_EndedObj.Name = "Tbx_EndedObj";
            this.Tbx_EndedObj.ReadOnly = true;
            this.Tbx_EndedObj.Size = new System.Drawing.Size(289, 166);
            this.Tbx_EndedObj.TabIndex = 0;
            // 
            // Gbx_Type
            // 
            this.Gbx_Type.Controls.Add(this.Pcb_Type);
            this.Gbx_Type.Location = new System.Drawing.Point(364, 22);
            this.Gbx_Type.Name = "Gbx_Type";
            this.Gbx_Type.Size = new System.Drawing.Size(330, 233);
            this.Gbx_Type.TabIndex = 15;
            this.Gbx_Type.TabStop = false;
            this.Gbx_Type.Text = "Тип матрицы ";
            // 
            // Pcb_Type
            // 
            this.Pcb_Type.Location = new System.Drawing.Point(6, 22);
            this.Pcb_Type.Name = "Pcb_Type";
            this.Pcb_Type.Size = new System.Drawing.Size(318, 205);
            this.Pcb_Type.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.Pcb_Type.TabIndex = 9;
            this.Pcb_Type.TabStop = false;
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("Consolas", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.Location = new System.Drawing.Point(30, 474);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(259, 27);
            this.label3.TabIndex = 14;
            this.label3.Text = "Введите стоимости";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Tbx_Price
            // 
            this.Tbx_Price.Location = new System.Drawing.Point(30, 504);
            this.Tbx_Price.Name = "Tbx_Price";
            this.Tbx_Price.Size = new System.Drawing.Size(258, 23);
            this.Tbx_Price.TabIndex = 13;
            this.Tbx_Price.Tag = "ErpPrice";
            this.Tbx_Price.TextChanged += new System.EventHandler(this.Tbx_Changed);
            this.Tbx_Price.Validating += new System.ComponentModel.CancelEventHandler(this.TextBoxDouble_Validating);
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Consolas", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(30, 336);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(259, 27);
            this.label2.TabIndex = 12;
            this.label2.Text = "Введите мастера";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Consolas", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(30, 267);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(259, 27);
            this.label1.TabIndex = 11;
            this.label1.Text = "Введите владельца";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // LblTvType
            // 
            this.LblTvType.Font = new System.Drawing.Font("Consolas", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblTvType.Location = new System.Drawing.Point(35, 128);
            this.LblTvType.Name = "LblTvType";
            this.LblTvType.Size = new System.Drawing.Size(259, 27);
            this.LblTvType.TabIndex = 6;
            this.LblTvType.Text = "Введите тип";
            this.LblTvType.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // LblTvBrand
            // 
            this.LblTvBrand.Font = new System.Drawing.Font("Consolas", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblTvBrand.Location = new System.Drawing.Point(30, 57);
            this.LblTvBrand.Name = "LblTvBrand";
            this.LblTvBrand.Size = new System.Drawing.Size(259, 27);
            this.LblTvBrand.TabIndex = 5;
            this.LblTvBrand.Text = "Введите бренд";
            this.LblTvBrand.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // BtnAdd
            // 
            this.BtnAdd.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.BtnAdd.Font = new System.Drawing.Font("Consolas", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BtnAdd.Location = new System.Drawing.Point(51, 617);
            this.BtnAdd.Name = "BtnAdd";
            this.BtnAdd.Size = new System.Drawing.Size(295, 46);
            this.BtnAdd.TabIndex = 8;
            this.BtnAdd.Text = "Добавить";
            this.BtnAdd.UseVisualStyleBackColor = true;
            // 
            // BtnClose
            // 
            this.BtnClose.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.BtnClose.Font = new System.Drawing.Font("Consolas", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BtnClose.Location = new System.Drawing.Point(421, 617);
            this.BtnClose.Name = "BtnClose";
            this.BtnClose.Size = new System.Drawing.Size(295, 46);
            this.BtnClose.TabIndex = 7;
            this.BtnClose.Text = "Закрыть";
            this.BtnClose.UseVisualStyleBackColor = true;
            // 
            // ErpOwnerField
            // 
            this.ErpOwnerField.ContainerControl = this;
            // 
            // ErpDiagonal
            // 
            this.ErpDiagonal.ContainerControl = this;
            // 
            // ErpPrice
            // 
            this.ErpPrice.ContainerControl = this;
            // 
            // AddObj_form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(799, 675);
            this.Controls.Add(this.GbxAddEditTV);
            this.Controls.Add(this.BtnAdd);
            this.Controls.Add(this.BtnClose);
            this.Font = new System.Drawing.Font("Consolas", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Name = "AddObj_form";
            this.Text = "Добавление телевизора";
            this.Load += new System.EventHandler(this.AddObj_form_Load);
            this.GbxAddEditTV.ResumeLayout(false);
            this.GbxAddEditTV.PerformLayout();
            this.Gbx_ReadyObject.ResumeLayout(false);
            this.Gbx_ReadyObject.PerformLayout();
            this.Gbx_Type.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.Pcb_Type)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ErpOwnerField)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ErpDiagonal)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ErpPrice)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox GbxAddEditTV;
        private System.Windows.Forms.PictureBox Pcb_Type;
        private System.Windows.Forms.Button BtnAdd;
        private System.Windows.Forms.Button BtnClose;
        private System.Windows.Forms.Label LblTvType;
        private System.Windows.Forms.Label LblTvBrand;
        private System.Windows.Forms.TextBox Tbx_Diagonal;
        private System.Windows.Forms.Label LblTvDiagonal;
        private System.Windows.Forms.ComboBox Cbx_Brand;
        private System.Windows.Forms.GroupBox Gbx_ReadyObject;
        private System.Windows.Forms.TextBox Tbx_EndedObj;
        private System.Windows.Forms.GroupBox Gbx_Type;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox Tbx_Price;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox Tbx_Owner;
        private System.Windows.Forms.ComboBox Cbx_Repairer;
        private System.Windows.Forms.ComboBox Cbx_Type;
        private System.Windows.Forms.ErrorProvider ErpOwnerField;
        private System.Windows.Forms.ErrorProvider ErpDiagonal;
        private System.Windows.Forms.ErrorProvider ErpPrice;
        private System.Windows.Forms.ComboBox Cbx_Defect;
        private System.Windows.Forms.Label lbl_defect;
    }
}