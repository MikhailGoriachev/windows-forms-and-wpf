﻿namespace WF_Televisions.Forms
{
    partial class AboutForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AboutForm));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.Btn_Close = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.Tmr_Close = new System.Windows.Forms.Timer(this.components);
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.listBox1);
            this.groupBox1.Font = new System.Drawing.Font("Consolas", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.groupBox1.Location = new System.Drawing.Point(14, 14);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(890, 492);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Задание";
            // 
            // listBox1
            // 
            this.listBox1.Font = new System.Drawing.Font("Consolas", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 18;
            this.listBox1.Items.AddRange(new object[] {
            resources.GetString("listBox1.Items"),
            "Разработайте класс Television (производитель и тип телевизора, диагональ экрана, " +
                "строка с описанием дефекта, фамилия и инициалами мастера, фамилия и инициалы вла" +
                "дельца, стоимость ремонта).",
            "Разработайте класс RepairShop (коллекция Television, название ремонтной мастерско" +
                "й, адрес ремонтной мастерской).",
            "Приложение должно иметь следующий функционал (при помощи пунктов меню, контекстно" +
                "го меню, кнопок панели инструментов):",
            "",
            "•Начальное формирование данных ремонтной мастерской (коллекция телевизоров от 12 " +
                "до 15 штук)",
            "•Сохранение данных ремонтной мастерской в выбранном файле – сериализация в формат" +
                "е JSON. ",
            "    Файл для сохранения выбирать стандартным диалогом ",
            "•Загрузка данных ремонтной мастерской из выбранного файла в – десериализация форм" +
                "ате JSON. ",
            "   Файл для загрузки выбирать стандартным диалогом",
            "•Изменение шрифта для отображения коллекции телевизоров в ListBox главного окна. " +
                "",
            "   Выбор шрифта выполняйте при помощи стандартного диалога",
            "•Изменение фона ListBox отображения коллекции телевизоров в главной форме при пом" +
                "ощи стандартного диалога ",
            "•Добавление телевизора в коллекцию, сериализация данных",
            "•Удаление телевизора из коллекции – выдача телевизора владельцу после ремонта, се" +
                "риализация данных",
            "•Редактирование выбранного телевизора в отдельной форме, сериализация данных",
            "•Редактирование данных ремонтной мастерской, сериализация данных",
            "•Упорядочивание коллекции телевизоров:",
            "\toПо производителю и типу",
            "\toПо убыванию диагонали экрана",
            "\toПо мастеру, выполняющему ремонт",
            "\toПо владельцу телевизора",
            "\toПо стоимости ремонта",
            "•Выборка и вывод в отдельной форме коллекции телевизоров с минимальной стоимостью" +
                " ремонта",
            "•Выборка и вывод в отдельной форме коллекции телевизоров, ремонтируемых выбранным" +
                " мастером",
            "•Выборка и вывод в отдельной форме коллекции телевизоров, с заданной диагональю э" +
                "крана ",
            "•Выборка и вывод в отдельной форме коллекции телевизоров, заданного владельцв",
            "",
            "В меню и контекстных меню (ListBox, MainForm) включите команды выхода, вывода окн" +
                "а со сведениями о программе и ее разработчике"});
            this.listBox1.Location = new System.Drawing.Point(19, 20);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(853, 454);
            this.listBox1.TabIndex = 0;
            // 
            // Btn_Close
            // 
            this.Btn_Close.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.Btn_Close.Font = new System.Drawing.Font("Consolas", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Btn_Close.Location = new System.Drawing.Point(720, 512);
            this.Btn_Close.Name = "Btn_Close";
            this.Btn_Close.Size = new System.Drawing.Size(184, 39);
            this.Btn_Close.TabIndex = 1;
            this.Btn_Close.Text = "Закрыть";
            this.Btn_Close.UseVisualStyleBackColor = false;
            this.Btn_Close.Click += new System.EventHandler(this.Btn_Close_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(30, 524);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(266, 15);
            this.label1.TabIndex = 2;
            this.label1.Text = "Вагнер Владислав. КА ШАГ, Донецк 2021\r\n";
            // 
            // Tmr_Close
            // 
            this.Tmr_Close.Interval = 10000;
            this.Tmr_Close.Tick += new System.EventHandler(this.Btn_Close_Click);
            // 
            // AboutForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(933, 554);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Btn_Close);
            this.Controls.Add(this.groupBox1);
            this.Font = new System.Drawing.Font("Consolas", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "AboutForm";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.Text = "AboutForm";
            this.groupBox1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Button Btn_Close;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Timer Tmr_Close;
    }
}