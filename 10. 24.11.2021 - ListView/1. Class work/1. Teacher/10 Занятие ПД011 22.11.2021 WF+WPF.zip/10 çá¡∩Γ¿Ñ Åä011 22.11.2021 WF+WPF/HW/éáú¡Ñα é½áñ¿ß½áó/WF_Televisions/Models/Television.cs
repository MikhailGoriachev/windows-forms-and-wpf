﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WF_Televisions.Utilities;
using System.Runtime.Serialization;
namespace WF_Televisions.Models
{
    [DataContract]
    public class Television
    {
        [DataMember]
        string _producer;

        public string Producer {
            get => _producer;

            set 
            {
                if (string.IsNullOrEmpty(value))
                    throw new Exception("Строка не может быть пустой!");

                _producer = value;
            }
            
        }
        [DataMember]
        string _type;

        public string Type {
            get => _type; 
            
            set
            {
                if (string.IsNullOrEmpty(value))
                    throw new Exception("Строка не может быть пустой!");
                _type = value;
            }
        }
        [DataMember]
        double _diagonal;
        //Свойство диагонали
        public double Diagonal 
        {
            get => _diagonal; 
            
            set
            {
                //Проверка на 0 до 6 знака после запятой
                if (value < 1e-6)
                    throw new Exception("Значение диагонали должно быть больше 0!");
                _diagonal = value;
            }
        }
        [DataMember]
        //Дефект устройства
        string _defect;

        public string Defect {

            get => _defect; 
            set
            {
                if (string.IsNullOrEmpty(value))
                    throw new Exception("Строка не может быть пустой!");
                _defect = value;
            }
        
        }
        [DataMember]
        //ФИО мастера
        string _surnameRepairer;

        public string SurnameRepairer { 
            get => _surnameRepairer;


            set
            {
                if (string.IsNullOrEmpty(value))
                    throw new Exception("Строка не может быть пустой!");
                _surnameRepairer = value;
            }
        }
        [DataMember]
        //ФИО владельца
        string _surnameOwner;

        public string SurnameOwner
        {
            get => _surnameOwner;

            set
            {
                if (string.IsNullOrEmpty(value))
                    throw new Exception("Строка не может быть пустой!");
                _surnameOwner = value;
            }
        }
        [DataMember]
        //Стоимость ремонта
        double _price;
        public double Price
        {
            get => _price;

            set
            {
                //Проверка на 0 до 6 знака после запятой
                if (value < 1e-6)
                    throw new Exception("Значение стоимости ремонта должно быть больше 0!");
                _price = value;
            }
        }

        //Внедрение зависимости
        public Television(): this("Samsung","Smart TV",50,"Питание", "Довлатов Л.Д.", "Степанов М.Л.",5400d)
        {}
         
        //Свойства: 
        public Television(string producer, string type, double diaonal, string defect, string repairer, string owner, double price)
        {
            Producer = producer;
            Type = type;
            Diagonal = diaonal;
            Defect = defect;
            SurnameRepairer = repairer;
            SurnameOwner = owner;
            Price = price;
        }

        //Генерация телевизора
        static public Television Generate()
        {
            int index = Utils.Random.Next(0, 7), 
                diagonalInd = Utils.Random.Next(0,Utils.diagonals.Length),
                defectInd = Utils.Random.Next(0, Utils.defects.Length), 
                ownerInd = Utils.Random.Next(0, Utils.owners.Length),
                repairerInd= Utils.Random.Next(0, Utils.repairers.Length);

            return 
                new Television
                (Utils.producers[index], Utils.types[index], Utils.diagonals[diagonalInd], Utils.defects[defectInd].def, Utils.repairers[repairerInd], Utils.owners[ownerInd], Utils.defects[defectInd].price);

        } //Generate

        //Компаратор по цене
        public int CompareTo(Television tv) => _price.CompareTo(tv._price);

        //Вывод в строку таблицы
        public string ToTableRow =>
            $"{_producer,10}│{_type,5}│{_diagonal,9:f2}│{_defect,14}│{_surnameOwner,17}│{_surnameRepairer,14}│{_price,4:f2}";
     
        //Строка
        public override string  ToString() =>
            $"TV:\r\nБренд: {_producer},\r\nТип: {_type},\r\nДиагональ(дюйм):{_diagonal:f2}\r\nДефект: {_defect}\r\nМастер: {_surnameRepairer}\r\nВладелец: {_surnameOwner}\r\nСтоимость ремонта: {_price:f2}";
        

        // Шапка таблицы
        public static string Header =>
            $"┌───────────────┬───────┬──────────┬──────────────┬─────────────────┬──────────────┬───────┐\r\n" +
            $"│ Производитель │  Тип  │Диагональ,│ Дефект       │ Владелец        │ Мастер       │ Цена  │" +
            $"│               │       │inch      │              │                 │              │       │\r\n" +
            $"├───────────────┼───────┼──────────┼──────────────┼─────────────────┼──────────────┼───────┤\r\n";

        // Подвал таблицы, статическое свойство
        public static string Footer =>
             "└───────────────┴───────┴──────────┴──────────────┴─────────────────┴──────────────┴───────┘";

       
    }
}
