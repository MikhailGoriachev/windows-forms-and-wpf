﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WF_Televisions.Models;

namespace WF_Televisions.Forms
{
    public partial class Selection_form : Form
    {
        //Мастреская 
        private RepairShop _repairShop = new RepairShop();

        public Selection_form():this("Выборка по умолчанию",new Television[10])
        {
            InitializeComponent();
            //Коллекция по умолчанию 
         /*   _repairShop.Televisions.Clear();
            _repairShop.Generate(defaultCount);

            TbxOutPut.Text = _repairShop.ShowCollection();*/
        }

        public Selection_form(string title,Television[] tvs)
        {

            InitializeComponent();

            //Добавление выборки в мастерскую
            _repairShop.Televisions.Clear();
            _repairShop.Televisions.AddRange(tvs);

            //Устанавливаем label 
            LblTitle.Text = title;

            //Меняем значение в статусной строке
            SStatusLbl_total.Text = $"Выбрано телевизоров: {_repairShop.Televisions.Count} ";

            //Связываем 
            BindTelevision();
        }

        //Связывание полученной коллекции с ListBox
        void BindTelevision()
        {
            //Обнуляем связь
            LbxOutPut.DataSource = null;

            //Возобновляем связь
            LbxOutPut.DataSource = _repairShop.Televisions;

            LbxOutPut.DisplayMember = "ToTableRow";
        }
       
    }
}
