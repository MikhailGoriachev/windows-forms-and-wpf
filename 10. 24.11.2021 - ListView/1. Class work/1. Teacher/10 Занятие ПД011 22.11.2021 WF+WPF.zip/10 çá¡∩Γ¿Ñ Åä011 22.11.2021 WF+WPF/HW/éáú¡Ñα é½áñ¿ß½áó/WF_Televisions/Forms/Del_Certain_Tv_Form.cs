﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WF_Televisions.Models;
using WF_Televisions.Controller;

namespace WF_Televisions.Forms
{
    public partial class Del_Certain_Tv_Form : Form
    {

        //Свойство контроллер
        private RepairShopController _repairShopController;


        public RepairShopController rsController
        {
            get => _repairShopController;
        }


        public Del_Certain_Tv_Form():this(new RepairShopController())
        {
        }

        //C_TOR с параметрами 

        public Del_Certain_Tv_Form(RepairShopController repair)
        {
            InitializeComponent();

            IsEmpty(repair);
            _repairShopController = repair;
        }

        //Связывание с коллекциями double
       void BindData(List<double> set)
        {
            //Добавляем данные в полученный список работников
            CbxField.DataSource = null;
            CbxField.DataSource = set;
        }
        
        //Связывание со строковыми коллекциями
       void BindData(List<string> set)
        {
            //Добавляем данные в полученный список работников
            CbxField.DataSource = null;
            CbxField.DataSource = set;
        }

        //Проверка на пустоту коллекции
        void IsEmpty(RepairShopController repairShopController)
        {
            if (repairShopController.RepairShop.Televisions.Count > 0)
                return;
            #region Radiobuttons
            RbtnDiagonal.Enabled = false;
            RbtnPrice.Enabled = false;
            RbtnRepairer.Enabled = false;
            RbtnType.Enabled = false;
            RbtnProducer.Enabled = false;
            #endregion

            //Отключаем ComboBox
            LblField.Enabled = false;
            CbxField.Enabled = false;

           
        }

        #region Radio buttons


        private void RbtnDiagonal_CheckedChanged(object sender, EventArgs e)
        {
            LblField.Enabled = true;
            CbxField.Enabled = true;
            LblField.Text = "Выбирете диагональ";

            List<double> tempList = new List<double>(_repairShopController.GetDoubleCollection(RepairShopController.SubCollection.diagonal));

            //Добавляем данные в полученный список диагоналей
            BindData(tempList);
        }

        private void RbtnPrice_CheckedChanged(object sender, EventArgs e)
        {
            LblField.Enabled = true;
            CbxField.Enabled = true;
            LblField.Text = "Выбирете стоимость";

            List<double> tempList = new List<double>(_repairShopController.GetDoubleCollection(RepairShopController.SubCollection.price));

            //Добавляем данные в полученный список цен
            BindData(tempList);


        }

        //Обработчик радиокнопки
        private void RbtnProducer_CheckedChanged(object sender, EventArgs e)
        {
            LblField.Enabled = true;
            CbxField.Enabled = true;
            LblField.Text = "Выбирете производителя";

            //Получение списка производителей без повторений
            List<string> tempList = new List<string>(_repairShopController.GetStringsCollection(RepairShopController.SubCollection.producer));

            //Связываем полученный список производителей
            BindData(tempList);
        }


        private void RbtnType_CheckedChanged(object sender, EventArgs e)
        {
            LblField.Enabled = true;
            CbxField.Enabled = true;
            LblField.Text = "Выбирете тип телевизора";

            //Получение списка типов без повторений
            List<string> tempList = new List<string>(_repairShopController.GetStringsCollection(RepairShopController.SubCollection.type));

            //Связываем полученный список типов
            BindData(tempList);
        }

        private void RbtnRepairer_CheckedChanged(object sender, EventArgs e)
        {
            LblField.Enabled = true;
            CbxField.Enabled = true;
            LblField.Text = "Выбирете мастера";

            //Получение списка мастеров без повторений
            List<string> tempList = new List<string>(_repairShopController.GetStringsCollection(RepairShopController.SubCollection.repairer));

            //Связываем полученный список типов
            BindData(tempList);
        }

        #endregion


        private void CbxField_SelectedIndexChanged(object sender, EventArgs e)
        {
            BtnDelete.Enabled = true;
        }

        private void BtnDelete_Click(object sender, EventArgs e)
        {
            int size = _repairShopController.RepairShop.Televisions.Count;

            //Условия на опеределение нажатой кнопки 

            //Если было выбрано удаление по бренду
            if (RbtnProducer.Checked)
            {
                string Brand = CbxField.Text;
                for (int i = size-1; i >= 0; i--)
                {
                    if(_repairShopController.RepairShop[i].Producer == Brand)
                       _repairShopController.RepairShop.Televisions.RemoveAt(i);
                }

            }

            //Если было выбрано удаление по диагонали
            if (RbtnDiagonal.Checked)
            {
                double Diagonal = (double) CbxField.SelectedItem ;
                for (int i = size - 1; i >= 0; i--)
                {
                    if (_repairShopController.RepairShop[i].Diagonal.CompareTo(Diagonal) == 0)
                        _repairShopController.RepairShop.Televisions.RemoveAt(i);
                }

            }
            //Если было выбрано удаление по стоимости
            if (RbtnPrice.Checked)
            {
                double Price = (double) CbxField.SelectedItem ;
                for (int i = size - 1; i >= 0; i--)
                {
                    if (_repairShopController.RepairShop[i].Price.CompareTo(Price) == 0)
                        _repairShopController.RepairShop.Televisions.RemoveAt(i);
                }
            }


            //Если было выбрано удаление по типу
            if (RbtnType.Checked)
            {
                string Type = CbxField.Text;
                for (int i = size - 1; i >= 0; i--)
                {
                    if (_repairShopController.RepairShop[i].Type == Type)
                        _repairShopController.RepairShop.Televisions.RemoveAt(i);
                }

            }

            //Если было выбрано удаление по мастеру
            if (RbtnRepairer.Checked)
            {
                string Repairer = CbxField.Text;
                for (int i = size - 1; i >= 0; i--)
                {
                    if (_repairShopController.RepairShop[i].SurnameRepairer == Repairer)
                        _repairShopController.RepairShop.Televisions.RemoveAt(i);
                }

            }
        }


    }
}
