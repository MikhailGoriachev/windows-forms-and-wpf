﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WF_Televisions.Models;
using WF_Televisions.Controller;

namespace WF_Televisions.Forms
{
    public partial class Select_Certain : Form
    {

        //Свойство контроллер
        private RepairShopController _repairShopController;


        public RepairShopController rsController
        {
            get => _repairShopController;
        }

        //Выбранное значение
        private object _chosenItem;

        public object ChosenItem
        {
            get => _chosenItem;
        }

        //Перечисление составных коллекций
        public enum SubObject
        {
            //Дагональ 
            diagonal,
            //Владелец
            owner,
            //Мастер 
            repairer
        }

        public Select_Certain():this(new RepairShopController(),SubObject.repairer)
        {
        }

        //C_TOR с параметрами 

        public Select_Certain(RepairShopController repair,SubObject subObject)
        {
            InitializeComponent();

            _repairShopController = repair;
            addToCbx(subObject);
            
        }

        //Связывание с коллекциями double
       void BindData(List<double> set)
        {
            //Добавляем данные в полученный список работников
            CbxField.DataSource = null;
            CbxField.DataSource = set;
        }
        
        //Связывание со строковыми коллекциями
       void BindData(List<string> set)
        {
            //Добавляем данные в полученный список работников
            CbxField.DataSource = null;
            CbxField.DataSource = set;
        }

        //Связывание с опеределённойколлекцией составных элементов
        void addToCbx(SubObject code)
        {
            //Создаём временные списки
            List<double> tempListDbl = new List<double>();
            List<string> tempListStr = new List<string>();

            //Выбираем связывание с коллекцией
            switch (code)
            {
                case SubObject.diagonal:

                    tempListDbl.AddRange(_repairShopController.GetDoubleCollection(RepairShopController.SubCollection.diagonal));

                    //Добавляем данные в полученный список диагоналей
                    BindData(tempListDbl);
                    LblTitle.Text = "Выбирете диагональ";
                    break;

                case SubObject.owner:
                    tempListStr.AddRange(_repairShopController.GetStringsCollection(RepairShopController.SubCollection.owner));

                    //Связываем полученный список типов
                    BindData(tempListStr);

                    LblTitle.Text = "Выбирете владельца";
                    break;

                case SubObject.repairer:
                    tempListStr.AddRange(_repairShopController.GetStringsCollection(RepairShopController.SubCollection.repairer));

                    //Связываем полученный список типов
                    BindData(tempListStr);

                    LblTitle.Text = "Выбирете мастера";
                    break;

                default:
                    break;
            }
        }

        private void CbxField_SelectedIndexChanged(object sender, EventArgs e)
        {
            BtnAccept.Enabled = true;
        }

        private void BtnAccept_Click(object sender, EventArgs e)
        {
            _chosenItem = CbxField.SelectedItem;

        }


    }
}
