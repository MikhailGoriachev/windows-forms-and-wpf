﻿namespace WF_Televisions.Forms
{
    partial class Edit_Obj_Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.GbxAddEditTV = new System.Windows.Forms.GroupBox();
            this.Tbx_Repairer = new System.Windows.Forms.TextBox();
            this.Tbx_Defect = new System.Windows.Forms.TextBox();
            this.Tbx_Type = new System.Windows.Forms.TextBox();
            this.Tbx_Producer = new System.Windows.Forms.TextBox();
            this.Tbx_Owner = new System.Windows.Forms.TextBox();
            this.lbl_defect = new System.Windows.Forms.Label();
            this.LblTvDiagonal = new System.Windows.Forms.Label();
            this.Tbx_Diagonal = new System.Windows.Forms.TextBox();
            this.Gbx_ReadyObject = new System.Windows.Forms.GroupBox();
            this.Tbx_EndedObj = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.Tbx_Price = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.LblTvType = new System.Windows.Forms.Label();
            this.LblTvBrand = new System.Windows.Forms.Label();
            this.BtnAdd = new System.Windows.Forms.Button();
            this.BtnClose = new System.Windows.Forms.Button();
            this.ErpOwnerField = new System.Windows.Forms.ErrorProvider(this.components);
            this.ErpDiagonal = new System.Windows.Forms.ErrorProvider(this.components);
            this.ErpPrice = new System.Windows.Forms.ErrorProvider(this.components);
            this.GbxAddEditTV.SuspendLayout();
            this.Gbx_ReadyObject.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ErpOwnerField)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ErpDiagonal)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ErpPrice)).BeginInit();
            this.SuspendLayout();
            // 
            // GbxAddEditTV
            // 
            this.GbxAddEditTV.Controls.Add(this.Tbx_Repairer);
            this.GbxAddEditTV.Controls.Add(this.Tbx_Defect);
            this.GbxAddEditTV.Controls.Add(this.Tbx_Type);
            this.GbxAddEditTV.Controls.Add(this.Tbx_Producer);
            this.GbxAddEditTV.Controls.Add(this.Tbx_Owner);
            this.GbxAddEditTV.Controls.Add(this.lbl_defect);
            this.GbxAddEditTV.Controls.Add(this.LblTvDiagonal);
            this.GbxAddEditTV.Controls.Add(this.Tbx_Diagonal);
            this.GbxAddEditTV.Controls.Add(this.Gbx_ReadyObject);
            this.GbxAddEditTV.Controls.Add(this.label3);
            this.GbxAddEditTV.Controls.Add(this.Tbx_Price);
            this.GbxAddEditTV.Controls.Add(this.label2);
            this.GbxAddEditTV.Controls.Add(this.label1);
            this.GbxAddEditTV.Controls.Add(this.LblTvType);
            this.GbxAddEditTV.Controls.Add(this.LblTvBrand);
            this.GbxAddEditTV.Location = new System.Drawing.Point(35, 43);
            this.GbxAddEditTV.Name = "GbxAddEditTV";
            this.GbxAddEditTV.Size = new System.Drawing.Size(681, 568);
            this.GbxAddEditTV.TabIndex = 0;
            this.GbxAddEditTV.TabStop = false;
            this.GbxAddEditTV.Text = "Редактирование телевизора";
            // 
            // Tbx_Repairer
            // 
            this.Tbx_Repairer.Location = new System.Drawing.Point(31, 366);
            this.Tbx_Repairer.Name = "Tbx_Repairer";
            this.Tbx_Repairer.Size = new System.Drawing.Size(258, 23);
            this.Tbx_Repairer.TabIndex = 27;
            this.Tbx_Repairer.Tag = "";
            this.Tbx_Repairer.TextChanged += new System.EventHandler(this.Tbx_Changed);
            this.Tbx_Repairer.Validating += new System.ComponentModel.CancelEventHandler(this.TextBoxStr_Validating);
            // 
            // Tbx_Defect
            // 
            this.Tbx_Defect.Location = new System.Drawing.Point(35, 232);
            this.Tbx_Defect.Name = "Tbx_Defect";
            this.Tbx_Defect.Size = new System.Drawing.Size(258, 23);
            this.Tbx_Defect.TabIndex = 26;
            this.Tbx_Defect.Tag = "";
            this.Tbx_Defect.TextChanged += new System.EventHandler(this.Tbx_Changed);
            this.Tbx_Defect.Validating += new System.ComponentModel.CancelEventHandler(this.TextBoxStr_Validating);
            // 
            // Tbx_Type
            // 
            this.Tbx_Type.Location = new System.Drawing.Point(34, 158);
            this.Tbx_Type.Name = "Tbx_Type";
            this.Tbx_Type.Size = new System.Drawing.Size(258, 23);
            this.Tbx_Type.TabIndex = 25;
            this.Tbx_Type.Tag = "";
            this.Tbx_Type.TextChanged += new System.EventHandler(this.Tbx_Changed);
            this.Tbx_Type.Validating += new System.ComponentModel.CancelEventHandler(this.TextBoxStr_Validating);
            // 
            // Tbx_Producer
            // 
            this.Tbx_Producer.Location = new System.Drawing.Point(34, 87);
            this.Tbx_Producer.Name = "Tbx_Producer";
            this.Tbx_Producer.Size = new System.Drawing.Size(258, 23);
            this.Tbx_Producer.TabIndex = 24;
            this.Tbx_Producer.Tag = "";
            this.Tbx_Producer.TextChanged += new System.EventHandler(this.Tbx_Changed);
            this.Tbx_Producer.Validating += new System.ComponentModel.CancelEventHandler(this.TextBoxStr_Validating);
            // 
            // Tbx_Owner
            // 
            this.Tbx_Owner.Location = new System.Drawing.Point(30, 301);
            this.Tbx_Owner.Name = "Tbx_Owner";
            this.Tbx_Owner.Size = new System.Drawing.Size(258, 23);
            this.Tbx_Owner.TabIndex = 21;
            this.Tbx_Owner.Tag = "ErpOwnerField";
            this.Tbx_Owner.TextChanged += new System.EventHandler(this.Tbx_Changed);
            this.Tbx_Owner.Validating += new System.ComponentModel.CancelEventHandler(this.TextBoxStr_Validating);
            // 
            // lbl_defect
            // 
            this.lbl_defect.Font = new System.Drawing.Font("Consolas", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lbl_defect.Location = new System.Drawing.Point(34, 202);
            this.lbl_defect.Name = "lbl_defect";
            this.lbl_defect.Size = new System.Drawing.Size(259, 27);
            this.lbl_defect.TabIndex = 22;
            this.lbl_defect.Text = "Дефект";
            this.lbl_defect.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // LblTvDiagonal
            // 
            this.LblTvDiagonal.Font = new System.Drawing.Font("Consolas", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblTvDiagonal.Location = new System.Drawing.Point(30, 406);
            this.LblTvDiagonal.Name = "LblTvDiagonal";
            this.LblTvDiagonal.Size = new System.Drawing.Size(259, 27);
            this.LblTvDiagonal.TabIndex = 10;
            this.LblTvDiagonal.Text = "Диагональ";
            this.LblTvDiagonal.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Tbx_Diagonal
            // 
            this.Tbx_Diagonal.Location = new System.Drawing.Point(30, 436);
            this.Tbx_Diagonal.Name = "Tbx_Diagonal";
            this.Tbx_Diagonal.Size = new System.Drawing.Size(258, 23);
            this.Tbx_Diagonal.TabIndex = 2;
            this.Tbx_Diagonal.Tag = "ErpDiagonal";
            this.Tbx_Diagonal.TextChanged += new System.EventHandler(this.Tbx_Changed);
            this.Tbx_Diagonal.Validating += new System.ComponentModel.CancelEventHandler(this.TextBoxDouble_Validating);
            // 
            // Gbx_ReadyObject
            // 
            this.Gbx_ReadyObject.Controls.Add(this.Tbx_EndedObj);
            this.Gbx_ReadyObject.Location = new System.Drawing.Point(335, 128);
            this.Gbx_ReadyObject.Name = "Gbx_ReadyObject";
            this.Gbx_ReadyObject.Size = new System.Drawing.Size(330, 284);
            this.Gbx_ReadyObject.TabIndex = 16;
            this.Gbx_ReadyObject.TabStop = false;
            this.Gbx_ReadyObject.Text = "Конечный обект";
            // 
            // Tbx_EndedObj
            // 
            this.Tbx_EndedObj.Location = new System.Drawing.Point(22, 30);
            this.Tbx_EndedObj.Multiline = true;
            this.Tbx_EndedObj.Name = "Tbx_EndedObj";
            this.Tbx_EndedObj.ReadOnly = true;
            this.Tbx_EndedObj.Size = new System.Drawing.Size(289, 231);
            this.Tbx_EndedObj.TabIndex = 0;
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("Consolas", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.Location = new System.Drawing.Point(30, 474);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(259, 27);
            this.label3.TabIndex = 14;
            this.label3.Text = "Стоимость";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Tbx_Price
            // 
            this.Tbx_Price.Location = new System.Drawing.Point(30, 504);
            this.Tbx_Price.Name = "Tbx_Price";
            this.Tbx_Price.Size = new System.Drawing.Size(258, 23);
            this.Tbx_Price.TabIndex = 13;
            this.Tbx_Price.Tag = "ErpPrice";
            this.Tbx_Price.TextChanged += new System.EventHandler(this.Tbx_Changed);
            this.Tbx_Price.Validating += new System.ComponentModel.CancelEventHandler(this.TextBoxDouble_Validating);
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Consolas", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(30, 336);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(259, 27);
            this.label2.TabIndex = 12;
            this.label2.Text = "Мастер";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Consolas", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(30, 267);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(259, 27);
            this.label1.TabIndex = 11;
            this.label1.Text = "Владелец";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // LblTvType
            // 
            this.LblTvType.Font = new System.Drawing.Font("Consolas", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblTvType.Location = new System.Drawing.Point(35, 128);
            this.LblTvType.Name = "LblTvType";
            this.LblTvType.Size = new System.Drawing.Size(259, 27);
            this.LblTvType.TabIndex = 6;
            this.LblTvType.Text = "Тип ";
            this.LblTvType.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // LblTvBrand
            // 
            this.LblTvBrand.Font = new System.Drawing.Font("Consolas", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblTvBrand.Location = new System.Drawing.Point(30, 57);
            this.LblTvBrand.Name = "LblTvBrand";
            this.LblTvBrand.Size = new System.Drawing.Size(259, 27);
            this.LblTvBrand.TabIndex = 5;
            this.LblTvBrand.Text = "Производитель";
            this.LblTvBrand.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // BtnAdd
            // 
            this.BtnAdd.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.BtnAdd.Font = new System.Drawing.Font("Consolas", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BtnAdd.Location = new System.Drawing.Point(35, 617);
            this.BtnAdd.Name = "BtnAdd";
            this.BtnAdd.Size = new System.Drawing.Size(295, 46);
            this.BtnAdd.TabIndex = 8;
            this.BtnAdd.Text = "Сохранить";
            this.BtnAdd.UseVisualStyleBackColor = true;
            // 
            // BtnClose
            // 
            this.BtnClose.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.BtnClose.Font = new System.Drawing.Font("Consolas", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BtnClose.Location = new System.Drawing.Point(421, 617);
            this.BtnClose.Name = "BtnClose";
            this.BtnClose.Size = new System.Drawing.Size(295, 46);
            this.BtnClose.TabIndex = 7;
            this.BtnClose.Text = "Закрыть";
            this.BtnClose.UseVisualStyleBackColor = true;
            // 
            // ErpOwnerField
            // 
            this.ErpOwnerField.ContainerControl = this;
            // 
            // ErpDiagonal
            // 
            this.ErpDiagonal.ContainerControl = this;
            // 
            // ErpPrice
            // 
            this.ErpPrice.ContainerControl = this;
            // 
            // Edit_Obj_Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(772, 675);
            this.Controls.Add(this.GbxAddEditTV);
            this.Controls.Add(this.BtnAdd);
            this.Controls.Add(this.BtnClose);
            this.Font = new System.Drawing.Font("Consolas", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.MaximizeBox = false;
            this.Name = "Edit_Obj_Form";
            this.ShowInTaskbar = false;
            this.Text = "Редактирование телевизора";
            this.Load += new System.EventHandler(this.Edit_Obj_Form_Load);
            this.GbxAddEditTV.ResumeLayout(false);
            this.GbxAddEditTV.PerformLayout();
            this.Gbx_ReadyObject.ResumeLayout(false);
            this.Gbx_ReadyObject.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ErpOwnerField)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ErpDiagonal)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ErpPrice)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox GbxAddEditTV;
        private System.Windows.Forms.Button BtnAdd;
        private System.Windows.Forms.Button BtnClose;
        private System.Windows.Forms.Label LblTvType;
        private System.Windows.Forms.Label LblTvBrand;
        private System.Windows.Forms.TextBox Tbx_Diagonal;
        private System.Windows.Forms.Label LblTvDiagonal;
        private System.Windows.Forms.GroupBox Gbx_ReadyObject;
        private System.Windows.Forms.TextBox Tbx_EndedObj;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox Tbx_Price;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox Tbx_Owner;
        private System.Windows.Forms.ErrorProvider ErpOwnerField;
        private System.Windows.Forms.ErrorProvider ErpDiagonal;
        private System.Windows.Forms.ErrorProvider ErpPrice;
        private System.Windows.Forms.Label lbl_defect;
        private System.Windows.Forms.TextBox Tbx_Repairer;
        private System.Windows.Forms.TextBox Tbx_Defect;
        private System.Windows.Forms.TextBox Tbx_Type;
        private System.Windows.Forms.TextBox Tbx_Producer;
    }
}