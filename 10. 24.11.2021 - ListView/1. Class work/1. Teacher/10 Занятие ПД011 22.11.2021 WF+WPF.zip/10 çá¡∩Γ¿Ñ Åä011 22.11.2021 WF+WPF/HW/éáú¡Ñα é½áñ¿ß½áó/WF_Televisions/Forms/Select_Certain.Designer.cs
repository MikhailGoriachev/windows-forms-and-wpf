﻿namespace WF_Televisions.Forms
{
    partial class Select_Certain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.BtnAccept = new System.Windows.Forms.Button();
            this.CbxField = new System.Windows.Forms.ComboBox();
            this.LblField = new System.Windows.Forms.Label();
            this.BtnClose = new System.Windows.Forms.Button();
            this.LblTitle = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // BtnAccept
            // 
            this.BtnAccept.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.BtnAccept.Enabled = false;
            this.BtnAccept.Font = new System.Drawing.Font("Consolas", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BtnAccept.Location = new System.Drawing.Point(6, 128);
            this.BtnAccept.Name = "BtnAccept";
            this.BtnAccept.Size = new System.Drawing.Size(159, 53);
            this.BtnAccept.TabIndex = 0;
            this.BtnAccept.Text = "Выбрать";
            this.BtnAccept.UseVisualStyleBackColor = true;
            this.BtnAccept.Click += new System.EventHandler(this.BtnAccept_Click);
            // 
            // CbxField
            // 
            this.CbxField.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CbxField.FormattingEnabled = true;
            this.CbxField.Location = new System.Drawing.Point(128, 74);
            this.CbxField.Name = "CbxField";
            this.CbxField.Size = new System.Drawing.Size(218, 23);
            this.CbxField.TabIndex = 1;
            this.CbxField.SelectedIndexChanged += new System.EventHandler(this.CbxField_SelectedIndexChanged);
            // 
            // LblField
            // 
            this.LblField.AutoSize = true;
            this.LblField.Font = new System.Drawing.Font("Consolas", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblField.Location = new System.Drawing.Point(133, 53);
            this.LblField.Name = "LblField";
            this.LblField.Size = new System.Drawing.Size(104, 18);
            this.LblField.TabIndex = 2;
            this.LblField.Text = "Поле выборки";
            // 
            // BtnClose
            // 
            this.BtnClose.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.BtnClose.Font = new System.Drawing.Font("Consolas", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BtnClose.Location = new System.Drawing.Point(281, 128);
            this.BtnClose.Name = "BtnClose";
            this.BtnClose.Size = new System.Drawing.Size(169, 53);
            this.BtnClose.TabIndex = 3;
            this.BtnClose.Text = "Закрыть";
            this.BtnClose.UseVisualStyleBackColor = true;
            // 
            // LblTitle
            // 
            this.LblTitle.AutoSize = true;
            this.LblTitle.Font = new System.Drawing.Font("Consolas", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblTitle.Location = new System.Drawing.Point(133, 27);
            this.LblTitle.Name = "LblTitle";
            this.LblTitle.Size = new System.Drawing.Size(54, 19);
            this.LblTitle.TabIndex = 4;
            this.LblTitle.Text = "     ";
            // 
            // Select_Certain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(462, 209);
            this.Controls.Add(this.LblTitle);
            this.Controls.Add(this.BtnClose);
            this.Controls.Add(this.LblField);
            this.Controls.Add(this.CbxField);
            this.Controls.Add(this.BtnAccept);
            this.Font = new System.Drawing.Font("Consolas", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Select_Certain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Удаление телевизоров";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button BtnAccept;
        private System.Windows.Forms.ComboBox CbxField;
        private System.Windows.Forms.Label LblField;
        private System.Windows.Forms.Button BtnClose;
        private System.Windows.Forms.Label LblTitle;
    }
}