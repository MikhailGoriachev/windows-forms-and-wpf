﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WF_Televisions.Models;
using System.Runtime.Serialization;
using System.Text.Json;
using System.IO;
using System.Runtime.Serialization.Json;

namespace WF_Televisions.Controller
{
    public class RepairShopController
    {
        //Мастерская
        private RepairShop _repairShop;

        //Перечесление компонентов television 
        public enum SubCollection
        {
            //Производитель 
            producer,
            //Дагональ 
            diagonal,
            //Тип 
            type,
            //Владелец
            owner,
            //Мастер 
            repairer,
            //Цена
            price
        }

        public RepairShop RepairShop
        {
            get => _repairShop;
        } // RepairShop

        //C_TOR с внедрением зависимости 
        public RepairShopController():this(new RepairShop())
        { }

        public RepairShopController(RepairShop repairShop)
        {
            _repairShop = repairShop;
        }//RepairShopController

        #region Сортировки 

        //Сортировка по производителю  _repairShop.SortTv
        public void SortByProducer()
            => _repairShop.SortTv((tv1, tv2) => tv1.Producer.CompareTo(tv2.Producer));
        
        //Сортирвока по убыванию диагонали 
        public void SortDescByDiagonal()
            => _repairShop.SortTv((tv1, tv2) => tv2.Diagonal.CompareTo(tv1.Diagonal));

        //Сортировка по мастеру
        public void SortByRapairer()
            => _repairShop.SortTv((tv1, tv2) => tv1.SurnameRepairer.CompareTo(tv2.SurnameRepairer));

        //Сортировка по владельцу
        public void SortByOwner()
            => _repairShop.SortTv((tv1, tv2) => tv1.SurnameOwner.CompareTo(tv2.SurnameOwner));

        //Сортировка по стоимости 
        public void SortByPrice()
            => _repairShop.SortTv((tv1,tv2) => tv1.Price.CompareTo(tv2.Price));
        #endregion

        #region Выборки 
        //По минимальной цене 
        public List<Television> SelectByMinPrice()
        {
            double min = _repairShop.MinPrice();
            return _repairShop.SelectBy((tv) => tv.Price.CompareTo(min) == 0);
        }
        //По мастеру  
        public List<Television> SelectByRepairer(string Repairer)
        {
            return _repairShop.SelectBy((tv) => tv.SurnameRepairer == Repairer);
        }
        //По заданной диагонали экрана 
        public List<Television> SelectByDiagonal(double Diagonal)
        {
            return _repairShop.SelectBy((tv) => tv.Diagonal.CompareTo(Diagonal) == 0);
        }
        //По заданному влаульцу
        public List<Television> SelectByOwner(string Owner)
        {
            return _repairShop.SelectBy((tv) => tv.SurnameOwner == Owner);
        }
        #endregion

        #region Коллекции составных частей обекта
        //Получения строковой коллекции 
        public List<string> GetStringsCollection(SubCollection code)
        {
            Dictionary<string, int> set = new Dictionary<string, int>();

            //Выбор цыкла для конкретного поля на Televisions
            switch (code)
            {
                case SubCollection.producer:
                    foreach (Television item in _repairShop.Televisions)
                    { set[item.Producer] = 0; }
                    break;

                case SubCollection.type:
                    foreach (Television item in _repairShop.Televisions)
                    { set[item.Type] = 0; }
                    break;

                case SubCollection.owner:
                    foreach (Television item in _repairShop.Televisions)
                    { set[item.SurnameOwner] = 0; }
                    break;

                case SubCollection.repairer:
                    foreach (Television item in _repairShop.Televisions)
                    { set[item.SurnameRepairer] = 0; }
                    break;

                //По умолчанию будет отрабатывать цыкл получения производителей
                default:
                    foreach (Television item in _repairShop.Televisions)
                    { set[item.Producer] = 0; }
                    break;
            }

            //Обращаем словарь в список
            List<string> temp = new List<string>(set.Keys);
            return temp;
        }//GetStringCollection

        
        //Метод получения коллекции с типом double 
        public List<double> GetDoubleCollection(SubCollection code)
        {
            Dictionary<double, int> set = new Dictionary<double, int>();

            //Выбор цыкла для конкретного поля на Televisions
            switch (code)
            {
                case SubCollection.diagonal:
                    foreach (Television item in _repairShop.Televisions)
                    { set[item.Diagonal] = 0; }
                    break;

                case SubCollection.price:
                    foreach (Television item in _repairShop.Televisions)
                    { set[item.Price] = 0; }
                    break;

                //По умолчанию будет отрабатывать цыкл получения цен
                default:
                    foreach (Television item in _repairShop.Televisions)
                    { set[item.Price] = 0; }
                    break;
            }

            //Обращаем словарь в список
            List<double> temp = new List<double>(set.Keys);
            return temp;
        }//GetDoubleCollection
        #endregion

        #region Сериализация 
        public void Serialize(string FName)
        {
            //Создаём форматтер 
            DataContractJsonSerializer jsonFormatter = new DataContractJsonSerializer(_repairShop.GetType());

            using (FileStream fs = new FileStream(FName, FileMode.OpenOrCreate))
            {
                jsonFormatter.WriteObject(fs,_repairShop);
            }
            

        }

        public void Deserialize(string FName)
        {
            DataContractJsonSerializer jsonFormatter = new DataContractJsonSerializer(_repairShop.GetType());
            using (FileStream fs = new FileStream(FName,FileMode.Open))
            {
                /*_repairShop =  JsonSerializer.DeserializeAsync<RepairShop>(fs);*/
                _repairShop = (RepairShop)jsonFormatter.ReadObject(fs);

            }
        }
        #endregion

    }
}
