﻿namespace WF_Televisions
{
    partial class Main_form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Main_form));
            this.LbxRepairShop = new System.Windows.Forms.ListBox();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.выходToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.мастерскаяToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.телевизорыToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.AddTvToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.EditTvToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.DeleteTvToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.ReformTSMItem = new System.Windows.Forms.ToolStripMenuItem();
            this.AddCollectionTvToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.DelTvsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.SortsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.SortByProducerTSMItem = new System.Windows.Forms.ToolStripMenuItem();
            this.SortByDiagonalTSMItem = new System.Windows.Forms.ToolStripMenuItem();
            this.SortByRepairerTSMItem = new System.Windows.Forms.ToolStripMenuItem();
            this.SortByOwnerTSMItem = new System.Windows.Forms.ToolStripMenuItem();
            this.SelectionTSMItem = new System.Windows.Forms.ToolStripMenuItem();
            this.SelectByMinPriceTSMItem = new System.Windows.Forms.ToolStripMenuItem();
            this.SelectRepairerTSMItem = new System.Windows.Forms.ToolStripMenuItem();
            this.SelectDiagonalTSMItem = new System.Windows.Forms.ToolStripMenuItem();
            this.SelectOwnerTSMItem = new System.Windows.Forms.ToolStripMenuItem();
            this.оПрограммеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.TbxTv = new System.Windows.Forms.TextBox();
            this.StsMain = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLbl = new System.Windows.Forms.ToolStripStatusLabel();
            this.GbxTv = new System.Windows.Forms.GroupBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.CbxChooseFew = new System.Windows.Forms.CheckBox();
            this.GbxCheckBox = new System.Windows.Forms.GroupBox();
            this.BtnDelSpecific = new System.Windows.Forms.Button();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripDropDownButton1 = new System.Windows.Forms.ToolStripDropDownButton();
            this.AddCollectionTSMItem = new System.Windows.Forms.ToolStripMenuItem();
            this.добавитьТелевизорToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSplitButton2 = new System.Windows.Forms.ToolStripSplitButton();
            this.редактироватьДанныеМатсрерскойToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripSplitButton1 = new System.Windows.Forms.ToolStripSplitButton();
            this.BtnSortByBrandTSMItem = new System.Windows.Forms.ToolStripMenuItem();
            this.BtnSortByDiagonalTSMItem = new System.Windows.Forms.ToolStripMenuItem();
            this.BtnSortByRepairerTSMItem = new System.Windows.Forms.ToolStripMenuItem();
            this.BtnSortByOwnerTSMItem = new System.Windows.Forms.ToolStripMenuItem();
            this.BtnSelectionsToolStrip = new System.Windows.Forms.ToolStripDropDownButton();
            this.SelectByPriceTSMItem = new System.Windows.Forms.ToolStripMenuItem();
            this.SelectByRepairerTSMItem = new System.Windows.Forms.ToolStripMenuItem();
            this.SelectByOwnerTSMItem = new System.Windows.Forms.ToolStripMenuItem();
            this.SelectByDiagonalTSMItem = new System.Windows.Forms.ToolStripMenuItem();
            this.OFD = new System.Windows.Forms.OpenFileDialog();
            this.SFD = new System.Windows.Forms.SaveFileDialog();
            this.OpenFileTSMItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.StsMain.SuspendLayout();
            this.GbxTv.SuspendLayout();
            this.GbxCheckBox.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // LbxRepairShop
            // 
            this.LbxRepairShop.Font = new System.Drawing.Font("Consolas", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LbxRepairShop.FormattingEnabled = true;
            this.LbxRepairShop.ItemHeight = 19;
            this.LbxRepairShop.Location = new System.Drawing.Point(12, 104);
            this.LbxRepairShop.Name = "LbxRepairShop";
            this.LbxRepairShop.ScrollAlwaysVisible = true;
            this.LbxRepairShop.Size = new System.Drawing.Size(761, 403);
            this.LbxRepairShop.TabIndex = 0;
            this.LbxRepairShop.SelectedIndexChanged += new System.EventHandler(this.LbxRepairShop_SelectedIndexChanged);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem1,
            this.мастерскаяToolStripMenuItem,
            this.телевизорыToolStripMenuItem,
            this.оПрограммеToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1137, 24);
            this.menuStrip1.TabIndex = 3;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.выходToolStripMenuItem,
            this.OpenFileTSMItem});
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(48, 20);
            this.toolStripMenuItem1.Text = "Файл";
            // 
            // выходToolStripMenuItem
            // 
            this.выходToolStripMenuItem.Name = "выходToolStripMenuItem";
            this.выходToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.F4)));
            this.выходToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.выходToolStripMenuItem.Text = "Выход";
            this.выходToolStripMenuItem.Click += new System.EventHandler(this.Exit_Command);
            // 
            // мастерскаяToolStripMenuItem
            // 
            this.мастерскаяToolStripMenuItem.Name = "мастерскаяToolStripMenuItem";
            this.мастерскаяToolStripMenuItem.Size = new System.Drawing.Size(84, 20);
            this.мастерскаяToolStripMenuItem.Text = "Мастерская";
            // 
            // телевизорыToolStripMenuItem
            // 
            this.телевизорыToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.AddTvToolStripMenuItem,
            this.EditTvToolStripMenuItem,
            this.DeleteTvToolStripMenuItem,
            this.toolStripSeparator2,
            this.ReformTSMItem,
            this.AddCollectionTvToolStripMenuItem,
            this.DelTvsToolStripMenuItem,
            this.SortsToolStripMenuItem,
            this.SelectionTSMItem});
            this.телевизорыToolStripMenuItem.Name = "телевизорыToolStripMenuItem";
            this.телевизорыToolStripMenuItem.Size = new System.Drawing.Size(85, 20);
            this.телевизорыToolStripMenuItem.Text = "Телевизоры";
            // 
            // AddTvToolStripMenuItem
            // 
            this.AddTvToolStripMenuItem.Name = "AddTvToolStripMenuItem";
            this.AddTvToolStripMenuItem.Size = new System.Drawing.Size(244, 22);
            this.AddTvToolStripMenuItem.Text = "Добавить TV";
            this.AddTvToolStripMenuItem.Click += new System.EventHandler(this.AddTv_Command);
            // 
            // EditTvToolStripMenuItem
            // 
            this.EditTvToolStripMenuItem.Name = "EditTvToolStripMenuItem";
            this.EditTvToolStripMenuItem.Size = new System.Drawing.Size(244, 22);
            this.EditTvToolStripMenuItem.Text = "Редактировать TV";
            this.EditTvToolStripMenuItem.Click += new System.EventHandler(this.EditTv_Command);
            // 
            // DeleteTvToolStripMenuItem
            // 
            this.DeleteTvToolStripMenuItem.Name = "DeleteTvToolStripMenuItem";
            this.DeleteTvToolStripMenuItem.Size = new System.Drawing.Size(244, 22);
            this.DeleteTvToolStripMenuItem.Text = "Удалить телевизор";
            this.DeleteTvToolStripMenuItem.Click += new System.EventHandler(this.DeleteTv_Command);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(241, 6);
            // 
            // ReformTSMItem
            // 
            this.ReformTSMItem.Name = "ReformTSMItem";
            this.ReformTSMItem.Size = new System.Drawing.Size(244, 22);
            this.ReformTSMItem.Text = "Переформировать коллекцию";
            this.ReformTSMItem.Click += new System.EventHandler(this.ReformCollection_Command);
            // 
            // AddCollectionTvToolStripMenuItem
            // 
            this.AddCollectionTvToolStripMenuItem.Name = "AddCollectionTvToolStripMenuItem";
            this.AddCollectionTvToolStripMenuItem.Size = new System.Drawing.Size(244, 22);
            this.AddCollectionTvToolStripMenuItem.Text = "Добавить коллекцию";
            this.AddCollectionTvToolStripMenuItem.Click += new System.EventHandler(this.AddCollection_Command);
            // 
            // DelTvsToolStripMenuItem
            // 
            this.DelTvsToolStripMenuItem.Name = "DelTvsToolStripMenuItem";
            this.DelTvsToolStripMenuItem.Size = new System.Drawing.Size(244, 22);
            this.DelTvsToolStripMenuItem.Text = "Удалить телевизоры";
            this.DelTvsToolStripMenuItem.Click += new System.EventHandler(this.DelTvGroup_Command);
            // 
            // SortsToolStripMenuItem
            // 
            this.SortsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.SortByProducerTSMItem,
            this.SortByDiagonalTSMItem,
            this.SortByRepairerTSMItem,
            this.SortByOwnerTSMItem});
            this.SortsToolStripMenuItem.Name = "SortsToolStripMenuItem";
            this.SortsToolStripMenuItem.Size = new System.Drawing.Size(244, 22);
            this.SortsToolStripMenuItem.Text = "Сортировки";
            // 
            // SortByProducerTSMItem
            // 
            this.SortByProducerTSMItem.Name = "SortByProducerTSMItem";
            this.SortByProducerTSMItem.Size = new System.Drawing.Size(212, 22);
            this.SortByProducerTSMItem.Text = "По производителю";
            this.SortByProducerTSMItem.Click += new System.EventHandler(this.SortByProducerTSMItem_Command);
            // 
            // SortByDiagonalTSMItem
            // 
            this.SortByDiagonalTSMItem.Name = "SortByDiagonalTSMItem";
            this.SortByDiagonalTSMItem.Size = new System.Drawing.Size(212, 22);
            this.SortByDiagonalTSMItem.Text = "По убыванию диагонали";
            this.SortByDiagonalTSMItem.Click += new System.EventHandler(this.SortByDiagonalTSMItem_Command);
            // 
            // SortByRepairerTSMItem
            // 
            this.SortByRepairerTSMItem.Name = "SortByRepairerTSMItem";
            this.SortByRepairerTSMItem.Size = new System.Drawing.Size(212, 22);
            this.SortByRepairerTSMItem.Text = "По мастеру";
            this.SortByRepairerTSMItem.Click += new System.EventHandler(this.SortByRepairerTSMItem_Command);
            // 
            // SortByOwnerTSMItem
            // 
            this.SortByOwnerTSMItem.Name = "SortByOwnerTSMItem";
            this.SortByOwnerTSMItem.Size = new System.Drawing.Size(212, 22);
            this.SortByOwnerTSMItem.Text = "По владельцу";
            this.SortByOwnerTSMItem.Click += new System.EventHandler(this.SortByOwnerTSMItem_Command);
            // 
            // SelectionTSMItem
            // 
            this.SelectionTSMItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.SelectByMinPriceTSMItem,
            this.SelectRepairerTSMItem,
            this.SelectDiagonalTSMItem,
            this.SelectOwnerTSMItem});
            this.SelectionTSMItem.Name = "SelectionTSMItem";
            this.SelectionTSMItem.Size = new System.Drawing.Size(244, 22);
            this.SelectionTSMItem.Text = "Выборки";
            // 
            // SelectByMinPriceTSMItem
            // 
            this.SelectByMinPriceTSMItem.Name = "SelectByMinPriceTSMItem";
            this.SelectByMinPriceTSMItem.Size = new System.Drawing.Size(265, 22);
            this.SelectByMinPriceTSMItem.Text = "Телевизоры с мин. ценой ремонта";
            this.SelectByMinPriceTSMItem.Click += new System.EventHandler(this.SelectByMinPrice_Command);
            // 
            // SelectRepairerTSMItem
            // 
            this.SelectRepairerTSMItem.Name = "SelectRepairerTSMItem";
            this.SelectRepairerTSMItem.Size = new System.Drawing.Size(265, 22);
            this.SelectRepairerTSMItem.Text = "По выбранному мастеру";
            this.SelectRepairerTSMItem.Click += new System.EventHandler(this.SelectByRepairer_Command);
            // 
            // SelectDiagonalTSMItem
            // 
            this.SelectDiagonalTSMItem.Name = "SelectDiagonalTSMItem";
            this.SelectDiagonalTSMItem.Size = new System.Drawing.Size(265, 22);
            this.SelectDiagonalTSMItem.Text = "По диагонали экрана";
            this.SelectDiagonalTSMItem.Click += new System.EventHandler(this.SelectByDiagonal_Command);
            // 
            // SelectOwnerTSMItem
            // 
            this.SelectOwnerTSMItem.Name = "SelectOwnerTSMItem";
            this.SelectOwnerTSMItem.Size = new System.Drawing.Size(265, 22);
            this.SelectOwnerTSMItem.Text = "По владельцу";
            this.SelectOwnerTSMItem.Click += new System.EventHandler(this.SelectByOwner_Command);
            // 
            // оПрограммеToolStripMenuItem
            // 
            this.оПрограммеToolStripMenuItem.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.оПрограммеToolStripMenuItem.Name = "оПрограммеToolStripMenuItem";
            this.оПрограммеToolStripMenuItem.Size = new System.Drawing.Size(94, 20);
            this.оПрограммеToolStripMenuItem.Text = "О программе";
            this.оПрограммеToolStripMenuItem.Click += new System.EventHandler(this.About_Command);
            // 
            // TbxTv
            // 
            this.TbxTv.Font = new System.Drawing.Font("Consolas", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TbxTv.Location = new System.Drawing.Point(20, 19);
            this.TbxTv.Multiline = true;
            this.TbxTv.Name = "TbxTv";
            this.TbxTv.ReadOnly = true;
            this.TbxTv.Size = new System.Drawing.Size(244, 265);
            this.TbxTv.TabIndex = 4;
            // 
            // StsMain
            // 
            this.StsMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLbl});
            this.StsMain.Location = new System.Drawing.Point(0, 577);
            this.StsMain.Name = "StsMain";
            this.StsMain.Size = new System.Drawing.Size(1137, 22);
            this.StsMain.TabIndex = 5;
            this.StsMain.Text = "statusStrip1";
            // 
            // toolStripStatusLbl
            // 
            this.toolStripStatusLbl.Name = "toolStripStatusLbl";
            this.toolStripStatusLbl.Size = new System.Drawing.Size(0, 17);
            // 
            // GbxTv
            // 
            this.GbxTv.Controls.Add(this.TbxTv);
            this.GbxTv.Location = new System.Drawing.Point(792, 76);
            this.GbxTv.Name = "GbxTv";
            this.GbxTv.Size = new System.Drawing.Size(280, 290);
            this.GbxTv.TabIndex = 6;
            this.GbxTv.TabStop = false;
            this.GbxTv.Text = "     Выбранный телевизор. Полная информация.";
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Consolas", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox1.Location = new System.Drawing.Point(12, 76);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(761, 30);
            this.textBox1.TabIndex = 8;
            this.textBox1.Text = "Производитель    Тип    Диагональ         Дефект            Владелец            М" +
    "астер           Цена   ";
            // 
            // CbxChooseFew
            // 
            this.CbxChooseFew.Font = new System.Drawing.Font("Consolas", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.CbxChooseFew.Location = new System.Drawing.Point(6, 12);
            this.CbxChooseFew.Name = "CbxChooseFew";
            this.CbxChooseFew.Size = new System.Drawing.Size(104, 45);
            this.CbxChooseFew.TabIndex = 10;
            this.CbxChooseFew.Text = "Выбрать несколько";
            this.CbxChooseFew.UseVisualStyleBackColor = true;
            this.CbxChooseFew.CheckedChanged += new System.EventHandler(this.CbxChooseFew_CheckedChanged);
            // 
            // GbxCheckBox
            // 
            this.GbxCheckBox.Controls.Add(this.CbxChooseFew);
            this.GbxCheckBox.Location = new System.Drawing.Point(15, 513);
            this.GbxCheckBox.Name = "GbxCheckBox";
            this.GbxCheckBox.Size = new System.Drawing.Size(116, 61);
            this.GbxCheckBox.TabIndex = 11;
            this.GbxCheckBox.TabStop = false;
            // 
            // BtnDelSpecific
            // 
            this.BtnDelSpecific.BackColor = System.Drawing.Color.IndianRed;
            this.BtnDelSpecific.Enabled = false;
            this.BtnDelSpecific.Location = new System.Drawing.Point(147, 519);
            this.BtnDelSpecific.Name = "BtnDelSpecific";
            this.BtnDelSpecific.Size = new System.Drawing.Size(104, 55);
            this.BtnDelSpecific.TabIndex = 13;
            this.BtnDelSpecific.Text = "Удаление по критерию";
            this.BtnDelSpecific.UseVisualStyleBackColor = false;
            this.BtnDelSpecific.Visible = false;
            this.BtnDelSpecific.Click += new System.EventHandler(this.BtnDelCertain_Click);
            // 
            // toolStrip1
            // 
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripDropDownButton1,
            this.toolStripSplitButton2,
            this.toolStripSeparator1,
            this.toolStripSplitButton1,
            this.BtnSelectionsToolStrip});
            this.toolStrip1.Location = new System.Drawing.Point(0, 24);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(1137, 25);
            this.toolStrip1.TabIndex = 14;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // toolStripDropDownButton1
            // 
            this.toolStripDropDownButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripDropDownButton1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.AddCollectionTSMItem,
            this.добавитьТелевизорToolStripMenuItem});
            this.toolStripDropDownButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripDropDownButton1.Image")));
            this.toolStripDropDownButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripDropDownButton1.Name = "toolStripDropDownButton1";
            this.toolStripDropDownButton1.Size = new System.Drawing.Size(29, 22);
            this.toolStripDropDownButton1.Text = "toolStripDropDownButton1";
            // 
            // AddCollectionTSMItem
            // 
            this.AddCollectionTSMItem.Name = "AddCollectionTSMItem";
            this.AddCollectionTSMItem.Size = new System.Drawing.Size(264, 22);
            this.AddCollectionTSMItem.Text = "Добавить коллекцию телевизоров";
            this.AddCollectionTSMItem.Click += new System.EventHandler(this.AddCollection_Command);
            // 
            // добавитьТелевизорToolStripMenuItem
            // 
            this.добавитьТелевизорToolStripMenuItem.Name = "добавитьТелевизорToolStripMenuItem";
            this.добавитьТелевизорToolStripMenuItem.Size = new System.Drawing.Size(264, 22);
            this.добавитьТелевизорToolStripMenuItem.Text = "Добавить телевизор";
            // 
            // toolStripSplitButton2
            // 
            this.toolStripSplitButton2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripSplitButton2.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.редактироватьДанныеМатсрерскойToolStripMenuItem});
            this.toolStripSplitButton2.Image = ((System.Drawing.Image)(resources.GetObject("toolStripSplitButton2.Image")));
            this.toolStripSplitButton2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripSplitButton2.Name = "toolStripSplitButton2";
            this.toolStripSplitButton2.Size = new System.Drawing.Size(32, 22);
            this.toolStripSplitButton2.Text = "toolStripSplitButton2";
            this.toolStripSplitButton2.ToolTipText = "Редактирование мастерской";
            // 
            // редактироватьДанныеМатсрерскойToolStripMenuItem
            // 
            this.редактироватьДанныеМатсрерскойToolStripMenuItem.Name = "редактироватьДанныеМатсрерскойToolStripMenuItem";
            this.редактироватьДанныеМатсрерскойToolStripMenuItem.Size = new System.Drawing.Size(273, 22);
            this.редактироватьДанныеМатсрерскойToolStripMenuItem.Text = "Редактировать данные матсрерской";
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripSplitButton1
            // 
            this.toolStripSplitButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripSplitButton1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.BtnSortByBrandTSMItem,
            this.BtnSortByDiagonalTSMItem,
            this.BtnSortByRepairerTSMItem,
            this.BtnSortByOwnerTSMItem});
            this.toolStripSplitButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripSplitButton1.Image")));
            this.toolStripSplitButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripSplitButton1.Name = "toolStripSplitButton1";
            this.toolStripSplitButton1.Size = new System.Drawing.Size(32, 22);
            this.toolStripSplitButton1.Text = "toolStripSplitButton1";
            this.toolStripSplitButton1.ToolTipText = "Сортировки";
            // 
            // BtnSortByBrandTSMItem
            // 
            this.BtnSortByBrandTSMItem.Name = "BtnSortByBrandTSMItem";
            this.BtnSortByBrandTSMItem.Size = new System.Drawing.Size(279, 22);
            this.BtnSortByBrandTSMItem.Text = "Сортировка по бренду";
            this.BtnSortByBrandTSMItem.Click += new System.EventHandler(this.SortByProducerTSMItem_Command);
            // 
            // BtnSortByDiagonalTSMItem
            // 
            this.BtnSortByDiagonalTSMItem.Name = "BtnSortByDiagonalTSMItem";
            this.BtnSortByDiagonalTSMItem.Size = new System.Drawing.Size(279, 22);
            this.BtnSortByDiagonalTSMItem.Text = "Сортировка по убыванию диагонали";
            this.BtnSortByDiagonalTSMItem.Click += new System.EventHandler(this.SortByDiagonalTSMItem_Command);
            // 
            // BtnSortByRepairerTSMItem
            // 
            this.BtnSortByRepairerTSMItem.Name = "BtnSortByRepairerTSMItem";
            this.BtnSortByRepairerTSMItem.Size = new System.Drawing.Size(279, 22);
            this.BtnSortByRepairerTSMItem.Text = "Сортировка по мастеру";
            this.BtnSortByRepairerTSMItem.Click += new System.EventHandler(this.SortByRepairerTSMItem_Command);
            // 
            // BtnSortByOwnerTSMItem
            // 
            this.BtnSortByOwnerTSMItem.Name = "BtnSortByOwnerTSMItem";
            this.BtnSortByOwnerTSMItem.Size = new System.Drawing.Size(279, 22);
            this.BtnSortByOwnerTSMItem.Text = "Сортировка по владельцу";
            this.BtnSortByOwnerTSMItem.Click += new System.EventHandler(this.SortByOwnerTSMItem_Command);
            // 
            // BtnSelectionsToolStrip
            // 
            this.BtnSelectionsToolStrip.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.BtnSelectionsToolStrip.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.SelectByPriceTSMItem,
            this.SelectByRepairerTSMItem,
            this.SelectByOwnerTSMItem,
            this.SelectByDiagonalTSMItem});
            this.BtnSelectionsToolStrip.Image = ((System.Drawing.Image)(resources.GetObject("BtnSelectionsToolStrip.Image")));
            this.BtnSelectionsToolStrip.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.BtnSelectionsToolStrip.Name = "BtnSelectionsToolStrip";
            this.BtnSelectionsToolStrip.Size = new System.Drawing.Size(29, 22);
            this.BtnSelectionsToolStrip.Text = "toolStripDropDownButton1";
            this.BtnSelectionsToolStrip.ToolTipText = "Выборки телевизоров";
            // 
            // SelectByPriceTSMItem
            // 
            this.SelectByPriceTSMItem.Name = "SelectByPriceTSMItem";
            this.SelectByPriceTSMItem.Size = new System.Drawing.Size(242, 22);
            this.SelectByPriceTSMItem.Text = "Выборка по мин. стоимости";
            this.SelectByPriceTSMItem.Click += new System.EventHandler(this.SelectByMinPrice_Command);
            // 
            // SelectByRepairerTSMItem
            // 
            this.SelectByRepairerTSMItem.Name = "SelectByRepairerTSMItem";
            this.SelectByRepairerTSMItem.Size = new System.Drawing.Size(242, 22);
            this.SelectByRepairerTSMItem.Text = "Выборка по мастеру";
            this.SelectByRepairerTSMItem.Click += new System.EventHandler(this.SelectByRepairer_Command);
            // 
            // SelectByOwnerTSMItem
            // 
            this.SelectByOwnerTSMItem.Name = "SelectByOwnerTSMItem";
            this.SelectByOwnerTSMItem.Size = new System.Drawing.Size(242, 22);
            this.SelectByOwnerTSMItem.Text = "Выборка по владельцу";
            this.SelectByOwnerTSMItem.Click += new System.EventHandler(this.SelectByOwner_Command);
            // 
            // SelectByDiagonalTSMItem
            // 
            this.SelectByDiagonalTSMItem.Name = "SelectByDiagonalTSMItem";
            this.SelectByDiagonalTSMItem.Size = new System.Drawing.Size(242, 22);
            this.SelectByDiagonalTSMItem.Text = "Выборка по диагонали экрана";
            this.SelectByDiagonalTSMItem.Click += new System.EventHandler(this.SelectByDiagonal_Command);
            // 
            // OFD
            // 
            this.OFD.FileName = "OFD";
            this.OFD.Filter = "(*.json)|*.json";
            // 
            // SFD
            // 
            this.SFD.Filter = "(*.json)|*.json";
            // 
            // OpenFileTSMItem
            // 
            this.OpenFileTSMItem.Name = "OpenFileTSMItem";
            this.OpenFileTSMItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.O)));
            this.OpenFileTSMItem.Size = new System.Drawing.Size(180, 22);
            this.OpenFileTSMItem.Text = "Открыть ";
            this.OpenFileTSMItem.Click += new System.EventHandler(this.Open_Click);
            // 
            // Main_form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1137, 599);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.BtnDelSpecific);
            this.Controls.Add(this.GbxCheckBox);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.GbxTv);
            this.Controls.Add(this.StsMain);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.LbxRepairShop);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.MainMenuStrip = this.menuStrip1;
            this.MaximizeBox = false;
            this.Name = "Main_form";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Задание на 17.11";
            this.Load += new System.EventHandler(this.Main_form_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.StsMain.ResumeLayout(false);
            this.StsMain.PerformLayout();
            this.GbxTv.ResumeLayout(false);
            this.GbxTv.PerformLayout();
            this.GbxCheckBox.ResumeLayout(false);
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox LbxRepairShop;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem выходToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem мастерскаяToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem телевизорыToolStripMenuItem;
        private System.Windows.Forms.TextBox TbxTv;
        private System.Windows.Forms.StatusStrip StsMain;
        private System.Windows.Forms.GroupBox GbxTv;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLbl;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.ToolStripMenuItem AddTvToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem EditTvToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem AddCollectionTvToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem DeleteTvToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripMenuItem DelTvsToolStripMenuItem;
        private System.Windows.Forms.CheckBox CbxChooseFew;
        private System.Windows.Forms.GroupBox GbxCheckBox;
        private System.Windows.Forms.ToolStripMenuItem SortsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem SortByProducerTSMItem;
        private System.Windows.Forms.ToolStripMenuItem SortByDiagonalTSMItem;
        private System.Windows.Forms.ToolStripMenuItem SortByRepairerTSMItem;
        private System.Windows.Forms.ToolStripMenuItem SortByOwnerTSMItem;
        private System.Windows.Forms.ToolStripMenuItem SelectionTSMItem;
        private System.Windows.Forms.ToolStripMenuItem SelectByMinPriceTSMItem;
        private System.Windows.Forms.ToolStripMenuItem SelectRepairerTSMItem;
        private System.Windows.Forms.ToolStripMenuItem SelectDiagonalTSMItem;
        private System.Windows.Forms.ToolStripMenuItem ReformTSMItem;
        private System.Windows.Forms.Button BtnDelSpecific;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripSplitButton toolStripSplitButton1;
        private System.Windows.Forms.ToolStripMenuItem BtnSortByBrandTSMItem;
        private System.Windows.Forms.ToolStripMenuItem BtnSortByDiagonalTSMItem;
        private System.Windows.Forms.ToolStripMenuItem BtnSortByRepairerTSMItem;
        private System.Windows.Forms.ToolStripMenuItem BtnSortByOwnerTSMItem;
        private System.Windows.Forms.ToolStripSplitButton toolStripSplitButton2;
        private System.Windows.Forms.ToolStripMenuItem редактироватьДанныеМатсрерскойToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripDropDownButton BtnSelectionsToolStrip;
        private System.Windows.Forms.ToolStripMenuItem SelectByPriceTSMItem;
        private System.Windows.Forms.ToolStripMenuItem SelectByRepairerTSMItem;
        private System.Windows.Forms.ToolStripMenuItem SelectByOwnerTSMItem;
        private System.Windows.Forms.ToolStripMenuItem SelectByDiagonalTSMItem;
        private System.Windows.Forms.ToolStripMenuItem SelectOwnerTSMItem;
        private System.Windows.Forms.ToolStripDropDownButton toolStripDropDownButton1;
        private System.Windows.Forms.ToolStripMenuItem AddCollectionTSMItem;
        private System.Windows.Forms.ToolStripMenuItem добавитьТелевизорToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem оПрограммеToolStripMenuItem;
        private System.Windows.Forms.OpenFileDialog OFD;
        private System.Windows.Forms.SaveFileDialog SFD;
        private System.Windows.Forms.ToolStripMenuItem OpenFileTSMItem;
    }
}

