﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WF_Televisions.Models;
using WF_Televisions.Forms;
using WF_Televisions.Utilities;
using WF_Televisions.Controller;

namespace WF_Televisions
{
    public partial class Main_form : Form
    {
        //Телемастерская
        //private RepairShop _repairShop;

        //Котроллер 
        private RepairShopController _repairShopController;

        //Имя файла 
        string fileName;
        public Main_form() : this(new RepairShopController())
        { }

        //C_TOR с параметрами
        public Main_form(RepairShopController repairShopController)
        {
            //Создание всех элементов формы
            InitializeComponent();

            _repairShopController = repairShopController;

            //Связывание данных 
            BindRepairShop();

            //Имя файла 
            //fileName = @"\..\..\Collection.json";
            fileName = @"D:\STEP – studying\Home works\2021\November 2021\- 17.11.2021 - result (WF - objects + Dialogs)\Вагнер Владислав\WF_Televisions\Collection.json";

            //Сохранение 
            _repairShopController.Serialize(fileName);

        }

        //Связываение данных
        private void BindRepairShop()
        {
            //Остановить предыдущую привязку
            LbxRepairShop.DataSource = null;

            //Производим привязку заново
            LbxRepairShop.DataSource = _repairShopController.RepairShop.Televisions;

            //Задаём свойство вывода
            LbxRepairShop.DisplayMember = "ToTableRow";
        }


        //Выбор элемента в списке
        private void LbxRepairShop_SelectedIndexChanged(object sender, EventArgs e)
        {
            int ind = LbxRepairShop.SelectedIndex;
            if (ind < 0 || ind >= _repairShopController.RepairShop.Amount)
            {
                TbxTv.Clear();
                BtnDelSpecific.Visible = true;
                return;
            }
           BtnDelSpecific.Visible = false;
            //Выводим информацию в правый text box
            TbxTv.Text = $"{DateTime.Now:HH:mm:ss}\r\n{_repairShopController.RepairShop[ind]}";


        }

        //Загрузка всей формы
        private void Main_form_Load(object sender, EventArgs e)
        {
            //Вывод количества созданных объектов в строку состояния
            //StsMain.Text = $"Телевизоров в мастерской: {_repairShop.Amount}";
            toolStripStatusLbl.Text = $"Мастерская: {_repairShopController.RepairShop.Name} | Телевизоров в мастерской: {_repairShopController.RepairShop.Amount}";

            //Отключаем кнопку удаление нескольких телевизоров 
            DelTvsToolStripMenuItem.Enabled = false;

            //Отключение выделения
            LbxRepairShop.ClearSelected();


           BtnDelSpecific.Visible = false;

            //Временно - проверка корректности поиска мин/макс
            //TbxTempMinMax.Text = $"Max: {_repairShopController.RepairShop.MaxPrice():f3}\r\nMin:{_repairShop.MinPrice():f3}\r\n150.31 ? 150.33 = {150.31.CompareTo(150.33)}";

        }

        // завершение работы приложения
        private void Exit_Command(object sender, EventArgs e) =>
            Application.Exit();

        private void AddTv_Command(object sender, EventArgs e)
        {
            AddObj_form addForm = new AddObj_form();
            DialogResult showResult = addForm.ShowDialog();

            //Если заверешение работы формы произошло не через кнопку добавить/сохранить
            //со свойством DialogResult.Yes, тогда объект не добавляем 
            if (showResult != DialogResult.OK)
                return;

            //Если же завершение работы формы было корректным, тогда добавляем объект в списо TV
            // _repairShopController.RepairShop.AddToList(addForm.television);
            _repairShopController.RepairShop.Televisions.Add(addForm.television);
            //Повторная звязка
            BindRepairShop();

            toolStripStatusLbl.Text = $"Мастерская: {_repairShopController.RepairShop.Name} | Телевизоров в мастерской: {_repairShopController.RepairShop.Amount}";
        }

        //Добавление коллекции телевизоров в фомру
        private void AddCollection_Command(object sender, EventArgs e)
        {
            _repairShopController.RepairShop.AddCollectionToList();

            //Проводим повторную связку с List box
            BindRepairShop();

            toolStripStatusLbl.Text = $"Мастерская: {_repairShopController.RepairShop.Name} | Телевизоров в мастерской: {_repairShopController.RepairShop.Amount}";
        }

        //Удаление телевизора
        private void DeleteTv_Command(object sender, EventArgs e)
        {
            int ind = LbxRepairShop.SelectedIndex;
            //Проверка на корректность выбранного элемента 
            if (ind < 0 || ind >= _repairShopController.RepairShop.Amount)
                return;
            //Удаление элемента
            _repairShopController.RepairShop.Televisions.RemoveAt(ind);

            //Повторное связывание 
            BindRepairShop();

            toolStripStatusLbl.Text = $"Мастерская: {_repairShopController.RepairShop.Name} | Телевизоров в мастерской: {_repairShopController.RepairShop.Amount}";


        }

        //Предикат вхождения в массив
        delegate bool Predicate(int ind);

        //Удаление нескольких телевизоров 
        private void DelTvGroup_Command(object sender, EventArgs e)
        {
            int count = LbxRepairShop.SelectedItems.Count, j = 0;

            int[] inds = new int[count];

            //Сравнение индексов
            Predicate predicate = (index) =>
            {

                //Если индекс есть в списке выбранны
                for (int i = 0; i < count; i++)
                {
                    if (inds[i] == index)
                        return true;
                }
                //Если индекса нет в списке выбранных 
                return false;

            };

            //Цикл сбора индексов 
            foreach (int index in LbxRepairShop.SelectedIndices)
            {
                inds[j++] = index;
            }

            //Удаление
            for (int i = _repairShopController.RepairShop.Amount; i >= 0; i--)
            {
                //Если текущий индекс = выбранному, тогда удаляем обект с этим индексом
                if (predicate(i))
                    _repairShopController.RepairShop.Televisions.RemoveAt(i);

            }


            BindRepairShop();
            CbxChooseFew.CheckState = CheckState.Unchecked;
            toolStripStatusLbl.Text = $"Мастерская: {_repairShopController.RepairShop.Name} | Телевизоров в мастерской: {_repairShopController.RepairShop.Amount}";

        }

        //Check box выбора нескольких телевизоров
        private void CbxChooseFew_CheckedChanged(object sender, EventArgs e)
        {
            if (CbxChooseFew.CheckState == CheckState.Checked)
            {
                

                //Изменение настроек списка
                LbxRepairShop.SelectionMode = SelectionMode.MultiSimple;

                //Проиводим перепривязку. Поскольку в противном случае иногда появляются 
                //проблемы с DiplayMember
                BindRepairShop();

                LbxRepairShop.ClearSelected();

                //Изменение состояний кнопок 
                AddTvToolStripMenuItem.Enabled = false;
                AddCollectionTvToolStripMenuItem.Enabled = false;
                ReformTSMItem.Enabled = false;
                EditTvToolStripMenuItem.Enabled = false;

                //Отключаем кнопку выборки 
                SelectionTSMItem.Enabled = false;

                DeleteTvToolStripMenuItem.Enabled = false;
                AddCollectionTvToolStripMenuItem.Enabled = false;

                DelTvsToolStripMenuItem.Enabled = true;

                //Очистка текстового поля
                GbxTv.Visible = false;

                //19.11.21 - кнопка удаления определенных телевизоров 
                BtnDelSpecific.Enabled = true;
                BtnDelSpecific.Visible = true;

                
                return;
            }

            GbxTv.Visible = true;
            
            //Изменение настроек списка
            LbxRepairShop.SelectionMode = SelectionMode.One;
            //Проиводим перепривязку 
            BindRepairShop();
            //Изменение состояний кнопок
            AddTvToolStripMenuItem.Enabled = true;
            ReformTSMItem.Enabled = true;
            AddCollectionTvToolStripMenuItem.Enabled = true;
            EditTvToolStripMenuItem.Enabled = true;
            DeleteTvToolStripMenuItem.Enabled = true;
            AddCollectionTvToolStripMenuItem.Enabled = true;

            DelTvsToolStripMenuItem.Enabled = false;
            //Включаем кнопку выборки 
            SelectionTSMItem.Enabled = true;

            //Кнопка удаления определенных телевизоров 
            BtnDelSpecific.Enabled = false;
            BtnDelSpecific.Visible = false;

           

        }

        private void SortByProducerTSMItem_Command(object sender, EventArgs e)
        {
            //Сортировка коллекции
            _repairShopController.SortByProducer();

            //Повторная привязка
            BindRepairShop();
        }

        private void SortByDiagonalTSMItem_Command(object sender, EventArgs e)
        {

            //Сортировка коллекции
            _repairShopController.SortDescByDiagonal();

            //Повторная привязка
            BindRepairShop();
        }

        private void SortByRepairerTSMItem_Command(object sender, EventArgs e)
        {

            //Сортировка коллекции
            _repairShopController.SortByRapairer();

            //Повторная привязка
            BindRepairShop();
        }

        private void SortByOwnerTSMItem_Command(object sender, EventArgs e)
        {

            //Сортировка коллекции
            _repairShopController.SortByOwner();

            //Повторная привязка
            BindRepairShop();
        }

        private void ReformCollection_Command(object sender, EventArgs e)
        {
            _repairShopController.RepairShop.Generate(Utils.Random.Next(12, 15));

            //Производим повторную привязку коллекции в List box
            BindRepairShop();

            toolStripStatusLbl.Text = $"Мастерская: {_repairShopController.RepairShop.Name} | Телевизоров в мастерской: {_repairShopController.RepairShop.Amount}";


        }

        #region Выборки
        //Выборка телевизоров
        private void SelectByMinPrice_Command(object sender, EventArgs e)
        {
            List<Television> televisions = _repairShopController.SelectByMinPrice();
            Form selection_Form = new Selection_form("Выборка по минимальной цене", televisions.ToArray());
            selection_Form.ShowDialog();
        }

        //Выборка по мастерам 
        private void SelectByRepairer_Command(object sender, EventArgs e)
        {
            //Список для хранения возвращаемого списка 
            List<Television> Tvs = new List<Television>();

            //Создаём окно выбора подколлекции 
            Select_Certain select_Certain = new Select_Certain(_repairShopController, Select_Certain.SubObject.repairer);

            if (select_Certain.ShowDialog() != DialogResult.OK)
                return;

            //Получаем выбранного мастера
            string ChosenRepairer = (string)select_Certain.ChosenItem;

            Tvs = _repairShopController.SelectByRepairer(ChosenRepairer);

            Selection_form selection_Form = new Selection_form($"Выборка всех телевизоров владельца \"{ChosenRepairer}\"", Tvs.ToArray());
            selection_Form.ShowDialog();
        }

        //Выборка по диагонали
        private void SelectByDiagonal_Command(object sender, EventArgs e)
        {

            //Список для хранения возвращаемого списка 
            List<Television> Tvs = new List<Television>();

            //Создаём окно выбора подколлекции 
            Select_Certain select_Certain = new Select_Certain(_repairShopController, Select_Certain.SubObject.diagonal);

            if (select_Certain.ShowDialog() != DialogResult.OK)
                return;

            //Получаем выбранную
            double ChosenDiagonal = (double)select_Certain.ChosenItem;

            Tvs = _repairShopController.SelectByDiagonal(ChosenDiagonal);

            Selection_form selection_Form = new Selection_form($"Выборка телевизоров с диагональю {ChosenDiagonal:f2}", Tvs.ToArray());
            selection_Form.ShowDialog();
        }

        //Выборка по владельцу
        private void SelectByOwner_Command(object sender, EventArgs e)
        {

            //Список для хранения возвращаемого списка 
            List<Television> Tvs = new List<Television>();

            //Создаём окно выбора подколлекции 
            Select_Certain select_Certain = new Select_Certain(_repairShopController, Select_Certain.SubObject.owner);

            if (select_Certain.ShowDialog() != DialogResult.OK)
                return;

            //Получаем выбранного владельца
            string ChosenOwner = (string)select_Certain.ChosenItem;

            Tvs = _repairShopController.SelectByOwner(ChosenOwner);

            Selection_form selection_Form = new Selection_form($"Выборка телевизоров мастера {ChosenOwner}", Tvs.ToArray());
            selection_Form.ShowDialog();
        }
        #endregion

        //Удаление множества телевизоров
        private void BtnDelCertain_Click(object sender, EventArgs e)
        {
            //Вызываем форму удаления 
            Del_Certain_Tv_Form del_Form = new Del_Certain_Tv_Form(_repairShopController);

            if (del_Form.ShowDialog() != DialogResult.OK)
                return;
            //Получаем измененный контроллер
            _repairShopController = del_Form.rsController;

            //Проводим повторную свяку
            BindRepairShop();

            CbxChooseFew.CheckState = CheckState.Unchecked;
            toolStripStatusLbl.Text = $"Мастерская: {_repairShopController.RepairShop.Name} | Телевизоров в мастерской: {_repairShopController.RepairShop.Amount}";

            //P.s. в ходе проверок появилась проблема: если одним из удаляемых элементов будет 
            //последний элемент в коллекции - тогда следает свойство в DisplayMember и отрабатывает только toString
            //не смог понять почему
        }

        //Редактирование телевизора
        private void EditTv_Command(object sender, EventArgs e)
        {
            //Проверка на наличие выбранного элемента 
            if (LbxRepairShop.SelectedIndex < 0 || LbxRepairShop.SelectedIndex >= _repairShopController.RepairShop.Amount)
            {
                MessageBox.Show("Не выбран телевизор", "Ошибка", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
                return;
            }

            Edit_Obj_Form editTvForm = new Edit_Obj_Form((Television)LbxRepairShop.SelectedItem);
            DialogResult showResult = editTvForm.ShowDialog();

            //Если заверешение работы формы произошло не через кнопку добавить/сохранить
            //со свойством DialogResult.Yes, тогда объект не добавляем 
            if (showResult != DialogResult.OK)
                return;

            //Если же завершение работы формы было корректным, тогда добавляем объект в списо TV
            // _repairShopController.RepairShop.AddToList(addForm.television);
            _repairShopController.RepairShop.Televisions.Add(editTvForm.television);
            //Повторная звязка
            BindRepairShop();

            toolStripStatusLbl.Text = $"Мастерская: {_repairShopController.RepairShop.Name} | Телевизоров в мастерской: {_repairShopController.RepairShop.Amount}";
        }

        //Запус формы о программе
        private void About_Command(object sender, EventArgs e)
        {
            Form fromAbout = new AboutForm();
            fromAbout.ShowDialog();
        }

        //Десериализация данных
        private void Open_File(object sender, CancelEventArgs e)
        {
            _repairShopController.Serialize(OFD.FileName);
            BindRepairShop();
        }

        private void Open_Click(object sender, EventArgs e)
        {
            DialogResult showResult = OFD.ShowDialog();
            if (showResult != DialogResult.OK)
                return;
            _repairShopController.Serialize(OFD.FileName);
            BindRepairShop();

        }
    } 

}
