﻿using System.Windows.Forms;
using Main.Properties;


namespace Main.Common
{
	public class BaseForm : Form
	{
		protected BaseForm() =>
			Icon = Resources.MainIcon;
	}
}