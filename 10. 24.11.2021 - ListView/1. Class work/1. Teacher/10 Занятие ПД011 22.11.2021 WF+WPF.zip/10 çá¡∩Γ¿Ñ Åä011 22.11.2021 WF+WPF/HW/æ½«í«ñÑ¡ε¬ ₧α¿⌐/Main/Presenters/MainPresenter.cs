﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using Main.ApplicationControl;
using Main.Common;
using Main.Models;
using Main.Views;
using Microsoft.VisualBasic;


namespace Main.Presenters
{
	internal sealed class MainPresenter : BasePresenter<IMainFormView>
	{
		private RepairShop _shop = new("Title", "Address");
		private readonly TelevisionValidator _validator = new();
		private readonly JsonRepository<RepairShop> _repository = new("Televisions.json");


		public MainPresenter(IMainFormView view, IApplicationController controller)
			: base(view, controller)
		{
			ViewOnFillRequired();
			RefreshData();

			View.FillRequired       += ViewOnFillRequired;
			View.ValidateRequired   += ViewOnValidateRequired;
			View.ShopDetailsChanged += ViewOnShopDetailsChanged;
			View.RemoveRequested    += ViewOnRemoveRequested;

			View.ProducerAndTypeOrderRequired += () =>
				ShowOrderedItems(_shop.OrderBy(t => t.Producer).ThenBy(t => t.Type));
			View.DiagonalDescendingOrderRequired += () =>
				ShowOrderedItems(_shop.OrderByDescending(t => t.Diagonal));
			View.RepairerOrderRequired += () =>
				ShowOrderedItems(_shop.OrderBy(t => t.Repairer));
			View.OwnerOrderRequired += () =>
				ShowOrderedItems(_shop.OrderBy(t => t.Owner));

			View.SelectMinPrice += () =>
				ShowOrderedItems(ViewOnSelectMinPrice());
			View.SelectRepairer += () =>
				ViewOnSelectRepairer();
			View.SelectDiagonal += () =>
				ViewOnSelectDiagonal();

			View.SaveToJsonRequested   += ViewOnSaveToJsonRequested;
			View.LoadFromJsonRequested += ViewOnLoadFromJsonRequested;
		}


		private void ViewOnLoadFromJsonRequested(OpenFileDialog dialog)
		{
			if (dialog.ShowDialog() != DialogResult.OK)
				return;

			_repository.Path = Path.GetFullPath(dialog.FileName);
			_shop            = _repository.Load() ?? _shop;
			RefreshData();
		}


		private void ViewOnSaveToJsonRequested(SaveFileDialog dialog)
		{
			if (dialog.ShowDialog() != DialogResult.OK)
				return;

			_repository.Path = Path.GetFullPath(dialog.FileName);
			_repository.Save(_shop);
		}


		private void ViewOnRemoveRequested(int index) =>
			_shop.RemoveAt(index);


		private void ViewOnSelectDiagonal()
		{
			bool isInputFailed = !int.TryParse(
									 Interaction.InputBox("Введите диагональ: ", "Выборка по диагонали"),
									 out int input);

			if (isInputFailed)
				return;

			ShowOrderedItems(_shop.Where(t => t.Diagonal == input));
		}


		private void ViewOnSelectRepairer()
		{
			var input = Interaction.InputBox("Введите мастера: ", "Выборка по мастеру");

			if (string.IsNullOrWhiteSpace(input))
				return;

			ShowOrderedItems(_shop.Where(t => t.Repairer == input));
		}


		private IEnumerable<Television> ViewOnSelectMinPrice()
		{
			var minPrice = _shop.Min(t => t.Price);

			return _shop.Where(t => t.Price == minPrice);
		}


		private void ShowOrderedItems(IEnumerable<Television> items) =>
			Controller.Run<SelectedTelevisionsPresenter, IEnumerable<Television>>(items);


		private void ViewOnShopDetailsChanged(string title, string address)
		{
			_shop.Title   = title;
			_shop.Address = address;
		}


		private void RefreshData()
		{
			View.SetShopDetails(_shop.Title, _shop.Address);
			View.SetView(new BindingList<Television>(_shop));
		}


		private void ViewOnFillRequired()
		{
			Random rand = new();

			_shop.Fill(Controller.ResolveService<ITelevisionProvider>(),
				(uint)rand.Next(7, 24));

			View.SetView(_shop);
		}


		private void ViewOnValidateRequired(DataGridView grid, DataGridViewCellCancelEventArgs e)
		{
			var television = _shop[e.RowIndex];

			var validationResults = _validator.Validate(television);

			if (!validationResults.IsValid)
			{
				grid.Rows[e.RowIndex].ErrorText = validationResults.ToString();

				e.Cancel = true;
				return;
			}

			grid.Rows[e.RowIndex].ErrorText = null;
		}
	}
}