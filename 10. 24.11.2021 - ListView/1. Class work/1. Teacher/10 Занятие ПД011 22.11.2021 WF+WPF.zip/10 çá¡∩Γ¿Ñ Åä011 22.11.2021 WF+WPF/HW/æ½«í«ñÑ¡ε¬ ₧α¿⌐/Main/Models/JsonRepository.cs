﻿using System.Collections.Generic;
using System.IO;
using System.Linq;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;


namespace Main.Models
{
	internal sealed class JsonRepository<T> 
	{
		private readonly JsonSerializer _serializer = new()
		{
			Formatting = Formatting.Indented
		};


		public string Path { get; set; }


		public JsonRepository(string path) => Path = path;


		public void Save(T value)
		{
			using var writer = OpenWriter();
			_serializer.Serialize(writer, value);
		}


		public void SaveRange(IEnumerable<T> values)
		{
			using var writer = OpenWriter();
			_serializer.Serialize(writer, values);
		}


		public T? Load()
		{
			using var reader = OpenReader();

			var items = _serializer.Deserialize<T>(reader);

			return items ?? default;
		}


		public IEnumerable<T?> LoadRange()
		{
			using var reader = OpenReader();

			var items = _serializer.Deserialize<List<T>>(reader);

			return items ?? Enumerable.Empty<T>();
		}


		public void Clear() => File.Delete(Path);


		private JsonTextWriter OpenWriter() => new(File.CreateText(Path));

		private JsonTextReader OpenReader() => new(File.OpenText(Path));
	}
}