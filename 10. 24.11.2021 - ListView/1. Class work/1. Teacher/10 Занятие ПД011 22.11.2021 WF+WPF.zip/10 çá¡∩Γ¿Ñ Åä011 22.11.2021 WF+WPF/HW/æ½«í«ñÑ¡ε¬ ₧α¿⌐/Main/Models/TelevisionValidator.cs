﻿using FluentValidation;


namespace Main.Models
{
	public class TelevisionValidator : AbstractValidator<Television>
	{
		public TelevisionValidator()
		{
			RuleFor(t => t.Diagonal).GreaterThan(0);
			RuleFor(t => t.Price).GreaterThanOrEqualTo(0m);
		}
	}
}