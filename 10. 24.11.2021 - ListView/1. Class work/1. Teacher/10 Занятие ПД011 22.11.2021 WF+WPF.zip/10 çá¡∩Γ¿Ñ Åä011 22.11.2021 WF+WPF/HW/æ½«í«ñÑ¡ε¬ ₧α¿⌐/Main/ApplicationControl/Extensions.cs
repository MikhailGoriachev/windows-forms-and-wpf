﻿using System;


namespace Main.ApplicationControl
{
	internal static class Extensions
	{
		public static double RealNextDouble(this Random rand, double min = 1, double max = 10) =>
			rand.NextDouble() * (max - min) + min;
	}
}