﻿namespace Main.Models
{
	public interface ITelevisionProvider
	{
		Television Provide();
	}
}