﻿namespace Main.Models
{
	public sealed class TelevisionProvider : ITelevisionProvider
	{
		private int _filler = 0;

		public Television Provide()
		{
			_filler++;

			return new(
				$"Producer{_filler}", $"Type{_filler}",
				_filler, $"Defect{_filler}", $"Repairer{_filler}",
				$"Owner{_filler}", _filler
			);
		}
	}
}