﻿using System.Collections;
using System.Collections.Generic;
using Newtonsoft.Json;


namespace Main.Models
{
	[JsonObject(MemberSerialization.OptIn)]
	public sealed class RepairShop : IList<Television>
	{
		[JsonProperty("Items", Order = int.MaxValue)]
		private readonly List<Television> _televisions = new();

		[JsonProperty]
		public string Address { get; set; }
		[JsonProperty]
		public string Title { get; set; }

		public int Count => _televisions.Count;
		bool ICollection<Television>.IsReadOnly => ((ICollection<Television>)_televisions).IsReadOnly;
		public Television this[int index] { get => _televisions[index]; set => _televisions[index] = value; }


		public RepairShop(string title, string address)
		{
			Title   = title;
			Address = address;
		}


		public void Fill(ITelevisionProvider provider, uint size)
		{
			_televisions.Clear();

			for (int i = 0; i < size; i++)
				_televisions.Add(provider.Provide());
		}


		public void Add(Television item) =>
			_televisions.Add(item);


		public void Clear() =>
			_televisions.Clear();


		public bool Contains(Television item) =>
			_televisions.Contains(item);


		public void CopyTo(Television[] array, int arrayIndex) =>
			_televisions.CopyTo(array, arrayIndex);


		public bool Remove(Television item) =>
			_televisions.Remove(item);


		IEnumerator IEnumerable.GetEnumerator() =>
			((IEnumerable)_televisions).GetEnumerator();


		public IEnumerator<Television> GetEnumerator() =>
			_televisions.GetEnumerator();


		public int IndexOf(Television item) =>
			_televisions.IndexOf(item);


		public void Insert(int index, Television item) =>
			_televisions.Insert(index, item);


		public void RemoveAt(int index) =>
			_televisions.RemoveAt(index);
	}
}