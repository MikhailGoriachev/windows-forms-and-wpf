﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using HW9.Models;

namespace HW9.Views
{
	public partial class ReportForm : Form
	{
		private List<Television> _televisions;


		public ReportForm(List<Television> televisions, string prompt)
		{
			InitializeComponent();
			_televisions = televisions;

			LblTitle.Text = prompt;

			LbxTelevisions.DataSource = _televisions;
			LbxTelevisions.DisplayMember = "TableRow";
		}

		private void BtnClose_Click(object sender, EventArgs e) => Close();

		private void ReportForm_Load(object sender, EventArgs e)
		{
			LblHeader.Text = Television.Header;
		}
	}
}
