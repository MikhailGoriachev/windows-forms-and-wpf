﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using HW9.Models;

namespace HW9.Views
{
	public partial class TVForm : Form
	{
		private Television _tv;

		public Television Tv
		{
			get => _tv;
			set
			{
				_tv = value;

				TxbBrandType.Text = _tv.BrandType;
				TxbDefect.Text = _tv.Defect;
				TxbRepairer.Text = _tv.Repairer;
				TxbOwner.Text = _tv.Owner;
				NudDiagonal.Text = _tv.Diagonal.ToString();
				NudPrice.Text = _tv.Price.ToString();
			}
		}

		// конструктор для формы в режиме добавления нового телевизора
		public TVForm()
		{
			InitializeComponent();
			_tv = new Television();
		}

        // конструктор для формы в режиме редкатирования данных телевизора
		public TVForm(string formTitle, string btnTitle)
		{
			InitializeComponent();
			_tv = new Television();

			// Заголовок формы
			Text = formTitle;
			BtnAdd.Text = btnTitle;
		}

		// Обработчик кнопки "Добавить"/"Сохранить" - собрать данные из элементов
		// интерфейса
		private void BtnAdd_Click(object sender, EventArgs e)
		{
			if (IsEmptyFields()) return;

			_tv = new Television()
			{
				BrandType = TxbBrandType.Text,
				Defect = TxbDefect.Text,
				Diagonal = int.Parse(NudDiagonal.Text),
				Owner = TxbOwner.Text,
				Price = int.Parse(NudPrice.Text),
				Repairer = TxbRepairer.Text
			};

		}

		// Не даём закрыться окну, если есть пустые поля
		private void TVForm_FormClosing(object sender, FormClosingEventArgs e)
		{
			if ((DialogResult == DialogResult.OK) & IsEmptyFields())
			{
				MessageBox.Show("Не все данные заполнены", "Ошибка",
					MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				e.Cancel = true;
			}
		}
		public bool IsEmptyFields() =>
			string.IsNullOrWhiteSpace(TxbBrandType.Text) ||
			string.IsNullOrWhiteSpace(TxbDefect.Text) ||
			string.IsNullOrWhiteSpace(TxbOwner.Text) ||
			string.IsNullOrWhiteSpace(TxbRepairer.Text) ||
			string.IsNullOrWhiteSpace(NudDiagonal.Text) ||
			string.IsNullOrWhiteSpace(NudPrice.Text);

		private void Nud_KeyDown(object sender, KeyEventArgs e) =>
			e.SuppressKeyPress = e.KeyData == Keys.OemMinus || e.KeyData == Keys.Subtract;
	}
}
