﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using HW9.Models;


namespace HW9.Controllers
{
	public class RepairShopController
	{
		// объект для обработки
		private RepairShop _repairShop;

		public RepairShop RepairShop
		{
			get => _repairShop;
			private set => _repairShop = value;
		}

		// конструкторы
		public RepairShopController() : this(new RepairShop())
		{
			_repairShop.Initialize();
		}
		public RepairShopController(RepairShop repairShop)
		{
			_repairShop = repairShop;
		}

		// получить список мастеров
		public List<string> GetRepairers => _repairShop.GetRepairers;

		// получить список диагоналей
		public List<string> GetDiagonal => _repairShop.GetDiagonals;


		#region Сериализация

		// Сохранение в файл JSON форматом
		public void SaveJsonToFile(string fileName)
		{
			using (StreamWriter file = File.CreateText(fileName))
			{
				new JsonSerializer{Formatting = Formatting.Indented}.Serialize(file, _repairShop);
			}
		}

		// Чтение из файла JSON форматом
		public void ReadJsonFromFile(string fileName)
		{

			using (StreamReader file = File.OpenText(fileName))
			{
				JsonSerializer serializer = new JsonSerializer();
				_repairShop.RemoveAll();
				_repairShop = (RepairShop)serializer.Deserialize(file, typeof(RepairShop));
			}

		}
		#endregion


		#region Сортировки

		// Запрос на упорядочивание коллекции по производителю и типу
		public void OrderByBrand() => RepairShop.OrderBy((t1, t2) =>
			t1.BrandType.CompareTo(t2.BrandType));

		// Запрос на упорядочивание коллекции по убыванию диагонали экрана
		public void OrderByDiagonalDesc() => RepairShop.OrderBy((t1, t2) =>
			t2.Diagonal.CompareTo(t1.Diagonal));

		// Запрос на упорядочивание коллекции по мастеру, выполняющему ремонт
		public void OrderByRepairer() => RepairShop.OrderBy((t1, t2) =>
			t1.Repairer.CompareTo(t2.Repairer));

		// Запрос на упорядочивание коллекции по владельцу телевизора
		public void OrderByOwner() => RepairShop.OrderBy((t1, t2) =>
			t1.Owner.CompareTo(t2.Owner));

		// Запрос на упорядочивание коллекции по стоимости
		public void OrderByPrice() => RepairShop.OrderBy((t1, t2) =>
			t1.Price.CompareTo(t2.Price));
		#endregion


		#region Выборки

		// Запрос на выборку в коллекцию телевизоров с минимальной стоимостью ремонта
		public List<Television> SelectWhereMinPrice()
		{
			int minPrice = _repairShop.MinPrice;
			return _repairShop.Filter(t => t.Price == minPrice);
		}

		// Запрос на выборку в коллекцию телевизоров, ремонтируемых заданным мастером
		public List<Television> SelectWhereRepairer(string repairer) =>
			_repairShop.Filter(t => t.Repairer == repairer);

		// Запрос на выборку в коллекцию телевизоров с заданной диагональю экран
		public List<Television> SelectWhereDiagonal(int diagonal) =>
			_repairShop.Filter(t => t.Diagonal == diagonal);

		// Запрос на выборку в коллекцию телевизоров с заданной диагональю экран
		public List<Television> SelectWhereOwner(string owner) =>
			_repairShop.Filter(t => t.Owner == owner);

		#endregion

	}
}
