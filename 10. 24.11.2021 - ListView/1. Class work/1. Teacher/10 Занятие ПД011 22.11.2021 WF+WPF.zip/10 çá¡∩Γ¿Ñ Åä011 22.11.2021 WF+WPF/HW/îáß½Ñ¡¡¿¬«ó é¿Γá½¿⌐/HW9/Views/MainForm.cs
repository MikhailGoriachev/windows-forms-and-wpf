﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using HW9.Controllers;
using HW9.Views;
using HW9.Models;

namespace HW9.Views
{
	public partial class MainForm : Form
	{
		// объект контроллера для работы
		private RepairShopController _repairShopController;

		// директория и имя файля для сохранения
		private string _fileName;

		// для хранения предыдущей директории сохранения при создании нового файла
		private string _lastDirectory;

		// маркер на изменения
		private bool _isSaved;

		public MainForm() : this(new RepairShopController()) { }

		public MainForm(RepairShopController repairShopController)
		{

			InitializeComponent();

			_fileName = "";
			_lastDirectory = "";
			_isSaved = false;

			_repairShopController = repairShopController;

			// установка делегатов сортировок в тег элементов для сокращения кода
			MnuOrderByBrandType.Tag = TsbOrderByBrand.Tag = (Action)_repairShopController.OrderByBrand;
			MnuOrderByDiagDesc.Tag = TsbOrderByDiagonal.Tag = (Action)_repairShopController.OrderByDiagonalDesc;
			MnuOrderByOwner.Tag = TsbOrderByOwner.Tag = (Action)_repairShopController.OrderByOwner;
			MnuOrderByPrice.Tag = TsbOrderByPrice.Tag = (Action)_repairShopController.OrderByPrice;
			MnuOrderByRepairer.Tag = TsbOrderByRepairer.Tag = (Action)_repairShopController.OrderByRepairer;

			BindCollection();
		}

		// выполняется после конструктора формы
		private void MainForm_Load(object sender, EventArgs e)
		{
			// обновить заголовок главного окна
			UpdateMainTitle();

			// установка текста в информационные элементы формы
			GrbShopTitle.Text = _repairShopController.RepairShop.Title + ". Адрес: " + _repairShopController.RepairShop.Address;
			StlMain.Text = $"Телевизоров в ремонте: {_repairShopController.RepairShop.Count}";
			LblHeader.Text = Television.Header;
		}

		// обновление заголовка главного окна
		private void UpdateMainTitle()
		{
			// формировка заголовка с проверкой на наличией изменений с последнего сохранения
			StringBuilder sb = new StringBuilder();
			sb.Append(_isSaved ? "" : "*");
			sb.Append(string.IsNullOrEmpty(_fileName) ? "Новая коллекция" : Path.GetFileNameWithoutExtension(_fileName));
			sb.Append(" - RepairShop");

			// установка заголовка в форму
			Text = sb.ToString();
		}

		// выполнение привязки коллекции
		private void BindCollection()
		{
			// остановить привязку
			LbxTelevisions.DataSource = null;

			// задать привязку
			LbxTelevisions.DataSource = _repairShopController.RepairShop.Televisions;

			LbxTelevisions.DisplayMember = "TableRow";
		}

		// команда заверешния работы приложения
		private void Exit_Command(object sender, EventArgs e) => Application.Exit();

		// обработка события закрытия формы
		private void MainForm_FormClosing(object sender, FormClosingEventArgs e)
		{
			// если изменений в данных после последнего сохранения не было - разрешаем событие
			if (_isSaved) return;

			// иначе спрашиваем сохранить ли данные в файл
			DialogResult result = MessageBox.Show($"Сохранить данные?", "RepairShop", MessageBoxButtons.YesNoCancel,
				MessageBoxIcon.Question);

			switch (result)
			{
				// пользователь выбрал отмену закрытия программы (Cancel)
				case DialogResult.Cancel:
					e.Cancel = true;
					break;
				// решено сохранить данные - инициируем метод сохранения
				case DialogResult.Yes:
					// если открытый диалог сохранения не завершен утвердительно - отменяем событие закрытия формы
					e.Cancel = !SaveFile();
					break;
			}
		}


		// команда отображения окна сведений о программе
		private void About_Command(object sender, EventArgs e)
		{
			AboutForm aboutForm = new AboutForm();
			aboutForm.ShowDialog();
		}

		// Команда отображения формы изменения данных о ремонтной мастерской
		private void ShopSettings_Command(object sender, EventArgs e)
		{
			ShopSettingsForm settingsForm =
				new ShopSettingsForm(_repairShopController.RepairShop.Title, _repairShopController.RepairShop.Address);

			if (settingsForm.ShowDialog() != DialogResult.OK) return;

			_repairShopController.RepairShop.Title = settingsForm.Title;
			_repairShopController.RepairShop.Address = settingsForm.Address;

			GrbShopTitle.Text = _repairShopController.RepairShop.Title + ". Адрес: " + _repairShopController.RepairShop.Address;
		}
		
		// Обработка выделения элемента листа перед появлением контекстного меню
		// по нажатию на правую кнопку мыши
		private void LbxTelevisions_MouseUp(object sender, MouseEventArgs e)
		{
			if (e.Button == MouseButtons.Right)
			{
				int index = this.LbxTelevisions.IndexFromPoint(e.Location);
				if (index != ListBox.NoMatches)
					LbxTelevisions.SelectedIndex = index;
			}
		}

		// Обработка двойного щелчка по листу - изменение элемента
		private void LbxTelevisions_MouseDoubleClick(object sender, MouseEventArgs e) =>
			TelevisionEdit_Command(sender, e);



		#region Управление коллекцией записей о телевизорах

		// Сформировать коллекцию заново
		private void Regenerate_Command(object sender, EventArgs e)
		{
			_repairShopController.RepairShop.Initialize();
			BindCollection();

			StlMain.Text = $"Сгенерирована новая коллекция. Телевизоров в ремонте: {_repairShopController.RepairShop.Count}";

			_isSaved = false;
			UpdateMainTitle();
		}

		// Удалить выделенную запись о телевизоре
		private void TelevisionRemove_Command(object sender, EventArgs e)
		{
			if (LbxTelevisions.SelectedIndex < 0)
				return;

			// индекс выбранного элемента
			int selected = LbxTelevisions.SelectedIndex;

			// удаление записи данных 
			_repairShopController.RepairShop.RemoveAt(selected);

			// перепривязка данных
			BindCollection();

			// Возврат выделения элемента на место удаленного, если возможно
			LbxTelevisions.SelectedIndex = !_repairShopController.RepairShop.IsEmpty
				? selected < _repairShopController.RepairShop.Count
					? selected : _repairShopController.RepairShop.Count - 1 : -1;

			// обновить строку состояния
			StlMain.Text = $"Из коллекции был удалён телевизор. Текущее количество телевизоров: {_repairShopController.RepairShop.Count}";

			_isSaved = false;
			UpdateMainTitle();
		}


		// Добавить запись о телевизоре
		private void TelevisionAdd_Command(object sender, EventArgs e)
		{

			TVForm tvForm = new TVForm();
			DialogResult dialogResult = tvForm.ShowDialog();

			// если окно закрыто не по кнопке "Добавить" - молча уходим
			if (dialogResult != DialogResult.OK) return;

			// получить данные из свойства формы
			Television television = tvForm.Tv;
			_repairShopController.RepairShop.AddTelevision(television);

			// обновить привязку
			BindCollection();

			// установка выделения в конец списка на новый элемент
			LbxTelevisions.SelectedIndex = _repairShopController.RepairShop.Count - 1;

			// обновить строку состояния
			StlMain.Text = $"В коллекцию был добавлен телевизор. Текущее количество телевизоров: {_repairShopController.RepairShop.Count}";

			_isSaved = false;
			UpdateMainTitle();
		}

		// Редактировать выделенную запись о телевизоре
		private void TelevisionEdit_Command(object sender, EventArgs e)
		{
			// если нет выбранного телевизора - уходим
			if (LbxTelevisions.SelectedIndex < 0)
				return;

			// индекс выбранного элемента
			int selected = LbxTelevisions.SelectedIndex;

			// передача данных в форму
			TVForm tvForm = new TVForm("Редактировать данные о телевизоре", "Сохранить")
			{
				Tv = _repairShopController.RepairShop[selected]
			};

			if (tvForm.ShowDialog() != DialogResult.OK) return;

			// получить данные
			_repairShopController.RepairShop[LbxTelevisions.SelectedIndex] = tvForm.Tv;

			BindCollection();

			// Установка выделения на изменённый элемент
			LbxTelevisions.SelectedIndex = selected;

			// обновить строку состояния
			StlMain.Text = $"Были изменены данные о телевизоре. Текущее количество телевизоров: {_repairShopController.RepairShop.Count}";

			_isSaved = false;
			UpdateMainTitle();
		}


		// Удалить все данные о телевизорах
		private void RemoveAll_Command(object sender, EventArgs e)
		{
			_repairShopController.RepairShop.RemoveAll();
			BindCollection();

			StlMain.Text = $"Все данные удалены.";

			_isSaved = false;
			UpdateMainTitle();
		}

		#endregion



		#region Сортировка

		// Вызов сортировки по тегу ToolStripMenu
		private void ToolStripMenu_OrderBy_Click(object sender, EventArgs e) =>
			OrderBy_Command((Action)((ToolStripMenuItem)sender).Tag);

		// Вызов сортировки по тегу ToolStripButton
		private void ToolStripButton_OrderBy_Click(object sender, EventArgs e) =>
			OrderBy_Command((Action)((ToolStripButton)sender).Tag);

		// Сортировка переданным делегатом
		private void OrderBy_Command(Action order)
		{
			order.Invoke();

			BindCollection();

			// обновить строку состояния
			StlMain.Text = $"Коллекция телевизоров упорядочена по наименованию. Текущее количество телевизоров: {_repairShopController.RepairShop.Count}";
		}

		#endregion



		#region Выборка записей

		// Выборка и вывод в отдельной форме коллекции телевизоров с минимальной
		// стоимостью ремонта
		private void ReportMinPrice_Command(object sender, EventArgs e)
		{
			List<Television> reported = _repairShopController.SelectWhereMinPrice();

			string prompt = $"Телевизоры с минимальной стоимостью ремонта:";

			ReportForm reportForm = new ReportForm(reported, prompt);

			reportForm.Show();
		}


		// Выборка по мастеру
		private void ReportByRepairer_Command(object sender, EventArgs e)
		{
			// Получение списка мастеров
			List<string> repairers = _repairShopController.RepairShop.GetRepairers;

			// Создание формы выбора мастера
			ChoiceReportArgForm choiceForm = new ChoiceReportArgForm(repairers, "Выбор мастера", "Выберите мастера:");

			if (choiceForm.ShowDialog() != DialogResult.OK) return;

			string prompt = $"Телевизоры, ремонтируемые мастером {choiceForm.Choosen}:";

			// Отобразить выборку ремонтов мастера в отдельной форме
			new ReportForm(_repairShopController.SelectWhereRepairer(choiceForm.Choosen), prompt).ShowDialog();
		}


		// Выборка по владельцу
		private void ReportByOwner_Command(object sender, EventArgs e)
		{
			// Получение списка владельцев
			List<string> owners = _repairShopController.RepairShop.GetOwners;

			// Создание формы выбора владельца
			ChoiceReportArgForm choiceForm = new ChoiceReportArgForm(owners, "Выбор владельца", "Выберите владельца:");

			if (choiceForm.ShowDialog() != DialogResult.OK) return;

			string prompt = $"Телевизоры владельца {choiceForm.Choosen}:";

			// Отобразить выборку по владельцу в отдельной форме
			new ReportForm(_repairShopController.SelectWhereOwner(choiceForm.Choosen), prompt).ShowDialog();
		}


		// Выборка по диагонали
		private void ReportByDiagonal_Command(object sender, EventArgs e)
		{
			// Получение списка мастеров
			List<string> repairers = _repairShopController.RepairShop.GetDiagonals;

			// Создание формы выбора мастера
			ChoiceReportArgForm choiceForm = new ChoiceReportArgForm(repairers, "Выбор диагонали", "Выберите диагональ:");

			if (choiceForm.ShowDialog() != DialogResult.OK) return;

			string prompt = $"Телевизоры, c диагональю {choiceForm.Choosen}:";

			// Отобразить выборку ремонтов мастера в отдельной форме
			new ReportForm(_repairShopController.SelectWhereDiagonal(int.Parse(choiceForm.Choosen)), prompt).ShowDialog();
		}

		#endregion



		#region Сохранение и загрузка

		// Вызов диалога выбора файла и сохранение
		private bool SaveFile()
		{
			// установка директории для выбора файла (если не была выбрана ранее - директория исполняющего файла)
			SfdMain.InitialDirectory = string.IsNullOrEmpty(_fileName) ?
				string.IsNullOrEmpty(_lastDirectory) ? Environment.CurrentDirectory : Path.GetDirectoryName(_lastDirectory) :
				Path.GetDirectoryName(_fileName);

			if (SfdMain.ShowDialog() != DialogResult.OK) return false;

			_fileName = SfdMain.FileName;
			_repairShopController.SaveJsonToFile(_fileName);

			return true;
		}


		// Обработка команды "сохранить как"
		private void SaveAs_Command(object sender, EventArgs e)
		{
			// запуск сохраняющего метода и проверка на результат
			if (!SaveFile()) return;

			StlMain.Text = $"Коллекция сохранена в файл. Телевизоров в ремонте: {_repairShopController.RepairShop.Count}";

			// обновление флага изменений и заголовка окна
			_isSaved = true;
			UpdateMainTitle();
		}


		// Обработка команды "сохранить"
		private void FileSave_Command(object sender, EventArgs e)
		{
			// если файл не был сохранён ранее - вызываем команду "сохранить как"
			if (string.IsNullOrEmpty(_fileName))
				SaveAs_Command(sender, e);
			else
				_repairShopController.SaveJsonToFile(_fileName);

			StlMain.Text = $"Коллекция сохранена в файл. Телевизоров в ремонте: {_repairShopController.RepairShop.Count}";

			// обновление флага изменений и заголовка окна
			_isSaved = true;
			UpdateMainTitle();
		}

		// Команда открытия файла
		private void FileOpen_Command(object sender, EventArgs e)
		{
			// установка директории для выбора файла (если не была выбрана ранее - директория исполняющего файла)
			OfdMain.InitialDirectory = string.IsNullOrEmpty(_fileName) ?
				string.IsNullOrEmpty(_lastDirectory) ? Environment.CurrentDirectory : Path.GetDirectoryName(_lastDirectory) :
									Path.GetDirectoryName(_fileName);

			// запуск диалогового окна открытия и проверка на результат
			if (OfdMain.ShowDialog() != DialogResult.OK) return;


			_fileName = OfdMain.FileName;
			_repairShopController.ReadJsonFromFile(_fileName);

			BindCollection();

			StlMain.Text = $"Коллекция загружена из файла. Телевизоров в ремонте: {_repairShopController.RepairShop.Count}";

			// обновление флага изменений и заголовка окна
			_isSaved = true;
			UpdateMainTitle();
		}

		private void FileNew_Command(object sender, EventArgs e)
		{
			// Запомнить последний путь
			_lastDirectory = _fileName;

			// Очистить текущее имя файла
			_fileName = "";

			// Очистить данные и обновить листбокс
			_repairShopController.RepairShop.RemoveAll();
			BindCollection();

			// обновление флага изменений и заголовка окна
			_isSaved = false;
			UpdateMainTitle();
		}





		#endregion



		#region Смена шрифта и фона

		// Команда смены шрифта
		private void Font_Command(object sender, EventArgs e) {
			if (FdlTextFont.ShowDialog() == DialogResult.OK)
				SetFont();
		}

		// Обработка кнопки применить в диалоге смены шрифта
		private void FdlTextFont_Apply(object sender, EventArgs e) => SetFont();

		// Непосредственно установка значения фона
		public void SetFont()
		{
			LbxTelevisions.Font = FdlTextFont.Font;
			LblHeader.Font = FdlTextFont.Font;
		}
		
		// Команда смены цвета фона
		private void BackColor_Command(object sender, EventArgs e)
		{
			if (CdlBackColor.ShowDialog() == DialogResult.OK){
				LbxTelevisions.BackColor = CdlBackColor.Color;
				LblHeader.BackColor = CdlBackColor.Color;
				LblForeground.BackColor = CdlBackColor.Color;
			}
		}
		#endregion
	}
}
