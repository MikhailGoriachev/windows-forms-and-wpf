﻿
namespace HW9.Views
{
	partial class ReportForm
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.LblHeader = new System.Windows.Forms.Label();
			this.LbxTelevisions = new System.Windows.Forms.ListBox();
			this.LblTitle = new System.Windows.Forms.Label();
			this.BtnClose = new System.Windows.Forms.Button();
			this.GrbFormal = new System.Windows.Forms.GroupBox();
			this.LblForeground = new System.Windows.Forms.Label();
			this.GrbFormal.SuspendLayout();
			this.SuspendLayout();
			// 
			// LblHeader
			// 
			this.LblHeader.BackColor = System.Drawing.SystemColors.Window;
			this.LblHeader.Font = new System.Drawing.Font("Consolas", 12F);
			this.LblHeader.Location = new System.Drawing.Point(20, 60);
			this.LblHeader.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			this.LblHeader.Name = "LblHeader";
			this.LblHeader.Size = new System.Drawing.Size(1056, 56);
			this.LblHeader.TabIndex = 10;
			this.LblHeader.Text = "label1";
			// 
			// LbxTelevisions
			// 
			this.LbxTelevisions.Font = new System.Drawing.Font("Consolas", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.LbxTelevisions.FormattingEnabled = true;
			this.LbxTelevisions.ItemHeight = 19;
			this.LbxTelevisions.Location = new System.Drawing.Point(20, 116);
			this.LbxTelevisions.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
			this.LbxTelevisions.Name = "LbxTelevisions";
			this.LbxTelevisions.ScrollAlwaysVisible = true;
			this.LbxTelevisions.Size = new System.Drawing.Size(1072, 137);
			this.LbxTelevisions.TabIndex = 9;
			// 
			// LblTitle
			// 
			this.LblTitle.Font = new System.Drawing.Font("Consolas", 12F);
			this.LblTitle.Location = new System.Drawing.Point(12, 28);
			this.LblTitle.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			this.LblTitle.Name = "LblTitle";
			this.LblTitle.Size = new System.Drawing.Size(588, 24);
			this.LblTitle.TabIndex = 11;
			this.LblTitle.Text = "Список телевизоров по выбранному параметру:";
			// 
			// BtnClose
			// 
			this.BtnClose.Location = new System.Drawing.Point(502, 296);
			this.BtnClose.Name = "BtnClose";
			this.BtnClose.Size = new System.Drawing.Size(120, 32);
			this.BtnClose.TabIndex = 12;
			this.BtnClose.Text = "Закрыть";
			this.BtnClose.UseVisualStyleBackColor = true;
			this.BtnClose.Click += new System.EventHandler(this.BtnClose_Click);
			// 
			// GrbFormal
			// 
			this.GrbFormal.Controls.Add(this.LblTitle);
			this.GrbFormal.Controls.Add(this.LblHeader);
			this.GrbFormal.Controls.Add(this.LbxTelevisions);
			this.GrbFormal.Controls.Add(this.LblForeground);
			this.GrbFormal.Location = new System.Drawing.Point(8, 8);
			this.GrbFormal.Name = "GrbFormal";
			this.GrbFormal.Size = new System.Drawing.Size(1112, 272);
			this.GrbFormal.TabIndex = 13;
			this.GrbFormal.TabStop = false;
			// 
			// LblForeground
			// 
			this.LblForeground.BackColor = System.Drawing.SystemColors.Window;
			this.LblForeground.Location = new System.Drawing.Point(20, 60);
			this.LblForeground.Name = "LblForeground";
			this.LblForeground.Size = new System.Drawing.Size(1072, 56);
			this.LblForeground.TabIndex = 14;
			// 
			// ReportForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(1138, 343);
			this.Controls.Add(this.GrbFormal);
			this.Controls.Add(this.BtnClose);
			this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
			this.MaximizeBox = false;
			this.Name = "ReportForm";
			this.ShowInTaskbar = false;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Отчет";
			this.Load += new System.EventHandler(this.ReportForm_Load);
			this.GrbFormal.ResumeLayout(false);
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.Label LblHeader;
		private System.Windows.Forms.ListBox LbxTelevisions;
		private System.Windows.Forms.Label LblTitle;
		private System.Windows.Forms.Button BtnClose;
		private System.Windows.Forms.GroupBox GrbFormal;
		private System.Windows.Forms.Label LblForeground;
	}
}