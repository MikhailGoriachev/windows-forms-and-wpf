﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HW9.Views
{
	public partial class ChoiceReportArgForm : Form
	{
		public ChoiceReportArgForm() : this(new List<string>(), "Выбор для отчета", "Выберите из списка:")
		{
		}

		public ChoiceReportArgForm(List<string> data, string title, string label)
		{
			InitializeComponent();
			Text = title;
			LblPrompt.Text = label;
			CbxList.DataSource = data;
			CbxList.SelectedIndex = 0;
		}

		public string Choosen => CbxList.Text;
	}
}
