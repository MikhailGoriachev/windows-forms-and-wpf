﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Televisions.Models;

namespace _HwE_MultiForms.Controllers
{
    /*
     * Реализация функционала приложения
     *     • Упорядочивание коллекции телевизоров
     *         o По производителю и типу
     *         o По убыванию диагонали экрана
     *         o По мастеру, выполняющему ремонт
     *         o По владельцу телевизора
     *     • Выборка в коллекцию телевизоров с минимальной стоимостью ремонта
     *     • Выборка в коллекцию телевизоров, ремонтируемых заданным мастером
     *     • Выборка в коллекцию телевизоров с заданной диагональю экрана 
     */
    public class RepairShopController
    {
        // объект для обработки
        private RepairShop _repairShop;

        public RepairShop RepairShop {
            get => _repairShop;
            private set => _repairShop = value;
        } // RepairShop


        // конструкторы
        // при создании RepairShop конструктором по умолчанию вызывается
        // метод формирования коллекции телевизоров для ремонта
        public RepairShopController():this(new RepairShop()) { }

        public RepairShopController(RepairShop repairShop) {
            _repairShop = repairShop;
        } // RepairShopController



        // Запрос на упорядочивание коллекции по производителю и типу
        public void OrderByBrand() => RepairShop.OrderBy((t1, t2) => 
            t1.BrandModel.CompareTo(t2.BrandModel));

        // Запрос на упорядочивание коллекции по убыванию диагонали экрана
        public void OrderByDiagonalDesc() => RepairShop.OrderBy((t1, t2) => 
            t2.Diagonal.CompareTo(t1.Diagonal));

        // Запрос на упорядочивание коллекции по мастеру, выполняющему ремонт
        public void OrderByArtisan() => RepairShop.OrderBy((t1, t2) => 
            t1.Artisan.CompareTo(t2.Artisan));

        // Запрос на упорядочивание коллекции по владельцу телевизора
        public void OrderByOwner() => RepairShop.OrderBy((t1, t2) =>
            t1.Owner.CompareTo(t2.Owner));

        // Запрос на выборку в коллекцию телевизоров с минимальной стоимостью ремонта
        public List<Television> SelectWhereMinPrice() {
            int minPrice = _repairShop.MinPrice();
            return _repairShop.Filter(t => t.Price == minPrice);
        } // SelectWhereMinPrice

        // Запрос на выборку в коллекцию телевизоров, ремонтируемых заданным мастером
        public List<Television> SelectWhereArtisan(string artisan) =>
            _repairShop.Filter(t => t.Artisan == artisan);

        // Запрос на выборку в коллекцию телевизоров с заданной диагональю экран
        public List<Television> SelectWhereDiagonal(double diagonal) =>
            _repairShop.Filter(t => Math.Abs(t.Diagonal - diagonal) < 1e-6);


        // список мастеров из коллекции ремонтов
        public List<string> GetArtitans() {
            Dictionary<string, int> artisans = new Dictionary<string, int>();

            _repairShop.Televisions.ForEach(t => artisans[t.Artisan] = 0);

            return artisans.Keys.ToList();
        } // GetArtitans
    } // class RepairShopController
}
