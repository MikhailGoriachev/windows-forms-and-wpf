﻿
namespace Televisions
{
    partial class MainForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.файлToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.мастерскаяToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.новаяToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.изменитьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ремонтыТелевизоровToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.принятьВРемонтToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.изменитьToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.сортировкToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.поУбываниюToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.поПроизводителюToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.поМастеруToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.поВладельцуToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.выборкаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.colorDialog1 = new System.Windows.Forms.ColorDialog();
            this.folderBrowserDialog1 = new System.Windows.Forms.FolderBrowserDialog();
            this.OfdMain = new System.Windows.Forms.OpenFileDialog();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.новыйToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.открытьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.файлToolStripMenuItem,
            this.мастерскаяToolStripMenuItem,
            this.ремонтыТелевизоровToolStripMenuItem,
            this.сортировкToolStripMenuItem,
            this.выборкаToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(13, 5, 0, 5);
            this.menuStrip1.Size = new System.Drawing.Size(1924, 46);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // файлToolStripMenuItem
            // 
            this.файлToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.новыйToolStripMenuItem,
            this.открытьToolStripMenuItem});
            this.файлToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.файлToolStripMenuItem.Name = "файлToolStripMenuItem";
            this.файлToolStripMenuItem.Size = new System.Drawing.Size(86, 36);
            this.файлToolStripMenuItem.Text = "Файл";
            // 
            // мастерскаяToolStripMenuItem
            // 
            this.мастерскаяToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.новаяToolStripMenuItem,
            this.изменитьToolStripMenuItem});
            this.мастерскаяToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.мастерскаяToolStripMenuItem.Name = "мастерскаяToolStripMenuItem";
            this.мастерскаяToolStripMenuItem.Size = new System.Drawing.Size(159, 36);
            this.мастерскаяToolStripMenuItem.Text = "Мастерская";
            // 
            // новаяToolStripMenuItem
            // 
            this.новаяToolStripMenuItem.Name = "новаяToolStripMenuItem";
            this.новаяToolStripMenuItem.Size = new System.Drawing.Size(270, 40);
            this.новаяToolStripMenuItem.Text = "Новая ";
            // 
            // изменитьToolStripMenuItem
            // 
            this.изменитьToolStripMenuItem.Name = "изменитьToolStripMenuItem";
            this.изменитьToolStripMenuItem.Size = new System.Drawing.Size(270, 40);
            this.изменитьToolStripMenuItem.Text = "Изменить";
            // 
            // ремонтыТелевизоровToolStripMenuItem
            // 
            this.ремонтыТелевизоровToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.принятьВРемонтToolStripMenuItem,
            this.изменитьToolStripMenuItem1});
            this.ремонтыТелевизоровToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.ремонтыТелевизоровToolStripMenuItem.Name = "ремонтыТелевизоровToolStripMenuItem";
            this.ремонтыТелевизоровToolStripMenuItem.Size = new System.Drawing.Size(277, 36);
            this.ремонтыТелевизоровToolStripMenuItem.Text = "Ремонты телевизоров";
            // 
            // принятьВРемонтToolStripMenuItem
            // 
            this.принятьВРемонтToolStripMenuItem.Name = "принятьВРемонтToolStripMenuItem";
            this.принятьВРемонтToolStripMenuItem.Size = new System.Drawing.Size(320, 40);
            this.принятьВРемонтToolStripMenuItem.Text = "Принять в ремонт";
            // 
            // изменитьToolStripMenuItem1
            // 
            this.изменитьToolStripMenuItem1.Name = "изменитьToolStripMenuItem1";
            this.изменитьToolStripMenuItem1.Size = new System.Drawing.Size(320, 40);
            this.изменитьToolStripMenuItem1.Text = "Изменить...";
            // 
            // сортировкToolStripMenuItem
            // 
            this.сортировкToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.поУбываниюToolStripMenuItem,
            this.поПроизводителюToolStripMenuItem,
            this.поМастеруToolStripMenuItem,
            this.поВладельцуToolStripMenuItem});
            this.сортировкToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.сортировкToolStripMenuItem.Name = "сортировкToolStripMenuItem";
            this.сортировкToolStripMenuItem.Size = new System.Drawing.Size(169, 36);
            this.сортировкToolStripMenuItem.Text = "Сортировка ";
            // 
            // поУбываниюToolStripMenuItem
            // 
            this.поУбываниюToolStripMenuItem.Name = "поУбываниюToolStripMenuItem";
            this.поУбываниюToolStripMenuItem.Size = new System.Drawing.Size(407, 40);
            this.поУбываниюToolStripMenuItem.Text = "По убыванию диагоналей";
            this.поУбываниюToolStripMenuItem.Click += new System.EventHandler(this.поУбываниюToolStripMenuItem_Click);
            // 
            // поПроизводителюToolStripMenuItem
            // 
            this.поПроизводителюToolStripMenuItem.Name = "поПроизводителюToolStripMenuItem";
            this.поПроизводителюToolStripMenuItem.Size = new System.Drawing.Size(407, 40);
            this.поПроизводителюToolStripMenuItem.Text = "По производителю";
            // 
            // поМастеруToolStripMenuItem
            // 
            this.поМастеруToolStripMenuItem.Name = "поМастеруToolStripMenuItem";
            this.поМастеруToolStripMenuItem.Size = new System.Drawing.Size(407, 40);
            this.поМастеруToolStripMenuItem.Text = "по мастеру ";
            // 
            // поВладельцуToolStripMenuItem
            // 
            this.поВладельцуToolStripMenuItem.Name = "поВладельцуToolStripMenuItem";
            this.поВладельцуToolStripMenuItem.Size = new System.Drawing.Size(407, 40);
            this.поВладельцуToolStripMenuItem.Text = "По владельцу";
            // 
            // выборкаToolStripMenuItem
            // 
            this.выборкаToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.выборкаToolStripMenuItem.Name = "выборкаToolStripMenuItem";
            this.выборкаToolStripMenuItem.Size = new System.Drawing.Size(134, 36);
            this.выборкаToolStripMenuItem.Text = "Выборка ";
            // 
            // OfdMain
            // 
            this.OfdMain.FileName = "openFileDialog1";
            // 
            // новыйToolStripMenuItem
            // 
            this.новыйToolStripMenuItem.Name = "новыйToolStripMenuItem";
            this.новыйToolStripMenuItem.Size = new System.Drawing.Size(270, 40);
            this.новыйToolStripMenuItem.Text = "Новый";
            // 
            // открытьToolStripMenuItem
            // 
            this.открытьToolStripMenuItem.Name = "открытьToolStripMenuItem";
            this.открытьToolStripMenuItem.Size = new System.Drawing.Size(270, 40);
            this.открытьToolStripMenuItem.Text = "Открыть ";
            this.открытьToolStripMenuItem.Click += new System.EventHandler(this.Open_Click);
            // 
            // statusStrip1
            // 
            this.statusStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.statusStrip1.Location = new System.Drawing.Point(0, 1028);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(1924, 22);
            this.statusStrip1.TabIndex = 1;
            this.statusStrip1.Text = "statusStrip1";
            this.statusStrip1.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.statusStrip1_ItemClicked);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(22F, 54F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1924, 1050);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.menuStrip1);
            this.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(7);
            this.Name = "MainForm";
            this.Text = "Задание на 22.11.2021";
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem файлToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem мастерскаяToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem новаяToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem изменитьToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ремонтыТелевизоровToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem принятьВРемонтToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem изменитьToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem сортировкToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem поУбываниюToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem поПроизводителюToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem поМастеруToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem поВладельцуToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem выборкаToolStripMenuItem;
        private System.Windows.Forms.ColorDialog colorDialog1;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog1;
        private System.Windows.Forms.OpenFileDialog OfdMain;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.ToolStripMenuItem новыйToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem открытьToolStripMenuItem;
        private System.Windows.Forms.StatusStrip statusStrip1;
    }
}

