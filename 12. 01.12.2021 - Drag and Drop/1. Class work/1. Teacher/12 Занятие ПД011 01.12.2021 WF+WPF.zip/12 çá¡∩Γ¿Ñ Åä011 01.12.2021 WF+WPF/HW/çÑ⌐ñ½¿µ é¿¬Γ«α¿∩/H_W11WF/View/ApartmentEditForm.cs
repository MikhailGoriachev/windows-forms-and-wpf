﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace H_W11WF.Views
{
	public partial class ApartmentEditForm : Form
	{
		public string Address { get; private set; }

		public ApartmentEditForm(string address)
		{
			InitializeComponent();

			TxbAddress.Text = address;
		}// RepairShopEditForm

		private void BtnSave_Click(object sender, EventArgs e)
		{
			Address = TxbAddress.Text;
		}// BtnSave_Click

		private void BtnCancel_Click(object sender, EventArgs e) => Close();

		private void ApartmentSettingsForm_FormClosing(object sender, FormClosingEventArgs e)
		{
			if ((DialogResult == DialogResult.OK) 
			   & string.IsNullOrWhiteSpace(TxbAddress.Text))
			{
				MessageBox.Show("Не все поля заполнены", "Ошибка",
					MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				e.Cancel = true;
			}
		}// ApartmentSettingsForm_FormClosing
	}// ApartmentEditForm
}
