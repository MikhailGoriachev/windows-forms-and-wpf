﻿
namespace H_W11WF.View
{
    partial class ChoiceForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.BtnExit = new System.Windows.Forms.Button();
            this.BtnSelect = new System.Windows.Forms.Button();
            this.CbxName = new System.Windows.Forms.ComboBox();
            this.LblText = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // BtnExit
            // 
            this.BtnExit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.BtnExit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.BtnExit.Location = new System.Drawing.Point(135, 109);
            this.BtnExit.Margin = new System.Windows.Forms.Padding(4);
            this.BtnExit.Name = "BtnExit";
            this.BtnExit.Size = new System.Drawing.Size(125, 41);
            this.BtnExit.TabIndex = 11;
            this.BtnExit.Text = "Отмена";
            this.BtnExit.UseVisualStyleBackColor = false;
            // 
            // BtnSelect
            // 
            this.BtnSelect.BackColor = System.Drawing.Color.PowderBlue;
            this.BtnSelect.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.BtnSelect.Location = new System.Drawing.Point(2, 109);
            this.BtnSelect.Margin = new System.Windows.Forms.Padding(4);
            this.BtnSelect.Name = "BtnSelect";
            this.BtnSelect.Size = new System.Drawing.Size(125, 41);
            this.BtnSelect.TabIndex = 10;
            this.BtnSelect.Text = "Выбрать";
            this.BtnSelect.UseVisualStyleBackColor = false;
            // 
            // CbxName
            // 
            this.CbxName.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CbxName.FormattingEnabled = true;
            this.CbxName.Location = new System.Drawing.Point(26, 48);
            this.CbxName.Margin = new System.Windows.Forms.Padding(4);
            this.CbxName.Name = "CbxName";
            this.CbxName.Size = new System.Drawing.Size(194, 24);
            this.CbxName.TabIndex = 9;
            // 
            // LblText
            // 
            this.LblText.AutoSize = true;
            this.LblText.Location = new System.Drawing.Point(23, 28);
            this.LblText.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.LblText.Name = "LblText";
            this.LblText.Size = new System.Drawing.Size(98, 16);
            this.LblText.TabIndex = 8;
            this.LblText.Text = "Выберите:";
            // 
            // ChoiceForm
            // 
            this.AcceptButton = this.BtnSelect;
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightSteelBlue;
            this.CancelButton = this.BtnExit;
            this.ClientSize = new System.Drawing.Size(264, 196);
            this.Controls.Add(this.BtnExit);
            this.Controls.Add(this.BtnSelect);
            this.Controls.Add(this.CbxName);
            this.Controls.Add(this.LblText);
            this.Font = new System.Drawing.Font("Lucida Console", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "ChoiceForm";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Выбор";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button BtnExit;
        private System.Windows.Forms.Button BtnSelect;
        private System.Windows.Forms.ComboBox CbxName;
        private System.Windows.Forms.Label LblText;
    }
}