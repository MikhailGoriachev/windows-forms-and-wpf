﻿using H_W11WF.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace H_W11WF.View
{
    public partial class ChoiceForm : Form
    {
        public ChoiceForm() : this(new List<string>()) { }
        public ChoiceForm(List<string> name)
        {
            InitializeComponent();

            
            CbxName.DataSource = name;
        }// ChoiceForm

        // вернуть выбранное наименование или состояние прибора
        public string Names => CbxName.Text;
    }// class ChoiceForm
}
