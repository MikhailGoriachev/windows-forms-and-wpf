﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using H_W11WF.Models;

namespace H_W11WF.Views
{
	public partial class ElectApplianceForm : Form
	{
		private ElectricalAppliance _appliance;

		public ElectricalAppliance Appliance
		{
			get => _appliance;
			set
			{
				_appliance = value;

				TxbName.Text = _appliance.Name;
				CmbPower.Text = _appliance.Power.ToString();
				NudPrice.Text = _appliance.Price.ToString();
				CmbState.Text = _appliance.OffOnn.ToString();				
			}
		}// ElectricalAppliance

		// конструктор для формы в режиме добавления нового прибора
		public ElectApplianceForm()
		{
			InitializeComponent();
			_appliance = new ElectricalAppliance();
		}

        // конструктор для формы в режиме редактирования данных прибора
		public ElectApplianceForm(string formTitle, string btnTitle)
		{
			InitializeComponent();
			_appliance = new ElectricalAppliance();

			// Заголовок формы
			Text = formTitle;
			BtnAdd.Text = btnTitle;
		}// TelevisionForm

		// Обработчик кнопки "Добавить"/"Сохранить" - собрать данные из элементов
		// интерфейса
		private void BtnAdd_Click(object sender, EventArgs e)
		{
			if (IsEmptyFields()) return;
			string state = _appliance.OffOnn ? "Включен" : "Выключен";
			_appliance = new ElectricalAppliance()
			{
				Name = TxbName.Text,
				Price = int.Parse(NudPrice.Text),
				Power = int.Parse(CmbPower.Text),
				OffOnn = CmbState.Text.Contains(state)
			};

		}// BtnAdd_Click

		// Не даём закрыться окну, если есть пустые поля
		private void ApplicationForm_FormClosing(object sender, FormClosingEventArgs e)
		{
			if ((DialogResult == DialogResult.OK) & IsEmptyFields())
			{
				MessageBox.Show("Не все данные заполнены", "Ошибка",
					MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				e.Cancel = true;
			}// if
		}// ApplicationForm_FormClosing

		public bool IsEmptyFields() =>
			string.IsNullOrWhiteSpace(TxbName.Text) ||
			string.IsNullOrWhiteSpace(CmbPower.Text)||
			string.IsNullOrWhiteSpace(NudPrice.Text)||
			string.IsNullOrWhiteSpace(CmbState.Text);


	}//class ElectApplianceForm
}
