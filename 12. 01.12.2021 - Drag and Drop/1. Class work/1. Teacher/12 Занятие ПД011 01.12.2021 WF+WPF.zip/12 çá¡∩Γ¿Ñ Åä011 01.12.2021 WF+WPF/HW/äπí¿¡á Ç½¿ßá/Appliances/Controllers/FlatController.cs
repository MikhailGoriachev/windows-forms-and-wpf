﻿using Appliances.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Appliances.Controllers
{
    public class FlatController {
        // объект для обработки
        private Flat _flat;

        public Flat Flat {
            get => _flat;
            private set => _flat = value;
        } // Flat

        // имя файла для сериализация в формате JSON
        private string _fileName;

        public string FileName {
            get => _fileName;
            private set => _fileName = value;
        } // FileName

        // конструкторы
        // при создании Flat конструктором по умолчанию вызывается
        // метод формирования коллекции 
        public FlatController() : this(new Flat(), "Flat.json") { }

        public FlatController(Flat flat) : this(flat, "Flat.json") { }

        public FlatController(Flat flat, string fileName) {
            _flat = flat;
            _fileName = fileName;
        } // FlatController


        // Запрос на упорядочивание коллекции по названию
        public List<Appliance> OrderByName() =>
            Flat.OrderBy((t1, t2) => t1.Name.CompareTo(t2.Name));


        // Запрос на упорядочивание коллекции по состоянию
        public List<Appliance> OrderByState() =>
            Flat.OrderBy((t1, t2) => t1.State.CompareTo(t2.State));


        // Запрос на упорядочивание коллекции по мощности
        public List<Appliance> OrderByPower() =>
            Flat.OrderBy((t1, t2) => t1.Power.CompareTo(t2.Power));


        // Запрос на упорядочивание коллекции по убыванию цены
        public List<Appliance> OrderByPriceDesc() =>
            Flat.OrderBy((t1, t2) => t2.Price.CompareTo(t1.Price));


        // Запрос на выборку в коллекцию электроприборов, с заданным названием
        public List<Appliance> SelectWhereName(string name) =>
            _flat.SelectTelevisions(t => t.Name == name);


        // Запрос на выборку в коллекцию электроприборов, заданного состояния
        public List<Appliance> SelectWhereState(bool state) =>
            _flat.SelectTelevisions(t => t.State == state);


        // список названий электроприборов из коллекции
        public List<string> GetNames() {
            Dictionary<string, int> names = new Dictionary<string, int>();

            _flat.Appliances.ForEach(t => names[t.Name] = 0);

            return names.Keys.ToList();
        } // GetNames


        // список состояний электроприборов из коллекции
        public List<string> GetStates() {
            Dictionary<string, int> states = new Dictionary<string, int>();

            _flat.Appliances.ForEach(t => states[t.State ? "включен" : "выключен"] = 0);

            return states.Keys.ToList();
        } // GetStates
    } // FlatController
}
