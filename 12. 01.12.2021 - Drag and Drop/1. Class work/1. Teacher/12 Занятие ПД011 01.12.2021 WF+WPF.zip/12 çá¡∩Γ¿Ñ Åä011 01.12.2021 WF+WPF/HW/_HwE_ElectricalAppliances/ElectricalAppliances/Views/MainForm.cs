﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using ElectricalAppliances.Controllers;
using ElectricalAppliances.Models;

namespace ElectricalAppliances.Views
{
    public partial class MainForm : Form
    {
        // контроллер для обработки данных по заданию
        private ApartmentController _apartmentController;

        public MainForm():this(new ApartmentController()) {} // MainForm

        public MainForm(ApartmentController apartmentController) {
            InitializeComponent();

            // получить данные по контроллеру 
            _apartmentController = apartmentController;

            // Вывести адрес квартиры
            LblApartmentInfo.Text = _apartmentController.Apartment.Address;

            // сформировать данные в ListView: приборы, отсортированные приборы, выборка по наименованию
            FillListView(_apartmentController.GetAll(), LsvAppliances);
            FillListView(_apartmentController.OrderByBrand(), LsvOrdered);
            FillListView(_apartmentController.SelectWhereName(_apartmentController.GetAll()[0].Name), LsvFiltered);

            // Сформировать заголовок вкладки отсортированной коллекции
            TbpSorted.Text += ": по названию";
            
            // вывести количество приборов квартире
            TslStatus.Text = $"Количество приборов в квартире: {_apartmentController.Count}";
            TslOn.Text = $"Включено: {_apartmentController.SelectWhereState(true).Count}";
            TslOff.Text = $"Выключено: {_apartmentController.SelectWhereState(false).Count}";
        } // MainForm


        // вывод коллекции электроприборов в ListView в табличном формате,
        // состояние прибора отображать картинкой
        public void FillListView(List<Appliance> appliances, ListView listView) {
            listView.Items.Clear();

            appliances.ForEach(a => listView.Items.Add(a.ToListViewItem()));
        } // FillListView


        // завершение приложения
        private void Exit_Command(object sender, EventArgs e) => Application.Exit();


        // свернуть в трей
        private void ToTray_Command(object sender, EventArgs e) {
            this.Hide();
            NtfMain.Visible = true;
        } // ToTray_Command


        // восстановить из трея
        private void FromTray_Command(object sender, EventArgs e) {
            this.Show();
            WindowState = FormWindowState.Normal;
            NtfMain.Visible = false;
        } // FromTray_Command


        // вывод формы со сведениями о приложении и разработчике
        private void About_Command(object sender, EventArgs e) {
            AboutForm aboutForm = new AboutForm();
            aboutForm.ShowDialog();
        } // About_Command


        // включить все приборы
        private void TurnOnAll_Commad(object sender, EventArgs e) {
            TbcMain.SelectedTab = TbpAppliances;

            _apartmentController.TurnAll(true);
            FillListView(_apartmentController.Apartment.Appliances, LsvAppliances);
        } // TurnOnAll_Commad


        // выключить все приборы
        private void TurnOffAll_Commad(object sender, EventArgs e) {
            TbcMain.SelectedTab = TbpAppliances;

            _apartmentController.TurnAll(false);
            FillListView(_apartmentController.Apartment.Appliances, LsvAppliances);
        } // TurnOnAll_Commad


        // включение выбранного прибора
        private void TurnOnSelected_Command(object sender, EventArgs e) {
            // выход, если нет выбранного прибора
            if (LsvAppliances.SelectedIndices.Count == 0) return;

            int index = LsvAppliances.SelectedIndices[0];
            _apartmentController.TurnAt(index, true);
            LsvAppliances.Items[index] = _apartmentController.Apartment[index].ToListViewItem();
            LsvAppliances.Items[index].Selected = true;
        } // TurnOnSelected_Command


        // выключение выбранного прибора
        private void TurnOffSelected_Command(object sender, EventArgs e) {
            // выход, если нет выбранного прибора
            if (LsvAppliances.SelectedIndices.Count == 0) return;

            int index = LsvAppliances.SelectedIndices[0];
            _apartmentController.TurnAt(index, false);
            LsvAppliances.Items[index] = _apartmentController.Apartment[index].ToListViewItem();
            LsvAppliances.Items[index].Selected = true;
        } // TurnOffSelected_Command


        // сортировка коллекции по названию прибора
        private void OrderByName_Command(object sender, EventArgs e) {
            TbcMain.SelectedTab = TbpSorted;

            FillListView(_apartmentController.OrderByBrand(), LsvOrdered);

            // скорректировать название вкладки
            TbpSorted.Text = TbpSorted.Text.Remove(TbpSorted.Text.IndexOf(":")+1) + " по названию";
        } // OrderByName_Command


        // сортировка коллекции по состоянию прибора
        private void OrderByState_Command(object sender, EventArgs e) {
            TbcMain.SelectedTab = TbpSorted;

            FillListView(_apartmentController.OrderByState(), LsvOrdered);

            // скорректировать название вкладки
            TbpSorted.Text = TbpSorted.Text.Remove(TbpSorted.Text.IndexOf(":")+1) + " по состоянию";
        } // OrderByState_Command


        // сортировка коллекции по мощности прибора
        private void OrderByPower_Command(object sender, EventArgs e) {
            TbcMain.SelectedTab = TbpSorted;

            FillListView(_apartmentController.OrderByPower(), LsvOrdered);

            // скорректировать название вкладки
            TbpSorted.Text = TbpSorted.Text.Remove(TbpSorted.Text.IndexOf(":") + 1) + " по мощности";
        } // OrderByPower_Command


        // сортировка коллекции по убыванию цены прибора
        private void OrderByPriceDesc_Command(object sender, EventArgs e) {
            TbcMain.SelectedTab = TbpSorted;

            FillListView(_apartmentController.OrderByPriceDesc(), LsvOrdered);

            // скорректировать название вкладки
            TbpSorted.Text = TbpSorted.Text.Remove(TbpSorted.Text.IndexOf(":") + 1) + " по убыванию цены";
        } // OrderByPriceDesc_Command
    } // class MainForm
}
