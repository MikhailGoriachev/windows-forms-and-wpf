﻿
namespace ElectricalAppliances.Views
{
    partial class MainForm
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.MnsMain = new System.Windows.Forms.MenuStrip();
            this.MniFile = new System.Windows.Forms.ToolStripMenuItem();
            this.MniFileOpen = new System.Windows.Forms.ToolStripMenuItem();
            this.MniFileSave = new System.Windows.Forms.ToolStripMenuItem();
            this.MniFileSaveAs = new System.Windows.Forms.ToolStripMenuItem();
            this.MniFileSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.MniFileExit = new System.Windows.Forms.ToolStripMenuItem();
            this.MniApartment = new System.Windows.Forms.ToolStripMenuItem();
            this.новаяКвартираToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.редактироватьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.MniControl = new System.Windows.Forms.ToolStripMenuItem();
            this.MniControlToTray = new System.Windows.Forms.ToolStripMenuItem();
            this.MniControlSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.MniControlTurnApplianceOn = new System.Windows.Forms.ToolStripMenuItem();
            this.MniControlTurnApplianceOff = new System.Windows.Forms.ToolStripMenuItem();
            this.MniControlSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.MniControlTurnOnAll = new System.Windows.Forms.ToolStripMenuItem();
            this.MniControlTurnOffAll = new System.Windows.Forms.ToolStripMenuItem();
            this.MniReport = new System.Windows.Forms.ToolStripMenuItem();
            this.MniReportOrder = new System.Windows.Forms.ToolStripMenuItem();
            this.MniReportOrderByName = new System.Windows.Forms.ToolStripMenuItem();
            this.MniReportOrderByState = new System.Windows.Forms.ToolStripMenuItem();
            this.MniReportOrderByPower = new System.Windows.Forms.ToolStripMenuItem();
            this.MniReportOrderByPrice = new System.Windows.Forms.ToolStripMenuItem();
            this.MniReportSelect = new System.Windows.Forms.ToolStripMenuItem();
            this.MniReportSelectByName = new System.Windows.Forms.ToolStripMenuItem();
            this.MniReportSelectByState = new System.Windows.Forms.ToolStripMenuItem();
            this.MniHelp = new System.Windows.Forms.ToolStripMenuItem();
            this.MniHelpAbout = new System.Windows.Forms.ToolStripMenuItem();
            this.TstMain = new System.Windows.Forms.ToolStrip();
            this.TsbNew = new System.Windows.Forms.ToolStripButton();
            this.TsbOpen = new System.Windows.Forms.ToolStripButton();
            this.TsbSave = new System.Windows.Forms.ToolStripButton();
            this.TstSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.TsbNewApartment = new System.Windows.Forms.ToolStripButton();
            this.TsbEditApartment = new System.Windows.Forms.ToolStripButton();
            this.TstSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.TsbToTray = new System.Windows.Forms.ToolStripButton();
            this.TsbTurnOnAll = new System.Windows.Forms.ToolStripButton();
            this.TsbTurnOffAll = new System.Windows.Forms.ToolStripButton();
            this.StsMain = new System.Windows.Forms.StatusStrip();
            this.TslStatus = new System.Windows.Forms.ToolStripStatusLabel();
            this.TslOn = new System.Windows.Forms.ToolStripStatusLabel();
            this.TslOff = new System.Windows.Forms.ToolStripStatusLabel();
            this.CmnNotify = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.CmiRestore = new System.Windows.Forms.ToolStripMenuItem();
            this.CmiNotifySeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.CmiAbout = new System.Windows.Forms.ToolStripMenuItem();
            this.CmiNotifySeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.CmiExit = new System.Windows.Forms.ToolStripMenuItem();
            this.CmnListView = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.ImlSmall = new System.Windows.Forms.ImageList(this.components);
            this.OfdMain = new System.Windows.Forms.OpenFileDialog();
            this.SfdMain = new System.Windows.Forms.SaveFileDialog();
            this.NtfMain = new System.Windows.Forms.NotifyIcon(this.components);
            this.LblApartmentInfo = new System.Windows.Forms.Label();
            this.TbcMain = new System.Windows.Forms.TabControl();
            this.TbpAppliances = new System.Windows.Forms.TabPage();
            this.LsvAppliances = new System.Windows.Forms.ListView();
            this.ClhState = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.ClhId = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.ClhName = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.ClhPower = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.ClhPrice = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.TbpSorted = new System.Windows.Forms.TabPage();
            this.LsvOrdered = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader5 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.TbpSelected = new System.Windows.Forms.TabPage();
            this.LsvFiltered = new System.Windows.Forms.ListView();
            this.columnHeader6 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader7 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader8 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader9 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader10 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.MnsMain.SuspendLayout();
            this.TstMain.SuspendLayout();
            this.StsMain.SuspendLayout();
            this.CmnNotify.SuspendLayout();
            this.TbcMain.SuspendLayout();
            this.TbpAppliances.SuspendLayout();
            this.TbpSorted.SuspendLayout();
            this.TbpSelected.SuspendLayout();
            this.SuspendLayout();
            // 
            // MnsMain
            // 
            this.MnsMain.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.MnsMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniFile,
            this.MniApartment,
            this.MniControl,
            this.MniReport,
            this.MniHelp});
            this.MnsMain.Location = new System.Drawing.Point(0, 0);
            this.MnsMain.Name = "MnsMain";
            this.MnsMain.Size = new System.Drawing.Size(1184, 28);
            this.MnsMain.TabIndex = 0;
            this.MnsMain.Text = "menuStrip1";
            // 
            // MniFile
            // 
            this.MniFile.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniFileOpen,
            this.MniFileSave,
            this.MniFileSaveAs,
            this.MniFileSeparator1,
            this.MniFileExit});
            this.MniFile.Name = "MniFile";
            this.MniFile.Size = new System.Drawing.Size(57, 24);
            this.MniFile.Text = "Файл";
            // 
            // MniFileOpen
            // 
            this.MniFileOpen.Name = "MniFileOpen";
            this.MniFileOpen.Size = new System.Drawing.Size(187, 24);
            this.MniFileOpen.Text = "Открыть...";
            // 
            // MniFileSave
            // 
            this.MniFileSave.Name = "MniFileSave";
            this.MniFileSave.Size = new System.Drawing.Size(187, 24);
            this.MniFileSave.Text = "Сохранить";
            // 
            // MniFileSaveAs
            // 
            this.MniFileSaveAs.Name = "MniFileSaveAs";
            this.MniFileSaveAs.Size = new System.Drawing.Size(187, 24);
            this.MniFileSaveAs.Text = "Сохранить как...";
            // 
            // MniFileSeparator1
            // 
            this.MniFileSeparator1.Name = "MniFileSeparator1";
            this.MniFileSeparator1.Size = new System.Drawing.Size(184, 6);
            // 
            // MniFileExit
            // 
            this.MniFileExit.Name = "MniFileExit";
            this.MniFileExit.Size = new System.Drawing.Size(187, 24);
            this.MniFileExit.Text = "Выход";
            this.MniFileExit.Click += new System.EventHandler(this.Exit_Command);
            // 
            // MniApartment
            // 
            this.MniApartment.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.новаяКвартираToolStripMenuItem,
            this.редактироватьToolStripMenuItem});
            this.MniApartment.Name = "MniApartment";
            this.MniApartment.Size = new System.Drawing.Size(87, 24);
            this.MniApartment.Text = "Квартира";
            // 
            // новаяКвартираToolStripMenuItem
            // 
            this.новаяКвартираToolStripMenuItem.Name = "новаяКвартираToolStripMenuItem";
            this.новаяКвартираToolStripMenuItem.Size = new System.Drawing.Size(199, 24);
            this.новаяКвартираToolStripMenuItem.Text = "Новая квартира...";
            // 
            // редактироватьToolStripMenuItem
            // 
            this.редактироватьToolStripMenuItem.Name = "редактироватьToolStripMenuItem";
            this.редактироватьToolStripMenuItem.Size = new System.Drawing.Size(199, 24);
            this.редактироватьToolStripMenuItem.Text = "Редактировать...";
            // 
            // MniControl
            // 
            this.MniControl.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniControlToTray,
            this.MniControlSeparator1,
            this.MniControlTurnApplianceOn,
            this.MniControlTurnApplianceOff,
            this.MniControlSeparator2,
            this.MniControlTurnOnAll,
            this.MniControlTurnOffAll});
            this.MniControl.Name = "MniControl";
            this.MniControl.Size = new System.Drawing.Size(106, 24);
            this.MniControl.Text = "Управление";
            // 
            // MniControlToTray
            // 
            this.MniControlToTray.Name = "MniControlToTray";
            this.MniControlToTray.Size = new System.Drawing.Size(223, 24);
            this.MniControlToTray.Text = "Свернуть в трей";
            this.MniControlToTray.Click += new System.EventHandler(this.ToTray_Command);
            // 
            // MniControlSeparator1
            // 
            this.MniControlSeparator1.Name = "MniControlSeparator1";
            this.MniControlSeparator1.Size = new System.Drawing.Size(220, 6);
            // 
            // MniControlTurnApplianceOn
            // 
            this.MniControlTurnApplianceOn.Name = "MniControlTurnApplianceOn";
            this.MniControlTurnApplianceOn.Size = new System.Drawing.Size(223, 24);
            this.MniControlTurnApplianceOn.Text = "Включить прибор...";
            this.MniControlTurnApplianceOn.Click += new System.EventHandler(this.TurnOnSelected_Command);
            // 
            // MniControlTurnApplianceOff
            // 
            this.MniControlTurnApplianceOff.Name = "MniControlTurnApplianceOff";
            this.MniControlTurnApplianceOff.Size = new System.Drawing.Size(223, 24);
            this.MniControlTurnApplianceOff.Text = "Выключить прибор...";
            this.MniControlTurnApplianceOff.Click += new System.EventHandler(this.TurnOffSelected_Command);
            // 
            // MniControlSeparator2
            // 
            this.MniControlSeparator2.Name = "MniControlSeparator2";
            this.MniControlSeparator2.Size = new System.Drawing.Size(220, 6);
            // 
            // MniControlTurnOnAll
            // 
            this.MniControlTurnOnAll.Name = "MniControlTurnOnAll";
            this.MniControlTurnOnAll.Size = new System.Drawing.Size(223, 24);
            this.MniControlTurnOnAll.Text = "Включить все";
            this.MniControlTurnOnAll.Click += new System.EventHandler(this.TurnOnAll_Commad);
            // 
            // MniControlTurnOffAll
            // 
            this.MniControlTurnOffAll.Name = "MniControlTurnOffAll";
            this.MniControlTurnOffAll.Size = new System.Drawing.Size(223, 24);
            this.MniControlTurnOffAll.Text = "Выключить все";
            this.MniControlTurnOffAll.Click += new System.EventHandler(this.TurnOffAll_Commad);
            // 
            // MniReport
            // 
            this.MniReport.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniReportOrder,
            this.MniReportSelect});
            this.MniReport.Name = "MniReport";
            this.MniReport.Size = new System.Drawing.Size(71, 24);
            this.MniReport.Text = "Отчеты";
            // 
            // MniReportOrder
            // 
            this.MniReportOrder.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniReportOrderByName,
            this.MniReportOrderByState,
            this.MniReportOrderByPower,
            this.MniReportOrderByPrice});
            this.MniReportOrder.Name = "MniReportOrder";
            this.MniReportOrder.Size = new System.Drawing.Size(170, 24);
            this.MniReportOrder.Text = "Упорядочить";
            // 
            // MniReportOrderByName
            // 
            this.MniReportOrderByName.Name = "MniReportOrderByName";
            this.MniReportOrderByName.Size = new System.Drawing.Size(216, 24);
            this.MniReportOrderByName.Text = "По названию";
            this.MniReportOrderByName.Click += new System.EventHandler(this.OrderByName_Command);
            // 
            // MniReportOrderByState
            // 
            this.MniReportOrderByState.Name = "MniReportOrderByState";
            this.MniReportOrderByState.Size = new System.Drawing.Size(216, 24);
            this.MniReportOrderByState.Text = "По состоянию";
            this.MniReportOrderByState.Click += new System.EventHandler(this.OrderByState_Command);
            // 
            // MniReportOrderByPower
            // 
            this.MniReportOrderByPower.Name = "MniReportOrderByPower";
            this.MniReportOrderByPower.Size = new System.Drawing.Size(216, 24);
            this.MniReportOrderByPower.Text = "По мощности";
            this.MniReportOrderByPower.Click += new System.EventHandler(this.OrderByPower_Command);
            // 
            // MniReportOrderByPrice
            // 
            this.MniReportOrderByPrice.Name = "MniReportOrderByPrice";
            this.MniReportOrderByPrice.Size = new System.Drawing.Size(216, 24);
            this.MniReportOrderByPrice.Text = "По убыванию цены";
            this.MniReportOrderByPrice.Click += new System.EventHandler(this.OrderByPriceDesc_Command);
            // 
            // MniReportSelect
            // 
            this.MniReportSelect.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniReportSelectByName,
            this.MniReportSelectByState});
            this.MniReportSelect.Name = "MniReportSelect";
            this.MniReportSelect.Size = new System.Drawing.Size(170, 24);
            this.MniReportSelect.Text = "Выбрать";
            // 
            // MniReportSelectByName
            // 
            this.MniReportSelectByName.Name = "MniReportSelectByName";
            this.MniReportSelectByName.Size = new System.Drawing.Size(178, 24);
            this.MniReportSelectByName.Text = "По названию";
            // 
            // MniReportSelectByState
            // 
            this.MniReportSelectByState.Name = "MniReportSelectByState";
            this.MniReportSelectByState.Size = new System.Drawing.Size(178, 24);
            this.MniReportSelectByState.Text = "По состоянию";
            // 
            // MniHelp
            // 
            this.MniHelp.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniHelpAbout});
            this.MniHelp.Name = "MniHelp";
            this.MniHelp.Size = new System.Drawing.Size(79, 24);
            this.MniHelp.Text = "Справка";
            // 
            // MniHelpAbout
            // 
            this.MniHelpAbout.Name = "MniHelpAbout";
            this.MniHelpAbout.Size = new System.Drawing.Size(182, 24);
            this.MniHelpAbout.Text = "О программе...";
            this.MniHelpAbout.Click += new System.EventHandler(this.About_Command);
            // 
            // TstMain
            // 
            this.TstMain.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TstMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.TsbNew,
            this.TsbOpen,
            this.TsbSave,
            this.TstSeparator1,
            this.TsbNewApartment,
            this.TsbEditApartment,
            this.TstSeparator2,
            this.TsbToTray,
            this.TsbTurnOnAll,
            this.TsbTurnOffAll});
            this.TstMain.Location = new System.Drawing.Point(0, 28);
            this.TstMain.Name = "TstMain";
            this.TstMain.Size = new System.Drawing.Size(1184, 25);
            this.TstMain.TabIndex = 1;
            this.TstMain.Text = "toolStrip1";
            // 
            // TsbNew
            // 
            this.TsbNew.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbNew.Image = ((System.Drawing.Image)(resources.GetObject("TsbNew.Image")));
            this.TsbNew.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbNew.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbNew.Name = "TsbNew";
            this.TsbNew.Size = new System.Drawing.Size(23, 22);
            this.TsbNew.Text = "toolStripButton1";
            // 
            // TsbOpen
            // 
            this.TsbOpen.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbOpen.Image = ((System.Drawing.Image)(resources.GetObject("TsbOpen.Image")));
            this.TsbOpen.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbOpen.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbOpen.Name = "TsbOpen";
            this.TsbOpen.Size = new System.Drawing.Size(23, 22);
            this.TsbOpen.Text = "toolStripButton2";
            // 
            // TsbSave
            // 
            this.TsbSave.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbSave.Image = ((System.Drawing.Image)(resources.GetObject("TsbSave.Image")));
            this.TsbSave.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbSave.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbSave.Name = "TsbSave";
            this.TsbSave.Size = new System.Drawing.Size(23, 22);
            this.TsbSave.Text = "toolStripButton3";
            // 
            // TstSeparator1
            // 
            this.TstSeparator1.Name = "TstSeparator1";
            this.TstSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // TsbNewApartment
            // 
            this.TsbNewApartment.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbNewApartment.Image = ((System.Drawing.Image)(resources.GetObject("TsbNewApartment.Image")));
            this.TsbNewApartment.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbNewApartment.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbNewApartment.Name = "TsbNewApartment";
            this.TsbNewApartment.Size = new System.Drawing.Size(23, 22);
            this.TsbNewApartment.Text = "toolStripButton4";
            // 
            // TsbEditApartment
            // 
            this.TsbEditApartment.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbEditApartment.Image = ((System.Drawing.Image)(resources.GetObject("TsbEditApartment.Image")));
            this.TsbEditApartment.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbEditApartment.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbEditApartment.Name = "TsbEditApartment";
            this.TsbEditApartment.Size = new System.Drawing.Size(23, 22);
            this.TsbEditApartment.Text = "toolStripButton5";
            // 
            // TstSeparator2
            // 
            this.TstSeparator2.Name = "TstSeparator2";
            this.TstSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // TsbToTray
            // 
            this.TsbToTray.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbToTray.Image = ((System.Drawing.Image)(resources.GetObject("TsbToTray.Image")));
            this.TsbToTray.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbToTray.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbToTray.Name = "TsbToTray";
            this.TsbToTray.Size = new System.Drawing.Size(23, 22);
            this.TsbToTray.Text = "toolStripButton6";
            // 
            // TsbTurnOnAll
            // 
            this.TsbTurnOnAll.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbTurnOnAll.Image = ((System.Drawing.Image)(resources.GetObject("TsbTurnOnAll.Image")));
            this.TsbTurnOnAll.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbTurnOnAll.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbTurnOnAll.Name = "TsbTurnOnAll";
            this.TsbTurnOnAll.Size = new System.Drawing.Size(23, 22);
            this.TsbTurnOnAll.Text = "toolStripButton7";
            // 
            // TsbTurnOffAll
            // 
            this.TsbTurnOffAll.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbTurnOffAll.Image = ((System.Drawing.Image)(resources.GetObject("TsbTurnOffAll.Image")));
            this.TsbTurnOffAll.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbTurnOffAll.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbTurnOffAll.Name = "TsbTurnOffAll";
            this.TsbTurnOffAll.Size = new System.Drawing.Size(23, 22);
            this.TsbTurnOffAll.Text = "toolStripButton7";
            // 
            // StsMain
            // 
            this.StsMain.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.StsMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.TslStatus,
            this.TslOn,
            this.TslOff});
            this.StsMain.Location = new System.Drawing.Point(0, 616);
            this.StsMain.Name = "StsMain";
            this.StsMain.Size = new System.Drawing.Size(1184, 25);
            this.StsMain.TabIndex = 2;
            this.StsMain.Text = "statusStrip1";
            // 
            // TslStatus
            // 
            this.TslStatus.AutoSize = false;
            this.TslStatus.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenInner;
            this.TslStatus.Name = "TslStatus";
            this.TslStatus.Padding = new System.Windows.Forms.Padding(6, 0, 0, 0);
            this.TslStatus.Size = new System.Drawing.Size(280, 20);
            this.TslStatus.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // TslOn
            // 
            this.TslOn.AutoSize = false;
            this.TslOn.BackColor = System.Drawing.Color.Aquamarine;
            this.TslOn.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenInner;
            this.TslOn.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.TslOn.Name = "TslOn";
            this.TslOn.Padding = new System.Windows.Forms.Padding(6, 0, 0, 0);
            this.TslOn.Size = new System.Drawing.Size(140, 20);
            this.TslOn.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // TslOff
            // 
            this.TslOff.AutoSize = false;
            this.TslOff.BackColor = System.Drawing.Color.Thistle;
            this.TslOff.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenInner;
            this.TslOff.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.TslOff.Name = "TslOff";
            this.TslOff.Padding = new System.Windows.Forms.Padding(6, 0, 0, 0);
            this.TslOff.Size = new System.Drawing.Size(140, 20);
            this.TslOff.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // CmnNotify
            // 
            this.CmnNotify.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.CmnNotify.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.CmiRestore,
            this.CmiNotifySeparator1,
            this.CmiAbout,
            this.CmiNotifySeparator2,
            this.CmiExit});
            this.CmnNotify.Name = "contextMenuStrip1";
            this.CmnNotify.Size = new System.Drawing.Size(183, 88);
            // 
            // CmiRestore
            // 
            this.CmiRestore.Name = "CmiRestore";
            this.CmiRestore.Size = new System.Drawing.Size(182, 24);
            this.CmiRestore.Text = "Восстановить";
            this.CmiRestore.Click += new System.EventHandler(this.FromTray_Command);
            // 
            // CmiNotifySeparator1
            // 
            this.CmiNotifySeparator1.Name = "CmiNotifySeparator1";
            this.CmiNotifySeparator1.Size = new System.Drawing.Size(179, 6);
            // 
            // CmiAbout
            // 
            this.CmiAbout.Name = "CmiAbout";
            this.CmiAbout.Size = new System.Drawing.Size(182, 24);
            this.CmiAbout.Text = "О программе...";
            this.CmiAbout.Click += new System.EventHandler(this.About_Command);
            // 
            // CmiNotifySeparator2
            // 
            this.CmiNotifySeparator2.Name = "CmiNotifySeparator2";
            this.CmiNotifySeparator2.Size = new System.Drawing.Size(179, 6);
            // 
            // CmiExit
            // 
            this.CmiExit.Name = "CmiExit";
            this.CmiExit.Size = new System.Drawing.Size(182, 24);
            this.CmiExit.Text = "Выход";
            this.CmiExit.Click += new System.EventHandler(this.Exit_Command);
            // 
            // CmnListView
            // 
            this.CmnListView.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.CmnListView.Name = "contextMenuStrip2";
            this.CmnListView.Size = new System.Drawing.Size(61, 4);
            // 
            // ImlSmall
            // 
            this.ImlSmall.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("ImlSmall.ImageStream")));
            this.ImlSmall.TransparentColor = System.Drawing.Color.Transparent;
            this.ImlSmall.Images.SetKeyName(0, "ledoff.png");
            this.ImlSmall.Images.SetKeyName(1, "ledon.png");
            // 
            // OfdMain
            // 
            this.OfdMain.FileName = "openFileDialog1";
            // 
            // NtfMain
            // 
            this.NtfMain.ContextMenuStrip = this.CmnNotify;
            this.NtfMain.Icon = ((System.Drawing.Icon)(resources.GetObject("NtfMain.Icon")));
            this.NtfMain.Text = "Управление электроприборами\r\nквартиры";
            // 
            // LblApartmentInfo
            // 
            this.LblApartmentInfo.Dock = System.Windows.Forms.DockStyle.Top;
            this.LblApartmentInfo.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblApartmentInfo.Location = new System.Drawing.Point(0, 53);
            this.LblApartmentInfo.Name = "LblApartmentInfo";
            this.LblApartmentInfo.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.LblApartmentInfo.Size = new System.Drawing.Size(1184, 27);
            this.LblApartmentInfo.TabIndex = 3;
            this.LblApartmentInfo.Text = "Место для вывода адреса квартиры";
            this.LblApartmentInfo.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // TbcMain
            // 
            this.TbcMain.Controls.Add(this.TbpAppliances);
            this.TbcMain.Controls.Add(this.TbpSorted);
            this.TbcMain.Controls.Add(this.TbpSelected);
            this.TbcMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TbcMain.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TbcMain.Location = new System.Drawing.Point(0, 80);
            this.TbcMain.Name = "TbcMain";
            this.TbcMain.SelectedIndex = 0;
            this.TbcMain.Size = new System.Drawing.Size(1184, 536);
            this.TbcMain.TabIndex = 6;
            // 
            // TbpAppliances
            // 
            this.TbpAppliances.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.TbpAppliances.Controls.Add(this.LsvAppliances);
            this.TbpAppliances.Location = new System.Drawing.Point(4, 27);
            this.TbpAppliances.Name = "TbpAppliances";
            this.TbpAppliances.Padding = new System.Windows.Forms.Padding(3);
            this.TbpAppliances.Size = new System.Drawing.Size(1176, 505);
            this.TbpAppliances.TabIndex = 0;
            this.TbpAppliances.Text = "Приборы квартиры";
            this.TbpAppliances.ToolTipText = "Коллекция приборов квартиры";
            this.TbpAppliances.UseVisualStyleBackColor = true;
            // 
            // LsvAppliances
            // 
            this.LsvAppliances.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.ClhState,
            this.ClhId,
            this.ClhName,
            this.ClhPower,
            this.ClhPrice});
            this.LsvAppliances.Dock = System.Windows.Forms.DockStyle.Fill;
            this.LsvAppliances.FullRowSelect = true;
            this.LsvAppliances.GridLines = true;
            this.LsvAppliances.HideSelection = false;
            this.LsvAppliances.LabelEdit = true;
            this.LsvAppliances.Location = new System.Drawing.Point(3, 3);
            this.LsvAppliances.MultiSelect = false;
            this.LsvAppliances.Name = "LsvAppliances";
            this.LsvAppliances.Size = new System.Drawing.Size(1166, 495);
            this.LsvAppliances.SmallImageList = this.ImlSmall;
            this.LsvAppliances.TabIndex = 0;
            this.LsvAppliances.UseCompatibleStateImageBehavior = false;
            this.LsvAppliances.View = System.Windows.Forms.View.Details;
            // 
            // ClhState
            // 
            this.ClhState.Text = "Состояние";
            this.ClhState.Width = 120;
            // 
            // ClhId
            // 
            this.ClhId.Text = "Идентификатор";
            this.ClhId.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.ClhId.Width = 180;
            // 
            // ClhName
            // 
            this.ClhName.Text = "Название";
            this.ClhName.Width = 260;
            // 
            // ClhPower
            // 
            this.ClhPower.Text = "Мощность, Вт";
            this.ClhPower.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.ClhPower.Width = 160;
            // 
            // ClhPrice
            // 
            this.ClhPrice.Text = "Цена, руб.";
            this.ClhPrice.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.ClhPrice.Width = 160;
            // 
            // TbpSorted
            // 
            this.TbpSorted.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.TbpSorted.Controls.Add(this.LsvOrdered);
            this.TbpSorted.Location = new System.Drawing.Point(4, 27);
            this.TbpSorted.Name = "TbpSorted";
            this.TbpSorted.Padding = new System.Windows.Forms.Padding(3);
            this.TbpSorted.Size = new System.Drawing.Size(1176, 505);
            this.TbpSorted.TabIndex = 1;
            this.TbpSorted.Text = "Упорядоченная коллекция";
            this.TbpSorted.UseVisualStyleBackColor = true;
            // 
            // LsvOrdered
            // 
            this.LsvOrdered.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3,
            this.columnHeader4,
            this.columnHeader5});
            this.LsvOrdered.Dock = System.Windows.Forms.DockStyle.Fill;
            this.LsvOrdered.FullRowSelect = true;
            this.LsvOrdered.GridLines = true;
            this.LsvOrdered.HideSelection = false;
            this.LsvOrdered.LabelEdit = true;
            this.LsvOrdered.Location = new System.Drawing.Point(3, 3);
            this.LsvOrdered.MultiSelect = false;
            this.LsvOrdered.Name = "LsvOrdered";
            this.LsvOrdered.Size = new System.Drawing.Size(1166, 495);
            this.LsvOrdered.SmallImageList = this.ImlSmall;
            this.LsvOrdered.TabIndex = 1;
            this.LsvOrdered.UseCompatibleStateImageBehavior = false;
            this.LsvOrdered.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Состояние";
            this.columnHeader1.Width = 120;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Идентификатор";
            this.columnHeader2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.columnHeader2.Width = 180;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Название";
            this.columnHeader3.Width = 260;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "Мощность, Вт";
            this.columnHeader4.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.columnHeader4.Width = 160;
            // 
            // columnHeader5
            // 
            this.columnHeader5.Text = "Цена, руб.";
            this.columnHeader5.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.columnHeader5.Width = 160;
            // 
            // TbpSelected
            // 
            this.TbpSelected.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.TbpSelected.Controls.Add(this.LsvFiltered);
            this.TbpSelected.Location = new System.Drawing.Point(4, 27);
            this.TbpSelected.Name = "TbpSelected";
            this.TbpSelected.Padding = new System.Windows.Forms.Padding(3);
            this.TbpSelected.Size = new System.Drawing.Size(1176, 505);
            this.TbpSelected.TabIndex = 2;
            this.TbpSelected.Text = "Выборка приборов";
            this.TbpSelected.UseVisualStyleBackColor = true;
            // 
            // LsvFiltered
            // 
            this.LsvFiltered.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader6,
            this.columnHeader7,
            this.columnHeader8,
            this.columnHeader9,
            this.columnHeader10});
            this.LsvFiltered.Dock = System.Windows.Forms.DockStyle.Fill;
            this.LsvFiltered.FullRowSelect = true;
            this.LsvFiltered.GridLines = true;
            this.LsvFiltered.HideSelection = false;
            this.LsvFiltered.LabelEdit = true;
            this.LsvFiltered.Location = new System.Drawing.Point(3, 3);
            this.LsvFiltered.MultiSelect = false;
            this.LsvFiltered.Name = "LsvFiltered";
            this.LsvFiltered.Size = new System.Drawing.Size(1166, 495);
            this.LsvFiltered.SmallImageList = this.ImlSmall;
            this.LsvFiltered.TabIndex = 1;
            this.LsvFiltered.UseCompatibleStateImageBehavior = false;
            this.LsvFiltered.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader6
            // 
            this.columnHeader6.Text = "Состояние";
            this.columnHeader6.Width = 120;
            // 
            // columnHeader7
            // 
            this.columnHeader7.Text = "Идентификатор";
            this.columnHeader7.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.columnHeader7.Width = 180;
            // 
            // columnHeader8
            // 
            this.columnHeader8.Text = "Название";
            this.columnHeader8.Width = 260;
            // 
            // columnHeader9
            // 
            this.columnHeader9.Text = "Мощность, Вт";
            this.columnHeader9.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.columnHeader9.Width = 160;
            // 
            // columnHeader10
            // 
            this.columnHeader10.Text = "Цена, руб.";
            this.columnHeader10.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.columnHeader10.Width = 160;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1184, 641);
            this.Controls.Add(this.TbcMain);
            this.Controls.Add(this.LblApartmentInfo);
            this.Controls.Add(this.TstMain);
            this.Controls.Add(this.StsMain);
            this.Controls.Add(this.MnsMain);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.MnsMain;
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Задание на 01.12.2021 - изучение ListView";
            this.MnsMain.ResumeLayout(false);
            this.MnsMain.PerformLayout();
            this.TstMain.ResumeLayout(false);
            this.TstMain.PerformLayout();
            this.StsMain.ResumeLayout(false);
            this.StsMain.PerformLayout();
            this.CmnNotify.ResumeLayout(false);
            this.TbcMain.ResumeLayout(false);
            this.TbpAppliances.ResumeLayout(false);
            this.TbpSorted.ResumeLayout(false);
            this.TbpSelected.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip MnsMain;
        private System.Windows.Forms.ToolStrip TstMain;
        private System.Windows.Forms.StatusStrip StsMain;
        private System.Windows.Forms.ContextMenuStrip CmnNotify;
        private System.Windows.Forms.ContextMenuStrip CmnListView;
        private System.Windows.Forms.ToolStripMenuItem MniFile;
        private System.Windows.Forms.ToolStripMenuItem MniFileOpen;
        private System.Windows.Forms.ToolStripMenuItem MniFileSave;
        private System.Windows.Forms.ToolStripMenuItem MniFileSaveAs;
        private System.Windows.Forms.ToolStripSeparator MniFileSeparator1;
        private System.Windows.Forms.ToolStripMenuItem MniFileExit;
        private System.Windows.Forms.ToolStripMenuItem MniApartment;
        private System.Windows.Forms.ToolStripMenuItem новаяКвартираToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem редактироватьToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem MniControl;
        private System.Windows.Forms.ToolStripMenuItem MniControlToTray;
        private System.Windows.Forms.ToolStripMenuItem MniReport;
        private System.Windows.Forms.ToolStripMenuItem MniHelp;
        private System.Windows.Forms.ToolStripMenuItem MniHelpAbout;
        private System.Windows.Forms.OpenFileDialog OfdMain;
        private System.Windows.Forms.SaveFileDialog SfdMain;
        private System.Windows.Forms.NotifyIcon NtfMain;
        private System.Windows.Forms.ToolStripButton TsbNew;
        private System.Windows.Forms.ToolStripButton TsbOpen;
        private System.Windows.Forms.ToolStripButton TsbSave;
        private System.Windows.Forms.ToolStripSeparator TstSeparator1;
        private System.Windows.Forms.ToolStripButton TsbNewApartment;
        private System.Windows.Forms.ToolStripButton TsbEditApartment;
        private System.Windows.Forms.ToolStripSeparator TstSeparator2;
        private System.Windows.Forms.ToolStripButton TsbToTray;
        private System.Windows.Forms.ToolStripButton TsbTurnOnAll;
        private System.Windows.Forms.ToolStripStatusLabel TslStatus;
        private System.Windows.Forms.ToolStripSeparator MniControlSeparator1;
        private System.Windows.Forms.ToolStripMenuItem MniControlTurnApplianceOn;
        private System.Windows.Forms.ToolStripMenuItem MniControlTurnApplianceOff;
        private System.Windows.Forms.ToolStripSeparator MniControlSeparator2;
        private System.Windows.Forms.ToolStripMenuItem MniControlTurnOnAll;
        private System.Windows.Forms.ToolStripMenuItem MniControlTurnOffAll;
        private System.Windows.Forms.ToolStripMenuItem MniReportOrder;
        private System.Windows.Forms.ToolStripMenuItem MniReportSelect;
        private System.Windows.Forms.ToolStripButton TsbTurnOffAll;
        private System.Windows.Forms.ToolStripMenuItem CmiRestore;
        private System.Windows.Forms.ToolStripSeparator CmiNotifySeparator1;
        private System.Windows.Forms.ToolStripMenuItem CmiAbout;
        private System.Windows.Forms.ToolStripSeparator CmiNotifySeparator2;
        private System.Windows.Forms.ToolStripMenuItem CmiExit;
        private System.Windows.Forms.ToolStripMenuItem MniReportOrderByName;
        private System.Windows.Forms.ToolStripMenuItem MniReportOrderByState;
        private System.Windows.Forms.ToolStripMenuItem MniReportOrderByPower;
        private System.Windows.Forms.ToolStripMenuItem MniReportOrderByPrice;
        private System.Windows.Forms.ToolStripMenuItem MniReportSelectByName;
        private System.Windows.Forms.ToolStripMenuItem MniReportSelectByState;
        private System.Windows.Forms.ImageList ImlSmall;
        private System.Windows.Forms.Label LblApartmentInfo;
        private System.Windows.Forms.TabControl TbcMain;
        private System.Windows.Forms.TabPage TbpAppliances;
        private System.Windows.Forms.ListView LsvAppliances;
        private System.Windows.Forms.ColumnHeader ClhState;
        private System.Windows.Forms.ColumnHeader ClhId;
        private System.Windows.Forms.ColumnHeader ClhName;
        private System.Windows.Forms.ColumnHeader ClhPower;
        private System.Windows.Forms.ColumnHeader ClhPrice;
        private System.Windows.Forms.TabPage TbpSorted;
        private System.Windows.Forms.ListView LsvOrdered;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.ColumnHeader columnHeader5;
        private System.Windows.Forms.TabPage TbpSelected;
        private System.Windows.Forms.ListView LsvFiltered;
        private System.Windows.Forms.ColumnHeader columnHeader6;
        private System.Windows.Forms.ColumnHeader columnHeader7;
        private System.Windows.Forms.ColumnHeader columnHeader8;
        private System.Windows.Forms.ColumnHeader columnHeader9;
        private System.Windows.Forms.ColumnHeader columnHeader10;
        private System.Windows.Forms.ToolStripStatusLabel TslOn;
        private System.Windows.Forms.ToolStripStatusLabel TslOff;
    }
}

