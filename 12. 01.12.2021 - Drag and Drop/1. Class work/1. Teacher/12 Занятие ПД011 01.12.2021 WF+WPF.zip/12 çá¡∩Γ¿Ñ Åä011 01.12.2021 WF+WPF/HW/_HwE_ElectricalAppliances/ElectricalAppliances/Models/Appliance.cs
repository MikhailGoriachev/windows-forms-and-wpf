﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ElectricalAppliances.Helpers;
using Microsoft.Win32;

namespace ElectricalAppliances.Models
{

    // Класс, описывающий электроприбор (название, мощность, цена
    // и состояние прибора: включен/выключен)


    public class Appliance
    {
        // идентификатор прибора, об уникальности идентификатора пока
        // не заботимся :)
        private int _id;
        public int Id { get => _id; private set => _id = value; }

        // название электроприбора
        private string _name;
        public string Name {
            get => _name;
            set {
                if (string.IsNullOrEmpty(value)) 
                    throw new ArgumentNullException("Пустая строка в названии прибора");
                
                _name = value; 
            } // set
        } // Name

        // мощность электроприбора
        private int _power;
        public int Power {
            get => _power; 
            set {
                if (value <= 0)
                    throw new ArgumentOutOfRangeException($"Недопустимая мощность электроприбора: {value}");

                _power = value;
            } // set
        } // Power


        // цена электроприбора
        private int _price;
        public int Price {
            get => _price;
            set {
                if (value <= 0)
                    throw new ArgumentOutOfRangeException($"Недопустимая цена электроприбора: {value}");

                _price = value;
            } // set
        } // Price

        // состояние электроприбора: включен/выключен
        private bool _state;
        public bool State {
            get => _state;
            set => _state = value;
        } // State

        #region ансамбль конструкторов
        public Appliance() : this("чайник", 1_200, 3_200, false) {
            Id = 0;
        } // Appliance

        public Appliance(string name, int power, int price, bool state) {
            Name = name;
            Power = power;
            Price = price;
            State = state;
            _id = 0;
        } // Appliance
        #endregion

        // строковое представление объекта
        public override string ToString() =>
            $"{_id}, {_name}: {_power} Вт, {_price} руб., {(_state?"Включен":"Выключен")}" ;

        // формирование строки в табличном представлениии
        public string ToTableRow(int indent) =>
            $"{" ".PadRight(indent)}" +
            $"│ {_id,6} │ {_name, -22} │ {_power, 12:n2} │ {_price, 10:n2} │ " +
            $"{(_state ? "Включен" : "Выключен"), -10} │";

        // формирование строки для ListView
        public ListViewItem ToListViewItem() {
            // получить элемент для заполнения строки ListView,
            // указать в нем данные 0го столбца: если без текста и только число,
            // то это индекс картинки из ImageList, 0 - выключен, 1 - включен
            ListViewItem listViewItem = new ListViewItem("", _state?1:0);

            // добавить остальные столбцы
            listViewItem.SubItems.Add($"{_id}");
            listViewItem.SubItems.Add(_name);
            listViewItem.SubItems.Add($"{_power:n2}");
            listViewItem.SubItems.Add($"{_price:n2}");

            return listViewItem;
        } // ToListViewItem

        // Шапка таблицы, статическое свойство
        public static string Header(int indent) {
            string spaces = " ".PadRight(indent);
            return
            $"{spaces}┌────────┬────────────────────────┬──────────────┬────────────┬────────────┐\n" +
            $"{spaces}│ Идент. │ Название прибора       │ Мощность, Вт │ Цена, руб. │ Состояние  │\n" +
            $"{spaces}├────────┼────────────────────────┼──────────────┼────────────┼────────────┤\n";
        } // Header

        // Подвал таблицы, статическое свойство
        public static string Footer(int indent) =>
            $"{" ".PadRight(indent)}└────────┴────────────────────────┴──────────────┴────────────┴────────────┘\n";

        // Фабричный метод для создания электроприбора из случайных данных
        // уникальность идентификатора обеспечиваем внешним кодом
        public static Appliance Generate(int id) {
            (string Name, int Power, int Price)[] data = { 
                ("чайник", 1_200, 2_100), ("блендер", 300, 900), ("утюг", 1_100, 1_900), 
                ("миксер", 780, 1_100),   ("хлебопечка", 1_100, 9_200), 
                ("стиральная машина", 2_100, 13_800), ("микроволновка", 900, 9_600), 
                ("светильник", 20, 600), ("панель управления", 20, 900), 
                ("посудомоечная машина", 2_100, 13_000), ("вертикальный пылесос", 900, 11_300)
            };
            int index = Utils.Random.Next(0, data.Length);
            return new Appliance { 
                _id = id,
                _name = data[index].Name, 
                _power = data[index].Power, 
                _price = data[index].Price,
                // сформировать состояние прибора - включен или выключен
                _state = Utils.GetRandom(0, 1) == 1  
            };
        } // Generate
    } // class Appliance
}
