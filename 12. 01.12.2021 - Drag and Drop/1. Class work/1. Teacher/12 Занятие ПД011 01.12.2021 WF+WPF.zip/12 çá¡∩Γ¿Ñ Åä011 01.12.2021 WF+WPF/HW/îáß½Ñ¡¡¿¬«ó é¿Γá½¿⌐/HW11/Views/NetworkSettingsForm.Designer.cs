﻿
namespace HW11.Views
{
	partial class NetworkSettingsForm
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.BtnCancel = new System.Windows.Forms.Button();
			this.BtnSave = new System.Windows.Forms.Button();
			this.TxbAddress = new System.Windows.Forms.TextBox();
			this.TxbTitle = new System.Windows.Forms.TextBox();
			this.LblAddress = new System.Windows.Forms.Label();
			this.LblTitle = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// BtnCancel
			// 
			this.BtnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.BtnCancel.Location = new System.Drawing.Point(324, 210);
			this.BtnCancel.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.BtnCancel.Name = "BtnCancel";
			this.BtnCancel.Size = new System.Drawing.Size(204, 44);
			this.BtnCancel.TabIndex = 11;
			this.BtnCancel.Text = "Отмена";
			this.BtnCancel.UseVisualStyleBackColor = true;
			this.BtnCancel.Click += new System.EventHandler(this.BtnCancel_Click);
			// 
			// BtnSave
			// 
			this.BtnSave.DialogResult = System.Windows.Forms.DialogResult.OK;
			this.BtnSave.Location = new System.Drawing.Point(36, 210);
			this.BtnSave.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.BtnSave.Name = "BtnSave";
			this.BtnSave.Size = new System.Drawing.Size(204, 44);
			this.BtnSave.TabIndex = 10;
			this.BtnSave.Text = "Сохранить";
			this.BtnSave.UseVisualStyleBackColor = true;
			this.BtnSave.Click += new System.EventHandler(this.BtnSave_Click);
			// 
			// TxbAddress
			// 
			this.TxbAddress.Location = new System.Drawing.Point(36, 144);
			this.TxbAddress.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.TxbAddress.Name = "TxbAddress";
			this.TxbAddress.Size = new System.Drawing.Size(490, 24);
			this.TxbAddress.TabIndex = 9;
			// 
			// TxbTitle
			// 
			this.TxbTitle.Location = new System.Drawing.Point(36, 66);
			this.TxbTitle.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.TxbTitle.Name = "TxbTitle";
			this.TxbTitle.Size = new System.Drawing.Size(490, 24);
			this.TxbTitle.TabIndex = 8;
			// 
			// LblAddress
			// 
			this.LblAddress.AutoSize = true;
			this.LblAddress.Location = new System.Drawing.Point(36, 111);
			this.LblAddress.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			this.LblAddress.Name = "LblAddress";
			this.LblAddress.Size = new System.Drawing.Size(124, 18);
			this.LblAddress.TabIndex = 7;
			this.LblAddress.Text = "Адрес квартиры:";
			// 
			// LblTitle
			// 
			this.LblTitle.AutoSize = true;
			this.LblTitle.Location = new System.Drawing.Point(36, 33);
			this.LblTitle.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			this.LblTitle.Name = "LblTitle";
			this.LblTitle.Size = new System.Drawing.Size(242, 18);
			this.LblTitle.TabIndex = 6;
			this.LblTitle.Text = "Название сети электроприборов:";
			// 
			// NetworkSettingsForm
			// 
			this.AcceptButton = this.BtnSave;
			this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.CancelButton = this.BtnCancel;
			this.ClientSize = new System.Drawing.Size(560, 285);
			this.Controls.Add(this.BtnCancel);
			this.Controls.Add(this.BtnSave);
			this.Controls.Add(this.TxbAddress);
			this.Controls.Add(this.TxbTitle);
			this.Controls.Add(this.LblAddress);
			this.Controls.Add(this.LblTitle);
			this.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.MaximizeBox = false;
			this.Name = "NetworkSettingsForm";
			this.ShowInTaskbar = false;
			this.Text = "Информация о сети электроприборов";
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Button BtnCancel;
		private System.Windows.Forms.Button BtnSave;
		private System.Windows.Forms.TextBox TxbAddress;
		private System.Windows.Forms.TextBox TxbTitle;
		private System.Windows.Forms.Label LblAddress;
		private System.Windows.Forms.Label LblTitle;
	}
}