﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HW11.Views
{
	public partial class NetworkSettingsForm : Form
	{
		// название сети электроприборов
		public string Title { get; private set; }
		// адрес квартиры
		public string Address { get; private set; }

		public NetworkSettingsForm(string title, string address)
		{
			InitializeComponent();

			TxbTitle.Text = title;
			TxbAddress.Text = address;
		}

		private void BtnSave_Click(object sender, EventArgs e)
		{
			Title = TxbTitle.Text;
			Address = TxbAddress.Text;
		}

		private void BtnCancel_Click(object sender, EventArgs e) => Close();

		private void ShopSettingsForm_FormClosing(object sender, FormClosingEventArgs e)
		{
			if ((DialogResult == DialogResult.OK)
			    & (string.IsNullOrWhiteSpace(TxbAddress.Text) ||
			       string.IsNullOrWhiteSpace(TxbAddress.Text)))
			{
				MessageBox.Show("Не все поля заполнены", "Ошибка",
					MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				e.Cancel = true;
			}
		}
	}
}
