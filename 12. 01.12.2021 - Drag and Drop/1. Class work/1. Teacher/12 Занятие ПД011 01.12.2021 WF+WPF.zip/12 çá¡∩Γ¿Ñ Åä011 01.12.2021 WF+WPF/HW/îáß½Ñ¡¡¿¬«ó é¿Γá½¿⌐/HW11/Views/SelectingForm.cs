﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HW11.Views
{
	public partial class SelectingForm : Form
	{
		public SelectingForm()
		{
			InitializeComponent();
			CbxList.SelectedIndex = 0;
		}

		public SelectingForm(List<string> data, string label)
		{
			InitializeComponent();
			LblPrompt.Text = label;
			CbxList.DataSource = data;
			CbxList.SelectedIndex = 0;
		}

		public string Choosen => CbxList.Text;
	}
}
