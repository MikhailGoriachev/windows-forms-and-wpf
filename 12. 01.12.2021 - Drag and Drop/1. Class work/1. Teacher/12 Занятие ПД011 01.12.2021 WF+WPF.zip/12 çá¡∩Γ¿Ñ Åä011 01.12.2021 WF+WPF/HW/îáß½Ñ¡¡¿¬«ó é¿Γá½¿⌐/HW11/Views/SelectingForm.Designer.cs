﻿
namespace HW11.Views
{
	partial class SelectingForm
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SelectingForm));
			this.BtnCancel = new System.Windows.Forms.Button();
			this.BtnOk = new System.Windows.Forms.Button();
			this.CbxList = new System.Windows.Forms.ComboBox();
			this.LblPrompt = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// BtnCancel
			// 
			this.BtnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.BtnCancel.Font = new System.Drawing.Font("Segoe UI", 12F);
			this.BtnCancel.Location = new System.Drawing.Point(203, 98);
			this.BtnCancel.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.BtnCancel.Name = "BtnCancel";
			this.BtnCancel.Size = new System.Drawing.Size(164, 29);
			this.BtnCancel.TabIndex = 11;
			this.BtnCancel.Text = "Отмена";
			this.BtnCancel.UseVisualStyleBackColor = true;
			// 
			// BtnOk
			// 
			this.BtnOk.DialogResult = System.Windows.Forms.DialogResult.OK;
			this.BtnOk.Font = new System.Drawing.Font("Segoe UI", 12F);
			this.BtnOk.Location = new System.Drawing.Point(27, 98);
			this.BtnOk.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.BtnOk.Name = "BtnOk";
			this.BtnOk.Size = new System.Drawing.Size(164, 29);
			this.BtnOk.TabIndex = 10;
			this.BtnOk.Text = "Выбрать";
			this.BtnOk.UseVisualStyleBackColor = true;
			// 
			// CbxList
			// 
			this.CbxList.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.CbxList.Font = new System.Drawing.Font("Segoe UI", 12F);
			this.CbxList.FormattingEnabled = true;
			this.CbxList.Items.AddRange(new object[] {
            "включено",
            "выключено"});
			this.CbxList.Location = new System.Drawing.Point(27, 52);
			this.CbxList.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.CbxList.Name = "CbxList";
			this.CbxList.Size = new System.Drawing.Size(340, 29);
			this.CbxList.Sorted = true;
			this.CbxList.TabIndex = 9;
			// 
			// LblPrompt
			// 
			this.LblPrompt.AutoSize = true;
			this.LblPrompt.Font = new System.Drawing.Font("Segoe UI", 12F);
			this.LblPrompt.Location = new System.Drawing.Point(15, 19);
			this.LblPrompt.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			this.LblPrompt.Name = "LblPrompt";
			this.LblPrompt.Size = new System.Drawing.Size(247, 21);
			this.LblPrompt.TabIndex = 8;
			this.LblPrompt.Text = "Укажите состояние для выборки:";
			// 
			// SelectingForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(382, 146);
			this.Controls.Add(this.BtnCancel);
			this.Controls.Add(this.BtnOk);
			this.Controls.Add(this.CbxList);
			this.Controls.Add(this.LblPrompt);
			this.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.MaximizeBox = false;
			this.Name = "SelectingForm";
			this.ShowInTaskbar = false;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "Выборка приборов";
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Button BtnCancel;
		private System.Windows.Forms.Button BtnOk;
		private System.Windows.Forms.ComboBox CbxList;
		private System.Windows.Forms.Label LblPrompt;
	}
}