﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HW11.Helpers;
using HW11.Models;
using Newtonsoft.Json;

namespace HW11.Controllers
{
	public class ApplianceNetworkController
	{
		// объект для обработки
		private ApplianceNetwork _applianceNetwork;

		public ApplianceNetwork ApplianceNetwork
		{
			get => _applianceNetwork;
			private set => _applianceNetwork = value;
		}

		public List<Appliance> Appliances { get => _applianceNetwork.Appliances; }

		// директория и имя файля для сохранения
		public string FileName { get; set; }

		// директория и имя файля для сохранения по-умолчанию
		public static readonly string FileNameDefault = Environment.CurrentDirectory + @"\App_Data\appliances.json";


		// конструкторы
		public ApplianceNetworkController() : this(FileNameDefault, new ApplianceNetwork())
		{
			string dir = Path.GetDirectoryName(FileNameDefault);
			if (!Directory.Exists(dir))
				Directory.CreateDirectory(dir);

			if (File.Exists(FileNameDefault))
				ReadJsonFromFile(FileNameDefault);
			else
			{
				_applianceNetwork.Initialize();
				SaveJsonToFile(FileNameDefault);
			}
		} 

		public ApplianceNetworkController(string fileName, ApplianceNetwork applianceNetwork)
		{
			_applianceNetwork = applianceNetwork;
			FileName = fileName;
		}

		// получить список приборов
		public List<string> GetAppliancesNames => _applianceNetwork.GetAppliancesNames();

		#region CRUD
		
		// добавление прибора в коллекцию
		public void AddAppliance(Appliance appliance) => _applianceNetwork.AddAppliance(appliance);

		// удаление выбранного прибора
		public void RemoveAt(int index) => _applianceNetwork.RemoveAppliance(index);


		// удаление всех приборов
		public void RemoveAll() => _applianceNetwork.Clear();

		#endregion


		#region Сериализация
		// Сохранение в файл JSON форматом
		public void SaveJsonToFile(string fileName)
		{
			using (StreamWriter file = File.CreateText(fileName))
			{
				new JsonSerializer { Formatting = Formatting.Indented }.Serialize(file, _applianceNetwork);
			}
		}

		// Чтение из файла JSON форматом
		public void ReadJsonFromFile(string fileName)
		{

			using (StreamReader file = File.OpenText(fileName))
			{
				JsonSerializer serializer = new JsonSerializer();
				_applianceNetwork.Clear();
				_applianceNetwork = (ApplianceNetwork)serializer.Deserialize(file, typeof(ApplianceNetwork));
			}
		}
		#endregion


		#region Сортировки

		// Запрос на упорядочивание коллекции по названию 
		public void OrderByName() => ApplianceNetwork.OrderBy((app1, app2) =>
			app1.Name.CompareTo(app2.Name));

		public void OrderByState() => ApplianceNetwork.OrderBy((app1, app2) =>
			app1.State.CompareTo(app2.State));

		public void OrderByPower() => ApplianceNetwork.OrderBy((app1, app2) =>
			app1.Power.CompareTo(app2.Power));

		public void OrderByPriceDesc() => ApplianceNetwork.OrderBy((app1, app2) =>
			app2.Price.CompareTo(app1.Price));


		// Статические методы сортировки

		public static void OrderByName(List<Appliance> list) =>
			Models.ApplianceNetwork.OrderBy(list, (app1, app2) =>
			app1.Name.CompareTo(app2.Name));

		public static void OrderByState(List<Appliance> list) =>
			Models.ApplianceNetwork.OrderBy(list, (app1, app2) =>
				app1.State.CompareTo(app2.State));

		public static void OrderByPower(List<Appliance> list) =>
			Models.ApplianceNetwork.OrderBy(list, (app1, app2) =>
				app1.Power.CompareTo(app2.Power));

		public static void OrderByPriceDesc(List<Appliance> list) =>
			Models.ApplianceNetwork.OrderBy(list, (app1, app2) =>
				app2.Price.CompareTo(app1.Price));

		#endregion


		#region Выборка

		// Запрос на выборку из коллекции приборов с заданным названием
		public List<Appliance> SelectWhereName(string name) =>
			_applianceNetwork.Filter(app => app.Name == name);

		// Запрос на выборку из коллекции приборов с заданным состоянием
		public List<Appliance> SelectWhereState(bool state) =>
			_applianceNetwork.Filter(app => app.State == state);

		#endregion


		#region Управление состоянием

		// включение всех приборов, всем приборам установить состояние
		// «включено»
		public void TurnOnAll() =>
			_applianceNetwork.SetAllAppliancesState(true);


		// выключение всех приборов, всем приборам установить состояние
		// «выключено»
		public void TurnOffAll() =>
			_applianceNetwork.SetAllAppliancesState(false);


		// включение выбранного прибора
		public void TurnOnAt(int index) => _applianceNetwork[index].State = true;


		// выключение выбранного прибора
		public void TurnOffAt(int index) => _applianceNetwork[index].State = false;

		#endregion
	}
}
