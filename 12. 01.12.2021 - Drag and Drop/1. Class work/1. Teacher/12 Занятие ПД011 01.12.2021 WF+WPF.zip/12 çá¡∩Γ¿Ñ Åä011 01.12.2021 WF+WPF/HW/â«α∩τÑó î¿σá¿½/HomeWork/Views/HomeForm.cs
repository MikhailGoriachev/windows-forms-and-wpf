﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using HomeWork.Controllers;     // контроллеры
using HomeWork.Models;          // модели
using HomeWork.Utilities;       // утилиты

namespace HomeWork.Views
{
    public partial class HomeForm : Form
    {
        // прибор
        public ElectricalAppliance appliance;

        // запуск формы в режиме создания
        public HomeForm()
        {
            InitializeComponent();

            // создание прибора 
            appliance = HomeAppliancesController.FactoryMethod(Utils.GetRand(0, 4));

            // вывод данных 
            
        }


    }
}
