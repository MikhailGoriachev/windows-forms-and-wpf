These icons are from Icojam (http://www.icojam.com)
(you can buy vector and hi-res version)

Animals mini free [bitmap]

Ammount of icons:
16

Icon Sizes:
64x64

File Types:
.png: 
64x64(32bit)
