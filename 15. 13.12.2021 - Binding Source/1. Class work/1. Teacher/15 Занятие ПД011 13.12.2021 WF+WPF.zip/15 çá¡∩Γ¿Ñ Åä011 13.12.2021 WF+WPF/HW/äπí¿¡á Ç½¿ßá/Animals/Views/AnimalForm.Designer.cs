﻿
namespace Animals.Views
{
    partial class AnimalForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.GrbAddElectrodevice = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.TbxColor = new System.Windows.Forms.TextBox();
            this.LblOwner = new System.Windows.Forms.Label();
            this.TbxOwner = new System.Windows.Forms.TextBox();
            this.LblType = new System.Windows.Forms.Label();
            this.CbxType = new System.Windows.Forms.ComboBox();
            this.BtnCancel = new System.Windows.Forms.Button();
            this.BtnOk = new System.Windows.Forms.Button();
            this.LblAge = new System.Windows.Forms.Label();
            this.LblWeight = new System.Windows.Forms.Label();
            this.LblPetName = new System.Windows.Forms.Label();
            this.NudAge = new System.Windows.Forms.NumericUpDown();
            this.NudWeight = new System.Windows.Forms.NumericUpDown();
            this.TbxPetName = new System.Windows.Forms.TextBox();
            this.ErpName = new System.Windows.Forms.ErrorProvider(this.components);
            this.ErpPetName = new System.Windows.Forms.ErrorProvider(this.components);
            this.ErpColor = new System.Windows.Forms.ErrorProvider(this.components);
            this.GrbAddElectrodevice.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.NudAge)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NudWeight)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ErpName)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ErpPetName)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ErpColor)).BeginInit();
            this.SuspendLayout();
            // 
            // GrbAddElectrodevice
            // 
            this.GrbAddElectrodevice.Controls.Add(this.label1);
            this.GrbAddElectrodevice.Controls.Add(this.TbxColor);
            this.GrbAddElectrodevice.Controls.Add(this.LblOwner);
            this.GrbAddElectrodevice.Controls.Add(this.TbxOwner);
            this.GrbAddElectrodevice.Controls.Add(this.LblType);
            this.GrbAddElectrodevice.Controls.Add(this.CbxType);
            this.GrbAddElectrodevice.Controls.Add(this.BtnCancel);
            this.GrbAddElectrodevice.Controls.Add(this.BtnOk);
            this.GrbAddElectrodevice.Controls.Add(this.LblAge);
            this.GrbAddElectrodevice.Controls.Add(this.LblWeight);
            this.GrbAddElectrodevice.Controls.Add(this.LblPetName);
            this.GrbAddElectrodevice.Controls.Add(this.NudAge);
            this.GrbAddElectrodevice.Controls.Add(this.NudWeight);
            this.GrbAddElectrodevice.Controls.Add(this.TbxPetName);
            this.GrbAddElectrodevice.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.GrbAddElectrodevice.Location = new System.Drawing.Point(12, 12);
            this.GrbAddElectrodevice.Name = "GrbAddElectrodevice";
            this.GrbAddElectrodevice.Size = new System.Drawing.Size(347, 337);
            this.GrbAddElectrodevice.TabIndex = 5;
            this.GrbAddElectrodevice.TabStop = false;
            this.GrbAddElectrodevice.Text = " Данные животного: ";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(17, 166);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(105, 18);
            this.label1.TabIndex = 15;
            this.label1.Text = "Цвет (масть):";
            // 
            // TbxColor
            // 
            this.TbxColor.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TbxColor.Location = new System.Drawing.Point(160, 162);
            this.TbxColor.Name = "TbxColor";
            this.TbxColor.Size = new System.Drawing.Size(156, 26);
            this.TbxColor.TabIndex = 14;
            this.TbxColor.Text = "белый";
            this.TbxColor.TextChanged += new System.EventHandler(this.Tbx_TextChanged);
            this.TbxColor.Validating += new System.ComponentModel.CancelEventHandler(this.Txb_Validated);
            // 
            // LblOwner
            // 
            this.LblOwner.AutoSize = true;
            this.LblOwner.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblOwner.Location = new System.Drawing.Point(17, 205);
            this.LblOwner.Name = "LblOwner";
            this.LblOwner.Size = new System.Drawing.Size(187, 18);
            this.LblOwner.TabIndex = 13;
            this.LblOwner.Text = "Фамилия И.О. владельца:";
            // 
            // TbxOwner
            // 
            this.TbxOwner.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TbxOwner.Location = new System.Drawing.Point(20, 226);
            this.TbxOwner.Name = "TbxOwner";
            this.TbxOwner.Size = new System.Drawing.Size(296, 26);
            this.TbxOwner.TabIndex = 12;
            this.TbxOwner.Text = "Юдина Н.А.";
            this.TbxOwner.TextChanged += new System.EventHandler(this.Tbx_TextChanged);
            this.TbxOwner.Validated += new System.EventHandler(this.Txb_Validated);
            // 
            // LblType
            // 
            this.LblType.AutoSize = true;
            this.LblType.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblType.Location = new System.Drawing.Point(17, 35);
            this.LblType.Name = "LblType";
            this.LblType.Size = new System.Drawing.Size(117, 18);
            this.LblType.TabIndex = 11;
            this.LblType.Text = "Вид животного:";
            // 
            // CbxType
            // 
            this.CbxType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CbxType.FormattingEnabled = true;
            this.CbxType.Location = new System.Drawing.Point(160, 33);
            this.CbxType.Name = "CbxType";
            this.CbxType.Size = new System.Drawing.Size(156, 26);
            this.CbxType.TabIndex = 10;
            // 
            // BtnCancel
            // 
            this.BtnCancel.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.BtnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.BtnCancel.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.BtnCancel.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BtnCancel.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.BtnCancel.Location = new System.Drawing.Point(185, 275);
            this.BtnCancel.Name = "BtnCancel";
            this.BtnCancel.Size = new System.Drawing.Size(131, 39);
            this.BtnCancel.TabIndex = 9;
            this.BtnCancel.Text = "Отмена";
            this.BtnCancel.UseVisualStyleBackColor = false;
            this.BtnCancel.Click += new System.EventHandler(this.BtnCancel_Click);
            // 
            // BtnOk
            // 
            this.BtnOk.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.BtnOk.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.BtnOk.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.BtnOk.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BtnOk.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.BtnOk.Location = new System.Drawing.Point(20, 275);
            this.BtnOk.Name = "BtnOk";
            this.BtnOk.Size = new System.Drawing.Size(131, 39);
            this.BtnOk.TabIndex = 8;
            this.BtnOk.UseVisualStyleBackColor = false;
            this.BtnOk.Click += new System.EventHandler(this.BtnOk_Click);
            // 
            // LblAge
            // 
            this.LblAge.AutoSize = true;
            this.LblAge.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblAge.Location = new System.Drawing.Point(17, 102);
            this.LblAge.Name = "LblAge";
            this.LblAge.Size = new System.Drawing.Size(136, 18);
            this.LblAge.TabIndex = 5;
            this.LblAge.Text = "Возраст (в годах):";
            // 
            // LblWeight
            // 
            this.LblWeight.AutoSize = true;
            this.LblWeight.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblWeight.Location = new System.Drawing.Point(17, 134);
            this.LblWeight.Name = "LblWeight";
            this.LblWeight.Size = new System.Drawing.Size(80, 18);
            this.LblWeight.TabIndex = 4;
            this.LblWeight.Text = "Вес (в кг):";
            // 
            // LblPetName
            // 
            this.LblPetName.AutoSize = true;
            this.LblPetName.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblPetName.Location = new System.Drawing.Point(17, 69);
            this.LblPetName.Name = "LblPetName";
            this.LblPetName.Size = new System.Drawing.Size(61, 18);
            this.LblPetName.TabIndex = 3;
            this.LblPetName.Text = "Кличка:";
            // 
            // NudAge
            // 
            this.NudAge.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.NudAge.Location = new System.Drawing.Point(160, 98);
            this.NudAge.Maximum = new decimal(new int[] {
            1215752192,
            23,
            0,
            0});
            this.NudAge.Name = "NudAge";
            this.NudAge.Size = new System.Drawing.Size(156, 26);
            this.NudAge.TabIndex = 2;
            this.NudAge.ThousandsSeparator = true;
            this.NudAge.Value = new decimal(new int[] {
            5,
            0,
            0,
            0});
            // 
            // NudWeight
            // 
            this.NudWeight.DecimalPlaces = 3;
            this.NudWeight.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.NudWeight.Location = new System.Drawing.Point(160, 130);
            this.NudWeight.Maximum = new decimal(new int[] {
            1874919424,
            2328306,
            0,
            0});
            this.NudWeight.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            196608});
            this.NudWeight.Name = "NudWeight";
            this.NudWeight.Size = new System.Drawing.Size(156, 26);
            this.NudWeight.TabIndex = 1;
            this.NudWeight.ThousandsSeparator = true;
            this.NudWeight.Value = new decimal(new int[] {
            8,
            0,
            0,
            0});
            // 
            // TbxPetName
            // 
            this.TbxPetName.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TbxPetName.Location = new System.Drawing.Point(160, 65);
            this.TbxPetName.Name = "TbxPetName";
            this.TbxPetName.Size = new System.Drawing.Size(156, 26);
            this.TbxPetName.TabIndex = 0;
            this.TbxPetName.Text = "Пушок";
            this.TbxPetName.TextChanged += new System.EventHandler(this.Tbx_TextChanged);
            this.TbxPetName.Validated += new System.EventHandler(this.Txb_Validated);
            // 
            // ErpName
            // 
            this.ErpName.ContainerControl = this;
            // 
            // ErpPetName
            // 
            this.ErpPetName.ContainerControl = this;
            // 
            // ErpColor
            // 
            this.ErpColor.ContainerControl = this;
            // 
            // AnimalForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(369, 361);
            this.Controls.Add(this.GrbAddElectrodevice);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.Name = "AnimalForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "AnimalForm";
            this.GrbAddElectrodevice.ResumeLayout(false);
            this.GrbAddElectrodevice.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.NudAge)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NudWeight)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ErpName)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ErpPetName)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ErpColor)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox GrbAddElectrodevice;
        private System.Windows.Forms.Button BtnOk;
        private System.Windows.Forms.Label LblAge;
        private System.Windows.Forms.Label LblWeight;
        private System.Windows.Forms.Label LblPetName;
        private System.Windows.Forms.NumericUpDown NudAge;
        private System.Windows.Forms.NumericUpDown NudWeight;
        private System.Windows.Forms.TextBox TbxPetName;
        private System.Windows.Forms.Button BtnCancel;
        private System.Windows.Forms.ErrorProvider ErpName;
        private System.Windows.Forms.Label LblOwner;
        private System.Windows.Forms.TextBox TbxOwner;
        private System.Windows.Forms.Label LblType;
        private System.Windows.Forms.ComboBox CbxType;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox TbxColor;
        private System.Windows.Forms.ErrorProvider ErpPetName;
        private System.Windows.Forms.ErrorProvider ErpColor;
    }
}