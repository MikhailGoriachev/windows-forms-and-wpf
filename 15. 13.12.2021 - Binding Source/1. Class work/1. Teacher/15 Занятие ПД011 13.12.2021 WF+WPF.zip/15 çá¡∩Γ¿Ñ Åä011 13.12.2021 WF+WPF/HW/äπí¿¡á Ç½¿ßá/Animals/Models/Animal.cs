﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;
using System.Threading.Tasks;
using Animals.Helpers;
using System.Windows.Forms;

namespace Animals.Models
{
    // классом Animal:
    //          индекс иконки животного в коллекции
    //          вид животного
    //          кличка животного
    //          вес животного(в кг)
    //          возраст животного(в годах)
    //          цвет(масть) животного 
    //          фамилия и инициалы владельца

    [DataContract]
    public class Animal {

        // индекс иконки животного в коллекции
        private int _imageId;
        [DataMember]
        public int ImageId { 
            get => _imageId;
            set { if (value <  0)
                    throw new Exception("Неверный индекс иконки животного");

                _imageId = value;
            } // set
        } // ImageId

        // вид животного
        private string _type;
        [DataMember]
        public string Type {
            get => _type;
            set {
                if (string.IsNullOrEmpty(value))
                    throw new Exception("Пустая строка в виде животного");

                _type = value;
            } // set
        } // PetName


        // кличка животного
        private string _petName;
        [DataMember]
        public string PetName {
            get => _petName;
            set {
                if (string.IsNullOrEmpty(value))
                    throw new Exception("Пустая строка в кличке животного");

                _petName = value;
            } // set
        } // PetName

        // вес животного(в кг)
        private double _weight;
        [DataMember]
        public double Weight{
            get => _weight;
            set {
                if (value <= 0)
                    throw new Exception("Неверный вес животного");

                _weight = value;
            } // set 
        } // Weight

        // возраст животного(в годах)
        private int _age;
        [DataMember]
        public int Age {
            get => _age;
            set {
                if (value < 0)
                    throw new Exception("Неверный возраст животного");

                _age = value;
            } // set
        } // Age

        // цвет(масть) животного
        private string _color;
        [DataMember]
        public string Color {
            get => _color;
            set {
                if (string.IsNullOrEmpty(value))
                    throw new Exception("Пустая строка в цвете животного");

                _color = value;
            } // set
        } // Color

        // фамилия и инициалы владельца
        private string _owner;
        [DataMember]
        public string Owner {
            get => _owner;
            set {
                if (string.IsNullOrEmpty(value))
                    throw new Exception("Пустая строка в фамилии и инициалах владельца");

                _owner = value;
            } // set
        } // Owner

        // ансамбль конструкторов
        public Animal() : this(0, "попугай", "Кузя", 0.41, 15, "светло-зеленый", "Златопольский Д.М.") { } // Animal

        public Animal(int imageId, string type, string petName, double weight, int age, string color, string owner) {
            ImageId = imageId;
            Type = type;
            PetName = petName;
            Weight = weight;
            Age = age;
            Color = color;
            Owner = owner;
        } // Animal

        // формирование строки для ListView
        public ListViewItem ToListViewItem() {
            ListViewItem listViewItem = new ListViewItem("", _imageId);

            // добавить остальные столбцы
            listViewItem.SubItems.Add(_type);
            listViewItem.SubItems.Add(_petName);
            listViewItem.SubItems.Add($"{_weight:f3}    ");
            listViewItem.SubItems.Add($"{_age}     ");
            listViewItem.SubItems.Add(_color);
            listViewItem.SubItems.Add(_owner);

            return listViewItem;
        } // ToListViewItem

        // Фабричный метод для создания объекта из случайных данных
        public static Animal Generate() {
            int index = Utils.GetRandom(0, Utils.AnimalsData.Length - 1);
            return new Animal() {
                ImageId = Utils.AnimalsData[index].ImageId,
                Type = Utils.AnimalsData[index].type,
                PetName = Utils.PetNames[Utils.GetRandom(0, Utils.PetNames.Length - 1)],
                Weight = Utils.GetRandom(Utils.AnimalsData[index].minWeight, Utils.AnimalsData[index].maxWeight),
                Age = Utils.GetRandom(0, Utils.AnimalsData[index].maxAge),
                Color = Utils.AnimalsData[index].colors[Utils.GetRandom(0, Utils.AnimalsData[index].colors.Length - 1)],
                Owner = Utils.FullNames[Utils.GetRandom(0, Utils.FullNames.Length - 1)]
             };
        } // Generate

    } // Animal
}
