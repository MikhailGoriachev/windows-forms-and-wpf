﻿using Animals.Controllers;
using Animals.Helpers;
using Animals.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Animals.Views
{
    public partial class MainForm : Form
    {

        private AnimalsController _animalsController;

        public MainForm() : this(new AnimalsController()) { } // MainForm

        public MainForm(AnimalsController animalsController) {
            InitializeComponent();

            _animalsController = animalsController;

            // Если папки и/или файл нет, то создать папку
            if (!File.Exists(@"App_data\" + _animalsController.FileName)) { 
                Directory.CreateDirectory(@"App_Data");
                _animalsController.Serialization(_animalsController.FileName);
            } 
            else {
                _animalsController.Deserialization(@"App_Data\" + _animalsController.FileName);
                WriteToDataGridView(DgvAnimals, _animalsController.Animals);
            } // if


            // запись коллекции объектов в ListView для табличного отображения
            WriteToDataGridView(DgvAnimals, _animalsController.Animals);
            WriteToTreeView(TrvAnimals, _animalsController);
            StlMain.Text = $"Коллекция сформирована. Текущее количество записей: {_animalsController.Count}";
        } // MainForm


        private void Exit_Command(object sender, EventArgs e) => Application.Exit();

        private void About_Command(object sender, EventArgs e) {
            FormAbout formAbout = new FormAbout();
            formAbout.ShowDialog();
        } // About_Command

        // Сохранение данных 
        private void Save_Command(object sender, EventArgs e) =>
            _animalsController.Serialization(_animalsController.FileName);


        // Загрузка данных из выбранного файла
        private void Open_Command(object sender, EventArgs e) {
            OfdMain.Title = "Открыть файл";
            OfdMain.Filter = "Файлы JSON (*.json)|*.json";
            OfdMain.FilterIndex = 1;
            if (OfdMain.ShowDialog() == DialogResult.OK) {
                _animalsController.Deserialization(OfdMain.FileName);
                WriteToDataGridView(DgvAnimals, _animalsController.Animals);
                WriteToTreeView(TrvAnimals, _animalsController);
                MainForm_Load(sender, e);
            } // if
            _animalsController.FileName = OfdMain.FileName;
            MainForm_Load(sender, e);
        } // Open_Command


        // Сохранение данных в выбранном файле 
        private void SaveAs_Command(object sender, EventArgs e) {
            SfdMain.Title = "Сохранить файл как";
            SfdMain.InitialDirectory = Path.GetDirectoryName(_animalsController.FileName);
            SfdMain.Filter = "Файлы JSON (*.json)|*.json";
            //SfdMain.FilterIndex = 1;
            if (SfdMain.ShowDialog() == DialogResult.OK) {
                _animalsController.Serialization(SfdMain.FileName);
            } // if
            _animalsController.FileName = SfdMain.FileName;
            MainForm_Load(sender, e);
        } // SaveAs_Command
        
        // запись коллекции объектов в ListView для табличного отображения
        private void WriteToDataGridView(DataGridView dataGridView, List<Animal> animals) {

            dataGridView.Rows.Clear();

            int i = 0;
            foreach (var animal in animals) {
                dataGridView.RowCount++;

                dataGridView[0, i].Value = animal.Type;
                dataGridView[0, i].Style.Alignment = DataGridViewContentAlignment.MiddleLeft;

                dataGridView[1, i].Value = animal.PetName;
                dataGridView[1, i].Style.Alignment = DataGridViewContentAlignment.MiddleLeft;

                dataGridView[2, i].Value = $"{animal.Weight:f3}";
                dataGridView[2, i].Style.Alignment = DataGridViewContentAlignment.MiddleRight;

                dataGridView[3, i].Value = $"{animal.Age}";
                dataGridView[3, i].Style.Alignment = DataGridViewContentAlignment.MiddleRight;

                dataGridView[4, i].Value = animal.Color;
                dataGridView[4, i].Style.Alignment = DataGridViewContentAlignment.MiddleLeft;

                dataGridView[5, i].Value = animal.Owner;
                dataGridView[5, i].Style.Alignment = DataGridViewContentAlignment.MiddleLeft;

                dataGridView.Rows[i].Tag = animal;
                i++;
            } // foreach animal
        } // WriteToListView

        // запись коллекции объектов в TreeView
        private void WriteToTreeView(TreeView treeView, AnimalsController animalsController) {
            treeView.Nodes.Clear();

            treeView.Nodes.Add(animalsController.Name);

            int i = 0;
            foreach (var animal in animalsController.Animals){
                // добавление узла животного
                treeView.Nodes[0].Nodes.Add($"{animal.Type} {animal.PetName}").Tag = animal;
                // смена картинки
                treeView.Nodes[0].Nodes[i].ImageIndex =
                    treeView.Nodes[0].Nodes[i].SelectedImageIndex = animal.ImageId + 2;

                treeView.Nodes[0].Nodes[i].ContextMenuStrip = CmnAnimal;

                // добавление листа - имя владельца
                treeView.Nodes[0].Nodes[i].Nodes.Add(animal.Owner);
                // смена картинки
                treeView.Nodes[0].Nodes[i].Nodes[0].ImageIndex =
                    treeView.Nodes[0].Nodes[i].Nodes[0].SelectedImageIndex = 19;

                // добавление листа - вес животного
                treeView.Nodes[0].Nodes[i].Nodes.Add($"{animal.Weight:f3} кг");
                // смена картинки
                treeView.Nodes[0].Nodes[i].Nodes[1].ImageIndex =
                    treeView.Nodes[0].Nodes[i].Nodes[1].SelectedImageIndex = 18;
                i++;
            } // foreach animal
            TrvAnimals.Nodes[0].ExpandAll();
            for(int j = 0; j < TrvAnimals.Nodes[0].Nodes.Count; j++)
                TrvAnimals.Nodes[0].Nodes[j].Collapse();
            TrvAnimals.SelectedNode = TrvAnimals.Nodes[0];
        } // WriteToListView

        // Начальное формирование данных
        private void Generate_Command(object sender, EventArgs e) {
            _animalsController.Generate(Utils.GetRandom(20, 25));

            StlMain.Text = $"Коллекция сформирована. Текущее количество записей: {_animalsController.Count}";
            WriteToDataGridView(DgvAnimals, _animalsController.Animals);
            WriteToTreeView(TrvAnimals, _animalsController);

            // сериализация данных
            Save_Command(sender, e);
            MainForm_Load(sender, e);
            // делаем главную страницу текущей
            TbcMain.SelectedTab = TbpGeneral;
        } // Generate_Command


        // свернуть в трей
        private void ToTray_Command(object sender, EventArgs e) {
            this.Hide();
            NtiMain.Visible = true;
        } // ToTray_Command


        // восстановить из трея
        private void FromTray_Command(object sender, EventArgs e){
            this.Show();
            WindowState = FormWindowState.Normal;
            NtiMain.Visible = false;
        } // FromTray_Command


        // удаление данных о животном
        private void RemoveAt_Command(object sender, EventArgs e) {
            // если нет выбранных элементов - молча уходим
            if (DgvAnimals.SelectedRows.Count == 0 && TrvAnimals.SelectedNode?.Level != 1) return;

            if (SpcMain.ActiveControl == DgvAnimals) 
                RemoveFromDataGridView();
            else
                RemoveFromTree();

            WriteToDataGridView(DgvAnimals, _animalsController.Animals);
            WriteToTreeView(TrvAnimals, _animalsController);


            StlMain.Text = $"Запись удалена. Текущее количество записей: {_animalsController.Count}";

            // сериализация данных
            Save_Command(sender, e);
        } // RemoveAt_Command

        private void RemoveFromTree() =>
           _animalsController.Animals.Remove(TrvAnimals.SelectedNode.Tag as Animal);

        private void RemoveFromDataGridView() =>
            _animalsController.Animals.Remove(DgvAnimals.SelectedRows[0].Tag as Animal);

        // сортировка коллекции по возрасту
        private void OrderByAge_Command(object sender, EventArgs e) {
            WriteToDataGridView(DgvOrderedAnimals, _animalsController.OrderByAge());

            // делаем страницу отсортированных данных текущей
            TbcMain.SelectedTab = TbpOrdered;

            // формирование заголовка поля вывода данных
            LblHeaderOrdered.Text = "Коллекция животных упорядочена по возрасту:"; ;
        } // OrderByAge_Command


        // сортировка коллекции по виду 
        private void OrderByType_Command(object sender, EventArgs e) {
            WriteToDataGridView(DgvOrderedAnimals, _animalsController.OrderByType());

            // делаем страницу отсортированных данных текущей
            TbcMain.SelectedTab = TbpOrdered;

            // формирование заголовка поля вывода данных
            LblHeaderOrdered.Text = "Коллекция животных упорядочена по виду:"; ;
        } // OrderByType_Command


        // сортировка коллекции по фамилиям владельцев 
        private void OrderByOwner_Command(object sender, EventArgs e) {
            WriteToDataGridView(DgvOrderedAnimals, _animalsController.OrderByOwner());

            // делаем страницу отсортированных данных текущей
            TbcMain.SelectedTab = TbpOrdered;

            // формирование заголовка поля вывода данных
            LblHeaderOrdered.Text = "Коллекция животных упорядочена по фамилиям владельцев :"; ;
        } // OrderByOwner_Command


        // Выборка и вывод в отдельной вкладке коллекции животных с максимальным весом
        private void SelectWhereMaxWeight_Command(object sender, EventArgs e) {
            TbxOwner.Visible = LblOwner.Visible = false;

            LblHeaderSelected.Text = $"Выборка коллекции животных с максимальным весом\n\rМаксимальным вес: {_animalsController.MaxWeight():f3} кг";
            WriteToDataGridView(DgvSelectedAnimals, _animalsController.SelectAnimalsWhereMaxWeight());

            TbcMain.SelectedTab = TbpSelected; ;
        } // SelectByName_Command

        // Выборка и вывод в отдельной вкладке коллекции животных, фамилия владельцев
        // которых содержит заданную подстроку (подстроку вводить в этой же вкладке)
        private void SelectWhereOwner_Command(object sender, EventArgs e) {
            LblHeaderSelected.Text = $"Выборка коллекции животных, фамилия владельцев которых содержит заданную подстроку";
            WriteToDataGridView(DgvSelectedAnimals, _animalsController.SelectAnimalsWhereOwner(""));
            TbxOwner.Visible = LblOwner.Visible = true;
            TbxOwner.Text = "";
            TbcMain.SelectedTab = TbpSelected; ;
        } // SelectByState_Command


        private void TbxOwner_TextChanged(object sender, EventArgs e) {
            WriteToDataGridView(DgvSelectedAnimals, _animalsController.SelectAnimalsWhereOwner(TbxOwner.Text));
        } // TbxOwner_TextChanged

        // Разрешаем работу кнопок правки данных только на главной вкладке формы  
        private void TbcMain_SelectedIndexChanged(object sender, EventArgs e) {
            TsbAddAppliance.Enabled = TsbEditAppliance.Enabled =
                TsbRemoveAppliance.Enabled  = 
                MniAnimals.Enabled =
                TbcMain.SelectedTab == TbpGeneral;
        } // TbcMain_SelectedIndexChanged

        // Добавление записи в коллекцию 
        private void AddAnimal_Command(object sender, EventArgs e) {
            AnimalForm animalForm = new AnimalForm();

            // если окно закрыто не по кнопке BtnOk - молча уходим
            if (animalForm.ShowDialog() != DialogResult.OK) return;

            // получить данные из свойства формы
            _animalsController.AddAnimal(animalForm.Animal);

            WriteToDataGridView(DgvAnimals, _animalsController.Animals);
            WriteToTreeView(TrvAnimals, _animalsController);

            StlMain.Text = $"Запись добавлена. Текущее количество: {_animalsController.Count}";
            MainForm_Load(sender, e);
            // сериализация данных
            Save_Command(sender, e);
        } // AddAppliance_Command

        // Редактирование выбранного электроприбора
        private void EditAnimal_Command(object sender, EventArgs e) {
            // если нет выбранных элементов - молча уходим
            if (DgvAnimals.SelectedRows?.Count == 0 && TrvAnimals.SelectedNode?.Level != 1) return;


            Animal temp = SpcMain.ActiveControl == TrvAnimals ? 
                TrvAnimals.SelectedNode.Tag as Animal : DgvAnimals.SelectedRows[0].Tag as Animal;


            AnimalForm animalForm = new AnimalForm("Редактирование данных о животном", "Сохранить");

            animalForm.Animal = temp;
            // если окно закрыто не по кнопке BtnOk - молча уходим
            if (animalForm.ShowDialog() != DialogResult.OK) return;

            
            // получить данные из свойства формы
            temp = animalForm.Animal;

            WriteToDataGridView(DgvAnimals, _animalsController.Animals);
            WriteToTreeView(TrvAnimals, _animalsController);

            StlMain.Text = $"Данные о животном изменены. Текущее количество записей: {_animalsController.Count}";
            
            MainForm_Load(sender, e);
            // сериализация данных
            Save_Command(sender, e);
        } // AddAppliance_Command


        private void LsvAnimals_DragDrop(object sender, DragEventArgs e) {
            string[] fileNames = (string[])e.Data.GetData(DataFormats.FileDrop);
            _animalsController.Deserialization(fileNames[0]);
            WriteToDataGridView(DgvAnimals, _animalsController.Animals);
            WriteToTreeView(TrvAnimals, _animalsController);
            MainForm_Load(sender, e);
            } // LsvAppliances_DragDrop

        private void LsvAnimals_DragEnter(object sender, DragEventArgs e)  {
            e.Effect = DragDropEffects.Copy;
        } // LsvAppliances_DragEnter

        private void TbcMain_KeyDown(object sender, KeyEventArgs e) {
            if (e.KeyData != Keys.Delete || TbcMain.SelectedTab != TbpGeneral) return;

            RemoveAt_Command(sender, EventArgs.Empty);
        } // TbcMain_KeyDown

        private void MainForm_Load(object sender, EventArgs e) {
            TbcMain.SelectedTab = TbpGeneral;
            StlFilePath.Text = Path.GetFileName(_animalsController.FileName);
        } // MainForm_Load

        // коррекция поведения TreeView - при отпускании любой кнопки мыши
        // сделать узел, на котором был клик, текущим 
        private void CorrectBehavor_MouseUp(object sender, MouseEventArgs e) {
            // закомментировано для исключения конфликтов с NodeMouseClick
            TrvAnimals.SelectedNode = TrvAnimals.GetNodeAt(e.Location);
        } // CorrectBehavor_MouseUp
    }
}
