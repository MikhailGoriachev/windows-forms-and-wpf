﻿using Appliances.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Appliances.Views
{
    public partial class ApplianceForm : Form
    {
        private Appliance _appliance;
        public Appliance Appliance {
            get => _appliance;
            set {
                _appliance = value;

                // запись в элементы управления
                TbxName.Text = _appliance.Name;
                NudPrice.Value = _appliance.Price;
                NudPower.Value = _appliance.Power;
                RbtON.Checked = _appliance.State;

                // если не совпадает с имеющимися вариантами - добавить
                if (CbxRoom.Items.IndexOf(_appliance.Room) < 0)
                    CbxRoom.Items.Add(_appliance.Room);

                CbxRoom.Text = _appliance.Room;

                TbxName.Tag = ErpName;
            } // set
        } // Appliance

        public ApplianceForm() : this("Добавление электроприбора", "Добавить", new List<string>()) { }
        public ApplianceForm(string title, string btnText, List<string> rooms) {
            InitializeComponent();
            CbxRoom.DataSource = rooms;
            RbtON.Checked = true;
            _appliance = new Appliance();
            Text = title;
            BtnOk.Text = btnText;
        } // ApplianceForm

        private void BtnOk_Click(object sender, EventArgs e) {
            _appliance.State = RbtON.Checked;
            _appliance.Name = TbxName.Text;
            _appliance.Price = (int)NudPrice.Value;
            _appliance.Power = (int)NudPower.Value;
            _appliance.Room = CbxRoom.Text;
        } // BtnOk_Click

        private void BtnCancel_Click(object sender, EventArgs e) => Close();

        private void Txb_Validated(object sender, EventArgs e) {
            TextBox tb = sender as TextBox;
            if (String.IsNullOrEmpty(tb.Text)) {
                ErpName.SetError(tb, "Некорректный ввод!");
                BtnOk.Enabled = false;
            } // if
        } // Txb_Validated

        private void Tbx_TextChanged(object sender, EventArgs e) {
            TextBox tb = sender as TextBox;
            ErpName.SetError(tb, "");

            if(!String.IsNullOrEmpty(TbxName.Text))
                BtnOk.Enabled = true;
        } // Tbx_TextChanged

        private void Cxb_Validated(object sender, EventArgs e) {
            ComboBox cb = sender as ComboBox;
            if (String.IsNullOrEmpty(cb.Text)) {
                ErpRoom.SetError(cb, "Некорректный ввод!");
                BtnOk.Enabled = false;
            } // if
        } // Txb_Validated

        private void Cbx_TextChanged(object sender, EventArgs e) {
            ComboBox cb = sender as ComboBox;
            ErpRoom.SetError(cb, "");

            if(!String.IsNullOrEmpty(CbxRoom.Text))
                BtnOk.Enabled = true;
        } // Tbx_TextChanged
    }
}
