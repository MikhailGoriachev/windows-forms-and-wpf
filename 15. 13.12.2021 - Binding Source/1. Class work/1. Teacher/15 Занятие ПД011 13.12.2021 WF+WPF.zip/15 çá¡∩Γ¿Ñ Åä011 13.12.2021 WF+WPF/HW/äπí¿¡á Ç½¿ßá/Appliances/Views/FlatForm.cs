﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Appliances.Views
{

    public partial class FlatForm : Form {
        private string _address;
        public string Address {
            get => _address;
            set{
                _address = value;

                // запись в элементы управления
                TbxAddress.Text = _address;
            } // set
        } // Address

        private string _name;
        public string Name {
            get => _name;
            set{
                _name = value;

                // запись в элементы управления
                TbxName.Text = _name;
            } // set
        } // Name

        public FlatForm(string address, string name) {
            InitializeComponent();
            TbxAddress.Tag = ErpAddress;
            TbxName.Tag = ErpName;
            
            TbxAddress.Text = address;
            TbxName.Text = name;
        } // RepairShopForm

        private void Tbx_Validated(object sender, EventArgs e){
            TextBox tb = sender as TextBox;
            ErrorProvider erp = tb.Tag as ErrorProvider;
            if (String.IsNullOrEmpty(tb.Text))
            {
                erp.SetError(tb, "Некорректный ввод!");
                BtnOk.Enabled = false;
            }
        } // Tbx_Validated

        private void Tbx_TextChanged(object sender, EventArgs e) {
            TextBox tb = sender as TextBox;
            ErrorProvider erp = tb.Tag as ErrorProvider;
            erp?.SetError(tb, "");

            if(!String.IsNullOrEmpty(TbxAddress.Text))
                BtnOk.Enabled = true;
        } // Tbx_TextChanged

        private void BtnOk_Click(object sender, EventArgs e) {
            _address = TbxAddress.Text;
            _name = TbxName.Text;
        } // BtnOk_Click
    }
}
