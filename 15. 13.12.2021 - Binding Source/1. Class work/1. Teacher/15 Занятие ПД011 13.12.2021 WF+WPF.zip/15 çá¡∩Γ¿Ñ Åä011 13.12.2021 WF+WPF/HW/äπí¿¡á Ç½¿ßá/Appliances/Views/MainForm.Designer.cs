﻿
namespace Appliances.Views
{
    partial class MainForm
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.ImlAppliances = new System.Windows.Forms.ImageList(this.components);
            this.TbsMain = new System.Windows.Forms.ToolStrip();
            this.TsbFileOpen = new System.Windows.Forms.ToolStripButton();
            this.TsbFileSave = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.TsbNewFlat = new System.Windows.Forms.ToolStripButton();
            this.TsbEditFlat = new System.Windows.Forms.ToolStripButton();
            this.TsbSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.TsbAddAppliance = new System.Windows.Forms.ToolStripButton();
            this.TsbEditAppliance = new System.Windows.Forms.ToolStripButton();
            this.TsbRemoveAppliance = new System.Windows.Forms.ToolStripButton();
            this.TsbSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.TsdOrderBy = new System.Windows.Forms.ToolStripDropDownButton();
            this.DmiOrderByName = new System.Windows.Forms.ToolStripMenuItem();
            this.DmiOrderByState = new System.Windows.Forms.ToolStripMenuItem();
            this.DmiOrderByPower = new System.Windows.Forms.ToolStripMenuItem();
            this.DmiOrderByPriceDesc = new System.Windows.Forms.ToolStripMenuItem();
            this.TsbSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.TsbExit = new System.Windows.Forms.ToolStripButton();
            this.TsbAbout = new System.Windows.Forms.ToolStripButton();
            this.TsbToTray = new System.Windows.Forms.ToolStripButton();
            this.TsdSelectWhere = new System.Windows.Forms.ToolStripDropDownButton();
            this.TsdSelectWhereName = new System.Windows.Forms.ToolStripMenuItem();
            this.TsdSelectWhereState = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.TsbTurnOnOff = new System.Windows.Forms.ToolStripButton();
            this.TsbTurnOn = new System.Windows.Forms.ToolStripButton();
            this.TsbTurnOff = new System.Windows.Forms.ToolStripButton();
            this.MnsMain = new System.Windows.Forms.MenuStrip();
            this.MniFile = new System.Windows.Forms.ToolStripMenuItem();
            this.MniFileOpen = new System.Windows.Forms.ToolStripMenuItem();
            this.MniFileSave = new System.Windows.Forms.ToolStripMenuItem();
            this.MniFileSaveAs = new System.Windows.Forms.ToolStripMenuItem();
            this.MniFileSep1 = new System.Windows.Forms.ToolStripSeparator();
            this.MniFileExit = new System.Windows.Forms.ToolStripMenuItem();
            this.MniFlat = new System.Windows.Forms.ToolStripMenuItem();
            this.MniFlatNew = new System.Windows.Forms.ToolStripMenuItem();
            this.MniFlatEdit = new System.Windows.Forms.ToolStripMenuItem();
            this.MniAppliances = new System.Windows.Forms.ToolStripMenuItem();
            this.MniAppliancesAdd = new System.Windows.Forms.ToolStripMenuItem();
            this.MniAppliancesEdit = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripSeparator();
            this.MniTurnOnOff = new System.Windows.Forms.ToolStripMenuItem();
            this.MniTurnOff = new System.Windows.Forms.ToolStripMenuItem();
            this.MniTurnOn = new System.Windows.Forms.ToolStripMenuItem();
            this.MniTelevisionsSep1 = new System.Windows.Forms.ToolStripSeparator();
            this.MniAppliancesRemoveAt = new System.Windows.Forms.ToolStripMenuItem();
            this.MniOrderBy = new System.Windows.Forms.ToolStripMenuItem();
            this.MniOrderByName = new System.Windows.Forms.ToolStripMenuItem();
            this.MniOrderByState = new System.Windows.Forms.ToolStripMenuItem();
            this.MniOrderByPower = new System.Windows.Forms.ToolStripMenuItem();
            this.MniOrderByPriceDesc = new System.Windows.Forms.ToolStripMenuItem();
            this.MniSelectWhere = new System.Windows.Forms.ToolStripMenuItem();
            this.MniSelectWhereName = new System.Windows.Forms.ToolStripMenuItem();
            this.MniSelectWhereState = new System.Windows.Forms.ToolStripMenuItem();
            this.MniHelp = new System.Windows.Forms.ToolStripMenuItem();
            this.MniHelpAbout = new System.Windows.Forms.ToolStripMenuItem();
            this.StsMain = new System.Windows.Forms.StatusStrip();
            this.StlMain = new System.Windows.Forms.ToolStripStatusLabel();
            this.OfdMain = new System.Windows.Forms.OpenFileDialog();
            this.LblAddress = new System.Windows.Forms.Label();
            this.CmnMain = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.toolStripMenuItem9 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem8 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem5 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem10 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripMenuItem11 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem12 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripMenuItem21 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem22 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem23 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem24 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem25 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem26 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem27 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem28 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem20 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripMenuItem6 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem7 = new System.Windows.Forms.ToolStripMenuItem();
            this.SfdMain = new System.Windows.Forms.SaveFileDialog();
            this.NtiMain = new System.Windows.Forms.NotifyIcon(this.components);
            this.CmnTray = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem4 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.вToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.TbcMain = new System.Windows.Forms.TabControl();
            this.TbpGeneral = new System.Windows.Forms.TabPage();
            this.SpcMain = new System.Windows.Forms.SplitContainer();
            this.TrvAppliances = new System.Windows.Forms.TreeView();
            this.ImlMain = new System.Windows.Forms.ImageList(this.components);
            this.DgvAppliances = new System.Windows.Forms.DataGridView();
            this.ClnName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ClnRoom = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ClnPower = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ClnPrice = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ClnState = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CmnAppliances = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.toolStripMenuItem31 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem32 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator7 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripMenuItem34 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem35 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator8 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripMenuItem36 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem37 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem38 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator9 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripMenuItem39 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem13 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripMenuItem40 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem41 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem42 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem43 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem44 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem45 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem46 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem47 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator10 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripMenuItem48 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem49 = new System.Windows.Forms.ToolStripMenuItem();
            this.TbpOrdered = new System.Windows.Forms.TabPage();
            this.DgvOrderedAppliances = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.LblHeaderOrdered = new System.Windows.Forms.Label();
            this.TbpSelected = new System.Windows.Forms.TabPage();
            this.DgvSelectedAppliances = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.LblHeaderSelected = new System.Windows.Forms.Label();
            this.CmnTree = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.toolStripMenuItem50 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem51 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem29 = new System.Windows.Forms.ToolStripSeparator();
            this.TurnOffInRoom = new System.Windows.Forms.ToolStripMenuItem();
            this.TurnOnInRoom = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator11 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripMenuItem67 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem68 = new System.Windows.Forms.ToolStripMenuItem();
            this.CmnTreeAppliance = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.toolStripMenuItem30 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator6 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripMenuItem53 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem57 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator12 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripMenuItem54 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator14 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripMenuItem66 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem69 = new System.Windows.Forms.ToolStripMenuItem();
            this.TbsMain.SuspendLayout();
            this.MnsMain.SuspendLayout();
            this.StsMain.SuspendLayout();
            this.CmnMain.SuspendLayout();
            this.CmnTray.SuspendLayout();
            this.TbcMain.SuspendLayout();
            this.TbpGeneral.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.SpcMain)).BeginInit();
            this.SpcMain.Panel1.SuspendLayout();
            this.SpcMain.Panel2.SuspendLayout();
            this.SpcMain.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DgvAppliances)).BeginInit();
            this.CmnAppliances.SuspendLayout();
            this.TbpOrdered.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DgvOrderedAppliances)).BeginInit();
            this.TbpSelected.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DgvSelectedAppliances)).BeginInit();
            this.CmnTree.SuspendLayout();
            this.CmnTreeAppliance.SuspendLayout();
            this.SuspendLayout();
            // 
            // ImlAppliances
            // 
            this.ImlAppliances.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("ImlAppliances.ImageStream")));
            this.ImlAppliances.TransparentColor = System.Drawing.Color.Transparent;
            this.ImlAppliances.Images.SetKeyName(0, "StateOff.png");
            this.ImlAppliances.Images.SetKeyName(1, "StateOn.png");
            // 
            // TbsMain
            // 
            this.TbsMain.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TbsMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.TsbFileOpen,
            this.TsbFileSave,
            this.toolStripSeparator1,
            this.TsbNewFlat,
            this.TsbEditFlat,
            this.TsbSeparator1,
            this.TsbAddAppliance,
            this.TsbEditAppliance,
            this.TsbRemoveAppliance,
            this.TsbSeparator2,
            this.TsdOrderBy,
            this.TsbSeparator3,
            this.TsbExit,
            this.TsbAbout,
            this.TsbToTray,
            this.TsdSelectWhere,
            this.toolStripSeparator2,
            this.TsbTurnOnOff,
            this.TsbTurnOn,
            this.TsbTurnOff});
            this.TbsMain.Location = new System.Drawing.Point(0, 29);
            this.TbsMain.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.TbsMain.Name = "TbsMain";
            this.TbsMain.Size = new System.Drawing.Size(987, 39);
            this.TbsMain.TabIndex = 8;
            this.TbsMain.Text = "toolStrip1";
            // 
            // TsbFileOpen
            // 
            this.TsbFileOpen.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbFileOpen.Image = global::Appliances.Properties.Resources.folder_blue;
            this.TsbFileOpen.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbFileOpen.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbFileOpen.Name = "TsbFileOpen";
            this.TsbFileOpen.Size = new System.Drawing.Size(36, 36);
            this.TsbFileOpen.ToolTipText = "Открыть файл данных\r\n";
            this.TsbFileOpen.Click += new System.EventHandler(this.Open_Command);
            // 
            // TsbFileSave
            // 
            this.TsbFileSave.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbFileSave.Image = global::Appliances.Properties.Resources.save_as;
            this.TsbFileSave.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbFileSave.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbFileSave.Name = "TsbFileSave";
            this.TsbFileSave.Size = new System.Drawing.Size(36, 36);
            this.TsbFileSave.ToolTipText = "Сохранить файл данных ";
            this.TsbFileSave.Click += new System.EventHandler(this.SaveAs_Command);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 39);
            // 
            // TsbNewFlat
            // 
            this.TsbNewFlat.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbNewFlat.Image = global::Appliances.Properties.Resources.Create;
            this.TsbNewFlat.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbNewFlat.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbNewFlat.Name = "TsbNewFlat";
            this.TsbNewFlat.Size = new System.Drawing.Size(34, 36);
            this.TsbNewFlat.ToolTipText = "Создание новых сведений о квартире";
            this.TsbNewFlat.Click += new System.EventHandler(this.Generate_Command);
            // 
            // TsbEditFlat
            // 
            this.TsbEditFlat.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbEditFlat.Image = global::Appliances.Properties.Resources.EditFlat;
            this.TsbEditFlat.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbEditFlat.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbEditFlat.Name = "TsbEditFlat";
            this.TsbEditFlat.Size = new System.Drawing.Size(34, 36);
            this.TsbEditFlat.ToolTipText = "Редактирование сведений о квартире";
            this.TsbEditFlat.Click += new System.EventHandler(this.EditFlat_Command);
            // 
            // TsbSeparator1
            // 
            this.TsbSeparator1.Name = "TsbSeparator1";
            this.TsbSeparator1.Size = new System.Drawing.Size(6, 39);
            // 
            // TsbAddAppliance
            // 
            this.TsbAddAppliance.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbAddAppliance.Image = global::Appliances.Properties.Resources.Add;
            this.TsbAddAppliance.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbAddAppliance.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbAddAppliance.Name = "TsbAddAppliance";
            this.TsbAddAppliance.Size = new System.Drawing.Size(34, 36);
            this.TsbAddAppliance.ToolTipText = "Добавить электроприбор\r\n";
            this.TsbAddAppliance.Click += new System.EventHandler(this.AddAppliance_Command);
            // 
            // TsbEditAppliance
            // 
            this.TsbEditAppliance.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbEditAppliance.Image = global::Appliances.Properties.Resources.edit;
            this.TsbEditAppliance.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbEditAppliance.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbEditAppliance.Name = "TsbEditAppliance";
            this.TsbEditAppliance.Size = new System.Drawing.Size(34, 36);
            this.TsbEditAppliance.ToolTipText = "Редактирование данных электроприбора\r\n";
            this.TsbEditAppliance.Click += new System.EventHandler(this.EditAppliance_Command);
            // 
            // TsbRemoveAppliance
            // 
            this.TsbRemoveAppliance.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbRemoveAppliance.Image = global::Appliances.Properties.Resources.remove;
            this.TsbRemoveAppliance.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbRemoveAppliance.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbRemoveAppliance.Name = "TsbRemoveAppliance";
            this.TsbRemoveAppliance.Size = new System.Drawing.Size(34, 36);
            this.TsbRemoveAppliance.ToolTipText = "Удалить электроприбор";
            this.TsbRemoveAppliance.Click += new System.EventHandler(this.RemoveAt_Command);
            // 
            // TsbSeparator2
            // 
            this.TsbSeparator2.Name = "TsbSeparator2";
            this.TsbSeparator2.Size = new System.Drawing.Size(6, 39);
            // 
            // TsdOrderBy
            // 
            this.TsdOrderBy.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsdOrderBy.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.DmiOrderByName,
            this.DmiOrderByState,
            this.DmiOrderByPower,
            this.DmiOrderByPriceDesc});
            this.TsdOrderBy.Image = global::Appliances.Properties.Resources.OrderBy;
            this.TsdOrderBy.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsdOrderBy.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsdOrderBy.Name = "TsdOrderBy";
            this.TsdOrderBy.Size = new System.Drawing.Size(43, 36);
            this.TsdOrderBy.Text = "Сортировка";
            this.TsdOrderBy.ToolTipText = "Сортировка коллекции\r\n";
            // 
            // DmiOrderByName
            // 
            this.DmiOrderByName.Image = global::Appliances.Properties.Resources.name;
            this.DmiOrderByName.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.DmiOrderByName.Name = "DmiOrderByName";
            this.DmiOrderByName.Size = new System.Drawing.Size(235, 36);
            this.DmiOrderByName.Text = "По названию";
            this.DmiOrderByName.Click += new System.EventHandler(this.OrderByName_Command);
            // 
            // DmiOrderByState
            // 
            this.DmiOrderByState.Image = global::Appliances.Properties.Resources.StateOn;
            this.DmiOrderByState.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.DmiOrderByState.Name = "DmiOrderByState";
            this.DmiOrderByState.Size = new System.Drawing.Size(235, 36);
            this.DmiOrderByState.Text = "По состоянию";
            this.DmiOrderByState.Click += new System.EventHandler(this.OrderByState_Command);
            // 
            // DmiOrderByPower
            // 
            this.DmiOrderByPower.Image = global::Appliances.Properties.Resources.power;
            this.DmiOrderByPower.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.DmiOrderByPower.Name = "DmiOrderByPower";
            this.DmiOrderByPower.Size = new System.Drawing.Size(235, 36);
            this.DmiOrderByPower.Text = "По мощности";
            this.DmiOrderByPower.Click += new System.EventHandler(this.OrderByPower_Command);
            // 
            // DmiOrderByPriceDesc
            // 
            this.DmiOrderByPriceDesc.Image = global::Appliances.Properties.Resources.Cost;
            this.DmiOrderByPriceDesc.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.DmiOrderByPriceDesc.Name = "DmiOrderByPriceDesc";
            this.DmiOrderByPriceDesc.Size = new System.Drawing.Size(235, 36);
            this.DmiOrderByPriceDesc.Text = "По убыванию цены";
            this.DmiOrderByPriceDesc.Click += new System.EventHandler(this.OrderByPriceDesc_Command);
            // 
            // TsbSeparator3
            // 
            this.TsbSeparator3.Name = "TsbSeparator3";
            this.TsbSeparator3.Size = new System.Drawing.Size(6, 39);
            // 
            // TsbExit
            // 
            this.TsbExit.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.TsbExit.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbExit.Image = global::Appliances.Properties.Resources.exit;
            this.TsbExit.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbExit.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbExit.Name = "TsbExit";
            this.TsbExit.Size = new System.Drawing.Size(34, 36);
            this.TsbExit.ToolTipText = "Выход из приложения";
            this.TsbExit.Click += new System.EventHandler(this.Exit_Command);
            // 
            // TsbAbout
            // 
            this.TsbAbout.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.TsbAbout.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbAbout.Image = global::Appliances.Properties.Resources.help;
            this.TsbAbout.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbAbout.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbAbout.Name = "TsbAbout";
            this.TsbAbout.Size = new System.Drawing.Size(36, 36);
            this.TsbAbout.ToolTipText = "Сведения о программе";
            this.TsbAbout.Click += new System.EventHandler(this.About_Command);
            // 
            // TsbToTray
            // 
            this.TsbToTray.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.TsbToTray.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbToTray.Image = global::Appliances.Properties.Resources.ToTray;
            this.TsbToTray.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbToTray.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbToTray.Name = "TsbToTray";
            this.TsbToTray.Size = new System.Drawing.Size(34, 36);
            this.TsbToTray.Text = "Свернуть в трей";
            this.TsbToTray.ToolTipText = "Свернуть в трей";
            this.TsbToTray.Click += new System.EventHandler(this.ToTray_Command);
            // 
            // TsdSelectWhere
            // 
            this.TsdSelectWhere.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsdSelectWhere.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.TsdSelectWhereName,
            this.TsdSelectWhereState});
            this.TsdSelectWhere.Image = global::Appliances.Properties.Resources.Select;
            this.TsdSelectWhere.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsdSelectWhere.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsdSelectWhere.Name = "TsdSelectWhere";
            this.TsdSelectWhere.Size = new System.Drawing.Size(43, 36);
            this.TsdSelectWhere.Text = "Выборка";
            this.TsdSelectWhere.ToolTipText = "Выборка из коллекции";
            // 
            // TsdSelectWhereName
            // 
            this.TsdSelectWhereName.Image = global::Appliances.Properties.Resources.name;
            this.TsdSelectWhereName.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsdSelectWhereName.Name = "TsdSelectWhereName";
            this.TsdSelectWhereName.Size = new System.Drawing.Size(268, 36);
            this.TsdSelectWhereName.Text = "С заданным названием";
            this.TsdSelectWhereName.Click += new System.EventHandler(this.SelectByName_Command);
            // 
            // TsdSelectWhereState
            // 
            this.TsdSelectWhereState.Image = global::Appliances.Properties.Resources.StateOn;
            this.TsdSelectWhereState.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsdSelectWhereState.Name = "TsdSelectWhereState";
            this.TsdSelectWhereState.Size = new System.Drawing.Size(268, 36);
            this.TsdSelectWhereState.Text = "С заданным состоянием";
            this.TsdSelectWhereState.Click += new System.EventHandler(this.SelectByState_Command);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 39);
            // 
            // TsbTurnOnOff
            // 
            this.TsbTurnOnOff.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbTurnOnOff.Image = global::Appliances.Properties.Resources.TurnOnOff;
            this.TsbTurnOnOff.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbTurnOnOff.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbTurnOnOff.Name = "TsbTurnOnOff";
            this.TsbTurnOnOff.Size = new System.Drawing.Size(34, 36);
            this.TsbTurnOnOff.Text = "toolStripButton1";
            this.TsbTurnOnOff.ToolTipText = "Включение/выключение \r\nвыбранного электроприбора";
            this.TsbTurnOnOff.Click += new System.EventHandler(this.TurnOnOff_Command);
            // 
            // TsbTurnOn
            // 
            this.TsbTurnOn.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbTurnOn.Image = global::Appliances.Properties.Resources.TurnON;
            this.TsbTurnOn.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbTurnOn.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbTurnOn.Name = "TsbTurnOn";
            this.TsbTurnOn.Size = new System.Drawing.Size(34, 36);
            this.TsbTurnOn.Text = "toolStripButton1";
            this.TsbTurnOn.ToolTipText = "Включение всех электроприборов квартиры";
            this.TsbTurnOn.Click += new System.EventHandler(this.TurnOn_Command);
            // 
            // TsbTurnOff
            // 
            this.TsbTurnOff.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbTurnOff.Image = global::Appliances.Properties.Resources.TurnOFF;
            this.TsbTurnOff.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbTurnOff.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbTurnOff.Name = "TsbTurnOff";
            this.TsbTurnOff.Size = new System.Drawing.Size(34, 36);
            this.TsbTurnOff.Text = "toolStripButton1";
            this.TsbTurnOff.ToolTipText = "Вsключение всех электроприборов квартиры";
            this.TsbTurnOff.Click += new System.EventHandler(this.TurnOff_Command);
            // 
            // MnsMain
            // 
            this.MnsMain.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.MnsMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniFile,
            this.MniFlat,
            this.MniAppliances,
            this.MniOrderBy,
            this.MniSelectWhere,
            this.MniHelp});
            this.MnsMain.Location = new System.Drawing.Point(0, 0);
            this.MnsMain.Name = "MnsMain";
            this.MnsMain.Size = new System.Drawing.Size(987, 29);
            this.MnsMain.TabIndex = 7;
            this.MnsMain.Text = "menuStrip1";
            // 
            // MniFile
            // 
            this.MniFile.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniFileOpen,
            this.MniFileSave,
            this.MniFileSaveAs,
            this.MniFileSep1,
            this.MniFileExit});
            this.MniFile.Name = "MniFile";
            this.MniFile.Size = new System.Drawing.Size(59, 25);
            this.MniFile.Text = "Файл";
            // 
            // MniFileOpen
            // 
            this.MniFileOpen.Image = global::Appliances.Properties.Resources.folder_blue;
            this.MniFileOpen.Name = "MniFileOpen";
            this.MniFileOpen.Size = new System.Drawing.Size(193, 26);
            this.MniFileOpen.Text = "Открыть...";
            this.MniFileOpen.Click += new System.EventHandler(this.Open_Command);
            // 
            // MniFileSave
            // 
            this.MniFileSave.Name = "MniFileSave";
            this.MniFileSave.Size = new System.Drawing.Size(193, 26);
            this.MniFileSave.Text = "Сохранить";
            this.MniFileSave.Click += new System.EventHandler(this.Save_Command);
            // 
            // MniFileSaveAs
            // 
            this.MniFileSaveAs.Image = global::Appliances.Properties.Resources.save_as;
            this.MniFileSaveAs.Name = "MniFileSaveAs";
            this.MniFileSaveAs.Size = new System.Drawing.Size(193, 26);
            this.MniFileSaveAs.Text = "Сохранить как...";
            this.MniFileSaveAs.Click += new System.EventHandler(this.SaveAs_Command);
            // 
            // MniFileSep1
            // 
            this.MniFileSep1.Name = "MniFileSep1";
            this.MniFileSep1.Size = new System.Drawing.Size(190, 6);
            // 
            // MniFileExit
            // 
            this.MniFileExit.Image = global::Appliances.Properties.Resources.exit;
            this.MniFileExit.Name = "MniFileExit";
            this.MniFileExit.Size = new System.Drawing.Size(193, 26);
            this.MniFileExit.Text = "Выход";
            this.MniFileExit.Click += new System.EventHandler(this.Exit_Command);
            // 
            // MniFlat
            // 
            this.MniFlat.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniFlatNew,
            this.MniFlatEdit});
            this.MniFlat.Name = "MniFlat";
            this.MniFlat.Size = new System.Drawing.Size(174, 25);
            this.MniFlat.Text = "Сведения о квартире";
            // 
            // MniFlatNew
            // 
            this.MniFlatNew.Image = global::Appliances.Properties.Resources.Create;
            this.MniFlatNew.Name = "MniFlatNew";
            this.MniFlatNew.Size = new System.Drawing.Size(160, 26);
            this.MniFlatNew.Text = "Новая";
            this.MniFlatNew.Click += new System.EventHandler(this.Generate_Command);
            // 
            // MniFlatEdit
            // 
            this.MniFlatEdit.Image = global::Appliances.Properties.Resources.EditFlat;
            this.MniFlatEdit.Name = "MniFlatEdit";
            this.MniFlatEdit.Size = new System.Drawing.Size(160, 26);
            this.MniFlatEdit.Text = "Изменить...";
            this.MniFlatEdit.Click += new System.EventHandler(this.EditFlat_Command);
            // 
            // MniAppliances
            // 
            this.MniAppliances.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniAppliancesAdd,
            this.MniAppliancesEdit,
            this.toolStripMenuItem1,
            this.MniTurnOnOff,
            this.MniTurnOff,
            this.MniTurnOn,
            this.MniTelevisionsSep1,
            this.MniAppliancesRemoveAt});
            this.MniAppliances.Name = "MniAppliances";
            this.MniAppliances.Size = new System.Drawing.Size(146, 25);
            this.MniAppliances.Text = "Электроприборы";
            // 
            // MniAppliancesAdd
            // 
            this.MniAppliancesAdd.Image = global::Appliances.Properties.Resources.Add;
            this.MniAppliancesAdd.Name = "MniAppliancesAdd";
            this.MniAppliancesAdd.Size = new System.Drawing.Size(238, 26);
            this.MniAppliancesAdd.Text = "Добавить...";
            this.MniAppliancesAdd.Click += new System.EventHandler(this.AddAppliance_Command);
            // 
            // MniAppliancesEdit
            // 
            this.MniAppliancesEdit.Image = global::Appliances.Properties.Resources.edit;
            this.MniAppliancesEdit.Name = "MniAppliancesEdit";
            this.MniAppliancesEdit.Size = new System.Drawing.Size(238, 26);
            this.MniAppliancesEdit.Text = "Изменить...";
            this.MniAppliancesEdit.Click += new System.EventHandler(this.EditAppliance_Command);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(235, 6);
            // 
            // MniTurnOnOff
            // 
            this.MniTurnOnOff.Image = global::Appliances.Properties.Resources.TurnOnOff;
            this.MniTurnOnOff.Name = "MniTurnOnOff";
            this.MniTurnOnOff.Size = new System.Drawing.Size(238, 26);
            this.MniTurnOnOff.Text = "Включить/выключить";
            this.MniTurnOnOff.Click += new System.EventHandler(this.TurnOnOff_Command);
            // 
            // MniTurnOff
            // 
            this.MniTurnOff.Image = global::Appliances.Properties.Resources.TurnON;
            this.MniTurnOff.Name = "MniTurnOff";
            this.MniTurnOff.Size = new System.Drawing.Size(238, 26);
            this.MniTurnOff.Text = "Выключить все";
            this.MniTurnOff.Click += new System.EventHandler(this.TurnOn_Command);
            // 
            // MniTurnOn
            // 
            this.MniTurnOn.Image = global::Appliances.Properties.Resources.TurnOFF;
            this.MniTurnOn.Name = "MniTurnOn";
            this.MniTurnOn.Size = new System.Drawing.Size(238, 26);
            this.MniTurnOn.Text = "Включить все";
            this.MniTurnOn.Click += new System.EventHandler(this.TurnOff_Command);
            // 
            // MniTelevisionsSep1
            // 
            this.MniTelevisionsSep1.Name = "MniTelevisionsSep1";
            this.MniTelevisionsSep1.Size = new System.Drawing.Size(235, 6);
            // 
            // MniAppliancesRemoveAt
            // 
            this.MniAppliancesRemoveAt.Image = global::Appliances.Properties.Resources.remove;
            this.MniAppliancesRemoveAt.Name = "MniAppliancesRemoveAt";
            this.MniAppliancesRemoveAt.Size = new System.Drawing.Size(238, 26);
            this.MniAppliancesRemoveAt.Text = "Удалить";
            this.MniAppliancesRemoveAt.Click += new System.EventHandler(this.RemoveAt_Command);
            // 
            // MniOrderBy
            // 
            this.MniOrderBy.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniOrderByName,
            this.MniOrderByState,
            this.MniOrderByPower,
            this.MniOrderByPriceDesc});
            this.MniOrderBy.Name = "MniOrderBy";
            this.MniOrderBy.Size = new System.Drawing.Size(108, 25);
            this.MniOrderBy.Text = "Сортировка";
            // 
            // MniOrderByName
            // 
            this.MniOrderByName.Image = global::Appliances.Properties.Resources.name;
            this.MniOrderByName.Name = "MniOrderByName";
            this.MniOrderByName.Size = new System.Drawing.Size(221, 26);
            this.MniOrderByName.Text = "По названию";
            this.MniOrderByName.Click += new System.EventHandler(this.OrderByName_Command);
            // 
            // MniOrderByState
            // 
            this.MniOrderByState.Image = global::Appliances.Properties.Resources.StateOn;
            this.MniOrderByState.Name = "MniOrderByState";
            this.MniOrderByState.Size = new System.Drawing.Size(221, 26);
            this.MniOrderByState.Text = "По состоянию";
            this.MniOrderByState.Click += new System.EventHandler(this.OrderByState_Command);
            // 
            // MniOrderByPower
            // 
            this.MniOrderByPower.Image = global::Appliances.Properties.Resources.power;
            this.MniOrderByPower.Name = "MniOrderByPower";
            this.MniOrderByPower.Size = new System.Drawing.Size(221, 26);
            this.MniOrderByPower.Text = "По мощности";
            this.MniOrderByPower.Click += new System.EventHandler(this.OrderByPower_Command);
            // 
            // MniOrderByPriceDesc
            // 
            this.MniOrderByPriceDesc.Image = global::Appliances.Properties.Resources.Cost;
            this.MniOrderByPriceDesc.Name = "MniOrderByPriceDesc";
            this.MniOrderByPriceDesc.Size = new System.Drawing.Size(221, 26);
            this.MniOrderByPriceDesc.Text = "По убыванию цены";
            this.MniOrderByPriceDesc.Click += new System.EventHandler(this.OrderByPriceDesc_Command);
            // 
            // MniSelectWhere
            // 
            this.MniSelectWhere.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniSelectWhereName,
            this.MniSelectWhereState});
            this.MniSelectWhere.Name = "MniSelectWhere";
            this.MniSelectWhere.Size = new System.Drawing.Size(85, 25);
            this.MniSelectWhere.Text = "Выборка";
            // 
            // MniSelectWhereName
            // 
            this.MniSelectWhereName.Image = global::Appliances.Properties.Resources.name;
            this.MniSelectWhereName.Name = "MniSelectWhereName";
            this.MniSelectWhereName.Size = new System.Drawing.Size(254, 26);
            this.MniSelectWhereName.Text = "С заданным названием";
            this.MniSelectWhereName.Click += new System.EventHandler(this.SelectByName_Command);
            // 
            // MniSelectWhereState
            // 
            this.MniSelectWhereState.Image = global::Appliances.Properties.Resources.StateOn;
            this.MniSelectWhereState.Name = "MniSelectWhereState";
            this.MniSelectWhereState.Size = new System.Drawing.Size(254, 26);
            this.MniSelectWhereState.Text = "С заданным состоянием";
            this.MniSelectWhereState.Click += new System.EventHandler(this.SelectByState_Command);
            // 
            // MniHelp
            // 
            this.MniHelp.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.MniHelp.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniHelpAbout});
            this.MniHelp.Name = "MniHelp";
            this.MniHelp.Size = new System.Drawing.Size(82, 25);
            this.MniHelp.Text = "Справка";
            // 
            // MniHelpAbout
            // 
            this.MniHelpAbout.Image = global::Appliances.Properties.Resources.help;
            this.MniHelpAbout.Name = "MniHelpAbout";
            this.MniHelpAbout.Size = new System.Drawing.Size(185, 26);
            this.MniHelpAbout.Text = "О программе...";
            this.MniHelpAbout.Click += new System.EventHandler(this.About_Command);
            // 
            // StsMain
            // 
            this.StsMain.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.StsMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.StlMain});
            this.StsMain.Location = new System.Drawing.Point(0, 596);
            this.StsMain.Name = "StsMain";
            this.StsMain.Size = new System.Drawing.Size(987, 22);
            this.StsMain.TabIndex = 10;
            this.StsMain.Text = "statusStrip1";
            // 
            // StlMain
            // 
            this.StlMain.Name = "StlMain";
            this.StlMain.Size = new System.Drawing.Size(972, 17);
            this.StlMain.Spring = true;
            this.StlMain.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // OfdMain
            // 
            this.OfdMain.FileName = "Flat.json";
            this.OfdMain.InitialDirectory = ".. \\.. \\";
            // 
            // LblAddress
            // 
            this.LblAddress.ContextMenuStrip = this.CmnMain;
            this.LblAddress.Dock = System.Windows.Forms.DockStyle.Top;
            this.LblAddress.Font = new System.Drawing.Font("Consolas", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblAddress.Location = new System.Drawing.Point(0, 68);
            this.LblAddress.Name = "LblAddress";
            this.LblAddress.Size = new System.Drawing.Size(987, 22);
            this.LblAddress.TabIndex = 16;
            this.LblAddress.Text = "Адрес квартиры";
            // 
            // CmnMain
            // 
            this.CmnMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem9,
            this.toolStripMenuItem8,
            this.toolStripMenuItem5,
            this.toolStripMenuItem10,
            this.toolStripMenuItem11,
            this.toolStripMenuItem12,
            this.toolStripSeparator3,
            this.toolStripMenuItem21,
            this.toolStripMenuItem26,
            this.toolStripMenuItem20,
            this.toolStripMenuItem6,
            this.toolStripMenuItem7});
            this.CmnMain.Name = "CmnMain";
            this.CmnMain.Size = new System.Drawing.Size(238, 220);
            // 
            // toolStripMenuItem9
            // 
            this.toolStripMenuItem9.Image = global::Appliances.Properties.Resources.save_as;
            this.toolStripMenuItem9.Name = "toolStripMenuItem9";
            this.toolStripMenuItem9.Size = new System.Drawing.Size(237, 22);
            this.toolStripMenuItem9.Text = "Сохранить как...";
            this.toolStripMenuItem9.Click += new System.EventHandler(this.SaveAs_Command);
            // 
            // toolStripMenuItem8
            // 
            this.toolStripMenuItem8.Name = "toolStripMenuItem8";
            this.toolStripMenuItem8.Size = new System.Drawing.Size(237, 22);
            this.toolStripMenuItem8.Text = "Сохранить";
            this.toolStripMenuItem8.Click += new System.EventHandler(this.Save_Command);
            // 
            // toolStripMenuItem5
            // 
            this.toolStripMenuItem5.Image = global::Appliances.Properties.Resources.folder_blue;
            this.toolStripMenuItem5.Name = "toolStripMenuItem5";
            this.toolStripMenuItem5.Size = new System.Drawing.Size(237, 22);
            this.toolStripMenuItem5.Text = "Открыть...";
            this.toolStripMenuItem5.Click += new System.EventHandler(this.Open_Command);
            // 
            // toolStripMenuItem10
            // 
            this.toolStripMenuItem10.Name = "toolStripMenuItem10";
            this.toolStripMenuItem10.Size = new System.Drawing.Size(234, 6);
            // 
            // toolStripMenuItem11
            // 
            this.toolStripMenuItem11.Image = global::Appliances.Properties.Resources.Create;
            this.toolStripMenuItem11.Name = "toolStripMenuItem11";
            this.toolStripMenuItem11.Size = new System.Drawing.Size(237, 22);
            this.toolStripMenuItem11.Text = "Новые данные квартиры";
            this.toolStripMenuItem11.Click += new System.EventHandler(this.Generate_Command);
            // 
            // toolStripMenuItem12
            // 
            this.toolStripMenuItem12.Image = global::Appliances.Properties.Resources.EditFlat;
            this.toolStripMenuItem12.Name = "toolStripMenuItem12";
            this.toolStripMenuItem12.Size = new System.Drawing.Size(237, 22);
            this.toolStripMenuItem12.Text = "Изменить данные квартиры...";
            this.toolStripMenuItem12.Click += new System.EventHandler(this.EditFlat_Command);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(234, 6);
            // 
            // toolStripMenuItem21
            // 
            this.toolStripMenuItem21.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem22,
            this.toolStripMenuItem23,
            this.toolStripMenuItem24,
            this.toolStripMenuItem25});
            this.toolStripMenuItem21.Name = "toolStripMenuItem21";
            this.toolStripMenuItem21.Size = new System.Drawing.Size(237, 22);
            this.toolStripMenuItem21.Text = "Сортировка";
            // 
            // toolStripMenuItem22
            // 
            this.toolStripMenuItem22.Image = global::Appliances.Properties.Resources.name;
            this.toolStripMenuItem22.Name = "toolStripMenuItem22";
            this.toolStripMenuItem22.Size = new System.Drawing.Size(183, 22);
            this.toolStripMenuItem22.Text = "По названию";
            this.toolStripMenuItem22.Click += new System.EventHandler(this.OrderByName_Command);
            // 
            // toolStripMenuItem23
            // 
            this.toolStripMenuItem23.Image = global::Appliances.Properties.Resources.StateOn;
            this.toolStripMenuItem23.Name = "toolStripMenuItem23";
            this.toolStripMenuItem23.Size = new System.Drawing.Size(183, 22);
            this.toolStripMenuItem23.Text = "По состоянию";
            this.toolStripMenuItem23.Click += new System.EventHandler(this.OrderByState_Command);
            // 
            // toolStripMenuItem24
            // 
            this.toolStripMenuItem24.Image = global::Appliances.Properties.Resources.power;
            this.toolStripMenuItem24.Name = "toolStripMenuItem24";
            this.toolStripMenuItem24.Size = new System.Drawing.Size(183, 22);
            this.toolStripMenuItem24.Text = "По мощности";
            this.toolStripMenuItem24.Click += new System.EventHandler(this.OrderByPower_Command);
            // 
            // toolStripMenuItem25
            // 
            this.toolStripMenuItem25.Image = global::Appliances.Properties.Resources.Cost;
            this.toolStripMenuItem25.Name = "toolStripMenuItem25";
            this.toolStripMenuItem25.Size = new System.Drawing.Size(183, 22);
            this.toolStripMenuItem25.Text = "По убыванию цены";
            this.toolStripMenuItem25.Click += new System.EventHandler(this.OrderByPriceDesc_Command);
            // 
            // toolStripMenuItem26
            // 
            this.toolStripMenuItem26.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem27,
            this.toolStripMenuItem28});
            this.toolStripMenuItem26.Name = "toolStripMenuItem26";
            this.toolStripMenuItem26.Size = new System.Drawing.Size(237, 22);
            this.toolStripMenuItem26.Text = "Выборка";
            // 
            // toolStripMenuItem27
            // 
            this.toolStripMenuItem27.Image = global::Appliances.Properties.Resources.name;
            this.toolStripMenuItem27.Name = "toolStripMenuItem27";
            this.toolStripMenuItem27.Size = new System.Drawing.Size(209, 22);
            this.toolStripMenuItem27.Text = "С заданным названием";
            this.toolStripMenuItem27.Click += new System.EventHandler(this.SelectByName_Command);
            // 
            // toolStripMenuItem28
            // 
            this.toolStripMenuItem28.Image = global::Appliances.Properties.Resources.StateOn;
            this.toolStripMenuItem28.Name = "toolStripMenuItem28";
            this.toolStripMenuItem28.Size = new System.Drawing.Size(209, 22);
            this.toolStripMenuItem28.Text = "С заданным состоянием";
            this.toolStripMenuItem28.Click += new System.EventHandler(this.SelectByState_Command);
            // 
            // toolStripMenuItem20
            // 
            this.toolStripMenuItem20.Name = "toolStripMenuItem20";
            this.toolStripMenuItem20.Size = new System.Drawing.Size(234, 6);
            // 
            // toolStripMenuItem6
            // 
            this.toolStripMenuItem6.Image = global::Appliances.Properties.Resources.help;
            this.toolStripMenuItem6.Name = "toolStripMenuItem6";
            this.toolStripMenuItem6.Size = new System.Drawing.Size(237, 22);
            this.toolStripMenuItem6.Text = "О программе...";
            this.toolStripMenuItem6.Click += new System.EventHandler(this.About_Command);
            // 
            // toolStripMenuItem7
            // 
            this.toolStripMenuItem7.Image = global::Appliances.Properties.Resources.exit;
            this.toolStripMenuItem7.Name = "toolStripMenuItem7";
            this.toolStripMenuItem7.Size = new System.Drawing.Size(237, 22);
            this.toolStripMenuItem7.Text = "Выход";
            this.toolStripMenuItem7.Click += new System.EventHandler(this.Exit_Command);
            // 
            // NtiMain
            // 
            this.NtiMain.ContextMenuStrip = this.CmnTray;
            this.NtiMain.Icon = ((System.Drawing.Icon)(resources.GetObject("NtiMain.Icon")));
            this.NtiMain.Text = "Приложение свернуто в трей";
            // 
            // CmnTray
            // 
            this.CmnTray.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem3,
            this.toolStripMenuItem4,
            this.toolStripMenuItem2,
            this.вToolStripMenuItem});
            this.CmnTray.Name = "contextMenuStrip1";
            this.CmnTray.Size = new System.Drawing.Size(192, 76);
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.Image = global::Appliances.Properties.Resources.FromTray;
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(191, 22);
            this.toolStripMenuItem3.Text = "Восстановить из трея";
            this.toolStripMenuItem3.Click += new System.EventHandler(this.FromTray_Command);
            // 
            // toolStripMenuItem4
            // 
            this.toolStripMenuItem4.Name = "toolStripMenuItem4";
            this.toolStripMenuItem4.Size = new System.Drawing.Size(188, 6);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Image = global::Appliances.Properties.Resources.help;
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(191, 22);
            this.toolStripMenuItem2.Text = "О программе...";
            this.toolStripMenuItem2.Click += new System.EventHandler(this.About_Command);
            // 
            // вToolStripMenuItem
            // 
            this.вToolStripMenuItem.Image = global::Appliances.Properties.Resources.exit;
            this.вToolStripMenuItem.Name = "вToolStripMenuItem";
            this.вToolStripMenuItem.Size = new System.Drawing.Size(191, 22);
            this.вToolStripMenuItem.Text = "Выход";
            this.вToolStripMenuItem.Click += new System.EventHandler(this.Exit_Command);
            // 
            // TbcMain
            // 
            this.TbcMain.Controls.Add(this.TbpGeneral);
            this.TbcMain.Controls.Add(this.TbpOrdered);
            this.TbcMain.Controls.Add(this.TbpSelected);
            this.TbcMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TbcMain.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TbcMain.Location = new System.Drawing.Point(0, 90);
            this.TbcMain.Name = "TbcMain";
            this.TbcMain.SelectedIndex = 0;
            this.TbcMain.Size = new System.Drawing.Size(987, 506);
            this.TbcMain.TabIndex = 17;
            this.TbcMain.SelectedIndexChanged += new System.EventHandler(this.TbcMain_SelectedIndexChanged);
            // 
            // TbpGeneral
            // 
            this.TbpGeneral.BackColor = System.Drawing.Color.WhiteSmoke;
            this.TbpGeneral.Controls.Add(this.SpcMain);
            this.TbpGeneral.ImageIndex = 0;
            this.TbpGeneral.Location = new System.Drawing.Point(4, 29);
            this.TbpGeneral.Name = "TbpGeneral";
            this.TbpGeneral.Padding = new System.Windows.Forms.Padding(3);
            this.TbpGeneral.Size = new System.Drawing.Size(979, 473);
            this.TbpGeneral.TabIndex = 0;
            this.TbpGeneral.Text = "Общие сведения";
            // 
            // SpcMain
            // 
            this.SpcMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.SpcMain.Location = new System.Drawing.Point(3, 3);
            this.SpcMain.Name = "SpcMain";
            // 
            // SpcMain.Panel1
            // 
            this.SpcMain.Panel1.Controls.Add(this.TrvAppliances);
            // 
            // SpcMain.Panel2
            // 
            this.SpcMain.Panel2.Controls.Add(this.DgvAppliances);
            this.SpcMain.Size = new System.Drawing.Size(973, 467);
            this.SpcMain.SplitterDistance = 256;
            this.SpcMain.TabIndex = 16;
            // 
            // TrvAppliances
            // 
            this.TrvAppliances.AllowDrop = true;
            this.TrvAppliances.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TrvAppliances.Font = new System.Drawing.Font("Consolas", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TrvAppliances.ImageIndex = 0;
            this.TrvAppliances.ImageList = this.ImlMain;
            this.TrvAppliances.Indent = 10;
            this.TrvAppliances.ItemHeight = 32;
            this.TrvAppliances.Location = new System.Drawing.Point(0, 0);
            this.TrvAppliances.Name = "TrvAppliances";
            this.TrvAppliances.SelectedImageIndex = 1;
            this.TrvAppliances.Size = new System.Drawing.Size(256, 467);
            this.TrvAppliances.TabIndex = 0;
            this.TrvAppliances.DragDrop += new System.Windows.Forms.DragEventHandler(this.DragDrop_Command);
            this.TrvAppliances.DragEnter += new System.Windows.Forms.DragEventHandler(this.DragEnter_Command);
            this.TrvAppliances.MouseUp += new System.Windows.Forms.MouseEventHandler(this.CorrectBehavor_MouseUp);
            // 
            // ImlMain
            // 
            this.ImlMain.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("ImlMain.ImageStream")));
            this.ImlMain.TransparentColor = System.Drawing.Color.Transparent;
            this.ImlMain.Images.SetKeyName(0, "folder_blue.ico");
            this.ImlMain.Images.SetKeyName(1, "open_folder.ico");
            this.ImlMain.Images.SetKeyName(2, "StateOff.png");
            this.ImlMain.Images.SetKeyName(3, "StateOn.png");
            // 
            // DgvAppliances
            // 
            this.DgvAppliances.AllowDrop = true;
            this.DgvAppliances.AllowUserToAddRows = false;
            this.DgvAppliances.AllowUserToDeleteRows = false;
            this.DgvAppliances.AllowUserToResizeRows = false;
            this.DgvAppliances.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.DgvAppliances.BackgroundColor = System.Drawing.SystemColors.ControlLight;
            this.DgvAppliances.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DgvAppliances.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ClnName,
            this.ClnRoom,
            this.ClnPower,
            this.ClnPrice,
            this.ClnState});
            this.DgvAppliances.ContextMenuStrip = this.CmnAppliances;
            this.DgvAppliances.Dock = System.Windows.Forms.DockStyle.Fill;
            this.DgvAppliances.Location = new System.Drawing.Point(0, 0);
            this.DgvAppliances.MultiSelect = false;
            this.DgvAppliances.Name = "DgvAppliances";
            this.DgvAppliances.ReadOnly = true;
            this.DgvAppliances.RowHeadersVisible = false;
            this.DgvAppliances.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.DgvAppliances.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DgvAppliances.Size = new System.Drawing.Size(713, 467);
            this.DgvAppliances.TabIndex = 16;
            this.DgvAppliances.DragDrop += new System.Windows.Forms.DragEventHandler(this.DragDrop_Command);
            this.DgvAppliances.DragEnter += new System.Windows.Forms.DragEventHandler(this.DragEnter_Command);
            // 
            // ClnName
            // 
            this.ClnName.FillWeight = 130F;
            this.ClnName.HeaderText = "Название прибора";
            this.ClnName.Name = "ClnName";
            this.ClnName.ReadOnly = true;
            // 
            // ClnRoom
            // 
            this.ClnRoom.FillWeight = 120F;
            this.ClnRoom.HeaderText = "Комната";
            this.ClnRoom.Name = "ClnRoom";
            this.ClnRoom.ReadOnly = true;
            // 
            // ClnPower
            // 
            this.ClnPower.HeaderText = "Мощность, Вт";
            this.ClnPower.Name = "ClnPower";
            this.ClnPower.ReadOnly = true;
            // 
            // ClnPrice
            // 
            this.ClnPrice.FillWeight = 80F;
            this.ClnPrice.HeaderText = "Цена, руб.";
            this.ClnPrice.Name = "ClnPrice";
            this.ClnPrice.ReadOnly = true;
            // 
            // ClnState
            // 
            this.ClnState.HeaderText = "Состояние";
            this.ClnState.Name = "ClnState";
            this.ClnState.ReadOnly = true;
            // 
            // CmnAppliances
            // 
            this.CmnAppliances.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem31,
            this.toolStripMenuItem32,
            this.toolStripSeparator7,
            this.toolStripMenuItem34,
            this.toolStripMenuItem35,
            this.toolStripSeparator8,
            this.toolStripMenuItem36,
            this.toolStripMenuItem37,
            this.toolStripMenuItem38,
            this.toolStripSeparator9,
            this.toolStripMenuItem39,
            this.toolStripMenuItem13,
            this.toolStripMenuItem40,
            this.toolStripMenuItem45,
            this.toolStripSeparator10,
            this.toolStripMenuItem48,
            this.toolStripMenuItem49});
            this.CmnAppliances.Name = "CmnMain";
            this.CmnAppliances.Size = new System.Drawing.Size(238, 298);
            // 
            // toolStripMenuItem31
            // 
            this.toolStripMenuItem31.Image = global::Appliances.Properties.Resources.Create;
            this.toolStripMenuItem31.Name = "toolStripMenuItem31";
            this.toolStripMenuItem31.Size = new System.Drawing.Size(237, 22);
            this.toolStripMenuItem31.Text = "Новые данные квартиры";
            this.toolStripMenuItem31.Click += new System.EventHandler(this.Generate_Command);
            // 
            // toolStripMenuItem32
            // 
            this.toolStripMenuItem32.Image = global::Appliances.Properties.Resources.EditFlat;
            this.toolStripMenuItem32.Name = "toolStripMenuItem32";
            this.toolStripMenuItem32.Size = new System.Drawing.Size(237, 22);
            this.toolStripMenuItem32.Text = "Изменить данные квартиры...";
            this.toolStripMenuItem32.Click += new System.EventHandler(this.EditFlat_Command);
            // 
            // toolStripSeparator7
            // 
            this.toolStripSeparator7.Name = "toolStripSeparator7";
            this.toolStripSeparator7.Size = new System.Drawing.Size(234, 6);
            // 
            // toolStripMenuItem34
            // 
            this.toolStripMenuItem34.Image = global::Appliances.Properties.Resources.Add;
            this.toolStripMenuItem34.Name = "toolStripMenuItem34";
            this.toolStripMenuItem34.Size = new System.Drawing.Size(237, 22);
            this.toolStripMenuItem34.Text = "Добавить...";
            this.toolStripMenuItem34.Click += new System.EventHandler(this.AddAppliance_Command);
            // 
            // toolStripMenuItem35
            // 
            this.toolStripMenuItem35.Image = global::Appliances.Properties.Resources.edit;
            this.toolStripMenuItem35.Name = "toolStripMenuItem35";
            this.toolStripMenuItem35.Size = new System.Drawing.Size(237, 22);
            this.toolStripMenuItem35.Text = "Изменить...";
            this.toolStripMenuItem35.Click += new System.EventHandler(this.EditAppliance_Command);
            // 
            // toolStripSeparator8
            // 
            this.toolStripSeparator8.Name = "toolStripSeparator8";
            this.toolStripSeparator8.Size = new System.Drawing.Size(234, 6);
            // 
            // toolStripMenuItem36
            // 
            this.toolStripMenuItem36.Image = global::Appliances.Properties.Resources.TurnOnOff;
            this.toolStripMenuItem36.Name = "toolStripMenuItem36";
            this.toolStripMenuItem36.Size = new System.Drawing.Size(237, 22);
            this.toolStripMenuItem36.Text = "Включить/выключить";
            this.toolStripMenuItem36.Click += new System.EventHandler(this.TurnOnOff_Command);
            // 
            // toolStripMenuItem37
            // 
            this.toolStripMenuItem37.Image = global::Appliances.Properties.Resources.TurnON;
            this.toolStripMenuItem37.Name = "toolStripMenuItem37";
            this.toolStripMenuItem37.Size = new System.Drawing.Size(237, 22);
            this.toolStripMenuItem37.Text = "Выключить все";
            this.toolStripMenuItem37.Click += new System.EventHandler(this.TurnOn_Command);
            // 
            // toolStripMenuItem38
            // 
            this.toolStripMenuItem38.Image = global::Appliances.Properties.Resources.TurnOFF;
            this.toolStripMenuItem38.Name = "toolStripMenuItem38";
            this.toolStripMenuItem38.Size = new System.Drawing.Size(237, 22);
            this.toolStripMenuItem38.Text = "Включить все";
            this.toolStripMenuItem38.Click += new System.EventHandler(this.TurnOff_Command);
            // 
            // toolStripSeparator9
            // 
            this.toolStripSeparator9.Name = "toolStripSeparator9";
            this.toolStripSeparator9.Size = new System.Drawing.Size(234, 6);
            // 
            // toolStripMenuItem39
            // 
            this.toolStripMenuItem39.Image = global::Appliances.Properties.Resources.remove;
            this.toolStripMenuItem39.Name = "toolStripMenuItem39";
            this.toolStripMenuItem39.Size = new System.Drawing.Size(237, 22);
            this.toolStripMenuItem39.Text = "Удалить";
            this.toolStripMenuItem39.Click += new System.EventHandler(this.RemoveAt_Command);
            // 
            // toolStripMenuItem13
            // 
            this.toolStripMenuItem13.Name = "toolStripMenuItem13";
            this.toolStripMenuItem13.Size = new System.Drawing.Size(234, 6);
            // 
            // toolStripMenuItem40
            // 
            this.toolStripMenuItem40.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem41,
            this.toolStripMenuItem42,
            this.toolStripMenuItem43,
            this.toolStripMenuItem44});
            this.toolStripMenuItem40.Name = "toolStripMenuItem40";
            this.toolStripMenuItem40.Size = new System.Drawing.Size(237, 22);
            this.toolStripMenuItem40.Text = "Сортировка";
            // 
            // toolStripMenuItem41
            // 
            this.toolStripMenuItem41.Image = global::Appliances.Properties.Resources.name;
            this.toolStripMenuItem41.Name = "toolStripMenuItem41";
            this.toolStripMenuItem41.Size = new System.Drawing.Size(183, 22);
            this.toolStripMenuItem41.Text = "По названию";
            this.toolStripMenuItem41.Click += new System.EventHandler(this.OrderByName_Command);
            // 
            // toolStripMenuItem42
            // 
            this.toolStripMenuItem42.Image = global::Appliances.Properties.Resources.StateOn;
            this.toolStripMenuItem42.Name = "toolStripMenuItem42";
            this.toolStripMenuItem42.Size = new System.Drawing.Size(183, 22);
            this.toolStripMenuItem42.Text = "По состоянию";
            this.toolStripMenuItem42.Click += new System.EventHandler(this.OrderByState_Command);
            // 
            // toolStripMenuItem43
            // 
            this.toolStripMenuItem43.Image = global::Appliances.Properties.Resources.power;
            this.toolStripMenuItem43.Name = "toolStripMenuItem43";
            this.toolStripMenuItem43.Size = new System.Drawing.Size(183, 22);
            this.toolStripMenuItem43.Text = "По мощности";
            this.toolStripMenuItem43.Click += new System.EventHandler(this.OrderByPower_Command);
            // 
            // toolStripMenuItem44
            // 
            this.toolStripMenuItem44.Image = global::Appliances.Properties.Resources.Cost;
            this.toolStripMenuItem44.Name = "toolStripMenuItem44";
            this.toolStripMenuItem44.Size = new System.Drawing.Size(183, 22);
            this.toolStripMenuItem44.Text = "По убыванию цены";
            this.toolStripMenuItem44.Click += new System.EventHandler(this.OrderByPriceDesc_Command);
            // 
            // toolStripMenuItem45
            // 
            this.toolStripMenuItem45.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem46,
            this.toolStripMenuItem47});
            this.toolStripMenuItem45.Name = "toolStripMenuItem45";
            this.toolStripMenuItem45.Size = new System.Drawing.Size(237, 22);
            this.toolStripMenuItem45.Text = "Выборка";
            // 
            // toolStripMenuItem46
            // 
            this.toolStripMenuItem46.Image = global::Appliances.Properties.Resources.name;
            this.toolStripMenuItem46.Name = "toolStripMenuItem46";
            this.toolStripMenuItem46.Size = new System.Drawing.Size(209, 22);
            this.toolStripMenuItem46.Text = "С заданным названием";
            this.toolStripMenuItem46.Click += new System.EventHandler(this.SelectByName_Command);
            // 
            // toolStripMenuItem47
            // 
            this.toolStripMenuItem47.Image = global::Appliances.Properties.Resources.StateOn;
            this.toolStripMenuItem47.Name = "toolStripMenuItem47";
            this.toolStripMenuItem47.Size = new System.Drawing.Size(209, 22);
            this.toolStripMenuItem47.Text = "С заданным состоянием";
            this.toolStripMenuItem47.Click += new System.EventHandler(this.SelectByState_Command);
            // 
            // toolStripSeparator10
            // 
            this.toolStripSeparator10.Name = "toolStripSeparator10";
            this.toolStripSeparator10.Size = new System.Drawing.Size(234, 6);
            // 
            // toolStripMenuItem48
            // 
            this.toolStripMenuItem48.Image = global::Appliances.Properties.Resources.help;
            this.toolStripMenuItem48.Name = "toolStripMenuItem48";
            this.toolStripMenuItem48.Size = new System.Drawing.Size(237, 22);
            this.toolStripMenuItem48.Text = "О программе...";
            this.toolStripMenuItem48.Click += new System.EventHandler(this.About_Command);
            // 
            // toolStripMenuItem49
            // 
            this.toolStripMenuItem49.Image = global::Appliances.Properties.Resources.exit;
            this.toolStripMenuItem49.Name = "toolStripMenuItem49";
            this.toolStripMenuItem49.Size = new System.Drawing.Size(237, 22);
            this.toolStripMenuItem49.Text = "Выход";
            this.toolStripMenuItem49.Click += new System.EventHandler(this.Exit_Command);
            // 
            // TbpOrdered
            // 
            this.TbpOrdered.BackColor = System.Drawing.Color.WhiteSmoke;
            this.TbpOrdered.Controls.Add(this.DgvOrderedAppliances);
            this.TbpOrdered.Controls.Add(this.LblHeaderOrdered);
            this.TbpOrdered.ImageIndex = 1;
            this.TbpOrdered.Location = new System.Drawing.Point(4, 29);
            this.TbpOrdered.Name = "TbpOrdered";
            this.TbpOrdered.Padding = new System.Windows.Forms.Padding(3);
            this.TbpOrdered.Size = new System.Drawing.Size(979, 473);
            this.TbpOrdered.TabIndex = 1;
            this.TbpOrdered.Text = "Отсортированные сведения";
            // 
            // DgvOrderedAppliances
            // 
            this.DgvOrderedAppliances.AllowUserToAddRows = false;
            this.DgvOrderedAppliances.AllowUserToDeleteRows = false;
            this.DgvOrderedAppliances.AllowUserToResizeRows = false;
            this.DgvOrderedAppliances.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.DgvOrderedAppliances.BackgroundColor = System.Drawing.SystemColors.ControlLight;
            this.DgvOrderedAppliances.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DgvOrderedAppliances.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5});
            this.DgvOrderedAppliances.ContextMenuStrip = this.CmnAppliances;
            this.DgvOrderedAppliances.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.DgvOrderedAppliances.Location = new System.Drawing.Point(3, 45);
            this.DgvOrderedAppliances.MultiSelect = false;
            this.DgvOrderedAppliances.Name = "DgvOrderedAppliances";
            this.DgvOrderedAppliances.ReadOnly = true;
            this.DgvOrderedAppliances.RowHeadersVisible = false;
            this.DgvOrderedAppliances.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.DgvOrderedAppliances.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DgvOrderedAppliances.Size = new System.Drawing.Size(973, 425);
            this.DgvOrderedAppliances.TabIndex = 18;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.FillWeight = 130F;
            this.dataGridViewTextBoxColumn1.HeaderText = "Название прибора";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.FillWeight = 120F;
            this.dataGridViewTextBoxColumn2.HeaderText = "Комната";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.HeaderText = "Мощность, Вт";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.FillWeight = 80F;
            this.dataGridViewTextBoxColumn4.HeaderText = "Цена, руб.";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.HeaderText = "Состояние";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.ReadOnly = true;
            // 
            // LblHeaderOrdered
            // 
            this.LblHeaderOrdered.Font = new System.Drawing.Font("Consolas", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblHeaderOrdered.Location = new System.Drawing.Point(6, 3);
            this.LblHeaderOrdered.Name = "LblHeaderOrdered";
            this.LblHeaderOrdered.Size = new System.Drawing.Size(744, 68);
            this.LblHeaderOrdered.TabIndex = 7;
            this.LblHeaderOrdered.Text = "Электрооборудование квартиры";
            // 
            // TbpSelected
            // 
            this.TbpSelected.BackColor = System.Drawing.Color.WhiteSmoke;
            this.TbpSelected.Controls.Add(this.DgvSelectedAppliances);
            this.TbpSelected.Controls.Add(this.LblHeaderSelected);
            this.TbpSelected.ImageIndex = 2;
            this.TbpSelected.Location = new System.Drawing.Point(4, 29);
            this.TbpSelected.Name = "TbpSelected";
            this.TbpSelected.Size = new System.Drawing.Size(979, 473);
            this.TbpSelected.TabIndex = 2;
            this.TbpSelected.Text = "Выборка данных";
            // 
            // DgvSelectedAppliances
            // 
            this.DgvSelectedAppliances.AllowUserToAddRows = false;
            this.DgvSelectedAppliances.AllowUserToDeleteRows = false;
            this.DgvSelectedAppliances.AllowUserToResizeRows = false;
            this.DgvSelectedAppliances.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.DgvSelectedAppliances.BackgroundColor = System.Drawing.SystemColors.ControlLight;
            this.DgvSelectedAppliances.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DgvSelectedAppliances.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn6,
            this.dataGridViewTextBoxColumn7,
            this.dataGridViewTextBoxColumn8,
            this.dataGridViewTextBoxColumn9,
            this.dataGridViewTextBoxColumn10});
            this.DgvSelectedAppliances.ContextMenuStrip = this.CmnAppliances;
            this.DgvSelectedAppliances.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.DgvSelectedAppliances.Location = new System.Drawing.Point(0, 48);
            this.DgvSelectedAppliances.MultiSelect = false;
            this.DgvSelectedAppliances.Name = "DgvSelectedAppliances";
            this.DgvSelectedAppliances.ReadOnly = true;
            this.DgvSelectedAppliances.RowHeadersVisible = false;
            this.DgvSelectedAppliances.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.DgvSelectedAppliances.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DgvSelectedAppliances.Size = new System.Drawing.Size(979, 425);
            this.DgvSelectedAppliances.TabIndex = 19;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.FillWeight = 130F;
            this.dataGridViewTextBoxColumn6.HeaderText = "Название прибора";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.FillWeight = 120F;
            this.dataGridViewTextBoxColumn7.HeaderText = "Комната";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            this.dataGridViewTextBoxColumn7.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.HeaderText = "Мощность, Вт";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            this.dataGridViewTextBoxColumn8.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.FillWeight = 80F;
            this.dataGridViewTextBoxColumn9.HeaderText = "Цена, руб.";
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            this.dataGridViewTextBoxColumn9.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn10
            // 
            this.dataGridViewTextBoxColumn10.HeaderText = "Состояние";
            this.dataGridViewTextBoxColumn10.Name = "dataGridViewTextBoxColumn10";
            this.dataGridViewTextBoxColumn10.ReadOnly = true;
            // 
            // LblHeaderSelected
            // 
            this.LblHeaderSelected.Font = new System.Drawing.Font("Consolas", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblHeaderSelected.Location = new System.Drawing.Point(6, 3);
            this.LblHeaderSelected.Name = "LblHeaderSelected";
            this.LblHeaderSelected.Size = new System.Drawing.Size(744, 59);
            this.LblHeaderSelected.TabIndex = 11;
            this.LblHeaderSelected.Text = "Электрооборудование квартиры";
            // 
            // CmnTree
            // 
            this.CmnTree.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem50,
            this.toolStripMenuItem51,
            this.toolStripMenuItem29,
            this.TurnOffInRoom,
            this.TurnOnInRoom,
            this.toolStripSeparator11,
            this.toolStripMenuItem67,
            this.toolStripMenuItem68});
            this.CmnTree.Name = "CmnMain";
            this.CmnTree.Size = new System.Drawing.Size(266, 148);
            // 
            // toolStripMenuItem50
            // 
            this.toolStripMenuItem50.Image = global::Appliances.Properties.Resources.Create;
            this.toolStripMenuItem50.Name = "toolStripMenuItem50";
            this.toolStripMenuItem50.Size = new System.Drawing.Size(265, 22);
            this.toolStripMenuItem50.Text = "Новые данные квартиры";
            this.toolStripMenuItem50.Click += new System.EventHandler(this.Generate_Command);
            // 
            // toolStripMenuItem51
            // 
            this.toolStripMenuItem51.Image = global::Appliances.Properties.Resources.EditFlat;
            this.toolStripMenuItem51.Name = "toolStripMenuItem51";
            this.toolStripMenuItem51.Size = new System.Drawing.Size(265, 22);
            this.toolStripMenuItem51.Text = "Изменить данные квартиры...";
            this.toolStripMenuItem51.Click += new System.EventHandler(this.EditFlat_Command);
            // 
            // toolStripMenuItem29
            // 
            this.toolStripMenuItem29.Name = "toolStripMenuItem29";
            this.toolStripMenuItem29.Size = new System.Drawing.Size(262, 6);
            // 
            // TurnOffInRoom
            // 
            this.TurnOffInRoom.Image = global::Appliances.Properties.Resources.TurnON;
            this.TurnOffInRoom.Name = "TurnOffInRoom";
            this.TurnOffInRoom.Size = new System.Drawing.Size(265, 22);
            this.TurnOffInRoom.Text = "Выключить все приборы комнаты";
            this.TurnOffInRoom.Click += new System.EventHandler(this.TurnOnInRoom_Command);
            // 
            // TurnOnInRoom
            // 
            this.TurnOnInRoom.Image = global::Appliances.Properties.Resources.TurnOFF;
            this.TurnOnInRoom.Name = "TurnOnInRoom";
            this.TurnOnInRoom.Size = new System.Drawing.Size(265, 22);
            this.TurnOnInRoom.Text = "Включить все приборы комнаты";
            this.TurnOnInRoom.Click += new System.EventHandler(this.TurnOffInRoom_Command);
            // 
            // toolStripSeparator11
            // 
            this.toolStripSeparator11.Name = "toolStripSeparator11";
            this.toolStripSeparator11.Size = new System.Drawing.Size(262, 6);
            // 
            // toolStripMenuItem67
            // 
            this.toolStripMenuItem67.Image = global::Appliances.Properties.Resources.help;
            this.toolStripMenuItem67.Name = "toolStripMenuItem67";
            this.toolStripMenuItem67.Size = new System.Drawing.Size(265, 22);
            this.toolStripMenuItem67.Text = "О программе...";
            this.toolStripMenuItem67.Click += new System.EventHandler(this.About_Command);
            // 
            // toolStripMenuItem68
            // 
            this.toolStripMenuItem68.Image = global::Appliances.Properties.Resources.exit;
            this.toolStripMenuItem68.Name = "toolStripMenuItem68";
            this.toolStripMenuItem68.Size = new System.Drawing.Size(265, 22);
            this.toolStripMenuItem68.Text = "Выход";
            this.toolStripMenuItem68.Click += new System.EventHandler(this.Exit_Command);
            // 
            // CmnTreeAppliance
            // 
            this.CmnTreeAppliance.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem30,
            this.toolStripSeparator6,
            this.toolStripMenuItem53,
            this.toolStripMenuItem57,
            this.toolStripSeparator12,
            this.toolStripMenuItem54,
            this.toolStripSeparator14,
            this.toolStripMenuItem66,
            this.toolStripMenuItem69});
            this.CmnTreeAppliance.Name = "CmnMain";
            this.CmnTreeAppliance.Size = new System.Drawing.Size(212, 154);
            // 
            // toolStripMenuItem30
            // 
            this.toolStripMenuItem30.Image = global::Appliances.Properties.Resources.Create;
            this.toolStripMenuItem30.Name = "toolStripMenuItem30";
            this.toolStripMenuItem30.Size = new System.Drawing.Size(211, 22);
            this.toolStripMenuItem30.Text = "Новые данные квартиры";
            this.toolStripMenuItem30.Click += new System.EventHandler(this.Generate_Command);
            // 
            // toolStripSeparator6
            // 
            this.toolStripSeparator6.Name = "toolStripSeparator6";
            this.toolStripSeparator6.Size = new System.Drawing.Size(208, 6);
            // 
            // toolStripMenuItem53
            // 
            this.toolStripMenuItem53.Image = global::Appliances.Properties.Resources.edit;
            this.toolStripMenuItem53.Name = "toolStripMenuItem53";
            this.toolStripMenuItem53.Size = new System.Drawing.Size(211, 22);
            this.toolStripMenuItem53.Text = "Изменить...";
            this.toolStripMenuItem53.Click += new System.EventHandler(this.EditAppliance_Command);
            // 
            // toolStripMenuItem57
            // 
            this.toolStripMenuItem57.Image = global::Appliances.Properties.Resources.remove;
            this.toolStripMenuItem57.Name = "toolStripMenuItem57";
            this.toolStripMenuItem57.Size = new System.Drawing.Size(211, 22);
            this.toolStripMenuItem57.Text = "Удалить";
            this.toolStripMenuItem57.Click += new System.EventHandler(this.RemoveAt_Command);
            // 
            // toolStripSeparator12
            // 
            this.toolStripSeparator12.Name = "toolStripSeparator12";
            this.toolStripSeparator12.Size = new System.Drawing.Size(208, 6);
            // 
            // toolStripMenuItem54
            // 
            this.toolStripMenuItem54.Image = global::Appliances.Properties.Resources.TurnOnOff;
            this.toolStripMenuItem54.Name = "toolStripMenuItem54";
            this.toolStripMenuItem54.Size = new System.Drawing.Size(211, 22);
            this.toolStripMenuItem54.Text = "Включить/выключить";
            this.toolStripMenuItem54.Click += new System.EventHandler(this.TurnOnOff_Command);
            // 
            // toolStripSeparator14
            // 
            this.toolStripSeparator14.Name = "toolStripSeparator14";
            this.toolStripSeparator14.Size = new System.Drawing.Size(208, 6);
            // 
            // toolStripMenuItem66
            // 
            this.toolStripMenuItem66.Image = global::Appliances.Properties.Resources.help;
            this.toolStripMenuItem66.Name = "toolStripMenuItem66";
            this.toolStripMenuItem66.Size = new System.Drawing.Size(211, 22);
            this.toolStripMenuItem66.Text = "О программе...";
            // 
            // toolStripMenuItem69
            // 
            this.toolStripMenuItem69.Image = global::Appliances.Properties.Resources.exit;
            this.toolStripMenuItem69.Name = "toolStripMenuItem69";
            this.toolStripMenuItem69.Size = new System.Drawing.Size(211, 22);
            this.toolStripMenuItem69.Text = "Выход";
            // 
            // MainForm
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.Gainsboro;
            this.ClientSize = new System.Drawing.Size(987, 618);
            this.ContextMenuStrip = this.CmnMain;
            this.Controls.Add(this.TbcMain);
            this.Controls.Add(this.LblAddress);
            this.Controls.Add(this.StsMain);
            this.Controls.Add(this.TbsMain);
            this.Controls.Add(this.MnsMain);
            this.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Задание на 13.12.2021";
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.TbsMain.ResumeLayout(false);
            this.TbsMain.PerformLayout();
            this.MnsMain.ResumeLayout(false);
            this.MnsMain.PerformLayout();
            this.StsMain.ResumeLayout(false);
            this.StsMain.PerformLayout();
            this.CmnMain.ResumeLayout(false);
            this.CmnTray.ResumeLayout(false);
            this.TbcMain.ResumeLayout(false);
            this.TbpGeneral.ResumeLayout(false);
            this.SpcMain.Panel1.ResumeLayout(false);
            this.SpcMain.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.SpcMain)).EndInit();
            this.SpcMain.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DgvAppliances)).EndInit();
            this.CmnAppliances.ResumeLayout(false);
            this.TbpOrdered.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DgvOrderedAppliances)).EndInit();
            this.TbpSelected.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DgvSelectedAppliances)).EndInit();
            this.CmnTree.ResumeLayout(false);
            this.CmnTreeAppliance.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.ToolStrip TbsMain;
        private System.Windows.Forms.ToolStripButton TsbFileOpen;
        private System.Windows.Forms.ToolStripButton TsbFileSave;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripButton TsbNewFlat;
        private System.Windows.Forms.ToolStripButton TsbEditFlat;
        private System.Windows.Forms.ToolStripSeparator TsbSeparator1;
        private System.Windows.Forms.ToolStripButton TsbAddAppliance;
        private System.Windows.Forms.ToolStripButton TsbEditAppliance;
        private System.Windows.Forms.ToolStripButton TsbRemoveAppliance;
        private System.Windows.Forms.ToolStripSeparator TsbSeparator2;
        private System.Windows.Forms.ToolStripDropDownButton TsdOrderBy;
        private System.Windows.Forms.ToolStripMenuItem DmiOrderByName;
        private System.Windows.Forms.ToolStripMenuItem DmiOrderByState;
        private System.Windows.Forms.ToolStripMenuItem DmiOrderByPower;
        private System.Windows.Forms.ToolStripMenuItem DmiOrderByPriceDesc;
        private System.Windows.Forms.ToolStripSeparator TsbSeparator3;
        private System.Windows.Forms.ToolStripButton TsbToTray;
        private System.Windows.Forms.ToolStripButton TsbAbout;
        private System.Windows.Forms.ToolStripButton TsbExit;
        private System.Windows.Forms.MenuStrip MnsMain;
        private System.Windows.Forms.ToolStripMenuItem MniFile;
        private System.Windows.Forms.ToolStripMenuItem MniFileOpen;
        private System.Windows.Forms.ToolStripMenuItem MniFileSave;
        private System.Windows.Forms.ToolStripMenuItem MniFileSaveAs;
        private System.Windows.Forms.ToolStripSeparator MniFileSep1;
        private System.Windows.Forms.ToolStripMenuItem MniFileExit;
        private System.Windows.Forms.ToolStripMenuItem MniFlat;
        private System.Windows.Forms.ToolStripMenuItem MniFlatNew;
        private System.Windows.Forms.ToolStripMenuItem MniFlatEdit;
        private System.Windows.Forms.ToolStripMenuItem MniOrderBy;
        private System.Windows.Forms.ToolStripMenuItem MniHelp;
        private System.Windows.Forms.ToolStripMenuItem MniHelpAbout;
        private System.Windows.Forms.ToolStripDropDownButton TsdSelectWhere;
        private System.Windows.Forms.ToolStripMenuItem TsdSelectWhereName;
        private System.Windows.Forms.ToolStripMenuItem TsdSelectWhereState;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripMenuItem MniOrderByName;
        private System.Windows.Forms.ToolStripMenuItem MniOrderByState;
        private System.Windows.Forms.ToolStripMenuItem MniOrderByPower;
        private System.Windows.Forms.ToolStripMenuItem MniOrderByPriceDesc;
        private System.Windows.Forms.ToolStripMenuItem MniSelectWhere;
        private System.Windows.Forms.ToolStripMenuItem MniSelectWhereName;
        private System.Windows.Forms.ToolStripMenuItem MniSelectWhereState;
        private System.Windows.Forms.StatusStrip StsMain;
        private System.Windows.Forms.ToolStripStatusLabel StlMain;
        private System.Windows.Forms.OpenFileDialog OfdMain;
        private System.Windows.Forms.ImageList ImlAppliances;
        private System.Windows.Forms.SaveFileDialog SfdMain;
        private System.Windows.Forms.NotifyIcon NtiMain;
        private System.Windows.Forms.ContextMenuStrip CmnTray;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem3;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem4;
        private System.Windows.Forms.ToolStripMenuItem вToolStripMenuItem;
        private System.Windows.Forms.ToolStripButton TsbTurnOnOff;
        private System.Windows.Forms.ToolStripButton TsbTurnOn;
        private System.Windows.Forms.ToolStripButton TsbTurnOff;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private System.Windows.Forms.Label LblAddress;
        private System.Windows.Forms.ContextMenuStrip CmnMain;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem9;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem8;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem5;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem10;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem11;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem12;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem6;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem7;
        private System.Windows.Forms.ToolStripMenuItem MniAppliances;
        private System.Windows.Forms.ToolStripMenuItem MniAppliancesAdd;
        private System.Windows.Forms.ToolStripMenuItem MniAppliancesEdit;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem MniTurnOnOff;
        private System.Windows.Forms.ToolStripMenuItem MniTurnOff;
        private System.Windows.Forms.ToolStripMenuItem MniTurnOn;
        private System.Windows.Forms.ToolStripSeparator MniTelevisionsSep1;
        private System.Windows.Forms.ToolStripMenuItem MniAppliancesRemoveAt;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem21;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem22;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem23;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem24;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem25;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem26;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem27;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem28;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem20;
        private System.Windows.Forms.TabControl TbcMain;
        private System.Windows.Forms.TabPage TbpGeneral;
        private System.Windows.Forms.TabPage TbpOrdered;
        private System.Windows.Forms.Label LblHeaderOrdered;
        private System.Windows.Forms.TabPage TbpSelected;
        private System.Windows.Forms.Label LblHeaderSelected;
        private System.Windows.Forms.ContextMenuStrip CmnAppliances;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem31;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem32;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator7;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem34;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem35;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator8;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem36;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem37;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem38;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator9;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem39;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem13;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem40;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem41;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem42;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem43;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem44;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem45;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem46;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem47;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator10;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem48;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem49;
        private System.Windows.Forms.SplitContainer SpcMain;
        private System.Windows.Forms.TreeView TrvAppliances;
        private System.Windows.Forms.ImageList ImlMain;
        private System.Windows.Forms.ContextMenuStrip CmnTree;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem50;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem51;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator11;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem67;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem68;
        private System.Windows.Forms.ToolStripMenuItem TurnOnInRoom;
        private System.Windows.Forms.ToolStripMenuItem TurnOffInRoom;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem29;
        private System.Windows.Forms.ContextMenuStrip CmnTreeAppliance;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem30;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator6;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem53;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem57;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator12;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem54;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator14;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem66;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem69;
        private System.Windows.Forms.DataGridView DgvOrderedAppliances;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridView DgvSelectedAppliances;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;
        private System.Windows.Forms.DataGridView DgvAppliances;
        private System.Windows.Forms.DataGridViewTextBoxColumn ClnName;
        private System.Windows.Forms.DataGridViewTextBoxColumn ClnRoom;
        private System.Windows.Forms.DataGridViewTextBoxColumn ClnPower;
        private System.Windows.Forms.DataGridViewTextBoxColumn ClnPrice;
        private System.Windows.Forms.DataGridViewTextBoxColumn ClnState;
    }
}

