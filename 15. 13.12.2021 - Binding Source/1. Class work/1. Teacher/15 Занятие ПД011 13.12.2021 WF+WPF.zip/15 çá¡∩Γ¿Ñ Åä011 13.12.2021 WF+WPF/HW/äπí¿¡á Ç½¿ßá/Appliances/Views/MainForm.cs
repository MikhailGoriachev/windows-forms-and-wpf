﻿using Appliances.Controllers;
using Appliances.Helpers;
using Appliances.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Appliances.Views
{
    public partial class MainForm : Form
    {

        private FlatController _flatController;

        public MainForm() : this(new FlatController()) { } // MainForm

        public MainForm(FlatController flatController) {
            InitializeComponent();

            _flatController = flatController;

            // Если папки и/или файл нет, то создать папку
            if (!File.Exists(@"App_data\" + _flatController.FileName)) { 
                Directory.CreateDirectory(@"App_Data");
                flatController.Flat.Serialization(@"App_Data\" + _flatController.FileName);
            } 
            else {
                _flatController.Flat.Deserialization(@"App_Data\" + _flatController.FileName);
            } // if


            // запись коллекции объектов в DataGridView для табличного отображения
            WriteToDataGridView(DgvAppliances, _flatController.Flat.Appliances);

            // запись коллекции объектов в TreeView
            WriteToTreeView(TrvAppliances, _flatController);
            TrvAppliances.ExpandAll();
            StlMain.Text = $"Коллекция электроприборов сформирована. Текущее количество электроприборов: {_flatController.Flat.Count}";
        } // MainForm


        private void Exit_Command(object sender, EventArgs e) => Application.Exit();

        private void About_Command(object sender, EventArgs e) {
            FormAbout formAbout = new FormAbout();
            formAbout.ShowDialog();
        } // About_Command

        // Сохранение данных электрооборудования квартиры
        private void Save_Command(object sender, EventArgs e) =>
            _flatController.Flat.Serialization(@"App_Data\" + _flatController.FileName);


        // Загрузка данных электрооборудования квартиры из выбранного файла
        private void Open_Command(object sender, EventArgs e) {
            OfdMain.Title = "Открыть файл";
            OfdMain.InitialDirectory = Path.GetDirectoryName(@"App_Data\" + _flatController.FileName);
            OfdMain.Filter = "Файлы JSON (*.json)|*.json";
            OfdMain.FilterIndex = 1;
            if (OfdMain.ShowDialog() == DialogResult.OK) {
                _flatController.Flat.Deserialization(OfdMain.FileName);
                WriteToTreeView(TrvAppliances, _flatController);
                MainForm_Load(sender, e);
            } // if
        } // Open_Command


        // Сохранение данных электрооборудования квартиры в выбранном файле 
        private void SaveAs_Command(object sender, EventArgs e) {
            SfdMain.Title = "Сохранить файл как";
            SfdMain.InitialDirectory = Path.GetDirectoryName(_flatController.FileName);
            SfdMain.Filter = "Файлы JSON (*.json)|*.json";
            //SfdMain.FilterIndex = 1;
            if (SfdMain.ShowDialog() == DialogResult.OK) {
                _flatController.Flat.Serialization(SfdMain.FileName);
            } // if
        } // SaveAs_Command

        // запись коллекции объектов в ListView для табличного отображения
        private void WriteToDataGridView(DataGridView dataGridView, List<Appliance> appliances) {
            dataGridView.Rows.Clear();

            int i = 0;
            foreach (var appliance in appliances) {
                dataGridView.RowCount++;

                dataGridView[0, i].Value = appliance.Name;
                dataGridView[0, i].Style.Alignment = DataGridViewContentAlignment.MiddleLeft;

                dataGridView[1, i].Value = appliance.Room;
                dataGridView[1, i].Style.Alignment = DataGridViewContentAlignment.MiddleLeft;

                dataGridView[2, i].Value = $"{appliance.Power:f2}";
                dataGridView[2, i].Style.Alignment = DataGridViewContentAlignment.MiddleRight;

                dataGridView[3, i].Value = $"{appliance.Price:f2}";
                dataGridView[3, i].Style.Alignment = DataGridViewContentAlignment.MiddleRight;

                dataGridView[4, i].Value = appliance.State ? "включен" : "выключен";
                dataGridView[4, i].Style.Alignment = DataGridViewContentAlignment.MiddleLeft;
                i++;
            } // foreach person
        } // WriteToListView

        private void WriteToTreeView(TreeView treeView, FlatController flatController) {
            treeView.Nodes.Clear();

            treeView.Nodes.Add(flatController.Flat.Name);

            int i = 0;
            foreach (var room in flatController.GetRooms()) {
                // добавление узла комнаты
                treeView.Nodes[0].Nodes.Add(room);
                treeView.Nodes[0].Nodes[i].ContextMenuStrip = CmnTree;
                int j = 0;
                foreach (var appliance in flatController.Flat.Appliances.FindAll(x => x.Room == room)) {
                    // добавление узла прибора
                    treeView.Nodes[0].Nodes[i].Nodes.Add(appliance.Name);
                    treeView.Nodes[0].Nodes[i].Nodes[j].ImageIndex = 
                        treeView.Nodes[0].Nodes[i].Nodes[j].SelectedImageIndex = appliance.State ? 3 : 2;
                    treeView.Nodes[0].Nodes[i].Nodes[j].Tag = appliance;
                    treeView.Nodes[0].Nodes[i].Nodes[j].ContextMenuStrip = CmnTreeAppliance;
                    j++;
                } // foreach appliance
                i++;
                TrvAppliances.ExpandAll();

            } // foreach room
        } // WriteToListView



        // Начальное формирование данных электрооборудования квартиры
        private void Generate_Command(object sender, EventArgs e) {
            _flatController.Flat.Generate(Utils.GetRandom(6, 8));
            _flatController.Flat.OrderBy((x, y) => x.Room.CompareTo(y.Room));
            
            StlMain.Text = $"Коллекция электроприборов сформирована. Текущее количество электроприборов: {_flatController.Flat.Count}";
            WriteToDataGridView(DgvAppliances, _flatController.Flat.Appliances);
            WriteToTreeView(TrvAppliances, _flatController);

            // сериализация данных
            Save_Command(sender, e);

            // делаем главную страницу текущей
            TbcMain.SelectedTab = TbpGeneral;
        } // Generate_Command


        // свернуть в трей
        private void ToTray_Command(object sender, EventArgs e) {
            this.Hide();
            NtiMain.Visible = true;
        } // ToTray_Command


        // восстановить из трея
        private void FromTray_Command(object sender, EventArgs e){
            this.Show();
            WindowState = FormWindowState.Normal;
            NtiMain.Visible = false;
        } // FromTray_Command


        // удаление электроприбора
        private void RemoveAt_Command(object sender, EventArgs e) {
            int index = 0;

            // если нет выбранных элементов - молча уходим
            if (DgvAppliances.SelectedRows.Count == 0 && TrvAppliances.SelectedNode?.Level != 2) return;
            else if (SpcMain.ActiveControl == TrvAppliances)
                RemoveFromTree();

            else {
                index = DgvAppliances.SelectedRows[0].Index;
                RemoveFromDataGridView(index);
            } // if

            WriteToDataGridView(DgvAppliances, _flatController.Flat.Appliances);
            WriteToTreeView(TrvAppliances, _flatController);

            StlMain.Text = $"Электроприбор удалён. Текущее количество электроприборов: {_flatController.Flat.Count}";

            if(DgvAppliances.RowCount > 0)
                DgvAppliances.Rows[index -= DgvAppliances.RowCount == index ? 1 : 0].Selected = true;

            // сериализация данных
            Save_Command(sender, e);
        } // RemoveAt_Command

        private void RemoveFromTree() =>
            _flatController.Flat.Appliances.Remove(TrvAppliances.SelectedNode.Tag as Appliance);


        private void RemoveFromDataGridView(int index) =>
            _flatController.Flat.RemoveAppliance(index);


        // Включение/выключение выбранного электроприбора
        private void TurnOnOff_Command(object sender, EventArgs e) {
            int index = 0;
            // если нет выбранных элементов - молча уходим
            if (DgvAppliances.SelectedRows.Count == 0 && TrvAppliances.SelectedNode?.Level != 2) return;
            else if (SpcMain.ActiveControl == TrvAppliances) {
                Appliance temp = TrvAppliances.SelectedNode.Tag as Appliance;
                temp.State = !temp.State;
            }
            else {
                index = DgvAppliances.SelectedRows[0].Index;
                _flatController.Flat.ChangeState(index);
            } // if

            WriteToDataGridView(DgvAppliances, _flatController.Flat.Appliances);
            WriteToTreeView(TrvAppliances, _flatController);

            StlMain.Text = $"";

            DgvAppliances.Rows[index].Selected = true;

            // сериализация данных
            Save_Command(sender, e);
        } // TurnOnOff_Command


        // Включение всех электроприборов квартиры
        private void TurnOn_Command(object sender, EventArgs e) {
            _flatController.Flat.TurnOnOff(true);

            WriteToDataGridView(DgvAppliances, _flatController.Flat.Appliances);
            WriteToTreeView(TrvAppliances, _flatController);

            StlMain.Text = $"Все электроприборы включены.";
        } // TurnOn_Command


        // Выключение всех электроприборов квартиры
        private void TurnOff_Command(object sender, EventArgs e) {
            _flatController.Flat.TurnOnOff(false);

            WriteToDataGridView(DgvAppliances, _flatController.Flat.Appliances);
            WriteToTreeView(TrvAppliances, _flatController);

            StlMain.Text = $"Все электроприборы выключены.";
        } // TurnOff_Command


        // Включение всех электроприборов комнаты
        private void TurnOnInRoom_Command(object sender, EventArgs e) {
            if (TrvAppliances?.SelectedNode?.Level != 1) return;

            _flatController.Flat.TurnOnOffInRoom(true, TrvAppliances.SelectedNode.Text);

            StlMain.Text = $"Электроприборы включены в комнате \"{TrvAppliances.SelectedNode.Text}\".";

            WriteToDataGridView(DgvAppliances, _flatController.Flat.Appliances);
            WriteToTreeView(TrvAppliances, _flatController);

        } // TurnOnInRoom_Command


        // Выключение всех электроприборов комнаты
        private void TurnOffInRoom_Command(object sender, EventArgs e) {
            if (TrvAppliances.SelectedNode.Level != 1) return;

            _flatController.Flat.TurnOnOffInRoom(false, TrvAppliances.SelectedNode.Text);


            StlMain.Text = $"Электроприборы выключены в комнате \"{TrvAppliances.SelectedNode.Text}\".";

            WriteToDataGridView(DgvAppliances, _flatController.Flat.Appliances);
            WriteToTreeView(TrvAppliances, _flatController);
        } // TurnOnInRoom_Command


        // сортировка коллекции электроприборов по названию
        private void OrderByName_Command(object sender, EventArgs e) {
            WriteToDataGridView(DgvOrderedAppliances, _flatController.OrderByName());

            // делаем страницу отсортированных данных текущей
            TbcMain.SelectedTab = TbpOrdered;

            // формирование заголовка поля вывода данных
            LblHeaderOrdered.Text = "Коллекция электроприборов упорядочена по названию:"; ;
        } // OrderByName_Command


        // сортировка коллекции электроприборов по состоянию
        private void OrderByState_Command(object sender, EventArgs e) {
            WriteToDataGridView(DgvOrderedAppliances, _flatController.OrderByState());

            // делаем страницу отсортированных данных текущей
            TbcMain.SelectedTab = TbpOrdered;

            // формирование заголовка поля вывода данных
            LblHeaderOrdered.Text = "Коллекция электроприборов упорядочена по состоянию:"; ;
        } // OrderByState_Command


        // сортировка коллекции электроприборов по мощности
        private void OrderByPower_Command(object sender, EventArgs e) {
            WriteToDataGridView(DgvOrderedAppliances, _flatController.OrderByPower());

            // делаем страницу отсортированных данных текущей
            TbcMain.SelectedTab = TbpOrdered;

            // формирование заголовка поля вывода данных
            LblHeaderOrdered.Text = "Коллекция электроприборов упорядочена по мощности:"; ;
        } // OrderByPower_Command


        // сортировка коллекции электроприборов по убыванию цены
        private void OrderByPriceDesc_Command(object sender, EventArgs e) {
            WriteToDataGridView(DgvOrderedAppliances, _flatController.OrderByPriceDesc());

            // делаем страницу отсортированных данных текущей
            TbcMain.SelectedTab = TbpOrdered;

            // формирование заголовка поля вывода данных
            LblHeaderOrdered.Text = "Коллекция электроприборов упорядочена по убыванию цены:"; ;
        } // OrderByPriceDesc_Command


        // Выборка и вывод в отдельной вкладке коллекции электроприборов, с заданным названием
        private void SelectByName_Command(object sender, EventArgs e) {
            // получить список названий из коллекции
            List<string> names = _flatController.GetNames();

            // создание формы выбора названия, передача в окно списка названий
            ChoiceForm choiceForm = new ChoiceForm("Выбор названия", "Название для выборки:", names);

            if (choiceForm.ShowDialog() != DialogResult.OK) return;
            string name = choiceForm.Option;

            LblHeaderSelected.Text = $"Выборка коллекции электроприборов, с заданным названием\n\rНазвание электроприбора: {name}";
            WriteToDataGridView(DgvSelectedAppliances, _flatController.SelectWhereName(name));

            TbcMain.SelectedTab = TbpSelected; ;
        } // SelectByName_Command


        // Выборка и вывод в отдельной вкладке коллекции электроприборов, с заданным состоянием
        private void SelectByState_Command(object sender, EventArgs e) {
            // получить список названий из коллекции
            List<string> states = new List<string>(new string[] { "включен", "выключен" });

            // создание формы выбора состояния, передача в окно списка состояний
            ChoiceForm choiceForm = new ChoiceForm("Выбор состояния", "Состояние для выборки:", states);

            if (choiceForm.ShowDialog() != DialogResult.OK) return;
            string state = choiceForm.Option;

            LblHeaderSelected.Text = $"Выборка коллекции электроприборов, с заданным состоянием\n\rСостояние электроприбора: {state}";
            WriteToDataGridView(DgvSelectedAppliances, _flatController.SelectWhereState(state == "включен"));

            TbcMain.SelectedTab = TbpSelected; ;
        } // SelectByState_Command


        // Разрешаем работу кнопок правки данных о электроприборе только на главной вкладке формы  
        private void TbcMain_SelectedIndexChanged(object sender, EventArgs e) {
            TsbAddAppliance.Enabled = TsbEditAppliance.Enabled =
                TsbRemoveAppliance.Enabled = TsbTurnOff.Enabled =
                TsbTurnOn.Enabled = TsbTurnOnOff.Enabled = 
                MniAppliances.Enabled = 
                TbcMain.SelectedTab == TbpGeneral;
        } // TbcMain_SelectedIndexChanged


        // Добавление электроприбора в коллекцию 
        private void AddAppliance_Command(object sender, EventArgs e) {
            ApplianceForm applianceForm = new ApplianceForm("Добавление электроприбора", "Добавить", _flatController.GetRooms());

            // если окно закрыто не по кнопке BtnOk - молча уходим
            if (applianceForm.ShowDialog() != DialogResult.OK) return;

            // получить данные из свойства формы
            _flatController.Flat.AddAppliance(applianceForm.Appliance);

            WriteToDataGridView(DgvAppliances, _flatController.Flat.Appliances);
            WriteToTreeView(TrvAppliances, _flatController);
            TrvAppliances.ExpandAll();

            StlMain.Text = $"Электроприбор добавлен. Текущее количество электроприборов: {_flatController.Flat.Count}";
            // сериализация данных
            Save_Command(sender, e);
        } // AddAppliance_Command


        // Редактирование выбранного электроприбора
        private void EditAppliance_Command(object sender, EventArgs e) {
            int index = 0;
            Appliance temp;
            // если нет выбранных элементов - молча уходим
            if (DgvAppliances.SelectedRows.Count == 0 && TrvAppliances.SelectedNode?.Level != 2) return;

            else if (SpcMain.ActiveControl == TrvAppliances)
                temp = TrvAppliances.SelectedNode.Tag as Appliance;
            else {
                index = DgvAppliances.SelectedRows[0].Index;
                temp = _flatController.Flat.Appliances[index];
            } // if

            ApplianceForm applianceForm = new ApplianceForm("Редактирование электроприбора", "Сохранить", _flatController.GetRooms());

            applianceForm.Appliance = temp;
            // если окно закрыто не по кнопке BtnOk - молча уходим
            if (applianceForm.ShowDialog() != DialogResult.OK) return;

            // получить данные из свойства формы
            else if (SpcMain.ActiveControl == DgvAppliances)
                _flatController.Flat.EditAppliance(index, applianceForm.Appliance);
            else temp = applianceForm.Appliance;

            WriteToDataGridView(DgvAppliances, _flatController.Flat.Appliances);
            WriteToTreeView(TrvAppliances, _flatController);

            StlMain.Text = $"Электроприбор изменён. Текущее количество электроприборов: {_flatController.Flat.Count}";
            // сериализация данных
            Save_Command(sender, e);
        } // AddAppliance_Command

        private void MainForm_Load(object sender, EventArgs e) => 
            LblAddress.Text = $"Адрес квартиры: {_flatController.Flat.Address}";

        // Редактирование данных квартиры
        private void EditFlat_Command(object sender, EventArgs e) {
            FlatForm flatForm = new FlatForm(_flatController.Flat.Address, _flatController.Flat.Name);

            // если окно закрыто не по кнопке BtnOk - молча уходим
            if (flatForm.ShowDialog() != DialogResult.OK) return;

            // получить данные
            _flatController.Flat.Address = flatForm.Address;
            _flatController.Flat.Name = flatForm.Name;

            // сериализация данных
            Save_Command(sender, e);

            WriteToTreeView(TrvAppliances, _flatController);

            MainForm_Load(sender, e);
        } // EditFlat_Command

        private void DragDrop_Command(object sender, DragEventArgs e) {
            string[] fileNames = (string[])e.Data.GetData(DataFormats.FileDrop);
            _flatController.Flat.Deserialization(fileNames[0]);

            WriteToDataGridView(DgvAppliances, _flatController.Flat.Appliances);
            WriteToTreeView(TrvAppliances, _flatController);
            TrvAppliances.ExpandAll();

            MainForm_Load(sender, e);
            } // LsvAppliances_DragDrop

        private void DragEnter_Command(object sender, DragEventArgs e)  {
            e.Effect = DragDropEffects.Copy;
        } // LsvAppliances_DragEnter


        // коррекция поведения TreeView - при отпускании любой кнопки мыши
        // сделать узел, на котором был клик, текущим 
        private void CorrectBehavor_MouseUp(object sender, MouseEventArgs e) {
            // закомментировано для исключения конфликтов с NodeMouseClick
            TrvAppliances.SelectedNode = TrvAppliances.GetNodeAt(e.Location);
        } // CorrectBehavor_MouseUp
    }
}
