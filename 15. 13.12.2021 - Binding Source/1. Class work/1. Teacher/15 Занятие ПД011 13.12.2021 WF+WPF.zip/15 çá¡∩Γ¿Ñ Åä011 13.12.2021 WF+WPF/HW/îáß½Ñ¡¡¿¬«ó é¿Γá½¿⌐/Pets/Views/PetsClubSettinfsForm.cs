﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pets.Views
{
	public partial class PetsClubSettinfsForm : Form
	{
		public string Title { get; private set; }

		public PetsClubSettinfsForm(string title)
		{
			InitializeComponent();
			TxbTitle.Text = title;

		}

		private void BtnSave_Click(object sender, EventArgs e) =>
			Title = TxbTitle.Text;

		private void PetsClubSettingsForm_FormClosing(object sender, FormClosingEventArgs e)
		{
			if ((DialogResult == DialogResult.OK) & string.IsNullOrWhiteSpace(TxbTitle.Text))
			{
				MessageBox.Show("Введите название", "Ошибка",
					MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				e.Cancel = true;
			}
		}
	}
}
