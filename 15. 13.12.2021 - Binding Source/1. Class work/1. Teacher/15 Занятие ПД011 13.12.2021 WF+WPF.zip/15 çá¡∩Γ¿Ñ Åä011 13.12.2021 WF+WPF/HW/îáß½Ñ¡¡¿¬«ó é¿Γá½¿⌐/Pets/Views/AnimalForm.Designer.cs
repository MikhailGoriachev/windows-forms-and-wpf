﻿
namespace Pets.Views
{
	partial class AnimalForm
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.LblSpecie = new System.Windows.Forms.Label();
			this.CbxSpecies = new System.Windows.Forms.ComboBox();
			this.TxbName = new System.Windows.Forms.TextBox();
			this.LblName = new System.Windows.Forms.Label();
			this.LblAge = new System.Windows.Forms.Label();
			this.LblWeight = new System.Windows.Forms.Label();
			this.LblColor = new System.Windows.Forms.Label();
			this.LblOwner = new System.Windows.Forms.Label();
			this.NudAge = new System.Windows.Forms.NumericUpDown();
			this.NudWeight = new System.Windows.Forms.NumericUpDown();
			this.TxbColor = new System.Windows.Forms.TextBox();
			this.TxbOwner = new System.Windows.Forms.TextBox();
			this.BtnCancel = new System.Windows.Forms.Button();
			this.BtnAdd = new System.Windows.Forms.Button();
			((System.ComponentModel.ISupportInitialize)(this.NudAge)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.NudWeight)).BeginInit();
			this.SuspendLayout();
			// 
			// LblSpecie
			// 
			this.LblSpecie.AutoSize = true;
			this.LblSpecie.Location = new System.Drawing.Point(22, 19);
			this.LblSpecie.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			this.LblSpecie.Name = "LblSpecie";
			this.LblSpecie.Size = new System.Drawing.Size(35, 18);
			this.LblSpecie.TabIndex = 0;
			this.LblSpecie.Text = "Вид";
			// 
			// CbxSpecies
			// 
			this.CbxSpecies.AutoCompleteCustomSource.AddRange(new string[] {
            "Птица",
            "Бык",
            "Кошка",
            "Корова",
            "Собака",
            "Утка",
            "Слон",
            "Рыба",
            "Лошадь",
            "Божья коровка",
            "Леопард",
            "Лев",
            "Лобстер",
            "Кролик",
            "Улитка",
            "Черепаха"});
			this.CbxSpecies.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.CbxSpecies.FormattingEnabled = true;
			this.CbxSpecies.Items.AddRange(new object[] {
            "Птица",
            "Бык",
            "Кошка",
            "Корова",
            "Собака",
            "Утка",
            "Слон",
            "Рыба",
            "Лошадь",
            "Божья коровка",
            "Леопард",
            "Лев",
            "Лобстер",
            "Кролик",
            "Улитка",
            "Черепаха"});
			this.CbxSpecies.Location = new System.Drawing.Point(22, 56);
			this.CbxSpecies.Margin = new System.Windows.Forms.Padding(4);
			this.CbxSpecies.Name = "CbxSpecies";
			this.CbxSpecies.Size = new System.Drawing.Size(180, 26);
			this.CbxSpecies.TabIndex = 1;
			// 
			// TxbName
			// 
			this.TxbName.Location = new System.Drawing.Point(230, 57);
			this.TxbName.Margin = new System.Windows.Forms.Padding(4);
			this.TxbName.Name = "TxbName";
			this.TxbName.Size = new System.Drawing.Size(180, 24);
			this.TxbName.TabIndex = 2;
			// 
			// LblName
			// 
			this.LblName.AutoSize = true;
			this.LblName.Location = new System.Drawing.Point(230, 20);
			this.LblName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			this.LblName.Name = "LblName";
			this.LblName.Size = new System.Drawing.Size(59, 18);
			this.LblName.TabIndex = 3;
			this.LblName.Text = "Кличка";
			// 
			// LblAge
			// 
			this.LblAge.AutoSize = true;
			this.LblAge.Location = new System.Drawing.Point(22, 101);
			this.LblAge.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			this.LblAge.Name = "LblAge";
			this.LblAge.Size = new System.Drawing.Size(80, 18);
			this.LblAge.TabIndex = 4;
			this.LblAge.Text = "Возраст, г";
			// 
			// LblWeight
			// 
			this.LblWeight.AutoSize = true;
			this.LblWeight.Location = new System.Drawing.Point(230, 100);
			this.LblWeight.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			this.LblWeight.Name = "LblWeight";
			this.LblWeight.Size = new System.Drawing.Size(56, 18);
			this.LblWeight.TabIndex = 5;
			this.LblWeight.Text = "Вес, кг";
			// 
			// LblColor
			// 
			this.LblColor.AutoSize = true;
			this.LblColor.Location = new System.Drawing.Point(22, 181);
			this.LblColor.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			this.LblColor.Name = "LblColor";
			this.LblColor.Size = new System.Drawing.Size(42, 18);
			this.LblColor.TabIndex = 6;
			this.LblColor.Text = "Цвет";
			// 
			// LblOwner
			// 
			this.LblOwner.AutoSize = true;
			this.LblOwner.Location = new System.Drawing.Point(230, 180);
			this.LblOwner.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			this.LblOwner.Name = "LblOwner";
			this.LblOwner.Size = new System.Drawing.Size(77, 18);
			this.LblOwner.TabIndex = 7;
			this.LblOwner.Text = "Владелец";
			// 
			// NudAge
			// 
			this.NudAge.DecimalPlaces = 1;
			this.NudAge.Location = new System.Drawing.Point(22, 138);
			this.NudAge.Margin = new System.Windows.Forms.Padding(4);
			this.NudAge.Maximum = new decimal(new int[] {
            -1530494976,
            232830,
            0,
            0});
			this.NudAge.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            131072});
			this.NudAge.Name = "NudAge";
			this.NudAge.Size = new System.Drawing.Size(182, 24);
			this.NudAge.TabIndex = 8;
			this.NudAge.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.NudAge.Value = new decimal(new int[] {
            1,
            0,
            0,
            65536});
			this.NudAge.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Nud_KeyDown);
			// 
			// NudWeight
			// 
			this.NudWeight.DecimalPlaces = 3;
			this.NudWeight.Location = new System.Drawing.Point(230, 137);
			this.NudWeight.Margin = new System.Windows.Forms.Padding(4);
			this.NudWeight.Maximum = new decimal(new int[] {
            -1530494976,
            232830,
            0,
            0});
			this.NudWeight.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            196608});
			this.NudWeight.Name = "NudWeight";
			this.NudWeight.Size = new System.Drawing.Size(182, 24);
			this.NudWeight.TabIndex = 9;
			this.NudWeight.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.NudWeight.Value = new decimal(new int[] {
            1,
            0,
            0,
            65536});
			this.NudWeight.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Nud_KeyDown);
			// 
			// TxbColor
			// 
			this.TxbColor.Location = new System.Drawing.Point(22, 218);
			this.TxbColor.Margin = new System.Windows.Forms.Padding(4);
			this.TxbColor.Name = "TxbColor";
			this.TxbColor.Size = new System.Drawing.Size(180, 24);
			this.TxbColor.TabIndex = 10;
			// 
			// TxbOwner
			// 
			this.TxbOwner.Location = new System.Drawing.Point(230, 217);
			this.TxbOwner.Margin = new System.Windows.Forms.Padding(4);
			this.TxbOwner.Name = "TxbOwner";
			this.TxbOwner.Size = new System.Drawing.Size(180, 24);
			this.TxbOwner.TabIndex = 11;
			// 
			// BtnCancel
			// 
			this.BtnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.BtnCancel.Location = new System.Drawing.Point(265, 264);
			this.BtnCancel.Name = "BtnCancel";
			this.BtnCancel.Size = new System.Drawing.Size(112, 32);
			this.BtnCancel.TabIndex = 13;
			this.BtnCancel.Text = "Отмена";
			this.BtnCancel.UseVisualStyleBackColor = true;
			// 
			// BtnAdd
			// 
			this.BtnAdd.BackColor = System.Drawing.SystemColors.Control;
			this.BtnAdd.DialogResult = System.Windows.Forms.DialogResult.OK;
			this.BtnAdd.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.BtnAdd.Location = new System.Drawing.Point(57, 265);
			this.BtnAdd.Name = "BtnAdd";
			this.BtnAdd.Size = new System.Drawing.Size(112, 32);
			this.BtnAdd.TabIndex = 12;
			this.BtnAdd.Text = "Добавить";
			this.BtnAdd.UseVisualStyleBackColor = false;
			this.BtnAdd.Click += new System.EventHandler(this.BtnAdd_Click);
			// 
			// AnimalForm
			// 
			this.AcceptButton = this.BtnAdd;
			this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.CancelButton = this.BtnCancel;
			this.ClientSize = new System.Drawing.Size(434, 315);
			this.Controls.Add(this.BtnCancel);
			this.Controls.Add(this.BtnAdd);
			this.Controls.Add(this.TxbOwner);
			this.Controls.Add(this.TxbColor);
			this.Controls.Add(this.NudWeight);
			this.Controls.Add(this.NudAge);
			this.Controls.Add(this.LblOwner);
			this.Controls.Add(this.LblColor);
			this.Controls.Add(this.LblWeight);
			this.Controls.Add(this.LblAge);
			this.Controls.Add(this.LblName);
			this.Controls.Add(this.TxbName);
			this.Controls.Add(this.CbxSpecies);
			this.Controls.Add(this.LblSpecie);
			this.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.Margin = new System.Windows.Forms.Padding(4);
			this.MaximizeBox = false;
			this.Name = "AnimalForm";
			this.ShowInTaskbar = false;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "Добавить питомца";
			this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.AnimalForm_FormClosing);
			((System.ComponentModel.ISupportInitialize)(this.NudAge)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.NudWeight)).EndInit();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Label LblSpecie;
		private System.Windows.Forms.ComboBox CbxSpecies;
		private System.Windows.Forms.TextBox TxbName;
		private System.Windows.Forms.Label LblName;
		private System.Windows.Forms.Label LblAge;
		private System.Windows.Forms.Label LblWeight;
		private System.Windows.Forms.Label LblColor;
		private System.Windows.Forms.Label LblOwner;
		private System.Windows.Forms.NumericUpDown NudAge;
		private System.Windows.Forms.NumericUpDown NudWeight;
		private System.Windows.Forms.TextBox TxbColor;
		private System.Windows.Forms.TextBox TxbOwner;
		private System.Windows.Forms.Button BtnCancel;
		private System.Windows.Forms.Button BtnAdd;
	}
}