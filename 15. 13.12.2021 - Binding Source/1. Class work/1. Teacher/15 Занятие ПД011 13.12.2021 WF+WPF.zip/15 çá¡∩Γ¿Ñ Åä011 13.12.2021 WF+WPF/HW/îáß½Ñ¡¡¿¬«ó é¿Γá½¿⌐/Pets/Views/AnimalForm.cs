﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Pets.Models;

namespace Pets.Views
{
	public partial class AnimalForm : Form
	{

		private Animal _animal;

		public Animal Animal
		{
			get => _animal;
			set
			{
				_animal = value;
				TxbColor.Text = _animal.Paint;
				TxbName.Text = _animal.Name;
				TxbOwner.Text = _animal.Owner;
				NudAge.Value = (decimal)_animal.Age;
				NudWeight.Value = (decimal)_animal.Weight;

				// определение количества нужных после запятой чисел и корректировка настроек для Nud установки веса
				int decimalPlaces = _animal.Weight < 0.1 ? (_animal.Weight < 0.01 ? 3 : 2) : 1;
				NudWeight.Increment = (decimal)(1 * Math.Pow(10, -decimalPlaces));
				NudWeight.DecimalPlaces = decimalPlaces;
				
				CbxSpecies.SelectedItem = Animal.Species;
			}
		}

		// Конструктор по умолчанию для ситуации добавления 
		public AnimalForm()
		{
			InitializeComponent();
			_animal = new Animal();
		}

		// Конструктор с параметарми для ситуации изменения
		public AnimalForm(string formTitle, string btnTitle)
		{
			InitializeComponent();
			_animal = new Animal();

			// Заголовок формы и кнопки
			Text = formTitle;
			BtnAdd.Text = btnTitle;
		}

		// Обработчик кнопки "Добавить"/"Сохранить" - собрать данные из элементов
		// интерфейса
		private void BtnAdd_Click(object sender, EventArgs e)
		{
			if (IsEmptyFields()) return;

			_animal = new Animal()
			{
				Name = TxbName.Text,
				Weight = (double)NudWeight.Value,
				Owner = TxbOwner.Text,
				Species = CbxSpecies.Text,
				Age = (double)NudAge.Value,
				Paint = TxbColor.Text,
				IdImage = CbxSpecies.SelectedIndex
			};

		}



		public bool IsEmptyFields() =>
			string.IsNullOrWhiteSpace(TxbName.Text) ||
			string.IsNullOrWhiteSpace(NudWeight.Text) ||
			string.IsNullOrWhiteSpace(TxbColor.Text) ||
			string.IsNullOrWhiteSpace(TxbOwner.Text) ||
			string.IsNullOrWhiteSpace(NudAge.Text);


		private void Nud_KeyDown(object sender, KeyEventArgs e) =>
			e.SuppressKeyPress = e.KeyData == Keys.OemMinus || e.KeyData == Keys.Subtract;

		// Не даём закрыться окну по кнопке подтверждения, если есть пустые поля
		private void AnimalForm_FormClosing(object sender, FormClosingEventArgs e)
		{
			if ((DialogResult == DialogResult.OK) & IsEmptyFields())
			{
				MessageBox.Show("Не все данные заполнены", "Ошибка",
					MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				e.Cancel = true;
			}
		}

	}
}
