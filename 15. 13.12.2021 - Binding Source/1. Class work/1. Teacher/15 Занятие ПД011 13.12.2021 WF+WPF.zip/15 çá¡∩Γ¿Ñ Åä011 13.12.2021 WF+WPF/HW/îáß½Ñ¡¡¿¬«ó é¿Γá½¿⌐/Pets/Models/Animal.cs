﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pets.Models
{
	// Класс Animal, описывающий животное
	public class Animal
	{
		// Идентификатор
		public int Id { get; set; }

		// индекс иконки животного в коллекции ImageList
		private int _idImage;

		public int IdImage
		{
			get => _idImage;
			set
			{
				if (value < 0)
					throw new ArgumentOutOfRangeException($"Недопустимый индекс иконки: {value}");
				_idImage = value;
			}
		}

		// вид животного (те, для которых есть картинка в Animals-mini: кот, лев, слон, рыба, …)
		private string _species;

		public string Species
		{
			get => _species;
			set
			{
				if (string.IsNullOrEmpty(value))
					throw new ArgumentNullException("Пустая строка в указании вида животного");
				_species = value;
			}
		}

		// кличка животного 
		private string _name;

		public string Name
		{
			get => _name;
			set
			{
				if (string.IsNullOrEmpty(value))
					throw new ArgumentNullException("Пустая строка в указании клички животного");
				_name = value;
			}
		}

		// вес животного(в кг)
		private double _weight;

		public double Weight
		{
			get => _weight;
			set
			{
				if (value <= 0)
					throw new ArgumentOutOfRangeException($"Недопустимый вес животного: {value}");

				_weight = value;
			}
		}

		// возраст животного(в годах)
		private double _age;

		public double Age
		{
			get => _age;
			set
			{
				if (value <= 0)
					throw new ArgumentOutOfRangeException($"Недопустимый ввозраст животного: {value}");

				_age = value;
			}
		}

		// цвет(масть) животного
		private string _paint;

		public string Paint
		{
			get => _paint;
			set
			{
				if (string.IsNullOrEmpty(value))
					throw new ArgumentNullException("Пустая строка в указании цвета животного");

				_paint = value;
			}
		}


		// фамилия и инициалы владельца(Иванов И.И., …)
		private string _owner;

		public string Owner
		{
			get => _owner;
			set
			{
				if (string.IsNullOrEmpty(value))
					throw new ArgumentNullException("Пустая строка в указании имени хозяина животного");

				_owner = value;
			}
		}

		// конструкторы
		public Animal() :this(0, "Птица", "Коко", 1, 0.7, "Бурый", "Ларин И.А.")
		{}


		public Animal(int idImage, string species, string name, double weight, double age, string paint, string owner)
		{
			IdImage = idImage;
			Species = species;
			Name = name;
			Weight = weight;
			Age = age;
			Paint = paint;
			Owner = owner;
		}

		public override string ToString() =>
			$" {_name}: [{_idImage}] {_species},{_weight} кг, {_age} лет, {_paint}, хозяин {Owner}";
	}
}
