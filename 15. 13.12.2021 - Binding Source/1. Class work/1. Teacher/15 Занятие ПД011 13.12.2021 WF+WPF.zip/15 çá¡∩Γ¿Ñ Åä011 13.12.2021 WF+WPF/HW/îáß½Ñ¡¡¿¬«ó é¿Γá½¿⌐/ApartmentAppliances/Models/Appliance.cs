﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ApartmentAppliances.Helpers;

namespace ApartmentAppliances.Models
{
	// класс, описывающий электроприбор (название, мощность, цена, состояние прибора: включен/выключен)
    public class Appliance
	{
        // идентификатор прибора
		public int Id { get; set; }

        // название электроприбора
        private string _name;
        public string Name
        {
            get => _name;
            set
            {
                if (string.IsNullOrEmpty(value))
                    throw new ArgumentNullException("Пустая строка в названии прибора");

                _name = value;
            } 
        }


        // комната, в которой расположен электроприбор
        private string _room;
        public string Room
        {
	        get => _room;
	        set
	        {
		        if (string.IsNullOrEmpty(value))
			        throw new ArgumentNullException("Пустая строка в названии комнаты");

		        _room = value;
	        }
        }

        // мощность электроприбора
        private int _power;
        public int Power
        {
            get => _power;
            set
            {
                if (value <= 0)
                    throw new ArgumentOutOfRangeException($"Недопустимая мощность электроприбора: {value}");

                _power = value;
            }
        } 

        // цена электроприбора
        private int _price;
        public int Price
        {
            get => _price;
            set
            {
                if (value <= 0)
                    throw new ArgumentOutOfRangeException($"Недопустимая цена электроприбора: {value}");

                _price = value;
            }
        } 


        // состояние электроприбора: включен/выключен
        private bool _state;
        public bool State
        {
            get => _state;
            set => _state = value;
        }

      
        // ансамбль конструкторов
        public Appliance() : this("чайник", "кухня", 1_200, 3_200, false) 
        { } 


        public Appliance(string name, string room, int power, int price, bool state)
        {
            Name = name;
            Power = power;
            Price = price;
            State = state;
        }

        public int CompareTo(Appliance appliance) => -_price.CompareTo(appliance._price);



        // строковое представление объекта
        override public string ToString() =>
	        $"{_name}: {_power} Вт, {_price} руб., {(_state ? "Включен" : "Выключен")}";


        // формирование строки таблицы, свойство
        public string TableRow =>
	        $" {_name,-22} │ {_power,12:n2} │ {_price,10:n2} │ " +
	        $"{(_state ? "Включен" : "Выключен"),-10}";


        // Шапка таблицы, статическое свойство
        public static string Header =>
	        $"┌────────────────────────┬──────────────┬────────────┬────────────┐\r\n" +
	        $"│ Название прибора       │ Мощность, Вт │ Цена, руб. │ Состояние  │\r\n" +
	        $"├────────────────────────┼──────────────┼────────────┼────────────┤\r\n";

        // Подвал таблицы, статическое свойство
        public static string Footer =>
	        "└────────────────────────┴──────────────┴────────────┴────────────┘";

        // Фабричный метод для создания электроприбора из случайных данных
        public static Appliance Generate()
        {
            (string Name, int Power, int Price)[] data = {
                ("Чайник", 1_200, 2_100), ("Блендер", 300, 900), ("Утюг", 1_100, 1_900),
                ("Миксер", 780, 1_100),   ("Хлебопечка", 1_100, 9_200),
                ("Стиральная машина", 2_100, 13_800), ("Микроволновка", 900, 9_600),
                ("Светильник", 20, 600), ("Панель управления", 20, 900),
                ("Посудомоечная машина", 2_100, 13_000), ("Вертикальный пылесос", 900, 11_300),
                ("Аудиосистема", 500, 12_500), ("Игровая консоль", 200, 25_000), ("ЖК-панель", 115, 50_000),
                ("Компьютер", 600, 100_000), ("Кондиционер", 2_000, 50_000)
            };
            int index = Utils.Random.Next(0, data.Length);

            string[] rooms = {"Кухня", "Зал", "Спальная", "Прихожая"};

            return new Appliance
            {
                _name = data[index].Name,
                _power = data[index].Power,
                _price = data[index].Price,
                _room = rooms[Utils.GetRandom(0, rooms.Length - 1)],
                // сформировать состояние прибора - включен или выключен
                _state = Utils.GetRandom(0, 1) == 1
            };
        }



    }
}
