﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Text;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ApartmentAppliances.Controllers;
using ApartmentAppliances.Models;
using ApartmentAppliances.Helpers;

namespace ApartmentAppliances.Views	
{
	public partial class MainForm : Form
	{
		// идентификаторы изображений для TreeView
		private enum ImgCode { Off, On, Room, Main }


		// Объект контроллера для работы с коллекцией
		private ApplianceNetworkController _applianceNetworkController;


		// Конструкторы
		public MainForm():this(new ApplianceNetworkController())
		{}

		public MainForm(ApplianceNetworkController applianceNetworkController)
		{
			InitializeComponent();
			_applianceNetworkController = applianceNetworkController;

		}

		// Обработка при загрузке формы
		private void MainForm_Load(object sender, EventArgs e)
		{
			TrvMain.LabelEdit = true;

			// Обновить содержимое ListView
			UpdateMainListViewAppliances();

			InitializeTreeView();

			// Обновить заголовок окна
			UpdateMainTitle();

			UpdateGrbText();

			UpdateRoomsCbx();

			StlLabel.Text = $"Устройств в сети: {_applianceNetworkController.ApplianceNetwork.Count}";
		}


		// Обновление заголовка главной формы
		private void UpdateMainTitle()
		{
			// формировка заголовка с проверкой на наличией изменений с последнего сохранения
			StringBuilder sb = new StringBuilder();
			sb.Append(_applianceNetworkController.ApplianceNetwork.Name);
			sb.Append(" - " + _applianceNetworkController.FileName);

			// установка заголовка в форму
			Text = sb.ToString();
		}

		public void UpdateGrbText() => GrbMain.Text = _applianceNetworkController.ApplianceNetwork.Name + ", адрес: " +
		                                              _applianceNetworkController.ApplianceNetwork.Address;

		public void UpdateRoomsCbx()
		{
			TsCbxRoom.Items.AddRange(_applianceNetworkController.ApplianceNetwork.GetRoomsList().ToArray()); 
			TsCbxRoom.SelectedIndex = 0;
		}
		// о программе
		private void About_Command(object sender, EventArgs e) => new AboutForm().ShowDialog();

		// выход из приложения
		private void Exit_Command(object sender, EventArgs e) => Application.Exit();

		// Команда отображения формы изменения данных о ремонтной мастерской
		private void NetworkSettings_Command(object sender, EventArgs e)
		{
			NetworkSettingsForm settingsForm =
				new NetworkSettingsForm(_applianceNetworkController.ApplianceNetwork.Name, 
					_applianceNetworkController.ApplianceNetwork.Address);

			if (settingsForm.ShowDialog() != DialogResult.OK) return;

			_applianceNetworkController.ApplianceNetwork.Name = settingsForm.Title;
			_applianceNetworkController.ApplianceNetwork.Address = settingsForm.Address;

			GrbMain.Text = _applianceNetworkController.ApplianceNetwork.Name + ". Адрес: " +
			               _applianceNetworkController.ApplianceNetwork.Address;

			UpdateMainTitle();

			SaveData();
		}

		#region Обработка TreeView

		// Метод заполнения TreeView коллекцией приборов
		private void InitializeTreeView()
		{
			TrvMain.Nodes.Clear();

			// создание корня - квартира
			TrvMain.Nodes.Add(_applianceNetworkController.ApplianceNetwork.Name, _applianceNetworkController.ApplianceNetwork.Name,
				(int)ImgCode.Main, (int)ImgCode.Main);

			// создание узлов - комнаты, из полученного списка комнат
			_applianceNetworkController.ApplianceNetwork.GetRoomsList().ForEach(name =>
			{
				TrvMain.Nodes[0].Nodes.Add(name, name, (int)ImgCode.Room, (int)ImgCode.Room);
			});

			// заполнение узлов листьями - приборы, все элементы коллекции
			_applianceNetworkController.Appliances.ForEach(ap =>
			{
				int imgInd = ap.State ? (int)ImgCode.On : (int)ImgCode.Off;
				TrvMain.Nodes[0].Nodes[ap.Room].Nodes.Add(ap.Name, ap.Name, imgInd, imgInd);
			});

			// развернуть сформированные узлы дерева 
			TrvMain.ExpandAll();
		}

		// обработка переименования элементов дерева
		private void TrvMain_AfterLabelEdit(object sender, NodeLabelEditEventArgs e)
		{
			if (e.Label == null) return;

			// защита от переименования в пустую строку
			if (string.IsNullOrWhiteSpace(e.Label))
			{
				e.CancelEdit = true;
				MessageBox.Show("Недопустимое название", "Переименование", MessageBoxButtons.OK,
					MessageBoxIcon.Error);
				e.Node.BeginEdit();
				return;
			}

			// проверка уровня вложенности переименовываемого узла
			switch (e.Node.Level)
			{
				// корневой узел - изменение названия квартиры
				case 0:
					_applianceNetworkController.ApplianceNetwork.Name = e.Label;
					UpdateGrbText();
					UpdateMainTitle();
					break;
				// узел уровня комнаты
				case 1:
					// защита от переименования в повторяющееся название комнаты
					if (_applianceNetworkController.ApplianceNetwork.GetRoomsList().Contains(e.Label))
					{
						MessageBox.Show("Название комнаты должно быть уникальным","Переименование комнаты", MessageBoxButtons.OK,
							MessageBoxIcon.Error);
						e.CancelEdit = true;
						e.Node.BeginEdit();
						return;
					}
					// вызов метода переименования комнаты
					_applianceNetworkController.ApplianceNetwork.RenameRoom(e.Node.Text, e.Label);
					break;
				case 2:
					// защита от переименования в повторяющееся название прибора в комнате
					if (_applianceNetworkController.ApplianceNetwork.GetRoomAppliancesNames(e.Node.Parent.Text)
						.Contains(e.Label))
					{
						MessageBox.Show("В этой комнате уже есть прибор с таким названием", "Переименование прибора", MessageBoxButtons.OK,
							MessageBoxIcon.Error);
						e.Node.EndEdit(true);
						return;
					}
					// вызов метода переименования прибора
					_applianceNetworkController.ApplianceNetwork.RenameAppliance(e.Node.Parent.Text, e.Node.Text, e.Label);
					break;
			}
			// завершение редактирования узла и обновление данных в интерфейсе
			e.Node.EndEdit(false);
			UpdateMainListViewAppliances();
			
			SaveData();
		}
		// обработка двойного щелчка мыши по дереву
		private void TrvMain_MouseDoubleClick(object sender, MouseEventArgs e)
		{
			// элемент дерева, в зоне которого было нажатие, если таковой существует
			var node = TrvMain.HitTest(e.Location).Node;
			if (node == null) return;

			// если двойной щелчок был по прибору - изменение его состояние на обратное
			if (node.Level == 2)
			{
				_applianceNetworkController.ApplianceNetwork.InvertApplianceState(node.Parent.Text, node.Text);
				node.ImageIndex = node.SelectedImageIndex = node.ImageIndex == 1 ? 0 : 1;
				UpdateMainListViewAppliances();
			}
		}

		
		// обрыботка события поднятия кнопки мыши
		private void TrvMain_MouseUp(object sender, MouseEventArgs e)
		{
			if (e.Button == MouseButtons.Right)
			{
				// элемент дерева, в зоне которого было нажатие
				var node = TrvMain.GetNodeAt(e.Location);

				if (node is null)
				{
					TrvMain.ContextMenuStrip = CmnForm;
					return;
				}

				// если элемент существует - выделение его в дереве
				TrvMain.SelectedNode = node;

				// Установка соответствующего контекстного меню
				TrvMain.ContextMenuStrip = node.Level switch
				{
					0 => CmnTrvRoot,
					1 => CmnTrvRoom,
					2 => CmnTrvAppl,
					_ => null
				};

				TrvMain.ContextMenuStrip.Show(TrvMain, e.Location);
			}

		}

		private void RenameSelectedNode_Command(object sender, EventArgs e)
		{
			var node = TrvMain.SelectedNode;

			// если уже редактируем - уходим
			if (node == null || node.IsEditing) return;

			// начать редактирование
			node.BeginEdit();
		}

		#endregion


		#region Обработка ListView

		// Обновить содержимого ListView главной вкладки
		private void UpdateMainListViewAppliances() =>
			UpdateListView(LsvAppliances, _applianceNetworkController.Appliances);

		// Метод обновления ListView по параметрам
		private static void UpdateListView(ListView listView, List<Appliance> appliances)
		{
			listView.Items.Clear();

			//if (appliances.Count == 0) return;

			appliances.ForEach(ap => listView.Items.Add(
				new ListViewItem(new[] { "", $"{ap.Name}", $"{ap.Room}", $"{ap.Power}", $"{ap.Price}" }, ap.State ? 1 : 0)));
		}


		// установить выделение в ListView
		private void SetLsvSelectedIndex(int index)
		{
			if (index == -1) return;
			LsvAppliances.Items[index].Selected = true;
			LsvAppliances.Select();
			LsvAppliances.EnsureVisible(index);
		}

		// Обработка нажатий клавиш при фокусе ListView
		private void LsvAppliances_KeyDown(object sender, KeyEventArgs e)
		{
			if (e.KeyCode == Keys.Delete) DeleteAppliance_Command(sender, e);
			if (e.KeyCode == Keys.Enter) EditAppliance_Command(sender, e);
		}

		private void LsvAppliances_MouseDoubleClick(object sender, MouseEventArgs e) =>
			EditAppliance_Command(sender, e);

		private void TbcMain_SelectedIndexChanged(object sender, EventArgs e)
		{
			TstrAdd.Enabled = TstrEdit.Enabled = TstrDelete.Enabled = TstrDeleteAll.Enabled = 
			MnuEditAdd.Enabled = MnuEditEdit.Enabled = MnuEditDelete.Enabled = MnuEditDeleteAll.Enabled =
			TstrOn.Enabled = TstrOff.Enabled = MnuControlOnCurrent.Enabled = MnuControlOffCurrent.Enabled =
					TbcMain.SelectedTab == TbpMain;
		}

		#endregion


		#region Изменение коллекции электроприборов
		// сформировать коллекцию
		private void GenerateCollection_Command(object sender, EventArgs e)
		{
			_applianceNetworkController.ApplianceNetwork.Initialize();
			UpdateMainListViewAppliances();
			
			SaveData();

			TbcMain.SelectedTab = TbpMain;

			// обновить строку состояния
			StlLabel.Text = $"Коллекция приборов переформированна. Текущее количество электроприборов: " +
			                $"{_applianceNetworkController.ApplianceNetwork.Count}";

			InitializeTreeView();
		}

		// добавить прибор
		private void Add_Command(object sender, EventArgs e)
		{
			ApplianceForm applianceForm = new ApplianceForm();

			// отмена добавления
			if (applianceForm.ShowDialog() != DialogResult.OK) 
				return;
			
			// доабвление прибора в текущую коллекцию
			_applianceNetworkController.AddAppliance(applianceForm.Appliance);

			// обновить главный listView
			UpdateMainListViewAppliances();

			// обновить дерево
			InitializeTreeView();

			// установка выделения в конец списка на новый элемент
			SetLsvSelectedIndex(LsvAppliances.Items.Count - 1);

			// обновить строку состояния
			StlLabel.Text = $"Добавлено устройство. Текущее количество электроприборов: " +
			               $"{_applianceNetworkController.ApplianceNetwork.Count}";

			// сохранение изменений в файл
			SaveData();
		}

		// удалить прибор
		private void DeleteAppliance_Command(object sender, EventArgs e)
		{
			if (LsvAppliances.SelectedIndices.Count == 0) return;

			// получить индекс выбранного элемента в ListView
			int index = LsvAppliances.SelectedIndices[0];

			string name = _applianceNetworkController.Appliances[index].Name;
			// удаление записи из коллекции и ListView
			_applianceNetworkController.RemoveAt(index);
			LsvAppliances.Items.RemoveAt(index);

			StlLabel.Text = $"Удалено устройство {name}." +
			                $" Текущее количество электроприборов: " +
			                $"{_applianceNetworkController.ApplianceNetwork.Count}";

			// обновить дерево
			InitializeTreeView();

			// Возврат выделения элемента на место удаленного, если возможно
			int count = LsvAppliances.Items.Count;
			SetLsvSelectedIndex(count != 0 ? (index < count ? index : count - 1) : -1);

			// сохранение изменений в файл
			SaveData();
		}

		// удалить все приборы
		private void DeleteAllAppliances_Command(object sender, EventArgs e)
		{
			// очистка коллекции и элементов интерфейса
			_applianceNetworkController.RemoveAll();
			LsvAppliances.Items.Clear();
			TrvMain.Nodes.Clear();

			StlLabel.Text = "Все устройства удалены.";

			// сохранение изменений в файл
			SaveData();
		}

		private void EditAppliance_Command(object sender, EventArgs e)
		{
			if (LsvAppliances.SelectedIndices.Count == 0) return;

			// получить индекс выбранного элемента в ListView
			int index = LsvAppliances.SelectedIndices[0];

			// передача данных в форму
			ApplianceForm applianceForm = new ApplianceForm("Редактировать данные электроприбора", "Сохранить")
			{
				Appliance = _applianceNetworkController.ApplianceNetwork[index]
			};

			// проверка на подтверджение изменения данных
			if (applianceForm.ShowDialog() != DialogResult.OK)
				return;

			_applianceNetworkController.ApplianceNetwork[index] = applianceForm.Appliance;

			// обновить listview и treeview
			UpdateMainListViewAppliances();
			InitializeTreeView();

			// установка выделения на изменяемый элемент
			SetLsvSelectedIndex(index);

			StlLabel.Text = $"Данные об электроприборе изменены." +
			                $" Текущее количество электроприборов: " +
			                $"{_applianceNetworkController.ApplianceNetwork.Count}";

			SaveData();
		}

		#endregion


		#region Сортировки

		// сортировка по названию
		private void OrderByName_Command(object sender, EventArgs e) =>
			Order(ApplianceNetworkController.OrderByName, "Приборы отсортированны по названию");

		// сотировка по мощности
		private void OrderByPower_Command(object sender, EventArgs e) =>
			Order(ApplianceNetworkController.OrderByPower, "Приборы отсортированны по мощности");

		// сотировка по состоянию
		private void OrderByPower_State(object sender, EventArgs e) =>
			Order(ApplianceNetworkController.OrderByState, "Приборы отсортированны по состоянию");

		// сортировка по убыванию цены
		private void OrderByPriceDesc_State(object sender, EventArgs e) =>
			Order(ApplianceNetworkController.OrderByPriceDesc, "Приборы отсортированны по убыванию цены");

		// метод сортировки копии и вывода в соответствующий listView
		private void Order(Action<List<Appliance>> sorter, string prompt)
		{
			// получить копию коллекции
			List<Appliance> appliances = _applianceNetworkController.Appliances;
			// сортировка копии
			sorter(appliances);
			// отобразить отсортированные элементы в соответствующем listView
			UpdateListView(LsvSorted, appliances);
			// изменение информации о сортировке
			GrbSorted.Text = prompt;
			// установока фокуса на вкладку с оттсортированной коллекции
			TbcMain.SelectedTab = TbpOrder;
		}

		#endregion


		#region Управление состоянием

		// включить все приборы
		private void OnAll_Command(object sender, EventArgs e)
		{
			_applianceNetworkController.TurnOnAll();
			
			UpdateMainListViewAppliances();
			InitializeTreeView();
			
			TbcMain.SelectedTab = TbpMain;
		}

		// выключить все приборы
		private void OffAll_Command(object sender, EventArgs e)
		{
			_applianceNetworkController.TurnOffAll();
			
			UpdateMainListViewAppliances();
			InitializeTreeView();

			TbcMain.SelectedTab = TbpMain;
		}

		// включить выбранный прибор
		private void OnCurrent_Command(object sender, EventArgs e)
		{
			if (LsvAppliances.SelectedIndices.Count == 0) return;

			int index = LsvAppliances.SelectedIndices[0];
			_applianceNetworkController.TurnOnAt(index);

			UpdateMainListViewAppliances();
			InitializeTreeView();

			SetLsvSelectedIndex(index);
			TbcMain.SelectedTab = TbpMain;
		}

		// выключить выбранный прибор
		private void OffCurrent_Command(object sender, EventArgs e)
		{
			if (LsvAppliances.SelectedIndices.Count == 0) return;

			int index = LsvAppliances.SelectedIndices[0];
			_applianceNetworkController.TurnOffAt(index);

			UpdateMainListViewAppliances();
			InitializeTreeView();
			
			SetLsvSelectedIndex(index);
			TbcMain.SelectedTab = TbpMain;
		}


		// Включение всех приборов комнаты из комбобокса
		private void TsbRoomOn_Click(object sender, EventArgs e) => TurnOnRoomAppliances_Command(TsCbxRoom.Text);

		// Выключение всех приборов комнаты из комбобокса
		private void TsbRoomOff_Click(object sender, EventArgs e) => TurnOffRoomAppliances_Command(TsCbxRoom.Text);



		// Включение всех приборов комнаты
		private void TurnOnRoomAppliances_Command(string room)
		{
			_applianceNetworkController.TurnOnAllAtRoom(TsCbxRoom.Text);
			UpdateMainListViewAppliances();
			InitializeTreeView();
		}
		// Выключение всех приборов комнаты
		private void TurnOffRoomAppliances_Command(string room)
		{
			_applianceNetworkController.TurnOffAllAtRoom(room);
			UpdateMainListViewAppliances();
			InitializeTreeView();
		}

		private void TurnOnRoomAppliances_NodeCommand(object sender, EventArgs e)
		{
			var selected = TrvMain.SelectedNode;
			if (selected is null) return;
			TurnOnRoomAppliances_Command(selected.Text);
		}

		private void TurnOffRoomAppliances_NodeCommand(object sender, EventArgs e)
		{
			var selected = TrvMain.SelectedNode;
			if (selected is null) return;
			TurnOffRoomAppliances_Command(selected.Text);
		}

		private void TurnOn_NodeCommand(object sender, EventArgs e)
		{
			var selected = TrvMain.SelectedNode;
			if (selected is null) return;

			_applianceNetworkController.TurnOnAt(
				_applianceNetworkController.ApplianceNetwork.FindIndex(selected.Parent.Text, selected.Text));

			UpdateMainListViewAppliances();
			InitializeTreeView();
		}

		private void TurnOff_NodeCommand(object sender, EventArgs e)
		{
			var selected = TrvMain.SelectedNode;
			if (selected is null) return;

			_applianceNetworkController.TurnOffAt(
				_applianceNetworkController.ApplianceNetwork.FindIndex(selected.Parent.Text, selected.Text));

			UpdateMainListViewAppliances();
			InitializeTreeView();
		}

		#endregion


		#region Выборки

		// Выборка по названию прибора
		private void SelectWhereName_Command(object sender, EventArgs e)
		{
			// Получение списка мастеров
			List<string> names = _applianceNetworkController.ApplianceNetwork.GetAppliancesNames();

			// Создание формы выбора названия
			SelectingForm selectingForm = new SelectingForm(names, "Выберите название прибора:");

			if (selectingForm.ShowDialog() != DialogResult.OK) return;

			List<Appliance> selected = _applianceNetworkController.SelectWhereName(selectingForm.Choosen);

			UpdateListView(LsvSelect, selected);

			GrbSelect.Text = $"Отобраны приборы с названием {selectingForm.Choosen}";

			TbcMain.SelectedTab = TbpSelect;
		}

		// Выборка по состоянию прибора
		private void SelectWhereState_Command(object sender, EventArgs e)
		{
			// Создание формы выбора состояния
			SelectingForm selectingForm = new SelectingForm();

			if (selectingForm.ShowDialog() != DialogResult.OK) return;

			List<Appliance> selected = _applianceNetworkController.SelectWhereState(selectingForm.Choosen != "выключено");

			UpdateListView(LsvSelect, selected);

			GrbSelect.Text = $"Отобраны приборы с названием {selectingForm.Choosen}";

			TbcMain.SelectedTab = TbpSelect;
		}

		#endregion


		#region Сохранение\загрузка
		private void SaveData() => _applianceNetworkController.SaveJsonToFile(_applianceNetworkController.FileName);

		// Обработка команды "сохранить"
		private void Save_Command(object sender, EventArgs e)
		{
			SaveData();
			StlLabel.Text = $"Данные сохранены в файл {_applianceNetworkController.FileName}";
		}

		// Обработка команды "сохранить как"
		private void SaveAs_Command(object sender, EventArgs e)
		{
			// установка директории для выбора файла 
			SfdMain.InitialDirectory = Path.GetDirectoryName(_applianceNetworkController.FileName);

			if (SfdMain.ShowDialog() != DialogResult.OK) return;

			_applianceNetworkController.FileName = SfdMain.FileName;
			_applianceNetworkController.SaveJsonToFile(_applianceNetworkController.FileName);

			StlLabel.Text = $"Данные сохранены в файл {_applianceNetworkController.FileName}";
		}


		// Команда открытия файла
		private void FileOpen_Command(object sender, EventArgs e)
		{
			// установка директории для выбора файла 
			OfdMain.InitialDirectory = Path.GetDirectoryName(_applianceNetworkController.FileName);

			// запуск диалогового окна открытия и проверка на результат
			if (OfdMain.ShowDialog() != DialogResult.OK) return;


			_applianceNetworkController.FileName = OfdMain.FileName;
			_applianceNetworkController.ReadJsonFromFile(_applianceNetworkController.FileName);

			// обновление данных в интерфейсе
			UpdateMainListViewAppliances();
			InitializeTreeView();
			UpdateMainTitle();

			StlLabel.Text = $"Данные загружены из файла {_applianceNetworkController.FileName}";

			GrbMain.Text = _applianceNetworkController.ApplianceNetwork.Name + ", адрес: " +
			               _applianceNetworkController.ApplianceNetwork.Address;

		}

		// Команда создания нового файла коллекции
		private void FileNew_Command(object sender, EventArgs e)
		{
			SaveAs_Command(sender, e);

			NetworkSettings_Command(sender, e);

			// Обновить данные и элементы интерфейса
			_applianceNetworkController.ApplianceNetwork.Initialize();
			UpdateMainListViewAppliances();
			InitializeTreeView();
		}

		#endregion


		#region Команды для трея
		// Команда сворачивания в трей
		private void ToTray_Command(object sender, EventArgs e)
		{
			this.Hide();
			NtiMain.BalloonTipText = _applianceNetworkController.ApplianceNetwork.Name;
			NtiMain.Visible = true;
		}

		// Команда востановления из трея
		private void Restore_Command(object sender, EventArgs e)
		{
			this.Show();
			WindowState = FormWindowState.Normal;
			NtiMain.Visible = false;
		}

		// Восстановление из трея по дабл-клику
		private void CmnTray_MouseDoubleClick(object sender, MouseEventArgs e) =>
			Restore_Command(sender, e);


		#endregion


		#region Смена шрифта и фона

		// Команда смены шрифта
		private void Font_Command(object sender, EventArgs e)
		{
			if (FdlTextFont.ShowDialog() == DialogResult.OK)
				SetFont();
		}

		// Обработка кнопки применить в диалоге смены шрифта
		private void FdlTextFont_Apply(object sender, EventArgs e) => SetFont();

		// Непосредственно установка значения фона
		public void SetFont() => LsvAppliances.Font = FdlTextFont.Font;

		// Команда смены цвета фона
		private void BackColor_Command(object sender, EventArgs e)
		{
			if (CdlBackColor.ShowDialog() == DialogResult.OK)
				LsvAppliances.BackColor = CdlBackColor.Color;
		}

		// Команда смены цвета текста
		private void ForeColor_Command(object sender, EventArgs e)
		{
			if (CdlBackColor.ShowDialog() == DialogResult.OK)
				LsvAppliances.ForeColor = CdlBackColor.Color;
		}
		#endregion


		#region Drag'n'Drop
		private void LsvAppliances_DragEnter(object sender, DragEventArgs e) =>
			e.Effect = e.Data.GetDataPresent(DataFormats.FileDrop) ? DragDropEffects.Move : DragDropEffects.None;

		private void LsvAppliances_DragDrop(object sender, DragEventArgs e)
		{
			if (!e.Data.GetDataPresent(DataFormats.FileDrop))
				return;
			
			_applianceNetworkController.ReadJsonFromFile(((string[])e.Data.GetData(DataFormats.FileDrop))[0]);

			// обновление элементов интерфейса
			UpdateMainTitle();
			UpdateMainListViewAppliances();
			InitializeTreeView();

			GrbMain.Text = _applianceNetworkController.ApplianceNetwork.Name + ", адрес: " +
			               _applianceNetworkController.ApplianceNetwork.Address;

			StlLabel.Text = $"Данные загружены из файла {_applianceNetworkController.FileName}";
		}








		#endregion

	}
}
