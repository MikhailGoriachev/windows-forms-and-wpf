﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;

namespace ApartmentAppliances.Models
{
	// класс, описывающий электрооборудование квартиры: адрес квартиры, коллекция электроприборов
	public class ApplianceNetwork
	{
		// коллекция приборов
		private List<Appliance> _appliances;

		public List<Appliance> Appliances
		{
			get => _appliances; 
			private set => _appliances = value;
		}

		// название сети электроприборов
		private string _name;
		public string Name
		{
			get => _name;
			set
			{
				if (string.IsNullOrEmpty(value))
					throw new ArgumentNullException("Пустая строка в названии электросети");
				_name = value;
			}
		}

		// адрес квартиры
		private string _address;
		public string Address
		{
			get => _address;
			set
			{
				if (string.IsNullOrEmpty(value))
					throw new ArgumentNullException("Пустая строка в указании адреса квартиры");
				_address = value;
			}
		}

		// конструкторы
		public ApplianceNetwork():this(new List<Appliance>(), "Моя квартира", "пр. Мира, 8")
		{}

		public ApplianceNetwork(List<Appliance> appliances, string name, string address)
		{
			Appliances = appliances;
			Name = name;
			Address = address;
		}

		// количество эл-тов в коллекции
		public int Count => Appliances.Count;

		// проверка на наличие элементов
		public bool IsEmpty => Count == 0;

		// реинициализация коллекции
		public void Initialize(int n = 15)
		{
			_appliances.Clear();
			for (int i = 0; i < n; i++)
			{
				var ap = Appliance.Generate();
				ap.Id = i + 1;
				// добавляем порядковый номер к повторяющимся в комнате приборам
				var count = GetRoomAppliancesNames(ap.Room).FindAll(name => name.Contains(ap.Name)).Count;
				if (count > 0)
					ap.Name += $" {count + 1}";
				
				_appliances.Add(ap);
			}
		}
		
		// индексатор
		public Appliance this[int index]
		{
			get
			{
				if (index < 0 || index >= Count)
					throw new IndexOutOfRangeException("Попытка доступа к элементу вне диапазона");
				return _appliances[index];
			}
			set
			{
				if (index < 0 || index >= Count)
					throw new IndexOutOfRangeException("Попытка доступа к элементу вне диапазона");

				_appliances[index] = value;
			}
		}

		// добавление прибора в коллекцию
		public void AddAppliance(Appliance appliance) => _appliances.Add(appliance);

		// удаление выбранного прибора по индексу
		public void RemoveAppliance(int index) => _appliances.RemoveAt(index);

		// удаление выбранного прибора по идентификатору
		public void RemoveApplianceById(int id) => _appliances.Remove(_appliances.Find(ap => ap.Id == id));

		// удаление всех приборов
		public void Clear() => _appliances.Clear();

		// получить индекс прибора по комнате и названию
		public int FindIndex(string room, string name) =>
			_appliances.FindIndex(ap => ap.Room == room && ap.Name == name);
		

		// упорядочивание коллекции по заданному компаратору
		public void OrderBy(Comparison<Appliance> comparison) => _appliances.Sort(comparison);

		public static void OrderBy(List<Appliance> list, Comparison<Appliance> comparison) => list.Sort(comparison);

		// выборка данных из коллекции по заданному предикату
		public List<Appliance> Filter(Predicate<Appliance> predicate) =>
			_appliances.FindAll(predicate);

		// получить список названий приборов
		public List<string> GetAppliancesNames()//=> _appliances.Select(appliance => appliance.Name).Distinct().ToList();
		{
			HashSet<string> names = new HashSet<string>();
			

			_appliances.ForEach(ap => names.Add(ap.Name.TrimEnd(" 0123456789".ToCharArray())));
			
			return names.ToList();
		}

		// получить список комнат
		public List<string> GetRoomsList() // => _appliances.Select(ap => ap.Room).Distinct().ToList();
		{
			SortedSet<string> rooms = new SortedSet<string>();

			_appliances.ForEach(ap => rooms.Add(ap.Room));

			return rooms.ToList();
		}

		// получить список приборов в комнате
		public List<string> GetRoomAppliancesNames(string room) // => 
		{
			HashSet<string> names = new HashSet<string>();

			_appliances.ForEach(ap =>
			{
				if(ap.Room == room) names.Add(ap.Name);
			});

			return names.ToList();
		}

		// переименование комнаты
		public void RenameRoom(string oldName, string newName) => Appliances.ForEach(ap =>
			{
				if (ap.Room == oldName) ap.Room = newName;
			});

		// переименование прибора
		public void RenameAppliance(string room, string oldName, string newName)
		{
			Appliance find = _appliances.Find(ap => ap.Room == room && ap.Name == oldName);
			find.Name = newName;
		}

		// включение/выключение выбранного электроприбора
		public void SetApplianceState(int index, bool state) => _appliances[index].State = state;

		// включение/выключение выбранного электроприбора по id
		public void SetApplianceStateById(int id, bool state)
		{
			var ap = _appliances.Find(ap => ap.Id == id);
			ap.State = state;
		}

		// включение/выключение всех электроприборов квартиры
		public void SetAllAppliancesState(bool state) => _appliances.ForEach(a => a.State = state);

		// обращение текущего состояния прибора
		public void InvertApplianceState(string room, string appliance) => _appliances
			.Where(ap => ap.Room == room && ap.Name == appliance).ToList().ForEach(ap => ap.State = !ap.State);

		// включение/выключение всех электроприборов комнаты
		public void SetAllRoomAppliancesState(string room, bool state) => _appliances.ForEach(a =>
			{
				if (a.Room == room) a.State = state;
			});
	}
}
