﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using H_W14WF.Controllers;
using H_W14WF.Models;
using H_W14WF.View;
using H_W14WF.Views;

namespace H_W14WF
{
    public partial class MainForm : Form
    {
        // контроллер для работы с формой
        private ElectAppliancesController _appliancesController;

        // конструкторы формы
        public MainForm() : this(new ElectAppliancesController()) { }
        public MainForm(ElectAppliancesController appliancesController)
        {
            InitializeComponent();

            // получить контроллер для работы с данными электроприборов в квартире
            _appliancesController = appliancesController;

            // сформировать данные в TreeView
            FillTreeView(_appliancesController.GetAll(), TrvAppliance);
        }// MainForm

        // после готовности всех элементов, после работы конструктора
        // заполнить данными коллекции
        private void MainForm_Load(object sender, EventArgs e)
        {
            Text = _appliancesController.Controller.NameApartment + "; Адрес: " + _appliancesController.Controller.Address;

            WriteToDgvAppliance();

            // вывод в строку состояния
            StlMain.Text = $"Сформировано приборов: {_appliancesController.Count}";
            LblHeaderOrdered.Text = $"Апартаменты: {_appliancesController.Controller.NameApartment} ; Адрес:  { _appliancesController.Controller.Address}\r\n";
        } // MainForm_Load


        private void Exit_Command(object sender, EventArgs e) => Application.Exit();

        private void About_Command(object sender, EventArgs e)
        {
            AboutForm aboutForm = new AboutForm();
            aboutForm.ShowDialog();
        }// About_Command

        // заполнение элемента TreeView
        private void FillTreeView(List<ElectricalAppliance> appliances, TreeView treeView)
        {
            treeView.Nodes.Clear();

            // заполнение словаря для формирования узлов дерева
            //         комната приборы
            Dictionary<string, List<ElectricalAppliance>> nodes = new Dictionary<string, List<ElectricalAppliance>>();
            foreach (var appliance in appliances)
            {
                // новый узел для добавления в дерево
                if (!nodes.ContainsKey(appliance.NameRooms))
                    nodes[appliance.NameRooms] = new List<ElectricalAppliance>();

                // добавить прибор комнаты
                nodes[appliance.NameRooms].Add(appliance);
            } // foreach appliance

            // формирование дерева
            treeView.Nodes.Add("", _appliancesController.Controller.NameApartment, 0, 0);
            foreach (var node in nodes)
            {
                // ссылка на очередной добавляемый узел дерева
                // указываем дважды индекс картинки, чтобы выбранный и невыбранный узлы 
                // выглядели одинаково
                var treeNode = treeView.Nodes[0].Nodes.Add("", node.Key, 1, 1);

                // добавить все приборы комнаты, соответствующей узлу дерева
                foreach (var appliance in node.Value)
                {
                    // индекс картинки для включенного и выключенного состояний приборов
                    int imageIndex = appliance.OffOnn ? 2 : 3;

                    TreeNode aplianceNode = treeNode.Nodes.Add("", appliance.Name, imageIndex, imageIndex);

                    // запомнить ссылку на прибор в теге узла
                    aplianceNode.Tag = appliance;

                    // назначить контекстное меню для прибора
                    aplianceNode.ContextMenuStrip = CmnTreeAppliance;
                }
            } // foreach node

            treeView.ExpandAll();
        } // FillTreeView


        // запись коллекции объектов в DataGridView для табличного отображения
        private void WriteToDgvAppliance()
        {
            int i = 0;
            foreach (var appliance in _appliancesController.Controller.Appliances)
            {               
                // добавить строку
                DgvAppliance.RowCount++;
                // заполнить строку данными
                DgvAppliance[0, i].Value = $"{appliance.NameRooms}"; 
                DgvAppliance[1, i].Value = $"{appliance.Name}";
                DgvAppliance[2, i].Value = appliance.Power;
                DgvAppliance[3, i].Value = $"{appliance.Price:f2}";
                DgvAppliance[4, i].Value = appliance.OffOnn ? "Включен" : "Выключен"; ;
                i++;
            }// foreach appliance

        }// WriteToDgvAppliance


        // свернуть в трей
        private void ToTray_Command(object sender, EventArgs e)
        {
            this.Hide();
            NtiMain.Visible = true;
        } // ToTray_Command


        // восстановить из трея
        private void FromTray_Command(object sender, EventArgs e)
        {
            this.Show();
            WindowState = FormWindowState.Normal;
            NtiMain.Visible = false;
        } // FromTray_Command


        private void NewCollection_Command(object sender, EventArgs e)
        {
            TbcMain.SelectedTab = TbpGeneral;
            _appliancesController.Controller.Initialize(Utils.Random.Next(10, 15));

            WriteToDgvAppliance();

            FillTreeView(_appliancesController.GetAll(), TrvAppliance);

            // обновить строку состояния
            StlMain.Text = $"Коллекция данных сформирована. Текущее количество приборов: {_appliancesController.Count}";
        }// NewCollection_Command


        // yдаление прибора из коллекции, сериализация данных
        private void RemoveAppliance_Command(object sender, EventArgs e)
        {
            TbcMain.SelectedTab = TbpGeneral;
            // ничего не выбрано - молча уходим
            if (DgvAppliance.SelectedRows.Count == 0) return;
            // получить индекс выбранного элемента в DataGridView
            int index = DgvAppliance.SelectedRows[0].Index;

            // удаление записей и из коллекции и из DataGridView
            _appliancesController.Controller.RemoveAt(index);

            DgvAppliance.Rows.RemoveAt(index);

            FillTreeView(_appliancesController.GetAll(), TrvAppliance);
            // сериализация данных
            // _appliancesController.SerializeData();

            // обновить строку состояния
            StlMain.Text = $"Данные удалены. Текущее количество телевизоров: {_appliancesController.Count}";
        }// RemoveAppliance_Command


        // добавление прибора в коллекцию
        private void AddAppliance_Command(object sender, EventArgs e)
        {
            TbcMain.SelectedTab = TbpGeneral;
            ElectApplianceForm applianceForm = new ElectApplianceForm();

            DialogResult dialogResult = applianceForm.ShowDialog();

            // если окно закрыто не по кнопке "Добавить" - молча уходим
            if (dialogResult != DialogResult.OK) return;

            // получить данные из свойства формы
            ElectricalAppliance appliance = applianceForm.Appliance;
            _appliancesController.Controller.AddAppliance(appliance);

            // сериализация данных
           //_appliancesController.SerializeData();

            WriteToDgvAppliance();

            FillTreeView(_appliancesController.GetAll(), TrvAppliance);
            // обновить строку состояния
            StlMain.Text = $"Данные добавлены. Текущее количество приборов: {_appliancesController.Count}";
        }// AddAppliance_Command


        // pедактирование выбранного прибора в отдельной форме
        private void ApplicationEdit_Command(object sender, EventArgs e)
        { 
            // ничего не выбрано - молча уходим
            if (DgvAppliance.SelectedRows.Count == 0) return;

            int index = DgvAppliance.SelectedRows[0].Index;

            // передача данных в форму
            ElectApplianceForm applianceForm = new ElectApplianceForm("Редактировать данные о приборе", "Сохранить");
            
            applianceForm.Appliance = _appliancesController.Controller[index];

            DialogResult dialogResult = applianceForm.ShowDialog();

            // если окно закрыто не по кнопке "Добавить" - молча уходим
            if (dialogResult != DialogResult.OK) return;

            // получить данные
            _appliancesController.Controller[index] = applianceForm.Appliance;

            WriteToDgvAppliance();

            FillTreeView(_appliancesController.GetAll(), TrvAppliance);

            // сериализация данных
            //_appliancesController.SerializeData();

            // обновить строку состояния
            StlMain.Text = $"Данные обновлены. Текущее количество приборов: {_appliancesController.Count}";
        }// ApplicationEdit_Command


        // pедактирование данных о квартире в отдельной форме
        private void ApartmentEdit_Command(object sender, EventArgs e)
        {
            ApartmentEditForm apartmentEdit =
                new ApartmentEditForm(_appliancesController.Controller.NameApartment,_appliancesController.Controller.Address);

            if (apartmentEdit.ShowDialog() != DialogResult.OK) return;

            _appliancesController.Controller.NameApartment = apartmentEdit.Title;
            _appliancesController.Controller.Address = apartmentEdit.Address;

            // сериализация данных
            //_appliancesController.SerializeData();

            Text = _appliancesController.Controller.NameApartment + "; Адрес: " + _appliancesController.Controller.Address;
        }// ApartmentEdit_Command


        #region Сортировка
        // запись отсортированной коллекции объектов в DataGridView для табличного отображения
        private void WriteTbcMainToDataGridView(List<ElectricalAppliance> appliancelist)
        {
            int i = 0;
            foreach (var appliance in appliancelist)
            {
                // добавить строку
                DgvOrdered.RowCount++;
                // заполнить строку данными
                DgvOrdered[0, i].Value = $"{appliance.NameRooms}";
                DgvOrdered[1, i].Value = $"{appliance.Name}";
                DgvOrdered[2, i].Value = appliance.Power;
                DgvOrdered[3, i].Value = $"{appliance.Price:f2}";
                DgvOrdered[4, i].Value = appliance.OffOnn ? "Включен" : "Выключен"; ;
                i++;
            }// foreach appliance

        }// WriteTbcMainToDataGridView

        // сортировка коллекции приборов по наименованию
        private void OrderByNameApplic_Command(object sender, EventArgs e)
        {
            List<ElectricalAppliance> list = _appliancesController.OrderByName();

            WriteTbcMainToDataGridView(list);

            // делаем страницу отсортированных данных текущей
            TbcMain.SelectedTab = TbpOrdered;

            // формирование заголовка поля вывода данных о приборах
            LblHeaderOrder.Text =
              $"{_appliancesController.Controller.NameApartment}, приборы по наименованию\r\n";
        } // OrderByNameApplic_Command

        // сортировка коллекции приборов по состоянию
        private void OrderByState_Command(object sender, EventArgs e)
        {
            List<ElectricalAppliance> list = _appliancesController.OrderByState();

            WriteTbcMainToDataGridView(list);

            // делаем страницу отсортированных данных текущей
            TbcMain.SelectedTab = TbpOrdered;

            // формирование заголовка поля вывода данных о приборах
            LblHeaderOrder.Text =
              $"{_appliancesController.Controller.NameApartment}, приборы по состоянию\r\n";
        } // OrderByState_Command


        // сортировка коллекции приборов по мощности
        private void OrderByPower_Command(object sender, EventArgs e)
        {
            List<ElectricalAppliance> list = _appliancesController.OrderByPower();

            WriteTbcMainToDataGridView(list);

            // делаем страницу отсортированных данных текущей
            TbcMain.SelectedTab = TbpOrdered;

            // формирование заголовка поля вывода данных о приборах
            LblHeaderOrder.Text =
              $"{_appliancesController.Controller.NameApartment}, приборы по мощности\r\n";
        } // OrderByPower_Command


        // сортировка коллекции приборов по цене
        private void OrderByPrice_Command(object sender, EventArgs e)
        {
            List<ElectricalAppliance> list = _appliancesController.OrderByPrice();

            WriteTbcMainToDataGridView(list);

            // делаем страницу отсортированных данных текущей
            TbcMain.SelectedTab = TbpOrdered;

            // формирование заголовка поля вывода данных о приборах
            LblHeaderOrder.Text =
              $"{_appliancesController.Controller.NameApartment}, приборы по убыванию цены\r\n";
        } // OrderByPrice_Command
        #endregion

        #region Выборка записей

        // запись выбранной коллекции объектов в DataGridView для табличного отображения
        private void WriteSelectToDataGridView(List<ElectricalAppliance> appliancelist)
        {
            int i = 0;
            foreach (var appliance in appliancelist)
            {
                // добавить строку
                DgvSelected.RowCount++;
                // заполнить строку данными
                DgvSelected[0, i].Value = $"{appliance.NameRooms}";
                DgvSelected[1, i].Value = $"{appliance.Name}";
                DgvSelected[2, i].Value = appliance.Power;
                DgvSelected[3, i].Value = $"{appliance.Price:f2}";
                DgvSelected[4, i].Value = appliance.OffOnn ? "Включен" : "Выключен"; ;
                i++;
            }// foreach appliance
        }// WriteSelectToDataGridView

        // выборка приборов с заданным наименованием
        private void SelectApplicationName_Command(object sender, EventArgs e)
        {
            // получить список наименований из коллекции приборов
            List<string> names = _appliancesController.Controller.GetNameAppliance;

            // создание формы выбора прибора, передача в окно наименования приборов
            ChoiceForm choiceForm = new ChoiceForm(names);

            if (choiceForm.ShowDialog() != DialogResult.OK) return;

            // выбор прибора произведен, получим наименование, построим выборку
            SelectApplicationName(choiceForm.Names);
        } // SelectApplicationName_Command


        // выборка приборов с заданным состоянием
        private void SelectApplicationState_Command(object sender, EventArgs e)
        {
            // получить список состояний из коллекции приборов
            List<string> states = _appliancesController.GetStates();

            // создание формы выбора прибора, передача в окно состояние приборов
            ChoiceForm choiceForm = new ChoiceForm(states);

            if (choiceForm.ShowDialog() != DialogResult.OK) return;
            string state = choiceForm.Names;

            // выбор прибора произведен, получим состояние, построим выборку
            SelectApplicationState(state == "включен");
        } // SelectApplicationState_Command


        // формирование выборки приборов с заданным наименованием
        private void SelectApplicationName(string name)
        {
            // выбрать приборы с заданным наименованием
            List<ElectricalAppliance> list = _appliancesController.SelectWhereName(name);

            WriteSelectToDataGridView(list);

            // делаем страницу выбранных данных текущей
            TbcMain.SelectedTab = TbpSelected;

            // изменить заголовок выбранных данных
            LblHeaderSelected.Text =
                 $"{_appliancesController.Controller.NameApartment}, приборы c заданным наименованием\r\n";
        } // SelectApplicationName


        // формирование выборки приборов с заданным состоянием
        private void SelectApplicationState(bool state)
        {
            // выбрать приборы с заданным состоянием
            List<ElectricalAppliance> list = _appliancesController.SelectWhereState(state);

            WriteSelectToDataGridView(list);

            // делаем страницу выбранных данных текущей
            TbcMain.SelectedTab = TbpSelected;

            // изменить заголовок выбранных данных
            LblHeaderSelected.Text =
                 $"{_appliancesController.Controller.NameApartment}, приборы c заданным состоянием\r\n";
        } // SelectApplicationState
        #endregion


        #region Включение, выключение приборов
        // Включить выбранный прибор
        private void TurnOnAt_Command(object sender, EventArgs e)
        {
            TbcMain.SelectedTab = TbpGeneral;
            // ничего не выбрано - молча уходим
            if (DgvAppliance.SelectedRows.Count == 0) return;

            int index = DgvAppliance.SelectedRows[0].Index;

            _appliancesController.Controller.TurnOnAt(index);

            WriteToDgvAppliance();

            FillTreeView(_appliancesController.GetAll(), TrvAppliance);

            // обновить строку состояния
            StlMain.Text = $"Прибор включен. Текущее количество приборов: {_appliancesController.Count}";
        }// TurnOnAt_Command

        // Включить все приборы
        private void TurnOnAll_Command(object sender, EventArgs e)
        {
            TbcMain.SelectedTab = TbpGeneral;
            _appliancesController.Controller.TurnOnAll();

            WriteToDgvAppliance();

            FillTreeView(_appliancesController.GetAll(), TrvAppliance);

            // обновить строку состояния
            StlMain.Text = $"Все приборы включены. Текущее количество приборов: {_appliancesController.Count}";
        }// TurnOnAll_Command

        // Команда в контекстном меню CmnTreeAppliance
        private void TurnOnApplianceCmnTree_Command(object sender, EventArgs e)
        {
            TbcMain.SelectedTab = TbpGeneral;
            // если узел не соответствует уровню прибора - уходим
            // 0 -- квартира
            // 1 -- комната
            // 2 -- прибор
            if (TrvAppliance.SelectedNode.Level != 2) return;

            (TrvAppliance.SelectedNode.Tag as ElectricalAppliance).OffOnn = true;
            TrvAppliance.SelectedNode.ImageIndex = TrvAppliance.SelectedNode.SelectedImageIndex = 2;

            // перерисовать DataGridView
            WriteToDgvAppliance();

            FillTreeView(_appliancesController.GetAll(), TrvAppliance);

        } // TurnOnApplianceCmnTree_Command

        // Выключить выбранный прибор
        private void TurnOffAt_Command(object sender, EventArgs e)
        {
            TbcMain.SelectedTab = TbpGeneral;
            // ничего не выбрано - молча уходим
            if (DgvAppliance.SelectedRows.Count == 0) return;

            int index = DgvAppliance.SelectedRows[0].Index;

            _appliancesController.Controller.TurnOffAt(index);

            WriteToDgvAppliance();

            FillTreeView(_appliancesController.GetAll(), TrvAppliance);

            // обновить строку состояния
            StlMain.Text = $"Прибор выключен. Текущее количество приборов: {_appliancesController.Count}";
        }// TurnOffAt_Command

        // Выключить все приборы
        private void TurnOffAll_Command(object sender, EventArgs e)
        {
            TbcMain.SelectedTab = TbpGeneral;
            _appliancesController.Controller.TurnOffAll();

            WriteToDgvAppliance();

            FillTreeView(_appliancesController.GetAll(), TrvAppliance);

            // обновить строку состояния
            StlMain.Text = $"Все приборы выключены. Текущее количество приборов: {_appliancesController.Count}";
        }// TurnOffAll_Command

        // Команда в контекстном меню CmnTreeAppliance
        private void TurnOffApplianceCmnTree_Command(object sender, EventArgs e)
        {
            TbcMain.SelectedTab = TbpGeneral;
            // если узел не соответствует уровню прибора - уходим
            // 0 -- квартира
            // 1 -- комната
            // 2 -- прибор
            if (TrvAppliance.SelectedNode.Level != 2) return;

            // изменения состояния в коллекции и изменение картинки в дереве
            (TrvAppliance.SelectedNode.Tag as ElectricalAppliance).OffOnn = false;
            TrvAppliance.SelectedNode.ImageIndex = TrvAppliance.SelectedNode.SelectedImageIndex = 3;

            // перерисовать DataGridView
            WriteToDgvAppliance();

            FillTreeView(_appliancesController.GetAll(), TrvAppliance);
        } // TurnOnApplianceCmnTree_Command

        #endregion


        // альтернативная коррекция поведения TreeView - по клику на узле (любой кнопкой мыши)
        // сделать узел, на котором был клик, текущим 
        private void CorrectBehavor_NodeMouseClick(object sender, TreeNodeMouseClickEventArgs e)
        {
            TrvAppliance.SelectedNode = e.Node;
        } // CorrectBehavor_NodeMouseClick

        // Загрузка файла данных
        private void LoadFile_Command(object sender, EventArgs e)
        {
            if (OfdMain.ShowDialog() != DialogResult.OK) return;

            // загрузка данных в контроллер
            _appliancesController.DataFileName = OfdMain.FileName;
            _appliancesController.DeserializeData();

            WriteToDgvAppliance();

            FillTreeView(_appliancesController.GetAll(), TrvAppliance);
            // вывести в строку состояния новые данные
            StlMain.Text = $"Приборов в квартире: {_appliancesController.Count}";
        } // LoadFile_Command

        // Сохранить файл данных с выбором имени файла
        private void SaveAsFile_Command(object sender, EventArgs e)
        {
            // выбор имени файла 
            if (SfdMain.ShowDialog() != DialogResult.OK) return;

            _appliancesController.DataFileName = SfdMain.FileName;
            _appliancesController.SerializeData();

            StlMain.Text = $"Данные сохранены в файле {_appliancesController.DataFileName}";
        } // SaveAsFile_Command

        private void Elements_DragEnter(object sender, DragEventArgs e)
        {
            e.Effect = DragDropEffects.Copy;
        }// Elements_DragEnter


        // Приемником перетаскивания сделаем строку ввода
        private void HederAppliance_DragDrop(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.FileDrop))
            {
                // Прием файла, data[] - массив имен файлов
               _appliancesController.DataFileName = ((string[])e.Data.GetData(DataFormats.FileDrop))[0];
               _appliancesController.DeserializeData();

                WriteToDgvAppliance();
                FillTreeView(_appliancesController.GetAll(), TrvAppliance);
            } // if
        } // HederAppliance_DragDrop

    }// class MainForm
}
