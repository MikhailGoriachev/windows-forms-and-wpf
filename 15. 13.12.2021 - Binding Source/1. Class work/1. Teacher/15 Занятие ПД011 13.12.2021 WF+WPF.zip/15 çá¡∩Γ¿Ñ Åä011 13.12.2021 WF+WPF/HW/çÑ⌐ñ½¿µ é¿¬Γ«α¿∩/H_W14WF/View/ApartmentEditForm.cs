﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace H_W14WF.Views
{
	public partial class ApartmentEditForm : Form
	{
		// название квартиры электроприборов
		public string Title { get; private set; }
		// адрес квартиры
		public string Address { get; private set; }

		public ApartmentEditForm(string title, string address)
		{
			InitializeComponent();

			TxbAddress.Text = address;
			TxbTitle.Text = title;
		}// RepairShopEditForm

		private void BtnSave_Click(object sender, EventArgs e)
		{
			Address = TxbAddress.Text;
			Title = TxbTitle.Text;
		}// BtnSave_Click

		private void BtnCancel_Click(object sender, EventArgs e) => Close();

		private void ApartmentSettingsForm_FormClosing(object sender, FormClosingEventArgs e)
		{
			if ((DialogResult == DialogResult.OK)
				& (string.IsNullOrWhiteSpace(TxbTitle.Text) ||
			   string.IsNullOrWhiteSpace(TxbAddress.Text)))
			{
				MessageBox.Show("Не все поля заполнены", "Ошибка",
					MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				e.Cancel = true;
			}
		}// ApartmentSettingsForm_FormClosing
	}// ApartmentEditForm
}
