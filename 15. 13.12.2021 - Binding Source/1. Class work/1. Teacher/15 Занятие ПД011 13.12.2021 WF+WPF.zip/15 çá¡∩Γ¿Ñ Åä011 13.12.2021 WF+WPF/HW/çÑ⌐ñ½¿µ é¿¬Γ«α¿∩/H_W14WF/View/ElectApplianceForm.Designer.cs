﻿
namespace H_W14WF.Views
{
    partial class ElectApplianceForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.GrbInfo = new System.Windows.Forms.GroupBox();
            this.TxbName = new System.Windows.Forms.TextBox();
            this.NudPrice = new System.Windows.Forms.NumericUpDown();
            this.CmbState = new System.Windows.Forms.ComboBox();
            this.CmbPower = new System.Windows.Forms.ComboBox();
            this.LblState = new System.Windows.Forms.Label();
            this.LblPrice = new System.Windows.Forms.Label();
            this.LblPower = new System.Windows.Forms.Label();
            this.LblName = new System.Windows.Forms.Label();
            this.BtnAdd = new System.Windows.Forms.Button();
            this.BtnClose = new System.Windows.Forms.Button();
            this.GrbInfo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.NudPrice)).BeginInit();
            this.SuspendLayout();
            // 
            // GrbInfo
            // 
            this.GrbInfo.BackColor = System.Drawing.Color.Lavender;
            this.GrbInfo.Controls.Add(this.TxbName);
            this.GrbInfo.Controls.Add(this.NudPrice);
            this.GrbInfo.Controls.Add(this.CmbState);
            this.GrbInfo.Controls.Add(this.CmbPower);
            this.GrbInfo.Controls.Add(this.LblState);
            this.GrbInfo.Controls.Add(this.LblPrice);
            this.GrbInfo.Controls.Add(this.LblPower);
            this.GrbInfo.Controls.Add(this.LblName);
            this.GrbInfo.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.GrbInfo.Location = new System.Drawing.Point(20, 16);
            this.GrbInfo.Name = "GrbInfo";
            this.GrbInfo.Size = new System.Drawing.Size(342, 298);
            this.GrbInfo.TabIndex = 0;
            this.GrbInfo.TabStop = false;
            this.GrbInfo.Text = "Данные о электроприборе";
            // 
            // TxbName
            // 
            this.TxbName.Location = new System.Drawing.Point(146, 51);
            this.TxbName.Name = "TxbName";
            this.TxbName.Size = new System.Drawing.Size(190, 24);
            this.TxbName.TabIndex = 16;
            // 
            // NudPrice
            // 
            this.NudPrice.Increment = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.NudPrice.Location = new System.Drawing.Point(146, 109);
            this.NudPrice.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.NudPrice.Minimum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.NudPrice.Name = "NudPrice";
            this.NudPrice.Size = new System.Drawing.Size(190, 24);
            this.NudPrice.TabIndex = 15;
            this.NudPrice.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.NudPrice.Value = new decimal(new int[] {
            10,
            0,
            0,
            0});
            // 
            // CmbState
            // 
            this.CmbState.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CmbState.FormattingEnabled = true;
            this.CmbState.Items.AddRange(new object[] {
            "выключен",
            "включен"});
            this.CmbState.Location = new System.Drawing.Point(146, 229);
            this.CmbState.Name = "CmbState";
            this.CmbState.Size = new System.Drawing.Size(190, 26);
            this.CmbState.TabIndex = 14;
            // 
            // CmbPower
            // 
            this.CmbPower.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CmbPower.FormattingEnabled = true;
            this.CmbPower.Items.AddRange(new object[] {
            "1000",
            "150",
            "180",
            "200",
            "220",
            "240",
            "260",
            "280",
            "300",
            "500"});
            this.CmbPower.Location = new System.Drawing.Point(146, 167);
            this.CmbPower.Name = "CmbPower";
            this.CmbPower.Size = new System.Drawing.Size(190, 26);
            this.CmbPower.Sorted = true;
            this.CmbPower.TabIndex = 13;
            // 
            // LblState
            // 
            this.LblState.Location = new System.Drawing.Point(13, 228);
            this.LblState.Name = "LblState";
            this.LblState.Size = new System.Drawing.Size(121, 24);
            this.LblState.TabIndex = 9;
            this.LblState.Text = "Состояние:";
            // 
            // LblPrice
            // 
            this.LblPrice.Location = new System.Drawing.Point(13, 110);
            this.LblPrice.Name = "LblPrice";
            this.LblPrice.Size = new System.Drawing.Size(114, 24);
            this.LblPrice.TabIndex = 7;
            this.LblPrice.Text = "Цена:";
            // 
            // LblPower
            // 
            this.LblPower.Location = new System.Drawing.Point(13, 169);
            this.LblPower.Name = "LblPower";
            this.LblPower.Size = new System.Drawing.Size(121, 24);
            this.LblPower.TabIndex = 6;
            this.LblPower.Text = "Мощность:";
            // 
            // LblName
            // 
            this.LblName.Location = new System.Drawing.Point(13, 51);
            this.LblName.Name = "LblName";
            this.LblName.Size = new System.Drawing.Size(107, 24);
            this.LblName.TabIndex = 4;
            this.LblName.Text = "Название:";
            // 
            // BtnAdd
            // 
            this.BtnAdd.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.BtnAdd.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.BtnAdd.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BtnAdd.Location = new System.Drawing.Point(20, 355);
            this.BtnAdd.Name = "BtnAdd";
            this.BtnAdd.Size = new System.Drawing.Size(152, 40);
            this.BtnAdd.TabIndex = 12;
            this.BtnAdd.Text = "Добавить";
            this.BtnAdd.UseVisualStyleBackColor = false;
            this.BtnAdd.Click += new System.EventHandler(this.BtnAdd_Click);
            // 
            // BtnClose
            // 
            this.BtnClose.BackColor = System.Drawing.Color.CadetBlue;
            this.BtnClose.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.BtnClose.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BtnClose.Location = new System.Drawing.Point(210, 355);
            this.BtnClose.Name = "BtnClose";
            this.BtnClose.Size = new System.Drawing.Size(152, 40);
            this.BtnClose.TabIndex = 13;
            this.BtnClose.Text = "Отмена";
            this.BtnClose.UseVisualStyleBackColor = false;
            // 
            // ElectApplianceForm
            // 
            this.AcceptButton = this.BtnAdd;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightCyan;
            this.CancelButton = this.BtnClose;
            this.ClientSize = new System.Drawing.Size(380, 416);
            this.Controls.Add(this.BtnClose);
            this.Controls.Add(this.BtnAdd);
            this.Controls.Add(this.GrbInfo);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.MaximizeBox = false;
            this.Name = "ElectApplianceForm";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Добавить электроприбор";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.ApplicationForm_FormClosing);
            this.GrbInfo.ResumeLayout(false);
            this.GrbInfo.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.NudPrice)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox GrbInfo;
        private System.Windows.Forms.Label LblState;
        private System.Windows.Forms.Label LblPrice;
        private System.Windows.Forms.Label LblPower;
        private System.Windows.Forms.Label LblName;
        private System.Windows.Forms.Button BtnAdd;
        private System.Windows.Forms.Button BtnClose;
        private System.Windows.Forms.ComboBox CmbPower;
        private System.Windows.Forms.ComboBox CmbState;
        private System.Windows.Forms.NumericUpDown NudPrice;
        private System.Windows.Forms.TextBox TxbName;
    }
}