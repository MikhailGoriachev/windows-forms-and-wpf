﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace H_W14WF.Models
{
    // Класс, описывающий электрооборудование квартиры:
    // *адрес квартиры,
    // *коллекция электроприборов
    [DataContract]
    public class AppliancesController
    {
        // коллекция приборов
        [DataMember]
        private List<ElectricalAppliance> _apliances;

        public List<ElectricalAppliance> Appliances {
            get => _apliances;
            private set => _apliances = value;
        }

        // адрес квартиры
        [DataMember]
        private string _address;
        public string Address
        {
            get => _address;
            set
            {
                if (string.IsNullOrEmpty(value))
                    throw new ArgumentNullException("AppliancesController: Пустая строка в указании адреса квартиры");
                _address = value;
            }
        }// Address

        // название квартиры
        [DataMember]
        private string _nameApartment;
        public string NameApartment
        {
            get => _nameApartment;
            set
            {
                if (string.IsNullOrEmpty(value))
                    throw new ArgumentNullException("AppliancesController: Пустая строка в указании названия квартиры");
                _nameApartment = value;
            }
        }// NameApartment


        // конструкторы для получения коллекции приборов
        public AppliancesController() : this(new List<ElectricalAppliance>(), "ул.Университетская, 12, д.8, кв.34", "Солнечный изумруд")
        {
            // создание коллекции приборов
            Initialize(Utils.Random.Next(10, 15));
        } // AppliancesController
        public AppliancesController(List<ElectricalAppliance> apliances, string address, string nameApartment)
        {
            _apliances     = apliances;
            _address       = address;
            _nameApartment = nameApartment;
        }// AppliancesController

        // количестово приборов в коллекции
        public int Count => _apliances.Count;

        public void Initialize(int n)
        {
            _apliances.Clear();
            for (int i = 0; i < n; i++)
                _apliances.Add(ElectricalAppliance.Create());
        }// Initialize


        // индексатор для электроприборов
        public ElectricalAppliance this[int index]
        {
            get => _apliances[index];
            set => _apliances[index] = value;
        } // indexer

        // упорядочивание коллекции по заданному компаратору
        public void OrderBy(Comparison<ElectricalAppliance> comparison) =>
            _apliances.Sort(comparison);

        // включение всех приборов
        public void TurnOnAll() =>
            _apliances.ForEach(a => a.OffOnn = true);


        // выключение всех приборов
        public void TurnOffAll() =>
            _apliances.ForEach(a => a.OffOnn = false);

        // включение выбранного прибора
        public void TurnOnAt(int index) => _apliances[index].OffOnn = true;


        // выключение выбранного прибора
        public void TurnOffAt(int index) => _apliances[index].OffOnn = false;


        // выборка данных из коллекции по заданному предикату
        public List<ElectricalAppliance> Filter(Predicate<ElectricalAppliance> predicate) =>
            _apliances.FindAll(predicate);


        // Получить список названия электроприборов
        public List<string> GetNameAppliance => _apliances.Select(ap => ap.Name).Distinct().ToList();

        // удаление выбранного прибора
        public void RemoveAt(int index) => _apliances.RemoveAt(index);

        // удаление всех приборов
        public void RemoveAll() => _apliances.Clear();


        // добавление прибора в коллекцию
        public void AddAppliance(ElectricalAppliance appliance) => _apliances.Add(appliance);


    }// class AppliancesController
}
