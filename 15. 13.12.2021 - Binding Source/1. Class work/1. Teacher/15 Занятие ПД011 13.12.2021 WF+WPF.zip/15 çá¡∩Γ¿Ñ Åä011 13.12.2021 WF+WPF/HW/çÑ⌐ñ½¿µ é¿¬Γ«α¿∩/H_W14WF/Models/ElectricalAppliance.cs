﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace H_W14WF.Models
{
    /// <summary>
    /// Доработайте класс, описывающий электроприбор (
    /// *название,
    /// *мощность,
    /// *цена,
    /// *включен/выключен) 
    /// *название комнаты, в которой размещен прибор (кухня, прихожая, …)
    /// </summary>
    [DataContract]
    public class ElectricalAppliance
    {
        // название
        [DataMember]
        private string _name;
        public string Name
        {
            get => _name;
            set
            {
                if (string.IsNullOrEmpty(value))
                    throw new ArgumentNullException("ElectricalAppliance: Пустая строка в названии прибора");
                _name = value;
            }
        }// Name

        // мощность(Вт)
        [DataMember]
        private int _power;
        public int Power
        {
            get => _power;
            set
            {
                if (value <= 0)
                    throw new ArgumentOutOfRangeException($"ElectricalAppliance: Недопустимая мощность электроприбора: {value}");
                _power = value;
            }
        }// Power

        // цена(рубл.)
        [DataMember]
        private double _price;
        public double Price
        {
            get => _price;
            set
            {
                if (value <= 0)
                    throw new ArgumentOutOfRangeException($"ElectricalAppliance: Недопустимая цена электроприбора: {value}");
                _price = value;
            }
        }// Price

        // включен/выключен электроприбор
        [DataMember]
        private bool _OffOnn;
        public bool OffOnn { get => _OffOnn; set => _OffOnn = value; }

        // название комнаты
        [DataMember]
        private string _nameRooms;
        public string NameRooms {
            get => _nameRooms;
            set {
                if (string.IsNullOrEmpty(value))
                    throw new ArgumentNullException("ElectricalAppliance: Пустая строка в названия комнаты");
                _nameRooms = value;
            }
        }// NameRooms

        // ансамбль конструкторов
        public ElectricalAppliance() : this("микроволновка", 1000, 2500d, false, "кухня") { }

        public ElectricalAppliance(string name, int power, double price, bool state, string rooms)
        {
            Name      = name;
            Power     = power;
            Price     = price;
            OffOnn    = state;
            NameRooms = rooms;
        } // ElectricalAppliance

        // строковое представление объекта
        override public string ToString() =>
         $"{_nameRooms}: {_name,-22}: {_power,8} Вт, {_price,14:f2} руб., {(_OffOnn ? "Включен" : "Выключен"),-12}";

        // вывод в табличном формате 
        public string TableRow()
        {
            string state = _OffOnn ? "Включен" : "Выключен";
            return $"│{_nameRooms, -15} │ {_name,-18} │ {_power,8} │ {_price,10:f2} │ {state,-12} │";
        }

        // фабрика, создающая данные о электроприборе
        public static ElectricalAppliance Create()
        {
            // название комнат
            string[] nameRooms = {
                "коридор", "кухня", "прихожая", "зал", "спальня"
            };

            string rooms = nameRooms[Utils.Random.Next(0, nameRooms.Length)];

            // название электроприбора
            string[] names = {
                "холодильник", "микроволновка", "духовая печь",
                "мультиварка", "кофемашина", "бойлер", "эл.чайник",
                "кофемашина", "тостер", "кух.комбайн", "фен", "торшер",
                "плойка", "миксер", "светильник", "телевизор", "магнитофон"
            };

            string name = names[Utils.Random.Next(0, names.Length)];

            // мощность в Ватт
            int power = Utils.Random.Next(100, 250);

            // цена(рубл.)
            double price = Utils.GetRandom(1_500d, 30_000d);

            // включен/выключен прибор
            bool offOnn = Utils.Random.Next(0, 3) == 1;

            // создать и вернуть объект данных
            return new ElectricalAppliance { NameRooms = rooms, Name = name, Power = power, Price = price, OffOnn = offOnn };
        } // Create

    }// class ElectricalAppliance
}
