﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Json;
using System.Text;
using System.Threading.Tasks;
using H_W14WF.Models;

namespace H_W14WF.Controllers
{
 /*
 * Реализация функционала приложения
 *     • Упорядочивание коллекции электроприборов
 *         o По названию
 *         o По состоянию
 *         o По мощности
 *         o По убыванию цены
 *     • Выборка в коллекцию электроприборов с заданным названием
 *     • Выборка в коллекцию электроприборов заданного состояния
 */
    public class ElectAppliancesController
    {
        // объект для обработки
        private AppliancesController _controller;

        public AppliancesController Controller
        {
            get => _controller;
            private set => _controller = value;
        }// Controller

        // имя файля для сохранения
        public string DataFileName { get; set; }


        // конструкторы
        // при создании AppliancesController конструктором по умолчанию вызывается
        // метод формирования коллекции электроприборов
        public ElectAppliancesController() : this(new AppliancesController(), ".\\App_Data\\appliances.json") 
        {
            _controller.OrderBy((a1, a2) => a1.NameRooms.CompareTo(a2.NameRooms));
        }

        public ElectAppliancesController(AppliancesController controller, string fileName)
        {
            _controller = controller;
            DataFileName = fileName;
        } // ElectAppliancesController


        public List<ElectricalAppliance> GetAll() => _controller.Appliances;

        public int Count => _controller.Appliances.Count;

        // Запрос на упорядочивание копии коллекции по названию электроприбора
        public List<ElectricalAppliance> OrderByName()
        {
            // получить копию коллекции электроприборов
            List<ElectricalAppliance> list = new List<ElectricalAppliance>(Controller.Appliances);

            // упорядочить копию коллекции электроприборов и вернуть эту копию
            list.Sort((el1, el2) => el1.Name.CompareTo(el2.Name));
            return list;
        } // OrderByName

        // Запрос на упорядочивание копии коллекции по состоянию электроприбора
        public List<ElectricalAppliance> OrderByState()
        {
            // получить копию коллекции электроприборов
            List<ElectricalAppliance> list = new List<ElectricalAppliance>(Controller.Appliances);

            // упорядочить копию коллекции электроприборов и вернуть эту копию
            list.Sort((el1, el2) => el1.OffOnn.CompareTo(el2.OffOnn));
            return list;
        } // OrderByState

        // Запрос на упорядочивание копии коллекции по мощности электроприбора
        public List<ElectricalAppliance> OrderByPower()
        {
            // получить копию коллекции электроприборов
            List<ElectricalAppliance> list = new List<ElectricalAppliance>(Controller.Appliances);

            // упорядочить копию коллекции электроприборов и вернуть эту копию
            list.Sort((el1, el2) => el1.Power.CompareTo(el2.Power));
            return list;
        } // OrderByPower

        // Запрос на упорядочивание копии коллекции по убыванию цены электроприбора
        public List<ElectricalAppliance> OrderByPrice()
        {
            // получить копию коллекции электроприборов
            List<ElectricalAppliance> list = new List<ElectricalAppliance>(Controller.Appliances);

            // упорядочить копию коллекции электроприборов и вернуть эту копию
            list.Sort((el1, el2) => el2.Price.CompareTo(el1.Price));
            return list;
        } // OrderByPrice

        // Запрос на выборку в коллекцию электроприборов с заданным названием
        public List<ElectricalAppliance> SelectWhereName(string name) =>
            _controller.Filter(el => el.Name == name);

        // Запрос на выборку в коллекцию электроприборов с заданным состоянием
        public List<ElectricalAppliance> SelectWhereState(bool state) =>
            _controller.Filter(el => el.OffOnn == state);

        // список состояний электроприборов из коллекции
        public List<string> GetStates()
        {
            Dictionary<string, int> states = new Dictionary<string, int>();

            _controller.Appliances.ForEach(t => states[t.OffOnn ? "включен" : "выключен"] = 0);

            return states.Keys.ToList();
        } // GetStates

        // сериализация данных в формате JSON
        public void SerializeData()
        {
            DataContractJsonSerializer jsonFormatter = new DataContractJsonSerializer(typeof(AppliancesController));

            // Запись объекта в JSON-файл
            using (FileStream fs = new FileStream(DataFileName, FileMode.Create))
            {
                jsonFormatter.WriteObject(fs, _controller);
            } // using
        } // SerializeData

        // десериализация данных из формата JSON
        public void DeserializeData()
        {
            DataContractJsonSerializer jsonFormatter = new DataContractJsonSerializer(typeof(AppliancesController));

            // Читаем коллекцию из JSON-файла
            using (FileStream fs = new FileStream(DataFileName, FileMode.OpenOrCreate))
            {
                _controller = (AppliancesController)jsonFormatter.ReadObject(fs);
            } // using
        } // DeserializeData

    }// ElectAppliancesController
}
