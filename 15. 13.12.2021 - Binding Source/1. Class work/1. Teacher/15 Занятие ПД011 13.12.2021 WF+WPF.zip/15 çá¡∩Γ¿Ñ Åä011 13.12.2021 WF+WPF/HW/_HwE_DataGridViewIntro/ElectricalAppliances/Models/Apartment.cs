﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ElectricalAppliances.Helpers;

namespace ElectricalAppliances.Models
{
    // Класс, представляющий квартиру с коллекцией электроприборов:
    //     • Адрес квартиры
    //     • Коллекция электроприборов
    // Обработки
    //     • Формирование коллекции электроприборов
    //     • Добавление электроприбора в коллекцию
    //     • Удаление электроприбора из коллекцию по индексу
    //     • Сортировка по компаратору
    //     • Выборка по предикату
    //     • Включение/выключение электроприбора по индексу
    //     • Включение/выключение всех электроприборов квартиры
    public class Apartment
    {
        // адрес квартиры
        private string _address;
        public string Address {
            get => _address;
            set {
                if (string.IsNullOrEmpty(value))
                    throw new ArgumentNullException("Пустая строка в названии прибора");

                _address = value;
            } // set
        } // Address

        // коллекция электроприборов квартиры
        private List<Appliance> _appliances;
        public List<Appliance> Appliances {
            get => _appliances;
            set => _appliances = value;
        } // Appliances


        #region Ансамбль конструкторов

        public Apartment() : this("", new List<Appliance>()) { } // Apartment

        public Apartment(string address, List<Appliance> listAppliances) {
            _address = address;
            _appliances = listAppliances;
        } // Apartment
        #endregion


        // формирование адреса квартиры, коллекции электроприборов
        public void Generate(int n = 12) {
            // получить адрес из нескольких предподготовленных адресов
            _address = Utils.GetAddress();

            // сформировать коллекцию приборов
            _appliances.Clear();

            // формирование (почти) неповторяющегося идентификатора - за счет
            // ширины диапазона генерации случайных чисел
            for (int i = 0; i < n; i++) {
                _appliances.Add(Appliance.Generate(Utils.GetRandom(1_000, 10_000)));
            } // for i

            // сортировать данные квартиры по комнатам
            _appliances.Sort((a1, a2) => a1.Room.CompareTo(a2.Room));
        } // Generate


        // Добавление электроприбора в коллекцию
        public void Add(Appliance appliance) => _appliances.Add(appliance);

        // Удаление электроприбора из коллекцию по индексу
        public void RemoveAt(int index) => _appliances.RemoveAt(index);


        // индексатор для изменения электроприбора по индексу
        public Appliance this[int index] {
            get => _appliances[index];
            set => _appliances[index] = value;
        } // indexer


        // упорядочивание коллекции по заданному компаратору
        public void OrderBy(Comparison<Appliance> comparison) =>
            _appliances.Sort(comparison);
          

        // упорядочивание копии коллекции по заданному компаратору
        public List<Appliance> OrderCopyBy(Comparison<Appliance> comparison) {
            // получить копию коллекции электроприборов 
            List<Appliance> listAppliances = new List<Appliance>(_appliances);

            // упорядочить копию коллекции электроприборов и вернуть эту копию
            listAppliances.Sort(comparison);
            return listAppliances;
        } // OrderCopyBy


        // выборка данных из коллекции по заданному предикату
        public List<Appliance> Filter(Predicate<Appliance> predicate) =>
            _appliances.FindAll(predicate);
            

        // включение/выключение электроприбора по его индексу
        public void TurnAt(int index, bool mode) => _appliances[index].State = mode;


        // включение/выключение всех электроприборов коллекции
        public void TurnAll(bool mode) => _appliances.ForEach(a => a.State = mode);
    } // class Apartment
}
