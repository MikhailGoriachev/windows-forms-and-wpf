﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using ElectricalAppliances.Controllers;
using ElectricalAppliances.Models;

namespace ElectricalAppliances.Views
{
    public partial class MainForm : Form
    {
        // контроллер для обработки данных по заданию
        private ApartmentController _apartmentController;

        public MainForm():this(new ApartmentController()) {} // MainForm

        public MainForm(ApartmentController apartmentController) {
            InitializeComponent();

            // получить данные по контроллеру 
            _apartmentController = apartmentController;

            // Вывести адрес квартиры
            LblApartmentInfo.Text = _apartmentController.Apartment.Address;

            // сформировать данные в ListView: приборы, отсортированные приборы, выборка по наименованию
            FillDataGridView(_apartmentController.GetAll(), DgvAppliances);
            FillDataGridView(_apartmentController.OrderByBrand(), DgvOrdered);
            FillDataGridView(_apartmentController.SelectWhereName(_apartmentController.GetAll()[0].Name), DgvFiltered);

            // сформировать данные в TreeView
            FillTreeView(_apartmentController.GetAll(), TrvApartment);

            // Сформировать заголовок вкладки отсортированной коллекции
            TbpSorted.Text += ": по названию";

            // вывести количество приборов квартире
            TslStatus.Text = $"Количество приборов в квартире: {_apartmentController.Count}";
            TslOn.Text = $"Включено: {_apartmentController.SelectWhereState(true).Count}";
            TslOff.Text = $"Выключено: {_apartmentController.SelectWhereState(false).Count}";

            // вывести имя файла данных в строку состояния
            TslFileName.Text = $"Файл данных: {_apartmentController.FileName}";
        } // MainForm


        // вывод коллекции электроприборов в DataGridView,
        // состояние прибора отображать цветом фона ячейки
        public void FillDataGridView(List<Appliance> appliances, DataGridView dataGridView) {
            dataGridView.Rows.Clear();

            appliances.ForEach(a => dataGridView.Rows.Add(a.ToDataGridViewRow()));
        } // FillDataGridView


        // заполнение элемента TreeView
        private void FillTreeView(List<Appliance> appliances, TreeView treeView) {
            treeView.Nodes.Clear();

            // заполнение словаря для формирования узлов дерева
            //         комната приборы
            Dictionary<string, List<Appliance>> nodes = new Dictionary<string, List<Appliance>>();
            foreach (var appliance in appliances) {
                // новый узел для добавления в дерево
                if (!nodes.ContainsKey(appliance.Room))
                    nodes[appliance.Room] = new List<Appliance>();
                
                // добавить прибор комнаты
                nodes[appliance.Room].Add(appliance);
            } // foreach appliance

            // формирование дерева
            treeView.Nodes.Add("", _apartmentController.Apartment.Address, 2, 2);
            foreach (var node in nodes) {
                // ссылка на очередной добавляемый узел дерева
                // указываем дважды индекс картинки, чтобы выбранный и невыбранный узлы 
                // выглядели одинаково
                var treeNode = treeView.Nodes[0].Nodes.Add("", node.Key, 3, 3);

                // назначить контекстное меню комнате
                treeNode.ContextMenuStrip = CmnTreeRoom;

                // добавить все приборы комнаты, соответствующей узлу дерева
                foreach (var appliance in node.Value) {
                    // индекс картинки для включенного и выключенного состояний приборов
                    int imageIndex = appliance.State ? 1 : 0;

                    TreeNode aplianceNode = treeNode.Nodes.Add("", appliance.Name, imageIndex, imageIndex);
               
                    // запомнить ссылку на прибор в теге узла
                    aplianceNode.Tag = appliance;

                    // назначить контекстное меню для прибора
                    aplianceNode.ContextMenuStrip = CmnTreeAppliance;
                }
            } // foreach node

            treeView.ExpandAll();
        } // FillTreeView


        // завершение приложения
        private void Exit_Command(object sender, EventArgs e) => Application.Exit();


        // свернуть в трей
        private void ToTray_Command(object sender, EventArgs e) {
            this.Hide();
            NtfMain.Visible = true;
        } // ToTray_Command


        // восстановить из трея
        private void FromTray_Command(object sender, EventArgs e) {
            this.Show();
            WindowState = FormWindowState.Normal;
            NtfMain.Visible = false;
        } // FromTray_Command


        // вывод формы со сведениями о приложении и разработчике
        private void About_Command(object sender, EventArgs e) {
            AboutForm aboutForm = new AboutForm();
            aboutForm.ShowDialog();
        } // About_Command


        // включить все приборы
        private void TurnOnAll_Commad(object sender, EventArgs e) {
            TbcMain.SelectedTab = TbpAppliances;

            // собственно включение всех приборов 
            _apartmentController.TurnAll(true);

            // обновить отображение приборов
            FillDataGridView(_apartmentController.Apartment.Appliances, DgvAppliances);
            FillTreeView(_apartmentController.GetAll(), TrvApartment);

            TslOn.Text = $"Включено: {_apartmentController.SelectWhereState(true).Count}";
            TslOff.Text = $"Выключено: {_apartmentController.SelectWhereState(false).Count}";
        } // TurnOnAll_Commad


        // выключить все приборы
        private void TurnOffAll_Commad(object sender, EventArgs e) {
            TbcMain.SelectedTab = TbpAppliances;

            // собственно выключение всех приборов 
            _apartmentController.TurnAll(false);

            // обновить отображение приборов
            FillDataGridView(_apartmentController.Apartment.Appliances, DgvAppliances);
            FillTreeView(_apartmentController.GetAll(), TrvApartment);

            TslOn.Text = $"Включено: {_apartmentController.SelectWhereState(true).Count}";
            TslOff.Text = $"Выключено: {_apartmentController.SelectWhereState(false).Count}";
        } // TurnOffAll_Commad


        // включение выбранного прибора
        private void TurnOnSelected_Command(object sender, EventArgs e) {
            // выход, если нет выбранного прибора
            if (DgvAppliances.SelectedRows.Count == 0) return;

            int index = DgvAppliances.SelectedRows[0].Index;
            _apartmentController.TurnAt(index, true);

            DgvAppliances[1, index].Value = _apartmentController.Apartment[index].State?"Включен":"Выключен";
            DgvAppliances[1, index].Style.BackColor = _apartmentController.Apartment[index].State? Color.LightSeaGreen : Color.LightPink; 
            DgvAppliances.Rows[index].Selected = true;

            TslOn.Text = $"Включено: {_apartmentController.SelectWhereState(true).Count}";
            TslOff.Text = $"Выключено: {_apartmentController.SelectWhereState(false).Count}";

            // перерисовать дерево
            FillTreeView(_apartmentController.GetAll(), TrvApartment);
        } // TurnOnSelected_Command


        // выключение выбранного в DataGridView прибора
        private void TurnOffSelected_Command(object sender, EventArgs e) {
            // выход, если нет выбранного прибора
            if (DgvAppliances.SelectedRows.Count == 0) return;

            int index = DgvAppliances.SelectedRows[0].Index;
            _apartmentController.TurnAt(index, false);

            // визуализация изменения
            DgvAppliances[1, index].Value = _apartmentController.Apartment[index].State ? "Включен" : "Выключен";
            DgvAppliances[1, index].Style.BackColor = _apartmentController.Apartment[index].State ? Color.LightSeaGreen : Color.LightPink;
            DgvAppliances.Rows[index].Selected = true;

            TslOn.Text = $"Включено: {_apartmentController.SelectWhereState(true).Count}";
            TslOff.Text = $"Выключено: {_apartmentController.SelectWhereState(false).Count}";

            // перерисовать дерево
            FillTreeView(_apartmentController.GetAll(), TrvApartment);
        } // TurnOffSelected_Command


        // сортировка коллекции по названию прибора
        private void OrderByName_Command(object sender, EventArgs e) {
            TbcMain.SelectedTab = TbpSorted;

            FillDataGridView(_apartmentController.OrderByBrand(), DgvOrdered);

            // скорректировать название вкладки
            TbpSorted.Text = TbpSorted.Text.Remove(TbpSorted.Text.IndexOf(":")+1) + " по названию";
        } // OrderByName_Command


        // сортировка коллекции по состоянию прибора
        private void OrderByState_Command(object sender, EventArgs e) {
            TbcMain.SelectedTab = TbpSorted;

            FillDataGridView(_apartmentController.OrderByState(), DgvOrdered);

            // скорректировать название вкладки
            TbpSorted.Text = TbpSorted.Text.Remove(TbpSorted.Text.IndexOf(":")+1) + " по состоянию";
        } // OrderByState_Command


        // сортировка коллекции по мощности прибора
        private void OrderByPower_Command(object sender, EventArgs e) {
            TbcMain.SelectedTab = TbpSorted;

            FillDataGridView(_apartmentController.OrderByPower(), DgvOrdered);

            // скорректировать название вкладки
            TbpSorted.Text = TbpSorted.Text.Remove(TbpSorted.Text.IndexOf(":") + 1) + " по мощности";
        } // OrderByPower_Command


        // сортировка коллекции по убыванию цены прибора
        private void OrderByPriceDesc_Command(object sender, EventArgs e) {
            TbcMain.SelectedTab = TbpSorted;

            FillDataGridView(_apartmentController.OrderByPriceDesc(), DgvOrdered);

            // скорректировать название вкладки
            TbpSorted.Text = TbpSorted.Text.Remove(TbpSorted.Text.IndexOf(":") + 1) + " по убыванию цены";
        } // OrderByPriceDesc_Command


        // выбор и загрузка файла данных о квартире и коллекции приборов квартиры
        private void OpenFile_Command(object sender, EventArgs e) {
            // показать диалог выбора файла, если файл не выбран - молча уходим 
            if (OfdMain.ShowDialog() != DialogResult.OK) return;

            // загрузка выбранного файла
            _apartmentController.FileName = OfdMain.FileName;
            _apartmentController.DeserializeData();

            // отображение данных файла, обновление данных
            // сформировать данные в ListView: приборы, отсортированные приборы, выборка по наименованию
            FillDataGridView(_apartmentController.GetAll(), DgvAppliances);
            FillDataGridView(_apartmentController.OrderByBrand(), DgvOrdered);
            FillDataGridView(_apartmentController.SelectWhereName(_apartmentController.GetAll()[0].Name), DgvFiltered);

            // сформировать дерево приборов
            FillTreeView(_apartmentController.GetAll(), TrvApartment);

            // вывести количество приборов квартире
            TslStatus.Text = $"Количество приборов в квартире: {_apartmentController.Count}";
            TslOn.Text = $"Включено: {_apartmentController.SelectWhereState(true).Count}";
            TslOff.Text = $"Выключено: {_apartmentController.SelectWhereState(false).Count}";

            // сделать первую (главную) вклдаку текущей
            TbcMain.SelectedTab = TbpAppliances;
        } // OpenFile_Command


        // задать имя файла и папку для сохранения данных при помощи стандартного диалога,
        // затем сохранить данные в выбранном файле
        private void SaveAs_Command(object sender, EventArgs e) {
            // Если файл для сохраненения не задан, то молча уходим 
            if (SfdMain.ShowDialog() != DialogResult.OK) return;

            // задать имя файла данных и собственно, сохранить данные
            _apartmentController.FileName = SfdMain.FileName;
            _apartmentController.SerializeData();

            // разрешим кнопку и пункт меню сохранения
            TsbSave.Enabled = true;
        } // SaveAs_Command


        // сохранить данные в заданном командой SaveAs имени файла
        private void Save_Command(object sender, EventArgs e) => _apartmentController.SerializeData();

        #region Перетаскивавние на ListView, TreeView

        // перетаскивание на ListView, TreeView
        private void Handler_DragDrop(object sender, DragEventArgs e) {
            if (!e.Data.GetDataPresent(DataFormats.FileDrop)) return;
            
            // Прием файла, data[] - массив имен файлов
            _apartmentController.FileName = ((string[])e.Data.GetData(DataFormats.FileDrop))[0];
            _apartmentController.DeserializeData();

            // обновление отобржаемых данных
            FillDataGridView(_apartmentController.GetAll(), DgvAppliances);
            FillDataGridView(_apartmentController.OrderByBrand(), DgvOrdered);
            FillDataGridView(_apartmentController.SelectWhereName(_apartmentController.GetAll()[0].Name), DgvFiltered);
            FillTreeView(_apartmentController.GetAll(), TrvApartment);

            // вывести количество приборов квартире
            TslStatus.Text = $"Количество приборов в квартире: {_apartmentController.Count}";
            TslOn.Text = $"Включено: {_apartmentController.SelectWhereState(true).Count}";
            TslOff.Text = $"Выключено: {_apartmentController.SelectWhereState(false).Count}";
        } // Handler_DragDrop


        // Подтверждение операции необходимо, оно задает операцию при
        // завершении буксировки, один обработчик для ListView, TreeView
        private void Object_DragEnter(object sender, DragEventArgs e) =>
            e.Effect = DragDropEffects.Copy;

        #endregion


        // событие клика в контекстном меню CmnTreeAppliance
        private void TurnOnApplianceCmnTree_Command(object sender, EventArgs e) {
            // если узел не соответствует уровню прибора - уходим
            // 0 -- квартира
            // 1 -- комната
            // 2 -- прибор
            if (TrvApartment.SelectedNode.Level != 2) return;

            (TrvApartment.SelectedNode.Tag as Appliance).State = true;
            TrvApartment.SelectedNode.ImageIndex = TrvApartment.SelectedNode.SelectedImageIndex = 1;

            // перерисовать ListView
            FillDataGridView(_apartmentController.GetAll(), DgvAppliances);

            // обновить статистику по состоянию приборов квартиры
            TslOn.Text = $"Включено: {_apartmentController.SelectWhereState(true).Count}";
            TslOff.Text = $"Выключено: {_apartmentController.SelectWhereState(false).Count}";
        } // TurnOnApplianceCmnTree_Command

        // событие клика в контекстном меню CmnTreeAppliance
        private void TurnOffApplianceCmnTree_Command(object sender, EventArgs e) {
            // если узел не соответствует уровню прибора - уходим
            // 0 -- квартира
            // 1 -- комната
            // 2 -- прибор
            if (TrvApartment.SelectedNode.Level != 2) return;

            // изменения состояния в коллекции и изменение картинки в дереве
            (TrvApartment.SelectedNode.Tag as Appliance).State = false;
            TrvApartment.SelectedNode.ImageIndex = TrvApartment.SelectedNode.SelectedImageIndex = 0;

            // перерисовать ListView
            FillDataGridView(_apartmentController.GetAll(), DgvAppliances);

            // обновить статистику по состоянию приборов квартиры
            TslOn.Text = $"Включено: {_apartmentController.SelectWhereState(true).Count}";
            TslOff.Text = $"Выключено: {_apartmentController.SelectWhereState(false).Count}";
        } // TurnOnApplianceCmnTree_Command

        // коррекция поведения TreeView - при отпускании любой кнопки мыши
        // сделать узел, на котором был клик, текущим 
        private void CorrectBehavor_MouseUp(object sender, MouseEventArgs e) {
            // закомментировано для исключения конфликтов с NodeMouseClick
            // TrvApartment.SelectedNode = TrvApartment.GetNodeAt(e.Location);
        } // CorrectBehavor_MouseUp

        // альтернативная коррекция поведения TreeView - по клику на узле (любой кнопкой мыши)
        // сделать узел, на котором был клик, текущим 
        private void CorrectBehavor_NodeMouseClick(object sender, TreeNodeMouseClickEventArgs e) {
            TrvApartment.SelectedNode = e.Node;
        } // CorrectBehavor_NodeMouseClick

        // включить все приборы комнаты
        private void TurnOnRoom_Command(object sender, EventArgs e) {
            // если узел не соответствует уровню комнаты - уходим
            // 0 -- квартира
            // 1 -- комната
            // 2 -- прибор
            if (TrvApartment.SelectedNode.Level != 1) return;

            // изменения состояния в коллекции приборов
            _apartmentController.TurnRoom(TrvApartment.SelectedNode.Text, true);

            // обновить отображение приборов
            FillDataGridView(_apartmentController.Apartment.Appliances, DgvAppliances);
            FillTreeView(_apartmentController.GetAll(), TrvApartment);

            // обновить статистику по состоянию приборов квартиры
            TslOn.Text = $"Включено: {_apartmentController.SelectWhereState(true).Count}";
            TslOff.Text = $"Выключено: {_apartmentController.SelectWhereState(false).Count}";
        } // TurnOnRoom_Command


        // выключить все приборы комнаты
        private void TurnOffRoom_Command(object sender, EventArgs e) {
            // если узел не соответствует уровню комнаты - уходим
            // 0 -- квартира
            // 1 -- комната
            // 2 -- прибор
            if (TrvApartment.SelectedNode.Level != 1) return;

            // изменения состояния в коллекции приборов
            _apartmentController.TurnRoom(TrvApartment.SelectedNode.Text, false);

            // обновить отображение приборов
            FillDataGridView(_apartmentController.Apartment.Appliances, DgvAppliances);
            FillTreeView(_apartmentController.GetAll(), TrvApartment);

            // обновить статистику по состоянию приборов квартиры
            TslOn.Text = $"Включено: {_apartmentController.SelectWhereState(true).Count}";
            TslOff.Text = $"Выключено: {_apartmentController.SelectWhereState(false).Count}";
        } // TurnOffRoom_Command

        // по правой кнопке мыши делаем строку DataGridView текущей
        // https://docs.microsoft.com/kk-kz/dotnet/api/system.windows.forms.datagridview.hittestinfo?view=netframework-2.0
        private void DgvAppliances_MouseDown(object sender, MouseEventArgs e) {
            if (e.Button == MouseButtons.Right) {
                DataGridView.HitTestInfo hit = DgvAppliances.HitTest(e.X, e.Y);
                DgvAppliances.Rows[hit.RowIndex].Selected = true;

                // вызов контекстного меню - избыточно, но как пример вызова - интересно 
                // CmnDataGridView.Show(DgvAppliances, e.X, e.Y);
            } // if
        }
    } // class MainForm
}
