﻿
namespace ElectricalAppliances.Views
{
    partial class MainForm
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            System.Windows.Forms.TreeNode treeNode1 = new System.Windows.Forms.TreeNode("Квартира");
            this.MnsMain = new System.Windows.Forms.MenuStrip();
            this.MniFile = new System.Windows.Forms.ToolStripMenuItem();
            this.MniFileOpen = new System.Windows.Forms.ToolStripMenuItem();
            this.MniFileSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.MniFileSave = new System.Windows.Forms.ToolStripMenuItem();
            this.MniFileSaveAs = new System.Windows.Forms.ToolStripMenuItem();
            this.MniFileSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.MniFileExit = new System.Windows.Forms.ToolStripMenuItem();
            this.MniApartment = new System.Windows.Forms.ToolStripMenuItem();
            this.новаяКвартираToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.редактироватьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.MniControl = new System.Windows.Forms.ToolStripMenuItem();
            this.MniControlToTray = new System.Windows.Forms.ToolStripMenuItem();
            this.MniControlSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.MniControlTurnApplianceOn = new System.Windows.Forms.ToolStripMenuItem();
            this.MniControlTurnApplianceOff = new System.Windows.Forms.ToolStripMenuItem();
            this.MniControlSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.MniControlTurnOnAll = new System.Windows.Forms.ToolStripMenuItem();
            this.MniControlTurnOffAll = new System.Windows.Forms.ToolStripMenuItem();
            this.MniReport = new System.Windows.Forms.ToolStripMenuItem();
            this.MniReportOrder = new System.Windows.Forms.ToolStripMenuItem();
            this.MniReportOrderByName = new System.Windows.Forms.ToolStripMenuItem();
            this.MniReportOrderByState = new System.Windows.Forms.ToolStripMenuItem();
            this.MniReportOrderByPower = new System.Windows.Forms.ToolStripMenuItem();
            this.MniReportOrderByPrice = new System.Windows.Forms.ToolStripMenuItem();
            this.MniReportSelect = new System.Windows.Forms.ToolStripMenuItem();
            this.MniReportSelectByName = new System.Windows.Forms.ToolStripMenuItem();
            this.MniReportSelectByState = new System.Windows.Forms.ToolStripMenuItem();
            this.MniHelp = new System.Windows.Forms.ToolStripMenuItem();
            this.MniHelpAbout = new System.Windows.Forms.ToolStripMenuItem();
            this.TstMain = new System.Windows.Forms.ToolStrip();
            this.TsbNew = new System.Windows.Forms.ToolStripButton();
            this.TsbOpen = new System.Windows.Forms.ToolStripButton();
            this.TsbSave = new System.Windows.Forms.ToolStripButton();
            this.TstSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.TsbEditApartment = new System.Windows.Forms.ToolStripButton();
            this.TsbToTray = new System.Windows.Forms.ToolStripButton();
            this.TstSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.TsbTurnOnAll = new System.Windows.Forms.ToolStripButton();
            this.TsbTurnOffAll = new System.Windows.Forms.ToolStripButton();
            this.TstSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.TsbAbout = new System.Windows.Forms.ToolStripButton();
            this.TsbExit = new System.Windows.Forms.ToolStripButton();
            this.StsMain = new System.Windows.Forms.StatusStrip();
            this.TslStatus = new System.Windows.Forms.ToolStripStatusLabel();
            this.TslOn = new System.Windows.Forms.ToolStripStatusLabel();
            this.TslOff = new System.Windows.Forms.ToolStripStatusLabel();
            this.TslFileName = new System.Windows.Forms.ToolStripStatusLabel();
            this.CmnNotify = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.CmiRestore = new System.Windows.Forms.ToolStripMenuItem();
            this.CmiNotifySeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.CmiAbout = new System.Windows.Forms.ToolStripMenuItem();
            this.CmiNotifySeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.CmiExit = new System.Windows.Forms.ToolStripMenuItem();
            this.CmnDataGridView = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.CmiDataGridViewTurnOn = new System.Windows.Forms.ToolStripMenuItem();
            this.CmiListViewTurnOff = new System.Windows.Forms.ToolStripMenuItem();
            this.CmiListViewSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.CmiListViewTurnOnAll = new System.Windows.Forms.ToolStripMenuItem();
            this.CmiListViewTurnOffAll = new System.Windows.Forms.ToolStripMenuItem();
            this.CmiListViewSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.CmiListViewToTray = new System.Windows.Forms.ToolStripMenuItem();
            this.ImlSmall = new System.Windows.Forms.ImageList(this.components);
            this.OfdMain = new System.Windows.Forms.OpenFileDialog();
            this.SfdMain = new System.Windows.Forms.SaveFileDialog();
            this.NtfMain = new System.Windows.Forms.NotifyIcon(this.components);
            this.LblApartmentInfo = new System.Windows.Forms.Label();
            this.TbcMain = new System.Windows.Forms.TabControl();
            this.TbpAppliances = new System.Windows.Forms.TabPage();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.TrvApartment = new System.Windows.Forms.TreeView();
            this.CmnTreeApartment = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.CmiTreeApartmentTurnOnAll = new System.Windows.Forms.ToolStripMenuItem();
            this.CmiTreeApartmentTurnOffAll = new System.Windows.Forms.ToolStripMenuItem();
            this.DgvAppliances = new System.Windows.Forms.DataGridView();
            this.ColIdentifier = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColState = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColRoom = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColApplianceNane = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColPower = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColPrice = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TbpSorted = new System.Windows.Forms.TabPage();
            this.DgvOrdered = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TbpSelected = new System.Windows.Forms.TabPage();
            this.DgvFiltered = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CmnTreeAppliance = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.CmnTreeRoom = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.CmiTreeRoomTurnOnAll = new System.Windows.Forms.ToolStripMenuItem();
            this.CmiTreeRoomTurnOffAll = new System.Windows.Forms.ToolStripMenuItem();
            this.MnsMain.SuspendLayout();
            this.TstMain.SuspendLayout();
            this.StsMain.SuspendLayout();
            this.CmnNotify.SuspendLayout();
            this.CmnDataGridView.SuspendLayout();
            this.TbcMain.SuspendLayout();
            this.TbpAppliances.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.CmnTreeApartment.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DgvAppliances)).BeginInit();
            this.TbpSorted.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DgvOrdered)).BeginInit();
            this.TbpSelected.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DgvFiltered)).BeginInit();
            this.CmnTreeAppliance.SuspendLayout();
            this.CmnTreeRoom.SuspendLayout();
            this.SuspendLayout();
            // 
            // MnsMain
            // 
            this.MnsMain.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.MnsMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniFile,
            this.MniApartment,
            this.MniControl,
            this.MniReport,
            this.MniHelp});
            this.MnsMain.Location = new System.Drawing.Point(0, 0);
            this.MnsMain.Name = "MnsMain";
            this.MnsMain.Size = new System.Drawing.Size(1184, 28);
            this.MnsMain.TabIndex = 0;
            this.MnsMain.Text = "menuStrip1";
            // 
            // MniFile
            // 
            this.MniFile.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniFileOpen,
            this.MniFileSeparator1,
            this.MniFileSave,
            this.MniFileSaveAs,
            this.MniFileSeparator2,
            this.MniFileExit});
            this.MniFile.Name = "MniFile";
            this.MniFile.Size = new System.Drawing.Size(57, 24);
            this.MniFile.Text = "Файл";
            // 
            // MniFileOpen
            // 
            this.MniFileOpen.Image = global::ElectricalAppliances.Properties.Resources.folder;
            this.MniFileOpen.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MniFileOpen.Name = "MniFileOpen";
            this.MniFileOpen.Size = new System.Drawing.Size(203, 38);
            this.MniFileOpen.Text = "Открыть...";
            this.MniFileOpen.Click += new System.EventHandler(this.OpenFile_Command);
            // 
            // MniFileSeparator1
            // 
            this.MniFileSeparator1.Name = "MniFileSeparator1";
            this.MniFileSeparator1.Size = new System.Drawing.Size(200, 6);
            // 
            // MniFileSave
            // 
            this.MniFileSave.Enabled = false;
            this.MniFileSave.Image = global::ElectricalAppliances.Properties.Resources.disk;
            this.MniFileSave.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MniFileSave.Name = "MniFileSave";
            this.MniFileSave.Size = new System.Drawing.Size(203, 38);
            this.MniFileSave.Text = "Сохранить";
            this.MniFileSave.Click += new System.EventHandler(this.Save_Command);
            // 
            // MniFileSaveAs
            // 
            this.MniFileSaveAs.Image = global::ElectricalAppliances.Properties.Resources.save_as;
            this.MniFileSaveAs.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MniFileSaveAs.Name = "MniFileSaveAs";
            this.MniFileSaveAs.Size = new System.Drawing.Size(203, 38);
            this.MniFileSaveAs.Text = "Сохранить как...";
            this.MniFileSaveAs.Click += new System.EventHandler(this.SaveAs_Command);
            // 
            // MniFileSeparator2
            // 
            this.MniFileSeparator2.Name = "MniFileSeparator2";
            this.MniFileSeparator2.Size = new System.Drawing.Size(200, 6);
            // 
            // MniFileExit
            // 
            this.MniFileExit.Image = global::ElectricalAppliances.Properties.Resources.door_out;
            this.MniFileExit.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MniFileExit.Name = "MniFileExit";
            this.MniFileExit.Size = new System.Drawing.Size(203, 38);
            this.MniFileExit.Text = "Выход";
            this.MniFileExit.Click += new System.EventHandler(this.Exit_Command);
            // 
            // MniApartment
            // 
            this.MniApartment.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.новаяКвартираToolStripMenuItem,
            this.редактироватьToolStripMenuItem});
            this.MniApartment.Name = "MniApartment";
            this.MniApartment.Size = new System.Drawing.Size(87, 24);
            this.MniApartment.Text = "Квартира";
            // 
            // новаяКвартираToolStripMenuItem
            // 
            this.новаяКвартираToolStripMenuItem.Image = global::ElectricalAppliances.Properties.Resources._new;
            this.новаяКвартираToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.новаяКвартираToolStripMenuItem.Name = "новаяКвартираToolStripMenuItem";
            this.новаяКвартираToolStripMenuItem.Size = new System.Drawing.Size(215, 38);
            this.новаяКвартираToolStripMenuItem.Text = "Новая квартира...";
            // 
            // редактироватьToolStripMenuItem
            // 
            this.редактироватьToolStripMenuItem.Image = global::ElectricalAppliances.Properties.Resources.pencil;
            this.редактироватьToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.редактироватьToolStripMenuItem.Name = "редактироватьToolStripMenuItem";
            this.редактироватьToolStripMenuItem.Size = new System.Drawing.Size(215, 38);
            this.редактироватьToolStripMenuItem.Text = "Редактировать...";
            // 
            // MniControl
            // 
            this.MniControl.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniControlToTray,
            this.MniControlSeparator1,
            this.MniControlTurnApplianceOn,
            this.MniControlTurnApplianceOff,
            this.MniControlSeparator2,
            this.MniControlTurnOnAll,
            this.MniControlTurnOffAll});
            this.MniControl.Name = "MniControl";
            this.MniControl.Size = new System.Drawing.Size(106, 24);
            this.MniControl.Text = "Управление";
            // 
            // MniControlToTray
            // 
            this.MniControlToTray.Image = global::ElectricalAppliances.Properties.Resources.arrow_in;
            this.MniControlToTray.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MniControlToTray.Name = "MniControlToTray";
            this.MniControlToTray.Size = new System.Drawing.Size(268, 38);
            this.MniControlToTray.Text = "Свернуть в трей";
            this.MniControlToTray.Click += new System.EventHandler(this.ToTray_Command);
            // 
            // MniControlSeparator1
            // 
            this.MniControlSeparator1.Name = "MniControlSeparator1";
            this.MniControlSeparator1.Size = new System.Drawing.Size(265, 6);
            // 
            // MniControlTurnApplianceOn
            // 
            this.MniControlTurnApplianceOn.Image = global::ElectricalAppliances.Properties.Resources.ledon1;
            this.MniControlTurnApplianceOn.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MniControlTurnApplianceOn.Name = "MniControlTurnApplianceOn";
            this.MniControlTurnApplianceOn.Size = new System.Drawing.Size(268, 38);
            this.MniControlTurnApplianceOn.Text = "Включить прибор...";
            this.MniControlTurnApplianceOn.Click += new System.EventHandler(this.TurnOnSelected_Command);
            // 
            // MniControlTurnApplianceOff
            // 
            this.MniControlTurnApplianceOff.Image = global::ElectricalAppliances.Properties.Resources.ledoff1;
            this.MniControlTurnApplianceOff.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MniControlTurnApplianceOff.Name = "MniControlTurnApplianceOff";
            this.MniControlTurnApplianceOff.Size = new System.Drawing.Size(268, 38);
            this.MniControlTurnApplianceOff.Text = "Выключить прибор...";
            this.MniControlTurnApplianceOff.Click += new System.EventHandler(this.TurnOffSelected_Command);
            // 
            // MniControlSeparator2
            // 
            this.MniControlSeparator2.Name = "MniControlSeparator2";
            this.MniControlSeparator2.Size = new System.Drawing.Size(265, 6);
            // 
            // MniControlTurnOnAll
            // 
            this.MniControlTurnOnAll.Image = global::ElectricalAppliances.Properties.Resources.lightbulb;
            this.MniControlTurnOnAll.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MniControlTurnOnAll.Name = "MniControlTurnOnAll";
            this.MniControlTurnOnAll.Size = new System.Drawing.Size(268, 38);
            this.MniControlTurnOnAll.Text = "Включить все приборы";
            this.MniControlTurnOnAll.Click += new System.EventHandler(this.TurnOnAll_Commad);
            // 
            // MniControlTurnOffAll
            // 
            this.MniControlTurnOffAll.Image = global::ElectricalAppliances.Properties.Resources.lightbulb_off;
            this.MniControlTurnOffAll.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MniControlTurnOffAll.Name = "MniControlTurnOffAll";
            this.MniControlTurnOffAll.Size = new System.Drawing.Size(268, 38);
            this.MniControlTurnOffAll.Text = "Выключить все приборы";
            this.MniControlTurnOffAll.Click += new System.EventHandler(this.TurnOffAll_Commad);
            // 
            // MniReport
            // 
            this.MniReport.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniReportOrder,
            this.MniReportSelect});
            this.MniReport.Name = "MniReport";
            this.MniReport.Size = new System.Drawing.Size(71, 24);
            this.MniReport.Text = "Отчеты";
            // 
            // MniReportOrder
            // 
            this.MniReportOrder.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniReportOrderByName,
            this.MniReportOrderByState,
            this.MniReportOrderByPower,
            this.MniReportOrderByPrice});
            this.MniReportOrder.Name = "MniReportOrder";
            this.MniReportOrder.Size = new System.Drawing.Size(170, 24);
            this.MniReportOrder.Text = "Упорядочить";
            // 
            // MniReportOrderByName
            // 
            this.MniReportOrderByName.Name = "MniReportOrderByName";
            this.MniReportOrderByName.Size = new System.Drawing.Size(216, 24);
            this.MniReportOrderByName.Text = "По названию";
            this.MniReportOrderByName.Click += new System.EventHandler(this.OrderByName_Command);
            // 
            // MniReportOrderByState
            // 
            this.MniReportOrderByState.Name = "MniReportOrderByState";
            this.MniReportOrderByState.Size = new System.Drawing.Size(216, 24);
            this.MniReportOrderByState.Text = "По состоянию";
            this.MniReportOrderByState.Click += new System.EventHandler(this.OrderByState_Command);
            // 
            // MniReportOrderByPower
            // 
            this.MniReportOrderByPower.Name = "MniReportOrderByPower";
            this.MniReportOrderByPower.Size = new System.Drawing.Size(216, 24);
            this.MniReportOrderByPower.Text = "По мощности";
            this.MniReportOrderByPower.Click += new System.EventHandler(this.OrderByPower_Command);
            // 
            // MniReportOrderByPrice
            // 
            this.MniReportOrderByPrice.Name = "MniReportOrderByPrice";
            this.MniReportOrderByPrice.Size = new System.Drawing.Size(216, 24);
            this.MniReportOrderByPrice.Text = "По убыванию цены";
            this.MniReportOrderByPrice.Click += new System.EventHandler(this.OrderByPriceDesc_Command);
            // 
            // MniReportSelect
            // 
            this.MniReportSelect.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniReportSelectByName,
            this.MniReportSelectByState});
            this.MniReportSelect.Name = "MniReportSelect";
            this.MniReportSelect.Size = new System.Drawing.Size(170, 24);
            this.MniReportSelect.Text = "Выбрать";
            // 
            // MniReportSelectByName
            // 
            this.MniReportSelectByName.Name = "MniReportSelectByName";
            this.MniReportSelectByName.Size = new System.Drawing.Size(178, 24);
            this.MniReportSelectByName.Text = "По названию";
            // 
            // MniReportSelectByState
            // 
            this.MniReportSelectByState.Name = "MniReportSelectByState";
            this.MniReportSelectByState.Size = new System.Drawing.Size(178, 24);
            this.MniReportSelectByState.Text = "По состоянию";
            // 
            // MniHelp
            // 
            this.MniHelp.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniHelpAbout});
            this.MniHelp.Name = "MniHelp";
            this.MniHelp.Size = new System.Drawing.Size(79, 24);
            this.MniHelp.Text = "Справка";
            // 
            // MniHelpAbout
            // 
            this.MniHelpAbout.Image = global::ElectricalAppliances.Properties.Resources.help;
            this.MniHelpAbout.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MniHelpAbout.Name = "MniHelpAbout";
            this.MniHelpAbout.Size = new System.Drawing.Size(198, 38);
            this.MniHelpAbout.Text = "О программе...";
            this.MniHelpAbout.Click += new System.EventHandler(this.About_Command);
            // 
            // TstMain
            // 
            this.TstMain.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TstMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.TsbNew,
            this.TsbOpen,
            this.TsbSave,
            this.TstSeparator1,
            this.TsbEditApartment,
            this.TsbToTray,
            this.TstSeparator2,
            this.TsbTurnOnAll,
            this.TsbTurnOffAll,
            this.TstSeparator3,
            this.TsbAbout,
            this.TsbExit});
            this.TstMain.Location = new System.Drawing.Point(0, 28);
            this.TstMain.Name = "TstMain";
            this.TstMain.Size = new System.Drawing.Size(1184, 39);
            this.TstMain.TabIndex = 1;
            this.TstMain.Text = "toolStrip1";
            // 
            // TsbNew
            // 
            this.TsbNew.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbNew.Image = global::ElectricalAppliances.Properties.Resources._new;
            this.TsbNew.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbNew.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbNew.Name = "TsbNew";
            this.TsbNew.Size = new System.Drawing.Size(36, 36);
            this.TsbNew.Text = "toolStripButton1";
            this.TsbNew.ToolTipText = "Новая квартира...";
            // 
            // TsbOpen
            // 
            this.TsbOpen.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbOpen.Image = global::ElectricalAppliances.Properties.Resources.folder;
            this.TsbOpen.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbOpen.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbOpen.Name = "TsbOpen";
            this.TsbOpen.Size = new System.Drawing.Size(36, 36);
            this.TsbOpen.Text = "toolStripButton2";
            this.TsbOpen.ToolTipText = "Открыть файл данных...";
            this.TsbOpen.Click += new System.EventHandler(this.OpenFile_Command);
            // 
            // TsbSave
            // 
            this.TsbSave.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbSave.Enabled = false;
            this.TsbSave.Image = global::ElectricalAppliances.Properties.Resources.disk;
            this.TsbSave.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbSave.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbSave.Name = "TsbSave";
            this.TsbSave.Size = new System.Drawing.Size(36, 36);
            this.TsbSave.Text = "toolStripButton3";
            this.TsbSave.ToolTipText = "Сохранить данные квартиры";
            this.TsbSave.Click += new System.EventHandler(this.Save_Command);
            // 
            // TstSeparator1
            // 
            this.TstSeparator1.Name = "TstSeparator1";
            this.TstSeparator1.Size = new System.Drawing.Size(6, 39);
            // 
            // TsbEditApartment
            // 
            this.TsbEditApartment.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbEditApartment.Image = global::ElectricalAppliances.Properties.Resources.pencil;
            this.TsbEditApartment.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbEditApartment.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbEditApartment.Name = "TsbEditApartment";
            this.TsbEditApartment.Size = new System.Drawing.Size(36, 36);
            this.TsbEditApartment.Text = "toolStripButton5";
            // 
            // TsbToTray
            // 
            this.TsbToTray.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbToTray.Image = global::ElectricalAppliances.Properties.Resources.arrow_in;
            this.TsbToTray.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbToTray.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbToTray.Name = "TsbToTray";
            this.TsbToTray.Size = new System.Drawing.Size(36, 36);
            this.TsbToTray.Text = "toolStripButton6";
            this.TsbToTray.Click += new System.EventHandler(this.ToTray_Command);
            // 
            // TstSeparator2
            // 
            this.TstSeparator2.Name = "TstSeparator2";
            this.TstSeparator2.Size = new System.Drawing.Size(6, 39);
            // 
            // TsbTurnOnAll
            // 
            this.TsbTurnOnAll.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbTurnOnAll.Image = global::ElectricalAppliances.Properties.Resources.lightbulb;
            this.TsbTurnOnAll.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbTurnOnAll.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbTurnOnAll.Name = "TsbTurnOnAll";
            this.TsbTurnOnAll.Size = new System.Drawing.Size(36, 36);
            this.TsbTurnOnAll.ToolTipText = "Включить все приборы квартиры";
            this.TsbTurnOnAll.Click += new System.EventHandler(this.TurnOnAll_Commad);
            // 
            // TsbTurnOffAll
            // 
            this.TsbTurnOffAll.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbTurnOffAll.Image = global::ElectricalAppliances.Properties.Resources.lightbulb_off;
            this.TsbTurnOffAll.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbTurnOffAll.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbTurnOffAll.Name = "TsbTurnOffAll";
            this.TsbTurnOffAll.Size = new System.Drawing.Size(36, 36);
            this.TsbTurnOffAll.ToolTipText = "Выключить все приборы квартиры";
            this.TsbTurnOffAll.Click += new System.EventHandler(this.TurnOffAll_Commad);
            // 
            // TstSeparator3
            // 
            this.TstSeparator3.Name = "TstSeparator3";
            this.TstSeparator3.Size = new System.Drawing.Size(6, 39);
            // 
            // TsbAbout
            // 
            this.TsbAbout.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbAbout.Image = global::ElectricalAppliances.Properties.Resources.help;
            this.TsbAbout.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbAbout.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbAbout.Name = "TsbAbout";
            this.TsbAbout.Size = new System.Drawing.Size(36, 36);
            this.TsbAbout.ToolTipText = "Сведения о приложении и разработчике";
            this.TsbAbout.Click += new System.EventHandler(this.About_Command);
            // 
            // TsbExit
            // 
            this.TsbExit.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.TsbExit.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbExit.Image = global::ElectricalAppliances.Properties.Resources.door_out;
            this.TsbExit.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbExit.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbExit.Name = "TsbExit";
            this.TsbExit.Size = new System.Drawing.Size(36, 36);
            this.TsbExit.ToolTipText = "Завершение приложение";
            this.TsbExit.Click += new System.EventHandler(this.Exit_Command);
            // 
            // StsMain
            // 
            this.StsMain.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.StsMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.TslStatus,
            this.TslOn,
            this.TslOff,
            this.TslFileName});
            this.StsMain.Location = new System.Drawing.Point(0, 616);
            this.StsMain.Name = "StsMain";
            this.StsMain.Size = new System.Drawing.Size(1184, 25);
            this.StsMain.TabIndex = 2;
            this.StsMain.Text = "statusStrip1";
            // 
            // TslStatus
            // 
            this.TslStatus.AutoSize = false;
            this.TslStatus.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenInner;
            this.TslStatus.Name = "TslStatus";
            this.TslStatus.Padding = new System.Windows.Forms.Padding(6, 0, 0, 0);
            this.TslStatus.Size = new System.Drawing.Size(280, 20);
            this.TslStatus.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // TslOn
            // 
            this.TslOn.AutoSize = false;
            this.TslOn.BackColor = System.Drawing.Color.Aquamarine;
            this.TslOn.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenInner;
            this.TslOn.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.TslOn.Name = "TslOn";
            this.TslOn.Padding = new System.Windows.Forms.Padding(6, 0, 0, 0);
            this.TslOn.Size = new System.Drawing.Size(140, 20);
            this.TslOn.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // TslOff
            // 
            this.TslOff.AutoSize = false;
            this.TslOff.BackColor = System.Drawing.Color.Thistle;
            this.TslOff.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenInner;
            this.TslOff.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.TslOff.Name = "TslOff";
            this.TslOff.Padding = new System.Windows.Forms.Padding(6, 0, 0, 0);
            this.TslOff.Size = new System.Drawing.Size(140, 20);
            this.TslOff.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // TslFileName
            // 
            this.TslFileName.Name = "TslFileName";
            this.TslFileName.Size = new System.Drawing.Size(609, 20);
            this.TslFileName.Spring = true;
            this.TslFileName.Text = "Имя файла данных";
            this.TslFileName.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // CmnNotify
            // 
            this.CmnNotify.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.CmnNotify.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.CmiRestore,
            this.CmiNotifySeparator1,
            this.CmiAbout,
            this.CmiNotifySeparator2,
            this.CmiExit});
            this.CmnNotify.Name = "contextMenuStrip1";
            this.CmnNotify.Size = new System.Drawing.Size(199, 130);
            // 
            // CmiRestore
            // 
            this.CmiRestore.Image = global::ElectricalAppliances.Properties.Resources.arrow_out;
            this.CmiRestore.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.CmiRestore.Name = "CmiRestore";
            this.CmiRestore.Size = new System.Drawing.Size(198, 38);
            this.CmiRestore.Text = "Восстановить";
            this.CmiRestore.Click += new System.EventHandler(this.FromTray_Command);
            // 
            // CmiNotifySeparator1
            // 
            this.CmiNotifySeparator1.Name = "CmiNotifySeparator1";
            this.CmiNotifySeparator1.Size = new System.Drawing.Size(195, 6);
            // 
            // CmiAbout
            // 
            this.CmiAbout.Name = "CmiAbout";
            this.CmiAbout.Size = new System.Drawing.Size(198, 38);
            this.CmiAbout.Text = "О программе...";
            this.CmiAbout.Click += new System.EventHandler(this.About_Command);
            // 
            // CmiNotifySeparator2
            // 
            this.CmiNotifySeparator2.Name = "CmiNotifySeparator2";
            this.CmiNotifySeparator2.Size = new System.Drawing.Size(195, 6);
            // 
            // CmiExit
            // 
            this.CmiExit.Name = "CmiExit";
            this.CmiExit.Size = new System.Drawing.Size(198, 38);
            this.CmiExit.Text = "Выход";
            this.CmiExit.Click += new System.EventHandler(this.Exit_Command);
            // 
            // CmnDataGridView
            // 
            this.CmnDataGridView.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.CmnDataGridView.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.CmiDataGridViewTurnOn,
            this.CmiListViewTurnOff,
            this.CmiListViewSeparator1,
            this.CmiListViewTurnOnAll,
            this.CmiListViewTurnOffAll,
            this.CmiListViewSeparator2,
            this.CmiListViewToTray});
            this.CmnDataGridView.Name = "contextMenuStrip2";
            this.CmnDataGridView.Size = new System.Drawing.Size(269, 206);
            // 
            // CmiDataGridViewTurnOn
            // 
            this.CmiDataGridViewTurnOn.Image = global::ElectricalAppliances.Properties.Resources.ledon1;
            this.CmiDataGridViewTurnOn.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.CmiDataGridViewTurnOn.Name = "CmiDataGridViewTurnOn";
            this.CmiDataGridViewTurnOn.Size = new System.Drawing.Size(268, 38);
            this.CmiDataGridViewTurnOn.Text = "Включить прибор";
            this.CmiDataGridViewTurnOn.Click += new System.EventHandler(this.TurnOnSelected_Command);
            // 
            // CmiListViewTurnOff
            // 
            this.CmiListViewTurnOff.Image = global::ElectricalAppliances.Properties.Resources.ledoff1;
            this.CmiListViewTurnOff.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.CmiListViewTurnOff.Name = "CmiListViewTurnOff";
            this.CmiListViewTurnOff.Size = new System.Drawing.Size(268, 38);
            this.CmiListViewTurnOff.Text = "Выключить прибор";
            this.CmiListViewTurnOff.Click += new System.EventHandler(this.TurnOffSelected_Command);
            // 
            // CmiListViewSeparator1
            // 
            this.CmiListViewSeparator1.Name = "CmiListViewSeparator1";
            this.CmiListViewSeparator1.Size = new System.Drawing.Size(265, 6);
            // 
            // CmiListViewTurnOnAll
            // 
            this.CmiListViewTurnOnAll.Image = global::ElectricalAppliances.Properties.Resources.lightbulb;
            this.CmiListViewTurnOnAll.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.CmiListViewTurnOnAll.Name = "CmiListViewTurnOnAll";
            this.CmiListViewTurnOnAll.Size = new System.Drawing.Size(268, 38);
            this.CmiListViewTurnOnAll.Text = "Включить все приборы";
            this.CmiListViewTurnOnAll.Click += new System.EventHandler(this.TurnOnAll_Commad);
            // 
            // CmiListViewTurnOffAll
            // 
            this.CmiListViewTurnOffAll.Image = global::ElectricalAppliances.Properties.Resources.lightbulb_off;
            this.CmiListViewTurnOffAll.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.CmiListViewTurnOffAll.Name = "CmiListViewTurnOffAll";
            this.CmiListViewTurnOffAll.Size = new System.Drawing.Size(268, 38);
            this.CmiListViewTurnOffAll.Text = "Выключить все приборы";
            this.CmiListViewTurnOffAll.Click += new System.EventHandler(this.TurnOffAll_Commad);
            // 
            // CmiListViewSeparator2
            // 
            this.CmiListViewSeparator2.Name = "CmiListViewSeparator2";
            this.CmiListViewSeparator2.Size = new System.Drawing.Size(265, 6);
            // 
            // CmiListViewToTray
            // 
            this.CmiListViewToTray.Image = global::ElectricalAppliances.Properties.Resources.arrow_in;
            this.CmiListViewToTray.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.CmiListViewToTray.Name = "CmiListViewToTray";
            this.CmiListViewToTray.Size = new System.Drawing.Size(268, 38);
            this.CmiListViewToTray.Text = "Свернуть в трей";
            this.CmiListViewToTray.Click += new System.EventHandler(this.ToTray_Command);
            // 
            // ImlSmall
            // 
            this.ImlSmall.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("ImlSmall.ImageStream")));
            this.ImlSmall.TransparentColor = System.Drawing.Color.Transparent;
            this.ImlSmall.Images.SetKeyName(0, "ledoff.png");
            this.ImlSmall.Images.SetKeyName(1, "ledon.png");
            this.ImlSmall.Images.SetKeyName(2, "house.png");
            this.ImlSmall.Images.SetKeyName(3, "control_panel.png");
            // 
            // OfdMain
            // 
            this.OfdMain.Filter = "Данные квартиры (*.json)|*.json|Все файлы (*.*)|*.*";
            this.OfdMain.Title = "Открыть файл данных квартиры";
            // 
            // SfdMain
            // 
            this.SfdMain.DefaultExt = "json";
            this.SfdMain.Filter = "Данные квартиры (*.json)|*.json|Все файлы (*.*)|*.*";
            this.SfdMain.Title = "Сохранить данные квартиры";
            // 
            // NtfMain
            // 
            this.NtfMain.ContextMenuStrip = this.CmnNotify;
            this.NtfMain.Icon = ((System.Drawing.Icon)(resources.GetObject("NtfMain.Icon")));
            this.NtfMain.Text = "Управление электроприборами\r\nквартиры";
            // 
            // LblApartmentInfo
            // 
            this.LblApartmentInfo.Dock = System.Windows.Forms.DockStyle.Top;
            this.LblApartmentInfo.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblApartmentInfo.Location = new System.Drawing.Point(0, 67);
            this.LblApartmentInfo.Name = "LblApartmentInfo";
            this.LblApartmentInfo.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.LblApartmentInfo.Size = new System.Drawing.Size(1184, 27);
            this.LblApartmentInfo.TabIndex = 3;
            this.LblApartmentInfo.Text = "Место для вывода адреса квартиры";
            this.LblApartmentInfo.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // TbcMain
            // 
            this.TbcMain.Controls.Add(this.TbpAppliances);
            this.TbcMain.Controls.Add(this.TbpSorted);
            this.TbcMain.Controls.Add(this.TbpSelected);
            this.TbcMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TbcMain.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TbcMain.Location = new System.Drawing.Point(0, 94);
            this.TbcMain.Name = "TbcMain";
            this.TbcMain.SelectedIndex = 0;
            this.TbcMain.Size = new System.Drawing.Size(1184, 522);
            this.TbcMain.TabIndex = 6;
            // 
            // TbpAppliances
            // 
            this.TbpAppliances.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.TbpAppliances.Controls.Add(this.splitContainer1);
            this.TbpAppliances.Location = new System.Drawing.Point(4, 27);
            this.TbpAppliances.Name = "TbpAppliances";
            this.TbpAppliances.Padding = new System.Windows.Forms.Padding(3);
            this.TbpAppliances.Size = new System.Drawing.Size(1176, 491);
            this.TbpAppliances.TabIndex = 0;
            this.TbpAppliances.Text = "Приборы квартиры";
            this.TbpAppliances.ToolTipText = "Коллекция приборов квартиры";
            this.TbpAppliances.UseVisualStyleBackColor = true;
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(3, 3);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.TrvApartment);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.DgvAppliances);
            this.splitContainer1.Size = new System.Drawing.Size(1166, 481);
            this.splitContainer1.SplitterDistance = 270;
            this.splitContainer1.TabIndex = 0;
            // 
            // TrvApartment
            // 
            this.TrvApartment.AllowDrop = true;
            this.TrvApartment.ContextMenuStrip = this.CmnTreeApartment;
            this.TrvApartment.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TrvApartment.ImageIndex = 2;
            this.TrvApartment.ImageList = this.ImlSmall;
            this.TrvApartment.Location = new System.Drawing.Point(0, 0);
            this.TrvApartment.Name = "TrvApartment";
            treeNode1.Name = "ApartmentNode";
            treeNode1.Text = "Квартира";
            treeNode1.ToolTipText = "Это адрес квартиры";
            this.TrvApartment.Nodes.AddRange(new System.Windows.Forms.TreeNode[] {
            treeNode1});
            this.TrvApartment.SelectedImageIndex = 0;
            this.TrvApartment.Size = new System.Drawing.Size(270, 481);
            this.TrvApartment.TabIndex = 0;
            this.TrvApartment.NodeMouseClick += new System.Windows.Forms.TreeNodeMouseClickEventHandler(this.CorrectBehavor_NodeMouseClick);
            this.TrvApartment.DragDrop += new System.Windows.Forms.DragEventHandler(this.Handler_DragDrop);
            this.TrvApartment.DragEnter += new System.Windows.Forms.DragEventHandler(this.Object_DragEnter);
            this.TrvApartment.MouseUp += new System.Windows.Forms.MouseEventHandler(this.CorrectBehavor_MouseUp);
            // 
            // CmnTreeApartment
            // 
            this.CmnTreeApartment.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.CmnTreeApartment.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.CmiTreeApartmentTurnOnAll,
            this.CmiTreeApartmentTurnOffAll});
            this.CmnTreeApartment.Name = "contextMenuStrip2";
            this.CmnTreeApartment.Size = new System.Drawing.Size(269, 80);
            // 
            // CmiTreeApartmentTurnOnAll
            // 
            this.CmiTreeApartmentTurnOnAll.Image = global::ElectricalAppliances.Properties.Resources.lightbulb;
            this.CmiTreeApartmentTurnOnAll.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.CmiTreeApartmentTurnOnAll.Name = "CmiTreeApartmentTurnOnAll";
            this.CmiTreeApartmentTurnOnAll.Size = new System.Drawing.Size(268, 38);
            this.CmiTreeApartmentTurnOnAll.Text = "Включить все приборы";
            this.CmiTreeApartmentTurnOnAll.Click += new System.EventHandler(this.TurnOnAll_Commad);
            // 
            // CmiTreeApartmentTurnOffAll
            // 
            this.CmiTreeApartmentTurnOffAll.Image = global::ElectricalAppliances.Properties.Resources.lightbulb_off;
            this.CmiTreeApartmentTurnOffAll.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.CmiTreeApartmentTurnOffAll.Name = "CmiTreeApartmentTurnOffAll";
            this.CmiTreeApartmentTurnOffAll.Size = new System.Drawing.Size(268, 38);
            this.CmiTreeApartmentTurnOffAll.Text = "Выключить все приборы";
            this.CmiTreeApartmentTurnOffAll.Click += new System.EventHandler(this.TurnOffAll_Commad);
            // 
            // DgvAppliances
            // 
            this.DgvAppliances.AllowUserToAddRows = false;
            this.DgvAppliances.AllowUserToDeleteRows = false;
            this.DgvAppliances.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.DgvAppliances.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DgvAppliances.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ColIdentifier,
            this.ColState,
            this.ColRoom,
            this.ColApplianceNane,
            this.ColPower,
            this.ColPrice});
            this.DgvAppliances.ContextMenuStrip = this.CmnDataGridView;
            this.DgvAppliances.Dock = System.Windows.Forms.DockStyle.Fill;
            this.DgvAppliances.Location = new System.Drawing.Point(0, 0);
            this.DgvAppliances.MultiSelect = false;
            this.DgvAppliances.Name = "DgvAppliances";
            this.DgvAppliances.ReadOnly = true;
            this.DgvAppliances.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DgvAppliances.Size = new System.Drawing.Size(892, 481);
            this.DgvAppliances.TabIndex = 0;
            this.DgvAppliances.MouseDown += new System.Windows.Forms.MouseEventHandler(this.DgvAppliances_MouseDown);
            // 
            // ColIdentifier
            // 
            this.ColIdentifier.FillWeight = 10F;
            this.ColIdentifier.HeaderText = "Идентиф.";
            this.ColIdentifier.Name = "ColIdentifier";
            this.ColIdentifier.ReadOnly = true;
            // 
            // ColState
            // 
            this.ColState.FillWeight = 15F;
            this.ColState.HeaderText = "Состояние";
            this.ColState.Name = "ColState";
            this.ColState.ReadOnly = true;
            // 
            // ColRoom
            // 
            this.ColRoom.FillWeight = 20F;
            this.ColRoom.HeaderText = "Комната";
            this.ColRoom.Name = "ColRoom";
            this.ColRoom.ReadOnly = true;
            // 
            // ColApplianceNane
            // 
            this.ColApplianceNane.FillWeight = 25F;
            this.ColApplianceNane.HeaderText = "Название прибора";
            this.ColApplianceNane.Name = "ColApplianceNane";
            this.ColApplianceNane.ReadOnly = true;
            // 
            // ColPower
            // 
            this.ColPower.FillWeight = 20F;
            this.ColPower.HeaderText = "Мощность, Вт";
            this.ColPower.Name = "ColPower";
            this.ColPower.ReadOnly = true;
            // 
            // ColPrice
            // 
            this.ColPrice.FillWeight = 15F;
            this.ColPrice.HeaderText = "Цена, руб.";
            this.ColPrice.Name = "ColPrice";
            this.ColPrice.ReadOnly = true;
            // 
            // TbpSorted
            // 
            this.TbpSorted.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.TbpSorted.Controls.Add(this.DgvOrdered);
            this.TbpSorted.Location = new System.Drawing.Point(4, 27);
            this.TbpSorted.Name = "TbpSorted";
            this.TbpSorted.Padding = new System.Windows.Forms.Padding(3);
            this.TbpSorted.Size = new System.Drawing.Size(1176, 491);
            this.TbpSorted.TabIndex = 1;
            this.TbpSorted.Text = "Упорядоченная коллекция";
            this.TbpSorted.UseVisualStyleBackColor = true;
            // 
            // DgvOrdered
            // 
            this.DgvOrdered.AllowUserToAddRows = false;
            this.DgvOrdered.AllowUserToDeleteRows = false;
            this.DgvOrdered.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.DgvOrdered.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DgvOrdered.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6});
            this.DgvOrdered.Dock = System.Windows.Forms.DockStyle.Fill;
            this.DgvOrdered.Location = new System.Drawing.Point(3, 3);
            this.DgvOrdered.MultiSelect = false;
            this.DgvOrdered.Name = "DgvOrdered";
            this.DgvOrdered.ReadOnly = true;
            this.DgvOrdered.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DgvOrdered.Size = new System.Drawing.Size(1166, 481);
            this.DgvOrdered.TabIndex = 1;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.FillWeight = 10F;
            this.dataGridViewTextBoxColumn1.HeaderText = "Идентиф.";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.FillWeight = 15F;
            this.dataGridViewTextBoxColumn2.HeaderText = "Состояние";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.FillWeight = 20F;
            this.dataGridViewTextBoxColumn3.HeaderText = "Комната";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.FillWeight = 25F;
            this.dataGridViewTextBoxColumn4.HeaderText = "Название прибора";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.FillWeight = 20F;
            this.dataGridViewTextBoxColumn5.HeaderText = "Мощность, Вт";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.FillWeight = 15F;
            this.dataGridViewTextBoxColumn6.HeaderText = "Цена, руб.";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.ReadOnly = true;
            // 
            // TbpSelected
            // 
            this.TbpSelected.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.TbpSelected.Controls.Add(this.DgvFiltered);
            this.TbpSelected.Location = new System.Drawing.Point(4, 27);
            this.TbpSelected.Name = "TbpSelected";
            this.TbpSelected.Padding = new System.Windows.Forms.Padding(3);
            this.TbpSelected.Size = new System.Drawing.Size(1176, 491);
            this.TbpSelected.TabIndex = 2;
            this.TbpSelected.Text = "Выборка приборов";
            this.TbpSelected.UseVisualStyleBackColor = true;
            // 
            // DgvFiltered
            // 
            this.DgvFiltered.AllowUserToAddRows = false;
            this.DgvFiltered.AllowUserToDeleteRows = false;
            this.DgvFiltered.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.DgvFiltered.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DgvFiltered.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn7,
            this.dataGridViewTextBoxColumn8,
            this.dataGridViewTextBoxColumn9,
            this.dataGridViewTextBoxColumn10,
            this.dataGridViewTextBoxColumn11,
            this.dataGridViewTextBoxColumn12});
            this.DgvFiltered.Dock = System.Windows.Forms.DockStyle.Fill;
            this.DgvFiltered.Location = new System.Drawing.Point(3, 3);
            this.DgvFiltered.MultiSelect = false;
            this.DgvFiltered.Name = "DgvFiltered";
            this.DgvFiltered.ReadOnly = true;
            this.DgvFiltered.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DgvFiltered.Size = new System.Drawing.Size(1166, 481);
            this.DgvFiltered.TabIndex = 2;
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.FillWeight = 10F;
            this.dataGridViewTextBoxColumn7.HeaderText = "Идентиф.";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            this.dataGridViewTextBoxColumn7.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.FillWeight = 15F;
            this.dataGridViewTextBoxColumn8.HeaderText = "Состояние";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            this.dataGridViewTextBoxColumn8.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.FillWeight = 20F;
            this.dataGridViewTextBoxColumn9.HeaderText = "Комната";
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            this.dataGridViewTextBoxColumn9.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn10
            // 
            this.dataGridViewTextBoxColumn10.FillWeight = 25F;
            this.dataGridViewTextBoxColumn10.HeaderText = "Название прибора";
            this.dataGridViewTextBoxColumn10.Name = "dataGridViewTextBoxColumn10";
            this.dataGridViewTextBoxColumn10.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn11
            // 
            this.dataGridViewTextBoxColumn11.FillWeight = 20F;
            this.dataGridViewTextBoxColumn11.HeaderText = "Мощность, Вт";
            this.dataGridViewTextBoxColumn11.Name = "dataGridViewTextBoxColumn11";
            this.dataGridViewTextBoxColumn11.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn12
            // 
            this.dataGridViewTextBoxColumn12.FillWeight = 15F;
            this.dataGridViewTextBoxColumn12.HeaderText = "Цена, руб.";
            this.dataGridViewTextBoxColumn12.Name = "dataGridViewTextBoxColumn12";
            this.dataGridViewTextBoxColumn12.ReadOnly = true;
            // 
            // CmnTreeAppliance
            // 
            this.CmnTreeAppliance.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.CmnTreeAppliance.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem1,
            this.toolStripMenuItem2});
            this.CmnTreeAppliance.Name = "contextMenuStrip2";
            this.CmnTreeAppliance.Size = new System.Drawing.Size(231, 80);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Image = global::ElectricalAppliances.Properties.Resources.ledon1;
            this.toolStripMenuItem1.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(230, 38);
            this.toolStripMenuItem1.Text = "Включить прибор";
            this.toolStripMenuItem1.Click += new System.EventHandler(this.TurnOnApplianceCmnTree_Command);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Image = global::ElectricalAppliances.Properties.Resources.ledoff1;
            this.toolStripMenuItem2.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(230, 38);
            this.toolStripMenuItem2.Text = "Выключить прибор";
            this.toolStripMenuItem2.Click += new System.EventHandler(this.TurnOffApplianceCmnTree_Command);
            // 
            // CmnTreeRoom
            // 
            this.CmnTreeRoom.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.CmnTreeRoom.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.CmiTreeRoomTurnOnAll,
            this.CmiTreeRoomTurnOffAll});
            this.CmnTreeRoom.Name = "contextMenuStrip2";
            this.CmnTreeRoom.Size = new System.Drawing.Size(334, 80);
            // 
            // CmiTreeRoomTurnOnAll
            // 
            this.CmiTreeRoomTurnOnAll.Image = global::ElectricalAppliances.Properties.Resources.lightbulb;
            this.CmiTreeRoomTurnOnAll.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.CmiTreeRoomTurnOnAll.Name = "CmiTreeRoomTurnOnAll";
            this.CmiTreeRoomTurnOnAll.Size = new System.Drawing.Size(333, 38);
            this.CmiTreeRoomTurnOnAll.Text = "Включить все приборы комнаты";
            this.CmiTreeRoomTurnOnAll.Click += new System.EventHandler(this.TurnOnRoom_Command);
            // 
            // CmiTreeRoomTurnOffAll
            // 
            this.CmiTreeRoomTurnOffAll.Image = global::ElectricalAppliances.Properties.Resources.lightbulb_off;
            this.CmiTreeRoomTurnOffAll.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.CmiTreeRoomTurnOffAll.Name = "CmiTreeRoomTurnOffAll";
            this.CmiTreeRoomTurnOffAll.Size = new System.Drawing.Size(333, 38);
            this.CmiTreeRoomTurnOffAll.Text = "Выключить все приборы комнаты";
            this.CmiTreeRoomTurnOffAll.Click += new System.EventHandler(this.TurnOffRoom_Command);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1184, 641);
            this.Controls.Add(this.TbcMain);
            this.Controls.Add(this.LblApartmentInfo);
            this.Controls.Add(this.TstMain);
            this.Controls.Add(this.StsMain);
            this.Controls.Add(this.MnsMain);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.MnsMain;
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Задание на 09.12.2021 - изучение ListView";
            this.MnsMain.ResumeLayout(false);
            this.MnsMain.PerformLayout();
            this.TstMain.ResumeLayout(false);
            this.TstMain.PerformLayout();
            this.StsMain.ResumeLayout(false);
            this.StsMain.PerformLayout();
            this.CmnNotify.ResumeLayout(false);
            this.CmnDataGridView.ResumeLayout(false);
            this.TbcMain.ResumeLayout(false);
            this.TbpAppliances.ResumeLayout(false);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.CmnTreeApartment.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DgvAppliances)).EndInit();
            this.TbpSorted.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DgvOrdered)).EndInit();
            this.TbpSelected.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DgvFiltered)).EndInit();
            this.CmnTreeAppliance.ResumeLayout(false);
            this.CmnTreeRoom.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip MnsMain;
        private System.Windows.Forms.ToolStrip TstMain;
        private System.Windows.Forms.StatusStrip StsMain;
        private System.Windows.Forms.ContextMenuStrip CmnNotify;
        private System.Windows.Forms.ContextMenuStrip CmnDataGridView;
        private System.Windows.Forms.ToolStripMenuItem MniFile;
        private System.Windows.Forms.ToolStripMenuItem MniFileOpen;
        private System.Windows.Forms.ToolStripMenuItem MniFileSave;
        private System.Windows.Forms.ToolStripMenuItem MniFileSaveAs;
        private System.Windows.Forms.ToolStripSeparator MniFileSeparator1;
        private System.Windows.Forms.ToolStripMenuItem MniFileExit;
        private System.Windows.Forms.ToolStripMenuItem MniApartment;
        private System.Windows.Forms.ToolStripMenuItem новаяКвартираToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem редактироватьToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem MniControl;
        private System.Windows.Forms.ToolStripMenuItem MniControlToTray;
        private System.Windows.Forms.ToolStripMenuItem MniReport;
        private System.Windows.Forms.ToolStripMenuItem MniHelp;
        private System.Windows.Forms.ToolStripMenuItem MniHelpAbout;
        private System.Windows.Forms.OpenFileDialog OfdMain;
        private System.Windows.Forms.SaveFileDialog SfdMain;
        private System.Windows.Forms.NotifyIcon NtfMain;
        private System.Windows.Forms.ToolStripButton TsbNew;
        private System.Windows.Forms.ToolStripButton TsbOpen;
        private System.Windows.Forms.ToolStripButton TsbSave;
        private System.Windows.Forms.ToolStripSeparator TstSeparator1;
        private System.Windows.Forms.ToolStripButton TsbEditApartment;
        private System.Windows.Forms.ToolStripSeparator TstSeparator2;
        private System.Windows.Forms.ToolStripButton TsbToTray;
        private System.Windows.Forms.ToolStripButton TsbTurnOnAll;
        private System.Windows.Forms.ToolStripStatusLabel TslStatus;
        private System.Windows.Forms.ToolStripSeparator MniControlSeparator1;
        private System.Windows.Forms.ToolStripMenuItem MniControlTurnApplianceOn;
        private System.Windows.Forms.ToolStripMenuItem MniControlTurnApplianceOff;
        private System.Windows.Forms.ToolStripSeparator MniControlSeparator2;
        private System.Windows.Forms.ToolStripMenuItem MniControlTurnOnAll;
        private System.Windows.Forms.ToolStripMenuItem MniControlTurnOffAll;
        private System.Windows.Forms.ToolStripMenuItem MniReportOrder;
        private System.Windows.Forms.ToolStripMenuItem MniReportSelect;
        private System.Windows.Forms.ToolStripButton TsbTurnOffAll;
        private System.Windows.Forms.ToolStripMenuItem CmiRestore;
        private System.Windows.Forms.ToolStripSeparator CmiNotifySeparator1;
        private System.Windows.Forms.ToolStripMenuItem CmiAbout;
        private System.Windows.Forms.ToolStripSeparator CmiNotifySeparator2;
        private System.Windows.Forms.ToolStripMenuItem CmiExit;
        private System.Windows.Forms.ToolStripMenuItem MniReportOrderByName;
        private System.Windows.Forms.ToolStripMenuItem MniReportOrderByState;
        private System.Windows.Forms.ToolStripMenuItem MniReportOrderByPower;
        private System.Windows.Forms.ToolStripMenuItem MniReportOrderByPrice;
        private System.Windows.Forms.ToolStripMenuItem MniReportSelectByName;
        private System.Windows.Forms.ToolStripMenuItem MniReportSelectByState;
        private System.Windows.Forms.ImageList ImlSmall;
        private System.Windows.Forms.Label LblApartmentInfo;
        private System.Windows.Forms.TabControl TbcMain;
        private System.Windows.Forms.TabPage TbpAppliances;
        private System.Windows.Forms.TabPage TbpSorted;
        private System.Windows.Forms.TabPage TbpSelected;
        private System.Windows.Forms.ToolStripStatusLabel TslOn;
        private System.Windows.Forms.ToolStripStatusLabel TslOff;
        private System.Windows.Forms.ToolStripMenuItem CmiDataGridViewTurnOn;
        private System.Windows.Forms.ToolStripMenuItem CmiListViewTurnOff;
        private System.Windows.Forms.ToolStripSeparator CmiListViewSeparator1;
        private System.Windows.Forms.ToolStripMenuItem CmiListViewTurnOnAll;
        private System.Windows.Forms.ToolStripMenuItem CmiListViewTurnOffAll;
        private System.Windows.Forms.ToolStripSeparator CmiListViewSeparator2;
        private System.Windows.Forms.ToolStripMenuItem CmiListViewToTray;
        private System.Windows.Forms.ToolStripSeparator TstSeparator3;
        private System.Windows.Forms.ToolStripButton TsbAbout;
        private System.Windows.Forms.ToolStripButton TsbExit;
        private System.Windows.Forms.ToolStripSeparator MniFileSeparator2;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.TreeView TrvApartment;
        private System.Windows.Forms.ToolStripStatusLabel TslFileName;
        private System.Windows.Forms.ContextMenuStrip CmnTreeAppliance;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private System.Windows.Forms.ContextMenuStrip CmnTreeApartment;
        private System.Windows.Forms.ToolStripMenuItem CmiTreeApartmentTurnOnAll;
        private System.Windows.Forms.ToolStripMenuItem CmiTreeApartmentTurnOffAll;
        private System.Windows.Forms.ContextMenuStrip CmnTreeRoom;
        private System.Windows.Forms.ToolStripMenuItem CmiTreeRoomTurnOnAll;
        private System.Windows.Forms.ToolStripMenuItem CmiTreeRoomTurnOffAll;
        private System.Windows.Forms.DataGridView DgvAppliances;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColIdentifier;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColState;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColRoom;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColApplianceNane;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColPower;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColPrice;
        private System.Windows.Forms.DataGridView DgvOrdered;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridView DgvFiltered;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn11;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn12;
    }
}

