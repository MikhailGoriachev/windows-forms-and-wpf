﻿using System.Windows.Forms;

namespace ElectricalAppliances.Views
{
    public partial class AboutForm : Form
    {
        public AboutForm() {
            InitializeComponent();

            // снять выделение текста
            TxbAbout.SelectionStart = 0;
            TxbAbout.SelectionLength = 0;
        } // AboutForm
    } // class AboutForm 
}
