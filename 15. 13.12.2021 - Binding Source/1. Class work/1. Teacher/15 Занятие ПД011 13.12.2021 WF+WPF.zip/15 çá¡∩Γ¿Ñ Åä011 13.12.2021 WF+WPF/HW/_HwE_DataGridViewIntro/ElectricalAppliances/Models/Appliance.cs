﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ElectricalAppliances.Helpers;
using Microsoft.Win32;

namespace ElectricalAppliances.Models
{

    // Класс, описывающий электроприбор (название, мощность, цена
    // и состояние прибора: включен/выключен)


    public class Appliance
    {
        // идентификатор прибора, об уникальности идентификатора пока
        // не заботимся :)
        private int _id;
        public int Id { get => _id; set => _id = value; }

        // название электроприбора
        private string _name;
        public string Name {
            get => _name;
            set {
                if (string.IsNullOrEmpty(value)) 
                    throw new ArgumentNullException("Пустая строка в названии прибора");
                
                _name = value; 
            } // set
        } // Name

        // название комнаты, в которой размещен электроприбор
        private string _room;
        public string Room {
            get => _room;
            set {
                if (string.IsNullOrEmpty(value)) 
                    throw new ArgumentNullException("Пустая строка в названии комнаты");
                
                _room = value; 
            } // set
        } // Room

        // мощность электроприбора
        private int _power;
        public int Power {
            get => _power; 
            set {
                if (value <= 0)
                    throw new ArgumentOutOfRangeException($"Недопустимая мощность электроприбора: {value}");

                _power = value;
            } // set
        } // Power


        // цена электроприбора
        private int _price;
        public int Price {
            get => _price;
            set {
                if (value <= 0)
                    throw new ArgumentOutOfRangeException($"Недопустимая цена электроприбора: {value}");

                _price = value;
            } // set
        } // Price

        // состояние электроприбора: включен/выключен
        private bool _state;
        public bool State {
            get => _state;
            set => _state = value;
        } // State

        #region ансамбль конструкторов
        public Appliance() : this("чайник", "кухня", 1_200, 3_200, false) {
            Id = 0;
        } // Appliance

        public Appliance(string name, string room, int power, int price, bool state) {
            Name = name;
            Room = room; 
            Power = power;
            Price = price;
            State = state;
            _id = 0;
        } // Appliance
        #endregion

        // строковое представление объекта
        public override string ToString() =>
            $"{_id}, {_room}/{_name}: {_power} Вт, {_price} руб., {(_state?"Включен":"Выключен")}" ;

        // формирование строки в табличном представлениии
        public string ToTableRow(int indent) =>
            $"{" ".PadRight(indent)}" +
            $"│ {_id,6} │ {_room,-15} │ {_name, -22} │ {_power, 12:n2} │ {_price, 10:n2} │ " +
            $"{(_state ? "Включен" : "Выключен"), -10} │";

        // формирование строки для ListView
        public ListViewItem ToListViewItem() {
            // получить элемент для заполнения строки ListView,
            // указать в нем данные 0го столбца: если без текста и только число,
            // то это индекс картинки из ImageList, 0 - выключен, 1 - включен
            ListViewItem listViewItem = new ListViewItem("", _state?1:0);

            // добавить остальные столбцы
            listViewItem.SubItems.Add($"{_id}");
            listViewItem.SubItems.Add(_room);
            listViewItem.SubItems.Add(_name);
            listViewItem.SubItems.Add($"{_power:n2}");
            listViewItem.SubItems.Add($"{_price:n2}");

            return listViewItem;
        } // ToListViewItem

        // Шапка таблицы, статическое свойство
        public static string Header(int indent) {
            string spaces = " ".PadRight(indent);
            return
            $"{spaces}┌────────┬─────────────────┬────────────────────────┬──────────────┬────────────┬────────────┐\n" +
            $"{spaces}│ Идент. │ Комната         │ Название прибора       │ Мощность, Вт │ Цена, руб. │ Состояние  │\n" +
            $"{spaces}├────────┼─────────────────┼────────────────────────┼──────────────┼────────────┼────────────┤\n";
        } // Header

        // Подвал таблицы, статическое свойство
        public static string Footer(int indent) =>
            $"{" ".PadRight(indent)}└────────┴─────────────────┴────────────────────────┴──────────────┴────────────┴────────────┘\n";

        // Фабричный метод для создания электроприбора из случайных данных
        // уникальность идентификатора обеспечиваем внешним кодом
        public static Appliance Generate(int id) {
            // заготовка электроприбора
            (string Name, int Power, int Price)[] data = { 
                ("чайник", 1_200, 2_100), ("блендер", 300, 900), ("утюг", 1_100, 1_900), 
                ("миксер", 780, 1_100),   ("хлебопечка", 1_100, 9_200), 
                ("стиральная машина", 2_100, 13_800), ("микроволновка", 900, 9_600), 
                ("светильник", 20, 600), ("панель управления", 20, 900), 
                ("посудомоечная машина", 2_100, 13_000), ("вертикальный пылесос", 900, 11_300)
            };

            // комнаты
            string[] rooms = { "кухня", "гостиная", "спальня", "зал", "прихожая", "ванная", "туалет"};

            int index = Utils.Random.Next(0, data.Length);
            return new Appliance { 
                _id = id,
                _room = rooms[Utils.GetRandom(0, rooms.Length-1)],
                _name = data[index].Name, 
                _power = data[index].Power, 
                _price = data[index].Price,
                // сформировать состояние прибора - включен или выключен
                _state = Utils.GetRandom(0, 1) == 1  
            };
        } // Generate

        // заполнение строки DataGridView
        public DataGridViewRow ToDataGridViewRow() {
            DataGridViewRow row = new DataGridViewRow();

            // идентификатор прибора
            DataGridViewCell cell = new DataGridViewTextBoxCell();
            cell.Value = $"{Id}";
            cell.Style.Alignment = DataGridViewContentAlignment.MiddleLeft;
            row.Cells.Add(cell);

            // состояние прибора
            cell = new DataGridViewTextBoxCell();
            (cell.Value, cell.Style.BackColor) = State 
                ? ("Включен", Color.LightSeaGreen) 
                : ("Выключен",  Color.LightPink);
            cell.Style.Alignment = DataGridViewContentAlignment.MiddleLeft;
            row.Cells.Add(cell);

            // название комнаты
            cell = new DataGridViewTextBoxCell();
            cell.Value = Room;
            cell.Style.Alignment = DataGridViewContentAlignment.MiddleLeft;
            row.Cells.Add(cell);

            // название прибора
            cell = new DataGridViewTextBoxCell();
            cell.Value = Name;
            cell.Style.Alignment = DataGridViewContentAlignment.MiddleLeft;
            row.Cells.Add(cell);

            // мощность, Вт
            cell = new DataGridViewTextBoxCell();
            cell.Value = $"{Power}";
            cell.Style.Alignment = DataGridViewContentAlignment.MiddleRight;
            row.Cells.Add(cell);

            // цена, руб.
            cell = new DataGridViewTextBoxCell();
            cell.Value = $"{Price:n2}";
            cell.Style.Alignment = DataGridViewContentAlignment.MiddleRight;
            row.Cells.Add(cell);

            // вернуть сформированную строку таблицы
            return row;
        } // ToDataGridViewRow
    } // class Appliance
}
