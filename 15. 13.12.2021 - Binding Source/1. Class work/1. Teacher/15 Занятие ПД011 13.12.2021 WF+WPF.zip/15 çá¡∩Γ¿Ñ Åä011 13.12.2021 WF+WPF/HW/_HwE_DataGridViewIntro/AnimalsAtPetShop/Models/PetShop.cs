﻿using System;
using System.Collections.Generic;
using AnimalsAtPetShop.Helpers;

namespace AnimalsAtPetShop.Models
{
    // Учет животных в зоомагазине :)
    public class PetShop
    {
        // название магазина
        private string _name;
        public string Name {
            get => _name;
            set {
                if (string.IsNullOrWhiteSpace(value))
                    throw new ArgumentException("PetShop: название магазина не может быть пустым");

                _name = value;
            }
        } // Name

        // адрес магазина
        private string _address;
        public string Address {
            get => _address;
            set {
                if (string.IsNullOrWhiteSpace(value))
                    throw new ArgumentException("PetShop: адрес магазина не может быть пустым");

                _address = value;
            }
        } // Address

        // коллекция учитываемых животных
        private List<Animal> _animals;
        public List<Animal> Animals {
            get => _animals;
            set => _animals = value;
        } // Animals


        #region Ансамбль конструкторов

        public PetShop() : this("x", "y", new List<Animal>()) {
            Generate();
        } // PetShop

        public PetShop(string name, string address, List<Animal> animals) {
            Name = name;
            Address = address;
            Animals = animals;
        } // PetShop

        #endregion


        // формирование адреса магазина, коллекции животных
        public void Generate(int n = 12) {
            // получить название из нескольких предподготовленных названий
            _name = Utils.GetShopName();

            // получить адрес из нескольких предподготовленных адресов
            _address = Utils.GetAddress();

            // сформировать коллекцию животных
            _animals.Clear();

            // формирование (почти) неповторяющегося идентификатора - за счет
            // ширины диапазона генерации случайных чисел
            for (int i = 0; i < n; i++) {
                _animals.Add(Animal.Generate(Utils.GetRandom(1_000, 10_000)));
            } // for i
        } // Generate


        // получить максимальный вес животного
        public double GetMaxWeight() {
            double maxWeight = _animals[0].Weight;
            _animals.ForEach(a => maxWeight = a.Weight > maxWeight ? a.Weight : maxWeight);

            return maxWeight;
        } // GetMaxWeight


        // упорядочивание копии коллекции по заданному компаратору
        public List<Animal> OrderCopyBy(Comparison<Animal> comparison) {
            // получить копию коллекции животных 
            List<Animal> listAppliances = new List<Animal>(_animals);

            // упорядочить копию коллекции электроприборов и вернуть эту копию
            listAppliances.Sort(comparison);
            return listAppliances;
        } // OrderCopyBy


        // выборка данных из коллекции по заданному предикату
        public List<Animal> Filter(Predicate<Animal> predicate) =>
            _animals.FindAll(predicate);

    } // class PetShop
}
