﻿using System;

namespace AnimalsAtPetShop.Helpers
{
    // вспомогательные методы и объекты - статический класс, т.е. класс,
    // содержащий только статические члены и методы
    public static class Utils
    {

        // объект для получения случайных чисел
        public static readonly Random Random = new Random(Environment.TickCount);

        // Получение случайного числа
        // краткая форма записи метода - это не лямбда выражение
        public static int GetRandom(int lo, int hi) => Random.Next(lo, hi + 1);
        public static double GetRandom(double lo, double hi) => lo + (hi - lo) * Random.NextDouble();

        // формирование случайных целых чисел в заданном диапазоне (lo, hi),
        // исключая указанное параметром exclude число
        public static int GetRandomExclude(int lo, int hi, int exclude) {
            int number = 0;
            do
                number = Random.Next(lo, hi);
            while (number == exclude);

            return number;
        } // GetRandomExclude


        // возвращает одно из нескольких названий
        public static string GetShopName() {
            string[] names = {
                "ЗооФуд",  "Теремок",     "Зообонус", "Том и Джерри",
                "Маламут", "38 попугаев", "Любимчик", "Далматинец"
            };

            return names[GetRandom(0, names.Length-1)];
        } // GetShopName


        // возвращает один из нескольких адресов
        public static string GetAddress() {
            string[] addresses = {
                "г. Донецк, ул. Овнатаняна, д. 2",
                "г. Донецк, ул. проспект Лагутенко, д. 1",
                "г. Макеевка, ул. Ленина, д.34б",
                "г. Макеевка, ул. Матросова, д. 21",
                "г. Харцызск, ул. Октябрьская, д. 11",
                "г. Докучаевск, ул. Центральная, д. 5",
                "г. Ясиноватая, ул. Чернышевского, д. 19а",
                "г. Донецк, просп. Ватутина, д. 1",
                "г. Донецк, проспект Ленинский, 106",
                "г. Донецк, проспект Ленинский, 2",
            };
            return addresses[GetRandom(0, addresses.Length-1)];
        } // GetAddress

        // клички животных
        public static string GetAnimalName() {
            string[] animalNames = {
                "Жучка", "Шарик", "Лисичка", "Бантик", "Черныш",
                "Жар-птица", "Кроха", "Здоровяк", "Тихоня",
                "Смешинка", "Жорка", "Винтик"
            };

            return animalNames[GetRandom(0, animalNames.Length-1)];
        } // GetAnimalName

        // полные имена для владельцев животных
        public static string GetOwnerFullName() {
            string[] fullNames = {
                "Петрова Р.А.", "Семенова Ф.А.", "Гамджашвили Ю.В.", "Штурлак А.П.", "Хамбиков И.В.",
                "Духанова Д.В.", "Хаджикова Е.В.", "Калугина А.С.", "Пекарь В.В.", "Дёмина Д.А."
            };

            return fullNames[GetRandom(0, fullNames.Length-1)];
        } // GetOwnerFullName

        // цвета, масти для животных
        public static string GetColor() {
            string[] colors = {
                "черный", "белый", "пегий", "каурый", "черепаховый", "трехцветка",
                "серый", "крапчатый", "дымчатый", ""
            };

            return colors[GetRandom(0, colors.Length - 1)];
        } // GetColor

    } // class Utils
}