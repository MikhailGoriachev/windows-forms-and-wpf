﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization.Json;  // для JSON, добавить сборку System.Runtime.Serialization.dll

using AnimalsAtPetShop.Helpers;
using AnimalsAtPetShop.Models;

namespace AnimalsAtPetShop.Controllers
{
    /*
     * Контроллер для выполнения обработок по командам из представления, из форм:
     *     • При запуске приложения проверять наличие в папке исполняемого
     *       файла папки App_Data и файла pershop.json с данными о животных.
     *       Если папки и/или файл нет, то создать папку, заполнить начальными
     *       данными объект, описывающий зоомагазин, сериализовать данные в формате JSON
     *     • Переформирование коллекции животных и сведений о магазине
     *       с сериализацией 
     *     • Сохранение данных в выбранном файле – сериализация в формате JSON
     *     • Загрузка данных из файла, десериализация в формате JSON. 
     *     • Добавление животного в коллекцию, сериализация данных
     *     • Удаление животного из коллекции, сериализация данных
     *     • Упорядочивание копии коллекции животных
     *         o По возрасту
     *         o По виду животного
     *         o По фамилии и инициалам владельца
     *     • Выборка коллекции животных с максимальным весом
     *     • Выборка коллекции животных по фамлии и инициалам владельца
     *
     */
    public class PetShopController
    {
         // данные по магазину, который мы учитываем 
        private PetShop _petShop;

        // имя файла для хранения данных квартиры
        public string DataFileName { get; set; }


        #region Ансамбль конструкторов
        public PetShopController():this(new PetShop()) { } // PetShopController

        public PetShopController(PetShop petShop) {
            _petShop = petShop;
            DataFileName = "pet_shop.json";  // todo: только для запуска
        } // PetShopController
        #endregion

        // Переформирование коллекции животных и сведений о магазине
        // с сериализацией
        public void Generate() {
            _petShop.Generate(Utils.GetRandom(20, 25));
            SerializeData();
        } // Generate


        // -----------------------------------------------------------------------------------
        public List<Animal> GetAll() => _petShop.Animals;
        public PetShop PetShop => _petShop;

        public int Count => _petShop.Animals.Count;

        // -----------------------------------------------------------------------------------

        // сериализация данных в формате JSON
        public void SerializeData() {
            DataContractJsonSerializer jsonFormatter = new DataContractJsonSerializer(typeof(PetShop));

            // Запись объекта в JSON-файл
            using (FileStream fs = new FileStream(DataFileName, FileMode.Create)) {
                jsonFormatter.WriteObject(fs, _petShop);
            } // using
        } // SerializeData

        // десериализация данных из формата JSON
        public void DeserializeData() {
            DataContractJsonSerializer jsonFormatter = new DataContractJsonSerializer(typeof(PetShop));

            // Читаем коллекцию из JSON-файла
            using (FileStream fs = new FileStream(DataFileName, FileMode.Open)) {
                _petShop = (PetShop)jsonFormatter.ReadObject(fs);
            } // using
        } // DeserializeData

        // -----------------------------------------------------------------------------------
        
        // Добавление животного в коллекцию, сериализация данных
        public void AddAnimal(Animal animal) {
            _petShop.Animals.Add(animal);
            SerializeData();
        } // AddAnimal

        // Удаление животного из коллекции, сериализация данных
        public void RemoveAnimalAt(int index) {
            _petShop.Animals.RemoveAt(index);
            SerializeData();
        } // RemoveAnimalAt

        // -----------------------------------------------------------------------------------


        // Запрос на упорядочивание копии коллекции животных по возрасту
        public List<Animal> OrderByBrand() =>
            _petShop.OrderCopyBy((a1, a2) => a1.Age.CompareTo(a2.Age));


        // Запрос на упорядочивание копии коллекции животных по виду животного
        public List<Animal> OrderByType() =>
            _petShop.OrderCopyBy((a1, a2) => a1.AnimalType.CompareTo(a2.AnimalType));


        // Запрос на упорядочивание копии коллекции животных по фамилии и инициалам владельца
        public List<Animal> OrderByPower() =>
            _petShop.OrderCopyBy((a1, a2) => a1.OwnerFullName.CompareTo(a2.OwnerFullName));


        // -----------------------------------------------------------------------------------


        // Запрос на выборку в коллекцию животных с максимальным весом
        public List<Animal> SelectWhereMaxWeight() {
            double maxWeight = _petShop.GetMaxWeight();
            return _petShop.Filter(a => Math.Abs(a.Weight - maxWeight) < 1e-6);
        } // SelectWhereMaxWeight



        // Запрос на выборку в коллекцию животных, фамилия владельцев которых
        // содержит заданную подстроку 
        public List<Animal> SelectWhereOwnerFullNameContains(string template) =>
            _petShop.Filter(a => a.OwnerFullName.Contains(template));
    } // class PetShopController
}
