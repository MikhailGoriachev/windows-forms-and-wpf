﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using WF_Appliance.Utilities;

namespace WF_Appliance.Models
{
    /*
     •	Редактирование данных квартиры, сериализация данных
     •  Упорядочивание коллекции электроприборов, вывод упорядоченной копии коллекции в отдельной вкладке. При выборе команды переходить на вкладку
         o По названию
         o По состоянию
         o По мощности
         o По убыванию цены
     •  Включение/выключение выбранного электроприбора
     •  Включение/выключение всех электроприборов квартиры
     */

    [DataContract]
    //Квартира
    public class Flat
    {
        //Адрес квартиры
        [DataMember]
        string _adress;

        public string Adress
        {

            get => _adress;
            set
            {
                if (string.IsNullOrEmpty(value))
                    throw new Exception("Строка не может быть пустой!");
                _adress = value;
            }

        }

        //Коллекция приборов
        [DataMember]
        //приборы
        List<Appliance> _Appliances;

        //Свойство
        public List<Appliance> Appliances { get => _Appliances; }

        //Копия коллекции приборов для сортировки
        private List<Appliance> _CopyAppliances;

        static public int n = Utils.Random.Next(12, 15);

        public Flat(): this(new List<Appliance>(),"Будённовский просп.,19")
        {
            //Заполнение списка в диапазоне 12-15 элементов
            Generate(Utils.Random.Next(12,15));
            
        }//Flat. Default C_TOR

        //Счётчик элементов коллекции
        public int Count => _Appliances.Count;

        //Индексатор для чтения. 
        public Appliance this [int index]
        {
            get
            {
                if (index >= 0 && index < _Appliances.Count)
                    return _Appliances[index];
                throw new Exception("Выход за пределы списка!");
            }
        }

        public Flat(List<Appliance> appliances,string adress)
        {
            _Appliances = appliances;
            _CopyAppliances = new List<Appliance>();
            Adress = adress;
        }//Flat. Custom C_TOR

        public void Generate(int n)
        {
            _Appliances.Clear();

            for (int i = 0; i < n; i++)
                _Appliances.Add(Appliance.Generate());
        } // Generate


        //Добавление прибора в коллекцию 
        public void AddToList(Appliance Appliance)
        {
            _Appliances.Add(Appliance);
        }

        //Добавление коллекции приборов 
        public void AddCollectionToList(int count = 8)
        {
            Appliance[] appliances = new Appliance[count];

            //Создание коллекции 
            for (int i = 0; i < count; i++)
                appliances[i] = Appliance.Generate();

            //Добавление инициализированного массива в список 
            _Appliances.AddRange(appliances);

        }

        //Вывод в строку 
        public string ShowCollection()
        {
            StringBuilder strBuilder = new StringBuilder();
            foreach(Appliance appliance in _Appliances)
            {
                strBuilder.Append(appliance.ToTableRow);
                strBuilder.Append("\r\n");
            }

            return strBuilder.ToString();

        }

        //Включение/отключение прибора 
        public void TurnOnOff(int index,bool state)
        {
            //В случае задания некорректного индекса - уходим
            if (index < 0 || index >= Appliances.Count)
                return;
            Appliances[index].State = state;
        }

        //Включение/отключение прибора через передаваемый объект 
        public void TurnOnOff(Appliance appliance, bool state)
        {
            //В случае задания некорректного индекса - уходим
            if (!Appliances.Contains(appliance))
                return;
            //Получаем индекс нужного прибора 
            int ind = Appliances.IndexOf(appliance);
            Appliances[ind].State = state;
        }

        //Включение/отключение всех приборов 
        public void TurnAll(bool state)
        {
            foreach (var elem in Appliances)
            elem.State = state;
        }

        //Метод выборки, возвращаем список элементов выбранных по определенным условиям
        public List<Appliance> SelectBy(Predicate<Appliance> condition)
            => _Appliances.FindAll(condition);

       

    }
}
