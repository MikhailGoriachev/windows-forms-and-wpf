﻿namespace WF_Appliance
{
    partial class Main_form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Main_form));
            this.ContextMenu_MainLsv = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.AddCollectionCM = new System.Windows.Forms.ToolStripMenuItem();
            this.AddAppCM = new System.Windows.Forms.ToolStripMenuItem();
            this.OpenFile_CM = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator9 = new System.Windows.Forms.ToolStripSeparator();
            this.TurnOffAppliance_CM = new System.Windows.Forms.ToolStripMenuItem();
            this.TurnOnAppliance_CM = new System.Windows.Forms.ToolStripMenuItem();
            this.EditAppCM = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator8 = new System.Windows.Forms.ToolStripSeparator();
            this.DelAppCM = new System.Windows.Forms.ToolStripMenuItem();
            this.DelWhole_CM = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator6 = new System.Windows.Forms.ToolStripSeparator();
            this.SortsSetCM = new System.Windows.Forms.ToolStripMenuItem();
            this.SortByProducerCM = new System.Windows.Forms.ToolStripMenuItem();
            this.SortByDiagonalCM = new System.Windows.Forms.ToolStripMenuItem();
            this.SortByRepairerCM = new System.Windows.Forms.ToolStripMenuItem();
            this.SortByOwnerCM = new System.Windows.Forms.ToolStripMenuItem();
            this.SelecetionsSetCM = new System.Windows.Forms.ToolStripMenuItem();
            this.SelectiByName_CM = new System.Windows.Forms.ToolStripMenuItem();
            this.SelectiByState_CM = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator7 = new System.Windows.Forms.ToolStripSeparator();
            this.ChangeFont_CM = new System.Windows.Forms.ToolStripMenuItem();
            this.ChangeBackColor_CM = new System.Windows.Forms.ToolStripMenuItem();
            this.ChangeForeColor_CM = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuBar = new System.Windows.Forms.MenuStrip();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.выходToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.OpenFileTSMItem = new System.Windows.Forms.ToolStripMenuItem();
            this.Flat_TSI = new System.Windows.Forms.ToolStripMenuItem();
            this.редактироватьДанныеМастерскойToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.Appliances_TSI = new System.Windows.Forms.ToolStripMenuItem();
            this.AddAppToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.EditAppToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.DeleteAppMNI = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.ReformTSMItem = new System.Windows.Forms.ToolStripMenuItem();
            this.AddCollectionAppMni = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.SortsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.SortByNameTSMItem = new System.Windows.Forms.ToolStripMenuItem();
            this.SortByStateTSMItem = new System.Windows.Forms.ToolStripMenuItem();
            this.SortByPowerTSMItem = new System.Windows.Forms.ToolStripMenuItem();
            this.SortByPriceTSMItem = new System.Windows.Forms.ToolStripMenuItem();
            this.SelectionTSMItem = new System.Windows.Forms.ToolStripMenuItem();
            this.SelectNameTSMItem = new System.Windows.Forms.ToolStripMenuItem();
            this.SelectStatelTSMItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.TurnOnAllTopMni = new System.Windows.Forms.ToolStripMenuItem();
            this.TurnOffAllTopMni = new System.Windows.Forms.ToolStripMenuItem();
            this.AboutSoft_TSI = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolBar = new System.Windows.Forms.ToolStrip();
            this.BtnAddToolStrip = new System.Windows.Forms.ToolStripDropDownButton();
            this.AddCollectionTSMItem = new System.Windows.Forms.ToolStripMenuItem();
            this.AddTvMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.AddFileMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.BtnEditRsToolStrip = new System.Windows.Forms.ToolStripSplitButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.BtnSortsToolStrip = new System.Windows.Forms.ToolStripDropDownButton();
            this.BtnSortByBrandTSMItem = new System.Windows.Forms.ToolStripMenuItem();
            this.BtnSortByDiagonalTSMItem = new System.Windows.Forms.ToolStripMenuItem();
            this.BtnSortByRepairerTSMItem = new System.Windows.Forms.ToolStripMenuItem();
            this.BtnSortByOwnerTSMItem = new System.Windows.Forms.ToolStripMenuItem();
            this.BtnSelectionsToolStrip = new System.Windows.Forms.ToolStripDropDownButton();
            this.SelectByRepairerTSMItem = new System.Windows.Forms.ToolStripMenuItem();
            this.SelectByOwnerTSMItem = new System.Windows.Forms.ToolStripMenuItem();
            this.SelectBySubStrTSI = new System.Windows.Forms.ToolStripMenuItem();
            this.BtnEditToolStrip = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.BtnDelAppToolStrip = new System.Windows.Forms.ToolStripButton();
            this.BtnManyAppsStrip = new System.Windows.Forms.ToolStripDropDownButton();
            this.SubBtnDelAll = new System.Windows.Forms.ToolStripMenuItem();
            this.BtnExitToolStrip = new System.Windows.Forms.ToolStripButton();
            this.BtnHideToolStrip = new System.Windows.Forms.ToolStripButton();
            this.BtnTurnOnOneStrip = new System.Windows.Forms.ToolStripButton();
            this.BtnTurnOFFOneStrip = new System.Windows.Forms.ToolStripButton();
            this.OFD = new System.Windows.Forms.OpenFileDialog();
            this.SFD = new System.Windows.Forms.SaveFileDialog();
            this.FND_GridView = new System.Windows.Forms.FontDialog();
            this.CLD_GridView = new System.Windows.Forms.ColorDialog();
            this.ImageList_Appliances = new System.Windows.Forms.ImageList(this.components);
            this.Tmr_Leave_Tab = new System.Windows.Forms.Timer(this.components);
            this.NTI = new System.Windows.Forms.NotifyIcon(this.components);
            this.ContextMenu_NTI = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.открытьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.выходToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.оПрограммеToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.Sorts_Tab = new System.Windows.Forms.TabPage();
            this.Dgv_Sorts = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Gbx_Sorts_Tab = new System.Windows.Forms.GroupBox();
            this.Lbl_SortsTab = new System.Windows.Forms.Label();
            this.СontextMenu_Lsv_Sorts = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.Lsv_SortByName_CM = new System.Windows.Forms.ToolStripMenuItem();
            this.Lsv_SortByState_CM = new System.Windows.Forms.ToolStripMenuItem();
            this.Lsv_SortByPower_CM = new System.Windows.Forms.ToolStripMenuItem();
            this.Lsv_SortByPrice_CM = new System.Windows.Forms.ToolStripMenuItem();
            this.Selection_Tab = new System.Windows.Forms.TabPage();
            this.Lbl_SelectBy_room = new System.Windows.Forms.Label();
            this.Tbx_Search = new System.Windows.Forms.TextBox();
            this.Dgv_Selections = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Gbx_SelectionTab = new System.Windows.Forms.GroupBox();
            this.Lbl_SelectionTab = new System.Windows.Forms.Label();
            this.Main_tab = new System.Windows.Forms.TabPage();
            this.SplitContainer_Main = new System.Windows.Forms.SplitContainer();
            this.Trv_Main = new System.Windows.Forms.TreeView();
            this.ContexMS_TrvMain = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.CM_Trv_TurnOn = new System.Windows.Forms.ToolStripMenuItem();
            this.CM_Trv_TurnOff = new System.Windows.Forms.ToolStripMenuItem();
            this.CM_Trv_TurnAllOn = new System.Windows.Forms.ToolStripMenuItem();
            this.CM_Trv_TurnAllOff = new System.Windows.Forms.ToolStripMenuItem();
            this.CM_Trv_Edit_Applince = new System.Windows.Forms.ToolStripMenuItem();
            this.CM_Trv_Edit_Flat = new System.Windows.Forms.ToolStripMenuItem();
            this.CM_Trv_Delete = new System.Windows.Forms.ToolStripMenuItem();
            this.CM_Trv_AddItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ImageList_TrvMain = new System.Windows.Forms.ImageList(this.components);
            this.GbxAppliance = new System.Windows.Forms.GroupBox();
            this.TbxAppliance = new System.Windows.Forms.TextBox();
            this.Dgv_Main = new System.Windows.Forms.DataGridView();
            this.ColApplianceName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.RoomCol = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PowerCol = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PriceCol = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.StateCol = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.GbxRooms = new System.Windows.Forms.GroupBox();
            this.TbxRooms = new System.Windows.Forms.TextBox();
            this.Lbl_Main_Empty = new System.Windows.Forms.Label();
            this.Tab_Control_Main = new System.Windows.Forms.TabControl();
            this.toolStripStatusLbl = new System.Windows.Forms.ToolStripStatusLabel();
            this.TSl_Footer = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.TSl_Footer_SortTab = new System.Windows.Forms.ToolStripStatusLabel();
            this.StsMain = new System.Windows.Forms.StatusStrip();
            this.ContextMenu_MainLsv.SuspendLayout();
            this.MenuBar.SuspendLayout();
            this.ToolBar.SuspendLayout();
            this.ContextMenu_NTI.SuspendLayout();
            this.Sorts_Tab.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Dgv_Sorts)).BeginInit();
            this.Gbx_Sorts_Tab.SuspendLayout();
            this.СontextMenu_Lsv_Sorts.SuspendLayout();
            this.Selection_Tab.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Dgv_Selections)).BeginInit();
            this.Gbx_SelectionTab.SuspendLayout();
            this.Main_tab.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.SplitContainer_Main)).BeginInit();
            this.SplitContainer_Main.Panel1.SuspendLayout();
            this.SplitContainer_Main.Panel2.SuspendLayout();
            this.SplitContainer_Main.SuspendLayout();
            this.ContexMS_TrvMain.SuspendLayout();
            this.GbxAppliance.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Dgv_Main)).BeginInit();
            this.GbxRooms.SuspendLayout();
            this.Tab_Control_Main.SuspendLayout();
            this.StsMain.SuspendLayout();
            this.SuspendLayout();
            // 
            // ContextMenu_MainLsv
            // 
            this.ContextMenu_MainLsv.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.AddCollectionCM,
            this.AddAppCM,
            this.OpenFile_CM,
            this.toolStripSeparator9,
            this.TurnOffAppliance_CM,
            this.TurnOnAppliance_CM,
            this.EditAppCM,
            this.toolStripSeparator8,
            this.DelAppCM,
            this.DelWhole_CM,
            this.toolStripSeparator6,
            this.SortsSetCM,
            this.SelecetionsSetCM,
            this.toolStripSeparator7,
            this.ChangeFont_CM,
            this.ChangeBackColor_CM,
            this.ChangeForeColor_CM});
            this.ContextMenu_MainLsv.Name = "contextMenu_MainLbx";
            this.ContextMenu_MainLsv.Size = new System.Drawing.Size(210, 314);
            // 
            // AddCollectionCM
            // 
            this.AddCollectionCM.Name = "AddCollectionCM";
            this.AddCollectionCM.Size = new System.Drawing.Size(209, 22);
            this.AddCollectionCM.Text = "Добавить коллекцию ";
            this.AddCollectionCM.Click += new System.EventHandler(this.AddCollection_Command);
            // 
            // AddAppCM
            // 
            this.AddAppCM.Name = "AddAppCM";
            this.AddAppCM.Size = new System.Drawing.Size(209, 22);
            this.AddAppCM.Text = "Добавить прибор";
            this.AddAppCM.Click += new System.EventHandler(this.AddAppliance_Command);
            // 
            // OpenFile_CM
            // 
            this.OpenFile_CM.Name = "OpenFile_CM";
            this.OpenFile_CM.Size = new System.Drawing.Size(209, 22);
            this.OpenFile_CM.Text = "Открыть в файле";
            this.OpenFile_CM.Visible = false;
            this.OpenFile_CM.Click += new System.EventHandler(this.OpenFile_Command);
            // 
            // toolStripSeparator9
            // 
            this.toolStripSeparator9.Name = "toolStripSeparator9";
            this.toolStripSeparator9.Size = new System.Drawing.Size(206, 6);
            // 
            // TurnOffAppliance_CM
            // 
            this.TurnOffAppliance_CM.Name = "TurnOffAppliance_CM";
            this.TurnOffAppliance_CM.Size = new System.Drawing.Size(209, 22);
            this.TurnOffAppliance_CM.Text = "Выключить прибор";
            this.TurnOffAppliance_CM.Click += new System.EventHandler(this.TurnOffOne_Command);
            // 
            // TurnOnAppliance_CM
            // 
            this.TurnOnAppliance_CM.Name = "TurnOnAppliance_CM";
            this.TurnOnAppliance_CM.Size = new System.Drawing.Size(209, 22);
            this.TurnOnAppliance_CM.Text = "Включить прибор";
            this.TurnOnAppliance_CM.Click += new System.EventHandler(this.TurnOnOne_Command);
            // 
            // EditAppCM
            // 
            this.EditAppCM.Name = "EditAppCM";
            this.EditAppCM.Size = new System.Drawing.Size(209, 22);
            this.EditAppCM.Text = "Редактировать прибор";
            this.EditAppCM.Click += new System.EventHandler(this.EditAppliance_Command);
            // 
            // toolStripSeparator8
            // 
            this.toolStripSeparator8.Name = "toolStripSeparator8";
            this.toolStripSeparator8.Size = new System.Drawing.Size(206, 6);
            // 
            // DelAppCM
            // 
            this.DelAppCM.Name = "DelAppCM";
            this.DelAppCM.Size = new System.Drawing.Size(209, 22);
            this.DelAppCM.Text = "Удалить";
            this.DelAppCM.Click += new System.EventHandler(this.DelAppliance_Command);
            // 
            // DelWhole_CM
            // 
            this.DelWhole_CM.Name = "DelWhole_CM";
            this.DelWhole_CM.Size = new System.Drawing.Size(209, 22);
            this.DelWhole_CM.Text = "Удалить всю коллекцию";
            this.DelWhole_CM.Click += new System.EventHandler(this.DelAll_Command);
            // 
            // toolStripSeparator6
            // 
            this.toolStripSeparator6.Name = "toolStripSeparator6";
            this.toolStripSeparator6.Size = new System.Drawing.Size(206, 6);
            // 
            // SortsSetCM
            // 
            this.SortsSetCM.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.SortByProducerCM,
            this.SortByDiagonalCM,
            this.SortByRepairerCM,
            this.SortByOwnerCM});
            this.SortsSetCM.Name = "SortsSetCM";
            this.SortsSetCM.Size = new System.Drawing.Size(209, 22);
            this.SortsSetCM.Text = "Сортировки ";
            // 
            // SortByProducerCM
            // 
            this.SortByProducerCM.Name = "SortByProducerCM";
            this.SortByProducerCM.Size = new System.Drawing.Size(247, 22);
            this.SortByProducerCM.Text = "Сортировка по производителю";
            this.SortByProducerCM.Click += new System.EventHandler(this.SortByNameTSMItem_Command);
            // 
            // SortByDiagonalCM
            // 
            this.SortByDiagonalCM.Name = "SortByDiagonalCM";
            this.SortByDiagonalCM.Size = new System.Drawing.Size(247, 22);
            this.SortByDiagonalCM.Text = "Сортировка по диаголнали";
            this.SortByDiagonalCM.Click += new System.EventHandler(this.SortByStatelTSMItem_Command);
            // 
            // SortByRepairerCM
            // 
            this.SortByRepairerCM.Name = "SortByRepairerCM";
            this.SortByRepairerCM.Size = new System.Drawing.Size(247, 22);
            this.SortByRepairerCM.Text = "Сортировка по мастеру";
            this.SortByRepairerCM.Click += new System.EventHandler(this.SortByPowerTSMItem_Command);
            // 
            // SortByOwnerCM
            // 
            this.SortByOwnerCM.Name = "SortByOwnerCM";
            this.SortByOwnerCM.Size = new System.Drawing.Size(247, 22);
            this.SortByOwnerCM.Text = "Сортировка по владельцу";
            this.SortByOwnerCM.Click += new System.EventHandler(this.SortByPriceTSMItem_Command);
            // 
            // SelecetionsSetCM
            // 
            this.SelecetionsSetCM.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.SelectiByName_CM,
            this.SelectiByState_CM});
            this.SelecetionsSetCM.Name = "SelecetionsSetCM";
            this.SelecetionsSetCM.Size = new System.Drawing.Size(209, 22);
            this.SelecetionsSetCM.Text = "Выборки";
            // 
            // SelectiByName_CM
            // 
            this.SelectiByName_CM.Name = "SelectiByName_CM";
            this.SelectiByName_CM.Size = new System.Drawing.Size(204, 22);
            this.SelectiByName_CM.Text = "Выборка по названию";
            this.SelectiByName_CM.Click += new System.EventHandler(this.SelectByName_Command);
            // 
            // SelectiByState_CM
            // 
            this.SelectiByState_CM.Name = "SelectiByState_CM";
            this.SelectiByState_CM.Size = new System.Drawing.Size(204, 22);
            this.SelectiByState_CM.Text = "Выборка по состоянию";
            this.SelectiByState_CM.Click += new System.EventHandler(this.SelectByState_Command);
            // 
            // toolStripSeparator7
            // 
            this.toolStripSeparator7.Name = "toolStripSeparator7";
            this.toolStripSeparator7.Size = new System.Drawing.Size(206, 6);
            // 
            // ChangeFont_CM
            // 
            this.ChangeFont_CM.Name = "ChangeFont_CM";
            this.ChangeFont_CM.Size = new System.Drawing.Size(209, 22);
            this.ChangeFont_CM.Text = "Изменить шрифт";
            this.ChangeFont_CM.Click += new System.EventHandler(this.ChangeFont_Command);
            // 
            // ChangeBackColor_CM
            // 
            this.ChangeBackColor_CM.Name = "ChangeBackColor_CM";
            this.ChangeBackColor_CM.Size = new System.Drawing.Size(209, 22);
            this.ChangeBackColor_CM.Text = "Изменить цвет фона";
            this.ChangeBackColor_CM.Click += new System.EventHandler(this.ChangeColor_Command);
            // 
            // ChangeForeColor_CM
            // 
            this.ChangeForeColor_CM.Name = "ChangeForeColor_CM";
            this.ChangeForeColor_CM.Size = new System.Drawing.Size(209, 22);
            this.ChangeForeColor_CM.Text = "Изменить цвет текста";
            this.ChangeForeColor_CM.Click += new System.EventHandler(this.ChangeColor_Command);
            // 
            // MenuBar
            // 
            this.MenuBar.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem1,
            this.Flat_TSI,
            this.Appliances_TSI,
            this.AboutSoft_TSI});
            this.MenuBar.Location = new System.Drawing.Point(0, 0);
            this.MenuBar.Name = "MenuBar";
            this.MenuBar.Size = new System.Drawing.Size(1073, 24);
            this.MenuBar.TabIndex = 3;
            this.MenuBar.Text = "menuStrip1";
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.выходToolStripMenuItem,
            this.OpenFileTSMItem});
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(48, 20);
            this.toolStripMenuItem1.Text = "Файл";
            // 
            // выходToolStripMenuItem
            // 
            this.выходToolStripMenuItem.Name = "выходToolStripMenuItem";
            this.выходToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.F4)));
            this.выходToolStripMenuItem.Size = new System.Drawing.Size(167, 22);
            this.выходToolStripMenuItem.Text = "Выход";
            this.выходToolStripMenuItem.Click += new System.EventHandler(this.Exit_Command);
            // 
            // OpenFileTSMItem
            // 
            this.OpenFileTSMItem.Name = "OpenFileTSMItem";
            this.OpenFileTSMItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.O)));
            this.OpenFileTSMItem.Size = new System.Drawing.Size(167, 22);
            this.OpenFileTSMItem.Text = "Открыть ";
            this.OpenFileTSMItem.Click += new System.EventHandler(this.OpenFile_Command);
            // 
            // Flat_TSI
            // 
            this.Flat_TSI.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.редактироватьДанныеМастерскойToolStripMenuItem});
            this.Flat_TSI.Name = "Flat_TSI";
            this.Flat_TSI.Size = new System.Drawing.Size(70, 20);
            this.Flat_TSI.Text = "Квартира";
            // 
            // редактироватьДанныеМастерскойToolStripMenuItem
            // 
            this.редактироватьДанныеМастерскойToolStripMenuItem.Name = "редактироватьДанныеМастерскойToolStripMenuItem";
            this.редактироватьДанныеМастерскойToolStripMenuItem.Size = new System.Drawing.Size(254, 22);
            this.редактироватьДанныеМастерскойToolStripMenuItem.Text = "Редактировать данные квартиры";
            this.редактироватьДанныеМастерскойToolStripMenuItem.Click += new System.EventHandler(this.EditFlat_Command);
            // 
            // Appliances_TSI
            // 
            this.Appliances_TSI.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.AddAppToolStripMenuItem,
            this.EditAppToolStripMenuItem,
            this.DeleteAppMNI,
            this.toolStripSeparator2,
            this.ReformTSMItem,
            this.AddCollectionAppMni,
            this.toolStripSeparator5,
            this.SortsToolStripMenuItem,
            this.SelectionTSMItem,
            this.toolStripSeparator4,
            this.TurnOnAllTopMni,
            this.TurnOffAllTopMni});
            this.Appliances_TSI.Name = "Appliances_TSI";
            this.Appliances_TSI.Size = new System.Drawing.Size(72, 20);
            this.Appliances_TSI.Text = "Приборы";
            // 
            // AddAppToolStripMenuItem
            // 
            this.AddAppToolStripMenuItem.Name = "AddAppToolStripMenuItem";
            this.AddAppToolStripMenuItem.Size = new System.Drawing.Size(244, 22);
            this.AddAppToolStripMenuItem.Text = "Добавить прибор";
            this.AddAppToolStripMenuItem.Click += new System.EventHandler(this.AddAppliance_Command);
            // 
            // EditAppToolStripMenuItem
            // 
            this.EditAppToolStripMenuItem.Name = "EditAppToolStripMenuItem";
            this.EditAppToolStripMenuItem.Size = new System.Drawing.Size(244, 22);
            this.EditAppToolStripMenuItem.Text = "Редактировать прибор";
            this.EditAppToolStripMenuItem.Click += new System.EventHandler(this.EditAppliance_Command);
            // 
            // DeleteAppMNI
            // 
            this.DeleteAppMNI.Name = "DeleteAppMNI";
            this.DeleteAppMNI.Size = new System.Drawing.Size(244, 22);
            this.DeleteAppMNI.Text = "Удалить прибор";
            this.DeleteAppMNI.Click += new System.EventHandler(this.DelAppliance_Command);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(241, 6);
            // 
            // ReformTSMItem
            // 
            this.ReformTSMItem.Name = "ReformTSMItem";
            this.ReformTSMItem.Size = new System.Drawing.Size(244, 22);
            this.ReformTSMItem.Text = "Переформировать коллекцию";
            this.ReformTSMItem.Click += new System.EventHandler(this.ReformCollection_Command);
            // 
            // AddCollectionAppMni
            // 
            this.AddCollectionAppMni.Name = "AddCollectionAppMni";
            this.AddCollectionAppMni.Size = new System.Drawing.Size(244, 22);
            this.AddCollectionAppMni.Text = "Добавить коллекцию";
            this.AddCollectionAppMni.Click += new System.EventHandler(this.AddCollection_Command);
            // 
            // toolStripSeparator5
            // 
            this.toolStripSeparator5.Name = "toolStripSeparator5";
            this.toolStripSeparator5.Size = new System.Drawing.Size(241, 6);
            // 
            // SortsToolStripMenuItem
            // 
            this.SortsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.SortByNameTSMItem,
            this.SortByStateTSMItem,
            this.SortByPowerTSMItem,
            this.SortByPriceTSMItem});
            this.SortsToolStripMenuItem.Name = "SortsToolStripMenuItem";
            this.SortsToolStripMenuItem.Size = new System.Drawing.Size(244, 22);
            this.SortsToolStripMenuItem.Text = "Сортировки";
            // 
            // SortByNameTSMItem
            // 
            this.SortByNameTSMItem.Name = "SortByNameTSMItem";
            this.SortByNameTSMItem.Size = new System.Drawing.Size(183, 22);
            this.SortByNameTSMItem.Text = "По назаванию";
            this.SortByNameTSMItem.Click += new System.EventHandler(this.SortByNameTSMItem_Command);
            // 
            // SortByStateTSMItem
            // 
            this.SortByStateTSMItem.Name = "SortByStateTSMItem";
            this.SortByStateTSMItem.Size = new System.Drawing.Size(183, 22);
            this.SortByStateTSMItem.Text = "По состоянию";
            this.SortByStateTSMItem.Click += new System.EventHandler(this.SortByStatelTSMItem_Command);
            // 
            // SortByPowerTSMItem
            // 
            this.SortByPowerTSMItem.Name = "SortByPowerTSMItem";
            this.SortByPowerTSMItem.Size = new System.Drawing.Size(183, 22);
            this.SortByPowerTSMItem.Text = "По мощности";
            this.SortByPowerTSMItem.Click += new System.EventHandler(this.SortByPowerTSMItem_Command);
            // 
            // SortByPriceTSMItem
            // 
            this.SortByPriceTSMItem.Name = "SortByPriceTSMItem";
            this.SortByPriceTSMItem.Size = new System.Drawing.Size(183, 22);
            this.SortByPriceTSMItem.Text = "По убыванию цены";
            this.SortByPriceTSMItem.Click += new System.EventHandler(this.SortByPriceTSMItem_Command);
            // 
            // SelectionTSMItem
            // 
            this.SelectionTSMItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.SelectNameTSMItem,
            this.SelectStatelTSMItem});
            this.SelectionTSMItem.Name = "SelectionTSMItem";
            this.SelectionTSMItem.Size = new System.Drawing.Size(244, 22);
            this.SelectionTSMItem.Text = "Выборки";
            // 
            // SelectNameTSMItem
            // 
            this.SelectNameTSMItem.Name = "SelectNameTSMItem";
            this.SelectNameTSMItem.Size = new System.Drawing.Size(154, 22);
            this.SelectNameTSMItem.Text = "По названию";
            this.SelectNameTSMItem.Click += new System.EventHandler(this.SelectByName_Command);
            // 
            // SelectStatelTSMItem
            // 
            this.SelectStatelTSMItem.Name = "SelectStatelTSMItem";
            this.SelectStatelTSMItem.Size = new System.Drawing.Size(154, 22);
            this.SelectStatelTSMItem.Text = "По состоянию";
            this.SelectStatelTSMItem.Click += new System.EventHandler(this.SelectByState_Command);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(241, 6);
            // 
            // TurnOnAllTopMni
            // 
            this.TurnOnAllTopMni.Name = "TurnOnAllTopMni";
            this.TurnOnAllTopMni.Size = new System.Drawing.Size(244, 22);
            this.TurnOnAllTopMni.Text = "Включить все";
            this.TurnOnAllTopMni.ToolTipText = "Включить все прибор в квартире";
            this.TurnOnAllTopMni.Click += new System.EventHandler(this.TurnOnAll_Command);
            // 
            // TurnOffAllTopMni
            // 
            this.TurnOffAllTopMni.Name = "TurnOffAllTopMni";
            this.TurnOffAllTopMni.Size = new System.Drawing.Size(244, 22);
            this.TurnOffAllTopMni.Text = "Выключить все";
            this.TurnOffAllTopMni.ToolTipText = "Выключить все прибор";
            this.TurnOffAllTopMni.Click += new System.EventHandler(this.TurnOffAll_Command);
            // 
            // AboutSoft_TSI
            // 
            this.AboutSoft_TSI.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.AboutSoft_TSI.Enabled = false;
            this.AboutSoft_TSI.Name = "AboutSoft_TSI";
            this.AboutSoft_TSI.Size = new System.Drawing.Size(94, 20);
            this.AboutSoft_TSI.Text = "О программе";
            this.AboutSoft_TSI.Click += new System.EventHandler(this.About_Command);
            // 
            // ToolBar
            // 
            this.ToolBar.AutoSize = false;
            this.ToolBar.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.BtnAddToolStrip,
            this.BtnEditRsToolStrip,
            this.toolStripSeparator1,
            this.BtnSortsToolStrip,
            this.BtnSelectionsToolStrip,
            this.BtnEditToolStrip,
            this.toolStripSeparator3,
            this.BtnDelAppToolStrip,
            this.BtnManyAppsStrip,
            this.BtnExitToolStrip,
            this.BtnHideToolStrip,
            this.BtnTurnOnOneStrip,
            this.BtnTurnOFFOneStrip});
            this.ToolBar.Location = new System.Drawing.Point(0, 24);
            this.ToolBar.Name = "ToolBar";
            this.ToolBar.Size = new System.Drawing.Size(1073, 31);
            this.ToolBar.TabIndex = 14;
            this.ToolBar.Text = "toolStrip1";
            // 
            // BtnAddToolStrip
            // 
            this.BtnAddToolStrip.AutoSize = false;
            this.BtnAddToolStrip.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.BtnAddToolStrip.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.AddCollectionTSMItem,
            this.AddTvMenuItem,
            this.AddFileMenuItem});
            this.BtnAddToolStrip.Image = ((System.Drawing.Image)(resources.GetObject("BtnAddToolStrip.Image")));
            this.BtnAddToolStrip.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.BtnAddToolStrip.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.BtnAddToolStrip.Name = "BtnAddToolStrip";
            this.BtnAddToolStrip.Size = new System.Drawing.Size(39, 22);
            this.BtnAddToolStrip.Text = "toolStripDropDownButton1";
            this.BtnAddToolStrip.ToolTipText = "Добавление объекта";
            // 
            // AddCollectionTSMItem
            // 
            this.AddCollectionTSMItem.Name = "AddCollectionTSMItem";
            this.AddCollectionTSMItem.Size = new System.Drawing.Size(192, 22);
            this.AddCollectionTSMItem.Text = "Добавить коллекцию";
            this.AddCollectionTSMItem.Click += new System.EventHandler(this.AddCollection_Command);
            // 
            // AddTvMenuItem
            // 
            this.AddTvMenuItem.Name = "AddTvMenuItem";
            this.AddTvMenuItem.Size = new System.Drawing.Size(192, 22);
            this.AddTvMenuItem.Text = "Добавить прибор";
            this.AddTvMenuItem.Click += new System.EventHandler(this.AddAppliance_Command);
            // 
            // AddFileMenuItem
            // 
            this.AddFileMenuItem.Name = "AddFileMenuItem";
            this.AddFileMenuItem.Size = new System.Drawing.Size(192, 22);
            this.AddFileMenuItem.Text = "Добавить из файла";
            this.AddFileMenuItem.Click += new System.EventHandler(this.OpenFile_Command);
            // 
            // BtnEditRsToolStrip
            // 
            this.BtnEditRsToolStrip.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.BtnEditRsToolStrip.Image = ((System.Drawing.Image)(resources.GetObject("BtnEditRsToolStrip.Image")));
            this.BtnEditRsToolStrip.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.BtnEditRsToolStrip.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.BtnEditRsToolStrip.Name = "BtnEditRsToolStrip";
            this.BtnEditRsToolStrip.Size = new System.Drawing.Size(36, 28);
            this.BtnEditRsToolStrip.Text = "toolStripSplitButton2";
            this.BtnEditRsToolStrip.ToolTipText = "Редактирование квартиры";
            this.BtnEditRsToolStrip.ButtonClick += new System.EventHandler(this.EditFlat_Command);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 31);
            // 
            // BtnSortsToolStrip
            // 
            this.BtnSortsToolStrip.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.BtnSortsToolStrip.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.BtnSortByBrandTSMItem,
            this.BtnSortByDiagonalTSMItem,
            this.BtnSortByRepairerTSMItem,
            this.BtnSortByOwnerTSMItem});
            this.BtnSortsToolStrip.Image = ((System.Drawing.Image)(resources.GetObject("BtnSortsToolStrip.Image")));
            this.BtnSortsToolStrip.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.BtnSortsToolStrip.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.BtnSortsToolStrip.Name = "BtnSortsToolStrip";
            this.BtnSortsToolStrip.Size = new System.Drawing.Size(33, 28);
            this.BtnSortsToolStrip.ToolTipText = "Сортировки";
            // 
            // BtnSortByBrandTSMItem
            // 
            this.BtnSortByBrandTSMItem.Name = "BtnSortByBrandTSMItem";
            this.BtnSortByBrandTSMItem.Size = new System.Drawing.Size(221, 22);
            this.BtnSortByBrandTSMItem.Text = "Сортировка названию";
            this.BtnSortByBrandTSMItem.Click += new System.EventHandler(this.SortByNameTSMItem_Command);
            // 
            // BtnSortByDiagonalTSMItem
            // 
            this.BtnSortByDiagonalTSMItem.Name = "BtnSortByDiagonalTSMItem";
            this.BtnSortByDiagonalTSMItem.Size = new System.Drawing.Size(221, 22);
            this.BtnSortByDiagonalTSMItem.Text = "Сортировка по состоянию";
            this.BtnSortByDiagonalTSMItem.Click += new System.EventHandler(this.SortByStatelTSMItem_Command);
            // 
            // BtnSortByRepairerTSMItem
            // 
            this.BtnSortByRepairerTSMItem.Name = "BtnSortByRepairerTSMItem";
            this.BtnSortByRepairerTSMItem.Size = new System.Drawing.Size(221, 22);
            this.BtnSortByRepairerTSMItem.Text = "Сортировка по мощности";
            this.BtnSortByRepairerTSMItem.Click += new System.EventHandler(this.SortByPowerTSMItem_Command);
            // 
            // BtnSortByOwnerTSMItem
            // 
            this.BtnSortByOwnerTSMItem.Name = "BtnSortByOwnerTSMItem";
            this.BtnSortByOwnerTSMItem.Size = new System.Drawing.Size(221, 22);
            this.BtnSortByOwnerTSMItem.Text = "Сортировка по стоимости";
            this.BtnSortByOwnerTSMItem.Click += new System.EventHandler(this.SortByPriceTSMItem_Command);
            // 
            // BtnSelectionsToolStrip
            // 
            this.BtnSelectionsToolStrip.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.BtnSelectionsToolStrip.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.SelectByRepairerTSMItem,
            this.SelectByOwnerTSMItem,
            this.SelectBySubStrTSI});
            this.BtnSelectionsToolStrip.Image = ((System.Drawing.Image)(resources.GetObject("BtnSelectionsToolStrip.Image")));
            this.BtnSelectionsToolStrip.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.BtnSelectionsToolStrip.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.BtnSelectionsToolStrip.Name = "BtnSelectionsToolStrip";
            this.BtnSelectionsToolStrip.Size = new System.Drawing.Size(33, 28);
            this.BtnSelectionsToolStrip.Text = "toolStripDropDownButton1";
            this.BtnSelectionsToolStrip.ToolTipText = "Выборки приборов";
            // 
            // SelectByRepairerTSMItem
            // 
            this.SelectByRepairerTSMItem.Name = "SelectByRepairerTSMItem";
            this.SelectByRepairerTSMItem.Size = new System.Drawing.Size(204, 22);
            this.SelectByRepairerTSMItem.Text = "Выборка по названию";
            this.SelectByRepairerTSMItem.Click += new System.EventHandler(this.SelectByName_Command);
            // 
            // SelectByOwnerTSMItem
            // 
            this.SelectByOwnerTSMItem.Name = "SelectByOwnerTSMItem";
            this.SelectByOwnerTSMItem.Size = new System.Drawing.Size(204, 22);
            this.SelectByOwnerTSMItem.Text = "Выборка по состоянию";
            this.SelectByOwnerTSMItem.Click += new System.EventHandler(this.SelectByState_Command);
            // 
            // SelectBySubStrTSI
            // 
            this.SelectBySubStrTSI.Name = "SelectBySubStrTSI";
            this.SelectBySubStrTSI.Size = new System.Drawing.Size(204, 22);
            this.SelectBySubStrTSI.Text = "Выборка по комнате";
            this.SelectBySubStrTSI.Click += new System.EventHandler(this.SelectBySubStr_Command);
            // 
            // BtnEditToolStrip
            // 
            this.BtnEditToolStrip.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.BtnEditToolStrip.Image = ((System.Drawing.Image)(resources.GetObject("BtnEditToolStrip.Image")));
            this.BtnEditToolStrip.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.BtnEditToolStrip.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.BtnEditToolStrip.Name = "BtnEditToolStrip";
            this.BtnEditToolStrip.Size = new System.Drawing.Size(24, 28);
            this.BtnEditToolStrip.ToolTipText = "Редактировать прибор";
            this.BtnEditToolStrip.Click += new System.EventHandler(this.EditAppliance_Command);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(6, 31);
            // 
            // BtnDelAppToolStrip
            // 
            this.BtnDelAppToolStrip.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.BtnDelAppToolStrip.Image = ((System.Drawing.Image)(resources.GetObject("BtnDelAppToolStrip.Image")));
            this.BtnDelAppToolStrip.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.BtnDelAppToolStrip.Name = "BtnDelAppToolStrip";
            this.BtnDelAppToolStrip.Size = new System.Drawing.Size(23, 28);
            this.BtnDelAppToolStrip.Text = "toolStripButton1";
            this.BtnDelAppToolStrip.ToolTipText = "Удалить прибор";
            this.BtnDelAppToolStrip.Click += new System.EventHandler(this.DelAppliance_Command);
            // 
            // BtnManyAppsStrip
            // 
            this.BtnManyAppsStrip.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.BtnManyAppsStrip.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.SubBtnDelAll});
            this.BtnManyAppsStrip.Image = ((System.Drawing.Image)(resources.GetObject("BtnManyAppsStrip.Image")));
            this.BtnManyAppsStrip.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.BtnManyAppsStrip.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.BtnManyAppsStrip.Name = "BtnManyAppsStrip";
            this.BtnManyAppsStrip.Size = new System.Drawing.Size(33, 28);
            this.BtnManyAppsStrip.ToolTipText = "Удаление коллекции";
            // 
            // SubBtnDelAll
            // 
            this.SubBtnDelAll.Name = "SubBtnDelAll";
            this.SubBtnDelAll.Size = new System.Drawing.Size(209, 22);
            this.SubBtnDelAll.Text = "Удалить всю коллекцию";
            this.SubBtnDelAll.Click += new System.EventHandler(this.DelAll_Command);
            // 
            // BtnExitToolStrip
            // 
            this.BtnExitToolStrip.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.BtnExitToolStrip.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.BtnExitToolStrip.Image = ((System.Drawing.Image)(resources.GetObject("BtnExitToolStrip.Image")));
            this.BtnExitToolStrip.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.BtnExitToolStrip.Name = "BtnExitToolStrip";
            this.BtnExitToolStrip.Size = new System.Drawing.Size(23, 28);
            this.BtnExitToolStrip.Click += new System.EventHandler(this.Exit_Command);
            // 
            // BtnHideToolStrip
            // 
            this.BtnHideToolStrip.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.BtnHideToolStrip.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.BtnHideToolStrip.Image = ((System.Drawing.Image)(resources.GetObject("BtnHideToolStrip.Image")));
            this.BtnHideToolStrip.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.BtnHideToolStrip.Name = "BtnHideToolStrip";
            this.BtnHideToolStrip.Size = new System.Drawing.Size(23, 28);
            this.BtnHideToolStrip.Text = "toolStripButton1";
            this.BtnHideToolStrip.ToolTipText = "Свернуть в tray";
            this.BtnHideToolStrip.Click += new System.EventHandler(this.HideForm_Command);
            // 
            // BtnTurnOnOneStrip
            // 
            this.BtnTurnOnOneStrip.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.BtnTurnOnOneStrip.Image = ((System.Drawing.Image)(resources.GetObject("BtnTurnOnOneStrip.Image")));
            this.BtnTurnOnOneStrip.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.BtnTurnOnOneStrip.Name = "BtnTurnOnOneStrip";
            this.BtnTurnOnOneStrip.Size = new System.Drawing.Size(23, 28);
            this.BtnTurnOnOneStrip.ToolTipText = "Включить прибор";
            this.BtnTurnOnOneStrip.Click += new System.EventHandler(this.TurnOnOne_Command);
            // 
            // BtnTurnOFFOneStrip
            // 
            this.BtnTurnOFFOneStrip.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.BtnTurnOFFOneStrip.Image = ((System.Drawing.Image)(resources.GetObject("BtnTurnOFFOneStrip.Image")));
            this.BtnTurnOFFOneStrip.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.BtnTurnOFFOneStrip.Name = "BtnTurnOFFOneStrip";
            this.BtnTurnOFFOneStrip.Size = new System.Drawing.Size(23, 28);
            this.BtnTurnOFFOneStrip.Text = "toolStripButton2";
            this.BtnTurnOFFOneStrip.ToolTipText = "Выключить прибор";
            this.BtnTurnOFFOneStrip.Click += new System.EventHandler(this.TurnOffOne_Command);
            // 
            // OFD
            // 
            this.OFD.Filter = "(*.json)|*.json";
            this.OFD.InitialDirectory = "*\\\\";
            // 
            // SFD
            // 
            this.SFD.Filter = "(*.json)|*.json";
            // 
            // ImageList_Appliances
            // 
            this.ImageList_Appliances.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("ImageList_Appliances.ImageStream")));
            this.ImageList_Appliances.TransparentColor = System.Drawing.Color.Transparent;
            this.ImageList_Appliances.Images.SetKeyName(0, "Turn_off_30x30.png");
            this.ImageList_Appliances.Images.SetKeyName(1, "Turn_On_30x30.png");
            // 
            // NTI
            // 
            this.NTI.Text = "Form";
            this.NTI.Visible = true;
            // 
            // ContextMenu_NTI
            // 
            this.ContextMenu_NTI.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.открытьToolStripMenuItem,
            this.выходToolStripMenuItem1,
            this.оПрограммеToolStripMenuItem1});
            this.ContextMenu_NTI.Name = "ContextMenu_NTI";
            this.ContextMenu_NTI.Size = new System.Drawing.Size(150, 70);
            // 
            // открытьToolStripMenuItem
            // 
            this.открытьToolStripMenuItem.Name = "открытьToolStripMenuItem";
            this.открытьToolStripMenuItem.Size = new System.Drawing.Size(149, 22);
            this.открытьToolStripMenuItem.Text = "Открыть";
            this.открытьToolStripMenuItem.Click += new System.EventHandler(this.OpenFromTray_Command);
            // 
            // выходToolStripMenuItem1
            // 
            this.выходToolStripMenuItem1.Name = "выходToolStripMenuItem1";
            this.выходToolStripMenuItem1.Size = new System.Drawing.Size(149, 22);
            this.выходToolStripMenuItem1.Text = "Выход";
            this.выходToolStripMenuItem1.Click += new System.EventHandler(this.Exit_Command);
            // 
            // оПрограммеToolStripMenuItem1
            // 
            this.оПрограммеToolStripMenuItem1.Name = "оПрограммеToolStripMenuItem1";
            this.оПрограммеToolStripMenuItem1.Size = new System.Drawing.Size(149, 22);
            this.оПрограммеToolStripMenuItem1.Text = "О программе";
            this.оПрограммеToolStripMenuItem1.Click += new System.EventHandler(this.About_Command);
            // 
            // Sorts_Tab
            // 
            this.Sorts_Tab.Controls.Add(this.Dgv_Sorts);
            this.Sorts_Tab.Controls.Add(this.Gbx_Sorts_Tab);
            this.Sorts_Tab.Location = new System.Drawing.Point(4, 22);
            this.Sorts_Tab.Name = "Sorts_Tab";
            this.Sorts_Tab.Size = new System.Drawing.Size(1065, 525);
            this.Sorts_Tab.TabIndex = 2;
            this.Sorts_Tab.Text = "Сортировки";
            this.Sorts_Tab.UseVisualStyleBackColor = true;
            this.Sorts_Tab.Enter += new System.EventHandler(this.Enter_Dyn_Tab);
            this.Sorts_Tab.Leave += new System.EventHandler(this.Tab_Leave);
            // 
            // Dgv_Sorts
            // 
            this.Dgv_Sorts.AllowDrop = true;
            this.Dgv_Sorts.AllowUserToAddRows = false;
            this.Dgv_Sorts.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.Dgv_Sorts.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Dgv_Sorts.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.Dgv_Sorts.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Dgv_Sorts.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn6,
            this.dataGridViewTextBoxColumn7,
            this.dataGridViewTextBoxColumn8,
            this.dataGridViewTextBoxColumn9,
            this.dataGridViewTextBoxColumn10});
            this.Dgv_Sorts.ContextMenuStrip = this.ContextMenu_MainLsv;
            this.Dgv_Sorts.GridColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Dgv_Sorts.Location = new System.Drawing.Point(0, 3);
            this.Dgv_Sorts.Name = "Dgv_Sorts";
            this.Dgv_Sorts.RowHeadersVisible = false;
            this.Dgv_Sorts.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.LightSteelBlue;
            this.Dgv_Sorts.RowTemplate.DefaultCellStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.Dgv_Sorts.RowTemplate.DefaultCellStyle.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.Dgv_Sorts.RowTemplate.ReadOnly = true;
            this.Dgv_Sorts.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.Dgv_Sorts.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.Dgv_Sorts.Size = new System.Drawing.Size(770, 519);
            this.Dgv_Sorts.TabIndex = 12;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn6.HeaderText = "Название прибора";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn7.HeaderText = "Комната";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            this.dataGridViewTextBoxColumn7.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn8.FillWeight = 50F;
            this.dataGridViewTextBoxColumn8.HeaderText = "Мощность";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            this.dataGridViewTextBoxColumn8.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn9.FillWeight = 45F;
            this.dataGridViewTextBoxColumn9.HeaderText = "Стоимость";
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            this.dataGridViewTextBoxColumn9.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn10
            // 
            this.dataGridViewTextBoxColumn10.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn10.HeaderText = "Состояние";
            this.dataGridViewTextBoxColumn10.Name = "dataGridViewTextBoxColumn10";
            this.dataGridViewTextBoxColumn10.ReadOnly = true;
            // 
            // Gbx_Sorts_Tab
            // 
            this.Gbx_Sorts_Tab.Controls.Add(this.Lbl_SortsTab);
            this.Gbx_Sorts_Tab.Location = new System.Drawing.Point(794, 65);
            this.Gbx_Sorts_Tab.Name = "Gbx_Sorts_Tab";
            this.Gbx_Sorts_Tab.Size = new System.Drawing.Size(254, 205);
            this.Gbx_Sorts_Tab.TabIndex = 11;
            this.Gbx_Sorts_Tab.TabStop = false;
            // 
            // Lbl_SortsTab
            // 
            this.Lbl_SortsTab.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Lbl_SortsTab.Font = new System.Drawing.Font("Rotonda Bold", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl_SortsTab.Location = new System.Drawing.Point(3, 16);
            this.Lbl_SortsTab.Name = "Lbl_SortsTab";
            this.Lbl_SortsTab.Size = new System.Drawing.Size(248, 186);
            this.Lbl_SortsTab.TabIndex = 9;
            this.Lbl_SortsTab.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // СontextMenu_Lsv_Sorts
            // 
            this.СontextMenu_Lsv_Sorts.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.Lsv_SortByName_CM,
            this.Lsv_SortByState_CM,
            this.Lsv_SortByPower_CM,
            this.Lsv_SortByPrice_CM});
            this.СontextMenu_Lsv_Sorts.Name = "СontextMenu_Lsv_Sorts";
            this.СontextMenu_Lsv_Sorts.Size = new System.Drawing.Size(222, 92);
            // 
            // Lsv_SortByName_CM
            // 
            this.Lsv_SortByName_CM.Name = "Lsv_SortByName_CM";
            this.Lsv_SortByName_CM.Size = new System.Drawing.Size(221, 22);
            this.Lsv_SortByName_CM.Text = "Сортировка по названию";
            this.Lsv_SortByName_CM.Click += new System.EventHandler(this.SortByNameTSMItem_Command);
            // 
            // Lsv_SortByState_CM
            // 
            this.Lsv_SortByState_CM.Name = "Lsv_SortByState_CM";
            this.Lsv_SortByState_CM.Size = new System.Drawing.Size(221, 22);
            this.Lsv_SortByState_CM.Text = "Сортировка по состоянию";
            this.Lsv_SortByState_CM.Click += new System.EventHandler(this.SortByStatelTSMItem_Command);
            // 
            // Lsv_SortByPower_CM
            // 
            this.Lsv_SortByPower_CM.Name = "Lsv_SortByPower_CM";
            this.Lsv_SortByPower_CM.Size = new System.Drawing.Size(221, 22);
            this.Lsv_SortByPower_CM.Text = "Сортировка по мощности";
            this.Lsv_SortByPower_CM.Click += new System.EventHandler(this.SortByPowerTSMItem_Command);
            // 
            // Lsv_SortByPrice_CM
            // 
            this.Lsv_SortByPrice_CM.Name = "Lsv_SortByPrice_CM";
            this.Lsv_SortByPrice_CM.Size = new System.Drawing.Size(221, 22);
            this.Lsv_SortByPrice_CM.Text = "Сортировка по стоимости";
            this.Lsv_SortByPrice_CM.Click += new System.EventHandler(this.SortByPriceTSMItem_Command);
            // 
            // Selection_Tab
            // 
            this.Selection_Tab.Controls.Add(this.Tbx_Search);
            this.Selection_Tab.Controls.Add(this.Dgv_Selections);
            this.Selection_Tab.Controls.Add(this.Gbx_SelectionTab);
            this.Selection_Tab.Controls.Add(this.Lbl_SelectBy_room);
            this.Selection_Tab.Location = new System.Drawing.Point(4, 22);
            this.Selection_Tab.Name = "Selection_Tab";
            this.Selection_Tab.Padding = new System.Windows.Forms.Padding(3);
            this.Selection_Tab.Size = new System.Drawing.Size(1065, 525);
            this.Selection_Tab.TabIndex = 1;
            this.Selection_Tab.Text = "Выборка";
            this.Selection_Tab.UseVisualStyleBackColor = true;
            this.Selection_Tab.Enter += new System.EventHandler(this.Enter_Dyn_Tab);
            this.Selection_Tab.Leave += new System.EventHandler(this.Tab_Leave);
            // 
            // Lbl_SelectBy_room
            // 
            this.Lbl_SelectBy_room.BackColor = System.Drawing.Color.Gray;
            this.Lbl_SelectBy_room.Font = new System.Drawing.Font("Rotonda Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl_SelectBy_room.Location = new System.Drawing.Point(8, 17);
            this.Lbl_SelectBy_room.Name = "Lbl_SelectBy_room";
            this.Lbl_SelectBy_room.Size = new System.Drawing.Size(789, 41);
            this.Lbl_SelectBy_room.TabIndex = 12;
            this.Lbl_SelectBy_room.Text = "Введите название комнаты";
            this.Lbl_SelectBy_room.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Tbx_Search
            // 
            this.Tbx_Search.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.Tbx_Search.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.Tbx_Search.Location = new System.Drawing.Point(8, 59);
            this.Tbx_Search.Multiline = true;
            this.Tbx_Search.Name = "Tbx_Search";
            this.Tbx_Search.Size = new System.Drawing.Size(789, 20);
            this.Tbx_Search.TabIndex = 13;
            this.Tbx_Search.TextChanged += new System.EventHandler(this.Tbx_Search_TextChanged);
            this.Tbx_Search.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Tbx_Search_KeyDown);
            // 
            // Dgv_Selections
            // 
            this.Dgv_Selections.AllowDrop = true;
            this.Dgv_Selections.AllowUserToAddRows = false;
            this.Dgv_Selections.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.Dgv_Selections.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Dgv_Selections.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.Dgv_Selections.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Dgv_Selections.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5});
            this.Dgv_Selections.ContextMenuStrip = this.ContextMenu_MainLsv;
            this.Dgv_Selections.GridColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Dgv_Selections.Location = new System.Drawing.Point(8, 17);
            this.Dgv_Selections.Name = "Dgv_Selections";
            this.Dgv_Selections.RowHeadersVisible = false;
            this.Dgv_Selections.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.LightSteelBlue;
            this.Dgv_Selections.RowTemplate.DefaultCellStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.Dgv_Selections.RowTemplate.DefaultCellStyle.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.Dgv_Selections.RowTemplate.ReadOnly = true;
            this.Dgv_Selections.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.Dgv_Selections.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.Dgv_Selections.Size = new System.Drawing.Size(789, 502);
            this.Dgv_Selections.TabIndex = 11;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn1.HeaderText = "Название прибора";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn2.HeaderText = "Комната";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn3.FillWeight = 50F;
            this.dataGridViewTextBoxColumn3.HeaderText = "Мощность";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn4.FillWeight = 45F;
            this.dataGridViewTextBoxColumn4.HeaderText = "Стоимость";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn5.HeaderText = "Состояние";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.ReadOnly = true;
            // 
            // Gbx_SelectionTab
            // 
            this.Gbx_SelectionTab.Controls.Add(this.Lbl_SelectionTab);
            this.Gbx_SelectionTab.Location = new System.Drawing.Point(803, 104);
            this.Gbx_SelectionTab.Name = "Gbx_SelectionTab";
            this.Gbx_SelectionTab.Size = new System.Drawing.Size(254, 205);
            this.Gbx_SelectionTab.TabIndex = 10;
            this.Gbx_SelectionTab.TabStop = false;
            // 
            // Lbl_SelectionTab
            // 
            this.Lbl_SelectionTab.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Lbl_SelectionTab.Font = new System.Drawing.Font("Rotonda Bold", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl_SelectionTab.Location = new System.Drawing.Point(3, 16);
            this.Lbl_SelectionTab.Name = "Lbl_SelectionTab";
            this.Lbl_SelectionTab.Size = new System.Drawing.Size(248, 186);
            this.Lbl_SelectionTab.TabIndex = 9;
            this.Lbl_SelectionTab.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Main_tab
            // 
            this.Main_tab.Controls.Add(this.SplitContainer_Main);
            this.Main_tab.Location = new System.Drawing.Point(4, 22);
            this.Main_tab.Name = "Main_tab";
            this.Main_tab.Padding = new System.Windows.Forms.Padding(3);
            this.Main_tab.Size = new System.Drawing.Size(1065, 525);
            this.Main_tab.TabIndex = 0;
            this.Main_tab.Text = "Гланая вкладка";
            this.Main_tab.UseVisualStyleBackColor = true;
            this.Main_tab.Enter += new System.EventHandler(this.Enter_Dyn_Tab);
            this.Main_tab.Leave += new System.EventHandler(this.Tab_Leave);
            // 
            // SplitContainer_Main
            // 
            this.SplitContainer_Main.Dock = System.Windows.Forms.DockStyle.Fill;
            this.SplitContainer_Main.Location = new System.Drawing.Point(3, 3);
            this.SplitContainer_Main.Name = "SplitContainer_Main";
            // 
            // SplitContainer_Main.Panel1
            // 
            this.SplitContainer_Main.Panel1.Controls.Add(this.Trv_Main);
            // 
            // SplitContainer_Main.Panel2
            // 
            this.SplitContainer_Main.Panel2.Controls.Add(this.GbxAppliance);
            this.SplitContainer_Main.Panel2.Controls.Add(this.Dgv_Main);
            this.SplitContainer_Main.Panel2.Controls.Add(this.GbxRooms);
            this.SplitContainer_Main.Panel2.Controls.Add(this.Lbl_Main_Empty);
            this.SplitContainer_Main.Size = new System.Drawing.Size(1059, 519);
            this.SplitContainer_Main.SplitterDistance = 337;
            this.SplitContainer_Main.TabIndex = 15;
            // 
            // Trv_Main
            // 
            this.Trv_Main.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.Trv_Main.ContextMenuStrip = this.ContexMS_TrvMain;
            this.Trv_Main.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Trv_Main.ForeColor = System.Drawing.SystemColors.Desktop;
            this.Trv_Main.ImageIndex = 3;
            this.Trv_Main.ImageList = this.ImageList_TrvMain;
            this.Trv_Main.Location = new System.Drawing.Point(3, 3);
            this.Trv_Main.Name = "Trv_Main";
            this.Trv_Main.SelectedImageIndex = 3;
            this.Trv_Main.ShowNodeToolTips = true;
            this.Trv_Main.Size = new System.Drawing.Size(357, 513);
            this.Trv_Main.TabIndex = 0;
            this.Trv_Main.NodeMouseClick += new System.Windows.Forms.TreeNodeMouseClickEventHandler(this.TrvMain_Node_MouseClick);
            this.Trv_Main.NodeMouseDoubleClick += new System.Windows.Forms.TreeNodeMouseClickEventHandler(this.Trv_Main_NodeMouseDblClick);
            this.Trv_Main.Enter += new System.EventHandler(this.Trv_Main_Enter);
            this.Trv_Main.Leave += new System.EventHandler(this.Trv_Main_Leave);
            // 
            // ContexMS_TrvMain
            // 
            this.ContexMS_TrvMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.CM_Trv_TurnOn,
            this.CM_Trv_TurnOff,
            this.CM_Trv_TurnAllOn,
            this.CM_Trv_TurnAllOff,
            this.CM_Trv_Edit_Applince,
            this.CM_Trv_Edit_Flat,
            this.CM_Trv_Delete,
            this.CM_Trv_AddItem});
            this.ContexMS_TrvMain.Name = "ContexMS_TrvMain";
            this.ContexMS_TrvMain.Size = new System.Drawing.Size(255, 180);
            this.ContexMS_TrvMain.Opened += new System.EventHandler(this.ContexMS_TrvMain_Opened);
            // 
            // CM_Trv_TurnOn
            // 
            this.CM_Trv_TurnOn.Image = ((System.Drawing.Image)(resources.GetObject("CM_Trv_TurnOn.Image")));
            this.CM_Trv_TurnOn.Name = "CM_Trv_TurnOn";
            this.CM_Trv_TurnOn.Size = new System.Drawing.Size(254, 22);
            this.CM_Trv_TurnOn.Text = "Включить прибор ";
            this.CM_Trv_TurnOn.Visible = false;
            this.CM_Trv_TurnOn.Click += new System.EventHandler(this.CM_Trv_TurnOn_Click);
            // 
            // CM_Trv_TurnOff
            // 
            this.CM_Trv_TurnOff.Image = ((System.Drawing.Image)(resources.GetObject("CM_Trv_TurnOff.Image")));
            this.CM_Trv_TurnOff.Name = "CM_Trv_TurnOff";
            this.CM_Trv_TurnOff.Size = new System.Drawing.Size(254, 22);
            this.CM_Trv_TurnOff.Text = "Выключить прибор ";
            this.CM_Trv_TurnOff.Visible = false;
            this.CM_Trv_TurnOff.Click += new System.EventHandler(this.CM_Trv_TurnOff_Click);
            // 
            // CM_Trv_TurnAllOn
            // 
            this.CM_Trv_TurnAllOn.Name = "CM_Trv_TurnAllOn";
            this.CM_Trv_TurnAllOn.Size = new System.Drawing.Size(254, 22);
            this.CM_Trv_TurnAllOn.Text = "Включить все приборы";
            this.CM_Trv_TurnAllOn.Visible = false;
            this.CM_Trv_TurnAllOn.Click += new System.EventHandler(this.CM_Trv_TurnAllOn_Click);
            // 
            // CM_Trv_TurnAllOff
            // 
            this.CM_Trv_TurnAllOff.Name = "CM_Trv_TurnAllOff";
            this.CM_Trv_TurnAllOff.Size = new System.Drawing.Size(254, 22);
            this.CM_Trv_TurnAllOff.Text = "Выключить все приборы";
            this.CM_Trv_TurnAllOff.Visible = false;
            this.CM_Trv_TurnAllOff.Click += new System.EventHandler(this.CM_Trv_TurnAllOff_Click);
            // 
            // CM_Trv_Edit_Applince
            // 
            this.CM_Trv_Edit_Applince.Image = global::WF_Appliance.Properties.Resources.Edit_20x20;
            this.CM_Trv_Edit_Applince.Name = "CM_Trv_Edit_Applince";
            this.CM_Trv_Edit_Applince.Size = new System.Drawing.Size(254, 22);
            this.CM_Trv_Edit_Applince.Text = "Редактировать прибор";
            this.CM_Trv_Edit_Applince.Visible = false;
            this.CM_Trv_Edit_Applince.Click += new System.EventHandler(this.CM_Trv_Edit_Applince_Click);
            // 
            // CM_Trv_Edit_Flat
            // 
            this.CM_Trv_Edit_Flat.Image = global::WF_Appliance.Properties.Resources.edit_RS_20x20;
            this.CM_Trv_Edit_Flat.Name = "CM_Trv_Edit_Flat";
            this.CM_Trv_Edit_Flat.Size = new System.Drawing.Size(254, 22);
            this.CM_Trv_Edit_Flat.Text = "Редактировать данные квартиры";
            // 
            // CM_Trv_Delete
            // 
            this.CM_Trv_Delete.Image = global::WF_Appliance.Properties.Resources.bin2_20x20;
            this.CM_Trv_Delete.Name = "CM_Trv_Delete";
            this.CM_Trv_Delete.Size = new System.Drawing.Size(254, 22);
            this.CM_Trv_Delete.Text = "Удалить прибор";
            this.CM_Trv_Delete.Visible = false;
            this.CM_Trv_Delete.Click += new System.EventHandler(this.CM_Trv_Delete_Click);
            // 
            // CM_Trv_AddItem
            // 
            this.CM_Trv_AddItem.Image = global::WF_Appliance.Properties.Resources.Add_up_30x30;
            this.CM_Trv_AddItem.Name = "CM_Trv_AddItem";
            this.CM_Trv_AddItem.Size = new System.Drawing.Size(254, 22);
            this.CM_Trv_AddItem.Text = "Добавить прибор";
            this.CM_Trv_AddItem.Click += new System.EventHandler(this.CM_Trv_AddItem_Click);
            // 
            // ImageList_TrvMain
            // 
            this.ImageList_TrvMain.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("ImageList_TrvMain.ImageStream")));
            this.ImageList_TrvMain.TransparentColor = System.Drawing.Color.Transparent;
            this.ImageList_TrvMain.Images.SetKeyName(0, "Turn_off_30x30.png");
            this.ImageList_TrvMain.Images.SetKeyName(1, "Turn_On_30x30.png");
            this.ImageList_TrvMain.Images.SetKeyName(2, "Door_64x64.png");
            this.ImageList_TrvMain.Images.SetKeyName(3, "House_64x64.png");
            // 
            // GbxAppliance
            // 
            this.GbxAppliance.Controls.Add(this.TbxAppliance);
            this.GbxAppliance.Location = new System.Drawing.Point(3, 331);
            this.GbxAppliance.Name = "GbxAppliance";
            this.GbxAppliance.Size = new System.Drawing.Size(320, 185);
            this.GbxAppliance.TabIndex = 14;
            this.GbxAppliance.TabStop = false;
            this.GbxAppliance.Text = "Выбранный прибор";
            // 
            // TbxAppliance
            // 
            this.TbxAppliance.Font = new System.Drawing.Font("Consolas", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TbxAppliance.Location = new System.Drawing.Point(6, 19);
            this.TbxAppliance.Multiline = true;
            this.TbxAppliance.Name = "TbxAppliance";
            this.TbxAppliance.ReadOnly = true;
            this.TbxAppliance.Size = new System.Drawing.Size(308, 160);
            this.TbxAppliance.TabIndex = 4;
            // 
            // Dgv_Main
            // 
            this.Dgv_Main.AllowDrop = true;
            this.Dgv_Main.AllowUserToAddRows = false;
            this.Dgv_Main.AllowUserToDeleteRows = false;
            this.Dgv_Main.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.Dgv_Main.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Dgv_Main.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.Dgv_Main.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Dgv_Main.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ColApplianceName,
            this.RoomCol,
            this.PowerCol,
            this.PriceCol,
            this.StateCol});
            this.Dgv_Main.ContextMenuStrip = this.ContextMenu_MainLsv;
            this.Dgv_Main.GridColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Dgv_Main.Location = new System.Drawing.Point(3, 3);
            this.Dgv_Main.Name = "Dgv_Main";
            this.Dgv_Main.ReadOnly = true;
            this.Dgv_Main.RowHeadersVisible = false;
            this.Dgv_Main.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.LightSteelBlue;
            this.Dgv_Main.RowTemplate.DefaultCellStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.Dgv_Main.RowTemplate.DefaultCellStyle.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.Dgv_Main.RowTemplate.ReadOnly = true;
            this.Dgv_Main.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.Dgv_Main.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.Dgv_Main.Size = new System.Drawing.Size(712, 322);
            this.Dgv_Main.TabIndex = 9;
            this.Dgv_Main.SelectionChanged += new System.EventHandler(this.Dvg_Main_SelectionChanged);
            this.Dgv_Main.DragDrop += new System.Windows.Forms.DragEventHandler(this.Ggv_Main_DragDrop);
            this.Dgv_Main.DragEnter += new System.Windows.Forms.DragEventHandler(this.Main_form_DragEnter);
            this.Dgv_Main.DragLeave += new System.EventHandler(this.Dvg_Main_DragLeave);
            this.Dgv_Main.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Dgv_Main_KeyDown);
            // 
            // ColApplianceName
            // 
            this.ColApplianceName.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.ColApplianceName.HeaderText = "Название прибора";
            this.ColApplianceName.Name = "ColApplianceName";
            this.ColApplianceName.ReadOnly = true;
            // 
            // RoomCol
            // 
            this.RoomCol.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.RoomCol.HeaderText = "Комната";
            this.RoomCol.Name = "RoomCol";
            this.RoomCol.ReadOnly = true;
            // 
            // PowerCol
            // 
            this.PowerCol.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.PowerCol.FillWeight = 50F;
            this.PowerCol.HeaderText = "Мощность";
            this.PowerCol.Name = "PowerCol";
            this.PowerCol.ReadOnly = true;
            // 
            // PriceCol
            // 
            this.PriceCol.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.PriceCol.FillWeight = 45F;
            this.PriceCol.HeaderText = "Стоимость";
            this.PriceCol.Name = "PriceCol";
            this.PriceCol.ReadOnly = true;
            // 
            // StateCol
            // 
            this.StateCol.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.StateCol.HeaderText = "Состояние";
            this.StateCol.Name = "StateCol";
            this.StateCol.ReadOnly = true;
            // 
            // GbxRooms
            // 
            this.GbxRooms.Controls.Add(this.TbxRooms);
            this.GbxRooms.Location = new System.Drawing.Point(393, 331);
            this.GbxRooms.Name = "GbxRooms";
            this.GbxRooms.Size = new System.Drawing.Size(320, 185);
            this.GbxRooms.TabIndex = 6;
            this.GbxRooms.TabStop = false;
            this.GbxRooms.Text = "Количество по комнатам";
            // 
            // TbxRooms
            // 
            this.TbxRooms.Font = new System.Drawing.Font("Consolas", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TbxRooms.Location = new System.Drawing.Point(6, 19);
            this.TbxRooms.Multiline = true;
            this.TbxRooms.Name = "TbxRooms";
            this.TbxRooms.ReadOnly = true;
            this.TbxRooms.Size = new System.Drawing.Size(308, 160);
            this.TbxRooms.TabIndex = 4;
            // 
            // Lbl_Main_Empty
            // 
            this.Lbl_Main_Empty.Font = new System.Drawing.Font("Rotonda Bold", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl_Main_Empty.Location = new System.Drawing.Point(226, 391);
            this.Lbl_Main_Empty.Name = "Lbl_Main_Empty";
            this.Lbl_Main_Empty.Size = new System.Drawing.Size(215, 69);
            this.Lbl_Main_Empty.TabIndex = 8;
            this.Lbl_Main_Empty.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Tab_Control_Main
            // 
            this.Tab_Control_Main.Controls.Add(this.Main_tab);
            this.Tab_Control_Main.Controls.Add(this.Selection_Tab);
            this.Tab_Control_Main.Controls.Add(this.Sorts_Tab);
            this.Tab_Control_Main.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Tab_Control_Main.Location = new System.Drawing.Point(0, 55);
            this.Tab_Control_Main.Name = "Tab_Control_Main";
            this.Tab_Control_Main.SelectedIndex = 0;
            this.Tab_Control_Main.Size = new System.Drawing.Size(1073, 551);
            this.Tab_Control_Main.TabIndex = 15;
            // 
            // toolStripStatusLbl
            // 
            this.toolStripStatusLbl.Name = "toolStripStatusLbl";
            this.toolStripStatusLbl.Size = new System.Drawing.Size(0, 17);
            // 
            // TSl_Footer
            // 
            this.TSl_Footer.Name = "TSl_Footer";
            this.TSl_Footer.Size = new System.Drawing.Size(0, 17);
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(0, 17);
            // 
            // TSl_Footer_SortTab
            // 
            this.TSl_Footer_SortTab.Name = "TSl_Footer_SortTab";
            this.TSl_Footer_SortTab.Size = new System.Drawing.Size(0, 17);
            // 
            // StsMain
            // 
            this.StsMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLbl,
            this.TSl_Footer,
            this.toolStripStatusLabel1,
            this.TSl_Footer_SortTab});
            this.StsMain.Location = new System.Drawing.Point(0, 606);
            this.StsMain.Name = "StsMain";
            this.StsMain.Size = new System.Drawing.Size(1073, 22);
            this.StsMain.TabIndex = 5;
            this.StsMain.Text = "statusStrip1";
            // 
            // Main_form
            // 
            this.AllowDrop = true;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1073, 628);
            this.Controls.Add(this.Tab_Control_Main);
            this.Controls.Add(this.ToolBar);
            this.Controls.Add(this.StsMain);
            this.Controls.Add(this.MenuBar);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.MainMenuStrip = this.MenuBar;
            this.MaximizeBox = false;
            this.Name = "Main_form";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Задание на 25.11";
            this.Load += new System.EventHandler(this.Main_form_Load);
            this.DragEnter += new System.Windows.Forms.DragEventHandler(this.Main_form_DragEnter);
            this.DragLeave += new System.EventHandler(this.Main_form_DragLeave);
            this.ContextMenu_MainLsv.ResumeLayout(false);
            this.MenuBar.ResumeLayout(false);
            this.MenuBar.PerformLayout();
            this.ToolBar.ResumeLayout(false);
            this.ToolBar.PerformLayout();
            this.ContextMenu_NTI.ResumeLayout(false);
            this.Sorts_Tab.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.Dgv_Sorts)).EndInit();
            this.Gbx_Sorts_Tab.ResumeLayout(false);
            this.СontextMenu_Lsv_Sorts.ResumeLayout(false);
            this.Selection_Tab.ResumeLayout(false);
            this.Selection_Tab.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Dgv_Selections)).EndInit();
            this.Gbx_SelectionTab.ResumeLayout(false);
            this.Main_tab.ResumeLayout(false);
            this.SplitContainer_Main.Panel1.ResumeLayout(false);
            this.SplitContainer_Main.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.SplitContainer_Main)).EndInit();
            this.SplitContainer_Main.ResumeLayout(false);
            this.ContexMS_TrvMain.ResumeLayout(false);
            this.GbxAppliance.ResumeLayout(false);
            this.GbxAppliance.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Dgv_Main)).EndInit();
            this.GbxRooms.ResumeLayout(false);
            this.GbxRooms.PerformLayout();
            this.Tab_Control_Main.ResumeLayout(false);
            this.StsMain.ResumeLayout(false);
            this.StsMain.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.MenuStrip MenuBar;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem выходToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem Flat_TSI;
        private System.Windows.Forms.ToolStripMenuItem Appliances_TSI;
        private System.Windows.Forms.ToolStripMenuItem AddAppToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem EditAppToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem AddCollectionAppMni;
        private System.Windows.Forms.ToolStripMenuItem DeleteAppMNI;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripMenuItem SortsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem SortByNameTSMItem;
        private System.Windows.Forms.ToolStripMenuItem SortByStateTSMItem;
        private System.Windows.Forms.ToolStripMenuItem SortByPowerTSMItem;
        private System.Windows.Forms.ToolStripMenuItem SelectionTSMItem;
        private System.Windows.Forms.ToolStripMenuItem SelectNameTSMItem;
        private System.Windows.Forms.ToolStripMenuItem SelectStatelTSMItem;
        private System.Windows.Forms.ToolStripMenuItem ReformTSMItem;
        private System.Windows.Forms.ToolStrip ToolBar;
        private System.Windows.Forms.ToolStripSplitButton BtnEditRsToolStrip;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripDropDownButton BtnSelectionsToolStrip;
        private System.Windows.Forms.ToolStripMenuItem SelectByRepairerTSMItem;
        private System.Windows.Forms.ToolStripMenuItem SelectByOwnerTSMItem;
        private System.Windows.Forms.ToolStripDropDownButton BtnAddToolStrip;
        private System.Windows.Forms.ToolStripMenuItem AddCollectionTSMItem;
        private System.Windows.Forms.ToolStripMenuItem AddTvMenuItem;
        private System.Windows.Forms.ToolStripMenuItem AboutSoft_TSI;
        private System.Windows.Forms.OpenFileDialog OFD;
        private System.Windows.Forms.SaveFileDialog SFD;
        private System.Windows.Forms.ToolStripMenuItem OpenFileTSMItem;
        private System.Windows.Forms.ContextMenuStrip ContextMenu_MainLsv;
        private System.Windows.Forms.ToolStripMenuItem AddCollectionCM;
        private System.Windows.Forms.ToolStripMenuItem AddAppCM;
        private System.Windows.Forms.ToolStripMenuItem EditAppCM;
        private System.Windows.Forms.ToolStripMenuItem DelAppCM;
        private System.Windows.Forms.ToolStripMenuItem SortsSetCM;
        private System.Windows.Forms.ToolStripMenuItem SortByProducerCM;
        private System.Windows.Forms.ToolStripMenuItem SortByDiagonalCM;
        private System.Windows.Forms.ToolStripMenuItem SortByRepairerCM;
        private System.Windows.Forms.ToolStripMenuItem SortByOwnerCM;
        private System.Windows.Forms.ToolStripMenuItem SelecetionsSetCM;
        private System.Windows.Forms.ToolStripMenuItem SelectiByName_CM;
        private System.Windows.Forms.ToolStripMenuItem SelectiByState_CM;
        private System.Windows.Forms.ToolStripMenuItem ChangeFont_CM;
        private System.Windows.Forms.ToolStripMenuItem ChangeBackColor_CM;
        private System.Windows.Forms.ToolStripMenuItem DelWhole_CM;
        private System.Windows.Forms.ToolStripMenuItem OpenFile_CM;
        private System.Windows.Forms.ToolStripButton BtnEditToolStrip;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripButton BtnDelAppToolStrip;
        private System.Windows.Forms.ToolStripMenuItem AddFileMenuItem;
        private System.Windows.Forms.ToolStripDropDownButton BtnManyAppsStrip;
        private System.Windows.Forms.ToolStripMenuItem SubBtnDelAll;
        private System.Windows.Forms.ToolStripDropDownButton BtnSortsToolStrip;
        private System.Windows.Forms.ToolStripMenuItem BtnSortByBrandTSMItem;
        private System.Windows.Forms.ToolStripMenuItem BtnSortByDiagonalTSMItem;
        private System.Windows.Forms.ToolStripMenuItem BtnSortByRepairerTSMItem;
        private System.Windows.Forms.ToolStripMenuItem BtnSortByOwnerTSMItem;
        private System.Windows.Forms.FontDialog FND_GridView;
        private System.Windows.Forms.ColorDialog CLD_GridView;
        private System.Windows.Forms.ToolStripMenuItem редактироватьДанныеМастерскойToolStripMenuItem;
        private System.Windows.Forms.Timer Tmr_Leave_Tab;
        private System.Windows.Forms.ToolStripMenuItem ChangeForeColor_CM;
        private System.Windows.Forms.ImageList ImageList_Appliances;
        private System.Windows.Forms.ToolStripButton BtnExitToolStrip;
        private System.Windows.Forms.NotifyIcon NTI;
        private System.Windows.Forms.ContextMenuStrip ContextMenu_NTI;
        private System.Windows.Forms.ToolStripMenuItem открытьToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem выходToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem оПрограммеToolStripMenuItem1;
        private System.Windows.Forms.ToolStripButton BtnHideToolStrip;
        private System.Windows.Forms.TabPage Sorts_Tab;
        private System.Windows.Forms.TabPage Selection_Tab;
        private System.Windows.Forms.TabPage Main_tab;
        private System.Windows.Forms.GroupBox GbxRooms;
        private System.Windows.Forms.TextBox TbxRooms;
        private System.Windows.Forms.TabControl Tab_Control_Main;
        private System.Windows.Forms.ToolStripButton BtnTurnOnOneStrip;
        private System.Windows.Forms.ToolStripButton BtnTurnOFFOneStrip;
        private System.Windows.Forms.ToolStripMenuItem SortByPriceTSMItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator5;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripMenuItem TurnOnAllTopMni;
        private System.Windows.Forms.ToolStripMenuItem TurnOffAllTopMni;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator9;
        private System.Windows.Forms.ToolStripMenuItem TurnOffAppliance_CM;
        private System.Windows.Forms.ToolStripMenuItem TurnOnAppliance_CM;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator8;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator6;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator7;
        private System.Windows.Forms.Label Lbl_SelectionTab;
        private System.Windows.Forms.GroupBox Gbx_SelectionTab;
        private System.Windows.Forms.GroupBox Gbx_Sorts_Tab;
        private System.Windows.Forms.Label Lbl_SortsTab;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLbl;
        private System.Windows.Forms.ToolStripStatusLabel TSl_Footer;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.ToolStripStatusLabel TSl_Footer_SortTab;
        private System.Windows.Forms.StatusStrip StsMain;
        private System.Windows.Forms.GroupBox GbxAppliance;
        private System.Windows.Forms.TextBox TbxAppliance;
        private System.Windows.Forms.SplitContainer SplitContainer_Main;
        private System.Windows.Forms.TreeView Trv_Main;
        private System.Windows.Forms.Label Lbl_Main_Empty;
        private System.Windows.Forms.ContextMenuStrip СontextMenu_Lsv_Sorts;
        private System.Windows.Forms.ToolStripMenuItem Lsv_SortByName_CM;
        private System.Windows.Forms.ToolStripMenuItem Lsv_SortByState_CM;
        private System.Windows.Forms.ToolStripMenuItem Lsv_SortByPower_CM;
        private System.Windows.Forms.ToolStripMenuItem Lsv_SortByPrice_CM;
        private System.Windows.Forms.ContextMenuStrip ContexMS_TrvMain;
        private System.Windows.Forms.ToolStripMenuItem CM_Trv_TurnOn;
        private System.Windows.Forms.ToolStripMenuItem CM_Trv_TurnOff;
        private System.Windows.Forms.ToolStripMenuItem CM_Trv_TurnAllOn;
        private System.Windows.Forms.ToolStripMenuItem CM_Trv_TurnAllOff;
        private System.Windows.Forms.ToolStripMenuItem CM_Trv_Edit_Applince;
        private System.Windows.Forms.ToolStripMenuItem CM_Trv_Edit_Flat;
        private System.Windows.Forms.ImageList ImageList_TrvMain;
        private System.Windows.Forms.DataGridView Dgv_Main;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColApplianceName;
        private System.Windows.Forms.DataGridViewTextBoxColumn RoomCol;
        private System.Windows.Forms.DataGridViewTextBoxColumn PowerCol;
        private System.Windows.Forms.DataGridViewTextBoxColumn PriceCol;
        private System.Windows.Forms.DataGridViewTextBoxColumn StateCol;
        private System.Windows.Forms.ToolStripMenuItem CM_Trv_Delete;
        private System.Windows.Forms.ToolStripMenuItem CM_Trv_AddItem;
        private System.Windows.Forms.DataGridView Dgv_Sorts;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;
        private System.Windows.Forms.DataGridView Dgv_Selections;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.ToolStripMenuItem SelectBySubStrTSI;
        private System.Windows.Forms.Label Lbl_SelectBy_room;
        private System.Windows.Forms.TextBox Tbx_Search;
    }
}

