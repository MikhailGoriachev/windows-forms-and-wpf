﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WF_Appliance.Models;
using WF_Appliance.Controller;

namespace WF_Appliance.Forms
{
    public partial class Delete_Certain_Form : Form
    {

        //Свойство контроллер
        private FlatController _FlatController;


        public FlatController rsController
        {
            get => _FlatController;
        }


        public Delete_Certain_Form() : this(new FlatController())
        {
        }

        //C_TOR с параметрами 

        public Delete_Certain_Form(FlatController repair)
        {
            InitializeComponent();

            IsEmpty(repair);
            _FlatController = repair;
        }

        //Связывание с коллекциями double
        void BindData(List<int> set)
        {
            //Добавляем данные в полученный список работников
            CbxField.DataSource = null;
            CbxField.DataSource = set;
        }

        //Связывание с коллекциями double
        void BindData(List<string> set)
        {
            //Добавляем данные в полученный список работников
            CbxField.DataSource = null;
            CbxField.DataSource = set;
        }



        //Проверка на пустоту коллекции
        void IsEmpty(FlatController flatController)
        {
            if (flatController.Count > 0)
                return;

            #region Radiobuttons
            //В случае если коллекция пуста - отключаем кнопки 
            RbtnPower.Enabled = false;
            RbtnPrice.Enabled = false;
            RbtnName.Enabled = false;
            #endregion

            //Отключаем ComboBox
            LblField.Enabled = false;
            CbxField.Enabled = false;


        }

        #region Radio buttons


        private void RbtnPower_CheckedChanged(object sender, EventArgs e)
        {
            LblField.Enabled = true;
            CbxField.Enabled = true;
            LblField.Text = "Выбирете мощность";

            List<int> tempList = new List<int>(_FlatController.GetIntsCollection(FlatController.SubCollection.Power));

            //Добавляем данные в полученный список диагоналей
            BindData(tempList);
        }

        private void RbtnPrice_CheckedChanged(object sender, EventArgs e)
        {
            LblField.Enabled = true;
            CbxField.Enabled = true;
            LblField.Text = "Выбирете стоимость";

            List<int> tempList = new List<int>(_FlatController.GetIntsCollection(FlatController.SubCollection.Price));

            //Добавляем данные в полученный список цен
            BindData(tempList);


        }

        //Обработчик радиокнопки
        private void RbtnName_CheckedChanged(object sender, EventArgs e)
        {
            LblField.Enabled = true;
            CbxField.Enabled = true;
            LblField.Text = "Выбирете название";

            //Получение списка производителей без повторений
            List<string> tempList = new List<string>(_FlatController.GetNamesCollection());

            //Связываем полученный список производителей
            BindData(tempList);
        }


        #endregion


        private void CbxField_SelectedIndexChanged(object sender, EventArgs e)
        {
            BtnDelete.Enabled = true;
        }

        private void BtnDelete_Click(object sender, EventArgs e)
        {
            int size = _FlatController.Count;

            //Условия на опеределение нажатой кнопки 

            //Если было выбрано удаление по названию прибора
            if (RbtnName.Checked)
            {
                string Name = CbxField.Text;
                //Удаляем с конца коллекции
                for (int i = size - 1; i >= 0; i--)
                {
                    if (_FlatController.Flat[i].Name == Name)
                        _FlatController.GetAppliances.RemoveAt(i);
                }

            }

            //Если было выбрано удаление по мощности
            if (RbtnPower.Checked)
            {
                double Power = int.Parse(CbxField.SelectedItem.ToString());
                for (int i = size - 1; i >= 0; i--)
                {
                    if (_FlatController.Flat[i].Power == Power)
                        _FlatController.GetAppliances.RemoveAt(i);
                }

            }
            //Если было выбрано удаление по стоимости
            if (RbtnPrice.Checked)
            {
                double Price = double.Parse(CbxField.SelectedItem.ToString());
                for (int i = size - 1; i >= 0; i--)
                {
                    if (_FlatController.Flat[i].Price == Price)
                        _FlatController.GetAppliances.RemoveAt(i);
                }
            }

        }


    }
}
