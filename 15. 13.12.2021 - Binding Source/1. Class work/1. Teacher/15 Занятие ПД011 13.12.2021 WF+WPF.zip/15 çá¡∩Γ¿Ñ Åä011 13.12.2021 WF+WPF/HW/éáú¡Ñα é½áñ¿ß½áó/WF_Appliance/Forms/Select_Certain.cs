﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WF_Appliance.Models;
using WF_Appliance.Controller;

namespace WF_Appliance.Forms
{
    public partial class Select_Certain : Form
    {

        //Свойство контроллер
        private FlatController _flatController;


        public FlatController rsController
        {
            get => _flatController;
        }

        //Выбранное значение
        private object _chosenItem;

        public object ChosenItem
        {
            get => _chosenItem;
        }

        //Перечисление составных коллекций
        public enum SubObject
        {
            //Мощность 
            power,
            //Название
            name,
            //Стоимость 
            price,
            //Состояние 
            state
        }

        public Select_Certain():this(new FlatController(),SubObject.price)
        {
        }

        //C_TOR с параметрами 

        public Select_Certain(FlatController flatController,SubObject subObject)
        {
            InitializeComponent();

            _flatController = flatController;
            addToCbx(subObject);
            
        }

        //Связывание с коллекциями double
       void BindData(List<int> set)
        {
            //Добавляем данные в полученный список работников
            CbxField.DataSource = null;
            CbxField.DataSource = set;
        }
        
        //Связывание со строковыми коллекциями
       void BindData(List<string> set)
        {
            //Добавляем данные в полученный список работников
            CbxField.DataSource = null;
            CbxField.DataSource = set;
        }

        //Связывание с опеределённойколлекцией составных элементов
        void addToCbx(SubObject code)
        {
            //Создаём временные списки
            List<int> tempListInt = new List<int>();
            List<string> tempListStr = new List<string>();

            //Выбираем связывание с коллекцией
            switch (code)
            {
                case SubObject.power:

                    tempListInt.AddRange(_flatController.GetIntsCollection(FlatController.SubCollection.Power));

                    //Добавляем данные в полученный список мощностей
                    BindData(tempListInt);
                    LblTitle.Text = "Выбирете мощность прибора";
                    break;

                case SubObject.name:
                    tempListStr.AddRange(_flatController.GetNamesCollection());

                    //Связываем полученный список названий прибора
                    BindData(tempListStr);

                    LblTitle.Text = "Выбирете название прибора ";
                    break;

                case SubObject.price:
                    tempListInt.AddRange(_flatController.GetIntsCollection(FlatController.SubCollection.Price));

                    //Связываем полученный список стоимостей
                    BindData(tempListInt);

                    LblTitle.Text = "Выбирете стоимость";
                    break;
                case SubObject.state:
                    tempListStr.Add("Включен");
                    tempListStr.Add("Выключен");

                    //Связываем полученный список стоимостей
                    BindData(tempListStr);

                    LblTitle.Text = "Выбирете состояние";
                    break;

                default:
                    break;
            }
        }

        private void CbxField_SelectedIndexChanged(object sender, EventArgs e)
        {
            BtnAccept.Enabled = true;
        }

        private void BtnAccept_Click(object sender, EventArgs e)
        {
            _chosenItem = CbxField.SelectedItem;

        }


    }
}
