﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Windows.Forms;
using WF_Appliance.Models;
using WF_Appliance.Forms;
using WF_Appliance.Utilities;
using WF_Appliance.Controller;

namespace WF_Appliance
{
    public partial class Main_form : Form
    {
        //Телемастерская
        //private Flat _flat;

        //Котроллер 
        private FlatController _flatController;

        public Main_form() : this(new FlatController())
        { }

        //C_TOR с параметрами
        public Main_form(FlatController FlatController)
        {
            //Создание всех элементов формы
            InitializeComponent();

            _flatController = FlatController;

            //Заполняем Gridview
            FillGridView(_flatController.GetAppliances, Dgv_Main);

            //Добавление данных в дерево
            FillTreeView();

            //Сохранение 
            _flatController.Serialize();

        }

        //Связываение данных
        private void FillGridView(List<Appliance> appliances, DataGridView Dgv)
        {
            //Очищаем ячейки GridView
            Dgv.Rows.Clear();

            int i = 0;

            foreach (Appliance item in appliances)
            {
                //Увеличиваем кол-во строк
                Dgv.RowCount++;


                //Строка названия
                Dgv[0, i].Value = item.Name;
                Dgv[0, i].Style.Alignment = DataGridViewContentAlignment.MiddleLeft;

                //Строка комнаты
                Dgv[1, i].Value = item.Room;
                Dgv[1, i].Style.Alignment = DataGridViewContentAlignment.MiddleLeft;

                //Строка мощности
                Dgv[2, i].Value = item.Power;
                Dgv[2, i].Style.Alignment = DataGridViewContentAlignment.MiddleCenter;

                //Строка стоимости
                Dgv[3, i].Value = item.Price;
                Dgv[3, i].Style.Alignment = DataGridViewContentAlignment.MiddleCenter;

                //Строка состояния
                Dgv[4, i].Value = item.State ? "Включен" : "Выключен";
                Dgv[4, i].Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
                Dgv[4, i].Style.BackColor = item.State ? Color.LightGreen : Color.OrangeRed;

                //Записываем обект в tag текущей строки 
                Dgv.Rows[i].Tag = item;

                i++;
            }
        }

        //Заполнение дерева 
        private void FillTreeView()
        {
            Trv_Main.Nodes.Clear();
            if (_flatController.IsEmpty)
            {
                return;
            }

            //Добавление главного узла - квартира 
            TreeNode NodeFlat = Trv_Main.Nodes.Add($"Квартира: {_flatController.Flat.Adress}");


            //Заполнение комнатами
            Dictionary<string, List<Appliance>> RoomApps = new Dictionary<string, List<Appliance>>();

            //Индекс каждой комнаты. Был введен, поскольку произвенсти индексирование коллекции комнат 
            //по названию NodesFlat[Room] не получилось, вылетал Exception
            int i = 0;

            //Проход по уникализированному списку комнат
            foreach (string Room in _flatController.GetRooms())
            {
                //Заносим данные в словарь
                RoomApps.Add(Room, _flatController.GetAppliances.FindAll(item => item.Room == Room));

                //Создаём узел конаты 
                TreeNode NodeRoom = NodeFlat.Nodes.Add("", Room, 2, 2);


                //Проход по ассноциированному списку из словарая, в котором находятся приборы с 
                //определенной комнаты
                foreach (Appliance item in RoomApps[Room])
                {
                    int imageIndex = item.State ? 1 : 0;

                    //В созданный во внешнем цыкле узел комнаты добавляем прибор
                    TreeNode NodeAppliance = NodeFlat.Nodes[i].Nodes.Add("", $"{item.Name}. {item.Power} Вт", imageIndex, imageIndex);

                    //Добавляем прибор в Tag каждого листа TreeView 
                    NodeAppliance.Tag = item;

                    //Задаём подсказку 
                    NodeAppliance.ToolTipText = $"{item.Name}: \r\nСтоимость: {item.Price}";
                }

                i++;
                // Trv_Main.Nodes[0].Nodes[]
            }


            NodeFlat.ExpandAll();
        }

        //Изменение конкретного прибора на дереве. Избегание перезаписи всего дерева 

        //Перезапись конкретного прибора. В аргументах передаём выделеные строки
        void ChangeOne(DataGridViewSelectedRowCollection RowsCollection, Appliance appliance)
        {
            //Если неккорректное количество строк - уходим
            if (RowsCollection.Count <= 0 || RowsCollection.Count >= Dgv_Main.Rows.Count)
                return;
            
            //Проходим по всей коллекции строк
            foreach (DataGridViewRow row in RowsCollection)
            {
                //Каждой строке находим столбец с имененем состояния 
               row.Cells[4].Value = appliance.State ? "Включен" : "Выключен";
                //Изменяем цвет в зависимости от состояния
               row.Cells[4].Style.BackColor = appliance.State ? Color.LightGreen : Color.OrangeRed;
            }
        }
        
        //Перезапись конкретного прибора. В аргументах передаём выделеные строки
        void ChangeAddOne(Appliance appliance)
        {
            DataGridViewRowCollection RowsCollection = Dgv_Main.Rows;

            int CountRows = RowsCollection.Count;
            //Если неккорректное количество строк или передан несуществующий объект  - уходим
            if (CountRows <= 0 || CountRows > _flatController.Count || appliance == null)
                return;

            //Прибор изменен
            bool changed = false;

            //Проходим по всей коллекции строк
            foreach (DataGridViewRow row in RowsCollection)
            {
                //Если текущая строка не содержит нужный обект в теге - переходим на следующую итерацию 
                if (row.Tag as Appliance != appliance)
                    continue;

               //Меняем название 
               row.Cells[0].Value = appliance.Name;

               //Меняем комнату
               row.Cells[1].Value = appliance.Room;

               //Меняем мощность
               row.Cells[2].Value = appliance.Power;

               //Меняем стоимость
               row.Cells[3].Value = appliance.Price;

                //Изменяем значение строки состояния
               row.Cells[4].Value = appliance.State ? "Включен" : "Выключен";
                //Изменяем цвет в зависимости от состояния
               row.Cells[4].Style.BackColor = appliance.State ? Color.LightGreen : Color.OrangeRed;

               changed = true;

            }

            //Если прибора нет и следственно он не был изменён - добавляем его в GridView
            if (changed == false)
            {
                //Увеличиваем кол-во строк
                Dgv_Main.RowCount++;

                //Строка названия
                Dgv_Main[0, CountRows].Value = appliance.Name;
                Dgv_Main[0, CountRows].Style.Alignment = DataGridViewContentAlignment.MiddleLeft;

                //Строка комнаты
                Dgv_Main[1, CountRows].Value = appliance.Room;
                Dgv_Main[1, CountRows].Style.Alignment = DataGridViewContentAlignment.MiddleLeft;

                //Строка мощности
                Dgv_Main[2, CountRows].Value = appliance.Power;
                Dgv_Main[2, CountRows].Style.Alignment = DataGridViewContentAlignment.MiddleCenter;

                //Строка стоимости
                Dgv_Main[3, CountRows].Value = appliance.Price;
                Dgv_Main[3, CountRows].Style.Alignment = DataGridViewContentAlignment.MiddleCenter;

                //Строка состояния
                Dgv_Main[4, CountRows].Value = appliance.State ? "Включен" : "Выключен";
                Dgv_Main[4, CountRows].Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
                Dgv_Main[4, CountRows].Style.BackColor = appliance.State ? Color.LightGreen : Color.OrangeRed;

                //Записываем обект в tag текущей строки 
                Dgv_Main.Rows[CountRows].Tag = appliance;
            }
        }

        //Загрузка всей формы
        private void Main_form_Load(object sender, EventArgs e)
        {
            //Вывод количества созданных объектов в строку состояния

            //Проверка на пустоту 
            IsColletionEmpty();

            int turnedOn = _flatController.CountTurnedOn(), amount = _flatController.Count;
            //Изменение статусной строки 
            TSl_Footer.Text = $"Приборов в квартире: {amount} | Включено: {turnedOn} | Выключено: {amount - turnedOn}";

            //Выводим кол-ва приборов в каждой комнате 
            CountInRooms();
        }

        // завершение работы приложения
        private void Exit_Command(object sender, EventArgs e) =>
            Application.Exit();

        //Изменение статусной строки 
        private void ChangeStatusString()
        {
            int turnedOn = _flatController.CountTurnedOn(), amount = _flatController.Count;
            TSl_Footer.Text = $"Приборов в квартире: {amount} | Включено: {turnedOn} | Выключено: {amount - turnedOn}";
        }

        //Вывод кол-ва приборов в комнате через TextBox
        private void CountInRooms()
        {
            //Создаём словарь для комнат
            Dictionary<string, int> Rooms = new Dictionary<string, int>();

            //Счётчик
            int count = 0, i = 0;

            TbxRooms.Clear();

            //Временный список 
            List<Appliance> tempList = new List<Appliance>();

            //Добавляем комнаты в словарь 
            foreach (Appliance item in _flatController.GetAppliances)
                Rooms[item.Room] = count;

            //Подсчёт кол-ва приборов в комнате 
            foreach (string key in Rooms.Keys)
            {
                //Находим необходимые приборы через FindAll
                count = _flatController.GetAppliances.FindAll(elem => elem.Room == key).Count;

                //Вывод в Tbx

                TbxRooms.Text += $"{++i}. {key}: {count} приборов\r\n";

            }
        }

        private void AddAppliance_Command(object sender, EventArgs e)
        {
            Appliance_form addForm = new Appliance_form();
            DialogResult showResult = addForm.ShowDialog();

            //Если заверешение работы формы произошло не через кнопку добавить/сохранить
            //со свойством DialogResult.Yes, тогда объект не добавляем 
            if (showResult != DialogResult.OK)
                return;

            Appliance CreatedAppliance = addForm.appliance;
            //Если же завершение работы формы было корректным, тогда добавляем объект в список приборов
            _flatController.Flat.Appliances.Add(CreatedAppliance);

            //Последний добавленный прибор заносим в GridView
            ChangeAddOne(CreatedAppliance);

            //Изменяем дерево
            AddAppliance_Tree(CreatedAppliance);

            //Проверка на пустоту 
            IsColletionEmpty();

            //Выводи кол-ва приборов в каждой комнате 
            CountInRooms();

            //Изменение статусной строки 
            int turnedOn = _flatController.CountTurnedOn(), amount = _flatController.Count;
            TSl_Footer.Text = $"Приборов в квартире: {amount} | Включено: {turnedOn} | Выключено: {amount - turnedOn}";

            //Сохранение 
            _flatController.Serialize();
        }

        //Добавление коллекции приборов в фомру
        private void AddCollection_Command(object sender, EventArgs e)
        {
            _flatController.Flat.AddCollectionToList();

            //Проводим повторную связку с GridView
            FillGridView(_flatController.GetAppliances,Dgv_Main);

            //Изменяем дерево
            FillTreeView();

            //Проверка на пустоту 
            IsColletionEmpty();

            //Выводи кол-ва приборов в каждой комнате 
            CountInRooms();

            //Изменение статусной строки 
            int turnedOn = _flatController.CountTurnedOn(), amount = _flatController.Count;
            TSl_Footer.Text = $"Приборов в квартире: {amount} | Включено: {turnedOn} | Выключено: {amount - turnedOn}";

            //Сохранение 
            if (_flatController.Count < 1000)
                _flatController.Serialize();
        }

        //Удаление прибора
        private void DelAppliance_Command(object sender, EventArgs e)
        {
            //Если выделено несколько записей
            if (Dgv_Main.SelectedRows.Count > 1)
            {
                DelMultiple();
                return;
            }

           DataGridViewRow dgvRow = Dgv_Main.CurrentRow;
            int RowInd = dgvRow.Index;

            //Если выделение некорректно - уходим
            if (RowInd > Dgv_Main.RowCount - 1 || RowInd < 0)
                return;

            //Получаем инжекс выбранного прибора в основной коллекции
            int ind = _flatController.GetAppliances.IndexOf(dgvRow.Tag as Appliance);

            //Удаление элемента
            _flatController.GetAppliances.RemoveAt(ind);

            //Проводим повторную связку с GridView
            FillGridView(_flatController.GetAppliances, Dgv_Main);

            //Изменяем дерево
            FillTreeView();

            //Проверка на пустоту 
            IsColletionEmpty();

            //Выводи кол-ва приборов в каждой комнате 
            CountInRooms();

            //Изменение статусной строки 
            int turnedOn = _flatController.CountTurnedOn(), amount = _flatController.Count;
            TSl_Footer.Text = $"Приборов в квартире: {amount} | Включено: {turnedOn} | Выключено: {amount - turnedOn}";

            //Сохранение 
            if (_flatController.Count >= 5)
                _flatController.Serialize();
        }

        //Удаление всей коллекции [23.11]
        private void DelAll_Command(object sender, EventArgs e)
        {
            _flatController.Flat.Appliances.RemoveRange(0, _flatController.Count);

            //Проводим повторную связку с GridView
            FillGridView(_flatController.GetAppliances, Dgv_Main);

            //Изменяем дерево
            FillTreeView();

            //Проверка на пустоту 
            IsColletionEmpty();

            //Изменение статусной строки 
            int turnedOn = _flatController.CountTurnedOn(), amount = _flatController.Count;
            TSl_Footer.Text = $"Приборов в квартире: {amount} | Включено: {turnedOn} | Выключено: {amount - turnedOn}";

        }

        //Отключение элементов управления коллекцией в случае её пустоты [23.11.21]
        private void IsColletionEmpty()
        {
            //Если коллекция не пуста
            if (!_flatController.IsEmpty)
            {

                //Изменение состояний кнопок
                EditAppToolStripMenuItem.Enabled = true;
                DeleteAppMNI.Enabled = true;
                AddCollectionAppMni.Enabled = true;
                SortsToolStripMenuItem.Enabled = true;
                SelectionTSMItem.Enabled = true;
                //DelAppsMni.Enabled = true;
                TurnOnAllTopMni.Enabled = true;
                TurnOffAllTopMni.Enabled = true;

                //Включаем кнопку выборки 
                SelectionTSMItem.Enabled = true;

                //Включаем кнопки контекстного меню 
                DelAppCM.Enabled = true;
                DelWhole_CM.Enabled = _flatController.Count > 1;
                EditAppCM.Enabled = true;
                SelecetionsSetCM.Enabled = true;
                SortsSetCM.Enabled = true;

                //Кнопки управления приборами
                BtnTurnOnOneStrip.Enabled =
                BtnTurnOFFOneStrip.Enabled =
                TurnOnAppliance_CM.Enabled =
                TurnOffAppliance_CM.Enabled = true;

                //Отключаем возможность загрузки из файла 
                OpenFile_CM.Visible = false;

                //включаем кнопки menu strip
                BtnSortsToolStrip.Enabled = true;
                BtnSelectionsToolStrip.Enabled = true;
                BtnEditToolStrip.Enabled = true;
                BtnDelAppToolStrip.Enabled = true;
                BtnManyAppsStrip.Enabled = true;

                //Включение текстового поля
                GbxRooms.Visible = GbxAppliance.Visible = true;

                //Отключение уведомления 
                Lbl_Main_Empty.Visible = false;

                return;

            }

            //Если коллекция пуста, оставляем включенными только возможности добавления 
            //Изменение состояний кнопок 

            EditAppToolStripMenuItem.Enabled = false;

            //Отключаем кнопку выборки 
            SelectionTSMItem.Enabled = false;
            SortsToolStripMenuItem.Enabled = false;
            DeleteAppMNI.Enabled = false;

            //DelAppsMni.Enabled = false;
            DelWhole_CM.Enabled = false;
            TurnOnAllTopMni.Enabled = false;
            TurnOffAllTopMni.Enabled = false;
            //Отключаем кнопки контекстного меню 

            DelAppCM.Enabled = false;
            EditAppCM.Enabled = false;
            SelecetionsSetCM.Enabled = false;
            SortsSetCM.Enabled = false;

            //Кнопки управления приборами
            BtnTurnOnOneStrip.Enabled =
            BtnTurnOFFOneStrip.Enabled =
            TurnOnAppliance_CM.Enabled =
            TurnOffAppliance_CM.Enabled = false;

            //Включаем возможность загрузки из файла 
            OpenFile_CM.Visible = true;

            //Отключаем кнопки menu strip
            BtnSortsToolStrip.Enabled = false;
            BtnSelectionsToolStrip.Enabled = false;
            BtnEditToolStrip.Enabled = false;
            BtnDelAppToolStrip.Enabled = false;
            BtnManyAppsStrip.Enabled = false;

            //Включение текстовых полей
            GbxRooms.Visible = GbxAppliance.Visible = false;

            //Отключение уведомления 
            Lbl_Main_Empty.Visible = true;
            Lbl_Main_Empty.Text = "Коллекция приборов пуста!";

        }

        #region Сортировки 

        //Загрузка вкладки
        private void SortsTab_Fill(List<Appliance> collection, string Type)
        {
            //Переключаем текущую вкладку 
            Tab_Control_Main.SelectedTab = Sorts_Tab;

            //Заполняем GridView
            FillGridView(collection,Dgv_Sorts);

            //Задание текста на Label
            switch (Type)
            {
                case "по имени":
                    Lbl_SortsTab.Text = "Сортировка приборов по названию";
                    break;

                case "по состоянию":
                    Lbl_SortsTab.Text = "Сортировка приборов по состоянию";
                    break;

                case "по мощности":
                    Lbl_SortsTab.Text = "Сортировка приборов по мощности";
                    break;

                case "по стоимости":
                    Lbl_SortsTab.Text = "Сортировка приборов по стоимости";
                    break;
                default:
                    break;
            }

            //Изменение статусной строки 
            int turnedOn = _flatController.CountTurnedOn(), amount = _flatController.Count;
            TSl_Footer.Text = $"Отсортировано приборов {Type}: {collection.Count} | Включено: {turnedOn} | Выключено: {amount - turnedOn}";

        }
        private void SortByNameTSMItem_Command(object sender, EventArgs e)
        {
            //Сортировка коллекции. Метод контроллера возвращает отсортированную копию коллекции
            SortsTab_Fill(_flatController.SortByName(), "по имени");

        }

        private void SortByStatelTSMItem_Command(object sender, EventArgs e)
        {

            //Сортировка коллекции. Метод контроллера возвращает отсортированную копию коллекции
            SortsTab_Fill(_flatController.SortByState(), "по состоянию");

        }
        private void SortByPowerTSMItem_Command(object sender, EventArgs e)
        {

            //Сортировка коллекции. Метод контроллера возвращает отсортированную копию коллекции
            SortsTab_Fill(_flatController.SortByPower(), "по мощности");

        }

        private void SortByPriceTSMItem_Command(object sender, EventArgs e)
        {

            //Сортировка коллекции. Метод контроллера возвращает отсортированную копию коллекции
            SortsTab_Fill(_flatController.SortDescByPrice(), "по стоимости");
        }
        #endregion

        private void ReformCollection_Command(object sender, EventArgs e)
        {
            _flatController.Flat.Generate(Utils.Random.Next(12, 15));

            //Проводим повторную связку с GridView
            FillGridView(_flatController.GetAppliances, Dgv_Main);

            //Изменяем дерево
            FillTreeView();

            //Проверка на пустоту 
            IsColletionEmpty();

            //Выводи кол-ва приборов в каждой комнате 
            CountInRooms();

            //Изменение статусной строки 
            int turnedOn = _flatController.CountTurnedOn(), amount = _flatController.Count;
            TSl_Footer.Text = $"Приборов в квартире: {amount} | Включено: {turnedOn} | Выключено: {amount - turnedOn}";

            //Сохранение 
            _flatController.Serialize();

        }

        #region Обработчики события на вкладках
        //Закрыть вкладку при выходе
        private void Tab_Leave(object sender, EventArgs e)
        {
            //Включаем кнопки управления
            TurnOn_Buttons_Tab();

        }

        //Переход во динамическую вкладку
        private void Enter_Dyn_Tab(object sender, EventArgs e)
        {

            TabPage tempPage = sender as TabPage;
            //Отключаем кнопки управления коллекцией 
            TurnOff_Buttons_Tab(tempPage);


            if (tempPage == Sorts_Tab)
                SortByNameTSMItem_Command(sender, e);
            else if (tempPage == Selection_Tab)
            {
                ReturnPorperSizes();
                //Проверка коллекции на пустоту
                if (_flatController.IsEmpty)
                {
                    IsColletionEmpty();

                    Lbl_SelectionTab.Text = "Исходная коллекция пуста!\r\nЗаполните данными!";

                    TSl_Footer.Text = "";
                    return;
                }

                if (Dgv_Selections.RowCount <= 0)
                    //Выводим сообщение
                    Lbl_SelectionTab.Text = "Необходимо выбрать способ выборки в меню сверху!";
                
                TSl_Footer.Text = "";
            }
            //Если возращаемя на главную вкладку
            else if (tempPage == Main_tab)
            {
                IsColletionEmpty();
                //Изменение статусной строки 
                int turnedOn = _flatController.CountTurnedOn(), amount = _flatController.Count;
                TSl_Footer.Text = $"Приборов в квартире: {amount} | Включено: {turnedOn} | Выключено: {amount - turnedOn}";

            }


        }

        #endregion

        #region Выборки


        //Загрузка вкладки
        private void SelectionTab_Fill(List<Appliance> collection)
        {
            //Переключаем текущую вкладку 
            Tab_Control_Main.SelectedTab = Selection_Tab;

            FillGridView(collection,Dgv_Selections);

        }


        //Выборка по  
        private void SelectByName_Command(object sender, EventArgs e)
        {

            ReturnPorperSizes();

            //Список для хранения возвращаемого списка 
            List<Appliance> Appliances = new List<Appliance>();

            //Создаём окно выбора подколлекции 
            Select_Certain select_Certain = new Select_Certain(_flatController, Select_Certain.SubObject.name);

            if (select_Certain.ShowDialog() != DialogResult.OK)
                return;

            //Получаем выбранного мастера
            string ChosenName = (string)select_Certain.ChosenItem;

            Appliances = _flatController.SelectByName(ChosenName);

            //Открываем вкладку
            SelectionTab_Fill(Appliances);

            //Выводим сообщение
            Lbl_SelectionTab.Text = $"Выборка по названию прибора \"{ChosenName}\"";
        }

        //Выборка по 
        private void SelectByState_Command(object sender, EventArgs e)
        {
            ReturnPorperSizes();

            //Список для хранения возвращаемого списка 
            List<Appliance> Appliances = new List<Appliance>();

            //Создаём окно выбора подколлекции 
            Select_Certain select_Certain = new Select_Certain(_flatController, Select_Certain.SubObject.state);

            if (select_Certain.ShowDialog() != DialogResult.OK)
                return;

            //Получаем выбранную
            string ChosenState = (string)select_Certain.ChosenItem;
            bool state = ChosenState == "Включен" ? true : false;

            Appliances = _flatController.SelectByState(state);

            //Выводим сообщение
            Lbl_SelectionTab.Text = $"Выборка по состоянию прибора \"{ChosenState}\"";

            //Открываем вкладку
            SelectionTab_Fill(Appliances);

        }

        //Выборка по подстроке
        private void SelectBySubStr_Command(object sender, EventArgs e)
        {

            //Настраиваем размеры и видимость элементов 
            Lbl_SelectBy_room.Visible = Tbx_Search.Visible = true;
            Dgv_Selections.Size = new Size(789, 434);
            Dgv_Selections.Location = new Point(8, 85);

            

            //Добавляем комнаты в подсказки
            Tbx_Search.AutoCompleteCustomSource.Clear();
            Tbx_Search.AutoCompleteCustomSource.AddRange(_flatController.GetRooms().ToArray());

            //Устанавливаем фокус на строку ввода
            Tbx_Search.Focus();

            //Выводим сообщение
            Lbl_SelectionTab.Text = $"Выборка по комнате. \r\n Начните ввод значений!";
        }

        //Ввод строки комнаты
        private void Tbx_Search_TextChanged(object sender, EventArgs e)
        {
            SelectionTab_Fill(_flatController.SelectByRoomWhere(Tbx_Search.Text));
            //Выводим сообщение
            Lbl_SelectionTab.Text = $"Поиск по строке: {Tbx_Search.Text}";
        }

        //Ограничения на ввод при поиске
        private void Tbx_Search_KeyDown(object sender, KeyEventArgs e)
        {
            //Код клавиши 
            Keys code = e.KeyCode;

            //Ограничние
            if (code == Keys.Space || (code >= Keys.D0 && code <= Keys.D9) || (code >= Keys.NumPad0 && code <= Keys.NumPad9))
                e.SuppressKeyPress = true;

        }
        #endregion

        //Задаёт стандартные размеры элементов на форме выборки 
        private void ReturnPorperSizes()
        {
            Lbl_SelectBy_room.Visible = Tbx_Search.Visible = false;
            Dgv_Selections.Size = new Size(789,513);
            Dgv_Selections.Location = new Point(8, 17);
        }

        //Удаление множества приборов
        private void BtnDelCertain_Click(object sender, EventArgs e)
        {
            //Вызываем форму удаления 
            Delete_Certain_Form del_Form = new Delete_Certain_Form(_flatController);

            if (del_Form.ShowDialog() != DialogResult.OK)
                return;
            //Получаем измененный контроллер
            _flatController = del_Form.rsController;



            //Сохранение если в коллекции осталось мие 5 элементов
            if (_flatController.Count >= 5)
                _flatController.Serialize();

            //Проверка на пустоту 
            IsColletionEmpty();

        }

        //Редактирование прибора
        private void EditAppliance_Command(object sender, EventArgs e)
        {
            DataGridViewRow dgvRow = Dgv_Main.CurrentRow;
            int RowInd = dgvRow.Index;

            //Если выделение некорректно - уходим
            if (RowInd > Dgv_Main.RowCount - 1 || RowInd < 0)
            {
                MessageBox.Show("Не выбран прибор", "Ошибка", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
                return;
            }

            //Получаем инжекс выбранного прибора в основной коллекции
            int ind = _flatController.GetAppliances.IndexOf(dgvRow.Tag as Appliance);

            //Запоминаем старую комнату
            string oldRoom = _flatController.GetAppliances[ind].Room;

            //Создаём форму в режиме редактирования
            Appliance_form appliance_Form = new Appliance_form(_flatController.GetAppliances[ind], _flatController.GetRooms());
            DialogResult showResult = appliance_Form.ShowDialog();

            //Если заверешение работы формы произошло не через кнопку добавить/сохранить
            //со свойством DialogResult.Yes, тогда объект не добавляем

            if (showResult != DialogResult.OK)
                return;

            //Если же завершение работы формы было корректным, тогда изменяем выбранный обект в списке
            Appliance TempApp = appliance_Form.appliance;

            _flatController.Flat.Appliances.Insert(ind, TempApp);

            //Изменение дерева 
            FillTreeView();

            //Изменение записи на GridView
            FillGridView(_flatController.GetAppliances,Dgv_Main);

            //Если комната изменилась
            if (_flatController.GetAppliances[ind].Room != oldRoom)
                //Выводим кол-ва приборов в каждой комнате 
                CountInRooms();

            //Сохранение 
            _flatController.Serialize();
        }

        //Запус формы о программе
        private void About_Command(object sender, EventArgs e)
        {
            Form fromAbout = new AboutForm();
            fromAbout.ShowDialog();
        }

        private void OpenFile_Command(object sender, EventArgs e)
        {
            DialogResult showResult = OFD.ShowDialog();
            if (showResult != DialogResult.OK)
                return;
            _flatController.FName = OFD.FileName;

            _flatController.Deserialize();

            //Презапись GridView
            FillGridView(_flatController.GetAppliances,Dgv_Main);

            //Перезапись TreeView
            FillTreeView();

            //Проверка на пустоту 
            IsColletionEmpty();

            //Выводим кол-ва приборов в каждой комнате 
            CountInRooms();

        }

        //Редактирование днанных телемастерской 
        private void EditFlat_Command(object sender, EventArgs e)
        {

            EditFlat_Form editFlat = new EditFlat_Form(_flatController.Flat.Adress);

            //Если форма была завершена не по кнопке "Сохранить"
            if (editFlat.ShowDialog() != DialogResult.OK)
                return;

            //Перезаписываем 
            _flatController.Flat.Adress = editFlat.Adress_;


        }

        //Изменение шрифта
        private void ChangeFont_Command(object sender, EventArgs e)
        {
            if (FND_GridView.ShowDialog() != DialogResult.OK)
                return;
            Dgv_Main.Font = FND_GridView.Font;
            Dgv_Sorts.Font = FND_GridView.Font;
            Dgv_Selections.Font = FND_GridView.Font;

        }

        //Изменение цвета
        private void ChangeColor_Command(object sender, EventArgs e)
        {
            if (CLD_GridView.ShowDialog() != DialogResult.OK)
                return;

            ToolStripMenuItem button = sender as ToolStripMenuItem;
            if (button == ChangeBackColor_CM)
            {
                Dgv_Main.BackColor = CLD_GridView.Color;
                Dgv_Selections.BackColor = CLD_GridView.Color;
                Dgv_Sorts.BackColor = CLD_GridView.Color;

            }
            else if (button == ChangeForeColor_CM)
            {
                Dgv_Main.ForeColor = CLD_GridView.Color;
                Dgv_Selections.ForeColor = CLD_GridView.Color;
                Dgv_Sorts.ForeColor = CLD_GridView.Color;
            }

        }

        //Отключение кнопок управления коллекцией при открытии вкладок Выборка и Сортировки 
        private void TurnOff_Buttons_Tab(TabPage tabPage)
        {
            //Если вкладка - выборка
            if (tabPage == Selection_Tab)
            {
                //Изменение состояний кнопок верхнего меню

                EditAppToolStripMenuItem.Enabled =
                SortsToolStripMenuItem.Enabled =
                DeleteAppMNI.Enabled =
                DelWhole_CM.Enabled =
                AddAppToolStripMenuItem.Enabled =
                ReformTSMItem.Enabled =
                AddCollectionAppMni.Enabled =
                TurnOnAllTopMni.Enabled =
                TurnOffAllTopMni.Enabled = false;

                //Отключаем кнопки menu strip
                BtnAddToolStrip.Enabled =
                BtnSortsToolStrip.Enabled =
                BtnEditToolStrip.Enabled =
                BtnDelAppToolStrip.Enabled =
                BtnManyAppsStrip.Enabled =
                BtnTurnOnOneStrip.Enabled =
                BtnTurnOFFOneStrip.Enabled = false;
                //BtnSelectionsToolStrip.Enabled = false;

            }
            //Оператор else if для полного контроля
            else if (tabPage == Sorts_Tab)
            {
                //Изменение состояний кнопок 
                EditAppToolStripMenuItem.Enabled =
                SelectionTSMItem.Enabled =
                DeleteAppMNI.Enabled =
                DelWhole_CM.Enabled =
                AddAppToolStripMenuItem.Enabled =
                ReformTSMItem.Enabled =
                AddCollectionAppMni.Enabled =
                TurnOnAllTopMni.Enabled =
                TurnOffAllTopMni.Enabled = false;

                SortsToolStripMenuItem.Enabled =
                BtnSortsToolStrip.Enabled = true;

                //Включаем кнопки menu strip
                BtnAddToolStrip.Enabled =
                BtnSelectionsToolStrip.Enabled =
                BtnEditToolStrip.Enabled =
                BtnDelAppToolStrip.Enabled =
                BtnManyAppsStrip.Enabled =
                BtnTurnOnOneStrip.Enabled =
                BtnTurnOFFOneStrip.Enabled = false;

            }
        }        
        //Отключение кнопок управления коллекцией при открытии вкладок Выборка и Сортировки 
        private void Turn_Buttons_State(bool State = false)
        {
                //Изменение состояний кнопок верхнего меню

                EditAppToolStripMenuItem.Enabled =
                SortsToolStripMenuItem.Enabled =
                DeleteAppMNI.Enabled =
                DelWhole_CM.Enabled =
                AddAppToolStripMenuItem.Enabled =
                TurnOnAllTopMni.Enabled =
                SortsToolStripMenuItem.Enabled =
                SelectionTSMItem.Enabled =
                TurnOffAllTopMni.Enabled =
                ReformTSMItem.Enabled =
                AddCollectionCM.Enabled =
                AddCollectionAppMni.Enabled =
                AddAppCM.Enabled =
                EditAppCM.Enabled =
                AddCollectionTSMItem.Enabled = State;

            //Отключаем кнопки menu strip
            BtnAddToolStrip.Enabled =
                BtnSortsToolStrip.Enabled =
                BtnEditToolStrip.Enabled =
                BtnDelAppToolStrip.Enabled =
                BtnManyAppsStrip.Enabled =
                BtnTurnOnOneStrip.Enabled =
                BtnTurnOFFOneStrip.Enabled =
                BtnSortsToolStrip.Enabled =
                BtnSelectionsToolStrip.Enabled = State;
        }

        //Отключение кнопок управления коллекцией при открытии вкладок Выборка и Сортировки 
        private void TurnOn_Buttons_Tab()
        {
            //Изменение состояний кнопок 
            EditAppToolStripMenuItem.Enabled =
            SortsToolStripMenuItem.Enabled =
            SelectionTSMItem.Enabled =
            DeleteAppMNI.Enabled =
            //DelAppsMni.Enabled = 
            DelWhole_CM.Enabled =
            AddAppToolStripMenuItem.Enabled =
            ReformTSMItem.Enabled =
            AddCollectionAppMni.Enabled =
            TurnOnAllTopMni.Enabled =
            TurnOffAllTopMni.Enabled = true;

            //Включаем кнопки menu strip
            BtnAddToolStrip.Enabled =
            BtnSortsToolStrip.Enabled =
            BtnSelectionsToolStrip.Enabled =
            BtnEditToolStrip.Enabled =
            BtnDelAppToolStrip.Enabled =
            BtnManyAppsStrip.Enabled =
            BtnTurnOnOneStrip.Enabled =
            BtnTurnOFFOneStrip.Enabled = true;


        }

        private void OpenFromTray_Command(object sender, EventArgs e)
        {
            this.Show();
            WindowState = FormWindowState.Normal;

            //Отключаем иконку 
            NTI.Visible = false;
        }

        private void HideForm_Command(object sender, EventArgs e)
        {
            this.Hide();
            NTI.Visible = true;
        }

        #region Изменение состояния приборов на GridView

        //Выключение одного прибора
        private void TurnOnOne_Command(object sender, EventArgs e)
        {
            DataGridViewRow dgvRow = Dgv_Main.CurrentRow;
            int RowInd = dgvRow.Index;

            //Если выделение некорректно - уходим
            if (RowInd > Dgv_Main.RowCount - 1 || RowInd < 0 || !Dgv_Main.Focused)
            {
                BtnTurnOnOneStrip.Enabled = 
                BtnTurnOFFOneStrip.Enabled = true;
                return;
            } 

            //Получаем инжекс выбранного прибора в основной коллекции
            int index = _flatController.GetAppliances.IndexOf(dgvRow.Tag as Appliance);

            //Включаем прибор по индексу 
            _flatController.TurnApp(index, true);

            //Перепривязка данных 

            Appliance appliance = _flatController.GetAppliances[index];

            ChangeOne(Dgv_Main.SelectedRows,appliance);
            ChangeApplianceStateTrv(appliance);

            //Отключение нажатой кнопки
            BtnTurnOnOneStrip.Enabled = false;
            BtnTurnOFFOneStrip.Enabled = true;

            ChangeStatusString();
        }

        //Выключение одного прибора
        private void TurnOffOne_Command(object sender, EventArgs e)
        {
            DataGridViewRow dgvRow = Dgv_Main.CurrentRow;
            int RowInd = dgvRow.Index;

            //Если выделение некорректно - уходим
            if (RowInd > Dgv_Main.RowCount - 1 || RowInd < 0 || !Dgv_Main.Focused)
            {
                BtnTurnOnOneStrip.Enabled =
                BtnTurnOFFOneStrip.Enabled = true;
                return;
            }

                //Получаем инжекс выбранного прибора в основной коллекции
                int index = _flatController.GetAppliances.IndexOf(dgvRow.Tag as Appliance);

            //Включаем прибор по индексу 
            _flatController.TurnApp(index, false);

            //Перепривязка данных 

            Appliance appliance = _flatController.GetAppliances[index];

            ChangeOne(Dgv_Main.SelectedRows, appliance);
            ChangeApplianceStateTrv(appliance);

            BtnTurnOnOneStrip.Enabled = true;
            BtnTurnOFFOneStrip.Enabled = false;

            ChangeStatusString();
        }

        //Включение всех приборов
        private void TurnOnAll_Command(object sender, EventArgs e)
        {
            _flatController.TurnAllApp(true);

            //Перепривязка данных 
            FillGridView(_flatController.GetAppliances,Dgv_Main);
            FillTreeView();

            ChangeStatusString();
        }

        //Выключение всех приборов
        private void TurnOffAll_Command(object sender, EventArgs e)
        {
            _flatController.TurnAllApp(false);

            //Перепривязка данных 
            FillGridView(_flatController.GetAppliances, Dgv_Main);
            FillTreeView();

            ChangeStatusString();
        }

        #endregion

        #region Drag&Drop

        //Сброс на форму
        private void Main_form_DragEnter(object sender, DragEventArgs e)
        {

            // проверка на содержимое
            if (e.Data.GetDataPresent(DataFormats.FileDrop))
            {
                // переход на главную вкладку
                Tab_Control_Main.SelectedTab = Main_tab;

                // изменение цвета GridView
                Dgv_Main.BackgroundColor = Color.CornflowerBlue;

                // установка эффекта
                e.Effect = DragDropEffects.Copy;
            }
            else
                // установка эффекта
                e.Effect = DragDropEffects.None;
        }
        private void Main_form_DragLeave(object sender, EventArgs e)
        {
            //Меняем цвет GridView 
            Dgv_Main.BackgroundColor = Color.White;
        }


        private void Ggv_Main_DragDrop(object sender, DragEventArgs e)
        {
            Dgv_Main.BackgroundColor = Color.White;

            string fileName = ((string[])e.Data.GetData(DataFormats.FileDrop))[0];
            _flatController.FName = fileName;
            _flatController.Deserialize();

            FillGridView(_flatController.GetAppliances,Dgv_Main);
            FillTreeView();

            //Выводим кол-ва приборов в каждой комнате 
            CountInRooms();

            IsColletionEmpty();

            ChangeStatusString();

        }
        private void Dvg_Main_DragLeave(object sender, EventArgs e)
        {
            //Меняем цвет GridView 
            Dgv_Main.BackgroundColor = Color.White;
        }
        #endregion

        #region Работа с дервом
        //Обработчик открывания контекстного меню
        private void ContexMS_TrvMain_Opened(object sender, EventArgs e)
        {
            TreeNode selectedNode = Trv_Main.SelectedNode;

            int selectedLevel = selectedNode.Level;

            //Если выбор узла некорректен - уходим
            if (selectedLevel < 0 || selectedLevel > 3)
                return;

            //Заранее отключаем все кнопки
            ContexMS_TrvMain_buttonsOff();

            switch (selectedLevel)
            {
                //Уровень квартиры
                case 0:

                    //Если все приборы включены
                    if (_flatController.AllTurnedOn())
                    {
                        CM_Trv_TurnAllOn.Visible = false;
                        CM_Trv_TurnAllOff.Visible =
                        CM_Trv_AddItem.Visible = true;
                    }

                    //Если все выключены
                    else if (_flatController.AllTurnedOff())
                    {
                        CM_Trv_TurnAllOn.Visible =
                        CM_Trv_AddItem.Visible = true;
                        CM_Trv_TurnAllOff.Visible = false;
                    }

                    //Если наблюдаются 2 состояния
                    else
                    {
                        CM_Trv_TurnAllOn.Visible =
                        CM_Trv_TurnAllOff.Visible =
                        CM_Trv_AddItem.Visible = true;
                    }
                    CM_Trv_Edit_Flat.Visible = true;
                    break;

                //Уровень комнаты
                case 1:

                    //Если все приборы в комнате включены
                    if (_flatController.AllTurnedOn(selectedNode.Text))
                    {
                        CM_Trv_TurnAllOn.Visible = false;
                        CM_Trv_TurnAllOff.Visible = true;
                    }

                    //Если все приборы в комнате выключены
                    else if (_flatController.AllTurnedOff(selectedNode.Text))
                    {
                        CM_Trv_TurnAllOn.Visible = true;
                        CM_Trv_TurnAllOff.Visible = false;
                    }

                    //Если наблюдаются 2 состояния
                    else
                    {
                        CM_Trv_TurnAllOn.Visible =
                        CM_Trv_TurnAllOff.Visible = true;
                    }
                    break;
                //Уровень прибора
                case 2:
                    //ВЫбор кнопки в зависимости от состояния
                    ((selectedNode.Tag as Appliance).State ? CM_Trv_TurnOff : CM_Trv_TurnOn).Visible =
                    CM_Trv_Delete.Visible =
                    CM_Trv_Edit_Applince.Visible = true;
                    break;

                default:
                    //Если ничего не выбрано - выводим контекстное меню с сообщением
                    ContexMS_TrvMain_buttonsOff(true);
                    break;
            }

        }

        //Отключение всех кнопок контеrстного меню TreeView
        private void ContexMS_TrvMain_buttonsOff(bool TurnOnNotification = false)
        {
            string NotificationTbx = "Нет соответствий!";
            ToolStripItemCollection TSI_Collection = ContexMS_TrvMain.Items;


            //Отключаем кликабельные элементы
            foreach (ToolStripMenuItem item in TSI_Collection)
            {
                item.Visible = false;
            }

            //Если нужно показывать уведомление и элемент не был создан
            if (TurnOnNotification && !TSI_Collection.ContainsKey(NotificationTbx))
                //Создаём элемент. Создаём практически кнопку
                ContexMS_TrvMain.Items.Add(NotificationTbx, Image.FromFile("..\\..\\Icons\\Notification.jpg")).Name = NotificationTbx;

            //Если нужно показывать уведомление и TextBox был создан и находится в коллекции
            else if (TurnOnNotification && TSI_Collection.ContainsKey(NotificationTbx))
                //Находим нужный элемент и включаем его
                TSI_Collection.Find(NotificationTbx, false)[0].Visible = true;

            //Если нам не нужно показывать уведомление и TexBox создан - отключаем его
            else if (!TurnOnNotification && TSI_Collection.ContainsKey(NotificationTbx))
                //Находим нужный элемент и выключаем его
                TSI_Collection.Find(NotificationTbx, false)[0].Visible = false;

        }

        //Коррекция поведения при выделении
        private void TrvMain_Node_MouseClick(object sender, TreeNodeMouseClickEventArgs e)
        {
            //Задаём вделение узла передаваемого в аргументах
            Trv_Main.SelectedNode = e.Node;
        }

        //Включение прибора из контекстного меню TrvMain
        private void CM_Trv_TurnOn_Click(object sender, EventArgs e)
        {

            TreeNode selectedNode = Trv_Main.SelectedNode;
            int selectedLevel = selectedNode.Level;

            //Проверка на уровень. Если не уровень приборов - уходим
            if (selectedLevel != 2)
                return;

            //Изменяем объект в tag'e
            Appliance appliance = (selectedNode.Tag as Appliance);
            appliance.State = true;

            //Изменение индекса изображений проецирующих состояние 
            selectedNode.ImageIndex = 1;
            selectedNode.SelectedImageIndex = 1;

            //Перезавписываем GridView
            //FillGridView(_flatController.GetAppliances,Dvg_Main);

            //Изменяем только соответствующий объект в GridView 
            ChangeAddOne(appliance);

            //Изменяем статусную строку 
            ChangeStatusString();

        }

        //Отключение прибора из контекстного меню TrvMain
        private void CM_Trv_TurnOff_Click(object sender, EventArgs e)
        {
            TreeNode selectedNode = Trv_Main.SelectedNode;
            int selectedLevel = selectedNode.Level;

            //Проверка на уровень. Если не уровень приборов - уходим
            if (selectedLevel != 2)
                return;

            //Изменяем объект в tag'e
            Appliance appliance = (selectedNode.Tag as Appliance);
            appliance.State = false;

            //Изменение индекса изображений проецирующих состояние 
            selectedNode.ImageIndex = 0;
            selectedNode.SelectedImageIndex = 0;

            //Перезавписываем GridView
            //FillGridView(_flatController.GetAppliances, Dvg_Main);

            //Изменяем только соответствующий объект в GridView 
            ChangeAddOne(appliance);

            //Изменяем статусную строку 
            ChangeStatusString();
        }

        //Включение всех приборов
        private void CM_Trv_TurnAllOn_Click(object sender, EventArgs e)
        {
            TreeNode selectedNode = Trv_Main.SelectedNode;
            int selectedLevel = selectedNode.Level;

            //Если находися на уровне приборов - уходим
            if ((Appliance)selectedNode.Tag != null)
                return;

            //Если уровень квартиры - выключаем абсолютно все приборы
            if (selectedLevel == 0)
                _flatController.TurnAllApp(true);
            //Если уровень квартир - выключаем по квартире
            else if (selectedLevel == 1)
                _flatController.TurnAppByRoom(selectedNode.Text, true);

            //Перепривязываем дерево и GridView
            FillTreeView();
            FillGridView(_flatController.GetAppliances,Dgv_Main);

            //Изменяем строку статуса
            ChangeStatusString();

        }

        //Выключение всех приборов в квартире/комнате
        private void CM_Trv_TurnAllOff_Click(object sender, EventArgs e)
        {

            TreeNode selectedNode = Trv_Main.SelectedNode;
            int selectedLevel = selectedNode.Level;

            //Если находися на уровне приборов - уходим
            if ((Appliance)selectedNode.Tag != null)
                return;

            //Если уровень квартиры - выключаем абсолютно все приборы
            if (selectedLevel == 0)
                _flatController.TurnAllApp(false);
            //Если уровень квартир - выключаем по квартире
            else if (selectedLevel == 1)
                _flatController.TurnAppByRoom(selectedNode.Text, false);

            //Перепривязываем дерево и GridView
            FillTreeView();
            FillGridView(_flatController.GetAppliances, Dgv_Main);

            //Изменяем строку статуса
        }

        //Редактирование прибора 
        private void CM_Trv_Edit_Applince_Click(object sender, EventArgs e)
        {
            TreeNode selectedNode = Trv_Main.SelectedNode;
            Appliance appliance = (Appliance)selectedNode.Tag;

            //Если находися не на уровне приборов - уходим
            if (appliance == null)
                return;

            //передаём выделенный прибор в фомру 
            Appliance_form appliance_Form = new Appliance_form(appliance, Utils.GetUniqueRooms(), true);

            if (appliance_Form.ShowDialog() != DialogResult.OK)
                return;

            //Получаем отредактированный объект
            Appliance EditedAppliance = appliance_Form.appliance;
            //Изменяем узел
            int ImageInd = EditedAppliance.State ? 1 : 0;
            selectedNode.Text = $"{EditedAppliance.Name}. {EditedAppliance.Power} Вт";
            selectedNode.ImageIndex =
            selectedNode.SelectedImageIndex = ImageInd;
            selectedNode.Tag = EditedAppliance;

            //Перезаписываем GridView и коллекцию приборов
            int ChangedInd = _flatController.GetAppliances.IndexOf(appliance);
            _flatController.GetAppliances.Insert(ChangedInd, EditedAppliance);
            FillGridView(_flatController.GetAppliances, Dgv_Main);


        }

        //Изменение состояния прибора извне 
        private void ChangeApplianceStateTrv(Appliance appliance)
        {
            //Проход по квартирам 
            foreach (TreeNode FlatNode in Trv_Main.Nodes)
            {
                //Проход по комнатам внутри квартиры 
                foreach (TreeNode RoomNode in FlatNode.Nodes)
                {
                    //Проход по приборам внутри комнаты 
                    foreach (TreeNode ApplianceNode in RoomNode.Nodes)
                    {
                        //Если найден прибор с измененным состоянием - меняем узел
                        if (ApplianceNode.Tag == appliance)
                        {
                            int image = appliance.State ? 1 : 0;
                            ApplianceNode.ImageIndex =
                            ApplianceNode.SelectedImageIndex = image;
                        }//if

                    }//Проход по приборам внутри комнаты

                }//Проход по комнатам внутри квартиры 

            }//Проход по квартирам 
        }

        //Двойной клик мыши - редактирование прибора
        private void Trv_Main_NodeMouseDblClick(object sender, TreeNodeMouseClickEventArgs e)
        {
            //Просто вызываем обработчик события кнопки контестного меню
            CM_Trv_Edit_Applince_Click(sender, new EventArgs());
        }

        //Удаление прибора с дерева 
        private  void Del_From_Tree(Appliance appliance)
        {
            //Проход по квартирам 
            foreach (TreeNode FlatNode in Trv_Main.Nodes)
            {
                //Проход по комнатам внутри квартиры 
                foreach (TreeNode RoomNode in FlatNode.Nodes)
                {
                    //Если текущая комнта пуста - удаляем ёё
                    if (RoomNode.Nodes.Count == 0)
                        RoomNode.Remove();

                    //Проход по приборам внутри комнаты 
                    foreach (TreeNode ApplianceNode in RoomNode.Nodes)
                    {
                        //Если найден прибор с измененным состоянием - удаляем узел
                        if (ApplianceNode.Tag == appliance)
                        {
                            ApplianceNode.Remove();
                            //Прерываем цыкл
                            break;
                        }//if

                    }//Проход по приборам внутри комнаты

                }//Проход по комнатам внутри квартиры 

            }//Проход по квартирам 
        }

        //Добавить прибор в дерево 
        private void AddAppliance_Tree(Appliance appliance)
        {
            bool added = false;
            int imageIndex = appliance.State ? 1 : 0;

            //Проход по квартирам 
            foreach (TreeNode FlatNode in Trv_Main.Nodes)
            {
                //Проход по комнатам внутри квартиры 
                foreach (TreeNode RoomNode in FlatNode.Nodes)
                {
                    //Если текущая комнта == комнате прибора - добавляем прибор
                    if (RoomNode.Text == appliance.Room)
                    {
                        //В узел комнаты добавляем прибор
                        TreeNode ApplianceNode = RoomNode.Nodes.Add("", $"{appliance.Name}. {appliance.Power} Вт", imageIndex, imageIndex);

                        //В tag узла прибора добавляем объект из аргументов
                        ApplianceNode.Tag = appliance;

                        //Комната была найдена и прибор добавен 
                        added = true;
                    }

                }//Проход по комнатам внутри квартиры 

            }//Проход по квартирам

            //Если комната не была найдена, тогда добавляем нужную комнату в квартиру и пишем в неё прибор
            if (added == false)
            {
                TreeNode CreatedRoom = Trv_Main.Nodes[0].Nodes.Add("",appliance.Room, 2, 2);

                //В узел комнаты добавляем прибор
                TreeNode ApplianceNode = CreatedRoom.Nodes.Add("", $"{appliance.Name}. {appliance.Power} Вт", imageIndex, imageIndex);

                //В tag узла прибора добавляем объект из аргументов
                ApplianceNode.Tag = appliance;
            }
        }

        //Удаление прибора по кнопке
        private void CM_Trv_Delete_Click(object sender, EventArgs e)
        {
            TreeNode selectedNode = Trv_Main.SelectedNode;
            Appliance appliance = (Appliance)selectedNode.Tag;

            //Если находися не на уровне приборов - уходим
            if (appliance == null)
                return;

            Del_From_Tree(appliance);

            //Удаляем из коллекции 
            _flatController.GetAppliances.Remove(appliance);

            //Перепривязываем GridView
            FillGridView(_flatController.GetAppliances,Dgv_Main);

        }

        //Добавление прибора 
        private void CM_Trv_AddItem_Click(object sender, EventArgs e)
        {
            TreeNode selectedNode = Trv_Main.SelectedNode;
            int selectedLevel = selectedNode.Level;

            //Если текущий уровень - не уровень квартиры
            if (selectedLevel > 0 || selectedLevel < 0)
                return;

            //передаём выделенный прибор в фомру 
            Appliance_form appliance_Form = new Appliance_form();

            if (appliance_Form.ShowDialog() != DialogResult.OK)
                return;

            //Получаем отредактированный объект
            Appliance CreatedAppliance = appliance_Form.appliance;

            //TODO: добавить проверку в flatController на пустоту 

            AddAppliance_Tree(CreatedAppliance);

            //Удаляем из коллекции 
            _flatController.GetAppliances.Add(CreatedAppliance);

            //Перепривязываем GridView
            FillGridView(_flatController.GetAppliances, Dgv_Main);


        }
        //Попадание на дерево 
        private void Trv_Main_Enter(object sender, EventArgs e)
        {
            Turn_Buttons_State();
        }

        //Уход из дерева
        private void Trv_Main_Leave(object sender, EventArgs e)
        {
            Turn_Buttons_State(true);
        }

        #endregion

        #region Обработчики для GridView
        //Изменение выделения на DataGridView
        private void Dvg_Main_SelectionChanged(object sender, EventArgs e)
        {
            DataGridViewRow dgvRow = Dgv_Main.CurrentRow;
            int RowInd = dgvRow.Index;

            //Если выделение некорректно - уходим
            if (RowInd > Dgv_Main.RowCount-1 || RowInd < 0)
                return;

            //Получаем инжекс выбранного прибора в основной коллекции
            int ind = _flatController.GetAppliances.IndexOf(dgvRow.Tag as Appliance);

            //Если индекс прибора некорректен - уходим
            if (ind < 0 || ind >= _flatController.Flat.Count){

                TbxAppliance.Clear();
                return;
            }


            DataGridViewSelectedRowCollection RowsCollection = Dgv_Main.SelectedRows;

            int CountRows = RowsCollection.Count;
            //Если неккорректное количество строк или передан несуществующий объект  - уходим
            if (CountRows <= 0 || CountRows > _flatController.Count)
                return;

            Turn_Buttons_State(true);

            //Проверяем состояние прибора и отключаем ненужные кнопки
            if (_flatController.Flat[ind].State) {

                BtnTurnOnOneStrip.Enabled = false;
                BtnTurnOFFOneStrip.Enabled = true;
            }
            else{

                BtnTurnOFFOneStrip.Enabled = false;
                BtnTurnOnOneStrip.Enabled = true;
            }


            //Если выделение множественное 
            if (CountRows > 1)
            {
                Turn_Buttons_State();

                //Включаем кнопки изменения состояния удаления
                BtnTurnOnOneStrip.Enabled =
                BtnTurnOFFOneStrip.Enabled = 
                DelAppCM.Enabled = 
                DeleteAppMNI.Enabled = 
                BtnDelAppToolStrip.Enabled = true;
            }

            //Выводим информацию в правый text box
            TbxAppliance.Text = $"{DateTime.Now:HH:mm:ss}\r\n{_flatController.Flat[ind]}";


        }

        //Включение/Отключение прибора пи нажатии на enter
        private void Dgv_Main_KeyDown(object sender, KeyEventArgs e)
        {
            Keys code = e.KeyCode;
            if (code != Keys.Space && code != Keys.Delete)
                return;

            switch (code)
            {
                //Включение/Выключение прибора
                case Keys.Space:

                    //Получаем обект, который выбран 
                    bool applianceState = (Dgv_Main.SelectedRows[0].Tag as Appliance).State;

                    if (applianceState)
                        TurnOffOne_Command(sender, new EventArgs());
                    else
                        TurnOnOne_Command(sender, new EventArgs());
                    break;

                //Удаление нескольких приборов
                case Keys.Delete:
                    DelMultiple();
                    break;

            }

        }

        #endregion

        //Удаление множества выделенных обектов 
        private void DelMultiple()
        {
            DataGridViewSelectedRowCollection RowsCollection = Dgv_Main.SelectedRows;

            int CountRows = RowsCollection.Count;
            //Если неккорректное количество строк или передан несуществующий объект  - уходим
            if (CountRows <= 0 || CountRows > _flatController.Count)
                return;


            Appliance appliance = new Appliance();
            //Проверка нахождения объектов приборов в тегах 
            foreach (DataGridViewRow item in RowsCollection)
            {
                //Если хотябы в одной строке в тег не записан прибор - сразу уходим из метода
                if ((item.Tag as Appliance) == null)
                    return;
                appliance = (item.Tag as Appliance);
                //Удаляем выделенный прибор
                _flatController.GetAppliances.Remove(appliance);
            }


            //Проверка на пустоту 
            IsColletionEmpty();

            //перезаписываем данные 
            FillGridView(_flatController.GetAppliances,Dgv_Main);
            FillTreeView();

            ChangeStatusString();
        }

        /*
         * PervSize: Dgv_Main.Size = 789; 513
         * New Size: Dgv_Main.Size = 789; 434
         * Prev Location: 8; 17 
         * New Location: 8; 85
         */

    }
}
    


