﻿namespace WF_Appliance.Forms
{
    partial class Appliance_form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.BtnAdd = new System.Windows.Forms.Button();
            this.BtnClose = new System.Windows.Forms.Button();
            this.LblName = new System.Windows.Forms.Label();
            this.LblPower = new System.Windows.Forms.Label();
            this.Gbx_ReadyObject = new System.Windows.Forms.GroupBox();
            this.Tbx_EndedObj = new System.Windows.Forms.TextBox();
            this.Cbx_Name = new System.Windows.Forms.ComboBox();
            this.Cbx_Power = new System.Windows.Forms.ComboBox();
            this.LblPrice = new System.Windows.Forms.Label();
            this.GbxAddEditTV = new System.Windows.Forms.GroupBox();
            this.Cbx_Rooms = new System.Windows.Forms.ComboBox();
            this.NudPrice = new System.Windows.Forms.NumericUpDown();
            this.GbxOnOff = new System.Windows.Forms.GroupBox();
            this.RbtnOff = new System.Windows.Forms.RadioButton();
            this.RbtnOn = new System.Windows.Forms.RadioButton();
            this.Lbl_Room = new System.Windows.Forms.Label();
            this.Gbx_ReadyObject.SuspendLayout();
            this.GbxAddEditTV.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.NudPrice)).BeginInit();
            this.GbxOnOff.SuspendLayout();
            this.SuspendLayout();
            // 
            // BtnAdd
            // 
            this.BtnAdd.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.BtnAdd.Font = new System.Drawing.Font("Consolas", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BtnAdd.Location = new System.Drawing.Point(52, 429);
            this.BtnAdd.Name = "BtnAdd";
            this.BtnAdd.Size = new System.Drawing.Size(295, 46);
            this.BtnAdd.TabIndex = 8;
            this.BtnAdd.Text = "Добавить";
            this.BtnAdd.UseVisualStyleBackColor = true;
            this.BtnAdd.Click += new System.EventHandler(this.BtnAdd_Click);
            // 
            // BtnClose
            // 
            this.BtnClose.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.BtnClose.Font = new System.Drawing.Font("Consolas", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BtnClose.Location = new System.Drawing.Point(422, 429);
            this.BtnClose.Name = "BtnClose";
            this.BtnClose.Size = new System.Drawing.Size(295, 46);
            this.BtnClose.TabIndex = 7;
            this.BtnClose.Text = "Закрыть";
            this.BtnClose.UseVisualStyleBackColor = true;
            // 
            // LblName
            // 
            this.LblName.Font = new System.Drawing.Font("Consolas", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblName.Location = new System.Drawing.Point(30, 57);
            this.LblName.Name = "LblName";
            this.LblName.Size = new System.Drawing.Size(259, 27);
            this.LblName.TabIndex = 5;
            this.LblName.Text = "Выберите прибор";
            this.LblName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // LblPower
            // 
            this.LblPower.Font = new System.Drawing.Font("Consolas", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblPower.Location = new System.Drawing.Point(35, 128);
            this.LblPower.Name = "LblPower";
            this.LblPower.Size = new System.Drawing.Size(259, 27);
            this.LblPower.TabIndex = 6;
            this.LblPower.Text = "Выберите мощность";
            this.LblPower.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Gbx_ReadyObject
            // 
            this.Gbx_ReadyObject.Controls.Add(this.Tbx_EndedObj);
            this.Gbx_ReadyObject.Location = new System.Drawing.Point(372, 95);
            this.Gbx_ReadyObject.Name = "Gbx_ReadyObject";
            this.Gbx_ReadyObject.Size = new System.Drawing.Size(330, 212);
            this.Gbx_ReadyObject.TabIndex = 16;
            this.Gbx_ReadyObject.TabStop = false;
            this.Gbx_ReadyObject.Text = "Сформированный обект";
            // 
            // Tbx_EndedObj
            // 
            this.Tbx_EndedObj.Location = new System.Drawing.Point(22, 30);
            this.Tbx_EndedObj.Multiline = true;
            this.Tbx_EndedObj.Name = "Tbx_EndedObj";
            this.Tbx_EndedObj.ReadOnly = true;
            this.Tbx_EndedObj.Size = new System.Drawing.Size(289, 166);
            this.Tbx_EndedObj.TabIndex = 0;
            // 
            // Cbx_Name
            // 
            this.Cbx_Name.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Cbx_Name.FormattingEnabled = true;
            this.Cbx_Name.Location = new System.Drawing.Point(35, 87);
            this.Cbx_Name.Name = "Cbx_Name";
            this.Cbx_Name.Size = new System.Drawing.Size(258, 23);
            this.Cbx_Name.TabIndex = 17;
            this.Cbx_Name.SelectedIndexChanged += new System.EventHandler(this.Cbx_IndexChanged);
            // 
            // Cbx_Power
            // 
            this.Cbx_Power.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Cbx_Power.FormattingEnabled = true;
            this.Cbx_Power.Location = new System.Drawing.Point(36, 158);
            this.Cbx_Power.Name = "Cbx_Power";
            this.Cbx_Power.Size = new System.Drawing.Size(258, 23);
            this.Cbx_Power.TabIndex = 18;
            this.Cbx_Power.SelectedIndexChanged += new System.EventHandler(this.Cbx_IndexChanged);
            // 
            // LblPrice
            // 
            this.LblPrice.Font = new System.Drawing.Font("Consolas", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblPrice.Location = new System.Drawing.Point(34, 202);
            this.LblPrice.Name = "LblPrice";
            this.LblPrice.Size = new System.Drawing.Size(259, 27);
            this.LblPrice.TabIndex = 22;
            this.LblPrice.Text = "Выберите стоимость";
            this.LblPrice.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // GbxAddEditTV
            // 
            this.GbxAddEditTV.Controls.Add(this.Cbx_Rooms);
            this.GbxAddEditTV.Controls.Add(this.NudPrice);
            this.GbxAddEditTV.Controls.Add(this.GbxOnOff);
            this.GbxAddEditTV.Controls.Add(this.LblPrice);
            this.GbxAddEditTV.Controls.Add(this.Cbx_Power);
            this.GbxAddEditTV.Controls.Add(this.Cbx_Name);
            this.GbxAddEditTV.Controls.Add(this.Gbx_ReadyObject);
            this.GbxAddEditTV.Controls.Add(this.LblPower);
            this.GbxAddEditTV.Controls.Add(this.LblName);
            this.GbxAddEditTV.Controls.Add(this.Lbl_Room);
            this.GbxAddEditTV.Location = new System.Drawing.Point(34, 12);
            this.GbxAddEditTV.Name = "GbxAddEditTV";
            this.GbxAddEditTV.Size = new System.Drawing.Size(732, 411);
            this.GbxAddEditTV.TabIndex = 0;
            this.GbxAddEditTV.TabStop = false;
            this.GbxAddEditTV.Text = "Добавление телевизора";
            // 
            // Cbx_Rooms
            // 
            this.Cbx_Rooms.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Cbx_Rooms.FormattingEnabled = true;
            this.Cbx_Rooms.Location = new System.Drawing.Point(36, 294);
            this.Cbx_Rooms.Name = "Cbx_Rooms";
            this.Cbx_Rooms.Size = new System.Drawing.Size(258, 23);
            this.Cbx_Rooms.TabIndex = 27;
            this.Cbx_Rooms.SelectedIndexChanged += new System.EventHandler(this.Cbx_IndexChanged);
            // 
            // NudPrice
            // 
            this.NudPrice.Location = new System.Drawing.Point(38, 232);
            this.NudPrice.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.NudPrice.Name = "NudPrice";
            this.NudPrice.Size = new System.Drawing.Size(256, 23);
            this.NudPrice.TabIndex = 25;
            this.NudPrice.ThousandsSeparator = true;
            this.NudPrice.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.NudPrice.ValueChanged += new System.EventHandler(this.Nud_ValueChanged);
            this.NudPrice.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Restrict_KeyDown);
            // 
            // GbxOnOff
            // 
            this.GbxOnOff.Controls.Add(this.RbtnOff);
            this.GbxOnOff.Controls.Add(this.RbtnOn);
            this.GbxOnOff.Location = new System.Drawing.Point(56, 331);
            this.GbxOnOff.Name = "GbxOnOff";
            this.GbxOnOff.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.GbxOnOff.Size = new System.Drawing.Size(207, 74);
            this.GbxOnOff.TabIndex = 24;
            this.GbxOnOff.TabStop = false;
            this.GbxOnOff.Text = "Состояние прибора";
            // 
            // RbtnOff
            // 
            this.RbtnOff.AutoSize = true;
            this.RbtnOff.Location = new System.Drawing.Point(117, 32);
            this.RbtnOff.Name = "RbtnOff";
            this.RbtnOff.Size = new System.Drawing.Size(81, 19);
            this.RbtnOff.TabIndex = 1;
            this.RbtnOff.TabStop = true;
            this.RbtnOff.Text = "Выключен";
            this.RbtnOff.UseVisualStyleBackColor = true;
            this.RbtnOff.Click += new System.EventHandler(this.TurnOff_Command);
            // 
            // RbtnOn
            // 
            this.RbtnOn.AutoSize = true;
            this.RbtnOn.Location = new System.Drawing.Point(6, 32);
            this.RbtnOn.Name = "RbtnOn";
            this.RbtnOn.Size = new System.Drawing.Size(74, 19);
            this.RbtnOn.TabIndex = 0;
            this.RbtnOn.TabStop = true;
            this.RbtnOn.Text = "Включен";
            this.RbtnOn.UseVisualStyleBackColor = true;
            this.RbtnOn.Click += new System.EventHandler(this.TurnOn_Command);
            // 
            // Lbl_Room
            // 
            this.Lbl_Room.Font = new System.Drawing.Font("Consolas", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Lbl_Room.Location = new System.Drawing.Point(35, 264);
            this.Lbl_Room.Name = "Lbl_Room";
            this.Lbl_Room.Size = new System.Drawing.Size(259, 27);
            this.Lbl_Room.TabIndex = 26;
            this.Lbl_Room.Text = "Выберите комнату";
            this.Lbl_Room.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Appliance_form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(799, 487);
            this.Controls.Add(this.GbxAddEditTV);
            this.Controls.Add(this.BtnAdd);
            this.Controls.Add(this.BtnClose);
            this.Font = new System.Drawing.Font("Consolas", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Name = "Appliance_form";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Добавление телевизора";
            this.Gbx_ReadyObject.ResumeLayout(false);
            this.Gbx_ReadyObject.PerformLayout();
            this.GbxAddEditTV.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.NudPrice)).EndInit();
            this.GbxOnOff.ResumeLayout(false);
            this.GbxOnOff.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button BtnAdd;
        private System.Windows.Forms.Button BtnClose;
        private System.Windows.Forms.GroupBox GbxAddEditTV;
        private System.Windows.Forms.Label LblPrice;
        private System.Windows.Forms.ComboBox Cbx_Power;
        private System.Windows.Forms.ComboBox Cbx_Name;
        private System.Windows.Forms.GroupBox Gbx_ReadyObject;
        private System.Windows.Forms.TextBox Tbx_EndedObj;
        private System.Windows.Forms.Label LblPower;
        private System.Windows.Forms.Label LblName;
        private System.Windows.Forms.GroupBox GbxOnOff;
        private System.Windows.Forms.RadioButton RbtnOff;
        private System.Windows.Forms.RadioButton RbtnOn;
        private System.Windows.Forms.NumericUpDown NudPrice;
        private System.Windows.Forms.ComboBox Cbx_Rooms;
        private System.Windows.Forms.Label Lbl_Room;
    }
}