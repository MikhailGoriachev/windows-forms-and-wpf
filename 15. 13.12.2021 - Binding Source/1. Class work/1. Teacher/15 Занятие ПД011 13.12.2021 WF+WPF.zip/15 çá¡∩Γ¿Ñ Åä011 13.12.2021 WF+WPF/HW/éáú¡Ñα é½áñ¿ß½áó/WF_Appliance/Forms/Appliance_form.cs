﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WF_Appliance.Controller;
using WF_Appliance.Models;
using WF_Appliance.Utilities;

namespace WF_Appliance.Forms
{
    public partial class Appliance_form : Form
    {

        //Свойство объекта 
        private Appliance _appliance = new Appliance();

        public Appliance appliance
        {
            get => _appliance;
        }

        //Игнорирование комнаты
        bool _IgnoreRoom = false;

        //Связаны ли данные 
        bool _Bound = false;
       
        //Конструктор для формы создания прибора
        public Appliance_form()
        {
            InitializeComponent();

            #region Связывание данных

            //Привязываем данные в comboboxes
            List<object> tempList = new List<object>(Utils.GetUniqueNames());
            BindData(tempList, Cbx_Name);
           

            //Добавляем мощности
            tempList.Clear();
            foreach (int item in Utils.Powers)
            {
                tempList.Add(item);
            }
            BindData(tempList, Cbx_Power);

            //Добавляем комнаты 
            tempList.Clear();
            tempList.AddRange(Utils.GetUniqueRooms());
            BindData(tempList, Cbx_Rooms);

            //Добавляем значение
            NudPrice.Value = Utils.Prices[Utils.Random.Next(0, Utils.Prices.Length)];

            //Задаём состояние 
            _appliance.State = Utils.Random.Next(1, 100) % 3 == 0 ? true : false;

            #endregion

            if (_appliance.State)
                RbtnOn.Checked = true;
            else
                RbtnOff.Checked = true;

            _Bound = true;

            //Выводим готовый объект в TextBox 
            Tbx_EndedObj.Text = $"Итоговый обект:\r\n{_appliance}";
        }

        //C_TOR с параметрами для редактирования прибора
        public Appliance_form(Appliance appliance,List<string> Rooms,bool IgnoreRooms = false)
        {
            InitializeComponent();

            _IgnoreRoom = IgnoreRooms;

            //Если игнорируем комнаты 
            if (IgnoreRooms)
            {
                //GbxOnOff.Location = new Point(63, 264); Curr:56; 331
                //GbxAddEditTV.Size = new Size(732, 344); Curr: 732; 411
                //BtnAdd.Location = new Point(52, 372); Curr:52; 429
                //BtnClose.Location = new Point(422, 372); Curr: 422; 429
                //Appliance_form.Size = 815,466 ; Curr: 815; 526

                Lbl_Room.Visible = 
                Cbx_Rooms.Visible = false;

                //Меняем положение элементов и размер формы, чтобы скрыть отсутствующие поля
                GbxOnOff.Location = new Point(63, 264);
                GbxAddEditTV.Size = new Size(732, 344);
                BtnAdd.Location = new Point(52, 372);
                BtnClose.Location = new Point(422, 372);
                this.Size = new Size(815, 466);
            }

            //Привязываем данные в comboboxes
            List<object> tempList = new List<object>(Utils.GetUniqueNames());
            BindData(tempList, Cbx_Name);

            //Добавляем мощности
            tempList.Clear();
            foreach (int item in Utils.Powers)
            {
                tempList.Add(item);
            }

            BindData(tempList, Cbx_Power);

            this.Text = "Редактирование обекта";

            _appliance.Name = appliance.Name;
            _appliance.Power = appliance.Power;
            _appliance.Price = appliance.Price;
            _appliance.State = appliance.State;
            _appliance.Room = appliance.Room;

            //Задаём значения в CBX исходя из текущего состояния обекта 
            Cbx_Name.SelectedIndex = Cbx_Name.Items.IndexOf(_appliance.Name);

            Cbx_Power.Items.IndexOf(_appliance.Power);

            Cbx_Power.SelectedIndex = Cbx_Power.Items.IndexOf(_appliance.Power);

            //Если комнаты не игнорируются - производим запись в комбобокс
            if (_IgnoreRoom == false)
            {
                //Добавляем комнаты 
                tempList.Clear();
                tempList.AddRange(Rooms);
                BindData(tempList, Cbx_Rooms);
                //Выбор элемента combox соответствующего полю редактируемого прибора
                Cbx_Rooms.SelectedIndex = Cbx_Rooms.Items.IndexOf(_appliance.Room);
            }

            BtnAdd.Text = "Сохранить";
            //Изменяем состояние обекта

            if (_appliance.State)
                RbtnOn.Checked = true;
            else
                RbtnOff.Checked = true;

            //Задаём существующее значение в NudPrice
            NudPrice.Value = (decimal)_appliance.Price;

            _Bound = true;

            //Выводим готовый объект в TextBox 
            Tbx_EndedObj.Text = $"Итоговый обект:\r\n{_appliance}";
            Tbx_EndedObj.Select(0,0);

        }

        //Привязка данных к конкретному комбобоксу
        void BindData(List<object> list,ComboBox cbx)
        {
            cbx.DataSource = null;
            cbx.DataSource = list;

        }


        int iters = 0;
        private void Cbx_IndexChanged(object sender, EventArgs e)
        {
            if (!_Bound)
                return;

            ComboBox TempCbx = (ComboBox)sender;


            //Выбор получающего поля
            if (TempCbx.Equals(Cbx_Name))
                _appliance.Name = TempCbx.SelectedItem.ToString();
            else if (TempCbx.Equals(Cbx_Power))
                _appliance.Power = int.Parse(TempCbx.SelectedItem.ToString());
            else if (TempCbx.Equals(Cbx_Rooms) && _IgnoreRoom == false)
                _appliance.Room = TempCbx.SelectedItem.ToString();


            //Выводим готовый объект в TextBox 
            Tbx_EndedObj.Text = $"Итоговый обект:\r\n{_appliance}";
        }

        private void Nud_ValueChanged(object sender, EventArgs e)
        {
            _appliance.Price = (int)NudPrice.Value;

            //Выводим готовый объект в TextBox 
            Tbx_EndedObj.Text = $"Итоговый обект:\r\n{_appliance}";
        }

        // Запрет на ввод знака '-'
        private void Restrict_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.OemMinus || e.KeyData == Keys.Subtract)
                //SendKeys.Flush();
                e.SuppressKeyPress = true;
        }

        private void TurnOn_Command(object sender, EventArgs e)
        {
            _appliance.State = true;

            //Выводим готовый объект в TextBox 
            Tbx_EndedObj.Text = $"Итоговый обект:\r\n{_appliance}";
        }

        private void TurnOff_Command(object sender, EventArgs e)
        {

            _appliance.State = false;

            //Выводим готовый объект в TextBox 
            Tbx_EndedObj.Text = $"Итоговый обект:\r\n{_appliance}";
        }

        //Нажатие завершающей кнопки
        private void BtnAdd_Click(object sender, EventArgs e)
        {/*
            _appliance.Name = Cbx_Name.SelectedItem.ToString();
            _appliance.Power = int.Parse(Cbx_Power.SelectedItem.ToString());

            if(IgnorRoom == false)
                _appliance.Room = Cbx_Rooms.SelectedItem.ToString();

            _appliance.Price = (int)NudPrice.Value;
            _appliance.State = RbtnOn.Checked;*/
        }
    }
}
