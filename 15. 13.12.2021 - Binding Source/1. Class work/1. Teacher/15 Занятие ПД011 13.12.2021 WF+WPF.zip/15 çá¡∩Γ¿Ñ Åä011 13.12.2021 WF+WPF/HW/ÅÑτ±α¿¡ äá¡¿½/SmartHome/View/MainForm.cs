﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SmartHome.Controllers;
using SmartHome.Helpers;
using SmartHome.Models;
using System.IO;

namespace SmartHome.View
{
    public partial class MainForm : Form
    {
        private AppartmentController _flatcontroller;

        public MainForm(): this(new AppartmentController()) { } // MainForm
        public MainForm(AppartmentController appcontroller)
        {
            InitializeComponent();

            _flatcontroller = appcontroller;

            // если нет папки, то создать ее
            if(!File.Exists(@"App_data\" + _flatcontroller.Filename))
            {
                Directory.CreateDirectory(@"App_Data");
                appcontroller.Flat.Serialization(@"App_Data" + _flatcontroller.Filename);
            }
            
               

            // заполнение таблицы GridView данными
            Drgv();

            //запись коллекции объектов в TreeView
            WriteToTreeView(TrvAppliances, _flatcontroller);
            TrvAppliances.ExpandAll();
            StlMain.Text = $"Коллекция приборов сформирована. Текущее количество приборов : {_flatcontroller.Flat.Count}";

            
        }// MainForm

        //заполнение данными GridView
        private void Drgv ()
        {
            DgvMain.RowCount = _flatcontroller.Flat.Count;  

            for(int i =0; i<_flatcontroller.Flat.Count; i++)
            {
                DgvMain[0, i].Value = _flatcontroller.Flat[i].Name;
                DgvMain[1, i].Value = _flatcontroller.Flat[i].Power;
                DgvMain[2, i].Value = _flatcontroller.Flat[i].Price;
                DgvMain[3, i].Value = _flatcontroller.Flat[i].State;
                DgvMain[4, i].Value = _flatcontroller.Flat[i].Room;
            }
        }

        private void tabPage1_Click(object sender, EventArgs e)
        {

        }

        private void Exit_Command(object sender, EventArgs e) => Application.Exit();

        private void About_Command(object sender, EventArgs e)
        {
            FormAbout fromabout = new FormAbout();
            fromabout.ShowDialog();
        }

        private void WriteToTreeView(TreeView treeView, AppartmentController appcontroller)
        {
            treeView.Nodes.Clear();

            treeView.Nodes.Add(appcontroller.Flat.FlatName);

            int i = 0;
            foreach(var room in appcontroller.GetRooms())
            {
                // добавление узла комнаты
                treeView.Nodes[0].Nodes.Add(room);

                int j = 0;
                foreach(var appliance in appcontroller.Flat.Appliances.FindAll(x => x.Room== room))
                {
                    // добавление узла прибора
                    treeView.Nodes[0].Nodes[i].Nodes.Add(appliance.Name);
                    treeView.Nodes[0].Nodes[i].Nodes[j].ImageIndex =
                        treeView.Nodes[0].Nodes[i].Nodes[j].SelectedImageIndex = 2;
                    j++;
                } // foreach appliance
                i++;
            }// foreach room

        }// WriteToTreeView

        private void Save_Command(object sender, EventArgs e)
        {
            _flatcontroller.Flat.Serialization(@"App_Data\" + _flatcontroller.Filename);
        }

        private void SaveAs_Command(object sender, EventArgs e)
        {
            SfdMain.Title = "Сохранить файл как";
            SfdMain.InitialDirectory = Path.GetDirectoryName(_flatcontroller.Filename);
            SfdMain.Filter = "Файл JSon (*.json) | *.json";

            if(SfdMain.ShowDialog() == DialogResult.OK)
            {
                _flatcontroller.Flat.Serialization(SfdMain.FileName);
            }
        }
        // начальное формироание данных электрооборудования квартиры
        private void Generate_Command(object sender, EventArgs e)
        {
            _flatcontroller.Flat.GenerateCollection(Utils.GetRandom(6, 8));

            StlMain.Text = $"Коллекция электроприборов сформирована. Текущее количество приборов : {_flatcontroller.Flat.Count}";
            WriteToTreeView(TrvAppliances, _flatcontroller);
            TrvAppliances.ExpandAll();

            //сериализаци данных 
            Save_Command(sender, e);

            //делаем главную страницу текущей
            TbcMain.SelectedTab = TbpGeneral;
        }

        // изменения сведения о квартире 
        private void FileEdit_Command(object sender, EventArgs e)
        {
            FlatForm flatForm = new FlatForm(_flatcontroller.Flat.Address, _flatcontroller.Flat.FlatName);
        }
    }
}
