﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SmartHome.Models;

namespace SmartHome.Controllers
{
    public class AppartmentController
    {
        // объект для обработки
        private Appartment _flat; 

        public Appartment Flat
        {
            get => _flat;
            private set => _flat = value;
        }

        // имя файла для сериализация в формате JSON
        private string _filename; 

        public string Filename
        {
            get => _filename;
            set => _filename = value; 
        }

        // конструкторы 
        public AppartmentController(): this(new Appartment(), "flat.json") { }

        public AppartmentController (Appartment flat, string filename)
        {
            _flat = flat;
            _filename = filename;
        }

        // запрос на упорядочивание коллекции по названию 
        public List<Appliance> OrderByName() =>
            Flat.OrderBy((t1, t2) => t1.Name.CompareTo(t2.Name));

        // Запрос на упорядочивание коллеккции по состоянию 
        public List<Appliance> OrderByState() =>
            Flat.OrderBy((t1, t2) => t1.State.CompareTo(t2.State));

        //Запрос на упорядочивание коллекции по мощности 

        public List<Appliance> OrderByPower() =>
            Flat.OrderBy((t1, t2) => t1.Power.CompareTo(t2.Power));

        //Запрос коллекции по убыванию цен 
        public List<Appliance> OrderByPrice() =>
            Flat.OrderBy((t1, t2) => t1.Price.CompareTo(t2.Price));

        //Запрос на выборку в коллекцию электроприборов, с заданным названием
        public List<Appliance> SelectName(string name) =>
            _flat.ChooseAppliance(t => t.Name == name);

        //Запрос на выборку в коллекцию электроприборов, заданного состояния
        public List<Appliance> SelectState(bool state) =>
            _flat.ChooseAppliance(t => t.State == state);

        //список название электроприборов из коллекции
        public List<string> GetNames()
        {
            HashSet<string> names = new HashSet<string>(); 

            foreach(var t in _flat.Appliances)
            {
                names.Add(t.Name);
            }

            return names.ToList();

           
        }

        // список состояний электроприборов из коллекции
        public List<bool> GetStates()
        {
            HashSet<bool> states = new HashSet<bool>();

            foreach(var t in _flat.Appliances)
            {
                states.Add(t.State);
            }

            return states.ToList();
        }

        //список названия комнат из коллекции 
        public List<string> GetRooms()
        {
            Dictionary<string, int> rooms = new Dictionary<string, int>();

            _flat.Appliances.ForEach(t => rooms[t.Room] = 0);

            return rooms.Keys.ToList();
        }

        public List<Appliance> OrderBy(Comparison<Appliance> comparedBy) =>
            Flat.OrderBy(comparedBy); 

    }
}
