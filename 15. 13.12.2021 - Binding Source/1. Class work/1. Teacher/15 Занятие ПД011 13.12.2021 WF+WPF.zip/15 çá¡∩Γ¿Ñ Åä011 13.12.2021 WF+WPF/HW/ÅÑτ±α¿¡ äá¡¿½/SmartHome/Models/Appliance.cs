﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using SmartHome.Helpers;

namespace SmartHome.Models
{
    // Класс, описывающий электроприбор (название, мощность, цена
    // и состояние прибора: включен/выключен)
    [DataContract]
    public class Appliance
    {
        
        //название прибора
        private string _name; 
        [DataMember]
        public string Name
        {
            get => _name;
            set { if (string.IsNullOrEmpty(value))
                    throw new ArgumentNullException("Пустая строка");
                _name = value;
                    
                                  }
        }

        //мощность электроприбора 
        private int _power; 
        [DataMember]
        public int Power
        {
            get => _power; 
            set
            {
                if (value < 0)
                    throw new ArgumentOutOfRangeException("Недопустимое значение для мощности");
                _power = value;
            }
        }

        //цена прибора 
        private int _price;
        [DataMember]
        public int Price
        {
            get => _price;
            set
            {
                if (value < 0) 
                    throw new ArgumentOutOfRangeException("Недопустимый параметр для цены");
                _price = value; 
            }
        }

        //состояние прибора 
        private bool _state; 
        [DataMember]
        public bool State
        {
            get => _state;
            set => _state = value; 
        }

        // название комнаты, в которой прибор 
        private string _room;
        
        public string Room
        {
            get => _room;
            set
            {
                if (string.IsNullOrEmpty(value)) 
                    throw new ArgumentNullException("Пустая строка");
                _room = value;
            }
        }

        // конструкторы
        Appliance () :this( "самовар", 350, 3400, false) { }
        Appliance(string name, int power, int price, bool state)
        {
            Name = name;
            Power = power;
            Price = price;
            State = state;
        }

        public int CompateTo(Appliance appliance) => _price.CompareTo(appliance._price);

        // строковое представление объекта 
        public override string ToString() => 
            $" {_name} : {_power} Вт, {_price} руб, {(_state ? "Включен":"Выключен" )} ";

        // табличная строка
        public string ToTableRow() =>
            $"{_name,-22} | {_power,12:n2} | {_price,10:n2} | {(_state ? "Включен" : "Выключен"), -10}";

        // Шапка таблицы, статическое свойство
        public static string Header =>
            $"┌────────────────────────┬──────────────┬────────────┬────────────┐\r\n" +
            $"│ Название прибора       │ Мощность, Вт │ Цена, руб. │ Состояние  │\r\n" +
            $"├────────────────────────┼──────────────┼────────────┼────────────┤\r\n";

        // Подвал таблицы, статическое свойство
        public static string Footer =>
            "└────────────────────────┴──────────────┴────────────┴────────────┘";

        // фабричный метод создания приборов 
        public static Appliance Generate()
        {
            (string name, int power, int price, string room)[] data =
            {
                ("кофемолка", 340, 1200, "кухня"), ("чайник", 800, 4000, "спальня"), ("мясорубка", 900, 3400, "прихожая"),
                ("миксер", 450, 1500,"гостинная"), ("хлебопечка", 560, 5600, "кухня"), ("светильник", 740, 6453, "зал"),
                ("пульт", 20, 340, "зал"), ("пылесос", 880, 7000, "коридор"), ("стиральная машина", 1200, 25000, "ванная"),
                ("блендер", 560, 3200, "кухня")
            };

            int index = Utils.Random.Next(0, data.Length);
            return new Appliance
            {
                _name = data[index].name,
                _power = data[index].power,
                _price = data[index].price,
                _room = data[index].room,
                // состояние прибора
                _state = Utils.GetRandom(0, 1) == 1
            };
        }



    }
}
