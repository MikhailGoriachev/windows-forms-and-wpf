﻿
namespace SmartHome.View
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.MnsMain = new System.Windows.Forms.MenuStrip();
            this.файлToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.открытьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.сохранитьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.сохранитьКакToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.выходToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.сведенияОКвартиреToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.FlatNew = new System.Windows.Forms.ToolStripMenuItem();
            this.FlatEdit = new System.Windows.Forms.ToolStripMenuItem();
            this.электроприборыToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.добавитьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.изменитьToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.выключитьВключитьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.включитьВсеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.выключитьВсеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.удалитьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.сортировкаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.поНазваниюToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.поСостояниюToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.поМощностиToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.поУбываниюЦеныToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.выборкаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.сЗаданнымНазваниемToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.сЗаданнымСостояниемToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.справкаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.оПрограммеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.TbsMain = new System.Windows.Forms.ToolStrip();
            this.toolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton2 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton3 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton4 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton5 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton6 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton7 = new System.Windows.Forms.ToolStripButton();
            this.toolStripDropDownButton1 = new System.Windows.Forms.ToolStripDropDownButton();
            this.поНазваниюToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.поСостояниюToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.поМощьностиToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.поУбываниюЦенToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripDropDownButton2 = new System.Windows.Forms.ToolStripDropDownButton();
            this.сЗаданнымНазваниемToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.сЗаданнымСостояниемToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripButton8 = new System.Windows.Forms.ToolStripButton();
            this.LblAddress = new System.Windows.Forms.Label();
            this.TbcMain = new System.Windows.Forms.TabControl();
            this.TbpGeneral = new System.Windows.Forms.TabPage();
            this.DgvMain = new System.Windows.Forms.DataGridView();
            this.name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.power = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Price = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.state = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.room = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TrvAppliances = new System.Windows.Forms.TreeView();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.StlMain = new System.Windows.Forms.ToolStrip();
            this.SfdMain = new System.Windows.Forms.SaveFileDialog();
            this.MnsMain.SuspendLayout();
            this.TbsMain.SuspendLayout();
            this.TbcMain.SuspendLayout();
            this.TbpGeneral.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DgvMain)).BeginInit();
            this.SuspendLayout();
            // 
            // MnsMain
            // 
            this.MnsMain.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.MnsMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.файлToolStripMenuItem,
            this.сведенияОКвартиреToolStripMenuItem,
            this.электроприборыToolStripMenuItem,
            this.сортировкаToolStripMenuItem,
            this.выборкаToolStripMenuItem,
            this.справкаToolStripMenuItem});
            this.MnsMain.Location = new System.Drawing.Point(0, 0);
            this.MnsMain.Name = "MnsMain";
            this.MnsMain.Size = new System.Drawing.Size(1394, 46);
            this.MnsMain.TabIndex = 0;
            this.MnsMain.Text = "menuStrip1";
            // 
            // файлToolStripMenuItem
            // 
            this.файлToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.открытьToolStripMenuItem,
            this.сохранитьToolStripMenuItem,
            this.сохранитьКакToolStripMenuItem,
            this.toolStripSeparator1,
            this.выходToolStripMenuItem});
            this.файлToolStripMenuItem.Font = new System.Drawing.Font("Consolas", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.файлToolStripMenuItem.Name = "файлToolStripMenuItem";
            this.файлToolStripMenuItem.Size = new System.Drawing.Size(106, 42);
            this.файлToolStripMenuItem.Text = "Файл ";
            // 
            // открытьToolStripMenuItem
            // 
            this.открытьToolStripMenuItem.Image = global::SmartHome.Properties.Resources.folder;
            this.открытьToolStripMenuItem.Name = "открытьToolStripMenuItem";
            this.открытьToolStripMenuItem.Size = new System.Drawing.Size(315, 42);
            this.открытьToolStripMenuItem.Text = "Открыть";
            // 
            // сохранитьToolStripMenuItem
            // 
            this.сохранитьToolStripMenuItem.Name = "сохранитьToolStripMenuItem";
            this.сохранитьToolStripMenuItem.Size = new System.Drawing.Size(315, 42);
            this.сохранитьToolStripMenuItem.Text = "Сохранить";
            this.сохранитьToolStripMenuItem.Click += new System.EventHandler(this.Save_Command);
            // 
            // сохранитьКакToolStripMenuItem
            // 
            this.сохранитьКакToolStripMenuItem.Image = global::SmartHome.Properties.Resources.save_as;
            this.сохранитьКакToolStripMenuItem.Name = "сохранитьКакToolStripMenuItem";
            this.сохранитьКакToolStripMenuItem.Size = new System.Drawing.Size(315, 42);
            this.сохранитьКакToolStripMenuItem.Text = "Сохранить как";
            this.сохранитьКакToolStripMenuItem.Click += new System.EventHandler(this.SaveAs_Command);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(312, 6);
            // 
            // выходToolStripMenuItem
            // 
            this.выходToolStripMenuItem.Image = global::SmartHome.Properties.Resources.exit;
            this.выходToolStripMenuItem.Name = "выходToolStripMenuItem";
            this.выходToolStripMenuItem.Size = new System.Drawing.Size(315, 42);
            this.выходToolStripMenuItem.Text = "Выход";
            this.выходToolStripMenuItem.Click += new System.EventHandler(this.Exit_Command);
            // 
            // сведенияОКвартиреToolStripMenuItem
            // 
            this.сведенияОКвартиреToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.FlatNew,
            this.FlatEdit});
            this.сведенияОКвартиреToolStripMenuItem.Font = new System.Drawing.Font("Consolas", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.сведенияОКвартиреToolStripMenuItem.Name = "сведенияОКвартиреToolStripMenuItem";
            this.сведенияОКвартиреToolStripMenuItem.Size = new System.Drawing.Size(316, 42);
            this.сведенияОКвартиреToolStripMenuItem.Text = "Сведения о квартире";
            // 
            // FlatNew
            // 
            this.FlatNew.Image = global::SmartHome.Properties.Resources.create;
            this.FlatNew.Name = "FlatNew";
            this.FlatNew.Size = new System.Drawing.Size(270, 42);
            this.FlatNew.Text = "Новая";
            this.FlatNew.Click += new System.EventHandler(this.Generate_Command);
            // 
            // FlatEdit
            // 
            this.FlatEdit.Image = global::SmartHome.Properties.Resources.edit;
            this.FlatEdit.Name = "FlatEdit";
            this.FlatEdit.Size = new System.Drawing.Size(270, 42);
            this.FlatEdit.Text = "Изменить";
            this.FlatEdit.Click += new System.EventHandler(this.FileEdit_Command);
            // 
            // электроприборыToolStripMenuItem
            // 
            this.электроприборыToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.добавитьToolStripMenuItem,
            this.изменитьToolStripMenuItem1,
            this.toolStripSeparator2,
            this.выключитьВключитьToolStripMenuItem,
            this.включитьВсеToolStripMenuItem,
            this.выключитьВсеToolStripMenuItem,
            this.toolStripSeparator3,
            this.удалитьToolStripMenuItem});
            this.электроприборыToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.электроприборыToolStripMenuItem.Name = "электроприборыToolStripMenuItem";
            this.электроприборыToolStripMenuItem.Size = new System.Drawing.Size(261, 42);
            this.электроприборыToolStripMenuItem.Text = "Электроприборы ";
            // 
            // добавитьToolStripMenuItem
            // 
            this.добавитьToolStripMenuItem.Image = global::SmartHome.Properties.Resources.add;
            this.добавитьToolStripMenuItem.Name = "добавитьToolStripMenuItem";
            this.добавитьToolStripMenuItem.Size = new System.Drawing.Size(405, 46);
            this.добавитьToolStripMenuItem.Text = "Добавить";
            // 
            // изменитьToolStripMenuItem1
            // 
            this.изменитьToolStripMenuItem1.Image = global::SmartHome.Properties.Resources.edit1;
            this.изменитьToolStripMenuItem1.Name = "изменитьToolStripMenuItem1";
            this.изменитьToolStripMenuItem1.Size = new System.Drawing.Size(405, 46);
            this.изменитьToolStripMenuItem1.Text = "Изменить";
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(402, 6);
            // 
            // выключитьВключитьToolStripMenuItem
            // 
            this.выключитьВключитьToolStripMenuItem.Image = global::SmartHome.Properties.Resources.turnon;
            this.выключитьВключитьToolStripMenuItem.Name = "выключитьВключитьToolStripMenuItem";
            this.выключитьВключитьToolStripMenuItem.Size = new System.Drawing.Size(405, 46);
            this.выключитьВключитьToolStripMenuItem.Text = "Выключить/Включить";
            // 
            // включитьВсеToolStripMenuItem
            // 
            this.включитьВсеToolStripMenuItem.Image = global::SmartHome.Properties.Resources.turnon1;
            this.включитьВсеToolStripMenuItem.Name = "включитьВсеToolStripMenuItem";
            this.включитьВсеToolStripMenuItem.Size = new System.Drawing.Size(405, 46);
            this.включитьВсеToolStripMenuItem.Text = "Включить все";
            // 
            // выключитьВсеToolStripMenuItem
            // 
            this.выключитьВсеToolStripMenuItem.Image = global::SmartHome.Properties.Resources.turnoff;
            this.выключитьВсеToolStripMenuItem.Name = "выключитьВсеToolStripMenuItem";
            this.выключитьВсеToolStripMenuItem.Size = new System.Drawing.Size(405, 46);
            this.выключитьВсеToolStripMenuItem.Text = "Выключить все";
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(402, 6);
            // 
            // удалитьToolStripMenuItem
            // 
            this.удалитьToolStripMenuItem.Image = global::SmartHome.Properties.Resources.remove;
            this.удалитьToolStripMenuItem.Name = "удалитьToolStripMenuItem";
            this.удалитьToolStripMenuItem.Size = new System.Drawing.Size(405, 46);
            this.удалитьToolStripMenuItem.Text = "Удалить";
            // 
            // сортировкаToolStripMenuItem
            // 
            this.сортировкаToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.поНазваниюToolStripMenuItem,
            this.поСостояниюToolStripMenuItem,
            this.поМощностиToolStripMenuItem,
            this.поУбываниюЦеныToolStripMenuItem});
            this.сортировкаToolStripMenuItem.Font = new System.Drawing.Font("Consolas", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.сортировкаToolStripMenuItem.Name = "сортировкаToolStripMenuItem";
            this.сортировкаToolStripMenuItem.Size = new System.Drawing.Size(181, 42);
            this.сортировкаToolStripMenuItem.Text = "Сортировка";
            // 
            // поНазваниюToolStripMenuItem
            // 
            this.поНазваниюToolStripMenuItem.Image = global::SmartHome.Properties.Resources.name;
            this.поНазваниюToolStripMenuItem.Name = "поНазваниюToolStripMenuItem";
            this.поНазваниюToolStripMenuItem.Size = new System.Drawing.Size(360, 42);
            this.поНазваниюToolStripMenuItem.Text = "По названию";
            // 
            // поСостояниюToolStripMenuItem
            // 
            this.поСостояниюToolStripMenuItem.Image = global::SmartHome.Properties.Resources.state;
            this.поСостояниюToolStripMenuItem.Name = "поСостояниюToolStripMenuItem";
            this.поСостояниюToolStripMenuItem.Size = new System.Drawing.Size(360, 42);
            this.поСостояниюToolStripMenuItem.Text = "По состоянию";
            // 
            // поМощностиToolStripMenuItem
            // 
            this.поМощностиToolStripMenuItem.Image = global::SmartHome.Properties.Resources.power;
            this.поМощностиToolStripMenuItem.Name = "поМощностиToolStripMenuItem";
            this.поМощностиToolStripMenuItem.Size = new System.Drawing.Size(360, 42);
            this.поМощностиToolStripMenuItem.Text = "По мощности";
            // 
            // поУбываниюЦеныToolStripMenuItem
            // 
            this.поУбываниюЦеныToolStripMenuItem.Image = global::SmartHome.Properties.Resources.low_price;
            this.поУбываниюЦеныToolStripMenuItem.Name = "поУбываниюЦеныToolStripMenuItem";
            this.поУбываниюЦеныToolStripMenuItem.Size = new System.Drawing.Size(360, 42);
            this.поУбываниюЦеныToolStripMenuItem.Text = "По убыванию цены";
            // 
            // выборкаToolStripMenuItem
            // 
            this.выборкаToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.сЗаданнымНазваниемToolStripMenuItem,
            this.сЗаданнымСостояниемToolStripMenuItem});
            this.выборкаToolStripMenuItem.Font = new System.Drawing.Font("Consolas", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.выборкаToolStripMenuItem.Name = "выборкаToolStripMenuItem";
            this.выборкаToolStripMenuItem.Size = new System.Drawing.Size(136, 42);
            this.выборкаToolStripMenuItem.Text = "Выборка";
            // 
            // сЗаданнымНазваниемToolStripMenuItem
            // 
            this.сЗаданнымНазваниемToolStripMenuItem.Image = global::SmartHome.Properties.Resources.name1;
            this.сЗаданнымНазваниемToolStripMenuItem.Name = "сЗаданнымНазваниемToolStripMenuItem";
            this.сЗаданнымНазваниемToolStripMenuItem.Size = new System.Drawing.Size(435, 42);
            this.сЗаданнымНазваниемToolStripMenuItem.Text = "С заданным названием";
            // 
            // сЗаданнымСостояниемToolStripMenuItem
            // 
            this.сЗаданнымСостояниемToolStripMenuItem.Image = global::SmartHome.Properties.Resources.state1;
            this.сЗаданнымСостояниемToolStripMenuItem.Name = "сЗаданнымСостояниемToolStripMenuItem";
            this.сЗаданнымСостояниемToolStripMenuItem.Size = new System.Drawing.Size(435, 42);
            this.сЗаданнымСостояниемToolStripMenuItem.Text = "С заданным состоянием";
            // 
            // справкаToolStripMenuItem
            // 
            this.справкаToolStripMenuItem.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.справкаToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.оПрограммеToolStripMenuItem});
            this.справкаToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.справкаToolStripMenuItem.Name = "справкаToolStripMenuItem";
            this.справкаToolStripMenuItem.Size = new System.Drawing.Size(147, 42);
            this.справкаToolStripMenuItem.Text = "Справка ";
            // 
            // оПрограммеToolStripMenuItem
            // 
            this.оПрограммеToolStripMenuItem.Image = global::SmartHome.Properties.Resources.question;
            this.оПрограммеToolStripMenuItem.Name = "оПрограммеToolStripMenuItem";
            this.оПрограммеToolStripMenuItem.Size = new System.Drawing.Size(297, 46);
            this.оПрограммеToolStripMenuItem.Text = "О программе";
            this.оПрограммеToolStripMenuItem.Click += new System.EventHandler(this.About_Command);
            // 
            // TbsMain
            // 
            this.TbsMain.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.TbsMain.ImageScalingSize = new System.Drawing.Size(45, 45);
            this.TbsMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButton1,
            this.toolStripButton2,
            this.toolStripButton3,
            this.toolStripButton4,
            this.toolStripButton5,
            this.toolStripButton6,
            this.toolStripButton7,
            this.toolStripDropDownButton1,
            this.toolStripDropDownButton2,
            this.toolStripButton8});
            this.TbsMain.Location = new System.Drawing.Point(0, 46);
            this.TbsMain.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.TbsMain.Name = "TbsMain";
            this.TbsMain.Size = new System.Drawing.Size(1394, 54);
            this.TbsMain.TabIndex = 8;
            this.TbsMain.Text = "toolStrip1";
            // 
            // toolStripButton1
            // 
            this.toolStripButton1.AutoSize = false;
            this.toolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton1.Image = global::SmartHome.Properties.Resources.folder1;
            this.toolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.Size = new System.Drawing.Size(45, 45);
            this.toolStripButton1.Text = "toolStripButton1";
            this.toolStripButton1.ToolTipText = "Открыть файл данных";
            // 
            // toolStripButton2
            // 
            this.toolStripButton2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton2.Image = global::SmartHome.Properties.Resources.save_as;
            this.toolStripButton2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton2.Name = "toolStripButton2";
            this.toolStripButton2.Size = new System.Drawing.Size(49, 49);
            this.toolStripButton2.Text = "toolStripButton2";
            this.toolStripButton2.ToolTipText = "Сохранить файл данных ";
            // 
            // toolStripButton3
            // 
            this.toolStripButton3.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton3.Image = global::SmartHome.Properties.Resources.create;
            this.toolStripButton3.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton3.Name = "toolStripButton3";
            this.toolStripButton3.Size = new System.Drawing.Size(49, 49);
            this.toolStripButton3.Text = "Создание новых сведений о квартире";
            // 
            // toolStripButton4
            // 
            this.toolStripButton4.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton4.Image = global::SmartHome.Properties.Resources.edit;
            this.toolStripButton4.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton4.Name = "toolStripButton4";
            this.toolStripButton4.Size = new System.Drawing.Size(49, 49);
            this.toolStripButton4.Text = "toolStripButton4";
            // 
            // toolStripButton5
            // 
            this.toolStripButton5.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton5.Image = global::SmartHome.Properties.Resources.add;
            this.toolStripButton5.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton5.Name = "toolStripButton5";
            this.toolStripButton5.Size = new System.Drawing.Size(49, 49);
            this.toolStripButton5.Text = "toolStripButton5";
            // 
            // toolStripButton6
            // 
            this.toolStripButton6.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton6.Image = global::SmartHome.Properties.Resources.pencil;
            this.toolStripButton6.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton6.Name = "toolStripButton6";
            this.toolStripButton6.Size = new System.Drawing.Size(49, 49);
            this.toolStripButton6.Text = "toolStripButton6";
            // 
            // toolStripButton7
            // 
            this.toolStripButton7.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton7.Image = global::SmartHome.Properties.Resources.remove;
            this.toolStripButton7.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton7.Name = "toolStripButton7";
            this.toolStripButton7.Size = new System.Drawing.Size(49, 49);
            this.toolStripButton7.Text = "toolStripButton7";
            // 
            // toolStripDropDownButton1
            // 
            this.toolStripDropDownButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripDropDownButton1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.поНазваниюToolStripMenuItem1,
            this.поСостояниюToolStripMenuItem1,
            this.поМощьностиToolStripMenuItem,
            this.поУбываниюЦенToolStripMenuItem});
            this.toolStripDropDownButton1.Image = global::SmartHome.Properties.Resources.order;
            this.toolStripDropDownButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripDropDownButton1.Name = "toolStripDropDownButton1";
            this.toolStripDropDownButton1.Size = new System.Drawing.Size(63, 49);
            this.toolStripDropDownButton1.Text = "toolStripDropDownButton1";
            // 
            // поНазваниюToolStripMenuItem1
            // 
            this.поНазваниюToolStripMenuItem1.Image = global::SmartHome.Properties.Resources.name;
            this.поНазваниюToolStripMenuItem1.Name = "поНазваниюToolStripMenuItem1";
            this.поНазваниюToolStripMenuItem1.Size = new System.Drawing.Size(341, 56);
            this.поНазваниюToolStripMenuItem1.Text = "По названию";
            // 
            // поСостояниюToolStripMenuItem1
            // 
            this.поСостояниюToolStripMenuItem1.Image = global::SmartHome.Properties.Resources.state;
            this.поСостояниюToolStripMenuItem1.Name = "поСостояниюToolStripMenuItem1";
            this.поСостояниюToolStripMenuItem1.Size = new System.Drawing.Size(341, 56);
            this.поСостояниюToolStripMenuItem1.Text = "По состоянию ";
            // 
            // поМощьностиToolStripMenuItem
            // 
            this.поМощьностиToolStripMenuItem.Image = global::SmartHome.Properties.Resources.power;
            this.поМощьностиToolStripMenuItem.Name = "поМощьностиToolStripMenuItem";
            this.поМощьностиToolStripMenuItem.Size = new System.Drawing.Size(341, 56);
            this.поМощьностиToolStripMenuItem.Text = "По мощьности";
            // 
            // поУбываниюЦенToolStripMenuItem
            // 
            this.поУбываниюЦенToolStripMenuItem.Image = global::SmartHome.Properties.Resources.low_price1;
            this.поУбываниюЦенToolStripMenuItem.Name = "поУбываниюЦенToolStripMenuItem";
            this.поУбываниюЦенToolStripMenuItem.Size = new System.Drawing.Size(341, 56);
            this.поУбываниюЦенToolStripMenuItem.Text = "По убыванию цен";
            // 
            // toolStripDropDownButton2
            // 
            this.toolStripDropDownButton2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripDropDownButton2.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.сЗаданнымНазваниемToolStripMenuItem1,
            this.сЗаданнымСостояниемToolStripMenuItem1});
            this.toolStripDropDownButton2.Image = global::SmartHome.Properties.Resources.vybor;
            this.toolStripDropDownButton2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripDropDownButton2.Name = "toolStripDropDownButton2";
            this.toolStripDropDownButton2.Size = new System.Drawing.Size(63, 49);
            this.toolStripDropDownButton2.Text = "toolStripDropDownButton2";
            // 
            // сЗаданнымНазваниемToolStripMenuItem1
            // 
            this.сЗаданнымНазваниемToolStripMenuItem1.Image = global::SmartHome.Properties.Resources.name;
            this.сЗаданнымНазваниемToolStripMenuItem1.Name = "сЗаданнымНазваниемToolStripMenuItem1";
            this.сЗаданнымНазваниемToolStripMenuItem1.Size = new System.Drawing.Size(408, 56);
            this.сЗаданнымНазваниемToolStripMenuItem1.Text = "С заданным названием";
            // 
            // сЗаданнымСостояниемToolStripMenuItem1
            // 
            this.сЗаданнымСостояниемToolStripMenuItem1.Image = global::SmartHome.Properties.Resources.state;
            this.сЗаданнымСостояниемToolStripMenuItem1.Name = "сЗаданнымСостояниемToolStripMenuItem1";
            this.сЗаданнымСостояниемToolStripMenuItem1.Size = new System.Drawing.Size(408, 56);
            this.сЗаданнымСостояниемToolStripMenuItem1.Text = "С заданным состоянием";
            // 
            // toolStripButton8
            // 
            this.toolStripButton8.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton8.Image = global::SmartHome.Properties.Resources.poweroff;
            this.toolStripButton8.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton8.Name = "toolStripButton8";
            this.toolStripButton8.Size = new System.Drawing.Size(49, 49);
            this.toolStripButton8.Text = "toolStripButton8";
            // 
            // LblAddress
            // 
            this.LblAddress.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.LblAddress.Location = new System.Drawing.Point(13, 104);
            this.LblAddress.Name = "LblAddress";
            this.LblAddress.Size = new System.Drawing.Size(1381, 38);
            this.LblAddress.TabIndex = 9;
            this.LblAddress.Text = "Адрес Квартиры : ";
            // 
            // TbcMain
            // 
            this.TbcMain.Controls.Add(this.TbpGeneral);
            this.TbcMain.Controls.Add(this.tabPage2);
            this.TbcMain.Controls.Add(this.tabPage3);
            this.TbcMain.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.TbcMain.Location = new System.Drawing.Point(0, 100);
            this.TbcMain.Name = "TbcMain";
            this.TbcMain.SelectedIndex = 0;
            this.TbcMain.Size = new System.Drawing.Size(1394, 552);
            this.TbcMain.TabIndex = 17;
            // 
            // TbpGeneral
            // 
            this.TbpGeneral.Controls.Add(this.DgvMain);
            this.TbpGeneral.Controls.Add(this.TrvAppliances);
            this.TbpGeneral.Location = new System.Drawing.Point(4, 41);
            this.TbpGeneral.Name = "TbpGeneral";
            this.TbpGeneral.Padding = new System.Windows.Forms.Padding(3);
            this.TbpGeneral.Size = new System.Drawing.Size(1386, 507);
            this.TbpGeneral.TabIndex = 0;
            this.TbpGeneral.Text = "Общие сведения";
            this.TbpGeneral.UseVisualStyleBackColor = true;
            this.TbpGeneral.Click += new System.EventHandler(this.tabPage1_Click);
            // 
            // DgvMain
            // 
            this.DgvMain.AllowUserToDeleteRows = false;
            this.DgvMain.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DgvMain.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.name,
            this.power,
            this.Price,
            this.state,
            this.room});
            this.DgvMain.Location = new System.Drawing.Point(406, 6);
            this.DgvMain.Name = "DgvMain";
            this.DgvMain.ReadOnly = true;
            this.DgvMain.RowHeadersWidth = 62;
            this.DgvMain.Size = new System.Drawing.Size(972, 497);
            this.DgvMain.TabIndex = 1;
            // 
            // name
            // 
            this.name.HeaderText = "Название прибора";
            this.name.MinimumWidth = 8;
            this.name.Name = "name";
            this.name.ReadOnly = true;
            this.name.Width = 150;
            // 
            // power
            // 
            this.power.HeaderText = "Мощность";
            this.power.MinimumWidth = 8;
            this.power.Name = "power";
            this.power.ReadOnly = true;
            this.power.Width = 150;
            // 
            // Price
            // 
            this.Price.HeaderText = "Цена";
            this.Price.MinimumWidth = 8;
            this.Price.Name = "Price";
            this.Price.ReadOnly = true;
            this.Price.Width = 150;
            // 
            // state
            // 
            this.state.HeaderText = "Состояние";
            this.state.MinimumWidth = 8;
            this.state.Name = "state";
            this.state.ReadOnly = true;
            this.state.Width = 150;
            // 
            // room
            // 
            this.room.HeaderText = "Комната";
            this.room.MinimumWidth = 8;
            this.room.Name = "room";
            this.room.ReadOnly = true;
            this.room.Width = 150;
            // 
            // TrvAppliances
            // 
            this.TrvAppliances.Location = new System.Drawing.Point(6, 6);
            this.TrvAppliances.Name = "TrvAppliances";
            this.TrvAppliances.Size = new System.Drawing.Size(394, 497);
            this.TrvAppliances.TabIndex = 0;
            // 
            // tabPage2
            // 
            this.tabPage2.Location = new System.Drawing.Point(4, 41);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1386, 507);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Отсортированные сведения";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // tabPage3
            // 
            this.tabPage3.Location = new System.Drawing.Point(4, 41);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(1386, 507);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Выборка данных";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // StlMain
            // 
            this.StlMain.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.StlMain.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.StlMain.Location = new System.Drawing.Point(0, 655);
            this.StlMain.Name = "StlMain";
            this.StlMain.Size = new System.Drawing.Size(1394, 25);
            this.StlMain.TabIndex = 18;
            this.StlMain.Text = "toolStrip1";
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1394, 680);
            this.Controls.Add(this.StlMain);
            this.Controls.Add(this.TbcMain);
            this.Controls.Add(this.LblAddress);
            this.Controls.Add(this.TbsMain);
            this.Controls.Add(this.MnsMain);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.MnsMain;
            this.Name = "MainForm";
            this.Text = "Задание на 12.12.21";
            this.MnsMain.ResumeLayout(false);
            this.MnsMain.PerformLayout();
            this.TbsMain.ResumeLayout(false);
            this.TbsMain.PerformLayout();
            this.TbcMain.ResumeLayout(false);
            this.TbpGeneral.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DgvMain)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip MnsMain;
        private System.Windows.Forms.ToolStripMenuItem файлToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem открытьToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem сохранитьToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem сохранитьКакToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem выходToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem сведенияОКвартиреToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem FlatNew;
        private System.Windows.Forms.ToolStripMenuItem FlatEdit;
        private System.Windows.Forms.ToolStripMenuItem электроприборыToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem добавитьToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem изменитьToolStripMenuItem1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripMenuItem выключитьВключитьToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem включитьВсеToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem выключитьВсеToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripMenuItem удалитьToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem сортировкаToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem поНазваниюToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem поСостояниюToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem выборкаToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem поМощностиToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem поУбываниюЦеныToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem сЗаданнымНазваниемToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem сЗаданнымСостояниемToolStripMenuItem;
        private System.Windows.Forms.ToolStrip TbsMain;
        private System.Windows.Forms.ToolStripButton toolStripButton1;
        private System.Windows.Forms.ToolStripButton toolStripButton2;
        private System.Windows.Forms.ToolStripButton toolStripButton3;
        private System.Windows.Forms.ToolStripButton toolStripButton4;
        private System.Windows.Forms.ToolStripButton toolStripButton5;
        private System.Windows.Forms.ToolStripButton toolStripButton6;
        private System.Windows.Forms.ToolStripButton toolStripButton7;
        private System.Windows.Forms.ToolStripDropDownButton toolStripDropDownButton1;
        private System.Windows.Forms.ToolStripMenuItem поНазваниюToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem поСостояниюToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem поМощьностиToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem поУбываниюЦенToolStripMenuItem;
        private System.Windows.Forms.ToolStripDropDownButton toolStripDropDownButton2;
        private System.Windows.Forms.ToolStripMenuItem сЗаданнымНазваниемToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem сЗаданнымСостояниемToolStripMenuItem1;
        private System.Windows.Forms.ToolStripButton toolStripButton8;
        private System.Windows.Forms.Label LblAddress;
        private System.Windows.Forms.TabControl TbcMain;
        private System.Windows.Forms.TabPage TbpGeneral;
        private System.Windows.Forms.DataGridView DgvMain;
        private System.Windows.Forms.TreeView TrvAppliances;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.ToolStrip StlMain;
        private System.Windows.Forms.ToolStripMenuItem справкаToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem оПрограммеToolStripMenuItem;
        private System.Windows.Forms.DataGridViewTextBoxColumn name;
        private System.Windows.Forms.DataGridViewTextBoxColumn power;
        private System.Windows.Forms.DataGridViewTextBoxColumn Price;
        private System.Windows.Forms.DataGridViewTextBoxColumn state;
        private System.Windows.Forms.DataGridViewTextBoxColumn room;
        private System.Windows.Forms.SaveFileDialog SfdMain;
    }
}