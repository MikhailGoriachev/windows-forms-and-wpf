﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Json;
using System.IO;
using SmartHome.Helpers;

namespace SmartHome.Models
{
    [DataContract]
    public class Appartment
    {
        // класс, описывающий электрооборудование квартиры: адрес квартиры, коллекция электроприборов

        //адресс
        private string _address;
        [DataMember]
        public string Address
        {
            get => _address;
            set
            {
                if (string.IsNullOrEmpty(value))
                    throw new ArgumentNullException(" Пустая строка");
            }
        }
        // коллеккция приборов
        private List<Appliance> _appliances; 
        [DataMember]
        public List<Appliance> Appliances
        {
            get => _appliances;
            private set => _appliances = value;

        }

        //условное название квартиру

        private string _flatName;

        public string FlatName
        {
            get => _flatName;
            set
            {
                if (string.IsNullOrEmpty(value)) 
                    throw new ArgumentNullException("Пустая строка");
                _flatName = value;
            }
        }

        //количество электроприборов в коллекции
        public int Count => _appliances.Count;


        // indexer
        public Appliance this[int index]
        {
            get => _appliances[index];
            set => _appliances[index] = value;
        }
        public Appartment():this("Кирова, 3Б, кв34", new List<Appliance>(), "Зойкина квартира")
        {
            GenerateCollection(Utils.GetRandom(10, 12));
        }
        public Appartment(string appart, List<Appliance> appliances, string flatname)
        {
            Address = appart;
            Appliances = appliances;
            FlatName = flatname;

        }

        // формирование приборов коллекции 
        public void GenerateCollection(int n)
        {
            _appliances.Clear(); 

            for(int i = 0; i<n; i++)
            {
                _appliances.Add(Appliance.Generate());
            }
        }

        // Удаление электроприбора
        public void RemoveAppliance(int index) => _appliances.RemoveAt(index);

        // Добавление электроприбора в коллекцию
        public void AddAppliance(Appliance appliance) => _appliances.Insert(0, appliance);

        // Редактирование электроприбора 
        public void EditAppliance(int index, Appliance appliance) => _appliances[index] = appliance;

        // Включение/выключение электроприбора
        public void OnOffAppliance(int index) => _appliances[index].State = !_appliances[index].State;

        // Включение/выключение всех электроприборов квартиры
        public void OnOffAll(bool state) => _appliances.ForEach(x => x.State = state);  

        // Упорядочивание копии коллекции электроприборов
        public List<Appliance> OrderBy (Comparison<Appliance> comparison)
        {
            List<Appliance> temp = _appliances;
            temp.Sort(comparison);
            return temp;
        }

        // Выборка электроприборов 
        public List<Appliance> ChooseAppliance(Predicate<Appliance> predicate) =>
            _appliances.FindAll(predicate);

        // сериализация в формате JSON
        public void Serialization(string filename)
        {
            DataContractJsonSerializer jsonFormater = new DataContractJsonSerializer(typeof(Appartment));

            using (FileStream fs = new FileStream(filename, FileMode.Create))
                jsonFormater.WriteObject(fs, this);

        }

        // десериализация формате JSON
        public void Deserilization(string filename)
        {
            DataContractJsonSerializer jsonFormater = new DataContractJsonSerializer(typeof(Appartment));

            using (FileStream fs = new FileStream(filename, FileMode.OpenOrCreate))
            {

                Appartment temp = (Appartment)jsonFormater.ReadObject(fs);
                Address = temp.Address;
                Appliances = temp.Appliances;
                 
            }


        }

    }
}
