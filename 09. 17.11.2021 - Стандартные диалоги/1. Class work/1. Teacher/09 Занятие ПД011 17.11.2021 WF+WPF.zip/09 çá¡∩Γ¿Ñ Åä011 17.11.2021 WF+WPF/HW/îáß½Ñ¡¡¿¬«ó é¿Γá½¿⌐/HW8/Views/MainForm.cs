﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using HW8.Models;

namespace HW8.Views
{
	public partial class MainForm : Form
	{
		private RepairShop _repairShop;

		public MainForm() : this(new RepairShop()) {}
		
		public MainForm(RepairShop repairShop)
		{

			InitializeComponent();

			_repairShop = repairShop;

			BindCollection();
		}

		// выполнение привязки коллекции
		private void BindCollection()
		{
			// остановить привязку
			LbxTelevisions.DataSource = null;

			// задать привязку
			LbxTelevisions.DataSource = _repairShop.Televisions;

			LbxTelevisions.DisplayMember = "TableRow";
		}

		// выполняется после конструктора формы
		private void MainForm_Load(object sender, EventArgs e)
		{
			Text = _repairShop.Title + ". Адрес: " + _repairShop.Address;
			StlMain.Text = $"Телевизоров в ремонте: {_repairShop.Count}";
			LblHeader.Text = Television.Header;

			RbtMinPrice.Checked = true;
			CbxReport.Enabled = false;

			
		}

		// команда заверешния работы приложения
		private void Exit_Command(object sender, EventArgs e) => Application.Exit();

		// команда отображения окна сведений о программе
		private void About_Command(object sender, EventArgs e)
		{
			AboutForm aboutForm = new AboutForm();
			aboutForm.ShowDialog();
		}

		// Команда отображения формы изменения данных о ремонтной мастерской
		private void ShopSettings_Command(object sender, EventArgs e)
		{
			ShopSettingsForm settingsForm = 
				new ShopSettingsForm(_repairShop.Title, _repairShop.Address);

			if (settingsForm.ShowDialog() != DialogResult.OK) return;

			_repairShop.Title = settingsForm.Title;
			_repairShop.Address = settingsForm.Address;

			Text = _repairShop.Title + ". Адрес: " + _repairShop.Address;
		}

		// Сортировка коллекции телевизоров По производителю и типу
		private void OrderByBrandType_Command(object sender, EventArgs e)
		{
			_repairShop.OrderByBrandType();

			BindCollection();

			// обновить строку состояния
			StlMain.Text = $"Коллекция телевизоров упорядочена по наименованию. Текущее количество телевизоров: {_repairShop.Count}";
		}

		//Сортировка коллекции телевизоров По убыванию диагонали экрана
		private void OrderByDiagonalDesc_Command(object sender, EventArgs e)
		{
			_repairShop.OrderByDiagonal();

			BindCollection();

			// обновить строку состояния
			StlMain.Text = $"Коллекция телевизоров упорядочена по уменьшению диагонали. Текущее количество телевизоров: {_repairShop.Count}";
		}

		//Сортировка коллекции телевизоров По мастеру, выполняющему ремонт
		private void OrderByRepairer_Command(object sender, EventArgs e)
		{
			_repairShop.OrderByRepairer();

			BindCollection();

			// обновить строку состояния
			StlMain.Text = $"Коллекция телевизоров упорядочена по мастеру, выполняющему ремонт. Текущее количество телевизоров: {_repairShop.Count}";
		}

		//Сортировка коллекции телевизоров По владельцу телевизора
		private void OrderByOwner_Command(object sender, EventArgs e)
		{
			_repairShop.OrderByOwner();

			BindCollection();

			// обновить строку состояния
			StlMain.Text = $"Коллекция телевизоров упорядочена по владельцу. Текущее количество телевизоров: {_repairShop.Count}";
		}


		private void TelevisionRemove_Command(object sender, EventArgs e)
		{
			if (LbxTelevisions.SelectedIndex < 0)
				return;

			// удаление записи данных 
			_repairShop.RemoveAt(LbxTelevisions.SelectedIndex);

			BindCollection();

			// обновить строку состояния
			StlMain.Text = $"Из коллекции был удалён телевизор. Текущее количество телевизоров: {_repairShop.Count}";

			UpdateCbxReport();
		}


		private void TelevisionAdd_Command(object sender, EventArgs e)
		{

			TVForm tvForm = new TVForm();
			DialogResult dialogResult = tvForm.ShowDialog();

			// если окно закрыто не по кнопке "Добавить" - молча уходим
			if (dialogResult != DialogResult.OK) return;

			// получить данные из свойства формы
			Television television = tvForm.Tv;
			_repairShop.AddTelevision(television);

			// обновить привязку
			BindCollection();

			// обновить строку состояния
			StlMain.Text = $"В коллекцию был добавлен телевизор. Текущее количество телевизоров: {_repairShop.Count}";
			
			UpdateCbxReport();
		}

		private void TelevisionEdit_Command(object sender, EventArgs e)
		{
			// если нет выбранного телевизора - уходим
			if (LbxTelevisions.SelectedIndex < 0)
				return;

			// передача данных в форму
			TVForm tvForm = new TVForm("Редактировать данные о телевизоре", "Сохранить");
			tvForm.Tv = _repairShop[LbxTelevisions.SelectedIndex];

			if (tvForm.ShowDialog() != DialogResult.OK) return;

			// получить данные
			_repairShop[LbxTelevisions.SelectedIndex] = tvForm.Tv;

			BindCollection();

			// обновить строку состояния
			StlMain.Text = $"Были изменены данные о телевизоре. Текущее количество телевизоров: {_repairShop.Count}";
			
			UpdateCbxReport();
		}

		// Радиокнопка - смена параметра формирования отчета
		private void RbtMinPrice_CheckedChanged(object sender, EventArgs e)
		{
			CbxReport.Items.Clear();
			CbxReport.Enabled = false;
		}

		// Радиокнопка - смена параметра формирования отчета
		private void RbtRepairer_CheckedChanged(object sender, EventArgs e)
		{
			CbxReport.Enabled = true;
			CbxReport.Items.Clear();
			CbxReport.Items.AddRange(_repairShop?.GetRepairers.ToArray());
			CbxReport.SelectedIndex = 0;
		}

		// Радиокнопка - смена параметра формировоания отчета
		private void RbtDiagonal_CheckedChanged(object sender, EventArgs e)
		{
			CbxReport.Enabled = true;
			CbxReport.Items.Clear();
			CbxReport.Items.AddRange(_repairShop?.GetDiagonals.ToArray());
			CbxReport.SelectedIndex = 0;
		}

		// Команда формирование отчета и вывода в отдельную форму
		private void BtnReport_Click(object sender, EventArgs e)
		{
			List<Television> reported = new List<Television>();

			if (RbtMinPrice.Checked)
				reported = _repairShop.GetTVsEqualsMinPrice();
			if (RbtRepairer.Checked)
				reported = _repairShop.GetTVsEqualsRepairer(CbxReport.SelectedItem.ToString());
			if (RbtDiagonal.Checked)
				reported = _repairShop.GetTVsEqualsDiagonal(int.Parse(CbxReport.SelectedItem.ToString()));


			ReportForm reportForm = new ReportForm(reported);

			reportForm.Show();
		}


		// Обновить комбобокс с выборкой для отчёта
		public void UpdateCbxReport()
		{
			if (RbtRepairer.Checked)
			{
				CbxReport.Items.Clear();
				CbxReport.Items.AddRange(_repairShop?.GetRepairers.ToArray());
				CbxReport.SelectedIndex = 0;
			}

			if (RbtDiagonal.Checked)
			{
				CbxReport.Items.Clear();
				CbxReport.Items.AddRange(_repairShop?.GetDiagonals.ToArray());
				CbxReport.SelectedIndex = 0;
			}
		}
	}
}
