﻿
namespace HW8.Views
{
	partial class MainForm
	{
		/// <summary>
		/// Обязательная переменная конструктора.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Освободить все используемые ресурсы.
		/// </summary>
		/// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Код, автоматически созданный конструктором форм Windows

		/// <summary>
		/// Требуемый метод для поддержки конструктора — не изменяйте 
		/// содержимое этого метода с помощью редактора кода.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
			this.LbxTelevisions = new System.Windows.Forms.ListBox();
			this.CmnForm = new System.Windows.Forms.ContextMenuStrip(this.components);
			this.оПрограммеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.выходToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.StsMain = new System.Windows.Forms.StatusStrip();
			this.StlMain = new System.Windows.Forms.ToolStripStatusLabel();
			this.LblHeader = new System.Windows.Forms.Label();
			this.MnuMain = new System.Windows.Forms.MenuStrip();
			this.MnuFile = new System.Windows.Forms.ToolStripMenuItem();
			this.MnuFileExit = new System.Windows.Forms.ToolStripMenuItem();
			this.MnuEdit = new System.Windows.Forms.ToolStripMenuItem();
			this.MnuEditAddTv = new System.Windows.Forms.ToolStripMenuItem();
			this.MnuEditEditTV = new System.Windows.Forms.ToolStripMenuItem();
			this.MnuEditRemove = new System.Windows.Forms.ToolStripMenuItem();
			this.MnuOrder = new System.Windows.Forms.ToolStripMenuItem();
			this.MnuOrderByBrandType = new System.Windows.Forms.ToolStripMenuItem();
			this.MnuOrderByDiagDesc = new System.Windows.Forms.ToolStripMenuItem();
			this.MnuOrderByRepairer = new System.Windows.Forms.ToolStripMenuItem();
			this.MnuOrderByOwner = new System.Windows.Forms.ToolStripMenuItem();
			this.MnuSettings = new System.Windows.Forms.ToolStripMenuItem();
			this.MnuSettingsEditShop = new System.Windows.Forms.ToolStripMenuItem();
			this.MnuHelp = new System.Windows.Forms.ToolStripMenuItem();
			this.MnuHelpAbout = new System.Windows.Forms.ToolStripMenuItem();
			this.LblTitle = new System.Windows.Forms.Label();
			this.TsbMain = new System.Windows.Forms.ToolStrip();
			this.TsbAdd = new System.Windows.Forms.ToolStripButton();
			this.TsbEdit = new System.Windows.Forms.ToolStripButton();
			this.TsbRemove = new System.Windows.Forms.ToolStripButton();
			this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
			this.toolStripButton1 = new System.Windows.Forms.ToolStripButton();
			this.toolStripButton2 = new System.Windows.Forms.ToolStripButton();
			this.toolStripButton3 = new System.Windows.Forms.ToolStripButton();
			this.toolStripButton4 = new System.Windows.Forms.ToolStripButton();
			this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
			this.CbxReport = new System.Windows.Forms.ComboBox();
			this.GrbReport = new System.Windows.Forms.GroupBox();
			this.BtnReport = new System.Windows.Forms.Button();
			this.RbtDiagonal = new System.Windows.Forms.RadioButton();
			this.RbtRepairer = new System.Windows.Forms.RadioButton();
			this.RbtMinPrice = new System.Windows.Forms.RadioButton();
			this.toolStripButton5 = new System.Windows.Forms.ToolStripButton();
			this.toolStripButton6 = new System.Windows.Forms.ToolStripButton();
			this.CmnForm.SuspendLayout();
			this.StsMain.SuspendLayout();
			this.MnuMain.SuspendLayout();
			this.TsbMain.SuspendLayout();
			this.GrbReport.SuspendLayout();
			this.SuspendLayout();
			// 
			// LbxTelevisions
			// 
			this.LbxTelevisions.ContextMenuStrip = this.CmnForm;
			this.LbxTelevisions.Font = new System.Drawing.Font("Consolas", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.LbxTelevisions.FormattingEnabled = true;
			this.LbxTelevisions.ItemHeight = 19;
			this.LbxTelevisions.Location = new System.Drawing.Point(17, 160);
			this.LbxTelevisions.Name = "LbxTelevisions";
			this.LbxTelevisions.ScrollAlwaysVisible = true;
			this.LbxTelevisions.Size = new System.Drawing.Size(1072, 213);
			this.LbxTelevisions.TabIndex = 5;
			// 
			// CmnForm
			// 
			this.CmnForm.Font = new System.Drawing.Font("Segoe UI", 12F);
			this.CmnForm.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.оПрограммеToolStripMenuItem,
            this.выходToolStripMenuItem});
			this.CmnForm.Name = "CmnForm";
			this.CmnForm.Size = new System.Drawing.Size(186, 56);
			// 
			// оПрограммеToolStripMenuItem
			// 
			this.оПрограммеToolStripMenuItem.Name = "оПрограммеToolStripMenuItem";
			this.оПрограммеToolStripMenuItem.Size = new System.Drawing.Size(185, 26);
			this.оПрограммеToolStripMenuItem.Text = "О программе...";
			this.оПрограммеToolStripMenuItem.Click += new System.EventHandler(this.About_Command);
			// 
			// выходToolStripMenuItem
			// 
			this.выходToolStripMenuItem.Name = "выходToolStripMenuItem";
			this.выходToolStripMenuItem.Size = new System.Drawing.Size(185, 26);
			this.выходToolStripMenuItem.Text = "Выход";
			this.выходToolStripMenuItem.Click += new System.EventHandler(this.Exit_Command);
			// 
			// StsMain
			// 
			this.StsMain.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.StsMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.StlMain});
			this.StsMain.Location = new System.Drawing.Point(0, 485);
			this.StsMain.Name = "StsMain";
			this.StsMain.Size = new System.Drawing.Size(1107, 25);
			this.StsMain.TabIndex = 7;
			this.StsMain.Text = "statusStrip1";
			// 
			// StlMain
			// 
			this.StlMain.AutoSize = false;
			this.StlMain.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.StlMain.Name = "StlMain";
			this.StlMain.Size = new System.Drawing.Size(1092, 20);
			this.StlMain.Spring = true;
			this.StlMain.Text = "toolStripStatusLabel1";
			this.StlMain.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// LblHeader
			// 
			this.LblHeader.BackColor = System.Drawing.SystemColors.Control;
			this.LblHeader.Font = new System.Drawing.Font("Consolas", 12F);
			this.LblHeader.Location = new System.Drawing.Point(17, 104);
			this.LblHeader.Name = "LblHeader";
			this.LblHeader.Size = new System.Drawing.Size(1056, 56);
			this.LblHeader.TabIndex = 8;
			this.LblHeader.Text = "label1";
			// 
			// MnuMain
			// 
			this.MnuMain.Font = new System.Drawing.Font("Segoe UI", 11.25F);
			this.MnuMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MnuFile,
            this.MnuEdit,
            this.MnuOrder,
            this.MnuSettings,
            this.MnuHelp});
			this.MnuMain.Location = new System.Drawing.Point(0, 0);
			this.MnuMain.Margin = new System.Windows.Forms.Padding(5, 0, 0, 5);
			this.MnuMain.Name = "MnuMain";
			this.MnuMain.Size = new System.Drawing.Size(1107, 28);
			this.MnuMain.TabIndex = 9;
			this.MnuMain.Text = "menuStrip1";
			// 
			// MnuFile
			// 
			this.MnuFile.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MnuFileExit});
			this.MnuFile.Name = "MnuFile";
			this.MnuFile.Size = new System.Drawing.Size(57, 24);
			this.MnuFile.Text = "Файл";
			// 
			// MnuFileExit
			// 
			this.MnuFileExit.Image = ((System.Drawing.Image)(resources.GetObject("MnuFileExit.Image")));
			this.MnuFileExit.Name = "MnuFileExit";
			this.MnuFileExit.Size = new System.Drawing.Size(180, 24);
			this.MnuFileExit.Text = "Выход";
			this.MnuFileExit.Click += new System.EventHandler(this.Exit_Command);
			// 
			// MnuEdit
			// 
			this.MnuEdit.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MnuEditAddTv,
            this.MnuEditEditTV,
            this.MnuEditRemove});
			this.MnuEdit.Name = "MnuEdit";
			this.MnuEdit.Size = new System.Drawing.Size(72, 24);
			this.MnuEdit.Text = "Правка";
			// 
			// MnuEditAddTv
			// 
			this.MnuEditAddTv.Image = global::HW8.Properties.Resources.add;
			this.MnuEditAddTv.Name = "MnuEditAddTv";
			this.MnuEditAddTv.Size = new System.Drawing.Size(180, 24);
			this.MnuEditAddTv.Text = "Добавить...";
			this.MnuEditAddTv.Click += new System.EventHandler(this.TelevisionAdd_Command);
			// 
			// MnuEditEditTV
			// 
			this.MnuEditEditTV.Image = global::HW8.Properties.Resources.edit;
			this.MnuEditEditTV.Name = "MnuEditEditTV";
			this.MnuEditEditTV.Size = new System.Drawing.Size(180, 24);
			this.MnuEditEditTV.Text = "Изменить...";
			this.MnuEditEditTV.Click += new System.EventHandler(this.TelevisionEdit_Command);
			// 
			// MnuEditRemove
			// 
			this.MnuEditRemove.Image = global::HW8.Properties.Resources.remove;
			this.MnuEditRemove.Name = "MnuEditRemove";
			this.MnuEditRemove.Size = new System.Drawing.Size(180, 24);
			this.MnuEditRemove.Text = "Удалить";
			this.MnuEditRemove.Click += new System.EventHandler(this.TelevisionRemove_Command);
			// 
			// MnuOrder
			// 
			this.MnuOrder.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MnuOrderByBrandType,
            this.MnuOrderByDiagDesc,
            this.MnuOrderByRepairer,
            this.MnuOrderByOwner});
			this.MnuOrder.Name = "MnuOrder";
			this.MnuOrder.Size = new System.Drawing.Size(104, 24);
			this.MnuOrder.Text = "Сортировка";
			// 
			// MnuOrderByBrandType
			// 
			this.MnuOrderByBrandType.Image = global::HW8.Properties.Resources.type;
			this.MnuOrderByBrandType.Name = "MnuOrderByBrandType";
			this.MnuOrderByBrandType.Size = new System.Drawing.Size(333, 24);
			this.MnuOrderByBrandType.Text = "По производителю и типу";
			this.MnuOrderByBrandType.Click += new System.EventHandler(this.OrderByBrandType_Command);
			// 
			// MnuOrderByDiagDesc
			// 
			this.MnuOrderByDiagDesc.Image = global::HW8.Properties.Resources.diag;
			this.MnuOrderByDiagDesc.Name = "MnuOrderByDiagDesc";
			this.MnuOrderByDiagDesc.Size = new System.Drawing.Size(333, 24);
			this.MnuOrderByDiagDesc.Text = "По убыванию диагонали экрана";
			this.MnuOrderByDiagDesc.Click += new System.EventHandler(this.OrderByDiagonalDesc_Command);
			// 
			// MnuOrderByRepairer
			// 
			this.MnuOrderByRepairer.Image = global::HW8.Properties.Resources.repairer;
			this.MnuOrderByRepairer.Name = "MnuOrderByRepairer";
			this.MnuOrderByRepairer.Size = new System.Drawing.Size(333, 24);
			this.MnuOrderByRepairer.Text = "По мастеру, выполняющему ремонт";
			this.MnuOrderByRepairer.Click += new System.EventHandler(this.OrderByRepairer_Command);
			// 
			// MnuOrderByOwner
			// 
			this.MnuOrderByOwner.Image = global::HW8.Properties.Resources.owner;
			this.MnuOrderByOwner.Name = "MnuOrderByOwner";
			this.MnuOrderByOwner.Size = new System.Drawing.Size(333, 24);
			this.MnuOrderByOwner.Text = "По владельцу телевизора";
			this.MnuOrderByOwner.Click += new System.EventHandler(this.OrderByOwner_Command);
			// 
			// MnuSettings
			// 
			this.MnuSettings.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MnuSettingsEditShop});
			this.MnuSettings.Name = "MnuSettings";
			this.MnuSettings.Size = new System.Drawing.Size(96, 24);
			this.MnuSettings.Text = "Настройки";
			// 
			// MnuSettingsEditShop
			// 
			this.MnuSettingsEditShop.Image = global::HW8.Properties.Resources.settings;
			this.MnuSettingsEditShop.Name = "MnuSettingsEditShop";
			this.MnuSettingsEditShop.Size = new System.Drawing.Size(353, 24);
			this.MnuSettingsEditShop.Text = "Изменить информацию о мастерской...";
			this.MnuSettingsEditShop.Click += new System.EventHandler(this.ShopSettings_Command);
			// 
			// MnuHelp
			// 
			this.MnuHelp.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MnuHelpAbout});
			this.MnuHelp.Name = "MnuHelp";
			this.MnuHelp.Size = new System.Drawing.Size(79, 24);
			this.MnuHelp.Text = "Справка";
			// 
			// MnuHelpAbout
			// 
			this.MnuHelpAbout.Image = global::HW8.Properties.Resources.about;
			this.MnuHelpAbout.Name = "MnuHelpAbout";
			this.MnuHelpAbout.Size = new System.Drawing.Size(180, 24);
			this.MnuHelpAbout.Text = "О программе";
			this.MnuHelpAbout.Click += new System.EventHandler(this.About_Command);
			// 
			// LblTitle
			// 
			this.LblTitle.Font = new System.Drawing.Font("Consolas", 12F);
			this.LblTitle.Location = new System.Drawing.Point(19, 80);
			this.LblTitle.Name = "LblTitle";
			this.LblTitle.Size = new System.Drawing.Size(392, 23);
			this.LblTitle.TabIndex = 10;
			this.LblTitle.Text = "Список телевизоров, находящихся в ремонте:";
			// 
			// TsbMain
			// 
			this.TsbMain.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
			this.TsbMain.ImageScalingSize = new System.Drawing.Size(30, 30);
			this.TsbMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.TsbAdd,
            this.TsbEdit,
            this.TsbRemove,
            this.toolStripSeparator1,
            this.toolStripButton1,
            this.toolStripButton2,
            this.toolStripButton3,
            this.toolStripButton4,
            this.toolStripSeparator2,
            this.toolStripButton5,
            this.toolStripButton6});
			this.TsbMain.Location = new System.Drawing.Point(0, 28);
			this.TsbMain.Name = "TsbMain";
			this.TsbMain.Padding = new System.Windows.Forms.Padding(5, 1, 15, 1);
			this.TsbMain.Size = new System.Drawing.Size(1107, 39);
			this.TsbMain.TabIndex = 12;
			this.TsbMain.Text = "toolStrip1";
			// 
			// TsbAdd
			// 
			this.TsbAdd.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.TsbAdd.Image = ((System.Drawing.Image)(resources.GetObject("TsbAdd.Image")));
			this.TsbAdd.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.TsbAdd.Name = "TsbAdd";
			this.TsbAdd.Size = new System.Drawing.Size(34, 34);
			this.TsbAdd.Text = "Добавить телевизор";
			this.TsbAdd.Click += new System.EventHandler(this.TelevisionAdd_Command);
			// 
			// TsbEdit
			// 
			this.TsbEdit.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.TsbEdit.Image = ((System.Drawing.Image)(resources.GetObject("TsbEdit.Image")));
			this.TsbEdit.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.TsbEdit.Name = "TsbEdit";
			this.TsbEdit.Size = new System.Drawing.Size(34, 34);
			this.TsbEdit.Text = "Изменить телевизор";
			this.TsbEdit.Click += new System.EventHandler(this.TelevisionEdit_Command);
			// 
			// TsbRemove
			// 
			this.TsbRemove.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.TsbRemove.Image = ((System.Drawing.Image)(resources.GetObject("TsbRemove.Image")));
			this.TsbRemove.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.TsbRemove.Name = "TsbRemove";
			this.TsbRemove.Size = new System.Drawing.Size(34, 34);
			this.TsbRemove.Text = "Удалить телевизор";
			this.TsbRemove.Click += new System.EventHandler(this.TelevisionRemove_Command);
			// 
			// toolStripSeparator1
			// 
			this.toolStripSeparator1.Name = "toolStripSeparator1";
			this.toolStripSeparator1.Size = new System.Drawing.Size(6, 37);
			// 
			// toolStripButton1
			// 
			this.toolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.toolStripButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton1.Image")));
			this.toolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.toolStripButton1.Name = "toolStripButton1";
			this.toolStripButton1.Size = new System.Drawing.Size(34, 34);
			this.toolStripButton1.Text = "Сортировка по производителю и типу";
			this.toolStripButton1.Click += new System.EventHandler(this.OrderByBrandType_Command);
			// 
			// toolStripButton2
			// 
			this.toolStripButton2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.toolStripButton2.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton2.Image")));
			this.toolStripButton2.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.toolStripButton2.Name = "toolStripButton2";
			this.toolStripButton2.Size = new System.Drawing.Size(34, 34);
			this.toolStripButton2.Text = "Сортировка по убыванию дигонали";
			this.toolStripButton2.Click += new System.EventHandler(this.OrderByDiagonalDesc_Command);
			// 
			// toolStripButton3
			// 
			this.toolStripButton3.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.toolStripButton3.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton3.Image")));
			this.toolStripButton3.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.toolStripButton3.Name = "toolStripButton3";
			this.toolStripButton3.Size = new System.Drawing.Size(34, 34);
			this.toolStripButton3.Text = "Сортировка по мастеру";
			this.toolStripButton3.Click += new System.EventHandler(this.OrderByRepairer_Command);
			// 
			// toolStripButton4
			// 
			this.toolStripButton4.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.toolStripButton4.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton4.Image")));
			this.toolStripButton4.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.toolStripButton4.Name = "toolStripButton4";
			this.toolStripButton4.Size = new System.Drawing.Size(34, 34);
			this.toolStripButton4.Text = "Сортировка по владельцу";
			this.toolStripButton4.Click += new System.EventHandler(this.OrderByOwner_Command);
			// 
			// toolStripSeparator2
			// 
			this.toolStripSeparator2.Name = "toolStripSeparator2";
			this.toolStripSeparator2.Size = new System.Drawing.Size(6, 37);
			// 
			// CbxReport
			// 
			this.CbxReport.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.CbxReport.FormattingEnabled = true;
			this.CbxReport.Location = new System.Drawing.Point(688, 40);
			this.CbxReport.Name = "CbxReport";
			this.CbxReport.Size = new System.Drawing.Size(136, 26);
			this.CbxReport.TabIndex = 13;
			// 
			// GrbReport
			// 
			this.GrbReport.Controls.Add(this.BtnReport);
			this.GrbReport.Controls.Add(this.RbtDiagonal);
			this.GrbReport.Controls.Add(this.RbtRepairer);
			this.GrbReport.Controls.Add(this.RbtMinPrice);
			this.GrbReport.Controls.Add(this.CbxReport);
			this.GrbReport.Location = new System.Drawing.Point(16, 392);
			this.GrbReport.Name = "GrbReport";
			this.GrbReport.Size = new System.Drawing.Size(1072, 80);
			this.GrbReport.TabIndex = 14;
			this.GrbReport.TabStop = false;
			this.GrbReport.Text = "Отчет";
			// 
			// BtnReport
			// 
			this.BtnReport.Location = new System.Drawing.Point(880, 37);
			this.BtnReport.Name = "BtnReport";
			this.BtnReport.Size = new System.Drawing.Size(136, 32);
			this.BtnReport.TabIndex = 17;
			this.BtnReport.Text = "Показать";
			this.BtnReport.UseVisualStyleBackColor = true;
			this.BtnReport.Click += new System.EventHandler(this.BtnReport_Click);
			// 
			// RbtDiagonal
			// 
			this.RbtDiagonal.AutoSize = true;
			this.RbtDiagonal.Location = new System.Drawing.Point(508, 40);
			this.RbtDiagonal.Name = "RbtDiagonal";
			this.RbtDiagonal.Size = new System.Drawing.Size(123, 22);
			this.RbtDiagonal.TabIndex = 16;
			this.RbtDiagonal.TabStop = true;
			this.RbtDiagonal.Text = "По диагонали";
			this.RbtDiagonal.UseVisualStyleBackColor = true;
			this.RbtDiagonal.CheckedChanged += new System.EventHandler(this.RbtDiagonal_CheckedChanged);
			// 
			// RbtRepairer
			// 
			this.RbtRepairer.AutoSize = true;
			this.RbtRepairer.Location = new System.Drawing.Point(345, 40);
			this.RbtRepairer.Name = "RbtRepairer";
			this.RbtRepairer.Size = new System.Drawing.Size(107, 22);
			this.RbtRepairer.TabIndex = 15;
			this.RbtRepairer.TabStop = true;
			this.RbtRepairer.Text = "По мастеру";
			this.RbtRepairer.UseVisualStyleBackColor = true;
			this.RbtRepairer.CheckedChanged += new System.EventHandler(this.RbtRepairer_CheckedChanged);
			// 
			// RbtMinPrice
			// 
			this.RbtMinPrice.AutoSize = true;
			this.RbtMinPrice.Location = new System.Drawing.Point(24, 40);
			this.RbtMinPrice.Name = "RbtMinPrice";
			this.RbtMinPrice.Size = new System.Drawing.Size(265, 22);
			this.RbtMinPrice.TabIndex = 14;
			this.RbtMinPrice.TabStop = true;
			this.RbtMinPrice.Text = "Минимальная стоимость ремонта";
			this.RbtMinPrice.UseVisualStyleBackColor = true;
			this.RbtMinPrice.CheckedChanged += new System.EventHandler(this.RbtMinPrice_CheckedChanged);
			// 
			// toolStripButton5
			// 
			this.toolStripButton5.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.toolStripButton5.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton5.Image")));
			this.toolStripButton5.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.toolStripButton5.Name = "toolStripButton5";
			this.toolStripButton5.Size = new System.Drawing.Size(34, 34);
			this.toolStripButton5.Text = "Изменить информацию о мастерской";
			this.toolStripButton5.Click += new System.EventHandler(this.ShopSettings_Command);
			// 
			// toolStripButton6
			// 
			this.toolStripButton6.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.toolStripButton6.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton6.Image")));
			this.toolStripButton6.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.toolStripButton6.Name = "toolStripButton6";
			this.toolStripButton6.Size = new System.Drawing.Size(34, 34);
			this.toolStripButton6.Text = "О программе";
			this.toolStripButton6.Click += new System.EventHandler(this.About_Command);
			// 
			// MainForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
			this.ClientSize = new System.Drawing.Size(1107, 510);
			this.ContextMenuStrip = this.CmnForm;
			this.Controls.Add(this.GrbReport);
			this.Controls.Add(this.TsbMain);
			this.Controls.Add(this.LblTitle);
			this.Controls.Add(this.LblHeader);
			this.Controls.Add(this.StsMain);
			this.Controls.Add(this.MnuMain);
			this.Controls.Add(this.LbxTelevisions);
			this.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.MainMenuStrip = this.MnuMain;
			this.MaximizeBox = false;
			this.Name = "MainForm";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Домашняя Работа";
			this.Load += new System.EventHandler(this.MainForm_Load);
			this.CmnForm.ResumeLayout(false);
			this.StsMain.ResumeLayout(false);
			this.StsMain.PerformLayout();
			this.MnuMain.ResumeLayout(false);
			this.MnuMain.PerformLayout();
			this.TsbMain.ResumeLayout(false);
			this.TsbMain.PerformLayout();
			this.GrbReport.ResumeLayout(false);
			this.GrbReport.PerformLayout();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.ListBox LbxTelevisions;
		private System.Windows.Forms.StatusStrip StsMain;
		private System.Windows.Forms.ToolStripStatusLabel StlMain;
		private System.Windows.Forms.Label LblHeader;
		private System.Windows.Forms.MenuStrip MnuMain;
		private System.Windows.Forms.ToolStripMenuItem MnuFile;
		private System.Windows.Forms.ToolStripMenuItem MnuFileExit;
		private System.Windows.Forms.ToolStripMenuItem MnuEdit;
		private System.Windows.Forms.ToolStripMenuItem MnuEditAddTv;
		private System.Windows.Forms.ToolStripMenuItem MnuEditEditTV;
		private System.Windows.Forms.ToolStripMenuItem MnuOrder;
		private System.Windows.Forms.ToolStripMenuItem MnuOrderByBrandType;
		private System.Windows.Forms.ToolStripMenuItem MnuOrderByDiagDesc;
		private System.Windows.Forms.ToolStripMenuItem MnuOrderByRepairer;
		private System.Windows.Forms.ToolStripMenuItem MnuEditRemove;
		private System.Windows.Forms.ToolStripMenuItem MnuOrderByOwner;
		private System.Windows.Forms.ToolStripMenuItem MnuSettings;
		private System.Windows.Forms.ToolStripMenuItem MnuSettingsEditShop;
		private System.Windows.Forms.ToolStripMenuItem MnuHelp;
		private System.Windows.Forms.ToolStripMenuItem MnuHelpAbout;
		private System.Windows.Forms.Label LblTitle;
		private System.Windows.Forms.ContextMenuStrip CmnForm;
		private System.Windows.Forms.ToolStripMenuItem оПрограммеToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem выходToolStripMenuItem;
		private System.Windows.Forms.ToolStrip TsbMain;
		private System.Windows.Forms.ToolStripButton TsbAdd;
		private System.Windows.Forms.ToolStripButton TsbEdit;
		private System.Windows.Forms.ToolStripButton TsbRemove;
		private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
		private System.Windows.Forms.ToolStripButton toolStripButton1;
		private System.Windows.Forms.ToolStripButton toolStripButton2;
		private System.Windows.Forms.ToolStripButton toolStripButton3;
		private System.Windows.Forms.ToolStripButton toolStripButton4;
		private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
		private System.Windows.Forms.ComboBox CbxReport;
		private System.Windows.Forms.GroupBox GrbReport;
		private System.Windows.Forms.Button BtnReport;
		private System.Windows.Forms.RadioButton RbtDiagonal;
		private System.Windows.Forms.RadioButton RbtRepairer;
		private System.Windows.Forms.RadioButton RbtMinPrice;
		private System.Windows.Forms.ToolStripButton toolStripButton5;
		private System.Windows.Forms.ToolStripButton toolStripButton6;
	}
}

