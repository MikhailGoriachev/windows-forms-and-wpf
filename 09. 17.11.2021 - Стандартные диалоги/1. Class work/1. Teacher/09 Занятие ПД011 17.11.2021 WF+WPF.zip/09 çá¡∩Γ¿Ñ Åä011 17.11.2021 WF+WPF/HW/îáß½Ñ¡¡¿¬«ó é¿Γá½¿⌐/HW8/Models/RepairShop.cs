﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HW8.Models
{
	/*
	 * класс RepairShop (коллекция Television, название ремонтной мастерской, адрес ремонтной мастерской).
	 */
	public class RepairShop
	{
		//коллекция Television
		private List<Television> _televisions;

		public List<Television> Televisions => _televisions;

		//название ремонтной мастерской
		private string _title;

		public string  Title
		{
			get => _title;
			set
			{
				if (string.IsNullOrEmpty(value))
					throw new ArgumentNullException("Пустая строка в названии мастерской");
				_title = value;
			}
		}

		//адрес ремонтной мастерской

		private string _address;

		public string Address
		{
			get =>_address;
			set
			{
				if (string.IsNullOrEmpty(value))
					throw new ArgumentNullException("Пустая строка в указании адреса мастерской");
				_address = value;
			}
		}

		public RepairShop() :this(new List<Television>(), "Телевизионная мастерская", "ул. Гурова, 25")
		{
			_televisions = new List<Television>()
			{
				new Television("Samsung LCD", 37, "Неисправность матрицы", "Казаков Д.В.", "Васильев П.К.", 3700),
				new Television("LG PDP", 42, "Не включается", "Михайлов Ю.Т.", "Крылов Т.Д.", 1700),
				new Television("Sony LED", 24, "Деффект матрицы", "Кудрявцев А.А.", "Долгов Д.Г.", 15000),
				new Television("Philips RP", 50, "Выгорание матрицы", "Михайлов Ю.Т.", "Карпов В.М.", 9000),
				new Television("Pansonic LCD", 70, "Мигающее изображение", "Кудрявцев А.А.", "Горелов Д.Д.", 4200),
				new Television("Samsung LED", 37, "Не включается", "Казаков Д.В.", "Громов М.И.", 4000),
				new Television("Sony LED", 22, "Битые пиксели", "Кудрявцев А.А.", "Орлов М.М.", 1700),
				new Television("Sony PDP", 34, "Неисправен БП", "Казаков Д.В.", "Носов И.М.", 2400),
				new Television("Lg OLED", 48, "Горизонтальные полосы", "Михайлов Ю.Т.", "Чернышев П.М.", 22000),
				new Television("Samsung PDP", 50, "Деффект матрицы", "Воронов С.М.", "Гусев А.Е.", 1300),
				new Television("Panasonic LED", 72, "Вертикальные полосы", "Михайлов Ю.Т.", "Никонов Д.И.", 8500),
				new Television("Xiaomi OLED", 42, "Не включается", "Воронов С.М.", "Иванов В.А.", 2000)
			};
		}

		public RepairShop(List<Television> televisions, string title, string address)
		{
			_televisions = televisions;
			_title = title;
			_address = address;
		}

		public int Count => _televisions.Count;

		// Получить список фамилий мастеров
		public List<string> GetRepairers => _televisions.Select(tv => tv.Repairer).Distinct().ToList();

		// Получить список диагоналей
		public List<string> GetDiagonals => _televisions.Select(tv => tv.Diagonal.ToString()).Distinct().ToList();

		// Получить список телевизоров, ремонт которых выполняет определенный мастер
		public List<Television> GetTVsEqualsRepairer(string repairer) =>
			_televisions.Where(tv => tv.Repairer == repairer).ToList();

		// Получить список телевизоров с определенной диагональю
		public List<Television> GetTVsEqualsDiagonal(int diagonal) =>
			_televisions.Where(tv => tv.Diagonal == diagonal).ToList();
		
		// Получить список телевизоров с минимальной стоимостью ремонта
		public List<Television> GetTVsEqualsMinPrice()
		{
			int minPrice = _televisions.Min(tv => tv.Price);

			return _televisions.Where(tv => tv.Price == minPrice).ToList();
		}

		public Television this[int index]
		{
			get
			{
				if (index < 0 || index > Count)
					throw new IndexOutOfRangeException("Попытка доступа к элементу вне диапазона");
				return _televisions[index];
			}
			set
			{
				if (index < 0 || index > Count)
					throw new IndexOutOfRangeException("Попытка доступа к элементу вне диапазона");

				_televisions[index] = value;
			}
		}

		// Сортировка По производителю и типу
		public void OrderByBrandType() =>
			_televisions.Sort((tv1, tv2) => tv1.BrandType.CompareTo(tv2.BrandType));

		// Сортировка По убыванию диагонали экрана
		public void OrderByDiagonal() =>
			_televisions.Sort((tv1, tv2) => tv2.Diagonal.CompareTo(tv1.Diagonal));

		// Сортировка По мастеру, выполняющему ремонт
		public void OrderByRepairer() =>
			_televisions.Sort((tv1, tv2) => tv1.Repairer.CompareTo(tv2.Repairer));

		// Сортировка По владельцу телевизора
		public void OrderByOwner() =>
			_televisions.Sort((tv1, tv2) => tv1.Owner.CompareTo(tv2.Owner));

		// удаление выбранного телевизора
		public void RemoveAt(int index) => _televisions.RemoveAt(index);

		// удаление всех телевизоров
		public void RemoveAll() => _televisions.Clear();

		// добавление телевизора в коллекцию
		public void AddTelevision(Television television) => _televisions.Add(television);

	}
}
