﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Televisions.Helpers;

namespace Televisions.Models
{
    // Класс RepairShop (коллекция Television, название ремонтной мастерской, адрес ремонтной мастерской).
    // Обработки:
    //     •	Начальное формирование данных ремонтной мастерской (коллекция телевизоров от 12 до 15 штук)
    //     •	Добавление телевизора в коллекцию
    //     •	Упорядочивание коллекции телевизоров
    //          o   По производителю и типу
    //          o   По убыванию диагонали экрана
    //          o   По мастеру, выполняющему ремонт
    //          o   По владельцу телевизора
    //     •	Выборка телевизоров с минимальной стоимостью ремонта
    //     •	Выборка телевизоров, ремонтируемых выбранным мастером
    //     •	Выборка телевизоров, с заданной диагональю экрана
    public class RepairShop {
        // название ремонтной мастерской
        private string _name;
        public string Name {
            get => _name;
            set {
                if (string.IsNullOrEmpty(value))
                    throw new Exception("Пустая строка в названии ремонтной мастерской");

                _name = value;
            } // set
        } // Name

        // адрес ремонтной мастерской
        private string _address;
        public string Address {
            get => _address;
            set {
                if (string.IsNullOrEmpty(value))
                    throw new Exception("Пустая строка в адресе ремонтной мастерской");

                _address = value;
            } // set
        } // Name

        // ссылка на коллекцию телевизоров
        private List<Television> _televisions;
        public List<Television> Televisions => _televisions;

        // конструкторы для получения коллекции телевизоров
        public RepairShop() : this("\"Эксперт-Сервис*\"", "Ленинский проспект, 4а", new List<Television>()) {
            // создание коллекции телевизоров, количество по заданию 
            Generate(Utils.GetRandom(12, 15));
        } // AppliancesController

        public RepairShop(string name, string address, List<Television> televisions) {
            _televisions = televisions;
            _name = name;
            _address = address;
        } // AppliancesController

        // количестово телевизоров в коллекции
        public int Count => _televisions.Count;


        // формирование заданного количества телевизоров в коллекции
        public void Generate(int n) {
            _televisions.Clear();

            for (int i = 0; i < n; i++)
                _televisions.Add(Television.Generate());
        } // Generate


        // Добавление телевизора в коллекцию
        public void AddTelevision(Television television) => _televisions.Insert(0, television);

        public void EditTelevision(int index, Television television) => _televisions[index] = television;

        // Упорядочивание коллекции телевизоров: 

        // По производителю и типу
        public void OrderByBrand() =>
            _televisions.Sort((x, y) => x.Brand.CompareTo(y.Brand));

        // По убыванию диагонали экрана
        public void OrderByScreen() =>
            _televisions.Sort((x, y) => y.Screen.CompareTo(x.Screen));

        // По мастеру, выполняющему ремонт
        public void OrderByMaster() =>
            _televisions.Sort((x, y) => x.Master.CompareTo(y.Master));

        // По владельцу телевизора
        public void OrderByOwner() =>
            _televisions.Sort((x, y) => x.Owner.CompareTo(y.Owner));

        // поиск минимальной стоимости ремонта
        public int MinCost() {
            int min = _televisions[0].Cost;
            _televisions.ForEach(x => { if (x.Cost < min) min = x.Cost; });
            return min;
        } // MinCost

        // Выборка телевизоров с минимальной стоимостью ремонта
        public List<Television> SelectTelevisions() {
            int min = MinCost();
            return new List<Television>(Array.FindAll(_televisions.ToArray(), x => x.Cost == min));
        } // SelectTelevisions

        // Выборка телевизоров, ремонтируемых выбранным мастером
        public List<Television> SelectTelevisions(string master) =>
            new List<Television>(Array.FindAll(_televisions.ToArray(), x => x.Master == master));

        // Выборка телевизоров, с заданной диагональю экрана
        public List<Television> SelectTelevisions(int screen) =>
            new List<Television>(Array.FindAll(_televisions.ToArray(), x => x.Screen == screen));
    } // RepairShop
}
