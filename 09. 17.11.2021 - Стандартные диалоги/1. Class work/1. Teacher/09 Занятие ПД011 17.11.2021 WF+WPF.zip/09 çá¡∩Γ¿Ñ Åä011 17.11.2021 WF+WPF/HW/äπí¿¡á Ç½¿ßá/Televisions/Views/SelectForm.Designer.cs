﻿
namespace Televisions.Views
{
    partial class SelectForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.LbxTelevisions = new System.Windows.Forms.ListBox();
            this.LblTelevision = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.LblMain = new System.Windows.Forms.Label();
            this.CbxMaster = new System.Windows.Forms.ComboBox();
            this.NudScreen = new System.Windows.Forms.NumericUpDown();
            this.BtnSelect = new System.Windows.Forms.Button();
            this.BtnExit = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.NudScreen)).BeginInit();
            this.SuspendLayout();
            // 
            // LbxTelevisions
            // 
            this.LbxTelevisions.Font = new System.Drawing.Font("Consolas", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LbxTelevisions.FormattingEnabled = true;
            this.LbxTelevisions.ItemHeight = 15;
            this.LbxTelevisions.Location = new System.Drawing.Point(18, 101);
            this.LbxTelevisions.Name = "LbxTelevisions";
            this.LbxTelevisions.Size = new System.Drawing.Size(754, 289);
            this.LbxTelevisions.TabIndex = 5;
            // 
            // LblTelevision
            // 
            this.LblTelevision.BackColor = System.Drawing.Color.Gainsboro;
            this.LblTelevision.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.LblTelevision.Font = new System.Drawing.Font("Consolas", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblTelevision.Location = new System.Drawing.Point(18, 71);
            this.LblTelevision.Name = "LblTelevision";
            this.LblTelevision.Size = new System.Drawing.Size(754, 40);
            this.LblTelevision.TabIndex = 6;
            this.LblTelevision.Text = "Выбранные телевизоры:\r\n|    Tелевизор    | Диагональ экрана |        Мастер      " +
    "  |       Владелец       | Стоимость ремонта |\r\n";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel1.Controls.Add(this.BtnSelect);
            this.panel1.Controls.Add(this.NudScreen);
            this.panel1.Controls.Add(this.CbxMaster);
            this.panel1.Controls.Add(this.LblMain);
            this.panel1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.panel1.Location = new System.Drawing.Point(18, 22);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(754, 46);
            this.panel1.TabIndex = 8;
            // 
            // LblMain
            // 
            this.LblMain.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblMain.Location = new System.Drawing.Point(3, 12);
            this.LblMain.Name = "LblMain";
            this.LblMain.Size = new System.Drawing.Size(324, 23);
            this.LblMain.TabIndex = 0;
            this.LblMain.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // CbxMaster
            // 
            this.CbxMaster.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CbxMaster.FormattingEnabled = true;
            this.CbxMaster.Items.AddRange(new object[] {
            "Семенов Б.В",
            "Семенова Р.Т.",
            "Дунаев О.Ю.",
            "Дунаева Г.Т",
            " Харламова П.А.",
            "Харламов т.Р.",
            "Олегова В.Ф.",
            "Олегов В.Ф.",
            "Янковский Т.Р.",
            "Янковская О.Л.",
            "Абалкин Н.Р.",
            "Абалкина П.Р.",
            "Романова Р.Л.",
            "Воликов О.П.",
            "Жукова Н.К.",
            "Соколов Р.Ж."});
            this.CbxMaster.Location = new System.Drawing.Point(333, 11);
            this.CbxMaster.Name = "CbxMaster";
            this.CbxMaster.Size = new System.Drawing.Size(198, 27);
            this.CbxMaster.TabIndex = 9;
            this.CbxMaster.Visible = false;
            // 
            // NudScreen
            // 
            this.NudScreen.Location = new System.Drawing.Point(333, 10);
            this.NudScreen.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.NudScreen.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.NudScreen.Name = "NudScreen";
            this.NudScreen.Size = new System.Drawing.Size(198, 27);
            this.NudScreen.TabIndex = 10;
            this.NudScreen.ThousandsSeparator = true;
            this.NudScreen.Value = new decimal(new int[] {
            55,
            0,
            0,
            0});
            this.NudScreen.Visible = false;
            // 
            // BtnSelect
            // 
            this.BtnSelect.BackColor = System.Drawing.SystemColors.HotTrack;
            this.BtnSelect.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.BtnSelect.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BtnSelect.Location = new System.Drawing.Point(556, 8);
            this.BtnSelect.Name = "BtnSelect";
            this.BtnSelect.Size = new System.Drawing.Size(175, 31);
            this.BtnSelect.TabIndex = 11;
            this.BtnSelect.Text = "Выбрать";
            this.BtnSelect.UseVisualStyleBackColor = false;
            this.BtnSelect.Click += new System.EventHandler(this.BtnSelect_Click);
            // 
            // BtnExit
            // 
            this.BtnExit.BackColor = System.Drawing.SystemColors.HotTrack;
            this.BtnExit.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.BtnExit.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BtnExit.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.BtnExit.Location = new System.Drawing.Point(597, 401);
            this.BtnExit.Name = "BtnExit";
            this.BtnExit.Size = new System.Drawing.Size(175, 31);
            this.BtnExit.TabIndex = 12;
            this.BtnExit.Text = "Выход";
            this.BtnExit.UseVisualStyleBackColor = false;
            this.BtnExit.Click += new System.EventHandler(this.BtnExit_Click);
            // 
            // SelectForm
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.Gainsboro;
            this.ClientSize = new System.Drawing.Size(787, 444);
            this.Controls.Add(this.BtnExit);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.LbxTelevisions);
            this.Controls.Add(this.LblTelevision);
            this.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "SelectForm";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Выборка телевизоров";
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.NudScreen)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListBox LbxTelevisions;
        private System.Windows.Forms.Label LblTelevision;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label LblMain;
        private System.Windows.Forms.ComboBox CbxMaster;
        private System.Windows.Forms.NumericUpDown NudScreen;
        private System.Windows.Forms.Button BtnSelect;
        private System.Windows.Forms.Button BtnExit;
    }
}