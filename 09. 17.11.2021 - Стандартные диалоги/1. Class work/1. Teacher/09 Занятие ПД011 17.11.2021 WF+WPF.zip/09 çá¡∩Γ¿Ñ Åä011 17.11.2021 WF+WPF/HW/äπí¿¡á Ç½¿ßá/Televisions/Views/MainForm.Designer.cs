﻿
namespace Televisions.Views
{
    partial class MainForm
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.MnsMain = new System.Windows.Forms.MenuStrip();
            this.MniFile = new System.Windows.Forms.ToolStripMenuItem();
            this.MniEdit = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripSeparator();
            this.сортировкаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.LbxTelevisions = new System.Windows.Forms.ListBox();
            this.LblTelevision = new System.Windows.Forms.Label();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.LblStatus = new System.Windows.Forms.ToolStripStatusLabel();
            this.LblName = new System.Windows.Forms.Label();
            this.LblAddress = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.выбратьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.справкаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.оПрограммеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.CmsLbxTelevisions = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripMenuItem4 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripMenuItem5 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripMenuItem6 = new System.Windows.Forms.ToolStripSeparator();
            this.оПрограммеToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.CmnMain = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.toolStripMenuItem20 = new System.Windows.Forms.ToolStripMenuItem();
            this.CmsMain = new System.Windows.Forms.ToolStripMenuItem();
            this.новаяКоллекцияToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.сортировкаToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.поПроизводителюИТипуToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.поУбываниюДиагоналиЭкранаToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.поМастеруВыполняющемуРемонтToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.поВладельцуТелевизораToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.добавитьТелевизорToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.редактироватьТелевизорToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.выбратьToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.сМинимальнойСтоимостьюРемонтаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ремонтируемыеВыбраннымМастеромToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.сЗаданнойДиагональюЭкранаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.выходToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.TsbGenerate = new System.Windows.Forms.ToolStripButton();
            this.TsbEditRepairShop = new System.Windows.Forms.ToolStripButton();
            this.TsbOrder = new System.Windows.Forms.ToolStripSplitButton();
            this.MniByBrand = new System.Windows.Forms.ToolStripMenuItem();
            this.MniByScreen = new System.Windows.Forms.ToolStripMenuItem();
            this.MniByMaster = new System.Windows.Forms.ToolStripMenuItem();
            this.MniByOwner = new System.Windows.Forms.ToolStripMenuItem();
            this.TsbAddTelevision = new System.Windows.Forms.ToolStripButton();
            this.TsbEdit = new System.Windows.Forms.ToolStripButton();
            this.TsbSelect = new System.Windows.Forms.ToolStripSplitButton();
            this.ByMinCost = new System.Windows.Forms.ToolStripMenuItem();
            this.ByMaster = new System.Windows.Forms.ToolStripMenuItem();
            this.ByScreen = new System.Windows.Forms.ToolStripMenuItem();
            this.MniExit = new System.Windows.Forms.ToolStripMenuItem();
            this.MniNewCollection = new System.Windows.Forms.ToolStripMenuItem();
            this.добавитьТелевизорToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.MniEditTelevision = new System.Windows.Forms.ToolStripMenuItem();
            this.редактироватьДанныеМастерскойToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.поПроизводителюИТипуToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.поУбываниюДиагоналиЭкранаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.поМастеруВыполняющемуРемонтToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.поВладельцуТелевизораToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.телевизорыToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.телевизорыToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.телевизорыToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.редактироватьДанныеМастерскойToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.MnsMain.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.CmsLbxTelevisions.SuspendLayout();
            this.CmnMain.SuspendLayout();
            this.SuspendLayout();
            // 
            // MnsMain
            // 
            this.MnsMain.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.MnsMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniFile,
            this.MniEdit,
            this.сортировкаToolStripMenuItem,
            this.выбратьToolStripMenuItem,
            this.справкаToolStripMenuItem});
            this.MnsMain.Location = new System.Drawing.Point(0, 0);
            this.MnsMain.Name = "MnsMain";
            this.MnsMain.Size = new System.Drawing.Size(800, 27);
            this.MnsMain.TabIndex = 0;
            this.MnsMain.Text = "menuStrip1";
            // 
            // MniFile
            // 
            this.MniFile.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniExit});
            this.MniFile.Name = "MniFile";
            this.MniFile.Size = new System.Drawing.Size(59, 23);
            this.MniFile.Text = "&Файл";
            // 
            // MniEdit
            // 
            this.MniEdit.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniNewCollection,
            this.toolStripMenuItem1,
            this.добавитьТелевизорToolStripMenuItem,
            this.toolStripMenuItem2,
            this.MniEditTelevision,
            this.редактироватьДанныеМастерскойToolStripMenuItem});
            this.MniEdit.Name = "MniEdit";
            this.MniEdit.Size = new System.Drawing.Size(73, 23);
            this.MniEdit.Text = "Правка";
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(346, 6);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(346, 6);
            // 
            // сортировкаToolStripMenuItem
            // 
            this.сортировкаToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.поПроизводителюИТипуToolStripMenuItem,
            this.поУбываниюДиагоналиЭкранаToolStripMenuItem,
            this.поМастеруВыполняющемуРемонтToolStripMenuItem,
            this.поВладельцуТелевизораToolStripMenuItem});
            this.сортировкаToolStripMenuItem.Name = "сортировкаToolStripMenuItem";
            this.сортировкаToolStripMenuItem.Size = new System.Drawing.Size(108, 23);
            this.сортировкаToolStripMenuItem.Text = "Сортировка";
            // 
            // toolStrip1
            // 
            this.toolStrip1.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.TsbGenerate,
            this.TsbEditRepairShop,
            this.toolStripSeparator1,
            this.TsbOrder,
            this.toolStripSeparator2,
            this.TsbAddTelevision,
            this.TsbEdit,
            this.toolStripSeparator3,
            this.TsbSelect});
            this.toolStrip1.Location = new System.Drawing.Point(0, 27);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(800, 37);
            this.toolStrip1.TabIndex = 1;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 37);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 37);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(6, 37);
            // 
            // LbxTelevisions
            // 
            this.LbxTelevisions.ContextMenuStrip = this.CmsLbxTelevisions;
            this.LbxTelevisions.Font = new System.Drawing.Font("Consolas", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LbxTelevisions.FormattingEnabled = true;
            this.LbxTelevisions.ItemHeight = 15;
            this.LbxTelevisions.Location = new System.Drawing.Point(23, 141);
            this.LbxTelevisions.Name = "LbxTelevisions";
            this.LbxTelevisions.Size = new System.Drawing.Size(754, 289);
            this.LbxTelevisions.TabIndex = 3;
            // 
            // LblTelevision
            // 
            this.LblTelevision.BackColor = System.Drawing.Color.Gainsboro;
            this.LblTelevision.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.LblTelevision.Font = new System.Drawing.Font("Consolas", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblTelevision.Location = new System.Drawing.Point(23, 123);
            this.LblTelevision.Name = "LblTelevision";
            this.LblTelevision.Size = new System.Drawing.Size(754, 40);
            this.LblTelevision.TabIndex = 4;
            this.LblTelevision.Text = "|    Tелевизор    | Диагональ экрана |        Мастер        |       Владелец     " +
    "  | Стоимость ремонта |\r\n";
            // 
            // statusStrip1
            // 
            this.statusStrip1.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.LblStatus});
            this.statusStrip1.Location = new System.Drawing.Point(0, 460);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(800, 24);
            this.statusStrip1.TabIndex = 2;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // LblStatus
            // 
            this.LblStatus.AutoSize = false;
            this.LblStatus.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblStatus.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.LblStatus.Name = "LblStatus";
            this.LblStatus.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.LblStatus.Size = new System.Drawing.Size(760, 19);
            this.LblStatus.Text = "toolStripStatusLabel1";
            this.LblStatus.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // LblName
            // 
            this.LblName.AutoSize = true;
            this.LblName.Font = new System.Drawing.Font("Consolas", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblName.Location = new System.Drawing.Point(3, 6);
            this.LblName.Name = "LblName";
            this.LblName.Size = new System.Drawing.Size(40, 18);
            this.LblName.TabIndex = 5;
            this.LblName.Text = "Name";
            // 
            // LblAddress
            // 
            this.LblAddress.AutoSize = true;
            this.LblAddress.Font = new System.Drawing.Font("Consolas", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblAddress.Location = new System.Drawing.Point(3, 26);
            this.LblAddress.Name = "LblAddress";
            this.LblAddress.Size = new System.Drawing.Size(64, 18);
            this.LblAddress.TabIndex = 6;
            this.LblAddress.Text = "Address";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel1.Controls.Add(this.LblAddress);
            this.panel1.Controls.Add(this.LblName);
            this.panel1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.panel1.Location = new System.Drawing.Point(23, 68);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(754, 46);
            this.panel1.TabIndex = 7;
            // 
            // выбратьToolStripMenuItem
            // 
            this.выбратьToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.телевизорыToolStripMenuItem,
            this.телевизорыToolStripMenuItem1,
            this.телевизорыToolStripMenuItem2});
            this.выбратьToolStripMenuItem.Name = "выбратьToolStripMenuItem";
            this.выбратьToolStripMenuItem.Size = new System.Drawing.Size(83, 23);
            this.выбратьToolStripMenuItem.Text = "Выбрать";
            // 
            // справкаToolStripMenuItem
            // 
            this.справкаToolStripMenuItem.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.справкаToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.оПрограммеToolStripMenuItem});
            this.справкаToolStripMenuItem.Name = "справкаToolStripMenuItem";
            this.справкаToolStripMenuItem.Size = new System.Drawing.Size(81, 23);
            this.справкаToolStripMenuItem.Text = "Справка";
            // 
            // оПрограммеToolStripMenuItem
            // 
            this.оПрограммеToolStripMenuItem.Name = "оПрограммеToolStripMenuItem";
            this.оПрограммеToolStripMenuItem.Size = new System.Drawing.Size(189, 24);
            this.оПрограммеToolStripMenuItem.Text = "О программе...";
            this.оПрограммеToolStripMenuItem.Click += new System.EventHandler(this.About_Command);
            // 
            // CmsLbxTelevisions
            // 
            this.CmsLbxTelevisions.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.новаяКоллекцияToolStripMenuItem,
            this.toolStripMenuItem3,
            this.сортировкаToolStripMenuItem1,
            this.toolStripMenuItem4,
            this.добавитьТелевизорToolStripMenuItem1,
            this.редактироватьТелевизорToolStripMenuItem,
            this.редактироватьДанныеМастерскойToolStripMenuItem1,
            this.toolStripMenuItem5,
            this.выбратьToolStripMenuItem1,
            this.toolStripMenuItem6,
            this.выходToolStripMenuItem,
            this.оПрограммеToolStripMenuItem1});
            this.CmsLbxTelevisions.Name = "CmsLbxTelevisions";
            this.CmsLbxTelevisions.Size = new System.Drawing.Size(276, 204);
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(272, 6);
            // 
            // toolStripMenuItem4
            // 
            this.toolStripMenuItem4.Name = "toolStripMenuItem4";
            this.toolStripMenuItem4.Size = new System.Drawing.Size(272, 6);
            // 
            // toolStripMenuItem5
            // 
            this.toolStripMenuItem5.Name = "toolStripMenuItem5";
            this.toolStripMenuItem5.Size = new System.Drawing.Size(272, 6);
            // 
            // toolStripMenuItem6
            // 
            this.toolStripMenuItem6.Name = "toolStripMenuItem6";
            this.toolStripMenuItem6.Size = new System.Drawing.Size(272, 6);
            // 
            // оПрограммеToolStripMenuItem1
            // 
            this.оПрограммеToolStripMenuItem1.Name = "оПрограммеToolStripMenuItem1";
            this.оПрограммеToolStripMenuItem1.Size = new System.Drawing.Size(275, 22);
            this.оПрограммеToolStripMenuItem1.Text = "О программе...";
            this.оПрограммеToolStripMenuItem1.Click += new System.EventHandler(this.About_Command);
            // 
            // CmnMain
            // 
            this.CmnMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.CmsMain,
            this.toolStripMenuItem20});
            this.CmnMain.Name = "CmsLbxTelevisions";
            this.CmnMain.Size = new System.Drawing.Size(159, 48);
            // 
            // toolStripMenuItem20
            // 
            this.toolStripMenuItem20.Name = "toolStripMenuItem20";
            this.toolStripMenuItem20.Size = new System.Drawing.Size(158, 22);
            this.toolStripMenuItem20.Text = "О программе...";
            // 
            // CmsMain
            // 
            this.CmsMain.Image = global::Televisions.Properties.Resources.exit;
            this.CmsMain.Name = "CmsMain";
            this.CmsMain.Size = new System.Drawing.Size(158, 22);
            this.CmsMain.Text = "Выход";
            // 
            // новаяКоллекцияToolStripMenuItem
            // 
            this.новаяКоллекцияToolStripMenuItem.Image = global::Televisions.Properties.Resources.Create;
            this.новаяКоллекцияToolStripMenuItem.Name = "новаяКоллекцияToolStripMenuItem";
            this.новаяКоллекцияToolStripMenuItem.Size = new System.Drawing.Size(275, 22);
            this.новаяКоллекцияToolStripMenuItem.Text = "Новая коллекция";
            this.новаяКоллекцияToolStripMenuItem.Click += new System.EventHandler(this.Generate_Command);
            // 
            // сортировкаToolStripMenuItem1
            // 
            this.сортировкаToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.поПроизводителюИТипуToolStripMenuItem1,
            this.поУбываниюДиагоналиЭкранаToolStripMenuItem1,
            this.поМастеруВыполняющемуРемонтToolStripMenuItem1,
            this.поВладельцуТелевизораToolStripMenuItem1});
            this.сортировкаToolStripMenuItem1.Image = global::Televisions.Properties.Resources.OrderBy;
            this.сортировкаToolStripMenuItem1.Name = "сортировкаToolStripMenuItem1";
            this.сортировкаToolStripMenuItem1.Size = new System.Drawing.Size(275, 22);
            this.сортировкаToolStripMenuItem1.Text = "Сортировка";
            // 
            // поПроизводителюИТипуToolStripMenuItem1
            // 
            this.поПроизводителюИТипуToolStripMenuItem1.Image = global::Televisions.Properties.Resources.name;
            this.поПроизводителюИТипуToolStripMenuItem1.Name = "поПроизводителюИТипуToolStripMenuItem1";
            this.поПроизводителюИТипуToolStripMenuItem1.Size = new System.Drawing.Size(279, 22);
            this.поПроизводителюИТипуToolStripMenuItem1.Text = "По производителю и типу";
            this.поПроизводителюИТипуToolStripMenuItem1.Click += new System.EventHandler(this.OrderByBrand_Command);
            // 
            // поУбываниюДиагоналиЭкранаToolStripMenuItem1
            // 
            this.поУбываниюДиагоналиЭкранаToolStripMenuItem1.Image = global::Televisions.Properties.Resources.Screen;
            this.поУбываниюДиагоналиЭкранаToolStripMenuItem1.Name = "поУбываниюДиагоналиЭкранаToolStripMenuItem1";
            this.поУбываниюДиагоналиЭкранаToolStripMenuItem1.Size = new System.Drawing.Size(279, 22);
            this.поУбываниюДиагоналиЭкранаToolStripMenuItem1.Text = "По убыванию диагонали экрана";
            this.поУбываниюДиагоналиЭкранаToolStripMenuItem1.Click += new System.EventHandler(this.OrderByScreen_Command);
            // 
            // поМастеруВыполняющемуРемонтToolStripMenuItem1
            // 
            this.поМастеруВыполняющемуРемонтToolStripMenuItem1.Image = global::Televisions.Properties.Resources.Master;
            this.поМастеруВыполняющемуРемонтToolStripMenuItem1.Name = "поМастеруВыполняющемуРемонтToolStripMenuItem1";
            this.поМастеруВыполняющемуРемонтToolStripMenuItem1.Size = new System.Drawing.Size(279, 22);
            this.поМастеруВыполняющемуРемонтToolStripMenuItem1.Text = "По мастеру, выполняющему ремонт";
            this.поМастеруВыполняющемуРемонтToolStripMenuItem1.Click += new System.EventHandler(this.OrderByMaster_Command);
            // 
            // поВладельцуТелевизораToolStripMenuItem1
            // 
            this.поВладельцуТелевизораToolStripMenuItem1.Image = global::Televisions.Properties.Resources.Owner;
            this.поВладельцуТелевизораToolStripMenuItem1.Name = "поВладельцуТелевизораToolStripMenuItem1";
            this.поВладельцуТелевизораToolStripMenuItem1.Size = new System.Drawing.Size(279, 22);
            this.поВладельцуТелевизораToolStripMenuItem1.Text = "По владельцу телевизора";
            this.поВладельцуТелевизораToolStripMenuItem1.Click += new System.EventHandler(this.OrderByOwner_Command);
            // 
            // добавитьТелевизорToolStripMenuItem1
            // 
            this.добавитьТелевизорToolStripMenuItem1.Image = global::Televisions.Properties.Resources.Add;
            this.добавитьТелевизорToolStripMenuItem1.Name = "добавитьТелевизорToolStripMenuItem1";
            this.добавитьТелевизорToolStripMenuItem1.Size = new System.Drawing.Size(275, 22);
            this.добавитьТелевизорToolStripMenuItem1.Text = "Добавить телевизор...";
            this.добавитьТелевизорToolStripMenuItem1.Click += new System.EventHandler(this.AddTelevision_Command);
            // 
            // редактироватьТелевизорToolStripMenuItem
            // 
            this.редактироватьТелевизорToolStripMenuItem.Image = global::Televisions.Properties.Resources.Edit;
            this.редактироватьТелевизорToolStripMenuItem.Name = "редактироватьТелевизорToolStripMenuItem";
            this.редактироватьТелевизорToolStripMenuItem.Size = new System.Drawing.Size(275, 22);
            this.редактироватьТелевизорToolStripMenuItem.Text = "Редактировать телевизор..";
            this.редактироватьТелевизорToolStripMenuItem.Click += new System.EventHandler(this.Edit_Command);
            // 
            // выбратьToolStripMenuItem1
            // 
            this.выбратьToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.сМинимальнойСтоимостьюРемонтаToolStripMenuItem,
            this.ремонтируемыеВыбраннымМастеромToolStripMenuItem,
            this.сЗаданнойДиагональюЭкранаToolStripMenuItem});
            this.выбратьToolStripMenuItem1.Image = global::Televisions.Properties.Resources.Select;
            this.выбратьToolStripMenuItem1.Name = "выбратьToolStripMenuItem1";
            this.выбратьToolStripMenuItem1.Size = new System.Drawing.Size(275, 22);
            this.выбратьToolStripMenuItem1.Text = "Выбрать";
            // 
            // сМинимальнойСтоимостьюРемонтаToolStripMenuItem
            // 
            this.сМинимальнойСтоимостьюРемонтаToolStripMenuItem.Image = global::Televisions.Properties.Resources.Cost;
            this.сМинимальнойСтоимостьюРемонтаToolStripMenuItem.Name = "сМинимальнойСтоимостьюРемонтаToolStripMenuItem";
            this.сМинимальнойСтоимостьюРемонтаToolStripMenuItem.Size = new System.Drawing.Size(293, 22);
            this.сМинимальнойСтоимостьюРемонтаToolStripMenuItem.Text = "с минимальной стоимостью ремонта";
            this.сМинимальнойСтоимостьюРемонтаToolStripMenuItem.Click += new System.EventHandler(this.SelectByMinCost_Command);
            // 
            // ремонтируемыеВыбраннымМастеромToolStripMenuItem
            // 
            this.ремонтируемыеВыбраннымМастеромToolStripMenuItem.Image = global::Televisions.Properties.Resources.Master;
            this.ремонтируемыеВыбраннымМастеромToolStripMenuItem.Name = "ремонтируемыеВыбраннымМастеромToolStripMenuItem";
            this.ремонтируемыеВыбраннымМастеромToolStripMenuItem.Size = new System.Drawing.Size(293, 22);
            this.ремонтируемыеВыбраннымМастеромToolStripMenuItem.Text = "ремонтируемые выбранным мастером";
            this.ремонтируемыеВыбраннымМастеромToolStripMenuItem.Click += new System.EventHandler(this.SelectByMaster_Command);
            // 
            // сЗаданнойДиагональюЭкранаToolStripMenuItem
            // 
            this.сЗаданнойДиагональюЭкранаToolStripMenuItem.Image = global::Televisions.Properties.Resources.Screen;
            this.сЗаданнойДиагональюЭкранаToolStripMenuItem.Name = "сЗаданнойДиагональюЭкранаToolStripMenuItem";
            this.сЗаданнойДиагональюЭкранаToolStripMenuItem.Size = new System.Drawing.Size(293, 22);
            this.сЗаданнойДиагональюЭкранаToolStripMenuItem.Text = "с заданной диагональю экрана";
            this.сЗаданнойДиагональюЭкранаToolStripMenuItem.Click += new System.EventHandler(this.SelectByScreen_Command);
            // 
            // выходToolStripMenuItem
            // 
            this.выходToolStripMenuItem.Image = global::Televisions.Properties.Resources.exit;
            this.выходToolStripMenuItem.Name = "выходToolStripMenuItem";
            this.выходToolStripMenuItem.Size = new System.Drawing.Size(275, 22);
            this.выходToolStripMenuItem.Text = "Выход";
            this.выходToolStripMenuItem.Click += new System.EventHandler(this.Exit_Command);
            // 
            // TsbGenerate
            // 
            this.TsbGenerate.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbGenerate.Image = global::Televisions.Properties.Resources.Create;
            this.TsbGenerate.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbGenerate.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbGenerate.Name = "TsbGenerate";
            this.TsbGenerate.Size = new System.Drawing.Size(34, 34);
            this.TsbGenerate.Text = "toolStripButton1";
            this.TsbGenerate.ToolTipText = "Начальное формирование данных ";
            this.TsbGenerate.Click += new System.EventHandler(this.Generate_Command);
            // 
            // TsbEditRepairShop
            // 
            this.TsbEditRepairShop.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbEditRepairShop.Image = global::Televisions.Properties.Resources.EditRepairShop;
            this.TsbEditRepairShop.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbEditRepairShop.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbEditRepairShop.Name = "TsbEditRepairShop";
            this.TsbEditRepairShop.Size = new System.Drawing.Size(34, 34);
            this.TsbEditRepairShop.Text = "toolStripButton1";
            this.TsbEditRepairShop.ToolTipText = "Редактировать данные мастерской";
            this.TsbEditRepairShop.Click += new System.EventHandler(this.EditRepairShop_Command);
            // 
            // TsbOrder
            // 
            this.TsbOrder.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbOrder.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniByBrand,
            this.MniByScreen,
            this.MniByMaster,
            this.MniByOwner});
            this.TsbOrder.Image = global::Televisions.Properties.Resources.OrderBy;
            this.TsbOrder.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbOrder.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbOrder.Name = "TsbOrder";
            this.TsbOrder.Size = new System.Drawing.Size(46, 34);
            this.TsbOrder.Text = "toolStripSplitButton1";
            this.TsbOrder.ToolTipText = "Упорядочть коллекцию телевизоров";
            this.TsbOrder.ButtonClick += new System.EventHandler(this.OrderByBrand_Command);
            // 
            // MniByBrand
            // 
            this.MniByBrand.Image = global::Televisions.Properties.Resources.name;
            this.MniByBrand.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MniByBrand.Name = "MniByBrand";
            this.MniByBrand.Size = new System.Drawing.Size(357, 36);
            this.MniByBrand.Text = "По производителю и типу";
            this.MniByBrand.Click += new System.EventHandler(this.OrderByBrand_Command);
            // 
            // MniByScreen
            // 
            this.MniByScreen.Image = global::Televisions.Properties.Resources.Screen;
            this.MniByScreen.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MniByScreen.Name = "MniByScreen";
            this.MniByScreen.Size = new System.Drawing.Size(357, 36);
            this.MniByScreen.Text = "По убыванию диагонали экрана";
            this.MniByScreen.Click += new System.EventHandler(this.OrderByScreen_Command);
            // 
            // MniByMaster
            // 
            this.MniByMaster.Image = global::Televisions.Properties.Resources.Master;
            this.MniByMaster.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MniByMaster.Name = "MniByMaster";
            this.MniByMaster.Size = new System.Drawing.Size(357, 36);
            this.MniByMaster.Text = "По мастеру, выполняющему ремонт";
            this.MniByMaster.Click += new System.EventHandler(this.OrderByMaster_Command);
            // 
            // MniByOwner
            // 
            this.MniByOwner.Image = global::Televisions.Properties.Resources.Owner;
            this.MniByOwner.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MniByOwner.Name = "MniByOwner";
            this.MniByOwner.Size = new System.Drawing.Size(357, 36);
            this.MniByOwner.Text = "По владельцу телевизора";
            this.MniByOwner.Click += new System.EventHandler(this.OrderByOwner_Command);
            // 
            // TsbAddTelevision
            // 
            this.TsbAddTelevision.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbAddTelevision.Image = global::Televisions.Properties.Resources.Add;
            this.TsbAddTelevision.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbAddTelevision.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbAddTelevision.Name = "TsbAddTelevision";
            this.TsbAddTelevision.Size = new System.Drawing.Size(34, 34);
            this.TsbAddTelevision.Text = "toolStripButton1";
            this.TsbAddTelevision.ToolTipText = "Добавить телевизор";
            this.TsbAddTelevision.Click += new System.EventHandler(this.AddTelevision_Command);
            // 
            // TsbEdit
            // 
            this.TsbEdit.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbEdit.Image = global::Televisions.Properties.Resources.Edit;
            this.TsbEdit.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbEdit.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbEdit.Name = "TsbEdit";
            this.TsbEdit.Size = new System.Drawing.Size(34, 34);
            this.TsbEdit.Text = "toolStripButton1";
            this.TsbEdit.ToolTipText = "Редактировать выбранный телевизор ";
            this.TsbEdit.Click += new System.EventHandler(this.Edit_Command);
            // 
            // TsbSelect
            // 
            this.TsbSelect.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbSelect.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ByMinCost,
            this.ByMaster,
            this.ByScreen});
            this.TsbSelect.Image = global::Televisions.Properties.Resources.Select;
            this.TsbSelect.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbSelect.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbSelect.Name = "TsbSelect";
            this.TsbSelect.Size = new System.Drawing.Size(46, 34);
            this.TsbSelect.Text = "toolStripSplitButton1";
            this.TsbSelect.ToolTipText = "Выбрать телевизоры ";
            // 
            // ByMinCost
            // 
            this.ByMinCost.Image = global::Televisions.Properties.Resources.Cost;
            this.ByMinCost.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.ByMinCost.Name = "ByMinCost";
            this.ByMinCost.Size = new System.Drawing.Size(371, 36);
            this.ByMinCost.Text = "с минимальной стоимостью ремонта";
            this.ByMinCost.Click += new System.EventHandler(this.SelectByMinCost_Command);
            // 
            // ByMaster
            // 
            this.ByMaster.Image = global::Televisions.Properties.Resources.Master;
            this.ByMaster.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.ByMaster.Name = "ByMaster";
            this.ByMaster.Size = new System.Drawing.Size(371, 36);
            this.ByMaster.Text = "ремонтируемые выбранным мастером";
            this.ByMaster.Click += new System.EventHandler(this.SelectByMaster_Command);
            // 
            // ByScreen
            // 
            this.ByScreen.Image = global::Televisions.Properties.Resources.Screen;
            this.ByScreen.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.ByScreen.Name = "ByScreen";
            this.ByScreen.Size = new System.Drawing.Size(371, 36);
            this.ByScreen.Text = "с заданной диагональю экрана";
            this.ByScreen.Click += new System.EventHandler(this.SelectByScreen_Command);
            // 
            // MniExit
            // 
            this.MniExit.Image = global::Televisions.Properties.Resources.exit;
            this.MniExit.Name = "MniExit";
            this.MniExit.Size = new System.Drawing.Size(124, 24);
            this.MniExit.Text = "Выход";
            this.MniExit.Click += new System.EventHandler(this.Exit_Command);
            // 
            // MniNewCollection
            // 
            this.MniNewCollection.Image = global::Televisions.Properties.Resources.Create;
            this.MniNewCollection.Name = "MniNewCollection";
            this.MniNewCollection.Size = new System.Drawing.Size(349, 24);
            this.MniNewCollection.Text = "Новая коллекция";
            this.MniNewCollection.Click += new System.EventHandler(this.Generate_Command);
            // 
            // добавитьТелевизорToolStripMenuItem
            // 
            this.добавитьТелевизорToolStripMenuItem.Image = global::Televisions.Properties.Resources.Add;
            this.добавитьТелевизорToolStripMenuItem.Name = "добавитьТелевизорToolStripMenuItem";
            this.добавитьТелевизорToolStripMenuItem.Size = new System.Drawing.Size(349, 24);
            this.добавитьТелевизорToolStripMenuItem.Text = "Добавить телевизор...";
            this.добавитьТелевизорToolStripMenuItem.Click += new System.EventHandler(this.AddTelevision_Command);
            // 
            // MniEditTelevision
            // 
            this.MniEditTelevision.Image = global::Televisions.Properties.Resources.Edit;
            this.MniEditTelevision.Name = "MniEditTelevision";
            this.MniEditTelevision.Size = new System.Drawing.Size(349, 24);
            this.MniEditTelevision.Text = "Редактировать телевизор...";
            this.MniEditTelevision.Click += new System.EventHandler(this.Edit_Command);
            // 
            // редактироватьДанныеМастерскойToolStripMenuItem
            // 
            this.редактироватьДанныеМастерскойToolStripMenuItem.Image = global::Televisions.Properties.Resources.EditRepairShop;
            this.редактироватьДанныеМастерскойToolStripMenuItem.Name = "редактироватьДанныеМастерскойToolStripMenuItem";
            this.редактироватьДанныеМастерскойToolStripMenuItem.Size = new System.Drawing.Size(349, 24);
            this.редактироватьДанныеМастерскойToolStripMenuItem.Text = "Редактировать данные мастерской...";
            this.редактироватьДанныеМастерскойToolStripMenuItem.Click += new System.EventHandler(this.EditRepairShop_Command);
            // 
            // поПроизводителюИТипуToolStripMenuItem
            // 
            this.поПроизводителюИТипуToolStripMenuItem.Image = global::Televisions.Properties.Resources.name;
            this.поПроизводителюИТипуToolStripMenuItem.Name = "поПроизводителюИТипуToolStripMenuItem";
            this.поПроизводителюИТипуToolStripMenuItem.Size = new System.Drawing.Size(343, 24);
            this.поПроизводителюИТипуToolStripMenuItem.Text = "По производителю и типу";
            this.поПроизводителюИТипуToolStripMenuItem.Click += new System.EventHandler(this.OrderByBrand_Command);
            // 
            // поУбываниюДиагоналиЭкранаToolStripMenuItem
            // 
            this.поУбываниюДиагоналиЭкранаToolStripMenuItem.Image = global::Televisions.Properties.Resources.Screen;
            this.поУбываниюДиагоналиЭкранаToolStripMenuItem.Name = "поУбываниюДиагоналиЭкранаToolStripMenuItem";
            this.поУбываниюДиагоналиЭкранаToolStripMenuItem.Size = new System.Drawing.Size(343, 24);
            this.поУбываниюДиагоналиЭкранаToolStripMenuItem.Text = "По убыванию диагонали экрана";
            this.поУбываниюДиагоналиЭкранаToolStripMenuItem.Click += new System.EventHandler(this.OrderByScreen_Command);
            // 
            // поМастеруВыполняющемуРемонтToolStripMenuItem
            // 
            this.поМастеруВыполняющемуРемонтToolStripMenuItem.Image = global::Televisions.Properties.Resources.Master;
            this.поМастеруВыполняющемуРемонтToolStripMenuItem.Name = "поМастеруВыполняющемуРемонтToolStripMenuItem";
            this.поМастеруВыполняющемуРемонтToolStripMenuItem.Size = new System.Drawing.Size(343, 24);
            this.поМастеруВыполняющемуРемонтToolStripMenuItem.Text = "По мастеру, выполняющему ремонт";
            this.поМастеруВыполняющемуРемонтToolStripMenuItem.Click += new System.EventHandler(this.OrderByMaster_Command);
            // 
            // поВладельцуТелевизораToolStripMenuItem
            // 
            this.поВладельцуТелевизораToolStripMenuItem.Image = global::Televisions.Properties.Resources.Owner;
            this.поВладельцуТелевизораToolStripMenuItem.Name = "поВладельцуТелевизораToolStripMenuItem";
            this.поВладельцуТелевизораToolStripMenuItem.Size = new System.Drawing.Size(343, 24);
            this.поВладельцуТелевизораToolStripMenuItem.Text = "По владельцу телевизора";
            this.поВладельцуТелевизораToolStripMenuItem.Click += new System.EventHandler(this.OrderByOwner_Command);
            // 
            // телевизорыToolStripMenuItem
            // 
            this.телевизорыToolStripMenuItem.Image = global::Televisions.Properties.Resources.Cost;
            this.телевизорыToolStripMenuItem.Name = "телевизорыToolStripMenuItem";
            this.телевизорыToolStripMenuItem.Size = new System.Drawing.Size(455, 24);
            this.телевизорыToolStripMenuItem.Text = "Телевизоры с минимальной стоимостью ремонта";
            this.телевизорыToolStripMenuItem.Click += new System.EventHandler(this.SelectByMinCost_Command);
            // 
            // телевизорыToolStripMenuItem1
            // 
            this.телевизорыToolStripMenuItem1.Image = global::Televisions.Properties.Resources.Master;
            this.телевизорыToolStripMenuItem1.Name = "телевизорыToolStripMenuItem1";
            this.телевизорыToolStripMenuItem1.Size = new System.Drawing.Size(455, 24);
            this.телевизорыToolStripMenuItem1.Text = "Телевизоры, ремонтируемые выбранным мастером";
            this.телевизорыToolStripMenuItem1.Click += new System.EventHandler(this.SelectByMaster_Command);
            // 
            // телевизорыToolStripMenuItem2
            // 
            this.телевизорыToolStripMenuItem2.Image = global::Televisions.Properties.Resources.Screen;
            this.телевизорыToolStripMenuItem2.Name = "телевизорыToolStripMenuItem2";
            this.телевизорыToolStripMenuItem2.Size = new System.Drawing.Size(455, 24);
            this.телевизорыToolStripMenuItem2.Text = "Телевизоры, с заданной диагональю экрана";
            this.телевизорыToolStripMenuItem2.Click += new System.EventHandler(this.SelectByScreen_Command);
            // 
            // редактироватьДанныеМастерскойToolStripMenuItem1
            // 
            this.редактироватьДанныеМастерскойToolStripMenuItem1.Image = global::Televisions.Properties.Resources.EditRepairShop;
            this.редактироватьДанныеМастерскойToolStripMenuItem1.Name = "редактироватьДанныеМастерскойToolStripMenuItem1";
            this.редактироватьДанныеМастерскойToolStripMenuItem1.Size = new System.Drawing.Size(275, 22);
            this.редактироватьДанныеМастерскойToolStripMenuItem1.Text = "Редактировать данные мастерской...";
            this.редактироватьДанныеМастерскойToolStripMenuItem1.Click += new System.EventHandler(this.EditRepairShop_Command);
            // 
            // MainForm
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.Gainsboro;
            this.ClientSize = new System.Drawing.Size(800, 484);
            this.ContextMenuStrip = this.CmnMain;
            this.Controls.Add(this.LbxTelevisions);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.MnsMain);
            this.Controls.Add(this.LblTelevision);
            this.Controls.Add(this.panel1);
            this.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.MnsMain;
            this.MaximizeBox = false;
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Задание на 17.11.2021";
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.MnsMain.ResumeLayout(false);
            this.MnsMain.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.CmsLbxTelevisions.ResumeLayout(false);
            this.CmnMain.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip MnsMain;
        private System.Windows.Forms.ToolStripMenuItem MniFile;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ListBox LbxTelevisions;
        private System.Windows.Forms.Label LblTelevision;
        private System.Windows.Forms.ToolStripButton TsbGenerate;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripSplitButton TsbOrder;
        private System.Windows.Forms.ToolStripMenuItem MniByBrand;
        private System.Windows.Forms.ToolStripMenuItem MniByScreen;
        private System.Windows.Forms.ToolStripMenuItem MniByMaster;
        private System.Windows.Forms.ToolStripMenuItem MniByOwner;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel LblStatus;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripButton TsbAddTelevision;
        private System.Windows.Forms.ToolStripButton TsbEdit;
        private System.Windows.Forms.Label LblName;
        private System.Windows.Forms.Label LblAddress;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripSplitButton TsbSelect;
        private System.Windows.Forms.ToolStripMenuItem ByMinCost;
        private System.Windows.Forms.ToolStripMenuItem ByMaster;
        private System.Windows.Forms.ToolStripMenuItem ByScreen;
        private System.Windows.Forms.ToolStripMenuItem MniExit;
        private System.Windows.Forms.ToolStripMenuItem MniEdit;
        private System.Windows.Forms.ToolStripMenuItem MniNewCollection;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem добавитьТелевизорToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem MniEditTelevision;
        private System.Windows.Forms.ToolStripMenuItem редактироватьДанныеМастерскойToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem сортировкаToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem поПроизводителюИТипуToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem поУбываниюДиагоналиЭкранаToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem поМастеруВыполняющемуРемонтToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem поВладельцуТелевизораToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem выбратьToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem телевизорыToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem телевизорыToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem телевизорыToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem справкаToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem оПрограммеToolStripMenuItem;
        private System.Windows.Forms.ContextMenuStrip CmsLbxTelevisions;
        private System.Windows.Forms.ToolStripMenuItem новаяКоллекцияToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem сортировкаToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem поПроизводителюИТипуToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem поУбываниюДиагоналиЭкранаToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem поМастеруВыполняющемуРемонтToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem поВладельцуТелевизораToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem добавитьТелевизорToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem редактироватьТелевизорToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem выбратьToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem сМинимальнойСтоимостьюРемонтаToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem3;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem4;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem5;
        private System.Windows.Forms.ToolStripMenuItem ремонтируемыеВыбраннымМастеромToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem сЗаданнойДиагональюЭкранаToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem6;
        private System.Windows.Forms.ToolStripMenuItem выходToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem оПрограммеToolStripMenuItem1;
        private System.Windows.Forms.ContextMenuStrip CmnMain;
        private System.Windows.Forms.ToolStripMenuItem CmsMain;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem20;
        private System.Windows.Forms.ToolStripButton TsbEditRepairShop;
        private System.Windows.Forms.ToolStripMenuItem редактироватьДанныеМастерскойToolStripMenuItem1;
    }
}

