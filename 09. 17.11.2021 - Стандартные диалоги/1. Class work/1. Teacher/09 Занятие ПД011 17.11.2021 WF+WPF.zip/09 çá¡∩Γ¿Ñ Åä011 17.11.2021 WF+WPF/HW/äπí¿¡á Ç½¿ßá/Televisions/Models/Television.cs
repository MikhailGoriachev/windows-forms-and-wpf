﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Televisions.Helpers;


namespace Televisions.Models
{
    // Класс, описывающий телевизор содержит: производитель и тип телевизора,
    //                                        диагональ экрана,
    //                                        строка с описанием дефекта,
    //                                        фамилия и инициалами мастера,
    //                                        фамилия и инициалы владельца,
    //                                        стоимость ремонта
    public class Television {
        // производитель и тип телевизора
        private string _brand;
        public string Brand {
            get => _brand;
            set {
                if (string.IsNullOrEmpty(value))
                    throw new Exception("Пустая строка в производителе и типе телевизора");

                _brand = value;
            } // set
        } // Brand

        // диагональ экрана (дюймы)
        private int _screen;  
        public int Screen {
            get => _screen;
            set {
                if (value <= 0)
                    throw new Exception("Некорректное значение диагонали экрана!");

                _screen = value;
            } // set
        } // Screen

        // строка с описанием дефекта
        private string _defect;
        public string Defect {
            get => _defect;
            set {
                if (string.IsNullOrEmpty(value))
                    throw new Exception("Пустая строка в строкe с описанием дефектателевизора");

                _defect = value;
            } // set
        } // Brand

        // фамилия и инициалами мастера
        private string _master;
        public string Master {
            get => _master;
            set {
                if (string.IsNullOrEmpty(value))
                    throw new Exception("Пустая строка в фамилии и инициалах мастера");

                _master = value;
            } // set
        } // Master

        // фамилия и инициалы владельца
        private string _owner;
        public string Owner {
            get => _owner;
            set {
                if (string.IsNullOrEmpty(value))
                    throw new Exception("Пустая строка в фамилии и инициалах владельца");

                _owner = value;
            } // set
        } // Owner

        // стоимость ремонта
        private int _cost;
        public int Cost {
            get => _cost;
            set {
                if (value <= 0)
                    throw new Exception("Некорректное значение стоимости ремонта!");

                _cost = value;
            } // set
        } // Cost

        // формирование строки таблицы, свойство
        public string TableRow =>
            $"│ {_brand,-15} │ {_screen,10}\"      │ {_master,-20} │ " +
            $"{_owner,-20} │ {_cost, 10} руб.   │";


        // Фабричный метод для создания телевизора из случайных данных
        public static Television Generate() {
            // массив моделей
            string[] brands = new[] { "Samsung", "Sony", "Philips", "LG", "Xiaomi", "Nokia" };

            //массив дефектов
            string[] defects = new[] { "Проблемы с включением и выключением питания",
                                       "Неисправность матрицы",
                                       "Проблемы со звуком"};

            // массив фамилий и инициалов
            string[] names = new[] { "Семенов Б.В."  , "Семенова Р.Т." , "Дунаев О.Ю." , "Дунаева Г.Т.",
                                     "Харламова П.А.", "Харламов т.Р." , "Олегова В.Ф.", "Олегов В.Ф.",
                                     "Янковский Т.Р.", "Янковская О.Л.", "Абалкин Н.Р.", "Абалкина П.Р.",
                                     "Романова Р.Л." , "Воликов О.П."  , "Жукова Н.К." , "Соколов Р.Ж."};

            return new Television {
                Master = names[Utils.Random.Next(names.Length)],
                Owner  = names[Utils.Random.Next(names.Length)],
                _brand = brands[Utils.Random.Next(brands.Length)],
                _defect = defects[Utils.Random.Next(defects.Length)],
                _cost = Utils.Random.Next(1000, 12000),
                _screen = Utils.GetRandom(55, 60)
            };
        } // Generate

    } // Television
}
