﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Televisions.Models;

namespace Televisions.Views
{
    public partial class TelevisionForm : Form
    {
        private Television _television;
        public Television Television {
            get => _television;
            set {
                _television = value;

                // запись в элементы управления
                TbxOwner.Text = _television.Owner;
                TbxDefect.Text = _television.Defect;
                NudCost.Value = (decimal)_television.Cost;
                NudScreen.Value = (decimal)_television.Screen;

                // если не совпадает с имеющимися вариантами - добавить
                if (CbxBrand.Items.IndexOf(_television.Brand) < 0)
                    CbxBrand.Items.Add(_television.Brand);

                if (CbxMaster.Items.IndexOf(_television.Master) < 0)
                    CbxMaster.Items.Add(_television.Master);

                CbxBrand.Text = _television.Brand;
                CbxMaster.Text = _television.Master;

            } // set
        }

        public TelevisionForm() : this("Добавлить телевизор", "Добавить") { }
        public TelevisionForm(string title, string btnText) {
            InitializeComponent();
            _television = new Television();
            Text = title;
            BtnOk.Text = btnText;
            CbxMaster.SelectedIndex = 0;
            CbxBrand.SelectedIndex = 0;

            TbxDefect.Tag = ErpDefect;
            TbxOwner.Tag = ErpOwner;
        } // TelevisionForm

        private void BtnOk_Click(object sender, EventArgs e) {
            _television.Brand = CbxBrand.Text;
            _television.Cost = (int)NudCost.Value;
            _television.Screen = (int)NudScreen.Value;
            _television.Owner = TbxOwner.Text;
            _television.Master = CbxMaster.Text;
            _television.Defect = TbxDefect.Text;
        } // BtnOk_Click

        private void BtnCancel_Click(object sender, EventArgs e) => Close();

        private void Txb_Validated(object sender, EventArgs e) {
            TextBox tb = sender as TextBox;
            ErrorProvider erp = tb.Tag as ErrorProvider;
            if (String.IsNullOrEmpty(tb.Text)) {
                erp.SetError(tb, "Некорректный ввод!");
                BtnOk.Enabled = false;
            }
        } // Txb_Validated

        private void Tbx_TextChanged(object sender, EventArgs e) {
            TextBox tb = sender as TextBox;
            ErrorProvider erp = tb.Tag as ErrorProvider;
            erp.SetError(tb, "");

            if(!String.IsNullOrEmpty(TbxOwner.Text) && !String.IsNullOrEmpty(TbxDefect.Text))
                BtnOk.Enabled = true;
        } // Tbx_TextChanged
    }
}
