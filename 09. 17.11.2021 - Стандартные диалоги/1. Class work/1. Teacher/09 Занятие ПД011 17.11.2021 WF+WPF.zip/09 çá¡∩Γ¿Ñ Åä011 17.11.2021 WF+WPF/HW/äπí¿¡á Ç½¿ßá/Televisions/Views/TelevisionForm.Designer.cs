﻿
namespace Televisions.Views
{
    partial class TelevisionForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.BtnOk = new System.Windows.Forms.Button();
            this.BtnCancel = new System.Windows.Forms.Button();
            this.GrbTelevision = new System.Windows.Forms.GroupBox();
            this.LblBrand = new System.Windows.Forms.Label();
            this.CbxBrand = new System.Windows.Forms.ComboBox();
            this.LblDefect = new System.Windows.Forms.Label();
            this.LblScreen = new System.Windows.Forms.Label();
            this.NudScreen = new System.Windows.Forms.NumericUpDown();
            this.TbxDefect = new System.Windows.Forms.TextBox();
            this.ErpDefect = new System.Windows.Forms.ErrorProvider(this.components);
            this.CbxMaster = new System.Windows.Forms.ComboBox();
            this.LblMaster = new System.Windows.Forms.Label();
            this.TbxOwner = new System.Windows.Forms.TextBox();
            this.LblOwner = new System.Windows.Forms.Label();
            this.NudCost = new System.Windows.Forms.NumericUpDown();
            this.LblCost = new System.Windows.Forms.Label();
            this.ErpOwner = new System.Windows.Forms.ErrorProvider(this.components);
            this.colorDialog1 = new System.Windows.Forms.ColorDialog();
            this.GrbTelevision.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.NudScreen)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ErpDefect)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NudCost)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ErpOwner)).BeginInit();
            this.SuspendLayout();
            // 
            // BtnOk
            // 
            this.BtnOk.BackColor = System.Drawing.SystemColors.HotTrack;
            this.BtnOk.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.BtnOk.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.BtnOk.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.BtnOk.Location = new System.Drawing.Point(368, 347);
            this.BtnOk.Name = "BtnOk";
            this.BtnOk.Size = new System.Drawing.Size(133, 27);
            this.BtnOk.TabIndex = 0;
            this.BtnOk.UseVisualStyleBackColor = false;
            this.BtnOk.Click += new System.EventHandler(this.BtnOk_Click);
            // 
            // BtnCancel
            // 
            this.BtnCancel.BackColor = System.Drawing.SystemColors.HotTrack;
            this.BtnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.BtnCancel.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.BtnCancel.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.BtnCancel.Location = new System.Drawing.Point(513, 347);
            this.BtnCancel.Name = "BtnCancel";
            this.BtnCancel.Size = new System.Drawing.Size(133, 27);
            this.BtnCancel.TabIndex = 1;
            this.BtnCancel.Text = "Отмена";
            this.BtnCancel.UseVisualStyleBackColor = false;
            this.BtnCancel.Click += new System.EventHandler(this.BtnCancel_Click);
            // 
            // GrbTelevision
            // 
            this.GrbTelevision.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.GrbTelevision.Controls.Add(this.NudCost);
            this.GrbTelevision.Controls.Add(this.LblCost);
            this.GrbTelevision.Controls.Add(this.TbxOwner);
            this.GrbTelevision.Controls.Add(this.CbxMaster);
            this.GrbTelevision.Controls.Add(this.LblMaster);
            this.GrbTelevision.Controls.Add(this.TbxDefect);
            this.GrbTelevision.Controls.Add(this.NudScreen);
            this.GrbTelevision.Controls.Add(this.LblScreen);
            this.GrbTelevision.Controls.Add(this.LblDefect);
            this.GrbTelevision.Controls.Add(this.CbxBrand);
            this.GrbTelevision.Controls.Add(this.LblBrand);
            this.GrbTelevision.Controls.Add(this.LblOwner);
            this.GrbTelevision.Location = new System.Drawing.Point(12, 12);
            this.GrbTelevision.Name = "GrbTelevision";
            this.GrbTelevision.Size = new System.Drawing.Size(634, 329);
            this.GrbTelevision.TabIndex = 2;
            this.GrbTelevision.TabStop = false;
            this.GrbTelevision.Text = " Данные телевизора: ";
            // 
            // LblBrand
            // 
            this.LblBrand.AutoSize = true;
            this.LblBrand.Location = new System.Drawing.Point(19, 48);
            this.LblBrand.Name = "LblBrand";
            this.LblBrand.Size = new System.Drawing.Size(266, 19);
            this.LblBrand.TabIndex = 0;
            this.LblBrand.Text = "Производитель и тип телевизора: ";
            // 
            // CbxBrand
            // 
            this.CbxBrand.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CbxBrand.FormattingEnabled = true;
            this.CbxBrand.Items.AddRange(new object[] {
            "Samsung",
            "Sony",
            "Philips",
            "LG",
            "Xiaomi",
            "Nokia"});
            this.CbxBrand.Location = new System.Drawing.Point(291, 44);
            this.CbxBrand.Name = "CbxBrand";
            this.CbxBrand.Size = new System.Drawing.Size(198, 27);
            this.CbxBrand.TabIndex = 1;
            // 
            // LblDefect
            // 
            this.LblDefect.AutoSize = true;
            this.LblDefect.Location = new System.Drawing.Point(19, 125);
            this.LblDefect.Name = "LblDefect";
            this.LblDefect.Size = new System.Drawing.Size(152, 19);
            this.LblDefect.TabIndex = 2;
            this.LblDefect.Text = "Описание дефекта:";
            // 
            // LblScreen
            // 
            this.LblScreen.AutoSize = true;
            this.LblScreen.Location = new System.Drawing.Point(19, 85);
            this.LblScreen.Name = "LblScreen";
            this.LblScreen.Size = new System.Drawing.Size(221, 19);
            this.LblScreen.TabIndex = 4;
            this.LblScreen.Text = "Диагональ экрана (дюймы): ";
            // 
            // NudScreen
            // 
            this.NudScreen.Location = new System.Drawing.Point(291, 83);
            this.NudScreen.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.NudScreen.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.NudScreen.Name = "NudScreen";
            this.NudScreen.Size = new System.Drawing.Size(198, 27);
            this.NudScreen.TabIndex = 5;
            this.NudScreen.ThousandsSeparator = true;
            this.NudScreen.Value = new decimal(new int[] {
            55,
            0,
            0,
            0});
            // 
            // TbxDefect
            // 
            this.TbxDefect.Location = new System.Drawing.Point(291, 125);
            this.TbxDefect.Name = "TbxDefect";
            this.TbxDefect.Size = new System.Drawing.Size(198, 27);
            this.TbxDefect.TabIndex = 6;
            this.TbxDefect.Text = "Неисправность матрицы";
            this.TbxDefect.TextChanged += new System.EventHandler(this.Tbx_TextChanged);
            this.TbxDefect.Validated += new System.EventHandler(this.Txb_Validated);
            // 
            // ErpDefect
            // 
            this.ErpDefect.ContainerControl = this;
            // 
            // CbxMaster
            // 
            this.CbxMaster.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CbxMaster.FormattingEnabled = true;
            this.CbxMaster.Items.AddRange(new object[] {
            "Семенов Б.В",
            "Семенова Р.Т.",
            "Дунаев О.Ю.",
            "Дунаева Г.Т",
            " Харламова П.А.",
            "Харламов т.Р.",
            "Олегова В.Ф.",
            "Олегов В.Ф.",
            "Янковский Т.Р.",
            "Янковская О.Л.",
            "Абалкин Н.Р.",
            "Абалкина П.Р.",
            "Романова Р.Л.",
            "Воликов О.П.",
            "Жукова Н.К.",
            "Соколов Р.Ж."});
            this.CbxMaster.Location = new System.Drawing.Point(291, 169);
            this.CbxMaster.Name = "CbxMaster";
            this.CbxMaster.Size = new System.Drawing.Size(198, 27);
            this.CbxMaster.TabIndex = 8;
            // 
            // LblMaster
            // 
            this.LblMaster.AutoSize = true;
            this.LblMaster.Location = new System.Drawing.Point(19, 173);
            this.LblMaster.Name = "LblMaster";
            this.LblMaster.Size = new System.Drawing.Size(256, 19);
            this.LblMaster.TabIndex = 7;
            this.LblMaster.Text = "Фамилия и инициалами мастера: ";
            // 
            // TbxOwner
            // 
            this.TbxOwner.Location = new System.Drawing.Point(291, 220);
            this.TbxOwner.Name = "TbxOwner";
            this.TbxOwner.Size = new System.Drawing.Size(198, 27);
            this.TbxOwner.TabIndex = 10;
            this.TbxOwner.Text = "Иванов И.И.";
            this.TbxOwner.TextChanged += new System.EventHandler(this.Tbx_TextChanged);
            this.TbxOwner.Validated += new System.EventHandler(this.Txb_Validated);
            // 
            // LblOwner
            // 
            this.LblOwner.AutoSize = true;
            this.LblOwner.Location = new System.Drawing.Point(19, 223);
            this.LblOwner.Name = "LblOwner";
            this.LblOwner.Size = new System.Drawing.Size(274, 19);
            this.LblOwner.TabIndex = 11;
            this.LblOwner.Text = "Фамилия и инициалами владельца: ";
            // 
            // NudCost
            // 
            this.NudCost.Location = new System.Drawing.Point(291, 265);
            this.NudCost.Maximum = new decimal(new int[] {
            1316134912,
            2328,
            0,
            0});
            this.NudCost.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.NudCost.Name = "NudCost";
            this.NudCost.Size = new System.Drawing.Size(198, 27);
            this.NudCost.TabIndex = 13;
            this.NudCost.ThousandsSeparator = true;
            this.NudCost.Value = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            // 
            // LblCost
            // 
            this.LblCost.AutoSize = true;
            this.LblCost.Location = new System.Drawing.Point(19, 267);
            this.LblCost.Name = "LblCost";
            this.LblCost.Size = new System.Drawing.Size(207, 19);
            this.LblCost.TabIndex = 12;
            this.LblCost.Text = "Стоимость ремонта (руб.):";
            // 
            // ErpOwner
            // 
            this.ErpOwner.ContainerControl = this;
            // 
            // TelevisionForm
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.ClientSize = new System.Drawing.Size(658, 386);
            this.Controls.Add(this.GrbTelevision);
            this.Controls.Add(this.BtnCancel);
            this.Controls.Add(this.BtnOk);
            this.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "TelevisionForm";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.GrbTelevision.ResumeLayout(false);
            this.GrbTelevision.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.NudScreen)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ErpDefect)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NudCost)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ErpOwner)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button BtnOk;
        private System.Windows.Forms.Button BtnCancel;
        private System.Windows.Forms.GroupBox GrbTelevision;
        private System.Windows.Forms.ComboBox CbxBrand;
        private System.Windows.Forms.Label LblBrand;
        private System.Windows.Forms.Label LblDefect;
        private System.Windows.Forms.NumericUpDown NudScreen;
        private System.Windows.Forms.Label LblScreen;
        private System.Windows.Forms.ComboBox CbxMaster;
        private System.Windows.Forms.Label LblMaster;
        private System.Windows.Forms.TextBox TbxDefect;
        private System.Windows.Forms.ErrorProvider ErpDefect;
        private System.Windows.Forms.TextBox TbxOwner;
        private System.Windows.Forms.Label LblOwner;
        private System.Windows.Forms.NumericUpDown NudCost;
        private System.Windows.Forms.Label LblCost;
        private System.Windows.Forms.ErrorProvider ErpOwner;
        private System.Windows.Forms.ColorDialog colorDialog1;
    }
}