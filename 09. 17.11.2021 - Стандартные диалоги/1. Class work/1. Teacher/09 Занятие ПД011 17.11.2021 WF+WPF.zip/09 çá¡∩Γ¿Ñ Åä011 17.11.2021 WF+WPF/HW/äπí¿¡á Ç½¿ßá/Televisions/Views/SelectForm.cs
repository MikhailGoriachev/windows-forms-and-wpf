﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Televisions.Models;

namespace Televisions.Views
{
    public partial class SelectForm : Form
    {
        private RepairShop _repairShop;
        public SelectForm() : this("", false, false, new RepairShop()) { }
        public SelectForm(string lblTitle, bool cbxMasterVisible, bool nudScreenVisible, RepairShop repairShop) {
            InitializeComponent();
            LblMain.Text = lblTitle;
            CbxMaster.Visible = cbxMasterVisible;
            NudScreen.Visible = nudScreenVisible;
            _repairShop = repairShop;
        } // SelectForm

        private void BtnSelect_Click(object sender, EventArgs e) {
            List<Television> selected;

            if(CbxMaster.Visible) selected = _repairShop.SelectTelevisions(CbxMaster.Text);

            else if(NudScreen.Visible) selected = _repairShop.SelectTelevisions((int)NudScreen.Value);

            else selected = _repairShop.SelectTelevisions();

            BindCollection(selected);
        } // BtnSelect_Click

        // выполнение привязки коллекции
        private void BindCollection(List<Television> televisions) {
            // остановить привязку
            LbxTelevisions.DataSource = null;

            // задать привязку
            LbxTelevisions.DataSource = televisions;

            LbxTelevisions.DisplayMember = "TableRow";
        } // BindCollection

        private void BtnExit_Click(object sender, EventArgs e) => Close();
    }
}
