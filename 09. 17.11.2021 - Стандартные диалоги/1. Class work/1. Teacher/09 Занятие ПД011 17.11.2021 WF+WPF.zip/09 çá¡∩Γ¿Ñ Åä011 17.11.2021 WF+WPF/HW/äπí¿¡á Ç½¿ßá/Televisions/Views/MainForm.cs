﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Televisions.Models;
using Televisions.Helpers;

namespace Televisions.Views
{
    public partial class MainForm : Form
    {
        private RepairShop _repairShop;
        
        public MainForm() : this(new RepairShop()) { } // MainForm

        public MainForm(RepairShop repairShop) {
            InitializeComponent();

            _repairShop = repairShop;

            // привязка ListBox к коллекции
            BindCollection();
            LblStatus.Text = $"Текущее количество телевизоров: {_repairShop.Count}";
        } // MainForm

        // выполнение привязки коллекции
        private void BindCollection() {
            // остановить привязку
            LbxTelevisions.DataSource = null;

            // задать привязку
            LbxTelevisions.DataSource = _repairShop.Televisions;

            LbxTelevisions.DisplayMember = "TableRow";
        } // BindCollection

        // Начальное формирование данных ремонтной мастерской (коллекция телевизоров от 12 до 15 штук)
        private void Generate_Command(object sender, EventArgs e) {
            _repairShop.Generate(Utils.GetRandom(12, 15));
            BindCollection();
            LblStatus.Text = $"Коллекция телевизоров сформирована. Текущее количество телевизоров: {_repairShop.Count}";
        } // Generate_Command

        // Упорядочивание коллекции телевизоров
        // по производителю и типу
        private void OrderByBrand_Command(object sender, EventArgs e) {
            _repairShop.OrderByBrand();
            BindCollection();
        } // OrderByBrand_Command

        // по убыванию диагонали экрана
        private void OrderByScreen_Command(object sender, EventArgs e) {
            _repairShop.OrderByScreen();
            BindCollection();
        } // OrderByScreen_Command

        // по мастеру, выполняющему ремонт
        private void OrderByMaster_Command(object sender, EventArgs e) {
            _repairShop.OrderByMaster();
            BindCollection();
        } // OrderByMaster_Command

        // по владельцу телевизора
        private void OrderByOwner_Command(object sender, EventArgs e) {
            _repairShop.OrderByOwner();
            BindCollection();
        } // OrderByOwner_Command

        private void AddTelevision_Command(object sender, EventArgs e) {
            TelevisionForm televisionForm = new TelevisionForm();

            // если окно закрыто не по кнопке BtnOk - молча уходим
            if (televisionForm.ShowDialog() != DialogResult.OK) return;

            // получить данные из свойства формы
            _repairShop.AddTelevision(televisionForm.Television);

            // обновить привязку
            BindCollection();
            LblStatus.Text = $"Телевизор добавлен. Текущее количество телевизоров: {_repairShop.Count}";
        } // AddTelevision_Command

        private void Edit_Command(object sender, EventArgs e) {
            // если нет выбранного телевизора - уходим
            if (LbxTelevisions.SelectedIndex < 0)
                return;

            TelevisionForm televisionForm = new TelevisionForm("Редактировать данные телевизора", "Сохранить");
            televisionForm.Television = _repairShop.Televisions[LbxTelevisions.SelectedIndex];

            // если окно закрыто не по кнопке BtnOk - молча уходим
            if (televisionForm.ShowDialog() != DialogResult.OK) return;

            // получить данные
            _repairShop.EditTelevision(LbxTelevisions.SelectedIndex, televisionForm.Television);

            BindCollection();
            LblStatus.Text = $"Телевизор отредактирован. Текущее количество телевизоров: {_repairShop.Count}";
        } // Edit_Command

        private void MainForm_Load(object sender, EventArgs e) {
            LblName.Text    = $"Название ремонтной мастерской: {_repairShop.Name}";
            LblAddress.Text = $"Адрес ремонтной мастерской   : {_repairShop.Address}";
        } // MainForm_Load

        private void SelectByMinCost_Command(object sender, EventArgs e) {
            SelectForm selectForm = new SelectForm($"Минимальная стоимость ремонта: {_repairShop.MinCost()} руб.", false, false, _repairShop);
            selectForm.ShowDialog();
        } // SelectByMinCost_Command

        private void SelectByMaster_Command(object sender, EventArgs e) {
            SelectForm selectForm = new SelectForm($"Фамилия и инициалы мастера: ", true, false, _repairShop);
            selectForm.ShowDialog();
        }

        private void SelectByScreen_Command(object sender, EventArgs e) {
            SelectForm selectForm = new SelectForm($"Диагональ экрана: ", false, true, _repairShop);
            selectForm.ShowDialog();
        } // SelectByScreen_Command

        private void Exit_Command(object sender, EventArgs e) => Application.Exit();

        private void About_Command(object sender, EventArgs e) {
            FormAbout formAbout = new FormAbout();
            formAbout.ShowDialog();
        } // About_Command

        private void EditRepairShop_Command(object sender, EventArgs e) {
            RepairShopForm repairShopForm = new RepairShopForm(_repairShop.Name, _repairShop.Address);

            // если окно закрыто не по кнопке BtnOk - молча уходим
            if (repairShopForm.ShowDialog() != DialogResult.OK) return;

            // получить данные
            _repairShop.Name    = repairShopForm.Name;
            _repairShop.Address = repairShopForm.Address;
            MainForm_Load(sender, e);
        } // EditRepairShop_Command
    }
}
