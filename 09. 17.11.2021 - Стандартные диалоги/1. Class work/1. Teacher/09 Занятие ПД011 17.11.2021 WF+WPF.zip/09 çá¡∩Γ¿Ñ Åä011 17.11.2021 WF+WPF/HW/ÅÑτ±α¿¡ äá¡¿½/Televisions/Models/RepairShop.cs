﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Televisions.Models
{
    /*класс RepairShop (коллекция Television, название ремонтной мастерской, адрес ремонтной мастерской).*/
    class RepairShop
    {
        List<Television> _televisions;  // коллекция телевизоров

        // название мастерской 
        private string  _name;          


        public string Name
        {
            get => _name; 
            set {
                if (string.IsNullOrEmpty(value)) throw new ArgumentNullException($"пустая строка");
                _name = value; }
        }

        // адресс мастерской 
        private string  _address;

        public string  Address
        {
            get => _address; 
            set {
                if (string.IsNullOrEmpty(value)) throw new ArgumentNullException($"пустая строка");
                _address = value; }
        }

        //конструктор
        public RepairShop() { }


    }
}
