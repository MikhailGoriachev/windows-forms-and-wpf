﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Televisions.Models
{
    /*класс Television (производитель и тип телевизора, диагональ экрана, 
     * строка с описанием дефекта, фамилия и инициалами мастера, фамилия и инициалы владельца, стоимость ремонта).*/
    class Television
    {
        // тип телевизора 
        private string _tvType;

        public string TvType
        {
            get => _tvType;
            set
            {
                if (string.IsNullOrEmpty(value)) 
                    throw new ArgumentNullException("Пустая строка");
                _tvType = value;

            }// set
        }// Name

        // диагональ телевизора 
        private double _diagonal;

        public double Diagonal
        {
            get => _diagonal;
            set
            {
                if (value < 0)
                    throw new ArgumentOutOfRangeException($"Недопустимое значение для электропиробора: {value}");
                _diagonal = value;
            }// set
        }

        // описание дефекта
        private string _defect;

        public string Defect
        {
            get => _defect; 
            set
            {
                if (string.IsNullOrEmpty(value))
                    throw new ArgumentNullException("Пустая строка в названии прибора");
                _defect = value;
            }
        }

        // имя мастера
        private string  _mastersFullName;

        public string  MastersFullName
        {
            get => _mastersFullName; 
            set {
                if (string.IsNullOrEmpty(value)) throw new ArgumentNullException($"пустая строка");
                _mastersFullName = value; }
        }

        // имя владельца 
        private string _ownersFullName;

        public string OwnersFullName
        {
            get => _ownersFullName;
            set {
                if (string.IsNullOrEmpty(value)) throw new ArgumentNullException($"пустая строка");
                _ownersFullName = value;
            }
        }

        //стоимость ремонта 
        private double _costOfrepair;

        public double CostOfRepair
        {
            get => _costOfrepair; 
            set {
                if (value < 0) 
                    throw new ArgumentOutOfRangeException($"стоимость не может быть отрицательным числом");
                _costOfrepair = value; }
        }

        // ансамбль конструкторов 
        public Television(): this("Grundic", 12.5, "нет звука", "Иванов И.И.", "Плят С.М.", 1200) { } 

        public Television (string type, double diag, string defect, string master, string owner, int cost)
        {
            TvType = type;
            Diagonal = diag;
            Defect = defect;
            MastersFullName = master;
            OwnersFullName = owner;
            CostOfRepair = cost; 
        }

        // компараторы по заданию 
        public int ComparatorType(Television t1, Television t2) => t1._tvType.CompareTo(t2._tvType);

        // по убыванию цены
        public int ComparatorPrice(Television t1, Television t2) => t2._diagonal.CompareTo(t1._diagonal);

        // по мастеру
        public int ComparatorMaster(Television t1, Television t2) => t1._mastersFullName.CompareTo(t2._mastersFullName);

        // по владельцу
        public int ComparatorOwner(Television t1, Television t2) => t1._ownersFullName.CompareTo(t2._ownersFullName);


        //строковое представление объекта 

        public override string ToString() => $"{_tvType}, диагональ - {_diagonal}, дефект {_defect}, " +
            $" Мастер {_mastersFullName}, Владелец {_ownersFullName}, стоимость ремонта {_costOfrepair} ";

        // формирование строки таблицы 
        public string TableRow =>
            $" | {_tvType,13},  | {_diagonal,9}, | {_defect,10}, | {_mastersFullName,13}, | {_ownersFullName,13}, | {CostOfRepair,9} ";

        // шапка таблицы, статическое свойство
        public static string Header =>
          $"\n +---------------+-----------+------------+---------------+---------------+-----------+\n" +
         $" | Производитель | Диагональ | Дефект     |  Имя мастера  | Имя Владельца | Стоимость |\n" +
         $" +---------------+-----------+------------+---------------+---------------+-----------+\n";

        // подвал таблицы 
        public static string Footer => 
            $" + ---------------+-----------+------------+---------------+---------------+-----------+\n";











    }
}
