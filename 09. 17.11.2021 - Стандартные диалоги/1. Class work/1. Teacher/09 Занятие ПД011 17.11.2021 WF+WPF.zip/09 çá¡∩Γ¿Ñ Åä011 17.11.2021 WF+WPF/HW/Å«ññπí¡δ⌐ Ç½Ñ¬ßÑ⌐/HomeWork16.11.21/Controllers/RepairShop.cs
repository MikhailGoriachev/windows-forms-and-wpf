﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HomeWork16._11._21.Models;


namespace HomeWork16._11._21.Controllers
{
    // класс ремонтной мастреской 
    public class RepairShop
    {
        public List<Television> TeleList = new List<Television>();

        // название ремонтной мастерской
        private string _repairShopName;
        public string RepairShopName
        {
            get { return _repairShopName; }
            set { if (string.IsNullOrWhiteSpace(value))
                    throw new Exception("RepairShop: ошибка имени мастерской");
                _repairShopName = value; }
        }

        // название ремонтной мастерской
        private string _repairShopAddress;
        public string RepairShopAddress
        {
            get { return _repairShopAddress; }
            set
            {
                if (string.IsNullOrWhiteSpace(value))
                    throw new Exception("RepairShop: ошибка адреса мастерской");
                _repairShopAddress = value;
            }
        }

        // Начальное формирование данных ремонтной мастерской
        public void CreateTVList() {
            TeleList.Clear();
            for (int i = 0; i < Utils.GetRandom(12, 16); i++)
                TeleList.Add(Television.CreateTV());
        }


        // Добавление элемента 
        public void Add(Television tv) {
            TeleList.Add(tv);
        }

        // размер массива
        public int Count()
        {
            return TeleList.Count();
        }


        /*
         	Упорядочивание коллекции телевизоров
            	По производителю и типу
            	По убыванию диагонали экрана
            	По мастеру, выполняющему ремонт
            	По владельцу телевизора

         */

        public void SortByType()
        {
            TeleList.Sort((a, b) => a.Type.CompareTo(b.Type));
        }

        public void SortByDiagonal()
        {
            TeleList.Sort((a, b) => b.Diagonal.CompareTo(a.Diagonal));
        }

        public void SortByRepairName()
        {
            TeleList.Sort((a, b) => a.RepairerName.CompareTo(b.RepairerName));
        }

        public void SortByOwnerName()
        {
            TeleList.Sort((a, b) => a.OwnerName.CompareTo(b.OwnerName));
        }

        // Выборка и вывод в отдельной форме коллекции телевизоров с минимальной стоимостью ремонта
        public List<Television> SelectMinRepairCost()
        {
            //List<Television> result = new List<Television>();
            //double min = TeleList[0].RepairCost;
            //foreach (var item in TeleList)
            //{
            //    if (item.RepairCost < min) {
            //        min = item.RepairCost;
            //    }
            //}

            //foreach (var item in TeleList)
            //{
            //    if (item.RepairCost == min)
            //    {
            //        result.Add(item);
            //    }
            //}

            //return result;
            double minRepairCost = TeleList.Min(a => a.RepairCost);
            return TeleList.FindAll((a) => a.RepairCost == minRepairCost);
        }

        //	Выборка и вывод в отдельной форме коллекции телевизоров, ремонтируемых выбранным мастером
        public List<Television> SelectRepairName(string repairName)
        {            
            return TeleList.FindAll((a) => a.RepairerName == repairName);
        }

        // Выборка и вывод в отдельной форме коллекции телевизоров, с заданной диагональю экрана 
        public List<Television> SelectDiagonal(double diagonal)
        {
            return TeleList.FindAll((a) => a.Diagonal == diagonal);
        }
    }
}
