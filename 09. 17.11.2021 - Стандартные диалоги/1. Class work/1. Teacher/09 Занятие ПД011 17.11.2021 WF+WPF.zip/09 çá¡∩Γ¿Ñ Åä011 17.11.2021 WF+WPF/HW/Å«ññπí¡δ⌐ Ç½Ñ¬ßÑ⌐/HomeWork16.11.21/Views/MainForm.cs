﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using HomeWork16._11._21.Controllers;
using HomeWork16._11._21.Models;
using HomeWork16._11._21.Views;

namespace HomeWork16._11._21
{
    public partial class MainForm : Form
    {
        // класс для телемастерской
        //private RepairShop RepairShop = new RepairShop() { RepairShopName = "Электрон", RepairShopAddress="ул.Артема д.12" };

        //public RepairShop GetRepairShop { get; private set; }

        private RepairShop _repairShop;

        public RepairShop RepairShop
        {
            get { return _repairShop; }
            set { _repairShop = value; }
        }



        public MainForm()
        {
            InitializeComponent();
            _repairShop = new RepairShop() { RepairShopName = "Электрон", RepairShopAddress = "ул.Артема д.12" };
            Text ="Ремонт телевизоров " + RepairShop.RepairShopName;
            RepairShop.CreateTVList();
            RepairShopBind();
            Lbl_status_bar.Text += RepairShop.Count().ToString();
            Lbt_statusBar_address.Text = RepairShop.RepairShopAddress;
            // назначить обработчик события выбора элемента в ListBox
            Lbx_main.SelectedIndexChanged += Lbx_main_SelectedIndexChanged;

        }

        private void Lbx_main_SelectedIndexChanged(object sender, EventArgs e)
        {
            // возращаем выбраный элемент из коллекции
            Television tv = (Television)Lbx_main.SelectedItem;
        }

        // Выполнение привязки к данным для Листбокса         
        private void RepairShopBind()
        {
            Lbx_main.DataSource = null;             // остановить текущую привязку
            Lbx_main.DataSource = RepairShop.TeleList;    // источник данных - связанная со списком коллекция
            Lbx_main.DisplayMember = "ToTableRow";  // отображаемое в списке свойство/атрибут
            
        } // 

        private void добавитьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            TVForm tvform = new TVForm();
            DialogResult dialogResult = tvform.ShowDialog();

            // если окно закрыто не по кнопке "Добавить" - молча уходим
            if (dialogResult != DialogResult.OK) return;

            // получить данные из свойства формы
            Television tv = tvform.Television;
            RepairShop.Add(tv);

            // обновить привязку
            RepairShopBind();
        }

        private void измениитьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // если нет выбранного работника - уходим
            if (Lbx_main.SelectedIndex < 0)
                return;

            // передача данных в форму
            TVForm tvform = new TVForm("Редактировать данные телевизора", "Сохранить");
            tvform.Television = (Television)Lbx_main.SelectedItem;

            if (tvform.ShowDialog() != DialogResult.OK) return;

            // получить данные
            RepairShop.TeleList[Lbx_main.SelectedIndex] = tvform.Television;

            // обновить привязку
            RepairShopBind();
        }

        private void редактироватьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AboutCompanyForm compForm = new AboutCompanyForm();
            compForm.RepairShop = RepairShop;

            if (compForm.ShowDialog() != DialogResult.OK) return;

            RepairShop.RepairShopName = compForm.RepairShop.RepairShopName;
            RepairShop.RepairShopAddress = compForm.RepairShop.RepairShopAddress;
            Text = "Ремонт телевизоров " + RepairShop.RepairShopName;
            Lbt_statusBar_address.Text = RepairShop.RepairShopAddress;


        }

        private void oПоПроизводителюИТипуToolStripMenuItem_Click(object sender, EventArgs e)
        {
            RepairShop.SortByType();
            RepairShopBind();

        }

        private void поУбываниюДиагоналиЭкранаToolStripMenuItem_Click(object sender, EventArgs e)
        {
            RepairShop.SortByDiagonal();
            RepairShopBind();

        }

        private void поМастеруВыполняющемуРемонтToolStripMenuItem_Click(object sender, EventArgs e)
        {
            RepairShop.SortByRepairName();
            RepairShopBind();

        }

        private void поВладельцуТелевизораToolStripMenuItem_Click(object sender, EventArgs e)
        {
            RepairShop.SortByOwnerName();
            RepairShopBind();

        }

        private void пересобратьКоллекциюДанныхToolStripMenuItem_Click(object sender, EventArgs e)
        {
            RepairShop.CreateTVList();
            RepairShopBind();
        }

        private void оПрограммеToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AboutProgramm aboutprg = new AboutProgramm();
            aboutprg.ShowDialog();  // модальное отображение формы
        }

        private void удалитьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Lbx_main.SelectedIndex < 0)
                return;

            // удаление записи данных 
            RepairShop.TeleList.Remove((Television)Lbx_main.SelectedItem);
            RepairShopBind();

        }

        private void Exit_Command(object sender, EventArgs e) =>
           Application.Exit();

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            SelectForm selectform = new SelectForm(_repairShop, toolStripButton1.Text);
            DialogResult dialogResult = selectform.ShowDialog();
                  
            // обновить привязку
            RepairShopBind();
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            SelectChoiseSearch choiseSearch = new SelectChoiseSearch(toolStripButton2.Text, "default");
            DialogResult dialogResultSearch = choiseSearch.ShowDialog();


            SelectForm selectform = new SelectForm(_repairShop, toolStripButton2.Text, choiseSearch.Choice.repairName);
            DialogResult dialogResult = selectform.ShowDialog();

            // обновить привязку
            RepairShopBind();
        }

        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            SelectChoiseSearch choiseSearch = new SelectChoiseSearch(toolStripButton2.Text, 1);
            DialogResult dialogResultSearch = choiseSearch.ShowDialog();


            SelectForm selectform = new SelectForm(_repairShop, toolStripButton3.Text, choiseSearch.Choice.diagonal);
            DialogResult dialogResult = selectform.ShowDialog();

            // обновить привязку
            RepairShopBind();
        }
    }
}
