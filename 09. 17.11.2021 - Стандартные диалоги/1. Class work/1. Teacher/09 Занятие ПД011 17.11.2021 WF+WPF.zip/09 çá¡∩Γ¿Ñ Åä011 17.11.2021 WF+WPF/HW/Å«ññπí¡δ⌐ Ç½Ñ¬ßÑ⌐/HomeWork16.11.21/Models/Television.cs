﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HomeWork16._11._21.Models
{
    // класс, описующий телевизоры
    public class Television
    {
        //тип и производитель телевизора
        private string _type;
        public string Type
        {
            get { return _type; }
            set { if (string.IsNullOrWhiteSpace(value))
                    throw new Exception("Television: ошибка типа телевизора");                   
                    _type = value; }
        }
             

        // диагональ экрана
        private double _diagonal;
        public double Diagonal
        {
            get { return _diagonal; }
            set { if(value<=0)
                    throw new Exception("Television: ошибка значения диагонали");
                _diagonal = value; }
        }


        // строка с описанием дефекта
        private string _defect;
        public string Defect
        {
            get { return _defect; }
            set { if (string.IsNullOrWhiteSpace(value))
                    throw new Exception("Television: ошибка описания дефекта"); 
                _defect = value; }
        }


        // фамилия и инициалами мастера
        private string _repairerName;
        public string RepairerName
        {
            get { return _repairerName; }
            set
            {
                if (string.IsNullOrWhiteSpace(value))
                    throw new Exception("Television: ошибка имени мастера");
                _repairerName = value;
            }
        }


        // фамилия и инициалами мастера
        private string _ownerName;
        public string OwnerName
        {
            get { return _ownerName; }
            set
            {
                if (string.IsNullOrWhiteSpace(value))
                    throw new Exception("Television: ошибка имени владельца");
                _ownerName = value;
            }
        }


        // repair cost
        private double _repairCost;
        public double RepairCost
        {
            get { return _repairCost; }
            set
            {
                if (value <= 0)
                    throw new Exception("Television: ошибка значения стоимости ремонта");
                _repairCost = value;
            }
        }

        public Television()
        {
            
        }

        // конструктор с параметрами
        public Television(string type,  double diagonal, string defect, string repairerName, string ownerName, double repairCost)
        {
            Type = type;            
            Diagonal = diagonal;
            Defect = defect;
            RepairerName = repairerName;
            OwnerName = ownerName;
            RepairCost = repairCost;
        }

        public string ToTableRow => $" {_type,-30} │ {_diagonal,5:f2} │ {_defect,-50} │ {_repairerName,-23} │ {_ownerName,-23} | {_repairCost,5:f2} ";




        #region ФОРМИРОВАНИЕ ТЕЛЕВИЗОРА

        // ФИО для мастеров
        static string[] repairerNames =  {
                "Петров Ф.И.",
                "Иванов Г.А.",
                "Сидоров А.М.",
                "Петров К.С.",
                "Степаненко Р.В."
        };

        // ФИО для владельцев
        static string[] ownerNames =  {
                "Анисимова Д. Б.",
                "Мальцев С. К.",
                "Колесникова Е. Р.",
                "Кузьмин Т. А.",
                "Белова В. С.",
                "Волков В. Е.",
                "Павлова К. Т.",
                "Дегтярев С. А.",
                "Орлов Р. И.",
                "Алексеева Э. С.",
                "Афанасьева А. М.",
                "Фомина М. С.",
                "Захаров А. Я.",
                "Булгаков А. А.",
                "Рыбаков Р. Э."
        };

        // модели телевизоров
        static  (string type, double diagonal)[] teleTypies =  {
                ("Xiaomi Mi TV 4A 43 T2",           43   ),
                ("NanoCell LG 49NANO866",           49   ),
                ("Samsung UE43TU7090U",             43   ),
                ("Philips 43PFS5505",               43   ),
                ("OLED LG OLED55CXRLA",             55   ),
                ("Samsung UE50TU7090U",             50   ),
                ("Xiaomi Mi TV 4S 50 T2 Global",    49.5 ),
                ("NanoCell LG 55NANO956",           55   ),
                ("QLED Samsung QE65Q950TSU",        65   ),
                ("QLED Samsung QE65Q700TAU",        65   ),
                ("NanoCell LG 43NANO796NF",         43   ),
                ("Samsung UE43TU8000U",             43   ),
                ("Xiaomi Mi TV 4A 55 T2",           55   )
        };

        // ФИО для владельцев
        static string[] defects =  {
                "поломка матрицы, вследствие удара",
                "попадание влаги в шлейф матрицы",
                "отсутствие подсветки матрицы",
                "отсутствие звука",
                "зависание основного экрана",
                "поломка платы",
                "отсутствие реакции на включение телевизора",
                "сбои программного обеспечения",
                "полное или частичное отсутствие изображения",
                "некорректное цветовоспроизведение",
                "поломка пульта д/у управления",
                "перегрев оборудования, вследствие попадания пыли"
        };


        // фабрика создания телевизора
        public static Television CreateTV()
        {

            int typeTV = Utils.GetRandom(0, teleTypies.Length );

            Television result = new Television(

                    teleTypies[typeTV].type,
                    teleTypies[typeTV].diagonal,
                    defects[Utils.GetRandom(0, defects.Length )],
                    repairerNames[Utils.GetRandom(0, repairerNames.Length )],
                    ownerNames[Utils.GetRandom(0, ownerNames.Length )],
                    Utils.GetRandom(50, 150) * 10
                );

            return result;
        }



        #endregion





    }
}
