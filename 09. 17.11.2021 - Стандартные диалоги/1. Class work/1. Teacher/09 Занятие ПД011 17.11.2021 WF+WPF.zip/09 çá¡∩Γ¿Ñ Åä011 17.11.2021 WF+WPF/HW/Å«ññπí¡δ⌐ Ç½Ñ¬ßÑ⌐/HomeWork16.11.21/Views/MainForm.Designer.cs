﻿
namespace HomeWork16._11._21
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.Lbl_status_bar = new System.Windows.Forms.ToolStripStatusLabel();
            this.Lbt_statusBar_address = new System.Windows.Forms.ToolStripStatusLabel();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.файлToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripSeparator();
            this.выходToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.телевизорыToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.добавитьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.удалитьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.измениитьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripSeparator();
            this.пересобратьКоллекциюДанныхToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.сортировкаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.oПоПроизводителюИТипуToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.поУбываниюДиагоналиЭкранаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.поМастеруВыполняющемуРемонтToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.поВладельцуТелевизораToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.оКомпанииToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.редактироватьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.оПрограммеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.Lbx_main = new System.Windows.Forms.ListBox();
            this.contextMenuStrip2 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.удалитьToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.добавитьToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.изменитьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripSeparator();
            this.сортироватьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.поПроизводителюИТипуToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.поУбываниюДиагоналиЭкранаToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.поМастеруВыполняющемуРемонтToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.поВладельцуТелевизораToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem4 = new System.Windows.Forms.ToolStripSeparator();
            this.оПрограммеToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.выходToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.contextMenuStrip3 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.оПрограммеToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem5 = new System.Windows.Forms.ToolStripSeparator();
            this.выходToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.Lbl_header = new System.Windows.Forms.Label();
            this.toolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton2 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton3 = new System.Windows.Forms.ToolStripButton();
            this.statusStrip1.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.contextMenuStrip2.SuspendLayout();
            this.contextMenuStrip3.SuspendLayout();
            this.SuspendLayout();
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.Lbl_status_bar,
            this.Lbt_statusBar_address});
            this.statusStrip1.Location = new System.Drawing.Point(0, 554);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(1141, 22);
            this.statusStrip1.TabIndex = 0;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // Lbl_status_bar
            // 
            this.Lbl_status_bar.Margin = new System.Windows.Forms.Padding(0, 3, 700, 2);
            this.Lbl_status_bar.Name = "Lbl_status_bar";
            this.Lbl_status_bar.Size = new System.Drawing.Size(218, 17);
            this.Lbl_status_bar.Text = "Количество телвизоров в ремноте : ";
            // 
            // Lbt_statusBar_address
            // 
            this.Lbt_statusBar_address.ImageAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.Lbt_statusBar_address.Name = "Lbt_statusBar_address";
            this.Lbt_statusBar_address.Padding = new System.Windows.Forms.Padding(0, 0, 10, 0);
            this.Lbt_statusBar_address.Size = new System.Drawing.Size(137, 17);
            this.Lbt_statusBar_address.Text = "toolStripStatusLabel1";
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.файлToolStripMenuItem,
            this.телевизорыToolStripMenuItem,
            this.сортировкаToolStripMenuItem,
            this.оКомпанииToolStripMenuItem,
            this.оПрограммеToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1141, 24);
            this.menuStrip1.TabIndex = 2;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // файлToolStripMenuItem
            // 
            this.файлToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem1,
            this.выходToolStripMenuItem});
            this.файлToolStripMenuItem.Name = "файлToolStripMenuItem";
            this.файлToolStripMenuItem.Size = new System.Drawing.Size(50, 20);
            this.файлToolStripMenuItem.Text = "Файл";
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(110, 6);
            // 
            // выходToolStripMenuItem
            // 
            this.выходToolStripMenuItem.Name = "выходToolStripMenuItem";
            this.выходToolStripMenuItem.Size = new System.Drawing.Size(113, 22);
            this.выходToolStripMenuItem.Text = "Выход";
            this.выходToolStripMenuItem.Click += new System.EventHandler(this.Exit_Command);
            // 
            // телевизорыToolStripMenuItem
            // 
            this.телевизорыToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.добавитьToolStripMenuItem,
            this.удалитьToolStripMenuItem,
            this.измениитьToolStripMenuItem,
            this.toolStripMenuItem2,
            this.пересобратьКоллекциюДанныхToolStripMenuItem});
            this.телевизорыToolStripMenuItem.Name = "телевизорыToolStripMenuItem";
            this.телевизорыToolStripMenuItem.Size = new System.Drawing.Size(91, 20);
            this.телевизорыToolStripMenuItem.Text = "Телевизоры";
            // 
            // добавитьToolStripMenuItem
            // 
            this.добавитьToolStripMenuItem.Name = "добавитьToolStripMenuItem";
            this.добавитьToolStripMenuItem.Size = new System.Drawing.Size(268, 22);
            this.добавитьToolStripMenuItem.Text = "Добавить ";
            this.добавитьToolStripMenuItem.Click += new System.EventHandler(this.добавитьToolStripMenuItem_Click);
            // 
            // удалитьToolStripMenuItem
            // 
            this.удалитьToolStripMenuItem.Name = "удалитьToolStripMenuItem";
            this.удалитьToolStripMenuItem.Size = new System.Drawing.Size(268, 22);
            this.удалитьToolStripMenuItem.Text = "Удалить";
            this.удалитьToolStripMenuItem.Click += new System.EventHandler(this.удалитьToolStripMenuItem_Click);
            // 
            // измениитьToolStripMenuItem
            // 
            this.измениитьToolStripMenuItem.Name = "измениитьToolStripMenuItem";
            this.измениитьToolStripMenuItem.Size = new System.Drawing.Size(268, 22);
            this.измениитьToolStripMenuItem.Text = "Измениить";
            this.измениитьToolStripMenuItem.Click += new System.EventHandler(this.измениитьToolStripMenuItem_Click);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(265, 6);
            // 
            // пересобратьКоллекциюДанныхToolStripMenuItem
            // 
            this.пересобратьКоллекциюДанныхToolStripMenuItem.Name = "пересобратьКоллекциюДанныхToolStripMenuItem";
            this.пересобратьКоллекциюДанныхToolStripMenuItem.Size = new System.Drawing.Size(268, 22);
            this.пересобратьКоллекциюДанныхToolStripMenuItem.Text = "Пересобрать коллекцию данных";
            this.пересобратьКоллекциюДанныхToolStripMenuItem.Click += new System.EventHandler(this.пересобратьКоллекциюДанныхToolStripMenuItem_Click);
            // 
            // сортировкаToolStripMenuItem
            // 
            this.сортировкаToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.oПоПроизводителюИТипуToolStripMenuItem,
            this.поУбываниюДиагоналиЭкранаToolStripMenuItem,
            this.поМастеруВыполняющемуРемонтToolStripMenuItem,
            this.поВладельцуТелевизораToolStripMenuItem});
            this.сортировкаToolStripMenuItem.Name = "сортировкаToolStripMenuItem";
            this.сортировкаToolStripMenuItem.Size = new System.Drawing.Size(87, 20);
            this.сортировкаToolStripMenuItem.Text = "Сортировка";
            // 
            // oПоПроизводителюИТипуToolStripMenuItem
            // 
            this.oПоПроизводителюИТипуToolStripMenuItem.Name = "oПоПроизводителюИТипуToolStripMenuItem";
            this.oПоПроизводителюИТипуToolStripMenuItem.Size = new System.Drawing.Size(286, 22);
            this.oПоПроизводителюИТипуToolStripMenuItem.Text = "По производителю и типу";
            this.oПоПроизводителюИТипуToolStripMenuItem.Click += new System.EventHandler(this.oПоПроизводителюИТипуToolStripMenuItem_Click);
            // 
            // поУбываниюДиагоналиЭкранаToolStripMenuItem
            // 
            this.поУбываниюДиагоналиЭкранаToolStripMenuItem.Name = "поУбываниюДиагоналиЭкранаToolStripMenuItem";
            this.поУбываниюДиагоналиЭкранаToolStripMenuItem.Size = new System.Drawing.Size(286, 22);
            this.поУбываниюДиагоналиЭкранаToolStripMenuItem.Text = "По убыванию диагонали экрана";
            this.поУбываниюДиагоналиЭкранаToolStripMenuItem.Click += new System.EventHandler(this.поУбываниюДиагоналиЭкранаToolStripMenuItem_Click);
            // 
            // поМастеруВыполняющемуРемонтToolStripMenuItem
            // 
            this.поМастеруВыполняющемуРемонтToolStripMenuItem.Name = "поМастеруВыполняющемуРемонтToolStripMenuItem";
            this.поМастеруВыполняющемуРемонтToolStripMenuItem.Size = new System.Drawing.Size(286, 22);
            this.поМастеруВыполняющемуРемонтToolStripMenuItem.Text = "По мастеру, выполняющему ремонт";
            this.поМастеруВыполняющемуРемонтToolStripMenuItem.Click += new System.EventHandler(this.поМастеруВыполняющемуРемонтToolStripMenuItem_Click);
            // 
            // поВладельцуТелевизораToolStripMenuItem
            // 
            this.поВладельцуТелевизораToolStripMenuItem.Name = "поВладельцуТелевизораToolStripMenuItem";
            this.поВладельцуТелевизораToolStripMenuItem.Size = new System.Drawing.Size(286, 22);
            this.поВладельцуТелевизораToolStripMenuItem.Text = "По владельцу телевизора";
            this.поВладельцуТелевизораToolStripMenuItem.Click += new System.EventHandler(this.поВладельцуТелевизораToolStripMenuItem_Click);
            // 
            // оКомпанииToolStripMenuItem
            // 
            this.оКомпанииToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.редактироватьToolStripMenuItem});
            this.оКомпанииToolStripMenuItem.Name = "оКомпанииToolStripMenuItem";
            this.оКомпанииToolStripMenuItem.Size = new System.Drawing.Size(90, 20);
            this.оКомпанииToolStripMenuItem.Text = "О компании";
            // 
            // редактироватьToolStripMenuItem
            // 
            this.редактироватьToolStripMenuItem.Name = "редактироватьToolStripMenuItem";
            this.редактироватьToolStripMenuItem.Size = new System.Drawing.Size(160, 22);
            this.редактироватьToolStripMenuItem.Text = "Редактировать";
            this.редактироватьToolStripMenuItem.Click += new System.EventHandler(this.редактироватьToolStripMenuItem_Click);
            // 
            // оПрограммеToolStripMenuItem
            // 
            this.оПрограммеToolStripMenuItem.Name = "оПрограммеToolStripMenuItem";
            this.оПрограммеToolStripMenuItem.Size = new System.Drawing.Size(95, 20);
            this.оПрограммеToolStripMenuItem.Text = "О программе";
            this.оПрограммеToolStripMenuItem.Click += new System.EventHandler(this.оПрограммеToolStripMenuItem_Click);
            // 
            // toolStrip1
            // 
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButton1,
            this.toolStripButton2,
            this.toolStripButton3});
            this.toolStrip1.Location = new System.Drawing.Point(0, 24);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(1141, 47);
            this.toolStrip1.TabIndex = 3;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // Lbx_main
            // 
            this.Lbx_main.ContextMenuStrip = this.contextMenuStrip2;
            this.Lbx_main.Font = new System.Drawing.Font("Consolas", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Lbx_main.FormattingEnabled = true;
            this.Lbx_main.ItemHeight = 15;
            this.Lbx_main.Location = new System.Drawing.Point(12, 143);
            this.Lbx_main.Name = "Lbx_main";
            this.Lbx_main.Size = new System.Drawing.Size(1117, 289);
            this.Lbx_main.TabIndex = 4;
            this.Lbx_main.SelectedIndexChanged += new System.EventHandler(this.Lbx_main_SelectedIndexChanged);
            // 
            // contextMenuStrip2
            // 
            this.contextMenuStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.удалитьToolStripMenuItem1,
            this.добавитьToolStripMenuItem1,
            this.изменитьToolStripMenuItem,
            this.toolStripMenuItem3,
            this.сортироватьToolStripMenuItem,
            this.toolStripMenuItem4,
            this.оПрограммеToolStripMenuItem1,
            this.выходToolStripMenuItem1});
            this.contextMenuStrip2.Name = "contextMenuStrip2";
            this.contextMenuStrip2.Size = new System.Drawing.Size(151, 148);
            // 
            // удалитьToolStripMenuItem1
            // 
            this.удалитьToolStripMenuItem1.Name = "удалитьToolStripMenuItem1";
            this.удалитьToolStripMenuItem1.Size = new System.Drawing.Size(150, 22);
            this.удалитьToolStripMenuItem1.Text = "Удалить";
            this.удалитьToolStripMenuItem1.Click += new System.EventHandler(this.удалитьToolStripMenuItem_Click);
            // 
            // добавитьToolStripMenuItem1
            // 
            this.добавитьToolStripMenuItem1.Name = "добавитьToolStripMenuItem1";
            this.добавитьToolStripMenuItem1.Size = new System.Drawing.Size(150, 22);
            this.добавитьToolStripMenuItem1.Text = "Добавить";
            this.добавитьToolStripMenuItem1.Click += new System.EventHandler(this.добавитьToolStripMenuItem_Click);
            // 
            // изменитьToolStripMenuItem
            // 
            this.изменитьToolStripMenuItem.Name = "изменитьToolStripMenuItem";
            this.изменитьToolStripMenuItem.Size = new System.Drawing.Size(150, 22);
            this.изменитьToolStripMenuItem.Text = "Изменить";
            this.изменитьToolStripMenuItem.Click += new System.EventHandler(this.измениитьToolStripMenuItem_Click);
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(147, 6);
            // 
            // сортироватьToolStripMenuItem
            // 
            this.сортироватьToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.поПроизводителюИТипуToolStripMenuItem,
            this.поУбываниюДиагоналиЭкранаToolStripMenuItem1,
            this.поМастеруВыполняющемуРемонтToolStripMenuItem1,
            this.поВладельцуТелевизораToolStripMenuItem1});
            this.сортироватьToolStripMenuItem.Name = "сортироватьToolStripMenuItem";
            this.сортироватьToolStripMenuItem.Size = new System.Drawing.Size(150, 22);
            this.сортироватьToolStripMenuItem.Text = "Сортировать";
            // 
            // поПроизводителюИТипуToolStripMenuItem
            // 
            this.поПроизводителюИТипуToolStripMenuItem.Name = "поПроизводителюИТипуToolStripMenuItem";
            this.поПроизводителюИТипуToolStripMenuItem.Size = new System.Drawing.Size(286, 22);
            this.поПроизводителюИТипуToolStripMenuItem.Text = "По производителю и типу";
            this.поПроизводителюИТипуToolStripMenuItem.Click += new System.EventHandler(this.oПоПроизводителюИТипуToolStripMenuItem_Click);
            // 
            // поУбываниюДиагоналиЭкранаToolStripMenuItem1
            // 
            this.поУбываниюДиагоналиЭкранаToolStripMenuItem1.Name = "поУбываниюДиагоналиЭкранаToolStripMenuItem1";
            this.поУбываниюДиагоналиЭкранаToolStripMenuItem1.Size = new System.Drawing.Size(286, 22);
            this.поУбываниюДиагоналиЭкранаToolStripMenuItem1.Text = "По убыванию диагонали экрана";
            this.поУбываниюДиагоналиЭкранаToolStripMenuItem1.Click += new System.EventHandler(this.поУбываниюДиагоналиЭкранаToolStripMenuItem_Click);
            // 
            // поМастеруВыполняющемуРемонтToolStripMenuItem1
            // 
            this.поМастеруВыполняющемуРемонтToolStripMenuItem1.Name = "поМастеруВыполняющемуРемонтToolStripMenuItem1";
            this.поМастеруВыполняющемуРемонтToolStripMenuItem1.Size = new System.Drawing.Size(286, 22);
            this.поМастеруВыполняющемуРемонтToolStripMenuItem1.Text = "По мастеру, выполняющему ремонт";
            this.поМастеруВыполняющемуРемонтToolStripMenuItem1.Click += new System.EventHandler(this.поМастеруВыполняющемуРемонтToolStripMenuItem_Click);
            // 
            // поВладельцуТелевизораToolStripMenuItem1
            // 
            this.поВладельцуТелевизораToolStripMenuItem1.Name = "поВладельцуТелевизораToolStripMenuItem1";
            this.поВладельцуТелевизораToolStripMenuItem1.Size = new System.Drawing.Size(286, 22);
            this.поВладельцуТелевизораToolStripMenuItem1.Text = "По владельцу телевизора";
            this.поВладельцуТелевизораToolStripMenuItem1.Click += new System.EventHandler(this.поВладельцуТелевизораToolStripMenuItem_Click);
            // 
            // toolStripMenuItem4
            // 
            this.toolStripMenuItem4.Name = "toolStripMenuItem4";
            this.toolStripMenuItem4.Size = new System.Drawing.Size(147, 6);
            // 
            // оПрограммеToolStripMenuItem1
            // 
            this.оПрограммеToolStripMenuItem1.Name = "оПрограммеToolStripMenuItem1";
            this.оПрограммеToolStripMenuItem1.Size = new System.Drawing.Size(150, 22);
            this.оПрограммеToolStripMenuItem1.Text = "О программе";
            this.оПрограммеToolStripMenuItem1.Click += new System.EventHandler(this.оПрограммеToolStripMenuItem_Click);
            // 
            // выходToolStripMenuItem1
            // 
            this.выходToolStripMenuItem1.Name = "выходToolStripMenuItem1";
            this.выходToolStripMenuItem1.Size = new System.Drawing.Size(150, 22);
            this.выходToolStripMenuItem1.Text = "Выход";
            this.выходToolStripMenuItem1.Click += new System.EventHandler(this.Exit_Command);
            // 
            // contextMenuStrip3
            // 
            this.contextMenuStrip3.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.оПрограммеToolStripMenuItem2,
            this.toolStripMenuItem5,
            this.выходToolStripMenuItem2});
            this.contextMenuStrip3.Name = "contextMenuStrip3";
            this.contextMenuStrip3.Size = new System.Drawing.Size(151, 54);
            // 
            // оПрограммеToolStripMenuItem2
            // 
            this.оПрограммеToolStripMenuItem2.Name = "оПрограммеToolStripMenuItem2";
            this.оПрограммеToolStripMenuItem2.Size = new System.Drawing.Size(150, 22);
            this.оПрограммеToolStripMenuItem2.Text = "О программе";
            this.оПрограммеToolStripMenuItem2.Click += new System.EventHandler(this.оПрограммеToolStripMenuItem_Click);
            // 
            // toolStripMenuItem5
            // 
            this.toolStripMenuItem5.Name = "toolStripMenuItem5";
            this.toolStripMenuItem5.Size = new System.Drawing.Size(147, 6);
            // 
            // выходToolStripMenuItem2
            // 
            this.выходToolStripMenuItem2.Name = "выходToolStripMenuItem2";
            this.выходToolStripMenuItem2.Size = new System.Drawing.Size(150, 22);
            this.выходToolStripMenuItem2.Text = "Выход";
            this.выходToolStripMenuItem2.Click += new System.EventHandler(this.Exit_Command);
            // 
            // Lbl_header
            // 
            this.Lbl_header.Location = new System.Drawing.Point(12, 109);
            this.Lbl_header.Name = "Lbl_header";
            this.Lbl_header.Size = new System.Drawing.Size(1117, 31);
            this.Lbl_header.TabIndex = 7;
            this.Lbl_header.Text = resources.GetString("Lbl_header.Text");
            // 
            // toolStripButton1
            // 
            this.toolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton1.Image = global::HomeWork16._11._21.Properties.Resources.glyphicons_halflings_108_save_as_2x;
            this.toolStripButton1.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.Size = new System.Drawing.Size(44, 44);
            this.toolStripButton1.Text = "Коллекция телевизоров с минимальной стоимостью ремонта";
            this.toolStripButton1.Click += new System.EventHandler(this.toolStripButton1_Click);
            // 
            // toolStripButton2
            // 
            this.toolStripButton2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton2.Image = global::HomeWork16._11._21.Properties.Resources.glyphicons_halflings_1_user_2x;
            this.toolStripButton2.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripButton2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton2.Name = "toolStripButton2";
            this.toolStripButton2.Size = new System.Drawing.Size(44, 44);
            this.toolStripButton2.Text = "Коллекция телевизоров, ремонтируемых выбранным мастером";
            this.toolStripButton2.Click += new System.EventHandler(this.toolStripButton2_Click);
            // 
            // toolStripButton3
            // 
            this.toolStripButton3.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton3.Image = global::HomeWork16._11._21.Properties.Resources.glyphicons_halflings_122_fullscreen_2x;
            this.toolStripButton3.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripButton3.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton3.Name = "toolStripButton3";
            this.toolStripButton3.Size = new System.Drawing.Size(44, 44);
            this.toolStripButton3.Text = "Коллекция телевизоров, с заданной диагональю экрана";
            this.toolStripButton3.Click += new System.EventHandler(this.toolStripButton3_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1141, 576);
            this.ContextMenuStrip = this.contextMenuStrip3;
            this.Controls.Add(this.Lbl_header);
            this.Controls.Add(this.Lbx_main);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "MainForm";
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.contextMenuStrip2.ResumeLayout(false);
            this.contextMenuStrip3.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem файлToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem выходToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem телевизорыToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem сортировкаToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem добавитьToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem удалитьToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem измениитьToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem oПоПроизводителюИТипуToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem поУбываниюДиагоналиЭкранаToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem поМастеруВыполняющемуРемонтToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem поВладельцуТелевизораToolStripMenuItem;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ListBox Lbx_main;
        private System.Windows.Forms.ToolStripStatusLabel Lbl_status_bar;
        private System.Windows.Forms.ToolStripMenuItem оКомпанииToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem редактироватьToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem оПрограммеToolStripMenuItem;
        private System.Windows.Forms.ToolStripStatusLabel Lbt_statusBar_address;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem пересобратьКоллекциюДанныхToolStripMenuItem;
        private System.Windows.Forms.ToolStripButton toolStripButton1;
        private System.Windows.Forms.ToolStripButton toolStripButton2;
        private System.Windows.Forms.ToolStripButton toolStripButton3;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip2;
        private System.Windows.Forms.ToolStripMenuItem удалитьToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem добавитьToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem изменитьToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem сортироватьToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem поПроизводителюИТипуToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem поУбываниюДиагоналиЭкранаToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem поМастеруВыполняющемуРемонтToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem поВладельцуТелевизораToolStripMenuItem1;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem4;
        private System.Windows.Forms.ToolStripMenuItem оПрограммеToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem выходToolStripMenuItem1;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip3;
        private System.Windows.Forms.ToolStripMenuItem оПрограммеToolStripMenuItem2;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem5;
        private System.Windows.Forms.ToolStripMenuItem выходToolStripMenuItem2;
        private System.Windows.Forms.Label Lbl_header;
    }
}