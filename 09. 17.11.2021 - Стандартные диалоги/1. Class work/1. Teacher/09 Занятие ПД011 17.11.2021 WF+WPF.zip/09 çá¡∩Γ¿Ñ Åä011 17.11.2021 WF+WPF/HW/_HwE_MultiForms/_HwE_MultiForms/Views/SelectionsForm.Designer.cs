﻿
namespace _HwE_MultiForms.Views
{
    partial class SelectionsForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SelectionsForm));
            this.LbxTelevisions = new System.Windows.Forms.ListBox();
            this.LblHeader = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // LbxTelevisions
            // 
            this.LbxTelevisions.Font = new System.Drawing.Font("Consolas", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LbxTelevisions.FormattingEnabled = true;
            this.LbxTelevisions.ItemHeight = 19;
            this.LbxTelevisions.Location = new System.Drawing.Point(16, 56);
            this.LbxTelevisions.Name = "LbxTelevisions";
            this.LbxTelevisions.ScrollAlwaysVisible = true;
            this.LbxTelevisions.Size = new System.Drawing.Size(1136, 422);
            this.LbxTelevisions.TabIndex = 6;
            // 
            // LblHeader
            // 
            this.LblHeader.Font = new System.Drawing.Font("Consolas", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblHeader.Location = new System.Drawing.Point(16, 16);
            this.LblHeader.Name = "LblHeader";
            this.LblHeader.Size = new System.Drawing.Size(1136, 40);
            this.LblHeader.TabIndex = 5;
            this.LblHeader.Text = "Ремонтная мастерская, телевизоры в ремонте";
            this.LblHeader.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // SelectionsForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1169, 493);
            this.Controls.Add(this.LbxTelevisions);
            this.Controls.Add(this.LblHeader);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(1185, 532);
            this.MinimizeBox = false;
            this.MinimumSize = new System.Drawing.Size(1185, 532);
            this.Name = "SelectionsForm";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "SelectionsForm";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListBox LbxTelevisions;
        private System.Windows.Forms.Label LblHeader;
    }
}