﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.ComponentModel;

using _HwE_MultiForms.Controllers;
using _HwE_MultiForms.Models;

namespace _HwE_MultiForms.Views
{
    public partial class MainForm : Form
    {
        // контроллер для работы с формой
        private RepairShopController _repairShopController;

        // конструкторы формы
        public MainForm(): this(new RepairShopController()) {}

        public MainForm(RepairShopController repairShopController) {
            InitializeComponent();

            // получить контроллер для работы с данными ремонтной мастерской
            _repairShopController = repairShopController;

            // формирование заголовка поля вывода данных о телевизорах
            LblHeader.Text =
                $"  Ремонтная мастерская \"{_repairShopController.RepairShop.Title}\", " +
                $"{_repairShopController.RepairShop.Address}, телевизоры в ремонте\r\n" +
                $"{Television.Header}";

            // привязка ListBox к коллекции
            BindCollection();

            // настройка комбобокса со списком мастеров
            CbxArtisans.Items.AddRange(_repairShopController.GetArtitans().ToArray());
            CbxArtisans.Text = CbxArtisans.Items[0].ToString();
        } // MainForm


        // выполнение привязки коллекции
        private void BindCollection() {
            // остановить привязку
            LbxTelevisions.DataSource = null;

            // задать привязку
            LbxTelevisions.DataSource = _repairShopController.RepairShop.Televisions;

            // свойство для отображения в ListBox
            LbxTelevisions.DisplayMember = "TableRow";
        } // BindCollection


        // выполняется после конструктора формы
        private void MainForm_Load(object sender, EventArgs e) {
            // вывод в строку состояния
            StlMain.Text = $"Телевизоров в ремонте: {_repairShopController.RepairShop.Televisions.Count}";
        } // MainForm_Load


        // выход из приложения
        private void Exit_Command(object sender, EventArgs e) => Application.Exit();


        // вывод окна со сведениями о программе
        private void About_Command(object sender, EventArgs e) {
            AboutForm aboutForm = new AboutForm();
            aboutForm.ShowDialog();
        } // About_Command

        // Сортировка коллекции телевизоров по производителю и типу
        private void OrderByBrand_Command(object sender, EventArgs e) {
            _repairShopController.OrderByBrand();
            BindCollection();
        } // OrderByBrand_Command

        // Сортировка коллекции телевизоров по убыванию диагонали экрана
        private void OrderByDiagonalDesc_Command(object sender, EventArgs e) {
            _repairShopController.OrderByDiagonalDesc();
            BindCollection();
        } // OrderByDiagonalDesc_Command


        // Выборка и вывод в отдельной форме коллекции телевизоров с минимальной
        // стоимостью ремонта
        private void SelectMinPrice_Command(object sender, EventArgs e) {
            List<Television> minPriceList = _repairShopController.SelectWhereMinPrice();

            SelectionsForm selectionsForm =
                new SelectionsForm(minPriceList, "Телевизоры с минимальной стоимостью ремонта");
            selectionsForm.ShowDialog();
        } // SelectMinPrice_Command

        private void SelectArtisan_Command(object sender, EventArgs e) {
            // получить список фамилий из коллекции ремонтов
            List<string> artisans = _repairShopController.GetArtitans();

            // создание формы выбора мастера, передача в окно списка мастеров
            ArtisanChoiceForm artisanChoiceForm = new ArtisanChoiceForm(artisans);

            if (artisanChoiceForm.ShowDialog() != DialogResult.OK) return;

            // выбор мастера произведен, получим мастера, построим выборку
            SelectArtisan(artisanChoiceForm.Artisan);
        } // SelectArtisan_Command


        // запуск выборки ремонтов мастеров, получить мастера из комбо-бокса панели интсрументов 
        private void SelectArtisanTbr_Command(object sender, EventArgs e) =>
            SelectArtisan(CbxArtisans.Text);

        private void SelectArtisan(string artisan) {
            // выбрать ремонты заданного мастера
            List<Television> list = _repairShopController.SelectWhereArtisan(artisan);

            SelectionsForm selectionsForm =
                new SelectionsForm(list, $"Телевизоры, ремонтируемые мастером {artisan}");
            selectionsForm.ShowDialog();
        }
    } // class MainForm
}
