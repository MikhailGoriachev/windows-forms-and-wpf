﻿namespace _HwE_MultiForms.Views
{
    partial class MainForm
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.MnsMain = new System.Windows.Forms.MenuStrip();
            this.MniFile = new System.Windows.Forms.ToolStripMenuItem();
            this.MniFileExit = new System.Windows.Forms.ToolStripMenuItem();
            this.MniRepairShop = new System.Windows.Forms.ToolStripMenuItem();
            this.MniRepairShopNew = new System.Windows.Forms.ToolStripMenuItem();
            this.MniRepairShopEdit = new System.Windows.Forms.ToolStripMenuItem();
            this.MniTelevisions = new System.Windows.Forms.ToolStripMenuItem();
            this.MniTelevisionsAdd = new System.Windows.Forms.ToolStripMenuItem();
            this.MniTelevisionsEdit = new System.Windows.Forms.ToolStripMenuItem();
            this.MniTelevisionsSep1 = new System.Windows.Forms.ToolStripSeparator();
            this.MniTelevisionsRemoveAt = new System.Windows.Forms.ToolStripMenuItem();
            this.MniOrderBy = new System.Windows.Forms.ToolStripMenuItem();
            this.MniOrderByBrand = new System.Windows.Forms.ToolStripMenuItem();
            this.MniOrderByDiagonalDesc = new System.Windows.Forms.ToolStripMenuItem();
            this.MniOrderByArtisan = new System.Windows.Forms.ToolStripMenuItem();
            this.MniOrderByOwner = new System.Windows.Forms.ToolStripMenuItem();
            this.MniSelectWhere = new System.Windows.Forms.ToolStripMenuItem();
            this.MniSelectWhereInexpensive = new System.Windows.Forms.ToolStripMenuItem();
            this.MniSelectWhereArtisan = new System.Windows.Forms.ToolStripMenuItem();
            this.MniSelectWhereDiagonal = new System.Windows.Forms.ToolStripMenuItem();
            this.MniHelp = new System.Windows.Forms.ToolStripMenuItem();
            this.MniHelpAbout = new System.Windows.Forms.ToolStripMenuItem();
            this.TbsMain = new System.Windows.Forms.ToolStrip();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.StsMain = new System.Windows.Forms.StatusStrip();
            this.StlMain = new System.Windows.Forms.ToolStripStatusLabel();
            this.LblHeader = new System.Windows.Forms.Label();
            this.LbxTelevisions = new System.Windows.Forms.ListBox();
            this.CbxArtisans = new System.Windows.Forms.ToolStripComboBox();
            this.toolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton2 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton3 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton4 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton5 = new System.Windows.Forms.ToolStripButton();
            this.TsbOrderByBrand = new System.Windows.Forms.ToolStripButton();
            this.TsbOrderByDiagonalDesc = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton8 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton9 = new System.Windows.Forms.ToolStripButton();
            this.TsbMinPrice = new System.Windows.Forms.ToolStripButton();
            this.TsbArtisanSelection = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton12 = new System.Windows.Forms.ToolStripButton();
            this.TsbAbout = new System.Windows.Forms.ToolStripButton();
            this.TsbExit = new System.Windows.Forms.ToolStripButton();
            this.MnsMain.SuspendLayout();
            this.TbsMain.SuspendLayout();
            this.StsMain.SuspendLayout();
            this.SuspendLayout();
            // 
            // MnsMain
            // 
            this.MnsMain.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.MnsMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniFile,
            this.MniRepairShop,
            this.MniTelevisions,
            this.MniOrderBy,
            this.MniSelectWhere,
            this.MniHelp});
            this.MnsMain.Location = new System.Drawing.Point(0, 0);
            this.MnsMain.Name = "MnsMain";
            this.MnsMain.Size = new System.Drawing.Size(1169, 29);
            this.MnsMain.TabIndex = 0;
            this.MnsMain.Text = "menuStrip1";
            // 
            // MniFile
            // 
            this.MniFile.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniFileExit});
            this.MniFile.Name = "MniFile";
            this.MniFile.Size = new System.Drawing.Size(59, 25);
            this.MniFile.Text = "Файл";
            // 
            // MniFileExit
            // 
            this.MniFileExit.Name = "MniFileExit";
            this.MniFileExit.Size = new System.Drawing.Size(125, 26);
            this.MniFileExit.Text = "Выход";
            this.MniFileExit.Click += new System.EventHandler(this.Exit_Command);
            // 
            // MniRepairShop
            // 
            this.MniRepairShop.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniRepairShopNew,
            this.MniRepairShopEdit});
            this.MniRepairShop.Name = "MniRepairShop";
            this.MniRepairShop.Size = new System.Drawing.Size(106, 25);
            this.MniRepairShop.Text = "Мастерская";
            // 
            // MniRepairShopNew
            // 
            this.MniRepairShopNew.Name = "MniRepairShopNew";
            this.MniRepairShopNew.Size = new System.Drawing.Size(160, 26);
            this.MniRepairShopNew.Text = "Новая...";
            // 
            // MniRepairShopEdit
            // 
            this.MniRepairShopEdit.Name = "MniRepairShopEdit";
            this.MniRepairShopEdit.Size = new System.Drawing.Size(160, 26);
            this.MniRepairShopEdit.Text = "Изменить...";
            // 
            // MniTelevisions
            // 
            this.MniTelevisions.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniTelevisionsAdd,
            this.MniTelevisionsEdit,
            this.MniTelevisionsSep1,
            this.MniTelevisionsRemoveAt});
            this.MniTelevisions.Name = "MniTelevisions";
            this.MniTelevisions.Size = new System.Drawing.Size(180, 25);
            this.MniTelevisions.Text = "Ремонты телевизоров";
            // 
            // MniTelevisionsAdd
            // 
            this.MniTelevisionsAdd.Name = "MniTelevisionsAdd";
            this.MniTelevisionsAdd.Size = new System.Drawing.Size(219, 26);
            this.MniTelevisionsAdd.Text = "Принять в ремонт...";
            // 
            // MniTelevisionsEdit
            // 
            this.MniTelevisionsEdit.Name = "MniTelevisionsEdit";
            this.MniTelevisionsEdit.Size = new System.Drawing.Size(219, 26);
            this.MniTelevisionsEdit.Text = "Изменить...";
            // 
            // MniTelevisionsSep1
            // 
            this.MniTelevisionsSep1.Name = "MniTelevisionsSep1";
            this.MniTelevisionsSep1.Size = new System.Drawing.Size(216, 6);
            // 
            // MniTelevisionsRemoveAt
            // 
            this.MniTelevisionsRemoveAt.Name = "MniTelevisionsRemoveAt";
            this.MniTelevisionsRemoveAt.Size = new System.Drawing.Size(219, 26);
            this.MniTelevisionsRemoveAt.Text = "Выдать";
            // 
            // MniOrderBy
            // 
            this.MniOrderBy.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniOrderByBrand,
            this.MniOrderByDiagonalDesc,
            this.MniOrderByArtisan,
            this.MniOrderByOwner});
            this.MniOrderBy.Name = "MniOrderBy";
            this.MniOrderBy.Size = new System.Drawing.Size(108, 25);
            this.MniOrderBy.Text = "Сортировка";
            // 
            // MniOrderByBrand
            // 
            this.MniOrderByBrand.Name = "MniOrderByBrand";
            this.MniOrderByBrand.Size = new System.Drawing.Size(258, 26);
            this.MniOrderByBrand.Text = "По производителю";
            this.MniOrderByBrand.Click += new System.EventHandler(this.OrderByBrand_Command);
            // 
            // MniOrderByDiagonalDesc
            // 
            this.MniOrderByDiagonalDesc.Name = "MniOrderByDiagonalDesc";
            this.MniOrderByDiagonalDesc.Size = new System.Drawing.Size(258, 26);
            this.MniOrderByDiagonalDesc.Text = "По убыванию диагонали";
            // 
            // MniOrderByArtisan
            // 
            this.MniOrderByArtisan.Name = "MniOrderByArtisan";
            this.MniOrderByArtisan.Size = new System.Drawing.Size(258, 26);
            this.MniOrderByArtisan.Text = "По мастеру";
            // 
            // MniOrderByOwner
            // 
            this.MniOrderByOwner.Name = "MniOrderByOwner";
            this.MniOrderByOwner.Size = new System.Drawing.Size(258, 26);
            this.MniOrderByOwner.Text = "По владельцу";
            // 
            // MniSelectWhere
            // 
            this.MniSelectWhere.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniSelectWhereInexpensive,
            this.MniSelectWhereArtisan,
            this.MniSelectWhereDiagonal});
            this.MniSelectWhere.Name = "MniSelectWhere";
            this.MniSelectWhere.Size = new System.Drawing.Size(85, 25);
            this.MniSelectWhere.Text = "Выборка";
            // 
            // MniSelectWhereInexpensive
            // 
            this.MniSelectWhereInexpensive.Name = "MniSelectWhereInexpensive";
            this.MniSelectWhereInexpensive.Size = new System.Drawing.Size(285, 26);
            this.MniSelectWhereInexpensive.Text = "Самые недорогие ремонты...";
            this.MniSelectWhereInexpensive.Click += new System.EventHandler(this.SelectMinPrice_Command);
            // 
            // MniSelectWhereArtisan
            // 
            this.MniSelectWhereArtisan.Name = "MniSelectWhereArtisan";
            this.MniSelectWhereArtisan.Size = new System.Drawing.Size(285, 26);
            this.MniSelectWhereArtisan.Text = "Ремонты мастера...";
            this.MniSelectWhereArtisan.Click += new System.EventHandler(this.SelectArtisan_Command);
            // 
            // MniSelectWhereDiagonal
            // 
            this.MniSelectWhereDiagonal.Name = "MniSelectWhereDiagonal";
            this.MniSelectWhereDiagonal.Size = new System.Drawing.Size(285, 26);
            this.MniSelectWhereDiagonal.Text = "Телевизоры с диагональю...";
            // 
            // MniHelp
            // 
            this.MniHelp.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniHelpAbout});
            this.MniHelp.Name = "MniHelp";
            this.MniHelp.Size = new System.Drawing.Size(82, 25);
            this.MniHelp.Text = "Справка";
            // 
            // MniHelpAbout
            // 
            this.MniHelpAbout.Name = "MniHelpAbout";
            this.MniHelpAbout.Size = new System.Drawing.Size(185, 26);
            this.MniHelpAbout.Text = "О программе...";
            this.MniHelpAbout.Click += new System.EventHandler(this.About_Command);
            // 
            // TbsMain
            // 
            this.TbsMain.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TbsMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButton1,
            this.toolStripButton2,
            this.toolStripSeparator1,
            this.toolStripButton3,
            this.toolStripButton4,
            this.toolStripButton5,
            this.toolStripSeparator2,
            this.TsbOrderByBrand,
            this.TsbOrderByDiagonalDesc,
            this.toolStripButton8,
            this.toolStripButton9,
            this.toolStripSeparator3,
            this.TsbMinPrice,
            this.CbxArtisans,
            this.TsbArtisanSelection,
            this.toolStripButton12,
            this.toolStripSeparator4,
            this.TsbAbout,
            this.TsbExit});
            this.TbsMain.Location = new System.Drawing.Point(0, 29);
            this.TbsMain.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.TbsMain.Name = "TbsMain";
            this.TbsMain.Size = new System.Drawing.Size(1169, 39);
            this.TbsMain.TabIndex = 1;
            this.TbsMain.Text = "toolStrip1";
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 39);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 39);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(6, 39);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(6, 39);
            // 
            // StsMain
            // 
            this.StsMain.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.StsMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.StlMain});
            this.StsMain.Location = new System.Drawing.Point(0, 544);
            this.StsMain.Name = "StsMain";
            this.StsMain.Size = new System.Drawing.Size(1169, 22);
            this.StsMain.TabIndex = 2;
            this.StsMain.Text = "statusStrip1";
            // 
            // StlMain
            // 
            this.StlMain.Name = "StlMain";
            this.StlMain.Size = new System.Drawing.Size(1154, 17);
            this.StlMain.Spring = true;
            this.StlMain.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // LblHeader
            // 
            this.LblHeader.Font = new System.Drawing.Font("Consolas", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblHeader.Location = new System.Drawing.Point(8, 72);
            this.LblHeader.Name = "LblHeader";
            this.LblHeader.Size = new System.Drawing.Size(1136, 40);
            this.LblHeader.TabIndex = 3;
            this.LblHeader.Text = "Ремонтная мастерская, телевизоры в ремонте";
            this.LblHeader.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // LbxTelevisions
            // 
            this.LbxTelevisions.Font = new System.Drawing.Font("Consolas", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LbxTelevisions.FormattingEnabled = true;
            this.LbxTelevisions.ItemHeight = 19;
            this.LbxTelevisions.Location = new System.Drawing.Point(8, 112);
            this.LbxTelevisions.Name = "LbxTelevisions";
            this.LbxTelevisions.ScrollAlwaysVisible = true;
            this.LbxTelevisions.Size = new System.Drawing.Size(1136, 422);
            this.LbxTelevisions.TabIndex = 4;
            // 
            // CbxArtisans
            // 
            this.CbxArtisans.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CbxArtisans.Margin = new System.Windows.Forms.Padding(6, 0, 1, 0);
            this.CbxArtisans.Name = "CbxArtisans";
            this.CbxArtisans.Size = new System.Drawing.Size(121, 39);
            // 
            // toolStripButton1
            // 
            this.toolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton1.Image")));
            this.toolStripButton1.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.Size = new System.Drawing.Size(23, 36);
            this.toolStripButton1.Text = "toolStripButton1";
            // 
            // toolStripButton2
            // 
            this.toolStripButton2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton2.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton2.Image")));
            this.toolStripButton2.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripButton2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton2.Name = "toolStripButton2";
            this.toolStripButton2.Size = new System.Drawing.Size(23, 36);
            this.toolStripButton2.Text = "toolStripButton2";
            // 
            // toolStripButton3
            // 
            this.toolStripButton3.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton3.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton3.Image")));
            this.toolStripButton3.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripButton3.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton3.Name = "toolStripButton3";
            this.toolStripButton3.Size = new System.Drawing.Size(23, 36);
            this.toolStripButton3.Text = "toolStripButton3";
            // 
            // toolStripButton4
            // 
            this.toolStripButton4.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton4.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton4.Image")));
            this.toolStripButton4.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripButton4.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton4.Name = "toolStripButton4";
            this.toolStripButton4.Size = new System.Drawing.Size(23, 36);
            this.toolStripButton4.Text = "toolStripButton4";
            // 
            // toolStripButton5
            // 
            this.toolStripButton5.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton5.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton5.Image")));
            this.toolStripButton5.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripButton5.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton5.Name = "toolStripButton5";
            this.toolStripButton5.Size = new System.Drawing.Size(23, 36);
            this.toolStripButton5.Text = "toolStripButton5";
            // 
            // TsbOrderByBrand
            // 
            this.TsbOrderByBrand.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbOrderByBrand.Image = ((System.Drawing.Image)(resources.GetObject("TsbOrderByBrand.Image")));
            this.TsbOrderByBrand.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbOrderByBrand.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbOrderByBrand.Name = "TsbOrderByBrand";
            this.TsbOrderByBrand.Size = new System.Drawing.Size(23, 36);
            this.TsbOrderByBrand.ToolTipText = "По производителю и типу";
            this.TsbOrderByBrand.Click += new System.EventHandler(this.OrderByBrand_Command);
            // 
            // TsbOrderByDiagonalDesc
            // 
            this.TsbOrderByDiagonalDesc.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbOrderByDiagonalDesc.Image = ((System.Drawing.Image)(resources.GetObject("TsbOrderByDiagonalDesc.Image")));
            this.TsbOrderByDiagonalDesc.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbOrderByDiagonalDesc.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbOrderByDiagonalDesc.Name = "TsbOrderByDiagonalDesc";
            this.TsbOrderByDiagonalDesc.Size = new System.Drawing.Size(23, 36);
            this.TsbOrderByDiagonalDesc.ToolTipText = "По убыванию диагонали экрана";
            this.TsbOrderByDiagonalDesc.Click += new System.EventHandler(this.OrderByDiagonalDesc_Command);
            // 
            // toolStripButton8
            // 
            this.toolStripButton8.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton8.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton8.Image")));
            this.toolStripButton8.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripButton8.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton8.Name = "toolStripButton8";
            this.toolStripButton8.Size = new System.Drawing.Size(23, 36);
            this.toolStripButton8.Text = "toolStripButton8";
            // 
            // toolStripButton9
            // 
            this.toolStripButton9.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton9.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton9.Image")));
            this.toolStripButton9.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripButton9.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton9.Name = "toolStripButton9";
            this.toolStripButton9.Size = new System.Drawing.Size(23, 36);
            this.toolStripButton9.Text = "toolStripButton9";
            // 
            // TsbMinPrice
            // 
            this.TsbMinPrice.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbMinPrice.Image = ((System.Drawing.Image)(resources.GetObject("TsbMinPrice.Image")));
            this.TsbMinPrice.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbMinPrice.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbMinPrice.Name = "TsbMinPrice";
            this.TsbMinPrice.Size = new System.Drawing.Size(23, 36);
            this.TsbMinPrice.ToolTipText = "Самые недорогие ремонты";
            this.TsbMinPrice.Click += new System.EventHandler(this.SelectMinPrice_Command);
            // 
            // TsbArtisanSelection
            // 
            this.TsbArtisanSelection.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbArtisanSelection.Image = ((System.Drawing.Image)(resources.GetObject("TsbArtisanSelection.Image")));
            this.TsbArtisanSelection.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbArtisanSelection.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbArtisanSelection.Margin = new System.Windows.Forms.Padding(0, 1, 6, 2);
            this.TsbArtisanSelection.Name = "TsbArtisanSelection";
            this.TsbArtisanSelection.Size = new System.Drawing.Size(23, 36);
            this.TsbArtisanSelection.ToolTipText = "Выборка ремонтов заданного мастера";
            this.TsbArtisanSelection.Click += new System.EventHandler(this.SelectArtisanTbr_Command);
            // 
            // toolStripButton12
            // 
            this.toolStripButton12.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton12.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton12.Image")));
            this.toolStripButton12.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripButton12.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton12.Name = "toolStripButton12";
            this.toolStripButton12.Size = new System.Drawing.Size(23, 36);
            this.toolStripButton12.Text = "toolStripButton12";
            // 
            // TsbAbout
            // 
            this.TsbAbout.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbAbout.Image = global::_HwE_MultiForms.Properties.Resources.help;
            this.TsbAbout.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbAbout.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbAbout.Name = "TsbAbout";
            this.TsbAbout.Size = new System.Drawing.Size(36, 36);
            this.TsbAbout.ToolTipText = "Сведения о программе";
            this.TsbAbout.Click += new System.EventHandler(this.About_Command);
            // 
            // TsbExit
            // 
            this.TsbExit.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.TsbExit.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbExit.Image = global::_HwE_MultiForms.Properties.Resources.door_out;
            this.TsbExit.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbExit.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbExit.Name = "TsbExit";
            this.TsbExit.Size = new System.Drawing.Size(36, 36);
            this.TsbExit.ToolTipText = "Выход из приложения";
            this.TsbExit.Click += new System.EventHandler(this.Exit_Command);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1169, 566);
            this.Controls.Add(this.LbxTelevisions);
            this.Controls.Add(this.LblHeader);
            this.Controls.Add(this.StsMain);
            this.Controls.Add(this.TbsMain);
            this.Controls.Add(this.MnsMain);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.MnsMain;
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(1185, 605);
            this.MinimumSize = new System.Drawing.Size(1185, 605);
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Задание на 17.11.2021 - использование нескольких форм в проекте";
            this.MnsMain.ResumeLayout(false);
            this.MnsMain.PerformLayout();
            this.TbsMain.ResumeLayout(false);
            this.TbsMain.PerformLayout();
            this.StsMain.ResumeLayout(false);
            this.StsMain.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip MnsMain;
        private System.Windows.Forms.ToolStrip TbsMain;
        private System.Windows.Forms.StatusStrip StsMain;
        private System.Windows.Forms.ToolStripMenuItem MniFile;
        private System.Windows.Forms.ToolStripMenuItem MniFileExit;
        private System.Windows.Forms.ToolStripMenuItem MniRepairShop;
        private System.Windows.Forms.ToolStripMenuItem MniRepairShopNew;
        private System.Windows.Forms.ToolStripMenuItem MniRepairShopEdit;
        private System.Windows.Forms.ToolStripMenuItem MniTelevisions;
        private System.Windows.Forms.ToolStripMenuItem MniTelevisionsAdd;
        private System.Windows.Forms.ToolStripMenuItem MniTelevisionsEdit;
        private System.Windows.Forms.ToolStripSeparator MniTelevisionsSep1;
        private System.Windows.Forms.ToolStripMenuItem MniTelevisionsRemoveAt;
        private System.Windows.Forms.ToolStripMenuItem MniOrderBy;
        private System.Windows.Forms.ToolStripMenuItem MniOrderByBrand;
        private System.Windows.Forms.ToolStripMenuItem MniOrderByDiagonalDesc;
        private System.Windows.Forms.ToolStripMenuItem MniOrderByArtisan;
        private System.Windows.Forms.ToolStripMenuItem MniOrderByOwner;
        private System.Windows.Forms.ToolStripMenuItem MniSelectWhere;
        private System.Windows.Forms.ToolStripMenuItem MniSelectWhereInexpensive;
        private System.Windows.Forms.ToolStripMenuItem MniSelectWhereArtisan;
        private System.Windows.Forms.ToolStripMenuItem MniSelectWhereDiagonal;
        private System.Windows.Forms.ToolStripMenuItem MniHelp;
        private System.Windows.Forms.ToolStripMenuItem MniHelpAbout;
        private System.Windows.Forms.Label LblHeader;
        private System.Windows.Forms.ListBox LbxTelevisions;
        private System.Windows.Forms.ToolStripStatusLabel StlMain;
        private System.Windows.Forms.ToolStripButton toolStripButton1;
        private System.Windows.Forms.ToolStripButton toolStripButton2;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripButton toolStripButton3;
        private System.Windows.Forms.ToolStripButton toolStripButton4;
        private System.Windows.Forms.ToolStripButton toolStripButton5;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripButton TsbOrderByBrand;
        private System.Windows.Forms.ToolStripButton TsbOrderByDiagonalDesc;
        private System.Windows.Forms.ToolStripButton toolStripButton8;
        private System.Windows.Forms.ToolStripButton toolStripButton9;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripButton TsbMinPrice;
        private System.Windows.Forms.ToolStripButton TsbArtisanSelection;
        private System.Windows.Forms.ToolStripButton toolStripButton12;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripButton TsbAbout;
        private System.Windows.Forms.ToolStripButton TsbExit;
        private System.Windows.Forms.ToolStripComboBox CbxArtisans;
    }
}

