﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using _HwE_MultiForms.Models;

namespace _HwE_MultiForms.Views
{
    public partial class SelectionsForm : Form
    {
        public SelectionsForm():this(new List<Television>(), "Нет данных для отображения") 
        { } // SelectionsForm

        public SelectionsForm(List<Television> televisions, string header) {
            InitializeComponent();

            // вывести заголовок
            LblHeader.Text = $"  {header}\r\n{Television.Header}";

            // задать привязку
            LbxTelevisions.DataSource = televisions;

            // свойство для отображения в ListBox
            LbxTelevisions.DisplayMember = "TableRow";
        } // SelectionsForm
    }
}
