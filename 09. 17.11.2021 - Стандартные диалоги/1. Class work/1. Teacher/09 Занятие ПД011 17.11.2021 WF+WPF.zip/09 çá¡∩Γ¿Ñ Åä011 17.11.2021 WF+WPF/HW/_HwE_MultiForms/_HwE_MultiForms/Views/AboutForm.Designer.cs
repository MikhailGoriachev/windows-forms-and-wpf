﻿namespace _HwE_MultiForms.Views
{
    partial class AboutForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AboutForm));
            this.TxbAbout = new System.Windows.Forms.TextBox();
            this.BtnOk = new System.Windows.Forms.Button();
            this.LblAbout = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // TxbAbout
            // 
            this.TxbAbout.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.TxbAbout.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TxbAbout.Location = new System.Drawing.Point(8, 8);
            this.TxbAbout.Multiline = true;
            this.TxbAbout.Name = "TxbAbout";
            this.TxbAbout.ReadOnly = true;
            this.TxbAbout.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.TxbAbout.Size = new System.Drawing.Size(776, 384);
            this.TxbAbout.TabIndex = 0;
            this.TxbAbout.Text = resources.GetString("TxbAbout.Text");
            // 
            // BtnOk
            // 
            this.BtnOk.BackColor = System.Drawing.Color.LightCyan;
            this.BtnOk.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.BtnOk.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BtnOk.Location = new System.Drawing.Point(624, 409);
            this.BtnOk.Name = "BtnOk";
            this.BtnOk.Size = new System.Drawing.Size(160, 32);
            this.BtnOk.TabIndex = 1;
            this.BtnOk.Text = "OK";
            this.BtnOk.UseVisualStyleBackColor = false;
            // 
            // LblAbout
            // 
            this.LblAbout.Font = new System.Drawing.Font("Verdana", 11.25F);
            this.LblAbout.Location = new System.Drawing.Point(8, 416);
            this.LblAbout.Name = "LblAbout";
            this.LblAbout.Size = new System.Drawing.Size(600, 23);
            this.LblAbout.TabIndex = 2;
            this.LblAbout.Text = "Студент Программер, группа ПД011, Донецк, 2021";
            this.LblAbout.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // AboutForm
            // 
            this.AcceptButton = this.BtnOk;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.LblAbout);
            this.Controls.Add(this.BtnOk);
            this.Controls.Add(this.TxbAbout);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(816, 489);
            this.MinimizeBox = false;
            this.MinimumSize = new System.Drawing.Size(816, 489);
            this.Name = "AboutForm";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Сведения о приложении и разработчике";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox TxbAbout;
        private System.Windows.Forms.Button BtnOk;
        private System.Windows.Forms.Label LblAbout;
    }
}