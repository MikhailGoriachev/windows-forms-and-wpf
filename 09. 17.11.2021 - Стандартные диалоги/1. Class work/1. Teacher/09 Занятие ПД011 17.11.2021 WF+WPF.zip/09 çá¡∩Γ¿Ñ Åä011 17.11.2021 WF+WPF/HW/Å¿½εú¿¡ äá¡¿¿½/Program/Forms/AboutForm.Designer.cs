﻿
namespace Program.Forms
{
    partial class AboutForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AboutForm));
            this.TxtBxAbout = new System.Windows.Forms.TextBox();
            this.BtnAboutClose = new System.Windows.Forms.Button();
            this.LblAboutCreator = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // TxtBxAbout
            // 
            this.TxtBxAbout.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TxtBxAbout.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.TxtBxAbout.Dock = System.Windows.Forms.DockStyle.Top;
            this.TxtBxAbout.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TxtBxAbout.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.TxtBxAbout.Location = new System.Drawing.Point(0, 0);
            this.TxtBxAbout.Multiline = true;
            this.TxtBxAbout.Name = "TxtBxAbout";
            this.TxtBxAbout.ReadOnly = true;
            this.TxtBxAbout.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.TxtBxAbout.Size = new System.Drawing.Size(897, 323);
            this.TxtBxAbout.TabIndex = 0;
            this.TxtBxAbout.Text = resources.GetString("TxtBxAbout.Text");
            // 
            // BtnAboutClose
            // 
            this.BtnAboutClose.BackColor = System.Drawing.Color.Gold;
            this.BtnAboutClose.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BtnAboutClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnAboutClose.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BtnAboutClose.Location = new System.Drawing.Point(292, 383);
            this.BtnAboutClose.MaximumSize = new System.Drawing.Size(313, 66);
            this.BtnAboutClose.MinimumSize = new System.Drawing.Size(313, 66);
            this.BtnAboutClose.Name = "BtnAboutClose";
            this.BtnAboutClose.Size = new System.Drawing.Size(313, 66);
            this.BtnAboutClose.TabIndex = 1;
            this.BtnAboutClose.Text = "Ок";
            this.BtnAboutClose.UseVisualStyleBackColor = false;
            this.BtnAboutClose.Click += new System.EventHandler(this.BtnAboutClose_Click);
            // 
            // LblAboutCreator
            // 
            this.LblAboutCreator.Dock = System.Windows.Forms.DockStyle.Top;
            this.LblAboutCreator.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblAboutCreator.ForeColor = System.Drawing.Color.Goldenrod;
            this.LblAboutCreator.Location = new System.Drawing.Point(0, 323);
            this.LblAboutCreator.Name = "LblAboutCreator";
            this.LblAboutCreator.Size = new System.Drawing.Size(897, 57);
            this.LblAboutCreator.TabIndex = 2;
            this.LblAboutCreator.Text = "Разработчик: Пилюгин Даниил. Шаг ПД011";
            this.LblAboutCreator.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // AboutForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(897, 462);
            this.Controls.Add(this.LblAboutCreator);
            this.Controls.Add(this.BtnAboutClose);
            this.Controls.Add(this.TxtBxAbout);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "AboutForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "About programm";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox TxtBxAbout;
        private System.Windows.Forms.Button BtnAboutClose;
        private System.Windows.Forms.Label LblAboutCreator;
    }
}