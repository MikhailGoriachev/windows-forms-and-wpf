﻿
namespace Program
{
    partial class MainForm
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.MenuStrip = new System.Windows.Forms.MenuStrip();
            this.TSMenuFile = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripSeparator();
            this.TSMenuExit = new System.Windows.Forms.ToolStripMenuItem();
            this.TSMenuAbout = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStrip = new System.Windows.Forms.ToolStrip();
            this.TStripBtnEditShop = new System.Windows.Forms.ToolStripButton();
            this.TStripBtnAddTelevisions = new System.Windows.Forms.ToolStripButton();
            this.TStripBtnAdd = new System.Windows.Forms.ToolStripButton();
            this.TStripBtnDelete = new System.Windows.Forms.ToolStripButton();
            this.TStripBtnDeleteAll = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.TStripBtnSort = new System.Windows.Forms.ToolStripDropDownButton();
            this.TSMISortByBrand = new System.Windows.Forms.ToolStripMenuItem();
            this.TSMISortByDiagonal = new System.Windows.Forms.ToolStripMenuItem();
            this.TSMISortByMaster = new System.Windows.Forms.ToolStripMenuItem();
            this.TSMISortByClient = new System.Windows.Forms.ToolStripMenuItem();
            this.TStripBtnEdit = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.TStripBtnShowByDiagonal = new System.Windows.Forms.ToolStripButton();
            this.TStripBtnShowByPrice = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.TStripBtnExit = new System.Windows.Forms.ToolStripButton();
            this.StatStrip = new System.Windows.Forms.StatusStrip();
            this.StSLMain = new System.Windows.Forms.ToolStripStatusLabel();
            this.LBox = new System.Windows.Forms.ListBox();
            this.CnMenuLBox = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.добавитьЭлементToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.удалитьЭлементToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.сортировкаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.поБрендуToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.поДиагоналиToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.поМастеруToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.поКлиентуToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.редактироватьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.LblHeadOfTable = new System.Windows.Forms.Label();
            this.LblAboutShop = new System.Windows.Forms.Label();
            this.CnMenuMain = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.оПрограммеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripSeparator();
            this.выходToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuStrip.SuspendLayout();
            this.ToolStrip.SuspendLayout();
            this.StatStrip.SuspendLayout();
            this.CnMenuLBox.SuspendLayout();
            this.CnMenuMain.SuspendLayout();
            this.SuspendLayout();
            // 
            // MenuStrip
            // 
            this.MenuStrip.AllowDrop = true;
            this.MenuStrip.BackColor = System.Drawing.Color.Gold;
            this.MenuStrip.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.MenuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.TSMenuFile,
            this.TSMenuAbout});
            this.MenuStrip.Location = new System.Drawing.Point(0, 0);
            this.MenuStrip.Name = "MenuStrip";
            this.MenuStrip.Size = new System.Drawing.Size(1382, 42);
            this.MenuStrip.TabIndex = 3;
            this.MenuStrip.Text = "menuStrip1";
            // 
            // TSMenuFile
            // 
            this.TSMenuFile.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem1,
            this.TSMenuExit});
            this.TSMenuFile.Font = new System.Drawing.Font("Century Gothic", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TSMenuFile.Image = ((System.Drawing.Image)(resources.GetObject("TSMenuFile.Image")));
            this.TSMenuFile.Name = "TSMenuFile";
            this.TSMenuFile.Size = new System.Drawing.Size(125, 38);
            this.TSMenuFile.Text = "&Файл";
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(184, 6);
            // 
            // TSMenuExit
            // 
            this.TSMenuExit.Image = global::Program.Properties.Resources.exit_icon;
            this.TSMenuExit.Name = "TSMenuExit";
            this.TSMenuExit.Size = new System.Drawing.Size(187, 38);
            this.TSMenuExit.Text = "&Выход";
            this.TSMenuExit.Click += new System.EventHandler(this.Exit_Command);
            // 
            // TSMenuAbout
            // 
            this.TSMenuAbout.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.TSMenuAbout.Font = new System.Drawing.Font("Century Gothic", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TSMenuAbout.Image = global::Program.Properties.Resources.share_icon;
            this.TSMenuAbout.Name = "TSMenuAbout";
            this.TSMenuAbout.Size = new System.Drawing.Size(251, 38);
            this.TSMenuAbout.Text = "&О программе";
            this.TSMenuAbout.Click += new System.EventHandler(this.AboutProgram_Command);
            // 
            // ToolStrip
            // 
            this.ToolStrip.BackColor = System.Drawing.SystemColors.HighlightText;
            this.ToolStrip.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.ToolStrip.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.ToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.TStripBtnEditShop,
            this.TStripBtnAddTelevisions,
            this.TStripBtnAdd,
            this.TStripBtnDelete,
            this.TStripBtnDeleteAll,
            this.toolStripSeparator1,
            this.TStripBtnSort,
            this.TStripBtnEdit,
            this.toolStripSeparator2,
            this.TStripBtnShowByDiagonal,
            this.TStripBtnShowByPrice,
            this.toolStripButton1,
            this.TStripBtnExit});
            this.ToolStrip.Location = new System.Drawing.Point(0, 42);
            this.ToolStrip.Name = "ToolStrip";
            this.ToolStrip.Padding = new System.Windows.Forms.Padding(0);
            this.ToolStrip.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional;
            this.ToolStrip.Size = new System.Drawing.Size(1382, 55);
            this.ToolStrip.TabIndex = 5;
            this.ToolStrip.Text = "TStrip";
            // 
            // TStripBtnEditShop
            // 
            this.TStripBtnEditShop.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TStripBtnEditShop.Image = global::Program.Properties.Resources.television;
            this.TStripBtnEditShop.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TStripBtnEditShop.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TStripBtnEditShop.Name = "TStripBtnEditShop";
            this.TStripBtnEditShop.Size = new System.Drawing.Size(52, 52);
            this.TStripBtnEditShop.Text = "Данные магазина";
            this.TStripBtnEditShop.Click += new System.EventHandler(this.Shop_Edit_Command);
            // 
            // TStripBtnAddTelevisions
            // 
            this.TStripBtnAddTelevisions.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TStripBtnAddTelevisions.Image = global::Program.Properties.Resources.add_group_icon;
            this.TStripBtnAddTelevisions.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TStripBtnAddTelevisions.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TStripBtnAddTelevisions.Margin = new System.Windows.Forms.Padding(10, 1, 10, 2);
            this.TStripBtnAddTelevisions.Name = "TStripBtnAddTelevisions";
            this.TStripBtnAddTelevisions.Size = new System.Drawing.Size(52, 52);
            this.TStripBtnAddTelevisions.Text = "Формирование коллекции";
            this.TStripBtnAddTelevisions.Click += new System.EventHandler(this.Create_All_Command);
            // 
            // TStripBtnAdd
            // 
            this.TStripBtnAdd.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TStripBtnAdd.Image = global::Program.Properties.Resources.add_circle_icon;
            this.TStripBtnAdd.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TStripBtnAdd.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TStripBtnAdd.Margin = new System.Windows.Forms.Padding(10, 1, 10, 2);
            this.TStripBtnAdd.Name = "TStripBtnAdd";
            this.TStripBtnAdd.Size = new System.Drawing.Size(52, 52);
            this.TStripBtnAdd.Text = "Добавить телевизор";
            this.TStripBtnAdd.Click += new System.EventHandler(this.AddTelev_Command);
            // 
            // TStripBtnDelete
            // 
            this.TStripBtnDelete.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TStripBtnDelete.Image = global::Program.Properties.Resources.circle_cross_icon;
            this.TStripBtnDelete.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TStripBtnDelete.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TStripBtnDelete.Margin = new System.Windows.Forms.Padding(10, 1, 10, 2);
            this.TStripBtnDelete.Name = "TStripBtnDelete";
            this.TStripBtnDelete.Size = new System.Drawing.Size(52, 52);
            this.TStripBtnDelete.Text = "Удалить телевизор";
            this.TStripBtnDelete.Click += new System.EventHandler(this.Delete_Command);
            // 
            // TStripBtnDeleteAll
            // 
            this.TStripBtnDeleteAll.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TStripBtnDeleteAll.Image = global::Program.Properties.Resources.delete_all_icon;
            this.TStripBtnDeleteAll.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TStripBtnDeleteAll.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TStripBtnDeleteAll.Margin = new System.Windows.Forms.Padding(10, 1, 10, 2);
            this.TStripBtnDeleteAll.Name = "TStripBtnDeleteAll";
            this.TStripBtnDeleteAll.Size = new System.Drawing.Size(52, 52);
            this.TStripBtnDeleteAll.Text = "Удалить все телевизоры";
            this.TStripBtnDeleteAll.Click += new System.EventHandler(this.Delete_All_Command);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.BackColor = System.Drawing.Color.Gold;
            this.toolStripSeparator1.ForeColor = System.Drawing.Color.Gold;
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 55);
            // 
            // TStripBtnSort
            // 
            this.TStripBtnSort.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TStripBtnSort.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.TSMISortByBrand,
            this.TSMISortByDiagonal,
            this.TSMISortByMaster,
            this.TSMISortByClient});
            this.TStripBtnSort.Image = global::Program.Properties.Resources.alpha_asc_down_navigation_sort_icon;
            this.TStripBtnSort.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TStripBtnSort.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TStripBtnSort.Margin = new System.Windows.Forms.Padding(10, 1, 10, 2);
            this.TStripBtnSort.Name = "TStripBtnSort";
            this.TStripBtnSort.Size = new System.Drawing.Size(62, 52);
            this.TStripBtnSort.Text = "Сортировка";
            // 
            // TSMISortByBrand
            // 
            this.TSMISortByBrand.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TSMISortByBrand.Name = "TSMISortByBrand";
            this.TSMISortByBrand.Size = new System.Drawing.Size(444, 26);
            this.TSMISortByBrand.Text = "По производителю и типу";
            this.TSMISortByBrand.Click += new System.EventHandler(this.SortedByBrandNType_Command);
            // 
            // TSMISortByDiagonal
            // 
            this.TSMISortByDiagonal.Font = new System.Drawing.Font("Century Gothic", 10.8F);
            this.TSMISortByDiagonal.Name = "TSMISortByDiagonal";
            this.TSMISortByDiagonal.Size = new System.Drawing.Size(444, 26);
            this.TSMISortByDiagonal.Text = "По убыванию диагонали экрана";
            this.TSMISortByDiagonal.Click += new System.EventHandler(this.SortedByDiag_Command);
            // 
            // TSMISortByMaster
            // 
            this.TSMISortByMaster.Font = new System.Drawing.Font("Century Gothic", 10.8F);
            this.TSMISortByMaster.Name = "TSMISortByMaster";
            this.TSMISortByMaster.Size = new System.Drawing.Size(444, 26);
            this.TSMISortByMaster.Text = "По мастеру, выполняющему ремонт";
            this.TSMISortByMaster.Click += new System.EventHandler(this.SortedByMaster_Command);
            // 
            // TSMISortByClient
            // 
            this.TSMISortByClient.Font = new System.Drawing.Font("Century Gothic", 10.8F);
            this.TSMISortByClient.Name = "TSMISortByClient";
            this.TSMISortByClient.Size = new System.Drawing.Size(444, 26);
            this.TSMISortByClient.Text = "По владельцу телевизора";
            this.TSMISortByClient.Click += new System.EventHandler(this.SortedByClient_Command);
            // 
            // TStripBtnEdit
            // 
            this.TStripBtnEdit.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TStripBtnEdit.Image = global::Program.Properties.Resources.editor_icon;
            this.TStripBtnEdit.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TStripBtnEdit.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TStripBtnEdit.Margin = new System.Windows.Forms.Padding(10, 1, 10, 2);
            this.TStripBtnEdit.Name = "TStripBtnEdit";
            this.TStripBtnEdit.Size = new System.Drawing.Size(52, 52);
            this.TStripBtnEdit.Text = "Редактировать данные о телевизоре";
            this.TStripBtnEdit.Click += new System.EventHandler(this.Edit_Command);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 55);
            // 
            // TStripBtnShowByDiagonal
            // 
            this.TStripBtnShowByDiagonal.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TStripBtnShowByDiagonal.Image = global::Program.Properties.Resources.diagonal_icon;
            this.TStripBtnShowByDiagonal.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TStripBtnShowByDiagonal.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TStripBtnShowByDiagonal.Margin = new System.Windows.Forms.Padding(10, 1, 10, 2);
            this.TStripBtnShowByDiagonal.Name = "TStripBtnShowByDiagonal";
            this.TStripBtnShowByDiagonal.Size = new System.Drawing.Size(52, 52);
            this.TStripBtnShowByDiagonal.Text = "Показать телевизоры по заданной диагонали";
            // 
            // TStripBtnShowByPrice
            // 
            this.TStripBtnShowByPrice.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TStripBtnShowByPrice.Image = global::Program.Properties.Resources.price_icon;
            this.TStripBtnShowByPrice.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TStripBtnShowByPrice.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TStripBtnShowByPrice.Margin = new System.Windows.Forms.Padding(10, 1, 10, 2);
            this.TStripBtnShowByPrice.Name = "TStripBtnShowByPrice";
            this.TStripBtnShowByPrice.Size = new System.Drawing.Size(52, 52);
            this.TStripBtnShowByPrice.Text = "Показать телевизоры по заданной стоимости ремонта";
            // 
            // toolStripButton1
            // 
            this.toolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton1.Image = global::Program.Properties.Resources.specialist_icon;
            this.toolStripButton1.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton1.Margin = new System.Windows.Forms.Padding(10, 1, 10, 2);
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.Size = new System.Drawing.Size(52, 52);
            this.toolStripButton1.Text = "Показать телевизоры по заданному мастеру";
            // 
            // TStripBtnExit
            // 
            this.TStripBtnExit.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.TStripBtnExit.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TStripBtnExit.Image = global::Program.Properties.Resources.exit_icon;
            this.TStripBtnExit.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TStripBtnExit.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TStripBtnExit.Margin = new System.Windows.Forms.Padding(10, 1, 10, 2);
            this.TStripBtnExit.Name = "TStripBtnExit";
            this.TStripBtnExit.Size = new System.Drawing.Size(52, 52);
            this.TStripBtnExit.Text = "toolStripButton5";
            this.TStripBtnExit.Click += new System.EventHandler(this.Exit_Command);
            // 
            // StatStrip
            // 
            this.StatStrip.BackColor = System.Drawing.Color.Gold;
            this.StatStrip.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.StatStrip.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.StatStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.StSLMain});
            this.StatStrip.Location = new System.Drawing.Point(0, 689);
            this.StatStrip.Name = "StatStrip";
            this.StatStrip.Size = new System.Drawing.Size(1382, 22);
            this.StatStrip.TabIndex = 6;
            // 
            // StSLMain
            // 
            this.StSLMain.Name = "StSLMain";
            this.StSLMain.Size = new System.Drawing.Size(0, 16);
            // 
            // LBox
            // 
            this.LBox.ContextMenuStrip = this.CnMenuLBox;
            this.LBox.Font = new System.Drawing.Font("Consolas", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LBox.FormattingEnabled = true;
            this.LBox.HorizontalScrollbar = true;
            this.LBox.ItemHeight = 23;
            this.LBox.Location = new System.Drawing.Point(51, 158);
            this.LBox.Name = "LBox";
            this.LBox.Size = new System.Drawing.Size(1279, 510);
            this.LBox.TabIndex = 7;
            // 
            // CnMenuLBox
            // 
            this.CnMenuLBox.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.CnMenuLBox.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.добавитьЭлементToolStripMenuItem,
            this.удалитьЭлементToolStripMenuItem,
            this.сортировкаToolStripMenuItem,
            this.редактироватьToolStripMenuItem});
            this.CnMenuLBox.Name = "CnMenuLBox";
            this.CnMenuLBox.Size = new System.Drawing.Size(243, 108);
            // 
            // добавитьЭлементToolStripMenuItem
            // 
            this.добавитьЭлементToolStripMenuItem.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.добавитьЭлементToolStripMenuItem.Image = global::Program.Properties.Resources.add_circle_icon;
            this.добавитьЭлементToolStripMenuItem.Name = "добавитьЭлементToolStripMenuItem";
            this.добавитьЭлементToolStripMenuItem.Size = new System.Drawing.Size(242, 26);
            this.добавитьЭлементToolStripMenuItem.Text = "Добавить элемент";
            this.добавитьЭлементToolStripMenuItem.Click += new System.EventHandler(this.AddTelev_Command);
            // 
            // удалитьЭлементToolStripMenuItem
            // 
            this.удалитьЭлементToolStripMenuItem.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.удалитьЭлементToolStripMenuItem.Image = global::Program.Properties.Resources.circle_cross_icon;
            this.удалитьЭлементToolStripMenuItem.Name = "удалитьЭлементToolStripMenuItem";
            this.удалитьЭлементToolStripMenuItem.Size = new System.Drawing.Size(242, 26);
            this.удалитьЭлементToolStripMenuItem.Text = "Удалить элемент";
            this.удалитьЭлементToolStripMenuItem.Click += new System.EventHandler(this.Delete_Command);
            // 
            // сортировкаToolStripMenuItem
            // 
            this.сортировкаToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.поБрендуToolStripMenuItem,
            this.поДиагоналиToolStripMenuItem,
            this.поМастеруToolStripMenuItem,
            this.поКлиентуToolStripMenuItem});
            this.сортировкаToolStripMenuItem.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.сортировкаToolStripMenuItem.Image = global::Program.Properties.Resources.alpha_asc_down_navigation_sort_icon;
            this.сортировкаToolStripMenuItem.Name = "сортировкаToolStripMenuItem";
            this.сортировкаToolStripMenuItem.Size = new System.Drawing.Size(242, 26);
            this.сортировкаToolStripMenuItem.Text = "Сортировка";
            // 
            // поБрендуToolStripMenuItem
            // 
            this.поБрендуToolStripMenuItem.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.поБрендуToolStripMenuItem.Name = "поБрендуToolStripMenuItem";
            this.поБрендуToolStripMenuItem.Size = new System.Drawing.Size(212, 26);
            this.поБрендуToolStripMenuItem.Text = "По бренду";
            this.поБрендуToolStripMenuItem.Click += new System.EventHandler(this.SortedByBrandNType_Command);
            // 
            // поДиагоналиToolStripMenuItem
            // 
            this.поДиагоналиToolStripMenuItem.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.поДиагоналиToolStripMenuItem.Name = "поДиагоналиToolStripMenuItem";
            this.поДиагоналиToolStripMenuItem.Size = new System.Drawing.Size(212, 26);
            this.поДиагоналиToolStripMenuItem.Text = "По диагонали";
            this.поДиагоналиToolStripMenuItem.Click += new System.EventHandler(this.SortedByDiag_Command);
            // 
            // поМастеруToolStripMenuItem
            // 
            this.поМастеруToolStripMenuItem.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.поМастеруToolStripMenuItem.Name = "поМастеруToolStripMenuItem";
            this.поМастеруToolStripMenuItem.Size = new System.Drawing.Size(212, 26);
            this.поМастеруToolStripMenuItem.Text = "По мастеру";
            this.поМастеруToolStripMenuItem.Click += new System.EventHandler(this.SortedByMaster_Command);
            // 
            // поКлиентуToolStripMenuItem
            // 
            this.поКлиентуToolStripMenuItem.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.поКлиентуToolStripMenuItem.Name = "поКлиентуToolStripMenuItem";
            this.поКлиентуToolStripMenuItem.Size = new System.Drawing.Size(212, 26);
            this.поКлиентуToolStripMenuItem.Text = "По клиенту";
            this.поКлиентуToolStripMenuItem.Click += new System.EventHandler(this.SortedByClient_Command);
            // 
            // редактироватьToolStripMenuItem
            // 
            this.редактироватьToolStripMenuItem.Font = new System.Drawing.Font("Century Gothic", 10.2F);
            this.редактироватьToolStripMenuItem.Image = global::Program.Properties.Resources.editor_icon;
            this.редактироватьToolStripMenuItem.Name = "редактироватьToolStripMenuItem";
            this.редактироватьToolStripMenuItem.Size = new System.Drawing.Size(242, 26);
            this.редактироватьToolStripMenuItem.Text = "Редактировать";
            this.редактироватьToolStripMenuItem.Click += new System.EventHandler(this.Edit_Command);
            // 
            // LblHeadOfTable
            // 
            this.LblHeadOfTable.Font = new System.Drawing.Font("Consolas", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblHeadOfTable.Location = new System.Drawing.Point(51, 123);
            this.LblHeadOfTable.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.LblHeadOfTable.Name = "LblHeadOfTable";
            this.LblHeadOfTable.Size = new System.Drawing.Size(1279, 32);
            this.LblHeadOfTable.TabIndex = 8;
            this.LblHeadOfTable.Text = " id    Модель      Тип   Дюймы     Мастер            Клиент     Стоимость       Д" +
    "ефект";
            // 
            // LblAboutShop
            // 
            this.LblAboutShop.AutoSize = true;
            this.LblAboutShop.BackColor = System.Drawing.Color.Gold;
            this.LblAboutShop.Font = new System.Drawing.Font("Century Gothic", 16.2F);
            this.LblAboutShop.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.LblAboutShop.Location = new System.Drawing.Point(465, 2);
            this.LblAboutShop.Name = "LblAboutShop";
            this.LblAboutShop.Size = new System.Drawing.Size(0, 34);
            this.LblAboutShop.TabIndex = 9;
            // 
            // CnMenuMain
            // 
            this.CnMenuMain.Font = new System.Drawing.Font("Century Gothic", 10.2F);
            this.CnMenuMain.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.CnMenuMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.оПрограммеToolStripMenuItem,
            this.toolStripMenuItem2,
            this.выходToolStripMenuItem});
            this.CnMenuMain.Name = "contextMenuStrip1";
            this.CnMenuMain.Size = new System.Drawing.Size(209, 62);
            // 
            // оПрограммеToolStripMenuItem
            // 
            this.оПрограммеToolStripMenuItem.Image = global::Program.Properties.Resources.share_icon;
            this.оПрограммеToolStripMenuItem.Name = "оПрограммеToolStripMenuItem";
            this.оПрограммеToolStripMenuItem.Size = new System.Drawing.Size(208, 26);
            this.оПрограммеToolStripMenuItem.Text = "О программе";
            this.оПрограммеToolStripMenuItem.Click += new System.EventHandler(this.AboutProgram_Command);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(205, 6);
            // 
            // выходToolStripMenuItem
            // 
            this.выходToolStripMenuItem.Image = global::Program.Properties.Resources.exit_icon;
            this.выходToolStripMenuItem.Name = "выходToolStripMenuItem";
            this.выходToolStripMenuItem.Size = new System.Drawing.Size(208, 26);
            this.выходToolStripMenuItem.Text = "Выход";
            this.выходToolStripMenuItem.Click += new System.EventHandler(this.Exit_Command);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1382, 711);
            this.ContextMenuStrip = this.CnMenuMain;
            this.Controls.Add(this.LblAboutShop);
            this.Controls.Add(this.LblHeadOfTable);
            this.Controls.Add(this.LBox);
            this.Controls.Add(this.StatStrip);
            this.Controls.Add(this.ToolStrip);
            this.Controls.Add(this.MenuStrip);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.MenuStrip;
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(1400, 758);
            this.MinimizeBox = false;
            this.MinimumSize = new System.Drawing.Size(1400, 758);
            this.Name = "MainForm";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Show;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Repair Shop";
            this.MenuStrip.ResumeLayout(false);
            this.MenuStrip.PerformLayout();
            this.ToolStrip.ResumeLayout(false);
            this.ToolStrip.PerformLayout();
            this.StatStrip.ResumeLayout(false);
            this.StatStrip.PerformLayout();
            this.CnMenuLBox.ResumeLayout(false);
            this.CnMenuMain.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.MenuStrip MenuStrip;
        private System.Windows.Forms.ToolStripMenuItem TSMenuFile;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem TSMenuExit;
        private System.Windows.Forms.ToolStripMenuItem TSMenuAbout;
        private System.Windows.Forms.ToolStrip ToolStrip;
        private System.Windows.Forms.StatusStrip StatStrip;
        private System.Windows.Forms.ToolStripStatusLabel StSLMain;
        private System.Windows.Forms.ToolStripButton TStripBtnAdd;
        private System.Windows.Forms.ToolStripButton TStripBtnDelete;
        private System.Windows.Forms.ToolStripDropDownButton TStripBtnSort;
        private System.Windows.Forms.ToolStripMenuItem TSMISortByBrand;
        private System.Windows.Forms.ToolStripMenuItem TSMISortByDiagonal;
        private System.Windows.Forms.ToolStripMenuItem TSMISortByMaster;
        private System.Windows.Forms.ToolStripMenuItem TSMISortByClient;
        private System.Windows.Forms.ListBox LBox;
        private System.Windows.Forms.ToolStripButton TStripBtnEdit;
        private System.Windows.Forms.ToolStripButton TStripBtnAddTelevisions;
        private System.Windows.Forms.ToolStripButton TStripBtnShowByDiagonal;
        private System.Windows.Forms.ToolStripButton TStripBtnShowByPrice;
        private System.Windows.Forms.ToolStripButton TStripBtnExit;
        private System.Windows.Forms.ToolStripButton TStripBtnDeleteAll;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripButton toolStripButton1;
        private System.Windows.Forms.Label LblHeadOfTable;
        private System.Windows.Forms.Label LblAboutShop;
        private System.Windows.Forms.ContextMenuStrip CnMenuLBox;
        private System.Windows.Forms.ToolStripMenuItem добавитьЭлементToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem удалитьЭлементToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem сортировкаToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem поБрендуToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem поДиагоналиToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem поМастеруToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem поКлиентуToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem редактироватьToolStripMenuItem;
        private System.Windows.Forms.ContextMenuStrip CnMenuMain;
        private System.Windows.Forms.ToolStripMenuItem оПрограммеToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem выходToolStripMenuItem;
        private System.Windows.Forms.ToolStripButton TStripBtnEditShop;
    }
}

