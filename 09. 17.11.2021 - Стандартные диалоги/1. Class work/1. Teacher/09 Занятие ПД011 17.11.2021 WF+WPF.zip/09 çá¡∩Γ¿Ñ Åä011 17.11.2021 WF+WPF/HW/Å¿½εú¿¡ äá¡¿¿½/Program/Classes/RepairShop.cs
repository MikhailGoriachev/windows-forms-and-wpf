﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program.Classes
{
    //класс мастерской по ремонту телевизоров
    public class RepairShop
    {
        private List<Television> _tvs;  //коллекция Television
        private string _name;           //название ремонтной мастерской
        private string _address;        //адрес ремонтной мастерской

        //свойтства
        public string Address
        {
            get { return _address; }
            set { _address = !string.IsNullOrWhiteSpace(value) ? value :
                    throw new Exception("Поле адреса мастерской не заполнено!");}
        }
        public string Name
        {
            get { return _name; }
            set { _name = !string.IsNullOrWhiteSpace(value) ? value :
                    throw new Exception("Поле названия мастерской не заполнено!");}
        }
        public List<Television> Tvs
        {
            get { return _tvs; }
            set { _tvs = value; }
        }

        //конструкторы
        public RepairShop()
        {
            _tvs = CreateTVs();
            _name = "Гарант-Сервис";
            _address = "пр. Мира, 8";
        }

        //фабрика коллекции телевизоров
        static public List<Television> CreateTVs()
        {
            List<Television> temp = new List<Television>();
            int n = MainForm.random.Next(10, 20);

            for (int i = 0; i < n; i++)
                temp.Add(Television.Create());

            return temp;
        }

        public override string ToString() => $"{_name}, {_address}";
    }
}
