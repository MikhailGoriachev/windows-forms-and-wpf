﻿
namespace Program.Forms
{
    partial class CUForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CUForm));
            this.LblBrand = new System.Windows.Forms.Label();
            this.PanelAdd = new System.Windows.Forms.Panel();
            this.LblHead = new System.Windows.Forms.Label();
            this.CmbBxBrands = new System.Windows.Forms.ComboBox();
            this.CmbBxTypes = new System.Windows.Forms.ComboBox();
            this.LblType = new System.Windows.Forms.Label();
            this.LblDiagonal = new System.Windows.Forms.Label();
            this.NumUDDiagonal = new System.Windows.Forms.NumericUpDown();
            this.LblDeff = new System.Windows.Forms.Label();
            this.TxtBxDeff = new System.Windows.Forms.TextBox();
            this.CmbBxMasters = new System.Windows.Forms.ComboBox();
            this.LblMaster = new System.Windows.Forms.Label();
            this.TxtBxClient = new System.Windows.Forms.TextBox();
            this.LblClient = new System.Windows.Forms.Label();
            this.NumUDCost = new System.Windows.Forms.NumericUpDown();
            this.LblCost = new System.Windows.Forms.Label();
            this.BtnAddOk = new System.Windows.Forms.Button();
            this.PanelAdd.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.NumUDDiagonal)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NumUDCost)).BeginInit();
            this.SuspendLayout();
            // 
            // LblBrand
            // 
            this.LblBrand.AutoSize = true;
            this.LblBrand.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblBrand.Location = new System.Drawing.Point(51, 99);
            this.LblBrand.Name = "LblBrand";
            this.LblBrand.Size = new System.Drawing.Size(151, 22);
            this.LblBrand.TabIndex = 0;
            this.LblBrand.Text = "Производитель";
            // 
            // PanelAdd
            // 
            this.PanelAdd.BackColor = System.Drawing.Color.Gold;
            this.PanelAdd.Controls.Add(this.LblHead);
            this.PanelAdd.Dock = System.Windows.Forms.DockStyle.Top;
            this.PanelAdd.Location = new System.Drawing.Point(0, 0);
            this.PanelAdd.Name = "PanelAdd";
            this.PanelAdd.Size = new System.Drawing.Size(569, 74);
            this.PanelAdd.TabIndex = 4;
            // 
            // LblHead
            // 
            this.LblHead.AutoSize = true;
            this.LblHead.Font = new System.Drawing.Font("Century Gothic", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblHead.Location = new System.Drawing.Point(160, 20);
            this.LblHead.Name = "LblHead";
            this.LblHead.Size = new System.Drawing.Size(249, 34);
            this.LblHead.TabIndex = 0;
            this.LblHead.Text = "Редактирование";
            // 
            // CmbBxBrands
            // 
            this.CmbBxBrands.Cursor = System.Windows.Forms.Cursors.Hand;
            this.CmbBxBrands.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.CmbBxBrands.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.CmbBxBrands.FormattingEnabled = true;
            this.CmbBxBrands.Items.AddRange(new object[] {
            "Bravis",
            "JVC",
            "Lenovo",
            "LG",
            "Panasonic",
            "Philips",
            "Samsung",
            "Sony",
            "Toshiba",
            "Xiaomi"});
            this.CmbBxBrands.Location = new System.Drawing.Point(225, 99);
            this.CmbBxBrands.Name = "CmbBxBrands";
            this.CmbBxBrands.Size = new System.Drawing.Size(272, 29);
            this.CmbBxBrands.Sorted = true;
            this.CmbBxBrands.TabIndex = 5;
            // 
            // CmbBxTypes
            // 
            this.CmbBxTypes.Cursor = System.Windows.Forms.Cursors.Hand;
            this.CmbBxTypes.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.CmbBxTypes.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.CmbBxTypes.FormattingEnabled = true;
            this.CmbBxTypes.Items.AddRange(new object[] {
            "LCD",
            "MicroLED",
            "NanoCell",
            "OLED",
            "QLED"});
            this.CmbBxTypes.Location = new System.Drawing.Point(225, 156);
            this.CmbBxTypes.Name = "CmbBxTypes";
            this.CmbBxTypes.Size = new System.Drawing.Size(272, 29);
            this.CmbBxTypes.Sorted = true;
            this.CmbBxTypes.TabIndex = 7;
            // 
            // LblType
            // 
            this.LblType.AutoSize = true;
            this.LblType.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblType.Location = new System.Drawing.Point(51, 156);
            this.LblType.Name = "LblType";
            this.LblType.Size = new System.Drawing.Size(154, 22);
            this.LblType.TabIndex = 6;
            this.LblType.Text = "Тип телевизора";
            // 
            // LblDiagonal
            // 
            this.LblDiagonal.AutoSize = true;
            this.LblDiagonal.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblDiagonal.Location = new System.Drawing.Point(68, 203);
            this.LblDiagonal.Name = "LblDiagonal";
            this.LblDiagonal.Size = new System.Drawing.Size(111, 22);
            this.LblDiagonal.TabIndex = 8;
            this.LblDiagonal.Text = "Диагональ";
            // 
            // NumUDDiagonal
            // 
            this.NumUDDiagonal.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.NumUDDiagonal.Cursor = System.Windows.Forms.Cursors.Hand;
            this.NumUDDiagonal.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.NumUDDiagonal.Location = new System.Drawing.Point(225, 203);
            this.NumUDDiagonal.Maximum = new decimal(new int[] {
            10000000,
            0,
            0,
            0});
            this.NumUDDiagonal.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.NumUDDiagonal.Name = "NumUDDiagonal";
            this.NumUDDiagonal.Size = new System.Drawing.Size(272, 24);
            this.NumUDDiagonal.TabIndex = 9;
            this.NumUDDiagonal.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.NumUDDiagonal.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // LblDeff
            // 
            this.LblDeff.AutoSize = true;
            this.LblDeff.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblDeff.Location = new System.Drawing.Point(68, 434);
            this.LblDeff.Name = "LblDeff";
            this.LblDeff.Size = new System.Drawing.Size(118, 44);
            this.LblDeff.TabIndex = 10;
            this.LblDeff.Text = "Описание \r\nдеффекта";
            this.LblDeff.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // TxtBxDeff
            // 
            this.TxtBxDeff.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TxtBxDeff.Cursor = System.Windows.Forms.Cursors.Hand;
            this.TxtBxDeff.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TxtBxDeff.Location = new System.Drawing.Point(225, 434);
            this.TxtBxDeff.Multiline = true;
            this.TxtBxDeff.Name = "TxtBxDeff";
            this.TxtBxDeff.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.TxtBxDeff.Size = new System.Drawing.Size(272, 137);
            this.TxtBxDeff.TabIndex = 11;
            // 
            // CmbBxMasters
            // 
            this.CmbBxMasters.Cursor = System.Windows.Forms.Cursors.Hand;
            this.CmbBxMasters.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.CmbBxMasters.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.CmbBxMasters.FormattingEnabled = true;
            this.CmbBxMasters.Items.AddRange(new object[] {
            "Андреев П.А.",
            "Петров Ю.А.",
            "Судиловский И.М.",
            "Харин А.И."});
            this.CmbBxMasters.Location = new System.Drawing.Point(225, 253);
            this.CmbBxMasters.Name = "CmbBxMasters";
            this.CmbBxMasters.Size = new System.Drawing.Size(272, 29);
            this.CmbBxMasters.Sorted = true;
            this.CmbBxMasters.TabIndex = 13;
            // 
            // LblMaster
            // 
            this.LblMaster.AutoSize = true;
            this.LblMaster.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblMaster.Location = new System.Drawing.Point(51, 253);
            this.LblMaster.Name = "LblMaster";
            this.LblMaster.Size = new System.Drawing.Size(154, 44);
            this.LblMaster.TabIndex = 12;
            this.LblMaster.Text = "Ответственный \r\nмастер";
            this.LblMaster.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // TxtBxClient
            // 
            this.TxtBxClient.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TxtBxClient.Cursor = System.Windows.Forms.Cursors.Hand;
            this.TxtBxClient.Font = new System.Drawing.Font("Century Gothic", 10.2F);
            this.TxtBxClient.Location = new System.Drawing.Point(224, 320);
            this.TxtBxClient.Multiline = true;
            this.TxtBxClient.Name = "TxtBxClient";
            this.TxtBxClient.Size = new System.Drawing.Size(272, 29);
            this.TxtBxClient.TabIndex = 15;
            // 
            // LblClient
            // 
            this.LblClient.AutoSize = true;
            this.LblClient.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblClient.Location = new System.Drawing.Point(64, 327);
            this.LblClient.Name = "LblClient";
            this.LblClient.Size = new System.Drawing.Size(138, 22);
            this.LblClient.TabIndex = 14;
            this.LblClient.Text = "ФИО клиента";
            this.LblClient.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // NumUDCost
            // 
            this.NumUDCost.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.NumUDCost.Cursor = System.Windows.Forms.Cursors.Hand;
            this.NumUDCost.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.NumUDCost.Location = new System.Drawing.Point(225, 383);
            this.NumUDCost.Maximum = new decimal(new int[] {
            10000000,
            0,
            0,
            0});
            this.NumUDCost.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.NumUDCost.Name = "NumUDCost";
            this.NumUDCost.Size = new System.Drawing.Size(272, 24);
            this.NumUDCost.TabIndex = 17;
            this.NumUDCost.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.NumUDCost.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // LblCost
            // 
            this.LblCost.AutoSize = true;
            this.LblCost.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblCost.Location = new System.Drawing.Point(73, 376);
            this.LblCost.Name = "LblCost";
            this.LblCost.Size = new System.Drawing.Size(113, 44);
            this.LblCost.TabIndex = 16;
            this.LblCost.Text = "Стоимость\r\nремонта\r\n";
            this.LblCost.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // BtnAddOk
            // 
            this.BtnAddOk.BackColor = System.Drawing.Color.Gold;
            this.BtnAddOk.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BtnAddOk.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.BtnAddOk.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnAddOk.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BtnAddOk.Location = new System.Drawing.Point(178, 599);
            this.BtnAddOk.Name = "BtnAddOk";
            this.BtnAddOk.Size = new System.Drawing.Size(211, 51);
            this.BtnAddOk.TabIndex = 18;
            this.BtnAddOk.Text = "Готово";
            this.BtnAddOk.UseVisualStyleBackColor = false;
            this.BtnAddOk.Click += new System.EventHandler(this.BtnAddOk_Click);
            // 
            // CUForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(569, 675);
            this.Controls.Add(this.BtnAddOk);
            this.Controls.Add(this.NumUDCost);
            this.Controls.Add(this.LblCost);
            this.Controls.Add(this.TxtBxClient);
            this.Controls.Add(this.LblClient);
            this.Controls.Add(this.CmbBxMasters);
            this.Controls.Add(this.LblMaster);
            this.Controls.Add(this.TxtBxDeff);
            this.Controls.Add(this.LblDeff);
            this.Controls.Add(this.NumUDDiagonal);
            this.Controls.Add(this.LblDiagonal);
            this.Controls.Add(this.CmbBxTypes);
            this.Controls.Add(this.LblType);
            this.Controls.Add(this.CmbBxBrands);
            this.Controls.Add(this.PanelAdd);
            this.Controls.Add(this.LblBrand);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(587, 722);
            this.MinimizeBox = false;
            this.MinimumSize = new System.Drawing.Size(587, 722);
            this.Name = "CUForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Editor";
            this.PanelAdd.ResumeLayout(false);
            this.PanelAdd.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.NumUDDiagonal)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NumUDCost)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label LblBrand;
        private System.Windows.Forms.Panel PanelAdd;
        private System.Windows.Forms.Label LblHead;
        private System.Windows.Forms.ComboBox CmbBxBrands;
        private System.Windows.Forms.ComboBox CmbBxTypes;
        private System.Windows.Forms.Label LblType;
        private System.Windows.Forms.Label LblDiagonal;
        private System.Windows.Forms.NumericUpDown NumUDDiagonal;
        private System.Windows.Forms.Label LblDeff;
        private System.Windows.Forms.TextBox TxtBxDeff;
        private System.Windows.Forms.ComboBox CmbBxMasters;
        private System.Windows.Forms.Label LblMaster;
        private System.Windows.Forms.TextBox TxtBxClient;
        private System.Windows.Forms.Label LblClient;
        private System.Windows.Forms.NumericUpDown NumUDCost;
        private System.Windows.Forms.Label LblCost;
        private System.Windows.Forms.Button BtnAddOk;
    }
}