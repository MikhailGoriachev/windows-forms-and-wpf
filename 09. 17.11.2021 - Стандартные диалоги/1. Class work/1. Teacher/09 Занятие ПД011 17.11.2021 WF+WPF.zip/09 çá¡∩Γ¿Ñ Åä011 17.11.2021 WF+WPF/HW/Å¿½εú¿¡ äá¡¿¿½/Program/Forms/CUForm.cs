﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Program.Classes;

namespace Program.Forms
{
    public partial class CUForm : Form
    {
        private Television tv;
        public Television getTv() => tv;
        //для добавления
        public CUForm()
        {
            InitializeComponent();
            tv = new Television();
            LblHead.Text = "Добавление";
        }
        //для редактирования
        public CUForm(Television _tv)
        {
            InitializeComponent();

            CmbBxBrands.Text = _tv.Brand;
            CmbBxTypes.Text = _tv.Type;
            NumUDDiagonal.Value = _tv.Diagonal;
            TxtBxDeff.Text = _tv.Defect;
            CmbBxMasters.Text = _tv.Master;
            TxtBxClient.Text = _tv.Client;
            NumUDCost.Value = _tv.RepairCost;

            tv = _tv;
        }

        private void BtnAddOk_Click(object sender, EventArgs e)
        {
            tv.Brand = CmbBxBrands.Text;
            tv.Type = CmbBxTypes.Text;
            tv.Diagonal = (int)NumUDDiagonal.Value;
            tv.Defect = TxtBxDeff.Text;
            tv.Master = CmbBxMasters.Text;
            tv.Client = TxtBxClient.Text;
            tv.RepairCost = (int)NumUDCost.Value;
        }
    }
}
