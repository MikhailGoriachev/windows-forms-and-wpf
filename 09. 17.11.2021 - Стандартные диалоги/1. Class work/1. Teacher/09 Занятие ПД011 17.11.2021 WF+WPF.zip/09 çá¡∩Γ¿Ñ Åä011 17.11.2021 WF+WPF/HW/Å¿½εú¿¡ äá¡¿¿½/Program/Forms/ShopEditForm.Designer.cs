﻿
namespace Program.Forms
{
    partial class ShopEditForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ShopEditForm));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.TxtBxName = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.BtnShoEditorOk = new System.Windows.Forms.Button();
            this.LblAddress = new System.Windows.Forms.Label();
            this.TxtBxAddress = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Program.Properties.Resources.greate_television_icon;
            this.pictureBox1.Location = new System.Drawing.Point(24, 43);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(300, 300);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // TxtBxName
            // 
            this.TxtBxName.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TxtBxName.Location = new System.Drawing.Point(360, 79);
            this.TxtBxName.Name = "TxtBxName";
            this.TxtBxName.Size = new System.Drawing.Size(310, 28);
            this.TxtBxName.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(408, 43);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(211, 23);
            this.label1.TabIndex = 2;
            this.label1.Text = "Название магазина";
            // 
            // BtnShoEditorOk
            // 
            this.BtnShoEditorOk.BackColor = System.Drawing.Color.Gold;
            this.BtnShoEditorOk.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.BtnShoEditorOk.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnShoEditorOk.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BtnShoEditorOk.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.BtnShoEditorOk.Location = new System.Drawing.Point(419, 296);
            this.BtnShoEditorOk.Name = "BtnShoEditorOk";
            this.BtnShoEditorOk.Size = new System.Drawing.Size(200, 47);
            this.BtnShoEditorOk.TabIndex = 3;
            this.BtnShoEditorOk.Text = "Готово";
            this.BtnShoEditorOk.UseVisualStyleBackColor = false;
            this.BtnShoEditorOk.Click += new System.EventHandler(this.BtnShoEditorOk_Click);
            // 
            // LblAddress
            // 
            this.LblAddress.AutoSize = true;
            this.LblAddress.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblAddress.Location = new System.Drawing.Point(408, 141);
            this.LblAddress.Name = "LblAddress";
            this.LblAddress.Size = new System.Drawing.Size(195, 23);
            this.LblAddress.TabIndex = 5;
            this.LblAddress.Text = "Адресс магазина";
            // 
            // TxtBxAddress
            // 
            this.TxtBxAddress.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TxtBxAddress.Location = new System.Drawing.Point(360, 167);
            this.TxtBxAddress.Multiline = true;
            this.TxtBxAddress.Name = "TxtBxAddress";
            this.TxtBxAddress.Size = new System.Drawing.Size(310, 103);
            this.TxtBxAddress.TabIndex = 4;
            // 
            // ShopEditForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(709, 394);
            this.Controls.Add(this.LblAddress);
            this.Controls.Add(this.TxtBxAddress);
            this.Controls.Add(this.BtnShoEditorOk);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.TxtBxName);
            this.Controls.Add(this.pictureBox1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "ShopEditForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Shop editor";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TextBox TxtBxName;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button BtnShoEditorOk;
        private System.Windows.Forms.Label LblAddress;
        private System.Windows.Forms.TextBox TxtBxAddress;
    }
}