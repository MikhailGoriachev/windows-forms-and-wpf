﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Program.Classes;

namespace Program.Forms
{
    public partial class ShopEditForm : Form
    {
        RepairShop _repairShop;
        public ShopEditForm(RepairShop rp)
        {
            InitializeComponent();
            _repairShop = rp;
            TxtBxName.Text = rp.Name;
            TxtBxAddress.Text = rp.Address;
        }

        private void BtnShoEditorOk_Click(object sender, EventArgs e)
        {
            _repairShop.Name = TxtBxName.Text;
            _repairShop.Address = TxtBxAddress.Text;
        }
    }
}
