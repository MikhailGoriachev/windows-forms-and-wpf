﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Program.Forms;
using Program.Classes;

namespace Program
{
    public partial class MainForm : Form
    {
        static public Random random = new Random();
        static public int id = 0;
        private RepairShop repairShop = new RepairShop();

        public MainForm()
        {
            InitializeComponent();
            StSLMain.Text = "С возвращением!";
            LblAboutShop.Text = repairShop.ToString();
            ShopBind();
        }

        //выход из приложения
        private void Exit_Command(object sender, EventArgs e) => Application.Exit();
        //о приложении
        private void AboutProgram_Command(object sender, EventArgs e)
        {
            AboutForm _aboutForm = new AboutForm();
            _aboutForm.ShowDialog();
        }
        //добавить запись
        private void AddTelev_Command(object sender, EventArgs e)
        {
            CUForm _addF = new CUForm();
            DialogResult dr = _addF.ShowDialog();

            if (dr != DialogResult.OK) return;

            
            repairShop.Tvs.Add(_addF.getTv());

            StSLMain.Text = $"Новая запись: {_addF.getTv()}";

            // обновить привязку
            ShopBind();
        }
        // Выполнение привязки к данным для Листбокса 
        private void ShopBind()
        {
            LBox.DataSource = null;       // остановить текущую привязку
            LBox.DataSource = repairShop.Tvs;   // источник данных - связанная со списком коллекция
            LBox.DisplayMember = "ToTable";  // отображаемое в списке свойство/атрибут
            LBox.ValueMember = "Id";      // поле, значение которого возвращет метод SelectedValue
        } 
        //удалить выбранный элемент
        private void Delete_Command(object sender, EventArgs e)
        {
            if (repairShop.Tvs.Count == 0) return;

            StSLMain.Text = $"Удалена запись: {repairShop.Tvs[LBox.SelectedIndex]}";

            repairShop.Tvs.RemoveAt(LBox.SelectedIndex);


            ShopBind();
        }
        //удалить всех
        private void Delete_All_Command(object sender, EventArgs e)
        {
            if (repairShop.Tvs.Count == 0) return;
            repairShop.Tvs.Clear();
            StSLMain.Text = $"Все записи удалены!";
            ShopBind();
        }
        //добавить всех
        private void Create_All_Command(object sender, EventArgs e)
        {
            repairShop.Tvs.AddRange(RepairShop.CreateTVs());
            StSLMain.Text = $"Добавлены новые записи!";
            ShopBind();
        }
        //редактировать запись
        private void Edit_Command(object sender, EventArgs e)
        {
            //если не выбран элемент уходим
            if (LBox.SelectedIndex < 0) return;
            CUForm _editF = new CUForm(repairShop.Tvs[LBox.SelectedIndex]);
            //если форму просто закрыли - ничего не делаем
            if (_editF.ShowDialog() != DialogResult.OK) return;
            //сохраняем в коллекцию отредактированную запись
            repairShop.Tvs[LBox.SelectedIndex] = _editF.getTv();
            //сообщаем об этом пользователю
            StSLMain.Text = $"Отредактирована запись: {_editF.getTv()}";
            ShopBind();
        }

        //сортировки
        private void SortedByBrandNType_Command(object sender, EventArgs e)
        {
            repairShop.Tvs.Sort((a, b) => (a.Brand + a.Type).CompareTo(b.Brand+b.Type));
            StSLMain.Text = $"Отсортировано по бренду и типу";
            ShopBind();
        }
        private void SortedByDiag_Command(object sender, EventArgs e)
        {
            repairShop.Tvs.Sort((a, b) => b.Diagonal.CompareTo(a.Diagonal));
            StSLMain.Text = $"Отсортировано по диагонали";
            ShopBind();
        }
        private void SortedByMaster_Command(object sender, EventArgs e)
        {
            repairShop.Tvs.Sort((a, b) => a.Master.CompareTo(b.Master));
            StSLMain.Text = $"Отсортировано по мастеру";
            ShopBind();
        }
        private void SortedByClient_Command(object sender, EventArgs e)
        {
            repairShop.Tvs.Sort((a, b) => a.Client.CompareTo(b.Client));
            StSLMain.Text = $"Отсортировано по клиенту";
            ShopBind();
        }

        //редактирование данных магазина
        private void Shop_Edit_Command(object sender, EventArgs e)
        {
            ShopEditForm shopEditForm = new ShopEditForm(repairShop);
            shopEditForm.ShowDialog();
            LblAboutShop.Text = repairShop.ToString();
        }
    }
}
