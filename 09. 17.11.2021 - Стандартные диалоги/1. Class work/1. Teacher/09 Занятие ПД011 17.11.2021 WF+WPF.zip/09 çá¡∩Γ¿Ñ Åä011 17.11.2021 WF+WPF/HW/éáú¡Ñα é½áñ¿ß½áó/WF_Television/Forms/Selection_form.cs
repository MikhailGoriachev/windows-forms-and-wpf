﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WF_Television.Models;

namespace WF_Television.Forms
{
    public partial class Selection_form : Form
    {
        //Мастреская 
        private RepairShop _repairShop = new RepairShop();

        private int defaultCount = 4;

        public Selection_form()
        {
            InitializeComponent();
            //Коллекция по умолчанию 
            _repairShop.Televisions.Clear();
            _repairShop.Generate(defaultCount);

            TbxOutPut.Text = _repairShop.ShowCollection();
        }

        public Selection_form(string title,Television[] tvs)
        {

            InitializeComponent();

            //Добавление выборки в мастерскую
            _repairShop.Televisions.Clear();
            _repairShop.Televisions.AddRange(tvs);
            TbxOutPut.Text = _repairShop.ShowCollection();
        }

        //Выходим из формы
        private void BtnComeBack_Click(object sender, EventArgs e)
        {
            Form main_form = Application.OpenForms[0];
            main_form.ShowDialog();
            this.Visible = false;
        }
    }
}
