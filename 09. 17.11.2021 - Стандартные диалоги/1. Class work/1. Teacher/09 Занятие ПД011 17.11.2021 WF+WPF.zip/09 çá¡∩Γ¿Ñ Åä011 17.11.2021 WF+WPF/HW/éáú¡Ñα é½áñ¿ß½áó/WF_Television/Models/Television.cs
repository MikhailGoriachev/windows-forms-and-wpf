﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WF_Television.Utilities;
namespace WF_Television.Models
{
    public class Television
    {
        string _producer;

        public string Producer {
            get => _producer;

            set 
            {
                if (string.IsNullOrEmpty(value))
                    throw new Exception("Строка не может быть пустой!");

                _producer = value;
            }
            
        }

        string _type;

        public string Type {
            get => _type; 
            
            set
            {
                if (string.IsNullOrEmpty(value))
                    throw new Exception("Строка не может быть пустой!");
                _type = value;
            }
        }

        double _diagonal;
        //Свойство диагонали
        public double Diagonal 
        {
            get => _diagonal; 
            
            set
            {
                //Проверка на 0 до 6 знака после запятой
                if (value < 1e-6)
                    throw new Exception("Значение диагонали должно быть больше 0!");
                _diagonal = value;
            }
        }

        //Дефект устройства
        string _defect;

        public string Defect {

            get => _defect; 
            set
            {
                if (string.IsNullOrEmpty(value))
                    throw new Exception("Строка не может быть пустой!");
                _defect = value;
            }
        
        }

        //ФИО мастера
        string _surnameRepairer;

        public string SurnameRepairer { 
            get => _surnameRepairer;


            set
            {
                if (string.IsNullOrEmpty(value))
                    throw new Exception("Строка не может быть пустой!");
                _surnameRepairer = value;
            }
        }

        //ФИО владельца
        string _surnameOwner;

        public string SurnameOwner
        {
            get => _surnameOwner;

            set
            {
                if (string.IsNullOrEmpty(value))
                    throw new Exception("Строка не может быть пустой!");
                _surnameOwner = value;
            }
        }

        //Стоимость ремонта
        double _price;
        public double Price
        {
            get => _price;

            set
            {
                //Проверка на 0 до 6 знака после запятой
                if (value < 1e-6)
                    throw new Exception("Значение стоимости ремонта должно быть больше 0!");
                _price = value;
            }
        }

        //Внедрение зависимости
        public Television(): this("Samsung","Smart TV",50,"Питание", "Довлатов Л.Д.", "Степанов М.Л.",5400d)
        {}
         
        //Свойства: 
        public Television(string producer, string type, double diaonal, string defect, string repairer, string owner, double price)
        {
            Producer = producer;
            Type = type;
            Diagonal = diaonal;
            Defect = defect;
            SurnameRepairer = repairer;
            SurnameOwner = owner;
            Price = price;
        }

        //Генерация телевизора
        static public Television Generate()
        {
            //Массив производителей
            string[] producers = {

                "Sony","LG","Haier", "Kivi", "Hisense","Samsung","Philips", //7 strs

            };

            //Типы телевизоров, виды матриц экранов
            string[] types =
            {
                "ЭЛТ","RP ","DLP","LCD","PDP", "LED","OLED" //Max Length = 4 char
            };

            //Повреждение
            string[] defects =
            {
                "Инвертор", 
                "Питания",  
                "Искажены цвета", //14
                "Не включается",
                "ДУ",
            };

            //Мастер
            string[] repairers = 
            {
               "Лапин П.Ю.",
               "Терентьев В.И.",
               "Доронин А.Н.",
               "Большаков К.В.",
               "Ковалёв Н.К.",
               "Блохин В.И.",
               "Баранов Ю.Е.",
               "Алексиков И.С."
            };

            //Владелец
            string[] owners =
            {
                "Скрипниченко Р.Ю", //16
                "Трошкина В.К.",
                "Медведев А.С.",
                "Бычкова Ю.Р.",
                "Шустра Д.И.",
                "Менделеев Д.Г.",
                "Швецова Е.К.",
                "Самошкина О.Ю."
            };


            int index = Utils.Random.Next(0, 7), 
                defectInd = Utils.Random.Next(0, defects.Length), 
                ownerInd = Utils.Random.Next(0,owners.Length),
                repairerInd= Utils.Random.Next(0, repairers.Length);

            return 
                new Television
                (producers[index], types[index], Utils.GetRandom(30, 60), defects[defectInd], repairers[repairerInd], owners[ownerInd], Utils.GetRandom(1000d, 15000d));

        } //Generate

        //Компаратор по цене
        public int CompareTo(Television tv) => _price.CompareTo(tv._price);

        //Вывод в строку таблицы
        public string ToTableRow =>
            $"{_producer,12}│{_type,5}│{_diagonal:f2}|{_defect,14}│{_surnameOwner,17}│{_surnameRepairer,14}│{_price:f2}";
     
        //Строка
        public override string  ToString() =>
            $"TV: {_producer},\r\n  {_type},\r\n  {_diagonal:f2}\r\n  {_defect}\r\n  {_surnameOwner}\r\n  {_surnameRepairer}\r\n  {_price:f2}";
        

        // Шапка таблицы
        public static string Header =>
            $"┌───────────────┬───────┬──────────┬──────────────┬─────────────────┬──────────────┬───────┐\r\n" +
            $"│ Производитель │  Тип  │Диагональ,│ Дефект       │ Владелец        │ Мастер       │ Цена  │" +
            $"│               │       │inch      │              │                 │              │       │\r\n" +
            $"├───────────────┼───────┼──────────┼──────────────┼─────────────────┼──────────────┼───────┤\r\n";

        // Подвал таблицы, статическое свойство
        public static string Footer =>
             "└───────────────┴───────┴──────────┴──────────────┴─────────────────┴──────────────┴───────┘";

       
    }
}
