﻿namespace WF_Television.Forms
{
    partial class Selection_form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.BtnComeBack = new System.Windows.Forms.Button();
            this.TbxOutPut = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Consolas", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(56, 18);
            this.label1.TabIndex = 0;
            this.label1.Text = "label1";
            // 
            // BtnComeBack
            // 
            this.BtnComeBack.Font = new System.Drawing.Font("Consolas", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BtnComeBack.Location = new System.Drawing.Point(290, 412);
            this.BtnComeBack.Name = "BtnComeBack";
            this.BtnComeBack.Size = new System.Drawing.Size(266, 41);
            this.BtnComeBack.TabIndex = 1;
            this.BtnComeBack.Text = "Вернуться в главную форму";
            this.BtnComeBack.UseVisualStyleBackColor = true;
            this.BtnComeBack.Click += new System.EventHandler(this.BtnComeBack_Click);
            // 
            // TbxOutPut
            // 
            this.TbxOutPut.Location = new System.Drawing.Point(12, 73);
            this.TbxOutPut.Multiline = true;
            this.TbxOutPut.Name = "TbxOutPut";
            this.TbxOutPut.Size = new System.Drawing.Size(787, 311);
            this.TbxOutPut.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Consolas", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(12, 39);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(787, 31);
            this.label2.TabIndex = 3;
            this.label2.Text = "Производитель     Тип    Диагональ         Дефект                 Владелец       " +
    "      Мастер       Цена ";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Selection_form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(811, 478);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.TbxOutPut);
            this.Controls.Add(this.BtnComeBack);
            this.Controls.Add(this.label1);
            this.Name = "Selection_form";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button BtnComeBack;
        private System.Windows.Forms.TextBox TbxOutPut;
        private System.Windows.Forms.Label label2;
    }
}