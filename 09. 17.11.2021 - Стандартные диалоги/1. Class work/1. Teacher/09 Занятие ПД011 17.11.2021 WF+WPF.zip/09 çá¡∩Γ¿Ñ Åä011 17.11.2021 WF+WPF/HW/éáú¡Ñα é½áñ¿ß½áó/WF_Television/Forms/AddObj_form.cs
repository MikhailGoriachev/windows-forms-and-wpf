﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WF_Television.Forms
{
    public partial class AddObj_form : Form
    {
        //TODO - попробуй в конце реализовать идею из калькулятора с добавлением картинки. Но только если займёт <= 30-50 min
        public AddObj_form()
        {
            InitializeComponent();
        }

        private void BtnAdd_Click(object sender, EventArgs e)
        {

        }
    }
}
