﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WF_Television.Models;
using WF_Television.Forms;

namespace WF_Television
{
    public partial class Main_form : Form
    {
        //Телемастерская
        private RepairShop _repairShop;
        public Main_form():this(new RepairShop())
        {}

        //C_TOR с параметрами
        public Main_form(RepairShop repairShop)
        {
            //Создание всех элементов формы
            InitializeComponent();

            _repairShop = repairShop;

            //Связывание данных 
            BindRepairShop();
        }

        //Связываение данных
        private void BindRepairShop()
        {
            //Остановить предыдущую привязку
            LbxRepairShop.DataSource = null;

            //Производим привязку заново
            LbxRepairShop.DataSource = _repairShop.Televisions;

            //Задаём свойство вывода
            LbxRepairShop.DisplayMember = "ToTableRow";
        }


        //Выбор элемента в списке
        private void LbxRepairShop_SelectedIndexChanged(object sender, EventArgs e)
        {
            int ind = LbxRepairShop.SelectedIndex;
            if (ind < 0 || ind >= _repairShop.Amount)
            {
                TbxTv.Clear();
                return;
            }
            //Выводим информацию в правый text box
            TbxTv.Text = $"{DateTime.Now: HH:mm:ss}\r\n{_repairShop[ind]}";
        }

        //Загрузка всей формы
        private void Main_form_Load(object sender, EventArgs e)
        {
            //Вывод количества созданных объектов в строку состояния
            //StsMain.Text = $"Телевизоров в мастерской: {_repairShop.Amount}";
            toolStripStatusLbl.Text = $"Телевизоров в мастерской: {_repairShop.Amount}";

            //Отключаем кнопку удаление нескольких телевизоров 
            DelTvsToolStripMenuItem.Enabled = false;

            //Отключение выделения
            LbxRepairShop.ClearSelected();

        }

        // завершение работы приложения
        private void Exit_Command(object sender, EventArgs e) =>
            Application.Exit();

        private void AddTv_Command(object sender, EventArgs e)
        {
            AddObj_form addForm = new AddObj_form();
            DialogResult showResult = addForm.ShowDialog();

            //Если заверешение работы формы произошло не через кнопку добавить/сохранить
            //со свойством DialogResult.Yes, тогда объект не добавляем 
            if (showResult != DialogResult.Yes)
                return;

            //Если же завершение работы формы было корректным, тогда добавляем объект в списо TV




            toolStripStatusLbl.Text = $"Телевизоров в мастерской: {_repairShop.Amount}";
        }

        //Добавление коллекции телевизоров в фомру
        private void AddCollection_Command(object sender, EventArgs e)
        {
            _repairShop.AddCollectionToList();

            //Проводим повторную связку с List box
            BindRepairShop();

            toolStripStatusLbl.Text = $"Телевизоров в мастерской: {_repairShop.Amount}";
        }

        //Удаление телевизора
        private void DeleteTv_Command(object sender, EventArgs e)
        {
            int ind = LbxRepairShop.SelectedIndex;
            //Проверка на корректность выбранного элемента 
            if (ind < 0 || ind >= _repairShop.Amount)
                return;
            //Удаление элемента
            _repairShop.Televisions.RemoveAt(ind);

            //Повторное связывание 
            BindRepairShop();

            toolStripStatusLbl.Text = $"Телевизоров в мастерской: {_repairShop.Amount}";
        }

        //Предикат вхождения в массив
        delegate bool Predicate(int ind);

        //Удаление нескольких телевизоров 
        private void DelTvGroup_Command(object sender, EventArgs e)
        {
            int count = LbxRepairShop.SelectedItems.Count,j=0;

            int[] inds = new int[count];

            //Сравнение индексов
            Predicate predicate = (index) => {

                for (int i = 0; i < count; i++)
                {
                    if (inds[i] == index)
                        return true;
                }
                return false;
                
                };

            //Цикл сбора индексов 
            foreach(int index in LbxRepairShop.SelectedIndices)
            {
                inds[j++] = index;
            }

            //Удаление
            for (int i = _repairShop.Amount; i >=0; i--)
            {
                if (predicate(i))
                    _repairShop.Televisions.RemoveAt(i);
                
            } 


            BindRepairShop();
            CbxChooseFew.CheckState = CheckState.Unchecked;
            toolStripStatusLbl.Text = $"Телевизоров в мастерской: {_repairShop.Amount}";
        }

        //Check box выбора нескольких телевизоров
        private void CbxChooseFew_CheckedChanged(object sender, EventArgs e)
        {
            if (CbxChooseFew.CheckState == CheckState.Checked)
            {
                //Изменение настроек списка
                LbxRepairShop.SelectionMode = SelectionMode.MultiSimple;
                LbxRepairShop.ClearSelected();
                //Изменение состояний кнопок 
                AddTvToolStripMenuItem.Enabled = false;
                AddCollectionTvToolStripMenuItem.Enabled = false;
                EditTvToolStripMenuItem.Enabled = false;
                DeleteTvToolStripMenuItem.Enabled = false;
                AddCollectionTvToolStripMenuItem.Enabled = false;

                DelTvsToolStripMenuItem.Enabled = true;

                //Очистка текстового поля
                GbxTv.Visible = false;

                return;
            }

            GbxTv.Visible = true;
            //Изменение настроек списка
            LbxRepairShop.SelectionMode = SelectionMode.One;
            //Изменение состояний кнопок
            AddTvToolStripMenuItem.Enabled = true;
            AddCollectionTvToolStripMenuItem.Enabled = true;
            EditTvToolStripMenuItem.Enabled = true;
            DeleteTvToolStripMenuItem.Enabled = true;
            AddCollectionTvToolStripMenuItem.Enabled = true;

            DelTvsToolStripMenuItem.Enabled = false;

        }

        private void SortByProducerTSMItem_Command(object sender, EventArgs e)
        {
            //Сортировка коллекции
            _repairShop.SortByProducer();

            //Повторная привязка
            BindRepairShop();
        }

        private void SortByDiagonalTSMItem_Command(object sender, EventArgs e)
        {

            //Сортировка коллекции
            _repairShop.SortDescByDiagonal();

            //Повторная привязка
            BindRepairShop();
        }

        private void SortByRepairerTSMItem_Command(object sender, EventArgs e)
        {

            //Сортировка коллекции
            _repairShop.SortByRapairer();

            //Повторная привязка
            BindRepairShop();
        }

        private void SortByOwnerTSMItem_Command(object sender, EventArgs e)
        {

            //Сортировка коллекции
            _repairShop.SortByOwner();

            //Повторная привязка
            BindRepairShop();
        }

        private void SelectByPriceTSMenuItem_Command(object sender, EventArgs e)
        {
            Form selection_Form = new Selection_form();
            selection_Form.ShowDialog();
        }
    }
}
