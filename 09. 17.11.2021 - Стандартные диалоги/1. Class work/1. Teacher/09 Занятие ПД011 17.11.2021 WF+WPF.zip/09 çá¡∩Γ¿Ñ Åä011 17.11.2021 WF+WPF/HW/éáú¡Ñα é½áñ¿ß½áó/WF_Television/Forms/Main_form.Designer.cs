﻿namespace WF_Television
{
    partial class Main_form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.LbxRepairShop = new System.Windows.Forms.ListBox();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.выходToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.мастерскаяToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.телевизорыToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.AddTvToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.EditTvToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.DeleteTvToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.AddCollectionTvToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.DelTvsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.SortsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.SortByProducerTSMItem = new System.Windows.Forms.ToolStripMenuItem();
            this.SortByDiagonalTSMItem = new System.Windows.Forms.ToolStripMenuItem();
            this.SortByRepairerTSMItem = new System.Windows.Forms.ToolStripMenuItem();
            this.SortByOwnerTSMItem = new System.Windows.Forms.ToolStripMenuItem();
            this.TbxTv = new System.Windows.Forms.TextBox();
            this.StsMain = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLbl = new System.Windows.Forms.ToolStripStatusLabel();
            this.GbxTv = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.CbxChooseFew = new System.Windows.Forms.CheckBox();
            this.GbxCheckBox = new System.Windows.Forms.GroupBox();
            this.выборкиToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.телевизорыСМинЦенойРемонтаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.поВыбранномуМастеруToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.поДиагоналиЭкранаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.StsMain.SuspendLayout();
            this.GbxTv.SuspendLayout();
            this.GbxCheckBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // LbxRepairShop
            // 
            this.LbxRepairShop.Font = new System.Drawing.Font("Consolas", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LbxRepairShop.FormattingEnabled = true;
            this.LbxRepairShop.ItemHeight = 19;
            this.LbxRepairShop.Location = new System.Drawing.Point(12, 76);
            this.LbxRepairShop.Name = "LbxRepairShop";
            this.LbxRepairShop.ScrollAlwaysVisible = true;
            this.LbxRepairShop.Size = new System.Drawing.Size(750, 403);
            this.LbxRepairShop.TabIndex = 0;
            this.LbxRepairShop.SelectedIndexChanged += new System.EventHandler(this.LbxRepairShop_SelectedIndexChanged);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem1,
            this.мастерскаяToolStripMenuItem,
            this.телевизорыToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1137, 24);
            this.menuStrip1.TabIndex = 3;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.выходToolStripMenuItem});
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(48, 20);
            this.toolStripMenuItem1.Text = "Файл";
            // 
            // выходToolStripMenuItem
            // 
            this.выходToolStripMenuItem.Name = "выходToolStripMenuItem";
            this.выходToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.F4)));
            this.выходToolStripMenuItem.Size = new System.Drawing.Size(151, 22);
            this.выходToolStripMenuItem.Text = "Выход";
            this.выходToolStripMenuItem.Click += new System.EventHandler(this.Exit_Command);
            // 
            // мастерскаяToolStripMenuItem
            // 
            this.мастерскаяToolStripMenuItem.Name = "мастерскаяToolStripMenuItem";
            this.мастерскаяToolStripMenuItem.Size = new System.Drawing.Size(84, 20);
            this.мастерскаяToolStripMenuItem.Text = "Мастерская";
            // 
            // телевизорыToolStripMenuItem
            // 
            this.телевизорыToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.AddTvToolStripMenuItem,
            this.EditTvToolStripMenuItem,
            this.DeleteTvToolStripMenuItem,
            this.toolStripSeparator2,
            this.AddCollectionTvToolStripMenuItem,
            this.DelTvsToolStripMenuItem,
            this.SortsToolStripMenuItem,
            this.выборкиToolStripMenuItem});
            this.телевизорыToolStripMenuItem.Name = "телевизорыToolStripMenuItem";
            this.телевизорыToolStripMenuItem.Size = new System.Drawing.Size(85, 20);
            this.телевизорыToolStripMenuItem.Text = "Телевизоры";
            // 
            // AddTvToolStripMenuItem
            // 
            this.AddTvToolStripMenuItem.Name = "AddTvToolStripMenuItem";
            this.AddTvToolStripMenuItem.Size = new System.Drawing.Size(192, 22);
            this.AddTvToolStripMenuItem.Text = "Добавить TV";
            // 
            // EditTvToolStripMenuItem
            // 
            this.EditTvToolStripMenuItem.Name = "EditTvToolStripMenuItem";
            this.EditTvToolStripMenuItem.Size = new System.Drawing.Size(192, 22);
            this.EditTvToolStripMenuItem.Text = "Редактировать TV";
            // 
            // DeleteTvToolStripMenuItem
            // 
            this.DeleteTvToolStripMenuItem.Name = "DeleteTvToolStripMenuItem";
            this.DeleteTvToolStripMenuItem.Size = new System.Drawing.Size(192, 22);
            this.DeleteTvToolStripMenuItem.Text = "Удалить телевизор";
            this.DeleteTvToolStripMenuItem.Click += new System.EventHandler(this.DeleteTv_Command);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(189, 6);
            // 
            // AddCollectionTvToolStripMenuItem
            // 
            this.AddCollectionTvToolStripMenuItem.Name = "AddCollectionTvToolStripMenuItem";
            this.AddCollectionTvToolStripMenuItem.Size = new System.Drawing.Size(192, 22);
            this.AddCollectionTvToolStripMenuItem.Text = "Добавить коллекцию";
            this.AddCollectionTvToolStripMenuItem.Click += new System.EventHandler(this.AddCollection_Command);
            // 
            // DelTvsToolStripMenuItem
            // 
            this.DelTvsToolStripMenuItem.Name = "DelTvsToolStripMenuItem";
            this.DelTvsToolStripMenuItem.Size = new System.Drawing.Size(192, 22);
            this.DelTvsToolStripMenuItem.Text = "Удалить телевизоры";
            this.DelTvsToolStripMenuItem.Click += new System.EventHandler(this.DelTvGroup_Command);
            // 
            // SortsToolStripMenuItem
            // 
            this.SortsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.SortByProducerTSMItem,
            this.SortByDiagonalTSMItem,
            this.SortByRepairerTSMItem,
            this.SortByOwnerTSMItem});
            this.SortsToolStripMenuItem.Name = "SortsToolStripMenuItem";
            this.SortsToolStripMenuItem.Size = new System.Drawing.Size(192, 22);
            this.SortsToolStripMenuItem.Text = "Сортировки";
            // 
            // SortByProducerTSMItem
            // 
            this.SortByProducerTSMItem.Name = "SortByProducerTSMItem";
            this.SortByProducerTSMItem.Size = new System.Drawing.Size(212, 22);
            this.SortByProducerTSMItem.Text = "По производителю";
            this.SortByProducerTSMItem.Click += new System.EventHandler(this.SortByProducerTSMItem_Command);
            // 
            // SortByDiagonalTSMItem
            // 
            this.SortByDiagonalTSMItem.Name = "SortByDiagonalTSMItem";
            this.SortByDiagonalTSMItem.Size = new System.Drawing.Size(212, 22);
            this.SortByDiagonalTSMItem.Text = "По убыванию диагонали";
            this.SortByDiagonalTSMItem.Click += new System.EventHandler(this.SortByDiagonalTSMItem_Command);
            // 
            // SortByRepairerTSMItem
            // 
            this.SortByRepairerTSMItem.Name = "SortByRepairerTSMItem";
            this.SortByRepairerTSMItem.Size = new System.Drawing.Size(212, 22);
            this.SortByRepairerTSMItem.Text = "По мастеру";
            this.SortByRepairerTSMItem.Click += new System.EventHandler(this.SortByRepairerTSMItem_Command);
            // 
            // SortByOwnerTSMItem
            // 
            this.SortByOwnerTSMItem.Name = "SortByOwnerTSMItem";
            this.SortByOwnerTSMItem.Size = new System.Drawing.Size(212, 22);
            this.SortByOwnerTSMItem.Text = "По владельцу";
            this.SortByOwnerTSMItem.Click += new System.EventHandler(this.SortByOwnerTSMItem_Command);
            // 
            // TbxTv
            // 
            this.TbxTv.Location = new System.Drawing.Point(20, 19);
            this.TbxTv.Multiline = true;
            this.TbxTv.Name = "TbxTv";
            this.TbxTv.ReadOnly = true;
            this.TbxTv.Size = new System.Drawing.Size(244, 265);
            this.TbxTv.TabIndex = 4;
            // 
            // StsMain
            // 
            this.StsMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLbl});
            this.StsMain.Location = new System.Drawing.Point(0, 560);
            this.StsMain.Name = "StsMain";
            this.StsMain.Size = new System.Drawing.Size(1137, 22);
            this.StsMain.TabIndex = 5;
            this.StsMain.Text = "statusStrip1";
            // 
            // toolStripStatusLbl
            // 
            this.toolStripStatusLbl.Name = "toolStripStatusLbl";
            this.toolStripStatusLbl.Size = new System.Drawing.Size(0, 17);
            // 
            // GbxTv
            // 
            this.GbxTv.Controls.Add(this.TbxTv);
            this.GbxTv.Location = new System.Drawing.Point(792, 76);
            this.GbxTv.Name = "GbxTv";
            this.GbxTv.Size = new System.Drawing.Size(280, 290);
            this.GbxTv.TabIndex = 6;
            this.GbxTv.TabStop = false;
            this.GbxTv.Text = "     Выбранный телевизор. Полная информация.";
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Consolas", 10F);
            this.label1.Location = new System.Drawing.Point(833, 515);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(900, 25);
            this.label1.TabIndex = 7;
            this.label1.Text = "│ Производитель   │     Тип  │Диагональ│        Дефект       │ Владелец        │ " +
    "Мастер       │ Цена  │";
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Consolas", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox1.Location = new System.Drawing.Point(12, 40);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(750, 30);
            this.textBox1.TabIndex = 8;
            this.textBox1.Text = "Производитель  │  Тип  │Диагональ  │      Дефект     │           Владелец     │  " +
    "     Мастер     │ Цена │";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(836, 445);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 9;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // CbxChooseFew
            // 
            this.CbxChooseFew.Font = new System.Drawing.Font("Consolas", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.CbxChooseFew.Location = new System.Drawing.Point(6, 10);
            this.CbxChooseFew.Name = "CbxChooseFew";
            this.CbxChooseFew.Size = new System.Drawing.Size(104, 45);
            this.CbxChooseFew.TabIndex = 10;
            this.CbxChooseFew.Text = "Выбрать несколько";
            this.CbxChooseFew.UseVisualStyleBackColor = true;
            this.CbxChooseFew.CheckedChanged += new System.EventHandler(this.CbxChooseFew_CheckedChanged);
            // 
            // GbxCheckBox
            // 
            this.GbxCheckBox.Controls.Add(this.CbxChooseFew);
            this.GbxCheckBox.Location = new System.Drawing.Point(12, 485);
            this.GbxCheckBox.Name = "GbxCheckBox";
            this.GbxCheckBox.Size = new System.Drawing.Size(116, 61);
            this.GbxCheckBox.TabIndex = 11;
            this.GbxCheckBox.TabStop = false;
            // 
            // выборкиToolStripMenuItem
            // 
            this.выборкиToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.телевизорыСМинЦенойРемонтаToolStripMenuItem,
            this.поВыбранномуМастеруToolStripMenuItem,
            this.поДиагоналиЭкранаToolStripMenuItem});
            this.выборкиToolStripMenuItem.Name = "выборкиToolStripMenuItem";
            this.выборкиToolStripMenuItem.Size = new System.Drawing.Size(192, 22);
            this.выборкиToolStripMenuItem.Text = "Выборки";
            // 
            // телевизорыСМинЦенойРемонтаToolStripMenuItem
            // 
            this.телевизорыСМинЦенойРемонтаToolStripMenuItem.Name = "телевизорыСМинЦенойРемонтаToolStripMenuItem";
            this.телевизорыСМинЦенойРемонтаToolStripMenuItem.Size = new System.Drawing.Size(265, 22);
            this.телевизорыСМинЦенойРемонтаToolStripMenuItem.Text = "Телевизоры с мин. ценой ремонта";
            this.телевизорыСМинЦенойРемонтаToolStripMenuItem.Click += new System.EventHandler(this.SelectByPriceTSMenuItem_Command);
            // 
            // поВыбранномуМастеруToolStripMenuItem
            // 
            this.поВыбранномуМастеруToolStripMenuItem.Name = "поВыбранномуМастеруToolStripMenuItem";
            this.поВыбранномуМастеруToolStripMenuItem.Size = new System.Drawing.Size(265, 22);
            this.поВыбранномуМастеруToolStripMenuItem.Text = "По выбранному мастеру";
            // 
            // поДиагоналиЭкранаToolStripMenuItem
            // 
            this.поДиагоналиЭкранаToolStripMenuItem.Name = "поДиагоналиЭкранаToolStripMenuItem";
            this.поДиагоналиЭкранаToolStripMenuItem.Size = new System.Drawing.Size(265, 22);
            this.поДиагоналиЭкранаToolStripMenuItem.Text = "По диагонали экрана";
            // 
            // Main_form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1137, 582);
            this.Controls.Add(this.GbxCheckBox);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.GbxTv);
            this.Controls.Add(this.StsMain);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.LbxRepairShop);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Main_form";
            this.Text = "Задание на 17.11";
            this.Load += new System.EventHandler(this.Main_form_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.StsMain.ResumeLayout(false);
            this.StsMain.PerformLayout();
            this.GbxTv.ResumeLayout(false);
            this.GbxTv.PerformLayout();
            this.GbxCheckBox.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox LbxRepairShop;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem выходToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem мастерскаяToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem телевизорыToolStripMenuItem;
        private System.Windows.Forms.TextBox TbxTv;
        private System.Windows.Forms.StatusStrip StsMain;
        private System.Windows.Forms.GroupBox GbxTv;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLbl;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.ToolStripMenuItem AddTvToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem EditTvToolStripMenuItem;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ToolStripMenuItem AddCollectionTvToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem DeleteTvToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripMenuItem DelTvsToolStripMenuItem;
        private System.Windows.Forms.CheckBox CbxChooseFew;
        private System.Windows.Forms.GroupBox GbxCheckBox;
        private System.Windows.Forms.ToolStripMenuItem SortsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem SortByProducerTSMItem;
        private System.Windows.Forms.ToolStripMenuItem SortByDiagonalTSMItem;
        private System.Windows.Forms.ToolStripMenuItem SortByRepairerTSMItem;
        private System.Windows.Forms.ToolStripMenuItem SortByOwnerTSMItem;
        private System.Windows.Forms.ToolStripMenuItem выборкиToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem телевизорыСМинЦенойРемонтаToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem поВыбранномуМастеруToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem поДиагоналиЭкранаToolStripMenuItem;
    }
}

