﻿
namespace H_W8WF
{
    partial class MainForm
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.MnuMain = new System.Windows.Forms.MenuStrip();
            this.MniFile = new System.Windows.Forms.ToolStripMenuItem();
            this.MniExit = new System.Windows.Forms.ToolStripMenuItem();
            this.MniEdit = new System.Windows.Forms.ToolStripMenuItem();
            this.MniEditNewCollection = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripSeparator();
            this.MniEditingTV = new System.Windows.Forms.ToolStripMenuItem();
            this.MniEditingMastersk = new System.Windows.Forms.ToolStripMenuItem();
            this.MniSort = new System.Windows.Forms.ToolStripMenuItem();
            this.MniSortBrend = new System.Windows.Forms.ToolStripMenuItem();
            this.MniSortDiag = new System.Windows.Forms.ToolStripMenuItem();
            this.MniSortMaster = new System.Windows.Forms.ToolStripMenuItem();
            this.MniSortOwner = new System.Windows.Forms.ToolStripMenuItem();
            this.TsbMain = new System.Windows.Forms.ToolStrip();
            this.TlsNew = new System.Windows.Forms.ToolStripButton();
            this.TstAdd = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.TlsSort = new System.Windows.Forms.ToolStripButton();
            this.TlsSortD = new System.Windows.Forms.ToolStripButton();
            this.TlsSortFM = new System.Windows.Forms.ToolStripButton();
            this.TlsTO = new System.Windows.Forms.ToolStripButton();
            this.StsMain = new System.Windows.Forms.StatusStrip();
            this.StlMain = new System.Windows.Forms.ToolStripStatusLabel();
            this.LbxTelevisions = new System.Windows.Forms.ListBox();
            this.LblTelevisions = new System.Windows.Forms.Label();
            this.GrbTelevisions = new System.Windows.Forms.GroupBox();
            this.NudCost = new System.Windows.Forms.NumericUpDown();
            this.NudDiagonal = new System.Windows.Forms.NumericUpDown();
            this.BtnOk = new System.Windows.Forms.Button();
            this.LblCost = new System.Windows.Forms.Label();
            this.CmbOwner = new System.Windows.Forms.ComboBox();
            this.LblOwner = new System.Windows.Forms.Label();
            this.CmbMaster = new System.Windows.Forms.ComboBox();
            this.LblMaster = new System.Windows.Forms.Label();
            this.CmbTVDefect = new System.Windows.Forms.ComboBox();
            this.LblDefect = new System.Windows.Forms.Label();
            this.LblTvDiagonal = new System.Windows.Forms.Label();
            this.LblTvBrend = new System.Windows.Forms.Label();
            this.CmbTvBrend = new System.Windows.Forms.ComboBox();
            this.MniSample = new System.Windows.Forms.ToolStripMenuItem();
            this.MniSampleMinCost = new System.Windows.Forms.ToolStripMenuItem();
            this.MniSampleMaster = new System.Windows.Forms.ToolStripMenuItem();
            this.MniSampleDiagonal = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.MniHelp = new System.Windows.Forms.ToolStripMenuItem();
            this.MniHelpAbout = new System.Windows.Forms.ToolStripMenuItem();
            this.TsbExit = new System.Windows.Forms.ToolStripButton();
            this.TslHelpAbout = new System.Windows.Forms.ToolStripButton();
            this.TlsTvRed = new System.Windows.Forms.ToolStripButton();
            this.TslRedTv = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.TslMinPrice = new System.Windows.Forms.ToolStripButton();
            this.TslMaster = new System.Windows.Forms.ToolStripButton();
            this.TslDiagonal = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.MnuMain.SuspendLayout();
            this.TsbMain.SuspendLayout();
            this.StsMain.SuspendLayout();
            this.GrbTelevisions.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.NudCost)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NudDiagonal)).BeginInit();
            this.SuspendLayout();
            // 
            // MnuMain
            // 
            this.MnuMain.Font = new System.Drawing.Font("Lucida Console", 12F);
            this.MnuMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniFile,
            this.MniEdit,
            this.MniSort,
            this.MniSample,
            this.MniHelp});
            this.MnuMain.Location = new System.Drawing.Point(0, 0);
            this.MnuMain.Name = "MnuMain";
            this.MnuMain.Size = new System.Drawing.Size(1028, 24);
            this.MnuMain.TabIndex = 0;
            this.MnuMain.Text = "menuStrip1";
            // 
            // MniFile
            // 
            this.MniFile.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniExit});
            this.MniFile.Name = "MniFile";
            this.MniFile.Size = new System.Drawing.Size(60, 20);
            this.MniFile.Text = "Файл";
            // 
            // MniExit
            // 
            this.MniExit.Image = ((System.Drawing.Image)(resources.GetObject("MniExit.Image")));
            this.MniExit.Name = "MniExit";
            this.MniExit.Size = new System.Drawing.Size(180, 22);
            this.MniExit.Text = "Выход";
            this.MniExit.Click += new System.EventHandler(this.Exit_Command);
            // 
            // MniEdit
            // 
            this.MniEdit.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniEditNewCollection,
            this.toolStripMenuItem1,
            this.MniEditingTV,
            this.MniEditingMastersk});
            this.MniEdit.Name = "MniEdit";
            this.MniEdit.Size = new System.Drawing.Size(80, 20);
            this.MniEdit.Text = "Правка";
            // 
            // MniEditNewCollection
            // 
            this.MniEditNewCollection.Image = ((System.Drawing.Image)(resources.GetObject("MniEditNewCollection.Image")));
            this.MniEditNewCollection.Name = "MniEditNewCollection";
            this.MniEditNewCollection.Size = new System.Drawing.Size(386, 22);
            this.MniEditNewCollection.Text = "Новая коллекция";
            this.MniEditNewCollection.Click += new System.EventHandler(this.NewCollection_Command);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(383, 6);
            // 
            // MniEditingTV
            // 
            this.MniEditingTV.Name = "MniEditingTV";
            this.MniEditingTV.Size = new System.Drawing.Size(386, 22);
            this.MniEditingTV.Text = "Редактировать TV";
            this.MniEditingTV.Click += new System.EventHandler(this.TVEdit_Command);
            // 
            // MniEditingMastersk
            // 
            this.MniEditingMastersk.Name = "MniEditingMastersk";
            this.MniEditingMastersk.Size = new System.Drawing.Size(386, 22);
            this.MniEditingMastersk.Text = "Редактировать данные мастерской";
            // 
            // MniSort
            // 
            this.MniSort.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniSortBrend,
            this.MniSortDiag,
            this.MniSortMaster,
            this.MniSortOwner});
            this.MniSort.Name = "MniSort";
            this.MniSort.Size = new System.Drawing.Size(120, 20);
            this.MniSort.Text = "Сортировка";
            // 
            // MniSortBrend
            // 
            this.MniSortBrend.Image = ((System.Drawing.Image)(resources.GetObject("MniSortBrend.Image")));
            this.MniSortBrend.Name = "MniSortBrend";
            this.MniSortBrend.Size = new System.Drawing.Size(266, 22);
            this.MniSortBrend.Text = "По бренду";
            this.MniSortBrend.Click += new System.EventHandler(this.OrderbyTvBrand_Command);
            // 
            // MniSortDiag
            // 
            this.MniSortDiag.Image = ((System.Drawing.Image)(resources.GetObject("MniSortDiag.Image")));
            this.MniSortDiag.Name = "MniSortDiag";
            this.MniSortDiag.Size = new System.Drawing.Size(266, 22);
            this.MniSortDiag.Text = "По диагонали экрана";
            this.MniSortDiag.Click += new System.EventHandler(this.OrderbyDiagonal_Command);
            // 
            // MniSortMaster
            // 
            this.MniSortMaster.Image = ((System.Drawing.Image)(resources.GetObject("MniSortMaster.Image")));
            this.MniSortMaster.Name = "MniSortMaster";
            this.MniSortMaster.Size = new System.Drawing.Size(266, 22);
            this.MniSortMaster.Text = "По ФИО мастера";
            this.MniSortMaster.Click += new System.EventHandler(this.OrderbyFullnameMaster_Command);
            // 
            // MniSortOwner
            // 
            this.MniSortOwner.Image = ((System.Drawing.Image)(resources.GetObject("MniSortOwner.Image")));
            this.MniSortOwner.Name = "MniSortOwner";
            this.MniSortOwner.Size = new System.Drawing.Size(266, 22);
            this.MniSortOwner.Text = "По ФИО владельца";
            this.MniSortOwner.Click += new System.EventHandler(this.OrderbyFullnameOwner_Command);
            // 
            // TsbMain
            // 
            this.TsbMain.AutoSize = false;
            this.TsbMain.Font = new System.Drawing.Font("Lucida Console", 12F);
            this.TsbMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.TlsNew,
            this.TstAdd,
            this.toolStripSeparator1,
            this.TslRedTv,
            this.TlsTvRed,
            this.toolStripSeparator2,
            this.TlsSort,
            this.TlsSortD,
            this.TlsSortFM,
            this.TlsTO,
            this.TsbExit,
            this.toolStripSeparator3,
            this.TslMinPrice,
            this.TslMaster,
            this.TslDiagonal,
            this.toolStripSeparator4,
            this.TslHelpAbout});
            this.TsbMain.Location = new System.Drawing.Point(0, 24);
            this.TsbMain.Name = "TsbMain";
            this.TsbMain.Size = new System.Drawing.Size(1028, 38);
            this.TsbMain.TabIndex = 1;
            this.TsbMain.Text = "toolStrip1";
            // 
            // TlsNew
            // 
            this.TlsNew.BackColor = System.Drawing.Color.PaleTurquoise;
            this.TlsNew.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TlsNew.Image = ((System.Drawing.Image)(resources.GetObject("TlsNew.Image")));
            this.TlsNew.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TlsNew.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TlsNew.Name = "TlsNew";
            this.TlsNew.Size = new System.Drawing.Size(32, 35);
            this.TlsNew.Text = "Новая коллекция";
            this.TlsNew.ToolTipText = "Сформировать новую коллекцию";
            this.TlsNew.Click += new System.EventHandler(this.NewCollection_Command);
            // 
            // TstAdd
            // 
            this.TstAdd.BackColor = System.Drawing.Color.PowderBlue;
            this.TstAdd.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TstAdd.Image = ((System.Drawing.Image)(resources.GetObject("TstAdd.Image")));
            this.TstAdd.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TstAdd.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TstAdd.Name = "TstAdd";
            this.TstAdd.Size = new System.Drawing.Size(32, 35);
            this.TstAdd.Text = "Добавить данные";
            this.TstAdd.Click += new System.EventHandler(this.AddTelevision_Command);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 38);
            // 
            // TlsSort
            // 
            this.TlsSort.BackColor = System.Drawing.Color.LightCyan;
            this.TlsSort.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TlsSort.Image = ((System.Drawing.Image)(resources.GetObject("TlsSort.Image")));
            this.TlsSort.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TlsSort.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TlsSort.Name = "TlsSort";
            this.TlsSort.Size = new System.Drawing.Size(32, 35);
            this.TlsSort.Text = "toolStripButton3";
            this.TlsSort.ToolTipText = "Сортировка коллекции по \r\nбренду телевизора";
            this.TlsSort.Click += new System.EventHandler(this.OrderbyTvBrand_Command);
            // 
            // TlsSortD
            // 
            this.TlsSortD.BackColor = System.Drawing.Color.LightCyan;
            this.TlsSortD.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TlsSortD.Image = ((System.Drawing.Image)(resources.GetObject("TlsSortD.Image")));
            this.TlsSortD.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TlsSortD.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TlsSortD.Name = "TlsSortD";
            this.TlsSortD.Size = new System.Drawing.Size(32, 35);
            this.TlsSortD.Text = "toolStripButton1";
            this.TlsSortD.ToolTipText = "Сортировка коллекции по \r\nдиагонали телевизора";
            this.TlsSortD.Click += new System.EventHandler(this.OrderbyDiagonal_Command);
            // 
            // TlsSortFM
            // 
            this.TlsSortFM.BackColor = System.Drawing.Color.LightCyan;
            this.TlsSortFM.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TlsSortFM.Image = ((System.Drawing.Image)(resources.GetObject("TlsSortFM.Image")));
            this.TlsSortFM.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TlsSortFM.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TlsSortFM.Name = "TlsSortFM";
            this.TlsSortFM.Size = new System.Drawing.Size(32, 35);
            this.TlsSortFM.Text = "toolStripButton2";
            this.TlsSortFM.ToolTipText = "Сортировка коллекции по мастеру,\r\nвыполняющему ремонт";
            this.TlsSortFM.Click += new System.EventHandler(this.OrderbyFullnameMaster_Command);
            // 
            // TlsTO
            // 
            this.TlsTO.BackColor = System.Drawing.Color.LightCyan;
            this.TlsTO.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TlsTO.Image = ((System.Drawing.Image)(resources.GetObject("TlsTO.Image")));
            this.TlsTO.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TlsTO.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TlsTO.Name = "TlsTO";
            this.TlsTO.Size = new System.Drawing.Size(32, 35);
            this.TlsTO.Text = "toolStripButton3";
            this.TlsTO.ToolTipText = "Сортировка коллекции по \r\nвладельцу телевизора";
            this.TlsTO.Click += new System.EventHandler(this.OrderbyFullnameOwner_Command);
            // 
            // StsMain
            // 
            this.StsMain.Font = new System.Drawing.Font("Lucida Console", 10F);
            this.StsMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.StlMain});
            this.StsMain.Location = new System.Drawing.Point(0, 539);
            this.StsMain.Name = "StsMain";
            this.StsMain.Size = new System.Drawing.Size(1028, 22);
            this.StsMain.TabIndex = 2;
            this.StsMain.Text = "StripStatus";
            // 
            // StlMain
            // 
            this.StlMain.Name = "StlMain";
            this.StlMain.Size = new System.Drawing.Size(1013, 17);
            this.StlMain.Spring = true;
            this.StlMain.Text = "ToolStripStatusLabel1";
            this.StlMain.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // LbxTelevisions
            // 
            this.LbxTelevisions.Font = new System.Drawing.Font("Consolas", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LbxTelevisions.FormattingEnabled = true;
            this.LbxTelevisions.ItemHeight = 15;
            this.LbxTelevisions.Location = new System.Drawing.Point(12, 115);
            this.LbxTelevisions.Name = "LbxTelevisions";
            this.LbxTelevisions.ScrollAlwaysVisible = true;
            this.LbxTelevisions.Size = new System.Drawing.Size(625, 364);
            this.LbxTelevisions.TabIndex = 4;
            // 
            // LblTelevisions
            // 
            this.LblTelevisions.BackColor = System.Drawing.SystemColors.Control;
            this.LblTelevisions.Font = new System.Drawing.Font("Verdana", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblTelevisions.Location = new System.Drawing.Point(12, 71);
            this.LblTelevisions.Name = "LblTelevisions";
            this.LblTelevisions.Size = new System.Drawing.Size(625, 41);
            this.LblTelevisions.TabIndex = 5;
            this.LblTelevisions.Text = "Коллекция телевизоров:\r\n  Бренд    Дюйм      Описание дефекта      ФИО мастера   " +
    " ФИО владельца   Цена";
            // 
            // GrbTelevisions
            // 
            this.GrbTelevisions.BackColor = System.Drawing.Color.Lavender;
            this.GrbTelevisions.Controls.Add(this.NudCost);
            this.GrbTelevisions.Controls.Add(this.NudDiagonal);
            this.GrbTelevisions.Controls.Add(this.BtnOk);
            this.GrbTelevisions.Controls.Add(this.LblCost);
            this.GrbTelevisions.Controls.Add(this.CmbOwner);
            this.GrbTelevisions.Controls.Add(this.LblOwner);
            this.GrbTelevisions.Controls.Add(this.CmbMaster);
            this.GrbTelevisions.Controls.Add(this.LblMaster);
            this.GrbTelevisions.Controls.Add(this.CmbTVDefect);
            this.GrbTelevisions.Controls.Add(this.LblDefect);
            this.GrbTelevisions.Controls.Add(this.LblTvDiagonal);
            this.GrbTelevisions.Controls.Add(this.LblTvBrend);
            this.GrbTelevisions.Controls.Add(this.CmbTvBrend);
            this.GrbTelevisions.Font = new System.Drawing.Font("Lucida Console", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.GrbTelevisions.Location = new System.Drawing.Point(655, 115);
            this.GrbTelevisions.Name = "GrbTelevisions";
            this.GrbTelevisions.Size = new System.Drawing.Size(350, 364);
            this.GrbTelevisions.TabIndex = 6;
            this.GrbTelevisions.TabStop = false;
            this.GrbTelevisions.Text = " Данные нового телевизора: ";
            // 
            // NudCost
            // 
            this.NudCost.Increment = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.NudCost.Location = new System.Drawing.Point(173, 260);
            this.NudCost.Maximum = new decimal(new int[] {
            5000,
            0,
            0,
            0});
            this.NudCost.Name = "NudCost";
            this.NudCost.Size = new System.Drawing.Size(171, 22);
            this.NudCost.TabIndex = 11;
            this.NudCost.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // NudDiagonal
            // 
            this.NudDiagonal.Location = new System.Drawing.Point(173, 93);
            this.NudDiagonal.Maximum = new decimal(new int[] {
            150,
            0,
            0,
            0});
            this.NudDiagonal.Minimum = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.NudDiagonal.Name = "NudDiagonal";
            this.NudDiagonal.Size = new System.Drawing.Size(171, 22);
            this.NudDiagonal.TabIndex = 2;
            this.NudDiagonal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.NudDiagonal.Value = new decimal(new int[] {
            20,
            0,
            0,
            0});
            // 
            // BtnOk
            // 
            this.BtnOk.BackColor = System.Drawing.Color.LightCyan;
            this.BtnOk.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BtnOk.Location = new System.Drawing.Point(124, 315);
            this.BtnOk.Name = "BtnOk";
            this.BtnOk.Size = new System.Drawing.Size(220, 32);
            this.BtnOk.TabIndex = 10;
            this.BtnOk.Text = "Добавить данные";
            this.BtnOk.UseVisualStyleBackColor = false;
            this.BtnOk.Click += new System.EventHandler(this.AddTelevision_Command);
            // 
            // LblCost
            // 
            this.LblCost.AutoSize = true;
            this.LblCost.Location = new System.Drawing.Point(6, 267);
            this.LblCost.Name = "LblCost";
            this.LblCost.Size = new System.Drawing.Size(169, 15);
            this.LblCost.TabIndex = 8;
            this.LblCost.Text = "Стоимость ремонта:";
            // 
            // CmbOwner
            // 
            this.CmbOwner.DropDownStyle = System.Windows.Forms.ComboBoxStyle.Simple;
            this.CmbOwner.FormattingEnabled = true;
            this.CmbOwner.Location = new System.Drawing.Point(173, 132);
            this.CmbOwner.Name = "CmbOwner";
            this.CmbOwner.Size = new System.Drawing.Size(171, 21);
            this.CmbOwner.TabIndex = 3;
            // 
            // LblOwner
            // 
            this.LblOwner.AutoSize = true;
            this.LblOwner.Location = new System.Drawing.Point(6, 138);
            this.LblOwner.Name = "LblOwner";
            this.LblOwner.Size = new System.Drawing.Size(115, 15);
            this.LblOwner.TabIndex = 7;
            this.LblOwner.Text = "Владелец TV:";
            // 
            // CmbMaster
            // 
            this.CmbMaster.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CmbMaster.FormattingEnabled = true;
            this.CmbMaster.Items.AddRange(new object[] {
            "Воронин Л.А.",
            "Ковалёв М.А.",
            "Лужко С.Л.",
            "Тюрин О.А."});
            this.CmbMaster.Location = new System.Drawing.Point(173, 216);
            this.CmbMaster.Name = "CmbMaster";
            this.CmbMaster.Size = new System.Drawing.Size(171, 23);
            this.CmbMaster.Sorted = true;
            this.CmbMaster.TabIndex = 5;
            // 
            // LblMaster
            // 
            this.LblMaster.AutoSize = true;
            this.LblMaster.Location = new System.Drawing.Point(6, 224);
            this.LblMaster.Name = "LblMaster";
            this.LblMaster.Size = new System.Drawing.Size(169, 15);
            this.LblMaster.TabIndex = 6;
            this.LblMaster.Text = "Мастер по ремонту:";
            // 
            // CmbTVDefect
            // 
            this.CmbTVDefect.DropDownStyle = System.Windows.Forms.ComboBoxStyle.Simple;
            this.CmbTVDefect.FormattingEnabled = true;
            this.CmbTVDefect.Location = new System.Drawing.Point(173, 174);
            this.CmbTVDefect.Name = "CmbTVDefect";
            this.CmbTVDefect.Size = new System.Drawing.Size(171, 21);
            this.CmbTVDefect.TabIndex = 4;
            // 
            // LblDefect
            // 
            this.LblDefect.AutoSize = true;
            this.LblDefect.Location = new System.Drawing.Point(6, 181);
            this.LblDefect.Name = "LblDefect";
            this.LblDefect.Size = new System.Drawing.Size(169, 15);
            this.LblDefect.TabIndex = 4;
            this.LblDefect.Text = "Введите дефект TV:";
            // 
            // LblTvDiagonal
            // 
            this.LblTvDiagonal.AutoSize = true;
            this.LblTvDiagonal.Location = new System.Drawing.Point(6, 95);
            this.LblTvDiagonal.Name = "LblTvDiagonal";
            this.LblTvDiagonal.Size = new System.Drawing.Size(124, 15);
            this.LblTvDiagonal.TabIndex = 3;
            this.LblTvDiagonal.Text = "Диагональ TV:";
            // 
            // LblTvBrend
            // 
            this.LblTvBrend.AutoSize = true;
            this.LblTvBrend.Location = new System.Drawing.Point(6, 52);
            this.LblTvBrend.Name = "LblTvBrend";
            this.LblTvBrend.Size = new System.Drawing.Size(97, 15);
            this.LblTvBrend.TabIndex = 1;
            this.LblTvBrend.Text = "Модель TV:";
            // 
            // CmbTvBrend
            // 
            this.CmbTvBrend.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CmbTvBrend.FormattingEnabled = true;
            this.CmbTvBrend.Items.AddRange(new object[] {
            "Hisense",
            "LG",
            "Philips",
            "Samsung",
            "Sony",
            "TCL"});
            this.CmbTvBrend.Location = new System.Drawing.Point(173, 44);
            this.CmbTvBrend.Name = "CmbTvBrend";
            this.CmbTvBrend.Size = new System.Drawing.Size(171, 23);
            this.CmbTvBrend.Sorted = true;
            this.CmbTvBrend.TabIndex = 1;
            // 
            // MniSample
            // 
            this.MniSample.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniSampleMinCost,
            this.MniSampleMaster,
            this.MniSampleDiagonal});
            this.MniSample.Name = "MniSample";
            this.MniSample.Size = new System.Drawing.Size(90, 20);
            this.MniSample.Text = "Выборка";
            // 
            // MniSampleMinCost
            // 
            this.MniSampleMinCost.Font = new System.Drawing.Font("Lucida Console", 10F);
            this.MniSampleMinCost.Name = "MniSampleMinCost";
            this.MniSampleMinCost.Size = new System.Drawing.Size(355, 22);
            this.MniSampleMinCost.Text = "TV с минимальной стоимостью ремонта";
            this.MniSampleMinCost.Click += new System.EventHandler(this.SampleMinCost_Command);
            // 
            // MniSampleMaster
            // 
            this.MniSampleMaster.Font = new System.Drawing.Font("Lucida Console", 10F);
            this.MniSampleMaster.Name = "MniSampleMaster";
            this.MniSampleMaster.Size = new System.Drawing.Size(355, 22);
            this.MniSampleMaster.Text = "TV ремонтируемых выбранным мастером";
            // 
            // MniSampleDiagonal
            // 
            this.MniSampleDiagonal.Font = new System.Drawing.Font("Lucida Console", 10F);
            this.MniSampleDiagonal.Name = "MniSampleDiagonal";
            this.MniSampleDiagonal.Size = new System.Drawing.Size(355, 22);
            this.MniSampleDiagonal.Text = "TV с заданной диагональю экрана";
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 38);
            // 
            // MniHelp
            // 
            this.MniHelp.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.MniHelp.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniHelpAbout});
            this.MniHelp.Name = "MniHelp";
            this.MniHelp.Size = new System.Drawing.Size(90, 20);
            this.MniHelp.Text = "Справка";
            // 
            // MniHelpAbout
            // 
            this.MniHelpAbout.Image = ((System.Drawing.Image)(resources.GetObject("MniHelpAbout.Image")));
            this.MniHelpAbout.Name = "MniHelpAbout";
            this.MniHelpAbout.Size = new System.Drawing.Size(206, 22);
            this.MniHelpAbout.Text = "О программе..";
            // 
            // TsbExit
            // 
            this.TsbExit.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.TsbExit.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbExit.Image = ((System.Drawing.Image)(resources.GetObject("TsbExit.Image")));
            this.TsbExit.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbExit.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbExit.Name = "TsbExit";
            this.TsbExit.Size = new System.Drawing.Size(32, 35);
            this.TsbExit.Text = "toolStripButton1";
            this.TsbExit.ToolTipText = "Завершение работы приложения";
            this.TsbExit.Click += new System.EventHandler(this.Exit_Command);
            // 
            // TslHelpAbout
            // 
            this.TslHelpAbout.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TslHelpAbout.Image = ((System.Drawing.Image)(resources.GetObject("TslHelpAbout.Image")));
            this.TslHelpAbout.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TslHelpAbout.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TslHelpAbout.Name = "TslHelpAbout";
            this.TslHelpAbout.Size = new System.Drawing.Size(32, 35);
            this.TslHelpAbout.Text = "toolStripButton1";
            this.TslHelpAbout.ToolTipText = "Вывод свежедений о приложении \r\nи разработчике";
            this.TslHelpAbout.Click += new System.EventHandler(this.About_Command);
            // 
            // TlsTvRed
            // 
            this.TlsTvRed.BackColor = System.Drawing.Color.PaleTurquoise;
            this.TlsTvRed.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TlsTvRed.Image = ((System.Drawing.Image)(resources.GetObject("TlsTvRed.Image")));
            this.TlsTvRed.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TlsTvRed.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TlsTvRed.Name = "TlsTvRed";
            this.TlsTvRed.Size = new System.Drawing.Size(32, 35);
            this.TlsTvRed.Text = "toolStripButton1";
            this.TlsTvRed.ToolTipText = "Редактирование данные мастерской";
            // 
            // TslRedTv
            // 
            this.TslRedTv.BackColor = System.Drawing.Color.PaleTurquoise;
            this.TslRedTv.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TslRedTv.Image = ((System.Drawing.Image)(resources.GetObject("TslRedTv.Image")));
            this.TslRedTv.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TslRedTv.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TslRedTv.Name = "TslRedTv";
            this.TslRedTv.Size = new System.Drawing.Size(32, 35);
            this.TslRedTv.Text = "toolStripButton1";
            this.TslRedTv.ToolTipText = "Редактировать данные\r\nвыбранного телевизора";
            this.TslRedTv.Click += new System.EventHandler(this.TVEdit_Command);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(6, 38);
            // 
            // TslMinPrice
            // 
            this.TslMinPrice.BackColor = System.Drawing.Color.LightBlue;
            this.TslMinPrice.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TslMinPrice.Image = ((System.Drawing.Image)(resources.GetObject("TslMinPrice.Image")));
            this.TslMinPrice.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TslMinPrice.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TslMinPrice.Name = "TslMinPrice";
            this.TslMinPrice.Size = new System.Drawing.Size(32, 35);
            this.TslMinPrice.Text = "toolStripButton1";
            this.TslMinPrice.ToolTipText = "Выборка телевизоров с\r\nминимальной стоимостью ремонта";
            // 
            // TslMaster
            // 
            this.TslMaster.BackColor = System.Drawing.Color.LightBlue;
            this.TslMaster.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TslMaster.Image = ((System.Drawing.Image)(resources.GetObject("TslMaster.Image")));
            this.TslMaster.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TslMaster.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TslMaster.Name = "TslMaster";
            this.TslMaster.Size = new System.Drawing.Size(32, 35);
            this.TslMaster.Text = "toolStripButton2";
            this.TslMaster.ToolTipText = "Выборка телевизоров ремонтируемых\r\nвыбранным мастером";
            // 
            // TslDiagonal
            // 
            this.TslDiagonal.BackColor = System.Drawing.Color.LightBlue;
            this.TslDiagonal.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TslDiagonal.Image = ((System.Drawing.Image)(resources.GetObject("TslDiagonal.Image")));
            this.TslDiagonal.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TslDiagonal.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TslDiagonal.Name = "TslDiagonal";
            this.TslDiagonal.Size = new System.Drawing.Size(32, 35);
            this.TslDiagonal.Text = "toolStripButton3";
            this.TslDiagonal.ToolTipText = "Выборка телевизоров с\r\n заданной диагональю экрана";
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(6, 38);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1028, 561);
            this.Controls.Add(this.GrbTelevisions);
            this.Controls.Add(this.LblTelevisions);
            this.Controls.Add(this.LbxTelevisions);
            this.Controls.Add(this.StsMain);
            this.Controls.Add(this.TsbMain);
            this.Controls.Add(this.MnuMain);
            this.MainMenuStrip = this.MnuMain;
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(1100, 600);
            this.MinimumSize = new System.Drawing.Size(1022, 566);
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Домашнее задание №8";
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.MnuMain.ResumeLayout(false);
            this.MnuMain.PerformLayout();
            this.TsbMain.ResumeLayout(false);
            this.TsbMain.PerformLayout();
            this.StsMain.ResumeLayout(false);
            this.StsMain.PerformLayout();
            this.GrbTelevisions.ResumeLayout(false);
            this.GrbTelevisions.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.NudCost)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NudDiagonal)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip MnuMain;
        private System.Windows.Forms.ToolStripMenuItem MniFile;
        private System.Windows.Forms.ToolStripMenuItem MniExit;
        private System.Windows.Forms.ToolStrip TsbMain;
        private System.Windows.Forms.StatusStrip StsMain;
        private System.Windows.Forms.ToolStripStatusLabel StlMain;
        private System.Windows.Forms.ToolStripMenuItem MniEdit;
        private System.Windows.Forms.ToolStripMenuItem MniEditNewCollection;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem MniEditingTV;
        private System.Windows.Forms.ToolStripMenuItem MniEditingMastersk;
        private System.Windows.Forms.ToolStripButton TlsNew;
        private System.Windows.Forms.ToolStripButton TstAdd;
        private System.Windows.Forms.ToolStripButton TlsSort;
        private System.Windows.Forms.ListBox LbxTelevisions;
        private System.Windows.Forms.Label LblTelevisions;
        private System.Windows.Forms.GroupBox GrbTelevisions;
        private System.Windows.Forms.Label LblTvDiagonal;
        private System.Windows.Forms.Label LblTvBrend;
        private System.Windows.Forms.ComboBox CmbTvBrend;
        private System.Windows.Forms.Label LblMaster;
        private System.Windows.Forms.ComboBox CmbTVDefect;
        private System.Windows.Forms.Label LblDefect;
        private System.Windows.Forms.Label LblCost;
        private System.Windows.Forms.ComboBox CmbOwner;
        private System.Windows.Forms.Label LblOwner;
        private System.Windows.Forms.ComboBox CmbMaster;
        private System.Windows.Forms.Button BtnOk;
        private System.Windows.Forms.NumericUpDown NudDiagonal;
        private System.Windows.Forms.NumericUpDown NudCost;
        private System.Windows.Forms.ToolStripMenuItem MniSort;
        private System.Windows.Forms.ToolStripMenuItem MniSortBrend;
        private System.Windows.Forms.ToolStripMenuItem MniSortDiag;
        private System.Windows.Forms.ToolStripMenuItem MniSortMaster;
        private System.Windows.Forms.ToolStripMenuItem MniSortOwner;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripButton TlsSortD;
        private System.Windows.Forms.ToolStripButton TlsSortFM;
        private System.Windows.Forms.ToolStripButton TlsTO;
        private System.Windows.Forms.ToolStripMenuItem MniSample;
        private System.Windows.Forms.ToolStripMenuItem MniSampleMinCost;
        private System.Windows.Forms.ToolStripMenuItem MniSampleMaster;
        private System.Windows.Forms.ToolStripMenuItem MniSampleDiagonal;
        private System.Windows.Forms.ToolStripMenuItem MniHelp;
        private System.Windows.Forms.ToolStripMenuItem MniHelpAbout;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripButton TsbExit;
        private System.Windows.Forms.ToolStripButton TslHelpAbout;
        private System.Windows.Forms.ToolStripButton TslRedTv;
        private System.Windows.Forms.ToolStripButton TlsTvRed;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripButton TslMinPrice;
        private System.Windows.Forms.ToolStripButton TslMaster;
        private System.Windows.Forms.ToolStripButton TslDiagonal;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
    }
}

