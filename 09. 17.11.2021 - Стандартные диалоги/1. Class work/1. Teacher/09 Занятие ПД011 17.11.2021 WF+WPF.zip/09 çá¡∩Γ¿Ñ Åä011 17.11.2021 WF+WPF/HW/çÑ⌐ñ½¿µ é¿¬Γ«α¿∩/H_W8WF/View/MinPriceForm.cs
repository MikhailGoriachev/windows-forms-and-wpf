﻿using H_W8WF.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace H_W8WF.View
{
    public partial class MinPriceForm : Form
    {
        private RepairShop _televisionsController;

        public RepairShop TeLevisionControl
        {
            get => _televisionsController;
            set
            {
                _televisionsController = value;

                TxtBoxInfo.Text = $"{_televisionsController}";
            }
        }
        public MinPriceForm()
        {
            InitializeComponent();
        }
    }
}
