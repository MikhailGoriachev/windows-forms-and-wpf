﻿using H_W8WF.Models;
using H_W8WF.View;
using H_W8WF.Views;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace H_W8WF
{
    public partial class MainForm : Form
    {
        // контроллер для работы с коллекцией телевизоров
        private RepairShop _televisionsController;

        /// <summary>
        /// Конструкторы формы, с возможностью внедрения зависимостей
        /// </summary>
        public MainForm() : this(new RepairShop()) { } // MainForm

        public MainForm(RepairShop televisionsController)
        {
            InitializeComponent();

            _televisionsController = televisionsController;

            // привязка ListBox к коллекции
            BindCollection();
        } // MainForm

        // выполнение привязки коллекции
        private void BindCollection()
        {
            // остановить привязку
            LbxTelevisions.DataSource = null;

            // задать привязку
            LbxTelevisions.DataSource = _televisionsController.Televisions;

            LbxTelevisions.DisplayMember = "TableRow";
        } // BindCollection

        // команда заверешния работы приложения
        private void Exit_Command(object sender, EventArgs e) => Application.Exit();

        private void MainForm_Load(object sender, EventArgs e)
        {
            // вывод в строку состояния
            StlMain.Text = $"Сформировано телевизоров: {_televisionsController.Count}";
        }// MainForm_Load

        // команда отображения окна сведений о программе
        private void About_Command(object sender, EventArgs e)
        {
            AboutForm aboutForm = new AboutForm();
            aboutForm.ShowDialog();
        }// About_Command

        private void NewCollection_Command(object sender, EventArgs e)
        {
            _televisionsController.Inizialize();

            BindCollection();

            // обновить строку состояния
            StlMain.Text = $"Коллекция данных сформирована. Текущее количество телевизоров: {_televisionsController.Count}";
        }// NewCollection_Command

        // добавление телевизора в коллекцию
        private void AddTelevision_Command(object sender, EventArgs e)
        {
            try
            {
                // собрать телевизор из данных формы
                Television tv = new Television
                {
                    TvBrand = CmbTvBrend.Text,
                    Diagonal = (int)NudDiagonal.Value,
                    TvDefect = CmbTVDefect.Text,
                    FullnameMaster = CmbMaster.Text,
                    FullnameOwner = CmbOwner.Text,
                    CostRepair = (int)NudCost.Value
                };

                // добавить телевизор в коллекцию
                _televisionsController.AddTelevizion(tv);

                // обновить привязку
                BindCollection();

                // обновить строку состояния
                StlMain.Text = $"Данные добавлены. Текущее количество телевизоров: {_televisionsController.Count}";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            } // try-catch
        }// AddTelevision_Command


        private void OrderbyTvBrand_Command(object sender, EventArgs e)
        {
            _televisionsController.OrderbyTvBrand();

            BindCollection();

            // обновить строку состояния
            StlMain.Text = $"Коллекция телевизоров упорядочена по бренду. Текущее количество телевизоров: {_televisionsController.Count}";
        }// OrderbyTvBrand_Command

        private void OrderbyDiagonal_Command(object sender, EventArgs e)
        {
            _televisionsController.OrderbyDiagonal();

            BindCollection();

            // обновить строку состояния
            StlMain.Text = $"Коллекция телевизоров упорядочена по убыванию диагонали. Текущее количество телевизоров: {_televisionsController.Count}";
        }// OrderbyDiagonal_Command

        private void OrderbyFullnameMaster_Command(object sender, EventArgs e)
        {
            _televisionsController.OrderbyFullnameMaster();

            BindCollection();

            // обновить строку состояния
            StlMain.Text = $"Коллекция телевизоров упорядочена по ФИО мастера. Текущее количество телевизоров: {_televisionsController.Count}";
        }// OrderbyFullnameMaster_Command

        private void OrderbyFullnameOwner_Command(object sender, EventArgs e)
        {
            _televisionsController.OrderbyFullnameOwner();

            BindCollection();

            // обновить строку состояния
            StlMain.Text = $"Коллекция телевизоров упорядочена по ФИО владельца. Текущее количество телевизоров: {_televisionsController.Count}";
        }// OrderbyFullnameOwner_Command

        private void SampleMinCost_Command(object sender, EventArgs e)
        {
            MinPriceForm minPriceForm = new MinPriceForm();
            DialogResult dialogResult = minPriceForm.ShowDialog();

            int cost = 300;

            _televisionsController.GetPriceRepair(cost);

            if (dialogResult != DialogResult.OK) return;

            // получить данные из свойства формы
            RepairShop shop = minPriceForm.TeLevisionControl;
            _televisionsController.GetPriceRepair(cost);

            // список заявок по номеру рейса и дате вылета
            List<Television> list = new List<Television>();
            foreach (Television req in _televisionsController.GetPriceRepair(cost))
                list.Add(req);
            // обновить привязку
            BindCollection();

        }

        // pедактирование выбранного телевизора в отдельной форме
        private void TVEdit_Command(object sender, EventArgs e)
        {
            if (LbxTelevisions.SelectedIndex < 0)
                return;

            RepairShopForm shopForm = new RepairShopForm();
            shopForm.ShowDialog();


            // обновить привязку
            BindCollection();
        }// TVEdit_Command
    }
}
