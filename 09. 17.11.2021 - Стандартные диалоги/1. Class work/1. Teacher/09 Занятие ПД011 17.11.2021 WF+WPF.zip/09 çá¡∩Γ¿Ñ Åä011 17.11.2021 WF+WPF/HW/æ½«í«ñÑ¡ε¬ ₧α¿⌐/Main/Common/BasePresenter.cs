﻿using System;
using System.Windows.Forms;
using Main.ApplicationControl;


namespace Main.Common
{
	internal class BasePresenter<TView> : IPresenter
		where TView : IView
	{
		protected IApplicationController Controller { get; }


		protected TView View { get; }


		protected BasePresenter(TView view, IApplicationController controller)
		{
			View       = view;
			Controller = controller;
		}


		public void Run() => View.Show();

		public void Run(Action<Form> onStartup) => View.Show(onStartup);
	}
}