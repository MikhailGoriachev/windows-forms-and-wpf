﻿using Main.ApplicationControl;


namespace Main.Common
{
	internal class BaseArgPresenter<TView, TArg> : BasePresenter<TView>
		where TView : IView
	{
		protected BaseArgPresenter(TView view, IApplicationController controller) : base(view, controller) { }
	}
}