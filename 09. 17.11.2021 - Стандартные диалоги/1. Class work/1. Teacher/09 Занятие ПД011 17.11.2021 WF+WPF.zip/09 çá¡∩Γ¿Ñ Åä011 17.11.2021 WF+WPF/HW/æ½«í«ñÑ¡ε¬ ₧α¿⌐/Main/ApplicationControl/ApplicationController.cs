﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Windows.Forms;
using Autofac;
using Autofac.Features.ResolveAnything;
using Main.Common;
using Main.Models;


namespace Main.ApplicationControl
{
	internal sealed class ApplicationController : IApplicationController
	{
		private IContainer Container { get; }


		public ApplicationController() =>
			Container = PrepareDependencies();


		T IApplicationController.ResolveService<T>() =>
			Container.Resolve<T>();


		public void Run<TPresenter>() where TPresenter : IPresenter
		{
			var presenter = Container.Resolve<TPresenter>();

			presenter.Run();
		}


		public void Run<TPresenter, TArg>(TArg arg) where TPresenter : IPresenter
		{
			var presenter = Container.Resolve<TPresenter>(new TypedParameter(typeof(TArg), arg));

			presenter.Run();
		}


		public void Run<TPresenter>(Action<Form> onStartup) where TPresenter : IPresenter
		{
			var presenter = Container.Resolve<TPresenter>();

			presenter.Run(onStartup);
		}


		private IContainer PrepareDependencies()
		{
			var builder = new ContainerBuilder();
			
			builder.RegisterInstance(this).As<IApplicationController>();
			builder.RegisterInstance(new ApplicationContext()).AsSelf();

			foreach (var (form, view) in SelectFormWithView())
				builder.RegisterType(form).As(view);

			builder.RegisterType<TelevisionProvider>().As<ITelevisionProvider>();

			builder.RegisterSource<AnyConcreteTypeNotAlreadyRegisteredSource>();
			return builder.Build();
		}


		private static IEnumerable<(Type Form, Type View)> SelectFormWithView() =>
			Assembly.GetExecutingAssembly()
					.GetTypes()
					.Where(t => t.BaseType == typeof(BaseForm))
					.Select(t =>
						(
							Form: t,
							View: t.GetInterfaces()
								   .FirstOrDefault(i => i.GetInterfaces().Contains(typeof(IView)))
								  ?? throw new($"Форма {t.FullName} не реализует {typeof(IView)}")
						));
	}
}