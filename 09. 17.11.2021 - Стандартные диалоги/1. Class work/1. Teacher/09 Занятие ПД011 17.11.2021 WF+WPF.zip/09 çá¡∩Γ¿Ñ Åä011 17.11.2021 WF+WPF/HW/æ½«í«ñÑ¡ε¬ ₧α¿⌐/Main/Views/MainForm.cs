﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using Main.Common;
using Main.Models;


namespace Main.Views
{
	internal interface IMainFormView : IView
	{
		event Action FillRequired;
		event Action<DataGridView, DataGridViewCellCancelEventArgs> ValidateRequired;
		event Action<string, string> ShopDetailsChanged;

		event Action ProducerAndTypeOrderRequired;
		event Action DiagonalDescendingOrderRequired;
		event Action RepairerOrderRequired;
		event Action OwnerOrderRequired;
		event Action SelectMinPrice;
		event Action SelectRepairer;
		event Action SelectDiagonal;

		void SetView(IList<Television> content);

		void SetShopDetails(string title, string address);
	}


	public sealed partial class MainForm : BaseForm, IMainFormView
	{
		private readonly ApplicationContext _context;


		public MainForm(ApplicationContext context)
		{
			InitializeComponent();
			_context = context;

			televisionBindingSource.AllowNew = true;
			MainGridView.DataSource          = televisionBindingSource;
		}


		private void FillContextMenuItem_Click(object sender, EventArgs e) =>
			FillRequired?.Invoke();


		private void MainGridView_RowValidating(object sender, DataGridViewCellCancelEventArgs e) =>
			ValidateRequired?.Invoke((DataGridView)sender, e);


		private void ShopTextBox_TextChanged(object sender, EventArgs e) =>
			ShopDetailsChanged?.Invoke(TitleTextBox.Text, AddressTextBox.Text);


		private void OrderByProducerContextMenuItem_Click(object sender, EventArgs e) =>
			ProducerAndTypeOrderRequired?.Invoke();


		private void OrderByDiagonalDescendingContextMenuItem_Click(object sender, EventArgs e) =>
			DiagonalDescendingOrderRequired?.Invoke();


		private void OrderByRepairerContextMenuItem_Click(object sender, EventArgs e) =>
			RepairerOrderRequired?.Invoke();


		private void OrderByOwnerContextMenuItem_Click(object sender, EventArgs e) =>
			OwnerOrderRequired?.Invoke();


		private void SelectDiagonalContextMenuItem_Click(object sender, EventArgs e) =>
			SelectDiagonal?.Invoke();


		private void SelectRepairerContextMenuItem_Click(object sender, EventArgs e) =>
			SelectRepairer?.Invoke();


		private void SelectMinPriceContextMenuItem_Click(object sender, EventArgs e) =>
			SelectMinPrice?.Invoke();


		public event Action? FillRequired;
		public event Action<DataGridView, DataGridViewCellCancelEventArgs>? ValidateRequired;
		public event Action<string, string>? ShopDetailsChanged;
		public event Action? ProducerAndTypeOrderRequired;
		public event Action? DiagonalDescendingOrderRequired;
		public event Action? RepairerOrderRequired;
		public event Action? OwnerOrderRequired;
		public event Action? SelectMinPrice;
		public event Action? SelectRepairer;
		public event Action? SelectDiagonal;


		public void SetShopDetails(string title, string address)
		{
			TitleTextBox.Text   = title;
			AddressTextBox.Text = address;
		}


		public void SetView(IList<Television> content) =>
			televisionBindingSource.DataSource = content;


		public new void Show()
		{
			_context.MainForm = this;
			Application.Run(_context);
		}
	}
}