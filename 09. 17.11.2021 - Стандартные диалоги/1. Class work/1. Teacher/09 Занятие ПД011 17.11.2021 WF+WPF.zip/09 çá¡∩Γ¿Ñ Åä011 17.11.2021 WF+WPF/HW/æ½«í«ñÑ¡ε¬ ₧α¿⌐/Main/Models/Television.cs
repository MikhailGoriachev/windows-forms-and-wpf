﻿namespace Main.Models
{
	public sealed class Television
	{
		public string Producer { get; set; }
		public string Type { get; set; }
		public int Diagonal { get; set; }
		public string Owner { get; set; }
		public string Defect { get; set; }
		public string Repairer { get; set; }
		public decimal Price { get; set; }


		public Television() { }


		public Television(string producer, string type, int diagonal,
			string defect, string repairer, string owner, decimal price)
		{
			Producer = producer;
			Type     = type;
			Diagonal = diagonal;
			Defect   = defect;
			Repairer = repairer;
			Owner    = owner;
			Price    = price;
		}
	}
}