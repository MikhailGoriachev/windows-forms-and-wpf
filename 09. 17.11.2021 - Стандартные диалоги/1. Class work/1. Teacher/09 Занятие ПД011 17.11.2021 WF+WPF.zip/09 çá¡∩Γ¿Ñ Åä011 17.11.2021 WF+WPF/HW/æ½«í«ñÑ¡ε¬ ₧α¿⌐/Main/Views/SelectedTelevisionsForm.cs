﻿using System.Collections.Generic;
using System.Linq;
using Main.Common;
using Main.Models;


namespace Main.Views
{
	internal interface ISelectedTelevisionsView : IView
	{
		void ApplyItems(IEnumerable<Television> items);
	}


	public sealed partial class SelectedTelevisionsForm : BaseForm, ISelectedTelevisionsView
	{
		public SelectedTelevisionsForm() =>
			InitializeComponent();


		public new void Show() => ShowDialog();


		public void ApplyItems(IEnumerable<Television> items)
		{
			televisionBindingSource.DataSource = items;
		}
	}
}