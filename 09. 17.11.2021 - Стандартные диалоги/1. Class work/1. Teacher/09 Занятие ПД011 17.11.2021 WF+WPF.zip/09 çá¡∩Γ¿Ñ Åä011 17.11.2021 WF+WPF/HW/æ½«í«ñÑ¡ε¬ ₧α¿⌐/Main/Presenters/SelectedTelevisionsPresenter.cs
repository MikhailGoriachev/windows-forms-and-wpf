﻿using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Main.ApplicationControl;
using Main.Common;
using Main.Models;
using Main.Views;


namespace Main.Presenters
{
	internal sealed class SelectedTelevisionsPresenter : BaseArgPresenter<ISelectedTelevisionsView, IEnumerable<Television>>
	{
		public SelectedTelevisionsPresenter(IEnumerable<Television> items, ISelectedTelevisionsView view,
			IApplicationController controller)
			: base(view, controller)
		{
			View.ApplyItems(items);
		}
	}
}