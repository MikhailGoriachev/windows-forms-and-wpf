﻿namespace Main.Views
{
	partial class SelectedTelevisionsForm
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
			this.televisionBindingSource = new System.Windows.Forms.BindingSource(this.components);
			this.MainGridView = new System.Windows.Forms.DataGridView();
			this.defectDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.diagonalDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.ownerDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.priceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.producerDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.repairerDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.typeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			((System.ComponentModel.ISupportInitialize)(this.televisionBindingSource)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.MainGridView)).BeginInit();
			this.SuspendLayout();
			// 
			// televisionBindingSource
			// 
			this.televisionBindingSource.DataSource = typeof(Main.Models.Television);
			// 
			// MainGridView
			// 
			this.MainGridView.AutoGenerateColumns = false;
			this.MainGridView.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
			dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
			dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
			dataGridViewCellStyle1.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
			dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
			dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
			dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
			dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
			this.MainGridView.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
			this.MainGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.MainGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.defectDataGridViewTextBoxColumn,
            this.diagonalDataGridViewTextBoxColumn,
            this.ownerDataGridViewTextBoxColumn,
            this.priceDataGridViewTextBoxColumn,
            this.producerDataGridViewTextBoxColumn,
            this.repairerDataGridViewTextBoxColumn,
            this.typeDataGridViewTextBoxColumn});
			this.MainGridView.DataSource = this.televisionBindingSource;
			dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
			dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
			dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
			dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
			dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
			dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
			dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
			this.MainGridView.DefaultCellStyle = dataGridViewCellStyle2;
			this.MainGridView.Dock = System.Windows.Forms.DockStyle.Fill;
			this.MainGridView.Location = new System.Drawing.Point(0, 0);
			this.MainGridView.Name = "MainGridView";
			dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
			dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
			dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
			dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
			dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
			dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
			dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
			this.MainGridView.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
			this.MainGridView.Size = new System.Drawing.Size(800, 450);
			this.MainGridView.TabIndex = 2;
			// 
			// defectDataGridViewTextBoxColumn
			// 
			this.defectDataGridViewTextBoxColumn.DataPropertyName = "Defect";
			this.defectDataGridViewTextBoxColumn.HeaderText = "Defect";
			this.defectDataGridViewTextBoxColumn.Name = "defectDataGridViewTextBoxColumn";
			// 
			// diagonalDataGridViewTextBoxColumn
			// 
			this.diagonalDataGridViewTextBoxColumn.DataPropertyName = "Diagonal";
			this.diagonalDataGridViewTextBoxColumn.HeaderText = "Diagonal";
			this.diagonalDataGridViewTextBoxColumn.Name = "diagonalDataGridViewTextBoxColumn";
			// 
			// ownerDataGridViewTextBoxColumn
			// 
			this.ownerDataGridViewTextBoxColumn.DataPropertyName = "Owner";
			this.ownerDataGridViewTextBoxColumn.HeaderText = "Owner";
			this.ownerDataGridViewTextBoxColumn.Name = "ownerDataGridViewTextBoxColumn";
			// 
			// priceDataGridViewTextBoxColumn
			// 
			this.priceDataGridViewTextBoxColumn.DataPropertyName = "Price";
			this.priceDataGridViewTextBoxColumn.HeaderText = "Price";
			this.priceDataGridViewTextBoxColumn.Name = "priceDataGridViewTextBoxColumn";
			// 
			// producerDataGridViewTextBoxColumn
			// 
			this.producerDataGridViewTextBoxColumn.DataPropertyName = "Producer";
			this.producerDataGridViewTextBoxColumn.HeaderText = "Producer";
			this.producerDataGridViewTextBoxColumn.Name = "producerDataGridViewTextBoxColumn";
			// 
			// repairerDataGridViewTextBoxColumn
			// 
			this.repairerDataGridViewTextBoxColumn.DataPropertyName = "Repairer";
			this.repairerDataGridViewTextBoxColumn.HeaderText = "Repairer";
			this.repairerDataGridViewTextBoxColumn.Name = "repairerDataGridViewTextBoxColumn";
			// 
			// typeDataGridViewTextBoxColumn
			// 
			this.typeDataGridViewTextBoxColumn.DataPropertyName = "Type";
			this.typeDataGridViewTextBoxColumn.HeaderText = "Type";
			this.typeDataGridViewTextBoxColumn.Name = "typeDataGridViewTextBoxColumn";
			// 
			// SelectedTelevisionsForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(800, 450);
			this.Controls.Add(this.MainGridView);
			this.Name = "SelectedTelevisionsForm";
			this.Text = "SelectedTelevisionsForm";
			((System.ComponentModel.ISupportInitialize)(this.televisionBindingSource)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.MainGridView)).EndInit();
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.BindingSource televisionBindingSource;
		private System.Windows.Forms.DataGridView MainGridView;
		private System.Windows.Forms.DataGridViewTextBoxColumn defectDataGridViewTextBoxColumn;
		private System.Windows.Forms.DataGridViewTextBoxColumn diagonalDataGridViewTextBoxColumn;
		private System.Windows.Forms.DataGridViewTextBoxColumn ownerDataGridViewTextBoxColumn;
		private System.Windows.Forms.DataGridViewTextBoxColumn priceDataGridViewTextBoxColumn;
		private System.Windows.Forms.DataGridViewTextBoxColumn producerDataGridViewTextBoxColumn;
		private System.Windows.Forms.DataGridViewTextBoxColumn repairerDataGridViewTextBoxColumn;
		private System.Windows.Forms.DataGridViewTextBoxColumn typeDataGridViewTextBoxColumn;
	}
}