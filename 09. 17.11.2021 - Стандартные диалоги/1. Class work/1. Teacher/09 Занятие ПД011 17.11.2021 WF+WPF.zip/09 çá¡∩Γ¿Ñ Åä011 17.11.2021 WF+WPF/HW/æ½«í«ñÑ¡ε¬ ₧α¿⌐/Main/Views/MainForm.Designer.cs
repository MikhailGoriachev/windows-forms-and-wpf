﻿namespace Main.Views
{
	partial class MainForm
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
			this.MainGridView = new System.Windows.Forms.DataGridView();
			this.defectDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.diagonalDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.ownerDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.priceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.producerDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.repairerDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.typeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.MainGridContextMenu = new System.Windows.Forms.ContextMenuStrip(this.components);
			this.FillContextMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.OrderByProducerContextMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.OrderByDiagonalDescendingContextMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.OrderByRepairerContextMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.OrderByOwnerContextMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.SelectMinPriceContextMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.SelectRepairerContextMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.SelectDiagonalContextMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.televisionBindingSource = new System.Windows.Forms.BindingSource(this.components);
			this.MainSplitContainer = new System.Windows.Forms.SplitContainer();
			this.AddressTextBox = new System.Windows.Forms.TextBox();
			this.TitleTextBox = new System.Windows.Forms.TextBox();
			((System.ComponentModel.ISupportInitialize)(this.MainGridView)).BeginInit();
			this.MainGridContextMenu.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.televisionBindingSource)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.MainSplitContainer)).BeginInit();
			this.MainSplitContainer.Panel1.SuspendLayout();
			this.MainSplitContainer.Panel2.SuspendLayout();
			this.MainSplitContainer.SuspendLayout();
			this.SuspendLayout();
			// 
			// MainGridView
			// 
			this.MainGridView.AutoGenerateColumns = false;
			this.MainGridView.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
			dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
			dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
			dataGridViewCellStyle1.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
			dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
			dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
			dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
			dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
			this.MainGridView.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
			this.MainGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.MainGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.defectDataGridViewTextBoxColumn,
            this.diagonalDataGridViewTextBoxColumn,
            this.ownerDataGridViewTextBoxColumn,
            this.priceDataGridViewTextBoxColumn,
            this.producerDataGridViewTextBoxColumn,
            this.repairerDataGridViewTextBoxColumn,
            this.typeDataGridViewTextBoxColumn});
			this.MainGridView.ContextMenuStrip = this.MainGridContextMenu;
			this.MainGridView.DataSource = this.televisionBindingSource;
			dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
			dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
			dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
			dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
			dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
			dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
			dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
			this.MainGridView.DefaultCellStyle = dataGridViewCellStyle2;
			this.MainGridView.Dock = System.Windows.Forms.DockStyle.Fill;
			this.MainGridView.Location = new System.Drawing.Point(0, 0);
			this.MainGridView.Name = "MainGridView";
			dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
			dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
			dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
			dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
			dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
			dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
			dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
			this.MainGridView.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
			this.MainGridView.Size = new System.Drawing.Size(800, 358);
			this.MainGridView.TabIndex = 1;
			this.MainGridView.RowValidating += new System.Windows.Forms.DataGridViewCellCancelEventHandler(this.MainGridView_RowValidating);
			// 
			// defectDataGridViewTextBoxColumn
			// 
			this.defectDataGridViewTextBoxColumn.DataPropertyName = "Defect";
			this.defectDataGridViewTextBoxColumn.HeaderText = "Defect";
			this.defectDataGridViewTextBoxColumn.Name = "defectDataGridViewTextBoxColumn";
			// 
			// diagonalDataGridViewTextBoxColumn
			// 
			this.diagonalDataGridViewTextBoxColumn.DataPropertyName = "Diagonal";
			this.diagonalDataGridViewTextBoxColumn.HeaderText = "Diagonal";
			this.diagonalDataGridViewTextBoxColumn.Name = "diagonalDataGridViewTextBoxColumn";
			// 
			// ownerDataGridViewTextBoxColumn
			// 
			this.ownerDataGridViewTextBoxColumn.DataPropertyName = "Owner";
			this.ownerDataGridViewTextBoxColumn.HeaderText = "Owner";
			this.ownerDataGridViewTextBoxColumn.Name = "ownerDataGridViewTextBoxColumn";
			// 
			// priceDataGridViewTextBoxColumn
			// 
			this.priceDataGridViewTextBoxColumn.DataPropertyName = "Price";
			this.priceDataGridViewTextBoxColumn.HeaderText = "Price";
			this.priceDataGridViewTextBoxColumn.Name = "priceDataGridViewTextBoxColumn";
			// 
			// producerDataGridViewTextBoxColumn
			// 
			this.producerDataGridViewTextBoxColumn.DataPropertyName = "Producer";
			this.producerDataGridViewTextBoxColumn.HeaderText = "Producer";
			this.producerDataGridViewTextBoxColumn.Name = "producerDataGridViewTextBoxColumn";
			// 
			// repairerDataGridViewTextBoxColumn
			// 
			this.repairerDataGridViewTextBoxColumn.DataPropertyName = "Repairer";
			this.repairerDataGridViewTextBoxColumn.HeaderText = "Repairer";
			this.repairerDataGridViewTextBoxColumn.Name = "repairerDataGridViewTextBoxColumn";
			// 
			// typeDataGridViewTextBoxColumn
			// 
			this.typeDataGridViewTextBoxColumn.DataPropertyName = "Type";
			this.typeDataGridViewTextBoxColumn.HeaderText = "Type";
			this.typeDataGridViewTextBoxColumn.Name = "typeDataGridViewTextBoxColumn";
			// 
			// MainGridContextMenu
			// 
			this.MainGridContextMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.FillContextMenuItem,
            this.OrderByProducerContextMenuItem,
            this.OrderByDiagonalDescendingContextMenuItem,
            this.OrderByRepairerContextMenuItem,
            this.OrderByOwnerContextMenuItem,
            this.SelectMinPriceContextMenuItem,
            this.SelectRepairerContextMenuItem,
            this.SelectDiagonalContextMenuItem});
			this.MainGridContextMenu.Name = "contextMenuStrip1";
			this.MainGridContextMenu.Size = new System.Drawing.Size(292, 202);
			// 
			// FillContextMenuItem
			// 
			this.FillContextMenuItem.Name = "FillContextMenuItem";
			this.FillContextMenuItem.Size = new System.Drawing.Size(291, 22);
			this.FillContextMenuItem.Text = "Формирование коллекции";
			this.FillContextMenuItem.Click += new System.EventHandler(this.FillContextMenuItem_Click);
			// 
			// OrderByProducerContextMenuItem
			// 
			this.OrderByProducerContextMenuItem.Name = "OrderByProducerContextMenuItem";
			this.OrderByProducerContextMenuItem.Size = new System.Drawing.Size(291, 22);
			this.OrderByProducerContextMenuItem.Text = "Упорядочить по производителю и типу";
			this.OrderByProducerContextMenuItem.Click += new System.EventHandler(this.OrderByProducerContextMenuItem_Click);
			// 
			// OrderByDiagonalDescendingContextMenuItem
			// 
			this.OrderByDiagonalDescendingContextMenuItem.Name = "OrderByDiagonalDescendingContextMenuItem";
			this.OrderByDiagonalDescendingContextMenuItem.Size = new System.Drawing.Size(291, 22);
			this.OrderByDiagonalDescendingContextMenuItem.Text = "Упорядочить по убыванию диагонали";
			this.OrderByDiagonalDescendingContextMenuItem.Click += new System.EventHandler(this.OrderByDiagonalDescendingContextMenuItem_Click);
			// 
			// OrderByRepairerContextMenuItem
			// 
			this.OrderByRepairerContextMenuItem.Name = "OrderByRepairerContextMenuItem";
			this.OrderByRepairerContextMenuItem.Size = new System.Drawing.Size(291, 22);
			this.OrderByRepairerContextMenuItem.Text = "Упорядочить по мастер";
			this.OrderByRepairerContextMenuItem.Click += new System.EventHandler(this.OrderByRepairerContextMenuItem_Click);
			// 
			// OrderByOwnerContextMenuItem
			// 
			this.OrderByOwnerContextMenuItem.Name = "OrderByOwnerContextMenuItem";
			this.OrderByOwnerContextMenuItem.Size = new System.Drawing.Size(291, 22);
			this.OrderByOwnerContextMenuItem.Text = "Упорядочить по владельцу";
			this.OrderByOwnerContextMenuItem.Click += new System.EventHandler(this.OrderByOwnerContextMenuItem_Click);
			// 
			// SelectMinPriceContextMenuItem
			// 
			this.SelectMinPriceContextMenuItem.Name = "SelectMinPriceContextMenuItem";
			this.SelectMinPriceContextMenuItem.Size = new System.Drawing.Size(291, 22);
			this.SelectMinPriceContextMenuItem.Text = "Выборка с минимальной стоимостью";
			this.SelectMinPriceContextMenuItem.Click += new System.EventHandler(this.SelectMinPriceContextMenuItem_Click);
			// 
			// SelectRepairerContextMenuItem
			// 
			this.SelectRepairerContextMenuItem.Name = "SelectRepairerContextMenuItem";
			this.SelectRepairerContextMenuItem.Size = new System.Drawing.Size(291, 22);
			this.SelectRepairerContextMenuItem.Text = "Выборка выбранного мастера";
			this.SelectRepairerContextMenuItem.Click += new System.EventHandler(this.SelectRepairerContextMenuItem_Click);
			// 
			// SelectDiagonalContextMenuItem
			// 
			this.SelectDiagonalContextMenuItem.Name = "SelectDiagonalContextMenuItem";
			this.SelectDiagonalContextMenuItem.Size = new System.Drawing.Size(291, 22);
			this.SelectDiagonalContextMenuItem.Text = "Выборка с заданной диагональю";
			this.SelectDiagonalContextMenuItem.Click += new System.EventHandler(this.SelectDiagonalContextMenuItem_Click);
			// 
			// televisionBindingSource
			// 
			this.televisionBindingSource.DataSource = typeof(Main.Models.Television);
			// 
			// MainSplitContainer
			// 
			this.MainSplitContainer.Cursor = System.Windows.Forms.Cursors.HSplit;
			this.MainSplitContainer.Dock = System.Windows.Forms.DockStyle.Fill;
			this.MainSplitContainer.IsSplitterFixed = true;
			this.MainSplitContainer.Location = new System.Drawing.Point(0, 0);
			this.MainSplitContainer.Name = "MainSplitContainer";
			this.MainSplitContainer.Orientation = System.Windows.Forms.Orientation.Horizontal;
			// 
			// MainSplitContainer.Panel1
			// 
			this.MainSplitContainer.Panel1.Controls.Add(this.AddressTextBox);
			this.MainSplitContainer.Panel1.Controls.Add(this.TitleTextBox);
			// 
			// MainSplitContainer.Panel2
			// 
			this.MainSplitContainer.Panel2.Controls.Add(this.MainGridView);
			this.MainSplitContainer.Size = new System.Drawing.Size(800, 450);
			this.MainSplitContainer.SplitterDistance = 88;
			this.MainSplitContainer.TabIndex = 2;
			// 
			// AddressTextBox
			// 
			this.AddressTextBox.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
			this.AddressTextBox.Location = new System.Drawing.Point(473, 28);
			this.AddressTextBox.Name = "AddressTextBox";
			this.AddressTextBox.Size = new System.Drawing.Size(250, 33);
			this.AddressTextBox.TabIndex = 1;
			this.AddressTextBox.TextChanged += new System.EventHandler(this.ShopTextBox_TextChanged);
			// 
			// TitleTextBox
			// 
			this.TitleTextBox.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
			this.TitleTextBox.Location = new System.Drawing.Point(77, 28);
			this.TitleTextBox.Name = "TitleTextBox";
			this.TitleTextBox.Size = new System.Drawing.Size(250, 33);
			this.TitleTextBox.TabIndex = 0;
			this.TitleTextBox.TextChanged += new System.EventHandler(this.ShopTextBox_TextChanged);
			// 
			// MainForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(800, 450);
			this.Controls.Add(this.MainSplitContainer);
			this.Name = "MainForm";
			this.Text = "MainForm";
			((System.ComponentModel.ISupportInitialize)(this.MainGridView)).EndInit();
			this.MainGridContextMenu.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.televisionBindingSource)).EndInit();
			this.MainSplitContainer.Panel1.ResumeLayout(false);
			this.MainSplitContainer.Panel1.PerformLayout();
			this.MainSplitContainer.Panel2.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.MainSplitContainer)).EndInit();
			this.MainSplitContainer.ResumeLayout(false);
			this.ResumeLayout(false);

		}

		#endregion
		private System.Windows.Forms.DataGridView MainGridView;
		private System.Windows.Forms.DataGridViewTextBoxColumn priceDataGridViewTextBoxColumn;
		private System.Windows.Forms.DataGridViewTextBoxColumn powerDataGridViewTextBoxColumn;
		private System.Windows.Forms.DataGridViewCheckBoxColumn stateDataGridViewCheckBoxColumn;
		private System.Windows.Forms.ContextMenuStrip MainGridContextMenu;
		private System.Windows.Forms.ToolStripMenuItem FillContextMenuItem;
		private System.Windows.Forms.DataGridViewTextBoxColumn defectDataGridViewTextBoxColumn;
		private System.Windows.Forms.DataGridViewTextBoxColumn diagonalDataGridViewTextBoxColumn;
		private System.Windows.Forms.DataGridViewTextBoxColumn ownerDataGridViewTextBoxColumn;
		private System.Windows.Forms.DataGridViewTextBoxColumn producerDataGridViewTextBoxColumn;
		private System.Windows.Forms.DataGridViewTextBoxColumn repairerDataGridViewTextBoxColumn;
		private System.Windows.Forms.DataGridViewTextBoxColumn typeDataGridViewTextBoxColumn;
		private System.Windows.Forms.BindingSource televisionBindingSource;
		private System.Windows.Forms.SplitContainer MainSplitContainer;
		private System.Windows.Forms.TextBox AddressTextBox;
		private System.Windows.Forms.TextBox TitleTextBox;
		private System.Windows.Forms.ToolStripMenuItem OrderByProducerContextMenuItem;
		private System.Windows.Forms.ToolStripMenuItem OrderByDiagonalDescendingContextMenuItem;
		private System.Windows.Forms.ToolStripMenuItem OrderByRepairerContextMenuItem;
		private System.Windows.Forms.ToolStripMenuItem OrderByOwnerContextMenuItem;
		private System.Windows.Forms.ToolStripMenuItem SelectMinPriceContextMenuItem;
		private System.Windows.Forms.ToolStripMenuItem SelectRepairerContextMenuItem;
		private System.Windows.Forms.ToolStripMenuItem SelectDiagonalContextMenuItem;
	}
}