﻿using System;
using System.Windows.Forms;
using Main.Common;


namespace Main.ApplicationControl
{
	internal interface IApplicationController
	{
		T ResolveService<T>() where T : notnull;

		void Run<TPresenter>() where TPresenter : IPresenter;

		void Run<TPresenter, TArg>(TArg arg) where TPresenter : IPresenter;

		void Run<TPresenter>(Action<Form> onStartup) where TPresenter : IPresenter;
	}
}