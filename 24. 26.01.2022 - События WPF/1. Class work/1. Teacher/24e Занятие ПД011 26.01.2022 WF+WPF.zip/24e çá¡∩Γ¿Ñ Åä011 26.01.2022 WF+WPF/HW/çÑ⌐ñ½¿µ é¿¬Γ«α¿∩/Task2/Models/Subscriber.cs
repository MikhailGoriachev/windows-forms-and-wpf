﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace Task2.Models
{
    // Класс подписчиков, необходимо хранить
    // *фамилию и инициалы подписчика,
    // *его адрес (улицу, дом и квартиру),
    // *название издания,
    // *тип издания,
    // *индекс издания,
    // *дату начала подписки
    // *период подписки
    public class Subscriber : DependencyObject
    {
        // максимальный период подписки
        public const int MaxPeriod = 12;

        // свойство зависимости - ФИО подписчика
        public static readonly DependencyProperty FullNameProperty;
        public string FullName
        {
            get => (string)GetValue(FullNameProperty);
            set => SetValue(FullNameProperty, value);
        }// FullName

        // свойство зависимости - адрес (улица, дом и квартира) подписчика
        public static readonly DependencyProperty AddressProperty;
        public string Address
        {
            get => (string)GetValue(AddressProperty);
            set => SetValue(AddressProperty, value);
        }// Address


        // свойство зависимости - название издания
        public static readonly DependencyProperty TitlePublicationProperty;
        public string TitlePublication
        {
            get => (string)GetValue(TitlePublicationProperty);
            set => SetValue(TitlePublicationProperty, value);
        }// TitlePublication


        // свойство зависимости - тип издания
        public static readonly DependencyProperty TypePublicationProperty;
        public string TypePublication
        {
            get => (string)GetValue(TypePublicationProperty);
            set => SetValue(TypePublicationProperty, value);
        }// TypePublication


        // свойство зависимости - индекс издания
        public static readonly DependencyProperty IndexPublicationProperty;
        public string IndexPublication
        {
            get => (string)GetValue(IndexPublicationProperty);
            set => SetValue(IndexPublicationProperty, value);
        }// IndexPublication


        // свойство зависимости - дату начала подписки
        public static readonly DependencyProperty StartDateSubscrProperty;
        public DateTime StartDateSubscription
        {
            get => (DateTime)GetValue(StartDateSubscrProperty);
            set => SetValue(StartDateSubscrProperty, value);
        }// StartDateSubscription


        // свойство зависимости - период подписки
        public static readonly DependencyProperty PeriodSubscrProperty;
        public int PeriodSubscription
        {
            get => (int)GetValue(PeriodSubscrProperty);
            set => SetValue(PeriodSubscrProperty, value);
        }// PeriodSubscription

        /*
        // конструкторы объекта класса
        public Subscriber() : this("Петров В.В.", "ул.Кирова д.27,кв.54",
            "Караван историй", "журнал", "Э83877", new DateTime(2022, 01, 12), 3)
        { }

        public Subscriber(string fullName, string address, string namePub,
            string typePub, string index, DateTime startdate, int period)
        {
            FullName = fullName;
            Address = address;
            TitlePublication = namePub;
            TypePublication = typePub;
            IndexPublication = index;
            StartDateSubscription = startdate;
            PeriodSubscription = period;
        }// Subscriber
        */

        // статический конструктор для реализации статической части свойств зависимостей 
        // т.е. это регистрация хранилища значений свойств 
        static Subscriber()
        {
            FullNameProperty = DependencyProperty.Register(
             "FullName", typeof(string), typeof(Subscriber));

            AddressProperty = DependencyProperty.Register(
                "Address", typeof(string), typeof(Subscriber));

            TitlePublicationProperty = DependencyProperty.Register(
                "TitlePublication", typeof(string), typeof(Subscriber));

            TypePublicationProperty = DependencyProperty.Register(
                "TypePublication", typeof(string), typeof(Subscriber));

            IndexPublicationProperty = DependencyProperty.Register(
                "IndexPublication", typeof(string), typeof(Subscriber));

            StartDateSubscrProperty = DependencyProperty.Register(
                "StartDateSubscription", typeof(DateTime), typeof(Subscriber));

            // регистрация делегата для корректирующей валидации
            FrameworkPropertyMetadata metadata = new FrameworkPropertyMetadata { CoerceValueCallback = CorrectPeriod };

            PeriodSubscrProperty = DependencyProperty.Register(
                "PeriodSubscription", typeof(int), typeof(Subscriber), metadata);

        }// Subscriber

        // ---------------------- корректирующие валидаторы ---------------------------------

        // Корректирующая валидация - делегат CoerceValueCallback для периода подписки
        private static object CorrectPeriod(DependencyObject d, object baseValue)
        {
            // получить новое значение периода подписки - то, что будет записано
            int currentValue = (int)baseValue;

            if (currentValue <= 0) currentValue = 0;

            // допустимый период подписки 
            else if (currentValue > MaxPeriod) currentValue = MaxPeriod;

            return currentValue;
        } // CorrectPeriod



    }// class Subscriber 
}
