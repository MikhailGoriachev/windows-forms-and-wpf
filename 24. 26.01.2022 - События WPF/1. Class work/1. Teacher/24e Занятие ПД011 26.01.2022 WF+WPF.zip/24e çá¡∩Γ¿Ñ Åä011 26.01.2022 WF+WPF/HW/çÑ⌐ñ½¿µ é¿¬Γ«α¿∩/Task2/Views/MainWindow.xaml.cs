﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Task2.Controllers;
using Task2.Models;

namespace Task2.Views
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private PostOfficeController _officeController;

        public MainWindow(): this(new PostOfficeController()) { }
        public MainWindow(PostOfficeController postOfficeController)
        {
            InitializeComponent();

            _officeController = postOfficeController;

            // привязка данных DataGrid
            DgSubscriber.ItemsSource = _officeController.OfficeController.Subscribers;

            // обновить строку состояния
            TbStatusBar.Text = $"Подписок на периодические издания: {_officeController.OfficeController.Count}";
        }// MainWindow

        // Завершение приложения - команда меню
        private void Exit_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        } // Exit_Click


        // Открыть окно со сведениями о приложении и разработчике
        private void About_Click(object sender, RoutedEventArgs e) =>
            new AboutWindow().ShowDialog();

        // удаление подписки
        private void RemoveAtPublication_Click(object sender, RoutedEventArgs e)
        {
            TbcMain.SelectedItem = TbcPostOffice;

            if (DgSubscriber.SelectedIndex == -1) return;

            // индекс выбранного элемента
            int selected = DgSubscriber.SelectedIndex;

            // удаление записи данных 
           _officeController.OfficeController.RemoveAt(selected);

            // обновить строку состояния
            TbStatusBar.Text = $"Подписок на периодические издания: {_officeController.OfficeController.Count}";
        }// RemoveAtPublication_Click

        #region Сортировка коллекции
        // сортировка копии коллекции по индексу издания
        private void OrderByIndex_Click(object sender, RoutedEventArgs e)
        {
            TbcMain.SelectedItem = TbcOrderBy;
            DgOrderBy.ItemsSource = _officeController.OrderByIndex();

            // обновить строку состояния
            TbStatusBar.Text = $"Подписки отсортированы по индексу издания: {_officeController.OfficeController.Count}";
        }// OrderByIndex_Click
        #endregion

        #region Выборка

        // подписки по выбранному типу издания
        private void SelectTypePubl_Click(object sender, RoutedEventArgs e)
        {
            TbcMain.SelectedItem = TbcSelected;
            // Создание формы выбора типа издания
            ChoiceWindow choiceWindow = new ChoiceWindow(_officeController.OfficeController.GetTypePublList,
                "Выбор типа издания", "Выберите тип издания:");

            if (choiceWindow.ShowDialog() == false) return;

            DgSelected.ItemsSource = _officeController.SelectWhereTypePubl(choiceWindow.Choosen);

            // обновить строку состояния
            TbStatusBar.Text = $"Подписки по выбранному типу издания.";
        }// SelectTypePubl_Click

        #endregion


    }// class MainWindow
}
