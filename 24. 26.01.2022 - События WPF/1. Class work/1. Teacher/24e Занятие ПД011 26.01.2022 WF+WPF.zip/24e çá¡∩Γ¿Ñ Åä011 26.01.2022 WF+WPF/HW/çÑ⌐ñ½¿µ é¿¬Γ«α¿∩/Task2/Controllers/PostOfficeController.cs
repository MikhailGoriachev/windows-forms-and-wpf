﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Task2.Models;

namespace Task2.Controllers
{
    public class PostOfficeController
    {
        // объект для обработки
        private PostOffice _postOffice;
        public PostOffice OfficeController => _postOffice;

        public PostOfficeController() : this(new PostOffice()) { }

        public PostOfficeController(PostOffice postOffice)
        {
            _postOffice = postOffice;
        }


        // получить копию данных о подписках
        public ObservableCollection<Subscriber> SubscriberCopy() =>
            new ObservableCollection<Subscriber>(_postOffice.Subscribers);

        // Запрос на получение упорядоченной копии коллекции по индексу издания
        public List<Subscriber> OrderByIndex() => OfficeController.OrderBy(s => s.IndexPublication);


        // Получить список типов издания, для коллекции
        public List<string> GetTypePubl => _postOffice.GetTypePublList;

        // Запрос на выборку подписок по выбранному типу издания
        public List<Subscriber> SelectWhereTypePubl(string type) =>
            _postOffice.Filter(t => t.TypePublication == type);

    }// class PostOfficeController
}
