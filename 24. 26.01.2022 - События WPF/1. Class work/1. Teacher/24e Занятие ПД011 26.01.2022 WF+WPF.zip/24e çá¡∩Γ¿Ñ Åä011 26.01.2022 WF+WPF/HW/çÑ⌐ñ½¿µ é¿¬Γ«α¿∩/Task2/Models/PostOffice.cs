﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Task2.Models
{
    // Класс почтовое отделение
    public class PostOffice
    {
        // коллекция данных
        private ObservableCollection<Subscriber> _subscribers;
        public ObservableCollection<Subscriber> Subscribers => _subscribers;

        public PostOffice() : this(new ObservableCollection<Subscriber>()) {
            Initialize();
        }

        public PostOffice(ObservableCollection<Subscriber> subscribers)
        {
            _subscribers = subscribers;
        }// PostOffice


        // формирование коллекции 
        public void Initialize(int n = 12)
        {
            _subscribers.Clear();

            for (int i = 0; i < n; i++)
            {
                _subscribers.Add(Generate());
            } // for i
        } // Initialize

        public int Count => _subscribers.Count;

        public Subscriber this[int index]
        {
            get
            {
                if (index < 0 || index >= Count)
                    throw new IndexOutOfRangeException("Попытка доступа к элементу вне диапазона");
                return _subscribers[index];
            }
            set
            {
                if (index < 0 || index >= Count)
                    throw new IndexOutOfRangeException("Попытка доступа к элементу вне диапазона");

                _subscribers[index] = value;
            }
        }// indexer

        // добавление подписки в коллекцию
        public void AddSubscriber(Subscriber subscriber) => _subscribers.Add(subscriber);

        // удаление выбранной подписки
        public void RemoveAt(int index) => _subscribers.RemoveAt(index);

        // упорядочивание копии коллекции по заданному компаратору
        public List<Subscriber> OrderBy<Tkey>(Func<Subscriber, Tkey> selector) =>
            new List<Subscriber>(_subscribers.OrderBy(selector));


        // выборка данных из коллекции по заданному предикату
        public List<Subscriber> Filter(Predicate<Subscriber> predicate) =>
            new List<Subscriber>(_subscribers.Where(x => predicate(x)));

        // Получить список типов издания
        public List<string> GetTypePublList => _subscribers.Select(subscribe => subscribe.TypePublication).Distinct().ToList();

        // фабричный метод для создания подписчика
        public static Subscriber Generate()
        {
            // индексы из массивов данных для создания подписчика
            int indexFullName = Utils.Random.Next(0, Utils.FullNames.Length - 1);
            int indexAdress = Utils.Random.Next(0, Utils.Address.Length - 1);
            int indexPublication = Utils.Random.Next(0, Utils.Publications.Length - 1);
            int indexIndex = Utils.Random.Next(0, Utils.Index.Length - 1);
            int period = Utils.Random.Next(0, 3);

            return new Subscriber {
                FullName = Utils.FullNames[indexFullName],
                Address = Utils.Address[indexAdress],
                TitlePublication = Utils.Publications[indexPublication].titlePubl,
                TypePublication = Utils.Publications[indexPublication].typePubl,
                IndexPublication = Utils.Index[indexIndex],
                StartDateSubscription = new DateTime(Utils.Random.Next(2020, 2021), Utils.Random.Next(1, 12), Utils.Random.Next(1, 28)),
                PeriodSubscription = period == 0 ? 1 : period == 1 ? 3 : period == 2 ? 6 : period == 3 ? 12 : 0
            };

            }// Generate


    }// class PostOffice
}
