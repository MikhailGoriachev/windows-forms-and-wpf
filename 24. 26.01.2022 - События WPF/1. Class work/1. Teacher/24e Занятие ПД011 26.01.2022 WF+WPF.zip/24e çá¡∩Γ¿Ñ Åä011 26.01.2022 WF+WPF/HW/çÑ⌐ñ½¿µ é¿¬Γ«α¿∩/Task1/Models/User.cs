﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace Task1.Models
{
    // Kласс с использованием свойств зависимости для представления данных сотрудника:
    // *фамилия, имя, отчество,
    // *возраст,
    // *оклад,
    // *город проживания.
    // Используйте корректирующие валидаторы
    // *для возраста (от 0 до 190),
    // *оклада (от 0 до 1 000 000).
    public class User: DependencyObject
    {
        public const int MaxAge = 190;
        public const double MaxSalary = 1_000_000d;

        // свойство зависимости - фамилия персоны
        public static readonly DependencyProperty FullNameProperty;
        public string FullName
        {
            get => (string)GetValue(FullNameProperty);
            set => SetValue(FullNameProperty, value);
        }// FullName


        // свойство зависимости - возраст персоны
        public static readonly DependencyProperty AgeProperty;
        public int Age
        {
            get => (int)GetValue(AgeProperty);
            set => SetValue(AgeProperty, value);
        }  // Age

        // свойство зависимости - оклад персоны
        public static readonly DependencyProperty SalaryProperty;
        public double Salary
        {
            get => (double)GetValue(SalaryProperty);
            set => SetValue(SalaryProperty, value);
        }// Salary

        // свойство зависимости - городa проживания персоны
        public static readonly DependencyProperty CityProperty;
        public string City
        {
            get => (string)GetValue(CityProperty);
            set => SetValue(CityProperty, value);
        }// City

        // конструкторы объекта класса
        public User() : this("Петров С.В.", 33, 16000d, "Макеевка") { }
        public User(string fullname, int age, double salary, string city)
        {
            FullName = fullname;
            Age = age;
            Salary = salary;
            City = city;
        }// User

        // статический конструктор для реализации статической части свойств зависимостей 
        // т.е. это регистрация хранилища значений свойств 
        static User()
        {
            // регистрация свойства в хранилище методом Register()
            // 1-й параметр метода - имя свойства
            // 2-й параметр метода - тип свойства
            // 3-й параметр метода - тип владельца свойства, т.е. имя нашего класса
            FullNameProperty = DependencyProperty.Register(
                "FullName", typeof(string), typeof(User));

            // регистрация делегата для корректирующей валидации
            FrameworkPropertyMetadata metadata = new FrameworkPropertyMetadata { CoerceValueCallback = CorrectAge };

            // или в полном варианте:
            // metadata.CoerceValueCallback = new CoerceValueCallback(CorrectAge);
            AgeProperty = DependencyProperty.Register("Age", typeof(int), typeof(User),
                metadata);

            // регистрация делегата для корректирующей валидации
            metadata = new FrameworkPropertyMetadata { CoerceValueCallback = CorrectSalary };

            SalaryProperty = DependencyProperty.Register("Salary", typeof(double), typeof(User),
                metadata);

            CityProperty = DependencyProperty.Register(
                "City", typeof(string), typeof(User));
        }// User


        // ---------------------- корректирующие валидаторы ---------------------------------

        // Корректирующая валидация - делегат CoerceValueCallback для возраста персоны
        private static object CorrectAge(DependencyObject d, object baseValue)
        {
            // получить новое значение возраста - то, что будет записано
            int currentValue = (int)baseValue;

            if (currentValue <= 0) currentValue = 0;

            // допустимый возраст 
            else if (currentValue > MaxAge) currentValue = MaxAge;

            return currentValue;
        } // CorrectAge


        // Корректирующая валидация - делегат CoerceValueCallback для оклада персоны
        private static object CorrectSalary(DependencyObject d, object baseValue)
        {
            // получить новое значение оклада - то, что будет записано
            double currentValue = (double)baseValue;

            if (currentValue <= 0) currentValue = 0;

            // допустимый оклад
            else if (currentValue > MaxSalary) currentValue = MaxSalary;

            return currentValue;
        }// CorrectSalary


        public override string ToString() => $"{FullName} , г.{City}, {Age}лет, оклад: {Salary}рубл.";

    }// class User
}
