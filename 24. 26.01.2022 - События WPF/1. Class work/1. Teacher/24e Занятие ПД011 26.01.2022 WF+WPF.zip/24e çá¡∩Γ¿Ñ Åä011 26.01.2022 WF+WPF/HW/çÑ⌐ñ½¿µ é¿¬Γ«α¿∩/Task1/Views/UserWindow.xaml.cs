﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Task1.Models;

namespace Task1.Views
{
    /// <summary>
    /// Логика взаимодействия для UserWindow.xaml
    /// </summary>
    public partial class UserWindow : Window
    {
        // объект данных
        private User _users;
        public User User
        {
            get => _users;
            set
            {
                _users = value;

                TxbFullName.Text = _users.FullName;
                TxbAge.Text = $"{_users.Age}";
                TxbSalary.Text = $"{_users.Salary}";
                TxbCity.Text = _users.City;
            }
        }

        public UserWindow()
        {
            InitializeComponent();
            // получить ссылку на ресурс
            _users = (User)Resources["Users"];

            _users.FullName = TxbFullName.Text;
            _users.Age = int.Parse(TxbAge.Text);
            _users.Salary = double.Parse(TxbSalary.Text);
            _users.City = TxbCity.Text;
            _users = new User();
        }// UserWindow


        public UserWindow(User user)
        {
            InitializeComponent();
            _users = (User)Resources["Users"];

            // загружаем свойства из передаваемого объекта
            _users.FullName = user.FullName;
            _users.Age = user.Age;
            _users.Salary = user.Salary;
            _users.City = user.City;
        }// UserWindow

        public UserWindow(string windowTitle, string btnTitle)
        {
            InitializeComponent();

            // Заголовок формы
            Title = windowTitle;
            BtnOk.Content = btnTitle;

            _users = (User)Resources["Users"];
            _users = new User();
            // загружаем свойства из передаваемого объекта
            //_users.FullName = user.FullName;
            //_users.Age = user.Age;
            // _users.Salary = user.Salary;
            //_users.City = user.City;
        }// UserWindow


        private void BtnOk_Click(object sender, RoutedEventArgs e)
        {

            _users = new User()
            {
                FullName = TxbFullName.Text,
                Age = int.Parse(TxbAge.Text),
                Salary = double.Parse(TxbSalary.Text),
                City = TxbCity.Text
            };

            DialogResult = true;
        }// BtnOk_Click

    }// class UserWindow
}
