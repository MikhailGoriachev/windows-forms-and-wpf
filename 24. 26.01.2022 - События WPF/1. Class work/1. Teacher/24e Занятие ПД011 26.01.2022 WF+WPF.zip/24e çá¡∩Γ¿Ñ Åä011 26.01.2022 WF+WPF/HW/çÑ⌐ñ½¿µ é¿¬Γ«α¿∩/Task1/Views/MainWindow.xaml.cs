﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Task1.Models;
using System.Collections;
using System.Collections.ObjectModel;
using System.ComponentModel;

namespace Task1.Views
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private Office _ofic;

        public MainWindow(): this(new Office())
        {
            InitializeComponent();
        }


        public MainWindow(Office users)
        {
            InitializeComponent();

            _ofic = users;

            DgUser.ItemsSource = _ofic.Users;
            // сортировка заданного столбца 
            DgUser.Items.SortDescriptions.Add(new SortDescription("FullName", ListSortDirection.Ascending));

        }//  MainWindow


        // Завершение приложения - команда меню
        private void Exit_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        } // Exit_Click


        // Открыть окно со сведениями о приложении и разработчике
        private void About_Click(object sender, RoutedEventArgs e) =>
            new AboutWindow().ShowDialog();

        // Редактировать данные о персоне
        private void EditUser_Click(object sender, RoutedEventArgs e)
        {
            // индекс выбранного элемента
            int selected = DgUser.SelectedIndex;
            if (selected == -1) return;

            // передача данных в форму
            UserWindow userWindow = new UserWindow("Редактировать данные о персоне", "Сохранить")
            {
                User = _ofic.Users[selected]
            };

            if (userWindow.ShowDialog() == false) return;

            // редактировать данные персоны 
            _ofic.Users[selected] = userWindow.User;

            // остановить привязку
            DgUser.ItemsSource = null;
            DgUser.ItemsSource = _ofic.Users;
        }// EditUser_Click


        // добавление персоны
        private void AddUser_Click(object sender, RoutedEventArgs e)
        {
            // создать окно для ввода данных персоны
            UserWindow userWindow = new UserWindow();

            if (userWindow.ShowDialog() == false) return;

            // добавить персону в коллекцию 
            _ofic.AddUser(userWindow.User);

            // остановить привязку
            DgUser.ItemsSource = null;
            DgUser.ItemsSource = _ofic.Users;
        }// AddUser_Click


        // удаление персоны
        private void RemoveAt_Click(object sender, RoutedEventArgs e)
        {
            if (DgUser.SelectedIndex == -1) return;

            // индекс выбранного элемента
            int selected = DgUser.SelectedIndex;

            // удаление записи данных 
            _ofic.RemoveAt(selected);

            // остановить привязку
            DgUser.ItemsSource = null;
            DgUser.ItemsSource = _ofic.Users;
        }// RemoveAt_Click



    }// class MainWindow
}
