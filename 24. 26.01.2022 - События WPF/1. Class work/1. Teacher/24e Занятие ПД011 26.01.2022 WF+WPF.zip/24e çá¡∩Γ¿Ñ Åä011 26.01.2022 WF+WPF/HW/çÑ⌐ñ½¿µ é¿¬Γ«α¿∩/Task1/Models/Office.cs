﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task1.Models
{
    public class Office
    {
        // ссылка на коллекцию персон
        private List<User> _users;
        public List<User> Users
        {
            get => _users;
            private set => _users = value;
        }


        public Office() : this( new List<User>())
        {
            Inizialize();
        }

        public Office(List<User> users)
        {
            _users = users;
        }

        // количестово персон в коллекции
        public int Count => _users.Count;

        public void Inizialize()
        {
            _users.Clear();

            _users = new List<User>(new[] {
                  new User{FullName = "Егорова Т.В.",       Age = 55, Salary = 74400.25, City = "Донецк"},
                  new User{FullName = "Николаева Е.В.",     Age = 75, Salary = 56893.35, City = "Горловка"},
                  new User{FullName = "Вольгогорский Т.Л.", Age = 59, Salary = 34683.75, City = "Донецк"},
                  new User{FullName = "Смирнова М.В.",      Age = 25, Salary = 86327.85, City = "Макеевка"},
                  new User{FullName = "Павлов Т.Р.",        Age = 54, Salary = 38854.25, City = "Донецк"},
                  new User{FullName = "Гончарова А.В.",     Age = 87, Salary = 86327.45, City = "Енакиево"},
                  new User{FullName = "Рыбакова Т.С.",      Age = 39, Salary = 88427.25, City = "Донецк"},
                  new User{FullName = "Свиридов Н.В.",      Age = 28, Salary = 86337.75, City = "Горловка"},
                  new User{FullName = "Семёнова Т.Д.",      Age = 75, Salary = 24878.35, City = "Макеевка"},
                  new User{FullName = "Васютина Е.В.",      Age = 58, Salary = 74437.15, City = "Донецк"}
            });

        }// Inizialize


        // добавление персоны в коллекцию
        public void AddUser(User user) => _users.Add(user);


        // удаление выбранной персоны
        public void RemoveAt(int index) => _users.RemoveAt(index);


    }// class Office
}
