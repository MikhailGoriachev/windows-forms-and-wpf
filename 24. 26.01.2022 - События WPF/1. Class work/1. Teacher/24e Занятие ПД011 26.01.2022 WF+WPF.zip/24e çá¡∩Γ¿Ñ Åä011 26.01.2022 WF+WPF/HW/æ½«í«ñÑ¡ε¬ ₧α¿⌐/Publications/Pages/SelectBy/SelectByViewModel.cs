﻿using System.Collections.Generic;
using System.Linq;
using Stylet;


namespace Publications.Pages.SelectBy
{
	public sealed record SelectByDto<TSelectable>(string Description, ICollection<TSelectable> Selectables);


	public sealed class SelectByViewModel<TSelectable> : Screen
	{
		public string Title { get; }
		public ICollection<TSelectable> SelectableItems { get; }
		public TSelectable SelectedItem { get; init; }


		public SelectByViewModel(SelectByDto<TSelectable> selectByDto)
		{
			var (description, selectables) = selectByDto;

			Title           = description;
			SelectableItems = selectables;
			SelectedItem    = SelectableItems.First();
		}


		public void Accept() => RequestClose(dialogResult: true);
	}
}