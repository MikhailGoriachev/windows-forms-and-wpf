﻿using System;
using FluentValidation;
using Publications.Models;


namespace Publications.Validators
{
	public static class PublicationValidatorExtensions
	{
		public static void SubscriberRule<T>(this IRuleBuilder<T, string?> builder) =>
			builder.NotEmpty()
				   .WithMessage("Подписчик должен быть");


		public static void AddressStreetRule<T>(this IRuleBuilder<T, string?> builder) =>
			builder.NotEmpty()
				   .WithMessage("Улица должна быть");


		public static void AddressHouseRule<T>(this IRuleBuilder<T, string?> builder) =>
			builder.NotEmpty()
				   .WithMessage("Дом должен быть");


		public static void AddressFlatRule<T>(this IRuleBuilder<T, string?> builder) =>
			builder.NotEmpty()
				   .WithMessage("Квартира должна быть");


		public static void TitleRule<T>(this IRuleBuilder<T, string?> builder) =>
			builder.NotEmpty()
				   .WithMessage("Название должно быть");


		public static void TypeRule<T>(this IRuleBuilder<T, string?> builder) =>
			builder.NotEmpty()
				   .WithMessage("Тип издания должен быть");


		public static void IndexRule<T>(this IRuleBuilder<T, string?> builder) =>
			builder.NotEmpty()
				   .WithMessage("Индекс издания должен быть");


		public static void SubscriptionStartRule<T>(this IRuleBuilder<T, DateTime> builder) =>
			builder.NotEmpty()
				   .WithMessage("Дата начала подписки должна быть");


		public static void SubscriptionDurationRule<T>(this IRuleBuilder<T, int> builder) =>
			builder.Must(i => Subscription.Durations.Contains(i))
				   .WithMessage($"Допустимая длительность подписки: {string.Join(", ", Subscription.Durations)}");
	}
}