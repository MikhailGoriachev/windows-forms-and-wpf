﻿using System;
using System.Collections.Generic;
using Publications.Infrastructure;
using Publications.Models;
using Publications.Pages.SelectionTab;
using Stylet;


namespace Publications.Pages.SelectBy
{
	public sealed class SelectByRunner<TSelectable>
	{
		private readonly TabScreen _ownerTabScreen;
		private readonly IWindowManager _windowManager;


		public SelectByRunner(TabScreen ownerTabScreen, IWindowManager windowManager)
		{
			_ownerTabScreen = ownerTabScreen;
			_windowManager  = windowManager;
		}


		public void SelectBy(SelectByDto<TSelectable> selectInfo,
							 Func<TSelectable, IEnumerable<Publication>> obtainSelected)
		{
			if (TrySelectWithDialog(selectInfo, out var selectByViewModel) == false)
				return;

			var selected = selectByViewModel.SelectedItem;
			var selectedPublications = obtainSelected.Invoke(selected);

			OpenSelectionTab(selectByViewModel.Title, selected, selectedPublications);
		}


		private bool TrySelectWithDialog(SelectByDto<TSelectable> selectByDto,
										 out SelectByViewModel<TSelectable> selectByViewModel)
		{
			selectByViewModel = new(selectByDto);

			var dialogResult = _windowManager.ShowDialog(selectByViewModel);

			return dialogResult == true;
		}


		private void OpenSelectionTab(string selectDescription,
									  TSelectable selectedItem,
									  IEnumerable<Publication> selected)
		{
			var bindableSelectedItems = new BindableCollection<Publication>(selected);

			var selectedViewModel = new SelectionTabViewModel(
				$"{selectDescription} \"{selectedItem}\"", bindableSelectedItems);

			_ownerTabScreen.ActivateOtherTab(selectedViewModel);
		}
	}
}