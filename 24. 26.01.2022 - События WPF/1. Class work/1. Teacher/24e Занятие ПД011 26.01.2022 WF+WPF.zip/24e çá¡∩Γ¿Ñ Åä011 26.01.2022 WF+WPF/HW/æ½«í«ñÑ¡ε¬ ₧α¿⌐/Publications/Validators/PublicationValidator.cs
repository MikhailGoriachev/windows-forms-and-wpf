﻿using FluentValidation;
using Publications.Models;


namespace Publications.Validators
{
	public sealed class PublicationValidator : AbstractValidator<Publication>
	{
		public PublicationValidator()
		{
			RuleFor(model => model.Subscriber)
				.SubscriberRule();

			RuleFor(model => model.Address.Street)
				.AddressStreetRule();

			RuleFor(model => model.Address.House)
				.AddressHouseRule();

			RuleFor(model => model.Address.Flat)
				.AddressFlatRule();

			RuleFor(model => model.Title)
				.TitleRule();

			RuleFor(model => model.Type)
				.TypeRule();

			RuleFor(model => model.Index)
				.IndexRule();

			RuleFor(model => model.Subscription.Start)
				.SubscriptionStartRule();

			RuleFor(model => model.Subscription.Duration)
				.SubscriptionDurationRule();
		}
	}
}