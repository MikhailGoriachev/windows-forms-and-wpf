﻿using Publications.Infrastructure;
using Publications.Pages.Shell;
using Stylet;
using StyletIoC;


namespace Publications
{
	public sealed class Bootstrapper : Bootstrapper<ShellViewModel>
	{
		protected override void ConfigureIoC(IStyletIoCBuilder builder) =>
			builder.Bind<IViewManager>().To<ViewManagerSupportGenericViewModels>();
	}
}