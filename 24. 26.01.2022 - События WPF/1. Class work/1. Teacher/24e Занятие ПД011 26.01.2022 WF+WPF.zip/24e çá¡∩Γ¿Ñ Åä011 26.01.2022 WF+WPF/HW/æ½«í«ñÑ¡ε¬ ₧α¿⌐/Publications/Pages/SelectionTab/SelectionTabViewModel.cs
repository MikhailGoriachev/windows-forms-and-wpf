﻿using Publications.Infrastructure;
using Publications.Models;
using Stylet;


namespace Publications.Pages.SelectionTab
{
	public sealed class SelectionTabViewModel : TabScreen
	{
		public BindableCollection<Publication> Publications { get; }


		public SelectionTabViewModel(string title, BindableCollection<Publication> publications) : base(title)
		{
			Publications = publications;
		}
	}
}