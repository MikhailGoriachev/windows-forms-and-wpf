﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Windows.Markup;
using Publications.Infrastructure;
using Publications.Models;
using Publications.Validators;
using Stylet;


namespace Publications.Pages.PublicationInput
{
	


	public sealed class PublicationViewModel : Screen
	{
		public static XmlLanguage DatePickerLanguage =>
			XmlLanguage.GetLanguage(CultureInfo.CurrentCulture.IetfLanguageTag);

		public string? Header { get; private set; }


		public Publication? Result { get; private set; }

		public string? Subscriber { get; set; }
		public string? Street { get; set; }
		public string? House { get; set; }
		public string? Flat { get; set; }
		public string? Title { get; set; }
		public string? Type { get; set; }
		public string? Index { get; set; }
		public DateTime Start { get; set; } = DateTime.UtcNow;
		public int Duration { get; set; } = PossibleDurations.First();

		public static ICollection<int> PossibleDurations => Subscription.Durations;

		public bool CanAccept => !HasErrors;


		public PublicationViewModel() =>
			InitializeWith("Добавление новой подписки");


		public PublicationViewModel(Publication itemToEdit) =>
			InitializeWith("Изменение сущестующей подписки", itemToEdit);


		public void Accept()
		{
			if (Validate() == false)
				return;

			Result = new()
			{
				Title = Title,
				Subscription = new()
				{
					Duration = Duration,
					Start    = Start
				},
				Address = new()
				{
					Flat   = Flat,
					House  = House,
					Street = Street
				},
				Index      = Index,
				Subscriber = Subscriber,
				Type       = Type
			};
			RequestClose(true);
		}


		private void InitializeWith(string header, Publication? item = null)
		{
			Header = header;
			if (item is not null)
				FillPropertiesFromExistingItem(item);

			Validator = new FluentValidationAdapter<PublicationViewModel>(new PublicationViewModelValidator());
			Validate();
		}


		private void FillPropertiesFromExistingItem(Publication item)
		{
			Title      = item.Title;
			Subscriber = item.Subscriber;
			Type       = item.Type;
			Index      = item.Index;

			Flat   = item.Address.Flat;
			House  = item.Address.House;
			Street = item.Address.Street;

			Start    = item.Subscription.Start;
			Duration = item.Subscription.Duration;
		}


		protected override void OnValidationStateChanged(IEnumerable<string> changedProperties)
		{
			base.OnValidationStateChanged(changedProperties);

			NotifyOfPropertyChange(() => CanAccept);
		}
	}
}