﻿using FluentValidation.Results;


namespace Publications.Infrastructure
{
	public sealed record CollectionValidationResult<T>(T Item, int Index, ValidationResult ValidationResult);
}