﻿using System.Collections.Generic;
using System.IO;
using System.Linq;
using Newtonsoft.Json;


namespace Publications.Models
{
	internal sealed class JsonRepository<T> where T : class
	{
		private readonly JsonSerializer _serializer = new()
		{
			Formatting = Formatting.Indented,
			DateFormatString = "d"
		};
		private readonly string _path;


		public JsonRepository(string path) => _path = path;


		public void Save(T value)
		{
			using var writer = OpenWriter();
			_serializer.Serialize(writer, value);
		}


		public void SaveRange(IEnumerable<T> values)
		{
			using var writer = OpenWriter();
			_serializer.Serialize(writer, values);
		}


		public T? Load()
		{
			using var reader = OpenReader();

			var items = _serializer.Deserialize<T>(reader);

			return items ?? default;
		}


		public IReadOnlyList<T> LoadRange()
		{
			using var reader = OpenReader();

			var items = _serializer.Deserialize<List<T>>(reader);

			return items ?? Enumerable.Empty<T>().ToList();
		}


		public void Clear() => File.Delete(_path);


		private JsonTextWriter OpenWriter() => new(File.CreateText(_path));

		private JsonTextReader OpenReader() => new(File.OpenText(_path));
	}
}