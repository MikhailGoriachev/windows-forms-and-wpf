﻿using System;
using System.ComponentModel;


namespace Publications.Models
{
	public sealed class Address : INotifyPropertyChanged, ICloneable
	{
		public string? Street { get; set; }
		public string? House { get; set; }
		public string? Flat { get; set; }

		public string FullAddress => $"{Street}, {House}, {Flat}";


		public event PropertyChangedEventHandler? PropertyChanged;


		public object Clone() => new Address
		{
			Street = (string)Street.Clone(),
			House  = (string)House.Clone(),
			Flat   = (string)Flat.Clone()
		};
	}
}