﻿using Publications.Infrastructure;
using Publications.Pages.MainTab;
using Stylet;


namespace Publications.Pages.Shell
{
	public sealed class ShellViewModel : Conductor<Screen>.Collection.OneActive, IShell
	{
		private readonly MainTabViewModel _mainTab;


		public ShellViewModel(MainTabViewModel mainTab)
		{
			_mainTab = mainTab;
			RestoreMainTab();
		}


		public void RestoreMainTab()
		{
			ActivateItem(_mainTab);
		}


		public void RemoveTab()
		{
			base.CloseItem(ActiveItem);
		}
	}
}