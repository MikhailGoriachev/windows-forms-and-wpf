﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using Microsoft.Win32;
using Publications.Infrastructure;
using Publications.Models;
using Publications.Pages.PublicationInput;
using Publications.Pages.SelectBy;
using Publications.Validators;
using Stylet;


namespace Publications.Pages.MainTab
{
	public class MainTabViewModel : TabScreen
	{
		private readonly IWindowManager _windowManager;

		public BindableCollection<Publication> Publications { get; } = new();
		public IList? SelectedPublications { get; set; }

		public int SelectedIndex { get; set; }

		public bool CanEdit => SelectedPublications is not null && SelectedPublications.Count == 1;
		public bool CanRemove => SelectedPublications is not null && SelectedPublications.Count > 0;
		public bool CanClear => CanSelect;

		private bool CanSelect { get; set; }
		public bool CanSelectByType => CanSelect;
		public bool CanSelectByDuration => CanSelect;
		public bool CanSelectBySubscriber => CanSelect;
		public bool CanSelectByTitle => CanSelect;
		public bool CanSave => CanSelect;


		public MainTabViewModel(IWindowManager windowManager) : base("Главная вкладка")
		{
			_windowManager = windowManager;

			Publications.CollectionChanged += PublicationsOnCollectionChanged;
		}


		public void Fill()
		{
			Publications.Clear();

			var size = new Random().Next(12, 16);

			var maked = new PublicationFactory().Make(size);

			Publications.AddRange(maked);
		}


		public void Add()
		{
			var publicationViewModel = new PublicationViewModel();

			var result = _windowManager.ShowDialog(publicationViewModel);

			if (result == true)
				Publications.Add(publicationViewModel.Result);
		}


		public void Edit()
		{
			var selectedPublication = Publications[SelectedIndex];
			var copyOfSelectedPublication = (Publication)selectedPublication.Clone();
			var publicationViewModel = new PublicationViewModel(copyOfSelectedPublication);

			var result = _windowManager.ShowDialog(publicationViewModel);

			if (result == true)
				Publications[SelectedIndex] = publicationViewModel.Result;
		}


		public void Remove()
		{
			Publications.RemoveRange(SelectedPublications!.Cast<Publication>());
			SelectedPublications = null;
		}


		public void Clear()
		{
			Publications.Clear();
			SelectedPublications = null;
		}


		public void Save()
		{
			var dialog = new SaveFileDialog();

			if (ShowJsonFileDialog(dialog) == false)
				return;

			var repo = new JsonRepository<Publication>(dialog.FileName);

			repo.SaveRange(Publications);
		}


		public void Load()
		{
			var dialog = new OpenFileDialog();

			if (ShowJsonFileDialog(dialog) == false)
				return;

			var repo = new JsonRepository<Publication>(dialog.FileName);

			if (LoadAndValidate(repo, out var loadedItems) == false)
				return;

			Publications.Clear();
			Publications.AddRange(loadedItems);
		}


		private bool LoadAndValidate(JsonRepository<Publication> repo, out IReadOnlyList<Publication> loadedItems)
		{
			var validator = new PublicationValidator();
			loadedItems = repo.LoadRange();

			var validationResult = validator.TryValidate(loadedItems);

			if (validationResult.IsValid)
				return true;

			ShowLoadValidationError(validationResult.ErrorDetails!);
			return false;
		}


		private void ShowLoadValidationError(CollectionValidationResult<Publication> validationResult)
		{
			var (item, index, result) = validationResult;

			_windowManager.ShowMessageBox(
				$@"
Ошибка с публикацией под номером {index + 1}

Данные публикации: 
	Заголовок - {item.Title}
	Тип - {item.Type}
	Индекс - {item.Index}
	Подписчик - {item.Subscriber}
	Улица - {item.Address.Street}
	Дом - {item.Address.House}
	Квартира - {item.Address.Flat}
	Дата начала подписки - {item.Subscription.Start:d}
	Длительность подписки - {item.Subscription.Duration}

Возникшие ошибки:
	{result.ToString("\n")}",
				"Ошибка валидации",
				icon: MessageBoxImage.Error);
		}


		public void SelectByType() =>
			SelectBy<string>(
				new("Выборка по типу",
					Publications
						.Select(t => t.Type!)
						.ToHashSet()),
				type => Publications
					.Where(publication => publication?.Type?.Equals(
											  type,
											  StringComparison.CurrentCultureIgnoreCase)
										  ?? false));


		public void SelectByDuration() =>
			SelectBy<int>(
				new("Выборка по периоду подписки",
					Publications
						.Select(t => t.Subscription!.Duration)
						.ToHashSet()),
				duration => Publications
					.Where(publication => publication.Subscription.Duration == duration));


		public void SelectBySubscriber() =>
			SelectBy<string>(
				new("Выборка по подписчику",
					Publications
						.Select(t => t.Subscriber!)
						.ToHashSet()),
				type => Publications
					.Where(publication => publication?.Subscriber?.Equals(
											  type,
											  StringComparison.CurrentCultureIgnoreCase)
										  ?? false));


		public void SelectByTitle() =>
			SelectBy<string>(
				new("Выборка по названию",
					Publications
						.Select(t => t.Title!)
						.ToHashSet()),
				type => Publications
					.Where(publication => publication?.Title?.Equals(
											  type,
											  StringComparison.CurrentCultureIgnoreCase)
										  ?? false));


		public void DataGridSelectionChanged(object sender, SelectionChangedEventArgs e) =>
			SelectedPublications = ((DataGrid)sender).SelectedItems;


		private static bool ShowJsonFileDialog(FileDialog dialog)
		{
			dialog.Filter       = "JSON documents|*.json";
			dialog.DefaultExt   = ".json";
			dialog.AddExtension = true;

			var result = dialog.ShowDialog();

			return result == true;
		}


		private void SelectBy<TSelectable>
		(
			SelectByDto<TSelectable> selectByDto,
			Func<TSelectable, IEnumerable<Publication>> obtainSelected
		)
		{
			var selectRunner = new SelectByRunner<TSelectable>(this, _windowManager);

			selectRunner.SelectBy(selectByDto, obtainSelected);
		}


		private void PublicationsOnCollectionChanged(object? sender, NotifyCollectionChangedEventArgs e) =>
			CanSelect = Publications.Count > 0;
	}
}