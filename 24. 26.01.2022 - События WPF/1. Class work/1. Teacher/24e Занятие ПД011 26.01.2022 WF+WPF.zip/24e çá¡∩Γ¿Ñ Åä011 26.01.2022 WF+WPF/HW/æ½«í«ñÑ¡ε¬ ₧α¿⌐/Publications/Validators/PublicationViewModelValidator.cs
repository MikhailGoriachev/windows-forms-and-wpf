﻿using FluentValidation;
using Publications.Pages.PublicationInput;


namespace Publications.Validators
{
	public sealed class PublicationViewModelValidator : AbstractValidator<PublicationViewModel>
	{
		public PublicationViewModelValidator()
		{
			RuleFor(model => model.Subscriber)
				.SubscriberRule();

			RuleFor(model => model.Street)
				.AddressStreetRule();

			RuleFor(model => model.House)
				.AddressHouseRule();

			RuleFor(model => model.Flat)
				.AddressFlatRule();

			RuleFor(model => model.Title)
				.TitleRule();

			RuleFor(model => model.Type)
				.TypeRule();

			RuleFor(model => model.Index)
				.IndexRule();

			RuleFor(model => model.Start)
				.SubscriptionStartRule();

			RuleFor(model => model.Duration)
				.SubscriptionDurationRule();
		}
	}
}