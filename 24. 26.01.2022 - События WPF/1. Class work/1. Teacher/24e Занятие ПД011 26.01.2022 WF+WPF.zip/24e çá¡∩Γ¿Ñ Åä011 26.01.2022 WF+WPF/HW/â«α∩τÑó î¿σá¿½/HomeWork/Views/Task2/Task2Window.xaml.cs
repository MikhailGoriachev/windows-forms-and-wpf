﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

using HomeWork.Controllers;         // контроллеры
using HomeWork.Models.Task2;        // модели второго задания

namespace HomeWork.Views.Task2
{
    /// <summary>
    /// Interaction logic for Task2Window.xaml
    /// </summary>
    public partial class Task2Window : Window
    {
        // контроллер обработки по заданию 1 (Список сотрудников)
        private Task2Controller _controller;

        public Task2Controller Controller
        {
            get => _controller;
            set => _controller = value;
        }


        #region Конструкторы


        // конструктор по умолчанию
        public Task2Window() : this(new Task2Controller()) { }


        // конструктор иницализирующий
        public Task2Window(Task2Controller task2Controller)
        {
            InitializeComponent();

            // установка значений
            _controller = task2Controller;

            // подписка на события
            CmbBorder.SelectionChanged += CmbBorder_SelectionChanged;
        }


        #endregion

        #region Методы


        #region Обработчики событий

        // загрузка формы
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            // обновление данных о сотрудниках в окне
            UpdateData();
        }


        // выбор элемента в DataGrid
        private void DgvPeriodicals_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            // заполнение информационных столбцов
            PeriodicalModel periodical = DgvPeriodicals.SelectedItem as PeriodicalModel;

            // если элемент не выбран
            if (periodical == null)
            {
                // установка значения полей по умолчанию
                SetDefaultInfo();
                return;
            }

            TbxInfoFullName.Text    = periodical.FullName;
            TbxInfoDuration.Text    = periodical.Duration.ToString();
            TbxInfoDate.Text        = $"{periodical.DateSubscribe:d}";
            TbxInfoAddress.Text     = $"{periodical.Street} {periodical.Home}/{periodical.Apartment}";
        }


        // закрытие окна
        private void Exit_Click(object sender, RoutedEventArgs e) => Close();


        // формирование списка подписок
        private void Initialization_Click(object sender, RoutedEventArgs e)
        {
            // формирование списка
            _controller.Initialization();

            // обновление данных в окне
            UpdateData();
        }


        // добавление коллекции подписок
        private void AddRange_Click(object sender, RoutedEventArgs e)
        {
            // формирование списка
            _controller.AddRange();

            // обновление данных в окне
            UpdateData();
        }


        // очистка списка
        private void Clear_Click(object sender, RoutedEventArgs e)
        {
            // формирование списка
            _controller.Clear();

            // обновление данных в окне
            UpdateData();
        }


        // добавить подписку
        private void Add_Click(object sender, RoutedEventArgs e)
        {
            // окно для добавления подписки
            PeriodicalWindow window = new PeriodicalWindow();

            // получение результата окна
            if (window.ShowDialog() == false)
                return;

            // добавление подписки
            _controller.Add(window.Periodical.Clone());

            // обновление данных
            UpdateData();
        }


        // изменить выбранного сотрудника
        private void Edit_Click(object sender, RoutedEventArgs e)
        {
            // если подписка не выбрана
            if (DgvPeriodicals.SelectedItems.Count == 0)
                return;

            // выбранная подписка
            PeriodicalModel periodical = DgvPeriodicals.SelectedItem as PeriodicalModel;

            // окно для редактирование подписки
            PeriodicalWindow window = new PeriodicalWindow(periodical);

            // получение результата окна
            if (window.ShowDialog() == false)
                return;

            // применение изменений
            periodical.FullName         = window.Periodical.FullName;
            periodical.Title            = window.Periodical.Title;
            periodical.Index            = window.Periodical.Index;
            periodical.Duration         = window.Periodical.Duration;
            periodical.DateSubscribe    = window.Periodical.DateSubscribe;
            periodical.Street           = window.Periodical.Street;
            periodical.Home             = window.Periodical.Home;
            periodical.Apartment        = window.Periodical.Apartment;

            // обновление данных
            UpdateData();
        }


        // удалить выбранную подписку
        private void Remove_Click(object sender, RoutedEventArgs e)
        {
            // удаление
            _controller.Remove(DgvPeriodicals.SelectedItem as PeriodicalModel);

            // обновление данных в окне
            UpdateData();
        }



        // сортировка 
        private void Order_Click(object sender, RoutedEventArgs e)
        {
            // получение назвая сортировки
            string orderBy = ((MenuItem)e.OriginalSource).Header.ToString();

            // сортировка
            switch (orderBy)
            {
                // case "Сортировка по фамилии":
                //     _controller.SortBySurname();
                //     break;
                // case "Сортировка по имени":
                //     _controller.SortByName();
                //     break;
                // case "Сортировка по отчеству":
                //     _controller.SortByPatronymic();
                //     break;
                default:
                    break;
            }

            // обновление данных
            UpdateData();
        }


        // открытие окна с информацией о программе 
        private void InfoProgram_Click(object sender, RoutedEventArgs e) => new ProgramInfoWindow().ShowDialog();


        #endregion


        #region Общие методы


        // установка значений по умолчанию информационных полей о выбранном элементе (справа от списка)
        public void SetDefaultInfo() => TbxInfoAddress.Text = TbxInfoFullName.Text = TbxInfoDate.Text = TbxInfoDuration.Text = "─────";


        // обновление информации о количестве элементов в статус-баре
        public void UpdateStatus()
        {
            // текст в текст-блоке
            string text = TblAmountElem.Text;

            // обрезание строки по символу ':'
            text = text.Remove(text.LastIndexOf(':') + 2);

            // обновление информации о количестве элементов
            TblAmountElem.Text = text + _controller.Periadicals.Count().ToString();
        }


        // обновление привязки в DataGrid
        public void UpdateBinding()
        {
            DgvPeriodicals.ItemsSource = null;
            DgvPeriodicals.ItemsSource = _controller.Periadicals;
        }


        // обновление данных о сотрудниках в окне
        public void UpdateData()
        {
            // обновление информации о количестве элементов в статус-баре
            UpdateStatus();

            // обновление привязки в DataGrid
            UpdateBinding();
        }


        // выбор сортировки в комбо-боксе
        private void CmbBorder_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            switch (CmbBorder.SelectedValue)
            {
                // case "Сортировка по фамилии":
                //     _controller.SortBySurname();
                //     break;
                // case "Сортировка по имени":
                //     _controller.SortByName();
                //     break;
                // case "Сортировка по отчеству":
                //     _controller.SortByPatronymic();
                //     break;
                default:
                    break;
            }

            // обновление данных
            UpdateData();
        }

        #endregion

        #endregion

    }
}
