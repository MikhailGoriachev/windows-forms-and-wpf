﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

using HomeWork.Utilities;           // утилиты
using HomeWork.Models.Task2;        // модели

namespace HomeWork.Views.Task2
{
    /// <summary>
    /// Interaction logic for PeriodicalWindow.xaml
    /// </summary>
    public partial class PeriodicalWindow : Window
    {
        // обрабатываемый сотрудник
        private PeriodicalModel _periocical;

        public PeriodicalModel Periodical => _periocical;


        #region Конструкторы 


        // конструктор по умолчанию (Запуск формы в режиме создания)
        public PeriodicalWindow()
        {
            InitializeComponent();

            // получение окна для запуска в режиме создания
            _periocical = Resources["EmployeeRes"] as PeriodicalModel;

            // новый объект
            PeriodicalModel employee = PeriodicalModel.GetPeriodical();

            // установка новых данных
            _periocical.FullName        = employee.FullName;
            _periocical.Title           = employee.Title;
            _periocical.Index           = employee.Index;
            _periocical.Duration        = employee.Duration;
            _periocical.DateSubscribe   = employee.DateSubscribe;
            _periocical.Street          = employee.Street;
            _periocical.Home            = employee.Home;
            _periocical.Apartment       = employee.Apartment;
        }


        // конструктор окна для запуска в режиме редактирования
        public PeriodicalWindow(PeriodicalModel employee)
        {
            InitializeComponent();

            // получение подписки из ресурсов
            _periocical = Resources["PeriodicalRes"] as PeriodicalModel;

            // установка данных
            _periocical.FullName        = employee.FullName;
            _periocical.Title           = employee.Title;
            _periocical.Index           = employee.Index;
            _periocical.Duration        = employee.Duration;
            _periocical.DateSubscribe   = employee.DateSubscribe;
            _periocical.Street          = employee.Street;
            _periocical.Home            = employee.Home;
            _periocical.Apartment       = employee.Apartment;

            // установка заголовка
            LblHeader.Content = Title = "Редактирование подписки на периодическое издания";

            // установка надписи на кнопке
            BtnOk.Content = "Сохранить";
        }

        #endregion


        #region Методы

        // загрузка окна
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            // подписка на события

            TbxFullName.TextChanged     += TextBox_TextChanged;
            TbxPatronymic.TextChanged   += TextBox_TextChanged;
            TbxAge.TextChanged          += TextBox_TextChanged;
            TbxStreet.TextChanged       += TextBox_TextChanged;
            TbxHome.TextChanged         += TextBox_TextChanged;
            TbxApartment.TextChanged    += TextBox_TextChanged;
            TbxType.TextChanged         += TextBox_TextChanged;
            TbxIndex.TextChanged        += TextBox_TextChanged;

            // TbxFullName
            // TbxPatronymic
            // TbxAge
            // TbxStreet
            // TbxHome
            // TbxApartment
            // TbxType
            // TbxIndex
            // CldDate

        }


        // добавление/сохранение сотрудника
        private void BtnOk_Click(object sender, RoutedEventArgs e) => DialogResult = true;


        // обработка измений текста в полях ввода
        private void TextBox_TextChanged(object sender, TextChangedEventArgs e) =>
            BtnOk.IsEnabled = !string.IsNullOrWhiteSpace(TbxFullName.Text)
                           && !string.IsNullOrWhiteSpace(TbxPatronymic.Text)
                           && !string.IsNullOrWhiteSpace(TbxStreet.Text)
                           && !string.IsNullOrWhiteSpace(TbxHome.Text)
                           && !string.IsNullOrWhiteSpace(TbxType.Text)
                           && !string.IsNullOrWhiteSpace(TbxIndex.Text)
                           && int.TryParse(TbxApartment.Text, out int i)
                           && int.TryParse(TbxAge.Text, out i);


        #endregion
    }
}
