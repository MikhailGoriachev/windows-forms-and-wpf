﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace Task2.Models
{
	// класс, представляющий подписку на периодические издания
	public class Subscribe : DependencyObject
	{
		// фамилию и инициалы подписчика
		public string SurnameNP
		{
			get => (string)GetValue(SurnameNPProperty);
			set => SetValue(SurnameNPProperty, value);
		}
		public static readonly DependencyProperty SurnameNPProperty =
			DependencyProperty.Register("SurnameNP", typeof(string ), typeof(Subscribe),
				new FrameworkPropertyMetadata { CoerceValueCallback = CorrectString });

		// адрес (улица, дом и квартира)

		// улица
		public string Street
		{
			get => (string)GetValue(StreetProperty);
			set => SetValue(StreetProperty, value);
		}
		public static readonly DependencyProperty StreetProperty =
			DependencyProperty.Register("Street", typeof(string), typeof(Subscribe),
				new FrameworkPropertyMetadata { CoerceValueCallback = CorrectString });

		// дом
		public string Building
		{
			get => (string)GetValue(BuildingProperty);
			set => SetValue(BuildingProperty, value);
		}
		public static readonly DependencyProperty BuildingProperty =
			DependencyProperty.Register("Building", typeof(string), typeof(Subscribe),
				new FrameworkPropertyMetadata { CoerceValueCallback = CorrectString });

		// квартира
		public int Apartment
		{
			get => (int)GetValue(ApartmentProperty);
			set => SetValue(ApartmentProperty, value);
		}
		public static readonly DependencyProperty ApartmentProperty =
			DependencyProperty.Register("Apartment", typeof(int), typeof(Subscribe));

		// название издания
		public string Title
		{
			get => (string)GetValue(TitleProperty);
			set => SetValue(TitleProperty, value);
		}
		public static readonly DependencyProperty TitleProperty =
			DependencyProperty.Register("Title", typeof(string), typeof(Subscribe),
				new FrameworkPropertyMetadata { CoerceValueCallback = CorrectString });

		// тип издания
		public string PubType
		{
			get => (string)GetValue(PubTypeProperty);
			set => SetValue(PubTypeProperty, value);
		}
		public static readonly DependencyProperty PubTypeProperty =
			DependencyProperty.Register("PubType", typeof(string), typeof(Subscribe),
				new FrameworkPropertyMetadata { CoerceValueCallback = CorrectString });

		// индекс издания
		public string PubIndex
		{
			get => (string)GetValue(PubIndexProperty);
			set => SetValue(PubIndexProperty, value);
		}

		public static readonly DependencyProperty PubIndexProperty =
			DependencyProperty.Register("PubIndex", typeof(string), typeof(Subscribe),
				new FrameworkPropertyMetadata { CoerceValueCallback = CorrectString });

		// дата начала подписки
		public DateTime StartDate
		{
			get => (DateTime)GetValue(StartDateProperty);
			set => SetValue(StartDateProperty, value);
		}
		public static readonly DependencyProperty StartDateProperty =
			DependencyProperty.Register("StartDate", typeof(DateTime), typeof(Subscribe));

		// период подписки
		public int Duration
		{
			get => (int)GetValue(DurationProperty);
			set => SetValue(DurationProperty, value);
		}
		public static readonly DependencyProperty DurationProperty =
			DependencyProperty.Register("Duration", typeof(int), typeof(Subscribe),
				new FrameworkPropertyMetadata { CoerceValueCallback = CorrectDuration });


		// методы коррекции значений свойств
		private static object CorrectDuration(DependencyObject d, object baseValue)
		{
			int currentValue = (int)baseValue;

			if (currentValue < 1) currentValue = 1;
			else if (currentValue > 12) currentValue = 12;
			
			return currentValue;
		}


		private static object CorrectString(DependencyObject d, object baseValue)
		{
			string currentValue = (string)baseValue;

			if (string.IsNullOrEmpty(currentValue)) currentValue = "не указано";

			return currentValue;
		}

	}
}
