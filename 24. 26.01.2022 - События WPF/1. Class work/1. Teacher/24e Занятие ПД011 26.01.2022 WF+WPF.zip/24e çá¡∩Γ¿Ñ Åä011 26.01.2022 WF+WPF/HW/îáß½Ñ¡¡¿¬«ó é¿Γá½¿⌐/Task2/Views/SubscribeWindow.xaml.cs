﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Task2.Models;

namespace Task2.Views
{
	/// <summary>
	/// Логика взаимодействия для SubscribeWindow.xaml
	/// </summary>
	public partial class SubscribeWindow : Window
	{
		private Subscribe _subscribe;

		public Subscribe Subscribe=> _subscribe;

		public SubscribeWindow()
		{
			InitializeComponent();

			_subscribe = (Subscribe)Resources["Subscribe"];
		}

		public SubscribeWindow(Subscribe subscribe)
		{
			InitializeComponent();
			Title = "Изменить данные о подписке";
			BtnOk.Content = "Изменить";

			_subscribe = (Subscribe)Resources["Subscribe"];

			_subscribe.Apartment = subscribe.Apartment;
			_subscribe.Building = subscribe.Building;
			_subscribe.Duration = subscribe.Duration;
			_subscribe.PubIndex = subscribe.PubIndex;
			_subscribe.PubType = subscribe.PubType;
			_subscribe.StartDate = subscribe.StartDate;
			_subscribe.Street = subscribe.Street;
			_subscribe.SurnameNP = subscribe.SurnameNP;
			_subscribe.Title = subscribe.Title;
		}

		
		private void Txb_PreviewTextInput(object sender, TextCompositionEventArgs e) =>
			e.Handled = !int.TryParse(e.Text, out _);

		private void BtnOk_Click(object sender, RoutedEventArgs e) =>
			DialogResult = true;

	}
}
