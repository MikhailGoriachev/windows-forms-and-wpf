﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Task2.Models;

namespace Task2.Controllers
{
	public class PostalServiceController
	{
		// директория и имя файля для сохранения
		public string FileName { get; set; }

		// директория и имя файля для сохранения по-умолчанию
		public static readonly string FileNameDefault = Environment.CurrentDirectory + @"\App_Data\subscribers.json";

		// объект для обработки
		private PostalService _postalService;
		
		public PostalService PostalService => _postalService;

		public PostalServiceController() 
		{
			string dir = Path.GetDirectoryName(FileNameDefault);
			if (!Directory.Exists(dir))
				Directory.CreateDirectory(dir);

			if (File.Exists(FileNameDefault))
				ReadJsonFromFile(FileNameDefault);
			else
			{
				_postalService = new PostalService();
				SaveJsonToFile(FileNameDefault);
			}
		}

		public PostalServiceController(string fileName, PostalService postalService)
		{
			_postalService = postalService;
			FileName = fileName;
		}

		// Получить список типов издания, фигурирующих в коллекции
		public List<string> GetPubTypesList => _postalService.GetPubTypesList;

		// Получить список периодов подписок, фигурирующих в коллекции
		public List<string> GetDurationsList => _postalService.GetDurationsList;

		// Получить список фамилий и инициалов, фигурирующих в коллекции
		public List<string> GetSurnamesList => _postalService.GetSurnamesList;

		// получить копию данных о подписках
		public ObservableCollection<Subscribe> TelevisionsCopy() =>
			new ObservableCollection<Subscribe>(_postalService.Subscribes);

		// Запрос на получение упорядоченной копии коллекции по индексу издания
		public List<Subscribe> OrderByPubIndex() => PostalService.OrderBy(s => s.PubIndex);

		// Запрос на получение упорядоченной копии коллекции по адресу подписчика
		public List<Subscribe> OrderByAddress() => 
			TelevisionsCopy().ToList()
				.OrderBy(s => s.Street)
				.ThenBy(s => s.Building)
				.ThenBy(s => s.Apartment)
				.ToList();

		// Запрос на получение упорядоченной копии коллекции по индексу издания
		public List<Subscribe> OrderByDurationDescend() => PostalService.OrderByDescending(s => s.Duration);


		// Запрос на выборку подписок по выбранному типу издания
		public List<Subscribe> SelectWherePubType(string type) =>
			_postalService.Filter(t => t.PubType == type);

		// Запрос на выборку подписок по выбранному периоду
		public List<Subscribe> SelectWhereDuration(int duration) =>
			_postalService.Filter(t => t.Duration == duration);

		// Запрос на выборку подписок по выбранной фамилии и инициалам подписчика
		public List<Subscribe> SelectWhereSurname(string surname) =>
			_postalService.Filter(t => t.SurnameNP == surname);


		#region Сериализация
		// Сохранение в файл JSON форматом
		public void SaveJsonToFile()
		{
			using (StreamWriter file = File.CreateText(PostalServiceController.FileNameDefault))
			{
				new JsonSerializer { Formatting = Formatting.Indented }.Serialize(file, _postalService);
			}
		}

		public void SaveJsonToFile(string fileName)
		{
			using (StreamWriter file = File.CreateText(fileName))
			{
				new JsonSerializer { Formatting = Formatting.Indented }.Serialize(file, _postalService);
			}
		}

		// Чтение из файла JSON форматом
		public void ReadJsonFromFile(string fileName)
		{
			using (StreamReader file = File.OpenText(fileName))
			{
				JsonSerializer serializer = new JsonSerializer();
				_postalService = (PostalService)serializer.Deserialize(file, typeof(PostalService));
				FileName = fileName;
			}
		}
		#endregion
	}
}
