﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Task1.Models;

namespace Task1.Views
{
	/// <summary>
	/// Логика взаимодействия для MainWindow.xaml
	/// </summary>
	public partial class MainWindow : Window
	{
		private static readonly int Elements = 20;

		private ObservableCollection<Person> _persons;

		public MainWindow(): 
			this(new ObservableCollection<Person>(Enumerable.Repeat(Person.Generate(), Elements)
				.Select(x => Person.Generate())
				.ToList()))
		{}

		public MainWindow(ObservableCollection<Person> persons)
		{
			InitializeComponent();
			_persons = persons;

			DgPersons.ItemsSource = _persons;
		}

		private void Add_Click(object sender, RoutedEventArgs e)
		{
			PersonWindow personWindow = new PersonWindow();
			
			if (personWindow.ShowDialog() == false) return;

			_persons.Add(personWindow.Person);
		}

		private void Edit_Command(object sender, RoutedEventArgs e)
		{
			if (DgPersons.SelectedIndex == -1) return;

			// индекс выбранного элемента
			int selected = DgPersons.SelectedIndex;


			PersonWindow personWindow = new PersonWindow(_persons[selected]);

			if (personWindow.ShowDialog() == false) return;

			_persons[selected] = personWindow.Person;
		}

		private void Delete_Command(object sender, RoutedEventArgs e)
		{
			if (DgPersons.SelectedIndex == -1) return;

			_persons.RemoveAt(DgPersons.SelectedIndex);
		}
	}
}
