﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Task1.Models;

namespace Task1.Views
{
	/// <summary>
	/// Логика взаимодействия для PersonWindow.xaml
	/// </summary>
	public partial class PersonWindow : Window
	{
		// ссылка  
		private Person _person;

		public Person Person => _person;

		public PersonWindow()
		{
			InitializeComponent();

            // получить ссылку на ресурс/найти ресурс по имен
			_person = (Person)Resources["Person"];
		}

		public PersonWindow(Person person)
		{
			InitializeComponent();
			Title = "Изменить данные о сотруднике";
			BtnOk.Content = "Изменить";

			// получить ссылку на ресурс/найти ресурс по имени 
			_person = (Person)Resources["Person"];

			// запись а поля ресурса => запись в поля элементов управления
			// !! реализация привязки !!
			_person.Surname = person.Surname;
			_person.Name = person.Name;
			_person.Patronymic = person.Patronymic;
			_person.City = person.City;
			_person.Age = person.Age;
			_person.Salary = person.Salary;
		}

		private void Txb_PreviewTextInput(object sender, TextCompositionEventArgs e) =>
			e.Handled = !int.TryParse(e.Text, out _);

		private void BtnOk_Click(object sender, RoutedEventArgs e) => 
			DialogResult = true;
	}
}
