﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using Task1.Helpers;

namespace Task1.Models
{
	/*Разработайте класс с использованием свойств зависимости для представления данных сотрудника:
	 фамилия, имя, отчество, возраст, оклад, город проживания. 
	Используйте корректирующие валидаторы для возраста (от 0 до 190), 
	оклада (от 0 до 1 000 000).*/
	public class Person : DependencyObject
	{
		public const int MaxAge = 190;
		public const int MaxSalary = 1_000_000;

		static Person()
		{
			SurnameProperty =
				DependencyProperty.Register("Surname", typeof(string), typeof(Person));
			NameProperty =
				DependencyProperty.Register("Name", typeof(string), typeof(Person));
			PatronymicProperty =
				DependencyProperty.Register("Patronymic", typeof(string), typeof(Person));
			CityProperty =
				DependencyProperty.Register("City", typeof(string), typeof(Person));
			AgeProperty =
				DependencyProperty.Register("Age", typeof(int), typeof(Person),
					new FrameworkPropertyMetadata {CoerceValueCallback = CorrectAge});
			SalaryProperty =
				DependencyProperty.Register("Salary", typeof(int), typeof(Person),
					new FrameworkPropertyMetadata {CoerceValueCallback = CorrectSalary});
		}


		// фамилия
		public static readonly DependencyProperty SurnameProperty;

		public string Surname
		{
			get => (string) GetValue(SurnameProperty);
			set => SetValue(SurnameProperty, value);
		}

		// имя
		public string Name
		{
			get => (string)GetValue(NameProperty);
			set => SetValue(NameProperty, value);
		}
		public static readonly DependencyProperty NameProperty;

		// отчество
		public string Patronymic
		{
			get => (string)GetValue(PatronymicProperty);
			set => SetValue(PatronymicProperty, value);
		}
		public static readonly DependencyProperty PatronymicProperty;

		// город проживания
		public string City
		{
			get => (string)GetValue(CityProperty);
            set => SetValue(CityProperty, value);
        }
		public static readonly DependencyProperty CityProperty;

		// возраст
		public int Age
		{
			get => (int)GetValue(AgeProperty);
			set => SetValue(AgeProperty, value);
		}
		public static readonly DependencyProperty AgeProperty;

		// оклад
		public int Salary
		{
			get => (int)GetValue(SalaryProperty);
			set => SetValue(SalaryProperty, value);
		}
		public static readonly DependencyProperty SalaryProperty;

		public Person()
		{
			
		}


		public Person(string name, string surname, string patronymic, string city, int age, int salary)
		{
			Name = name;
			Surname = surname;
			Patronymic = patronymic;
			City = city;
			Age = age;
			Salary = salary;
		}

		// ---------------------- корректирующие валидаторы ---------------------------------
		private static object CorrectAge(DependencyObject d, object baseValue)
		{
			int currentValue = (int)baseValue;

			if (currentValue <= 0) currentValue = 0;
			else if (currentValue > MaxAge) currentValue = MaxAge;

			return currentValue;
		}

		private static object CorrectSalary(DependencyObject d, object baseValue)
		{
			int currentValue = (int)baseValue;

			if (currentValue <= 0) currentValue = 0;
			else if (currentValue > MaxSalary) currentValue = MaxSalary;

			return currentValue;
		}

		public static Person Generate()
		{
			string[] surnames = { 
				"Архипова", "Балашов", "Миронов", "Долгова", "Новикова", "Исаков", "Попов", "Соловьева", "Сухова", "Шмелев",
				"Бирюков", "Маслова", "Иванова", "Моргунов", "Зимин", "Баранова", "Колесов", "Павлова", "Павлов", "Новиков",};

			string[] names =
			{
				"Алина", "Тимофей", "Яков", "Майя", "София", "Арсений", "Никита", "Валерия", "Валерия", "Роман", "Данила",
				"Юлия", "Вероника", "Демьян", "Даниил", "Мария", "Михаил", "Аделина", "Дмитрий", "Марк"
			};

			string[] patronymics =
			{
				"Ивановна", "Маркович", "Матвеевич", "Данииловна", "Ивановна", "Адамович", "Андреевич", "Романовна", "Степановна",
				"Матвеевич", "Николаевич", "Егоровна", "Юрьевна", "Тимурович", "Иванович", "Марковна", "Михайлович", "Сергеевна",
				"Львович", "Арсентьевич"
			};

			string[] cities =
			{
				"Донецк", "Макеевка", "Горловка", "Снежное", "Дебальцево", "Торез", "Енакиево", "Шахтерск",
			};

			return new Person
			{
				Age = Utils.GetRandom(18, 65),
				City = cities[Utils.GetRandom(0, cities.Length - 1)],
				Name = names[Utils.GetRandom(0, names.Length - 1)],
				Surname = surnames[Utils.GetRandom(0, surnames.Length - 1)],
				Patronymic = patronymics[Utils.GetRandom(0, patronymics.Length - 1)],
				Salary = Utils.GetRandom(5000,1000000)
			};
		}
	}
}
