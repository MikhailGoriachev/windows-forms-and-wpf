﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using DependencyUser.Helpers;

namespace DependencyUser.Models
{
    //класс, показываюший предприятие, коллекцию сотрудников
    public class Enterprise
    {
        //коллекция сотрудников
        public ObservableCollection<User> Users { get; set; } = new ObservableCollection<User>();

        // формирование списка сотрудников
         public void GenerateUsers(int n = 10)
        {
            Users.Clear();

            //формирование данных
            for (int i = 0; i < n; i++)
            {
                Users.Add(Factory());
            }

            
        }

        //фабричный метод создания сотрудников
        static public User Factory()
        {
            string[] surnames =
            {
                "Иванов",
                "Петров",
                "Сидоров",
                "Никифоров",
                "Глушко",
                "Нефедов",
                "Крыга",
                "Зиновьев",
                "Васильев"
            };

            string[] names =
            {
                "Иван",
                "Сергей",
                "Константин",
                "Николай",
                "Григорий",
                "Валерий",
                "Павел",
                "Егор",
                "Тихон",
                "Валентин",
            };

            string[] patronymics =
            {
                "Панфилович",
                "Викторович",
                "Николаевич",
                "Федорович",
                "Леонидович",
                "Ильич",
                "Дмитриевич",
                "Зиновьевич",
                "Геогриевич"
            };

           
            string[] cities = {"Воронеж", "Волгоград", "Краснодон", "Шостка", "Ростов", "Дальнегорск", "Мичуринск"};

            return new User()
            {
                FullName = names[Utils.GetRand(0, names.Length)],
                Surname = surnames[Utils.GetRand(0, surnames.Length)],
                Patromynic = patronymics[Utils.GetRand(0, patronymics.Length)],
                Age = Utils.GetRand(21, 80),
                Salary = Utils.GetRand(12000, 90000),
                City = cities[Utils.GetRand(0, cities.Length)]

            };

            
        }

        //добавление сотрудника
        public void Add(User users) => Users.Add(users);

        //упорядочивание по компаратору
        public void OrderBy<TKey>(Func<User, TKey> keySelector)
        {
            Users = new ObservableCollection<User>(Users.OrderBy(keySelector));
        }

    }
}
