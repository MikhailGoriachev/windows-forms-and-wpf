﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DependencyUser.Models;
using DependencyUser.Helpers;

namespace DependencyUser.Controllers
{
    class Controller
    {
        //предприятие 
        private Enterprise _enterprise;

        public Enterprise Enterprise
        {
            get => _enterprise;
            set => _enterprise = value;
        }

        //доступ к предприятию 
        public ObservableCollection<User> Users
        {
            get => _enterprise.Users;
            set => _enterprise.Users = value;
        }

        //конструктор инициализирующий
        public Controller(Enterprise enterprise)
        {
            _enterprise = enterprise;
        }

        //переформирование коллекции сотрудников
        public void Initialization(int n = 10) => _enterprise.GenerateUsers(n);

        //добавление сотрудника
        public void Add(User user) => _enterprise.Add(user);

        //упорядочивание по фамилии
        public void OrderBySurname() => _enterprise.OrderBy(x => x.Surname);

        //упорядочивание по имени 
        public void OrderByFullname() => _enterprise.OrderBy(x => x.FullName);

        //упорядочивание по отчеству
        public void OrderByPatronymic() => _enterprise.OrderBy(x => x.Patromynic);
    }
}
