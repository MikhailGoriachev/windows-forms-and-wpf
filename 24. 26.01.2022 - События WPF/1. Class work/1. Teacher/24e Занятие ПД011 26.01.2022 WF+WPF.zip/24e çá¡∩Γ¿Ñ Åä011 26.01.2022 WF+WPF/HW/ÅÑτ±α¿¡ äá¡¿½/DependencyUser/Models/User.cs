﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace DependencyUser.Models
{
    //класс для представления свойств сотрудника
    public class User :DependencyObject
    {
        //максимальное значение для оклада
        public const int MaxSalary = 1000000;
        // максимальное значение для возраста
        public const int MaxAge = 190;

        //свойство зависимости 
        public static readonly DependencyProperty FullNameProperty;

        // имя
        public string FullName
        {
            get => (string) GetValue(FullNameProperty);
            set => SetValue(FullNameProperty, value);
        }

        //фамилия 
        public static readonly DependencyProperty SurnamePropery;
        public string Surname
        {
            get => (string) GetValue(SurnamePropery);
            set => SetValue(SurnamePropery, value);
        }

        // отчество 
        public static readonly DependencyProperty PatronymicProperty;

        public string Patromynic
        {
            get => (string) GetValue(PatronymicProperty);
            set => SetValue(PatronymicProperty, value);
        }

        public static readonly DependencyProperty AgeProperty;

        //возраст
        public int Age
        {
            get { return (int)GetValue(AgeProperty); }
            set { SetValue(AgeProperty, value); }
        }

        //оклад

        public static readonly DependencyProperty SalaryProperty;

        public int Salary
        {
            get => (int) GetValue(SalaryProperty);
            set => SetValue(SalaryProperty, value);
        }
        
        //город проживания

        public static readonly DependencyProperty CityProperty;

        public string City
        {
            get => (string) GetValue(CityProperty);
            set => SetValue(CityProperty, value);
        }

        static User()
        {
            FullNameProperty = DependencyProperty.Register("FullName",typeof(string), typeof(User));

            SurnamePropery = DependencyProperty.Register("Surname", typeof(string), typeof(User));

            PatronymicProperty = DependencyProperty.Register("Patronymic", typeof(string), typeof(User));

            FrameworkPropertyMetadata metadata = new FrameworkPropertyMetadata {CoerceValueCallback = CorrectAge};

            AgeProperty = DependencyProperty.Register("Age", typeof(int), typeof(User), metadata);

            FrameworkPropertyMetadata metadata1 = new FrameworkPropertyMetadata {CoerceValueCallback = CorrectSalary};
            SalaryProperty = DependencyProperty.Register("Salary", typeof(int), typeof(User), metadata1);

            CityProperty = DependencyProperty.Register("City", typeof(string), typeof(User));
        }

        //корректирующая валидация для возврата оклада сотрудника
        private static object CorrectAge(DependencyObject d, object baseValue)
        {
            int currentvalue = (int) baseValue;

            if (currentvalue <= 0) return 0;

            if (currentvalue > MaxAge) return MaxAge;

            return currentvalue;
        }

        //корректирующая валидация для оклада сотрудника 
        private static object CorrectSalary(DependencyObject d, object baseValue)
        {
            int currentvalue = (int) baseValue;

            if (currentvalue <= 0) return 0;

            if (currentvalue > MaxSalary) return MaxSalary;

            return currentvalue;
        }


    }
}
