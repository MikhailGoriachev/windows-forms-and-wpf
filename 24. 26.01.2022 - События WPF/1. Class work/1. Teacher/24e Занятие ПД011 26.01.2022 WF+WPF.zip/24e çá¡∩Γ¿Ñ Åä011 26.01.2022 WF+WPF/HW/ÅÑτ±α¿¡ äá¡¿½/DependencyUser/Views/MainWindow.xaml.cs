﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using DependencyUser.Models;
using DependencyUser.Views;

namespace DependencyUser
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public Enterprise Firm { get; set; } = new Enterprise();
        public MainWindow()
        {
            InitializeComponent();


        }

        private void CreateCollection_Click(object sender, RoutedEventArgs e)
        {
            Firm.GenerateUsers();
        }

        private void AddUser_Click(object sender, RoutedEventArgs e)
        {
            AddUser add = new AddUser();
            if (add.ShowDialog() == true) 
                Firm.Add(add.User);
        }

        private void SortBySurname_Click(object sender, RoutedEventArgs e)
        {
            throw new NotImplementedException();
        }

        private void SortByName_Click(object sender, RoutedEventArgs e)
        {
            throw new NotImplementedException();
        }

        private void SortByPatronymic_Click(object sender, RoutedEventArgs e)
        {
            throw new NotImplementedException();
        }
    }
}
