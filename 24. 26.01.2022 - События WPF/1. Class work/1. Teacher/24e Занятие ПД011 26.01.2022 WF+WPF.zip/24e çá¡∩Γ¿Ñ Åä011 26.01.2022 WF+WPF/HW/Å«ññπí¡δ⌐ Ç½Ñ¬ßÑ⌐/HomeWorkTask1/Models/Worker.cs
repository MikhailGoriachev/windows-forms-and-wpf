﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace HomeWorkTask1.Models
{
    public class Worker : DependencyObject
    {
        /*
         Разработайте класс с использованием свойств зависимости для представления данных сотрудника: 
        фамилия, 
        имя, 
        отчество, 
        возраст, 
        оклад, 
        город проживания.
        Используйте корректирующие валидаторы для возраста (от 0 до 190), оклада (от 0 до 1 000 000).*/

        public const int MaxAge = 190;
        public const double MaxSalary = 1000000d;

        // свойство зависимости - фамилия сотрудника        
        public static readonly DependencyProperty SurNameProperty;  // хранилище значений
        public string SurName
        {    // свойство-обертка для доступа к хранилищу значений
            get => (string)GetValue(SurNameProperty);
            set => SetValue(SurNameProperty, value);
        } // SurName


        // свойство зависимости - имя сотрудника        
        public static readonly DependencyProperty NameProperty;  // хранилище значений
        public string Name
        {    // свойство-обертка для доступа к хранилищу значений
            get => (string)GetValue(NameProperty);
            set => SetValue(NameProperty, value);
        } // Name


        // свойство зависимости - отчество сотрудника        
        public static readonly DependencyProperty PatronymicProperty;  // хранилище значений
        public string Patronymic
        {    // свойство-обертка для доступа к хранилищу значений
            get => (string)GetValue(PatronymicProperty);
            set => SetValue(PatronymicProperty, value);
        } // Patronymic


        // свойство зависимости - возраст сотрудника        
        public static readonly DependencyProperty AgeProperty;  // хранилище значений
        public int Age
        {    // свойство-обертка для доступа к хранилищу значений
            get => (int)GetValue(AgeProperty);
            set => SetValue(AgeProperty, value);
        } // Age


        // свойство зависимости - оклад сотрудника        
        public static readonly DependencyProperty SalaryProperty;  // хранилище значений
        public double Salary
        {    // свойство-обертка для доступа к хранилищу значений
            get => (double)GetValue(SalaryProperty);
            set => SetValue(SalaryProperty, value);
        } // Salary


        // свойство зависимости - город проживания сотрудника        
        public static readonly DependencyProperty CityProperty;  // хранилище значений
        public string City
        {    // свойство-обертка для доступа к хранилищу значений
            get => (string)GetValue(CityProperty);
            set => SetValue(CityProperty, value);
        } // City



        // статический конструктор для реализации статической части свойств зависимостей 
        // т.е. это регистрация хранилища значений свойств 
        static Worker()
        {
            // регистрация свойства в хранилище методом Register()
            // 1-й параметр метода - имя свойства
            // 2-й параметр метода - тип свойства
            // 3-й параметр метода - тип владельца свойства, т.е. имя нашего класса
            SurNameProperty = DependencyProperty.Register(
                "SurName", typeof(string), typeof(Worker));

            NameProperty = DependencyProperty.Register(
                "Name", typeof(string), typeof(Worker));

            PatronymicProperty = DependencyProperty.Register(
                "Patronymic", typeof(string), typeof(Worker));

            // регистрация делегата для корректирующей валидации возраста
            FrameworkPropertyMetadata metadataForAge = new FrameworkPropertyMetadata { CoerceValueCallback = CorrectAge };

            AgeProperty = DependencyProperty.Register(
                "Age", typeof(int), typeof(Worker),
                metadataForAge);


            // регистрация делегата для корректирующей валидации оклада
            FrameworkPropertyMetadata metadataForSalary = new FrameworkPropertyMetadata { CoerceValueCallback = CorrectSalary };

            SalaryProperty = DependencyProperty.Register(
                "Salary", typeof(double), typeof(Worker),
                metadataForSalary);

            CityProperty = DependencyProperty.Register(
                "City", typeof(string), typeof(Worker));

           
        } // Fox


        // ---------------------- корректирующие валидаторы ---------------------------------

        // Корректирующая валидация - делегат CoerceValueCallback для возраста сотрудника
        private static object CorrectAge(DependencyObject d, object baseValue)
        {
            // получить новое значение возраста - то, что будет записано
            int currentValue = (int)baseValue;

            // Если возраст меньше 0, вернуть 0
            if (currentValue <= 0)
                return 0;
            // Если возраст больше 190, вернуть 190
            if (currentValue > MaxAge)
                return MaxAge;

            return currentValue;
        } // CorrectAge


        // Корректирующая валидация - делегат CoerceValueCallback для оклада сотрудника
        private static object CorrectSalary(DependencyObject d, object baseValue)
        {
            // получить новое значение оклада - то, что будет записано
            double currentValue = (double)baseValue;

            // Если оклад меньше 0, вернуть 0
            if (currentValue <= 0) 
                return 0;
            // Если оклад больше 1000000, вернуть 1000000
            if (currentValue > MaxSalary) 
                return MaxSalary;

            return currentValue;
        } // CorrectSalary


    }
}
