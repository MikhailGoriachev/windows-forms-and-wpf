﻿using HomeWorkTask1.Models;
using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace HomeWork.Views
{
    /// <summary>
    /// Логика взаимодействия для SelectedWindow.xaml
    /// </summary>
    public partial class SelectedWindow : Window
    {
        // для добавления
        public SelectedWindow()
        {
            InitializeComponent();
            this.Title = "Добавить работника";
            Btn_ok.Content = "Добавить";


        }

        // для редактирования
        public SelectedWindow(Worker worker)
        {
            InitializeComponent();
            this.Title = "Редактировать данные работника";
            Txb_SurName.Text = worker.SurName;
            Txb_Name.Text = worker.Name;
            Txb_Patronymic.Text = worker.Patronymic;
            Txb_Age.Text = worker.Age.ToString();
            Txb_Salary.Text = worker.Salary.ToString();
            Txb_City.Text = worker.City;
            Btn_ok.Content = "Сохранить";

        }

        public Worker GetResult()
        {
            int age = 0;
            double salary = 0; 

            try {

                int.TryParse(Txb_Age.Text, out age);
                double.TryParse(Txb_Salary.Text, out salary);
                if (string.IsNullOrWhiteSpace(Txb_SurName.Text) || string.IsNullOrWhiteSpace(Txb_Name.Text) || string.IsNullOrWhiteSpace(Txb_Patronymic.Text) || string.IsNullOrWhiteSpace(Txb_City.Text))
                    throw new Exception("Все поля дожны быть заполнены!");
            }
            catch (Exception ex)
            {
                Interaction.MsgBox(ex.Message, MsgBoxStyle.Critical | MsgBoxStyle.OkOnly, "Ошибка");
                
            }

            Worker result = new Worker()
            {
                SurName = Txb_SurName.Text,
                Name = Txb_Name.Text,
                Patronymic = Txb_Patronymic.Text,
                Age = age,
                Salary = salary,
                City = Txb_City.Text

            };

            return result;
        }

        private void Click_Close(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }
        private void Click_Ok(object sender, RoutedEventArgs e)
        {
            DialogResult = true;
            Close();
        }

    }
}
