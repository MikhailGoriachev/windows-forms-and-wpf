﻿using HomeWork.Views;
using HomeWorkTask1.Models;
using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace HomeWorkTask1
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private ObservableCollection<Worker> workers;

        public MainWindow()
        {
            InitializeComponent();
             workers = new ObservableCollection<Worker>{
                new Worker {SurName = "Ильина",         Name = "Таисия",            Patronymic = "Владимировна",         Age = 18,   Salary = 25000,      City = "Донецк"       },
                new Worker {SurName = "Казаков",        Name = "Артём",             Patronymic = "Петрович",             Age = 23,   Salary = 25000,      City = "Донецк"       },
                new Worker {SurName = "Белова",         Name = "Екатерина",         Patronymic = "Кирилловна",           Age = 45,   Salary = 30000,      City = "Горловка"     },
                new Worker {SurName = "Быкова",         Name = "Диана",             Patronymic = "Алексеевна",           Age = 290,   Salary = 150000,     City = "Донецк"       },
                new Worker {SurName = "Дементьев",      Name = "Лев",               Patronymic = "Дмитриевич",           Age = 30,   Salary = 30000,      City = "Горловка"     },
                new Worker {SurName = "Смирнова",       Name = "Мила",              Patronymic = "Матвеевна",            Age = 26,   Salary = 50000,      City = "Макеевка"     },
                new Worker {SurName = "Лебедева",       Name = "Софья",             Patronymic = "Марковна",             Age = 37,   Salary = 80000,      City = "Горловка"     },
                new Worker {SurName = "Боброва",        Name = "Арина",             Patronymic = "Сергеевна",            Age = 41,   Salary = 60000,      City = "Донецк"       },
                new Worker {SurName = "Попов",          Name = "Валерий",           Patronymic = "Ильич",                Age = 59,   Salary = 90000,      City = "Макеевка"     },
                new Worker {SurName = "Моргунов",       Name = "Георгий",           Patronymic = "Максимович",           Age = 62,   Salary = 180000,     City = "Донецк"       },
                new Worker {SurName = "Попова",         Name = "Василиса",          Patronymic = "Ильинична",            Age = 18,   Salary = 35000,      City = "Горловка"     },
                new Worker {SurName = "Федотова",       Name = "Вероника",          Patronymic = "Михайловна",           Age = 35,   Salary = 65000,      City = "Макеевка"     },
                new Worker {SurName = "Филиппов",       Name = "Адам",              Patronymic = "Дмитриевич",           Age = 74,   Salary = 65000,      City = "Горловка"     },
                new Worker {SurName = "Никулина",       Name = "Ангелина",          Patronymic = "Владиславовна",        Age = 61,   Salary = 60000,      City = "Донецк"       },
                new Worker {SurName = "Исаев",          Name = "Роман",             Patronymic = "Семёнович",            Age = 49,   Salary = 40000,      City = "Енакиево"     },
                new Worker {SurName = "Рыбакова",       Name = "Алиса",             Patronymic = "Максимовна",           Age = 58,   Salary = 150000,     City = "Донецк"       },
                new Worker {SurName = "Ларионов",       Name = "Матвей",            Patronymic = "Максимович",           Age = 60,   Salary = 150000,     City = "Макеевка"     },
                new Worker {SurName = "Седова",         Name = "Варвара",           Patronymic = "Серафимовна",          Age = 24,   Salary = 30000,      City = "Енакиево"     }

            };

            workers.CollectionChanged += CollectionChangedEventHandler;
           
            DgWorker.ItemsSource = workers;
          

        }

        // обработчик для упорядовачиние коллекции
        private void CollectionChangedEventHandler(object sender, NotifyCollectionChangedEventArgs e)
        {
            // не получается(
        } // CollectionChangedEventHandler

        // завершить работу приложения
        private void Exit_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }

       
        // перейти в окно О программе
        private void AboutWindows_Click(object sender, RoutedEventArgs e)
        {
            AboutWindow aboutWindow = new AboutWindow();
            aboutWindow.ShowDialog();
        }



        // добавить работника
        private void Add_Click(object sender, RoutedEventArgs e)
        {


            try
            {
                SelectedWindow editWindow = new SelectedWindow();

                if (editWindow.ShowDialog() != true) return;

                workers.Add(editWindow.GetResult());
            }
            catch (Exception ex)
            {
                Interaction.MsgBox(ex.Message, MsgBoxStyle.Critical | MsgBoxStyle.OkOnly, "Ошибка");
            }


        }

        // изменить работника
        private void Edit_Click(object sender, RoutedEventArgs e)
        {


            try
            {
                SelectedWindow editWindow = new SelectedWindow((Worker)DgWorker.SelectedItem);

                if (editWindow.ShowDialog() != true) return;

                workers[DgWorker.SelectedIndex] = editWindow.GetResult();

            }
            catch (Exception ex)
            {
                Interaction.MsgBox(ex.Message, MsgBoxStyle.Critical | MsgBoxStyle.OkOnly, "Ошибка");
            }



        }

        // удалить работника
        private void Remove_Click(object sender, RoutedEventArgs e)
        {


            try
            {
                workers.RemoveAt(DgWorker.SelectedIndex);

            }
            catch (Exception ex)
            {
                Interaction.MsgBox(ex.Message, MsgBoxStyle.Critical | MsgBoxStyle.OkOnly, "Ошибка");
            }


        }

















    }
}
