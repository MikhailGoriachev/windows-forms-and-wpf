﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Workers.Models;

namespace Workers.Controllers
{
    internal class WorkersController {
        // коллекция Worker
        private List<Worker> _workers;
        public List<Worker> Workers {
            get => _workers;
            private set => _workers = value;
        } // Workers


        // конструкторы
        public WorkersController():this(new List<Worker>()) {
            Initialize();
        } // WorkersController

        public WorkersController(List<Worker> workers) {
            Workers = workers;
        } // WorkersController


        // формирование коллекции 
        public void Initialize(int n = 12) {
            _workers.Clear();

            for (int i = 0; i < n; i++) {
                _workers.Add(Worker.Generate());
            } // for i
            OrderByName();
        } // Initialize


        // индексатор 
        public Worker this[int index] {
            get => _workers[index];
            set => _workers[index] = value;
        } // indexer


        // получение текущего количества элементов в коллекции
        public int Count => _workers.Count;


        // добавление работника в коллекцию
        public void Add(Worker worker) {
            _workers.Add(worker);
            OrderByName();
        } // Add


        // удаление работника из коллекции
        public void RemoveAt(int index) => _workers.RemoveAt(index);


        // Запрос на упорядочивание коллекции по фамилии, имени, отчеству сотрудника.
        public void OrderByName() =>
            _workers.Sort((x, y) => $"{x.Surname} {x.Name} {x.Patronymic}".CompareTo($"{y.Surname} {y.Name} {y.Patronymic}"));

    } // WorkersController
}
