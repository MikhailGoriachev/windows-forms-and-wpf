﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Workers.Models;

namespace Workers.Views
{
    /// <summary>
    /// Логика взаимодействия для WorkerWindow.xaml
    /// </summary>
    public partial class WorkerWindow : Window
    {
        // объект данных
        private Worker _worker;
        public Worker Worker => _worker;
        public WorkerWindow() {
            InitializeComponent();

            // Программный доступ к ресурсам окна:
            _worker = (Worker)Resources["Worker"];   // получить ссылку на ресурс
        } // WorkerWindow

        public WorkerWindow(Worker worker) {
            InitializeComponent();

            Title = "Редактировать работника";
            BtnOK.Content = "Сохранить";

            // Программный доступ к ресурсам окна:
            _worker = (Worker)Resources["Worker"];   // получить ссылку на ресурс
            _worker.Age = worker.Age;
            _worker.Salary = worker.Salary;
            _worker.Patronymic = worker.Patronymic;
            _worker.Surname = worker.Surname;
            _worker.City = worker.City;
            _worker.Name = worker.Name;
        } // WorkerWindow

        #region Изменение цвета надписи на кнопке при перемещении курсора мыши на кнопку
        private void Button_MouseEnter(object sender, MouseEventArgs e)
        {
            Button btn = e.OriginalSource as Button;
            btn.Foreground = new SolidColorBrush(Color.FromArgb(255, 0, 0, 0));
        } // Button_MouseEnter

        private void Button_MouseLeave(object sender, MouseEventArgs e)
        {
            Button btn = e.OriginalSource as Button;
            btn.Foreground = new SolidColorBrush(Colors.White);
        } // Button_MouseLeave


        #endregion

        private void BtnOK_Click(object sender, RoutedEventArgs e) => DialogResult = true;
    }
    
}
