﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using Workers.Helpers;

namespace Workers.Models
{
    public class Worker : DependencyObject
    {
        public const int MaxAge = 190;          // максимальный возраст
        public const int MaxSalary = 1_000_000; // максимальный оклад

        // фамилия
        public static readonly DependencyProperty SurnameProperty;  // хранилище значений
        public string Surname {
            get => (string)GetValue(SurnameProperty);
            set => SetValue(SurnameProperty, value);
        } // Surname


        // имя
        public static readonly DependencyProperty NameProperty;  // хранилище значений
        public string Name {
            get => (string)GetValue(NameProperty);
            set => SetValue(NameProperty, value);
        } // Name


        // отчество
        public static readonly DependencyProperty PatronymicProperty;  // хранилище значений
        public string Patronymic {
            get => (string)GetValue(PatronymicProperty);
            set => SetValue(PatronymicProperty, value);
        } // Patronymic


        // возраст
        public static readonly DependencyProperty AgeProperty;
        public int Age  {
            get => (int)GetValue(AgeProperty);
            set => SetValue(AgeProperty, value);
        }  // Age
         

        // оклад
        public static readonly DependencyProperty SalaryProperty;
        public int Salary  {
            get => (int)GetValue(SalaryProperty);
            set => SetValue(SalaryProperty, value);
        } // Salary

        // город проживания
        public static readonly DependencyProperty CityProperty;  // хранилище значений
        public string City {
            get => (string)GetValue(CityProperty);
            set => SetValue(CityProperty, value);
        } // City


        // статический конструктор
        static Worker() {
            SurnameProperty = DependencyProperty
                .Register("Surname", typeof(string), typeof(Worker));

            NameProperty = DependencyProperty
                .Register("Name", typeof(string), typeof(Worker));

            PatronymicProperty = DependencyProperty
                .Register("Patronymic", typeof(string), typeof(Worker));

            CityProperty = DependencyProperty
                .Register("City", typeof(string), typeof(Worker));

            // регистрация делегата для корректирующей валидации
            FrameworkPropertyMetadata metadata = new FrameworkPropertyMetadata { CoerceValueCallback = CorrectAge };

            AgeProperty = DependencyProperty
                .Register("Age", typeof(int), typeof(Worker), metadata);

            // регистрация делегата для корректирующей валидации
            metadata = new FrameworkPropertyMetadata { CoerceValueCallback = CorrectSalary };

            SalaryProperty = DependencyProperty
                .Register("Salary", typeof(int), typeof(Worker), metadata);
        } // Worker

        // ---------------------- корректирующие валидаторы ---------------------------------

        // Корректирующая валидация - делегат CoerceValueCallback для оклада работника
        private static object CorrectSalary(DependencyObject d, object baseValue) {
            int currentValue = (int)baseValue;

            if (currentValue < 0) currentValue = 0;
            if (currentValue > MaxSalary) currentValue = MaxSalary;

            return currentValue;
        } // CorrectSalary


        // Корректирующая валидация - делегат CoerceValueCallback для возраста работника
        private static object CorrectAge(DependencyObject d, object baseValue) {
            // получить новое значение возраста - то, что будет записано
            int currentValue = (int)baseValue;

            if (currentValue < 0) currentValue = 0;
            else if (currentValue > MaxAge) currentValue = MaxAge;

            return currentValue;
        } // CorrectAge


        // фабричный метод для создания работника
        public static Worker Generate() {
            // индексы из массивов данных для создания работника
            int indexName = Utils.GetRandom(0, Utils.FullNames.Length - 1);
            int indexCity = Utils.GetRandom(0, Utils.Cities.Length - 1);

            // создание объекта из массивов шаблонных данных, валидация при создании не нужна
            return new Worker {
                Surname = Utils.FullNames[indexName].Surname,
                Name = Utils.FullNames[indexName].Name,
                Patronymic = Utils.FullNames[indexName].Patronymic,
                City = Utils.Cities[indexCity],
                Age = Utils.GetRandom(18, 70),
                Salary = Utils.GetRandom(20_000, 1_000_000),
            };
        } // Generate
    } // Worker
}
