﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Workers.Controllers;
using Workers.Models;
using Workers.Helpers;

namespace Workers.Views
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private WorkersController _workersController;
        public MainWindow() {
            InitializeComponent();
            _workersController = new WorkersController();
            DgvWorkers.ItemsSource = _workersController.Workers;

            TbStatusBar.Text = $"Количество работников в коллекции: {_workersController.Workers.Count}";
        } // MainWindow

        private void Exit_Click(object sender, RoutedEventArgs e) => Close();

        // выполнение формирования данных
        private void New_Command(object sender, RoutedEventArgs e) {
            _workersController.Initialize(Utils.GetRandom(12, 20));

            DgvWorkers.ItemsSource = null;
            DgvWorkers.ItemsSource = _workersController.Workers;

            TbStatusBar.Text = $"Количество работников в коллекции: {_workersController.Workers.Count}";
        } // New_Command

        private void AddWorker_Command(object sender, RoutedEventArgs e) {
            WorkerWindow workerWindow = new WorkerWindow();

            if (workerWindow.ShowDialog() != true) return;

            _workersController.Add(workerWindow.Worker);

            DgvWorkers.ItemsSource = null;
            DgvWorkers.ItemsSource = _workersController.Workers;

            TbStatusBar.Text = $"Количество работников в коллекции: {_workersController.Workers.Count}";
        } // AddWorker_Command

        private void EditWorker_Command(object sender, RoutedEventArgs e) {
            int index = DgvWorkers.SelectedIndex;
            if (index == -1) return;

            WorkerWindow workerWindow = new WorkerWindow(_workersController[index]);

            if (workerWindow.ShowDialog() != true) return;

            _workersController[index] = workerWindow.Worker;

            DgvWorkers.ItemsSource = null;
            DgvWorkers.ItemsSource = _workersController.Workers;
        } // EditWorker_Command

        private void DeleteWorker_Command(object sender, RoutedEventArgs e)  {
            int index = DgvWorkers.SelectedIndex;
            if (index == -1) return;

            _workersController.RemoveAt(index);

            DgvWorkers.ItemsSource = null;
            DgvWorkers.ItemsSource = _workersController.Workers;

            TbStatusBar.Text = $"Количество работников в коллекции: {_workersController.Workers.Count}";
            DgvWorkers.SelectedIndex = index != _workersController.Workers.Count? index: index - 1;
        } // DeleteWorker_Command

    } // MainWindow
}
