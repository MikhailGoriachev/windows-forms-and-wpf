﻿using Homework.Helpers;
using System;
using System.Windows;


namespace Homework.Models
{
    // модель подписчика 
    public class Subscriber : DependencyObject  {
        // Фамилия И.О.
        public static readonly DependencyProperty FullNameProperty;  // хранилище значений
        public string FullName {
            get => (string)GetValue(FullNameProperty);
            set => SetValue(FullNameProperty, value);
        } // FullName

        // улица
        public static readonly DependencyProperty StreetProperty;  // хранилище значений
        public string Street {
            get => (string)GetValue(StreetProperty);
            set => SetValue(StreetProperty, value);
        } // Street

        // дом
        public static readonly DependencyProperty BuildingProperty;  // хранилище значений
        public string Building {
            get => (string)GetValue(BuildingProperty);
            set => SetValue(BuildingProperty, value);
        } // Building

        // квартира
        public static readonly DependencyProperty FlatProperty;  // хранилище значений
        public int Flat  {
            get => (int)GetValue(FlatProperty);
            set => SetValue(FlatProperty, value);
        } // Flat

        // Адрес подписчика
        public string Address { get => $"{Street}, д. {Building}, кв. {Flat}"; }

        // вид издания
        public static readonly DependencyProperty PubTypeProperty;  // хранилище значений
        public string PubType {
            get => (string)GetValue(PubTypeProperty);
            set => SetValue(PubTypeProperty, value);
        } // PubType

        // индекс издания
        public static readonly DependencyProperty PubIndexProperty;  // хранилище значений
        public int PubIndex {
            get => (int)GetValue(PubIndexProperty);
            set => SetValue(PubIndexProperty, value);
        } // PubIndex

        // наименование (название) издания
        public static readonly DependencyProperty TitleProperty;  // хранилище значений
        public string Title {
            get => (string)GetValue(TitleProperty);
            set => SetValue(TitleProperty, value);
        } // Title

        // дата начала подписки
        public static readonly DependencyProperty DateStartProperty;  // хранилище значений
        public DateTime DateStart {
            get => (DateTime)GetValue(DateStartProperty);
            set => SetValue(DateStartProperty, value);
        } // DateStart

        // период подписки
        public static readonly DependencyProperty DurationProperty;  // хранилище значений
        public int Duration {
            get => (int)GetValue(DurationProperty);
            set => SetValue(DurationProperty, value);
        } // Duration

        public Subscriber() { }
        public Subscriber (SubscriberSerializeModel subscriber) {
            FullName = subscriber.FullName;
            Street = subscriber.Street;
            Building = subscriber.Building;
            Flat = subscriber.Flat;
            PubType = subscriber.PubType;
            PubIndex = subscriber.PubIndex;
            Title = subscriber.Title;
            DateStart = subscriber.DateStart;
            Duration = subscriber.Duration;
        } // Subscriber 

        // статический конструктор
        static Subscriber() {
            FullNameProperty = DependencyProperty
                .Register("FullName", typeof(string), typeof(Subscriber));

            StreetProperty = DependencyProperty
                .Register("Street", typeof(string), typeof(Subscriber));

            BuildingProperty = DependencyProperty
                .Register("Building", typeof(string), typeof(Subscriber));

            FlatProperty = DependencyProperty
                .Register("Flat", typeof(int), typeof(Subscriber));

            PubTypeProperty = DependencyProperty
                .Register("PubType", typeof(string), typeof(Subscriber)); 

            PubIndexProperty = DependencyProperty
                .Register("PubIndex", typeof(int), typeof(Subscriber));

            TitleProperty = DependencyProperty
                .Register("Title", typeof(string), typeof(Subscriber));

            DateStartProperty = DependencyProperty
                .Register("DateStart", typeof(DateTime), typeof(Subscriber));

            DurationProperty = DependencyProperty
                .Register("Duration", typeof(int), typeof(Subscriber));
        } // Subscriber

        // фабричный метод для создания подписчика
        public static Subscriber Generate()  {
            // индексы из массивов данных для создания телевизора
            int indexFullName = Utils.GetRandom(0, Utils.FullNames.Length - 1);
            int indexStreet = Utils.GetRandom(0, Utils.Streets.Length - 1);
            int indexPublication = Utils.GetRandom(0, Utils.Publications.Length - 1);
            int duration = Utils.GetRandom(0, 3);

            // создание объекта из массивов шаблонных данных, валидация при создании не нужна
            return new Subscriber {
                FullName = Utils.FullNames[indexFullName],
                Building = $"{Utils.GetRandom(1, 200)}",
                DateStart = new DateTime(Utils.GetRandom(2020, 2022), Utils.GetRandom(1, 12), Utils.GetRandom(1, 28)),
                Flat = Utils.GetRandom(1, 500),
                Street = Utils.Streets[indexStreet],
                PubIndex = Utils.GetRandom(10000, 99999),
                Title = Utils.Publications[indexPublication].Name,
                PubType = Utils.Publications[indexPublication].pubType,
                Duration = duration == 0 ? 1 : duration == 1 ? 3 : duration == 2 ? 6 : duration == 3 ? 12 :0,
            };
        } // Television
    } // Subscriber
}
