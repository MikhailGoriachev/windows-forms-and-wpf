﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;

namespace Homework.Models
{
    // класс подписки для сериализации
    [DataContract]
    public class SubscriberSerializeModel {
        [DataMember]
        public string FullName { get; set; }

        // улица
        [DataMember]
        public string Street { get; set; }

        // дом
        [DataMember]
        public string Building { get; set; }

        // квартира
        [DataMember]
        public int Flat { get; set; }

        // вид издания
        [DataMember]
        public string PubType { get; set; }

        // индекс издания
        [DataMember]
        public int PubIndex { get; set; }

        // наименование (название) издания
        [DataMember]
        public string Title { get; set; }

        // дата начала подписки
        [DataMember]
        public DateTime DateStart { get; set; }

        // период подписки
        [DataMember]
        public int Duration { get; set; }

        public SubscriberSerializeModel(Subscriber subscriber) {
            FullName = subscriber.FullName;
            Street = subscriber.Street;
            Building = subscriber.Building;
            Flat = subscriber.Flat;
            PubType = subscriber.PubType;
            PubIndex = subscriber.PubIndex;
            Title = subscriber.Title;
            DateStart = subscriber.DateStart;
            Duration = subscriber.Duration;
        } // PublicationsController 

    } // SubscriberSerializeModel
}
