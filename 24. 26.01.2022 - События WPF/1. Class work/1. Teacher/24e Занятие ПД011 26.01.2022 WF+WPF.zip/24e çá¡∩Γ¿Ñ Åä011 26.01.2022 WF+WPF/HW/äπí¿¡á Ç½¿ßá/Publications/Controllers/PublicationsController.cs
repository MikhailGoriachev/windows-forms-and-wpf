﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Json;
using System.Text;
using System.Threading.Tasks;
using Homework.Models;

namespace Homework.Controllers
{
    /*
     * Реализация функционала приложения   
    Сортировка:
     * •	Упорядочивание по индексу издания
     * •	Упорядочивание по адресу подписчика
     * •	Упорядочивание по убыванию периода подписки
    Выборка:
     * •	Подписки по выбранному типу издания
     * •	Подписки по выбранному периоду
     * •	Подписки по выбранной фамилии и инициалам подписчика
     */
    public class PublicationsController
    {
        private string _fileName;
        public string FileName { get => _fileName; set => _fileName = value; }

        // коллекция Subscriber
        private List<Subscriber> _subscribers;
        public List<Subscriber> Subscribers {
            get => _subscribers;
            set => _subscribers = value;
        } // Televisions


        // конструкторы
        public PublicationsController():this(new List<Subscriber>()) {
            _fileName = "publications.json";
            Initialize();
        } // PublicationsController

        public PublicationsController(List<Subscriber> subscribers) {
            Subscribers = subscribers;
        } // PublicationsController


        // формирование коллекции 
        public void Initialize(int n = 12) {
            _subscribers.Clear();

            for (int i = 0; i < n; i++) {
                _subscribers.Add(Subscriber.Generate());
            } // for i
            SerializeData();
        } // Initialize


        // индексатор 
        public Subscriber this[int index] {
            get => _subscribers[index];
            set => _subscribers[index] = value;
        } // indexer


        // получение текущего количества элементов в коллекции
        public int Count => _subscribers.Count;


        // добавление подписчика в коллекцию
        public void Add(Subscriber subscriber) {
            _subscribers.Add(subscriber);
            SerializeData();
        } // Add


        // удаление подписчика из коллекции
        public void RemoveAt(int index) {
            _subscribers.RemoveAt(index);
            SerializeData();
        } // RemoveAt 


        // Запрос на упорядочивание коллекции по индексу издания
        public List<Subscriber> OrderByIndex() { 
            List<Subscriber> list = new List<Subscriber>(_subscribers);
            list.Sort((x, y)=>x.PubIndex.CompareTo(y.PubIndex));
            return list;
        } // OrderByIndex

        // Запрос на упорядочивание коллекции по адресу подписчика
        public List<Subscriber> OrderByAddress() {
            List<Subscriber> list = new List<Subscriber>(_subscribers);
            list.Sort((x, y) => x.Address.CompareTo(y.Address));
            return list;
        } // OrderByAddress

        // Запрос на упорядочивание коллекции по убыванию периода подписки
        public List<Subscriber> OrderByDurationDesc() {
            List<Subscriber> list = new List<Subscriber>(_subscribers);
            list.Sort((x, y) => y.Duration.CompareTo(x.Duration));
            return list;
        } // OrderByDurationDesc

        // Запрос на упорядочивание коллекции по типу издания
        public List<Subscriber> OrderByPubType() {
            List<Subscriber> list = new List<Subscriber>(_subscribers);
            list.Sort((x, y) => x.PubType.CompareTo(y.PubType));
            return list;
        } // OrderByPubType

        // выборка данных из коллекции по выбранному типу издания
        public List<Subscriber> SelectWherePubType(string pubType) =>
            _subscribers.FindAll(x => x.PubType == pubType);

        // выборка данных из коллекции по выбранному периоду
        public List<Subscriber> SelectWhereDuration(int duration) =>
            _subscribers.FindAll(x => x.Duration == duration);

        // выборка данных из коллекции по выбранной фамилии и инициалам подписчика
        public List<Subscriber> SelectWhereFullName(string fullName) =>
            _subscribers.FindAll(x => x.FullName == fullName);

        // выборка данных из коллекции по выбранному названию издания
        public List<Subscriber> SelectWhereTitle(string title) =>
            _subscribers.FindAll(x => x.Title == title);

        // список подписчиков из коллекции
        public List<string> GetFullNames() {
            Dictionary<string, int> fullNames = new Dictionary<string, int>();

            _subscribers.ForEach(s => fullNames[s.FullName] = 0);

            return fullNames.Keys.ToList();
        } // GetFullNames


        // список видов изданий из коллекци
        public List<string> GetPubTypes() {
            Dictionary<string, int> pubTypes = new Dictionary<string, int>();

            _subscribers.ForEach(s => pubTypes[s.PubType] = 0);

            return pubTypes.Keys.ToList();
        } // GetPubTypes


        // список наименований изданий из коллекци
        public List<string> GetTitles() {
            Dictionary<string, int> titles = new Dictionary<string, int>();

            _subscribers.ForEach(s => titles[s.Title] = 0);

            return titles.Keys.ToList();
        } // GetTitles

        // -----------------------------------------------------------------------------------

        // сериализация данных в формате JSON
        public void SerializeData() {
            DataContractJsonSerializer jsonFormatter = new DataContractJsonSerializer(typeof(List<SubscriberSerializeModel>));

            List<SubscriberSerializeModel> temp = new List<SubscriberSerializeModel>();
            _subscribers.ForEach(x => temp.Add(new SubscriberSerializeModel(x)));
            // Запись объекта в JSON-файл
            using (FileStream fs = new FileStream(FileName, FileMode.Create)) {
                jsonFormatter.WriteObject(fs, temp);
            } // using
        } // SerializeData

        // десериализация данных из формата JSON
        public void DeserializeData() {
            DataContractJsonSerializer jsonFormatter = new DataContractJsonSerializer(typeof(List<SubscriberSerializeModel>));

            List<SubscriberSerializeModel> temp = new List<SubscriberSerializeModel>();
            // Читаем коллекцию из JSON-файла
            using (FileStream fs = new FileStream(FileName, FileMode.OpenOrCreate)) {
                temp = (List<SubscriberSerializeModel>)jsonFormatter.ReadObject(fs);
            } // using

            _subscribers.Clear();
            temp.ForEach(x => _subscribers.Add(new Subscriber(x)));
        } // DeserializeData

        // -----------------------------------------------------------------------------------
    } // class PublicationsController
}
