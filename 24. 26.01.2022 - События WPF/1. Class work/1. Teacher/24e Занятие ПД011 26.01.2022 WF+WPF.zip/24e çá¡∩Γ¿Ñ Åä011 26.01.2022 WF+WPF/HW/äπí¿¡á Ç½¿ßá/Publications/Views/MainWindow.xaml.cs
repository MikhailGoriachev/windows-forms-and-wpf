﻿using Homework.Controllers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Homework.Models;
using Homework.Helpers;
using Publications.Views;
using Microsoft.Win32;
using System.IO;

namespace Homework.Views { 
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        // контроллер
        private PublicationsController _publicationsController;

        public MainWindow() : this(new PublicationsController()) { }
        public MainWindow(PublicationsController publicationsController) {
            InitializeComponent();

            _publicationsController = publicationsController;

            // TbxAddress.Text =
            //     $"  Ремонтная мастерская \"{_publicationsController.RepairShop.Title}\", " +
            //     $"{_publicationsController.RepairShop.Address}";

            BindCollection(_publicationsController.Subscribers, DgvPublications);
            TbStatusBar.Text = $"Кол-во подписок: {_publicationsController.Subscribers.Count}";
        } // RepairShopWindow

        #region Изменение цвета надписи на кнопке при перемещении курсора мыши на кнопку
        private void Button_MouseEnter(object sender, MouseEventArgs e) {
            Button btn = e.OriginalSource as Button;
            btn.Foreground = new SolidColorBrush(Color.FromArgb(255, 0, 0, 0));
        } // Button_MouseEnter

        private void Button_MouseLeave(object sender, MouseEventArgs e) {
            Button btn = e.OriginalSource as Button;
            btn.Foreground = new SolidColorBrush(Colors.White);
        } // Button_MouseLeave
        #endregion

        // выполнение привязки коллекции
        private void BindCollection(List<Subscriber> list, DataGrid dataGrid)  {
            // остановить привязку
            dataGrid.ItemsSource = null;

            // задать привязку
            dataGrid.ItemsSource = list;
        } // BindCollection
        private void Exit_Click(object sender, RoutedEventArgs e) => Close();

        // Открыть окно со сведениями о приложении и разработчике
        private void About_Click(object sender, RoutedEventArgs e) {
            AboutWindow aboutWindow = new AboutWindow();
            aboutWindow.ShowDialog();
        } // About_Click

        // выполнение формирования данных  
        private void New_Command(object sender, RoutedEventArgs e) {
            TbcPublications.SelectedItem = MainTab;

            _publicationsController.Initialize(Utils.GetRandom(12, 15));

            BindCollection(_publicationsController.Subscribers, DgvPublications);
            BindCollection(new List<Subscriber>(), DgvSorted);
            BindCollection(new List<Subscriber>(), DgvSelected);
            TbStatusBar.Text = $"Кол-во подписок: {_publicationsController.Subscribers.Count}";
        } // New_Command

        // сортировка коллекции по индексу издания
        private void OrderByIndex_Command(object sender, RoutedEventArgs e)  {
            BindCollection(_publicationsController.OrderByIndex(), DgvSorted);

            TbcPublications.SelectedItem = SortedTab;
        } // OrderByIndex_Command


        // сортировка коллекции по адресу
        private void OrderByAddress_Command(object sender, RoutedEventArgs e) {
            BindCollection(_publicationsController.OrderByAddress(), DgvSorted);

            TbcPublications.SelectedItem = SortedTab;
        } // OrderByAddress_Command


        // сортировка коллекции по убыванию длительности подписки
        private void OrderByDurationDesc_Command(object sender, RoutedEventArgs e) {
            BindCollection(_publicationsController.OrderByDurationDesc(), DgvSorted);

            TbcPublications.SelectedItem = SortedTab;
        } // OrderByDurationDesc_Command

        // сортировка коллекции по типу издания
        private void OrderByPubType_Command(object sender, RoutedEventArgs e) {
            BindCollection(_publicationsController.OrderByPubType(), DgvSorted);

            TbcPublications.SelectedItem = SortedTab;
        } // OrderByPubType_Command

        // выборка коллекции по выбранному типу издания
        private void SelectPubType_Command(object sender, RoutedEventArgs e) {
            List<string> pubTypes = _publicationsController.GetPubTypes();
            pubTypes.Sort();
            // создание окна выбора, передача в окно списка 
            ChoiceWindow ChoiceWindow = new ChoiceWindow(pubTypes, "Вид издания для выборки:");

            if (ChoiceWindow.ShowDialog() == false) return;

            BindCollection(_publicationsController.SelectWherePubType(ChoiceWindow.Choice), DgvSelected);
            TbcPublications.SelectedItem = SelectedTab;
        } // SelectPubType_Command

        // выборка  по выбранному периоду
        private void SelectDuration_Command(object sender, RoutedEventArgs e) {
            // получить список из коллекции
            List<string> durations = new List<string>(new string[] {"1", "3", "6", "12" });

            // создание окна выбора, передача в окно списка 
            ChoiceWindow ChoiceWindow = new ChoiceWindow(durations, "Длительность подписки для выборки:");

            if (ChoiceWindow.ShowDialog() == false) return;

            BindCollection(_publicationsController.SelectWhereDuration(int.Parse(ChoiceWindow.Choice)), DgvSelected);
            TbcPublications.SelectedItem = SelectedTab;
        } // SelectDuration_Command

        // выборка по выбранной фамилии и инициалам подписчика
        private void SelectFullNames_Command(object sender, RoutedEventArgs e) {
            // получить список фамилий из коллекции
            List<string> fullNames = _publicationsController.GetFullNames();
            fullNames.Sort();
            // создание окна выбора, передача в окно списка 
            ChoiceWindow ChoiceWindow = new ChoiceWindow(fullNames, "Подписчик для выборки:");

            if (ChoiceWindow.ShowDialog() == false) return;

            BindCollection(_publicationsController.SelectWhereFullName(ChoiceWindow.Choice), DgvSelected);
            TbcPublications.SelectedItem = SelectedTab;
        } // SelectFullNames_Command

        // выборка по выбранному названию издания
        private void SelectTitle_Command(object sender, RoutedEventArgs e)  {
            // получить список из коллекции
            List<string> titles = _publicationsController.GetTitles();
            titles.Sort();
            // создание окна выбора, передача в окно списка 
            ChoiceWindow ChoiceWindow = new ChoiceWindow(titles, "Наименование для выборки:");

            if (ChoiceWindow.ShowDialog() == false) return;

            BindCollection(_publicationsController.SelectWhereTitle(ChoiceWindow.Choice), DgvSelected);
            TbcPublications.SelectedItem = SelectedTab;
        } // SelectTitle_Command

        // Выдача 
        private void DeletePublication_Command(object sender, RoutedEventArgs e) {
            TbcPublications.SelectedItem = MainTab;
            int index = DgvPublications.SelectedIndex;
            if (index == -1) return;

            _publicationsController.RemoveAt(index);

            BindCollection(_publicationsController.Subscribers, DgvPublications);
            TbStatusBar.Text = $"Кол-во подписок: {_publicationsController.Subscribers.Count}";
            DgvPublications.SelectedIndex = index != _publicationsController.Subscribers.Count ? index : index - 1;
        } // DeletePublication_Command

        // Добавление подписки
        private void AddTelevision_Command(object sender, RoutedEventArgs e) {
            TbcPublications.SelectedItem = MainTab;
            // создать окно для ввода параметров
            PublicationWindow publicationWindow = new PublicationWindow();

            // показать окно ввода модально, если форма завершается не по ОК, молча уходим
            if (publicationWindow.ShowDialog() == false) return;

            // добавить телевизор в коллекцию ремонтируемых телевизоров
            _publicationsController.Add(publicationWindow.Subscriber);

            BindCollection(_publicationsController.Subscribers, DgvPublications);
            TbStatusBar.Text = $"Кол-во подписок: {_publicationsController.Subscribers.Count}";
            DgvPublications.SelectedIndex = _publicationsController.Subscribers.Count - 1;
        } // AddTelevision_Command

        // редактирование данных 
        private void EditPublication_Command(object sender, RoutedEventArgs e) {
            TbcPublications.SelectedItem = MainTab;
            int index = DgvPublications.SelectedIndex;
            if (index == -1) return;
            // создать окно для ввода параметров телевизора
            PublicationWindow publicationWindow = new PublicationWindow(_publicationsController.Subscribers[index]);

            // показать окно ввода модально, если форма завершается не по ОК, молча уходим
            if (publicationWindow.ShowDialog() == false) return;

            // редактировать телевизор 
            _publicationsController.Subscribers[index] = publicationWindow.Subscriber;

            BindCollection(_publicationsController.Subscribers, DgvPublications);
            DgvPublications.SelectedIndex = index;
            _publicationsController.SerializeData();
        } // EditTelevision_Command

        // Открытие файла
        private void Open_Command(object sender, RoutedEventArgs e)  {
            OpenFileDialog ofd = new OpenFileDialog
            {
                Multiselect = false,
                Title = "Файл данных для загрузки",
                Filter = "Файлы JSON (*.json)|*.json",
                FilterIndex = 0,
                InitialDirectory = AppDomain.CurrentDomain.BaseDirectory
            };

            if (ofd.ShowDialog() != true) return;
            _publicationsController.FileName = ofd.FileName;
            _publicationsController.DeserializeData();
            BindCollection(_publicationsController.Subscribers, DgvPublications);
            TbStatusBar.Text = $"Кол-во подписок: {_publicationsController.Subscribers.Count}";
        } // Open_Click

        // Сохранить как
        private void SaveAs_Command(object sender, RoutedEventArgs e) {
            SaveFileDialog sfd = new SaveFileDialog {
                Title = "Файл данных для coхранения",
                Filter = "Файлы JSON (*.json)|*.json",
                FilterIndex = 0,
                InitialDirectory = AppDomain.CurrentDomain.BaseDirectory
            };

            if (sfd.ShowDialog() != true) return;
            _publicationsController.FileName = sfd.FileName;
            _publicationsController.SerializeData();
            TbStatusBar.Text = $"Файл сохранён! ";
        } // SaveAs_Command

        // Сохранить
        private void Save_Command(object sender, RoutedEventArgs e) {
            _publicationsController.SerializeData();
            TbStatusBar.Text = $"Файл сохранён!";
        } // Save_Command
    }
}
