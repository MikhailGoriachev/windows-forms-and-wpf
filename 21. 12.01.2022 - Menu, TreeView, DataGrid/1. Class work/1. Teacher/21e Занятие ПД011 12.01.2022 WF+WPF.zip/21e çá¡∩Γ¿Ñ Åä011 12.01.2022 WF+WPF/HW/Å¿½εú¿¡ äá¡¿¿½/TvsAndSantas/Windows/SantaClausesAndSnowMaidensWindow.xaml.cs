﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using TvsAndSantas.Models;

namespace TvsAndSantas.Windows
{
    /// <summary>
    /// Логика взаимодействия для SantaClausesAndSnowMaidensWindow.xaml
    /// </summary>
    public partial class SantaClausesAndSnowMaidensWindow : Window
    {
        public SantaClausesAndSnowMaidensWindow()
        {
            InitializeComponent();

            List<SnowMaiden> snowMaidens = new List<SnowMaiden>()
            {
                new SnowMaiden(),
                new SnowMaiden(){ AmountVerses = 19, AmountGames = 19},
                new SnowMaiden(){ AmountVerses = 18, AmountGames = 18},
                new SnowMaiden(){ AmountVerses = 17, AmountGames = 17},
                new SnowMaiden(){ AmountVerses = 16, AmountGames = 16},
                new SnowMaiden(){ AmountVerses = 15, AmountGames = 15},
                new SnowMaiden(){ AmountVerses = 14, AmountGames = 14},
                new SnowMaiden(){ AmountVerses = 13, AmountGames = 13},
                new SnowMaiden(){ AmountVerses = 12, AmountGames = 12},
                new SnowMaiden(){ AmountVerses = 11, AmountGames = 11},
                new SnowMaiden(){ AmountVerses = 10, AmountGames = 10},
                new SnowMaiden(){ AmountVerses = 9, AmountGames = 9},
                new SnowMaiden(){ AmountVerses = 8, AmountGames = 8},
                new SnowMaiden(){ AmountVerses = 7, AmountGames = 7}
            };
            ListSnowMaidents.ItemsSource = snowMaidens;
        }
    }
}
