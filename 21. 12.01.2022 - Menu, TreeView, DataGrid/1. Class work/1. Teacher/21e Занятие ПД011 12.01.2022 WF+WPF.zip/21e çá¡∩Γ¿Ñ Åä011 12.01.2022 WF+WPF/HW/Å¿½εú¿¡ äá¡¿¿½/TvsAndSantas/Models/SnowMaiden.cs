﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TvsAndSantas.Models
{
    //класс для представления данных актрисы, играющей роль Снегурочки
    class SnowMaiden
    {
        public string Surname { get; set; }         //фамилия
        public string Name { get; set; }            //имя
        public string Patronymic { get; set; }      //отчество
        public string Color { get; set; }           //цвет полушубка
        public int AmountVerses { get; set; }       //количество стихотворений, которые знает актриса
        public int AmountGames { get; set; }        //количество игр для детей, которые может организовать актриса

        public SnowMaiden()
        {
            Surname = "Савельева";
            Name = "Светлана";
            Patronymic = "Игоревна";
            Color = "Красный";
            AmountGames = 20;
            AmountVerses = 20;
        }
    }
}
