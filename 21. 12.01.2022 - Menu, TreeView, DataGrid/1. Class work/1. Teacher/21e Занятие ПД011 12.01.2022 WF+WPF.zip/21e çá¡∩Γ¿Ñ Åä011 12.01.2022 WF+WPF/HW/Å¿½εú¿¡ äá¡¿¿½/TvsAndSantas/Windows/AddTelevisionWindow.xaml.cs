﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using TvsAndSantas.Models;

namespace TvsAndSantas.Windows
{
    /// <summary>
    /// Логика взаимодействия для AddTelevisionWindow.xaml
    /// </summary>
    public partial class AddTelevisionWindow : Window
    {
        public Television tv;
        public AddTelevisionWindow()
        {
            InitializeComponent();
            BtnOk.Click += MakeTv_Command;
        }

        public AddTelevisionWindow(Television inputTv)
        {
            InitializeComponent();

            tv = inputTv;

            TxtBxBrand.Text = inputTv.Brand;
            TxtBxType.Text = inputTv.Type;
            TxtBxDiagonal.Text = inputTv.Diagonal.ToString();
            TxtBxDefect.Text = inputTv.Defect;
            TxtBxMaster.Text = inputTv.Master;
            TxtBxClient.Text = inputTv.Client;
            TxtBxCost.Text = inputTv.RepairCost.ToString();

            BtnOk.Click += EditTv_Command;
        }

        private void MoveWindow_Command(object sender, MouseButtonEventArgs e) => DragMove();

        private void EditTv_Command(object sender, RoutedEventArgs e)
        {
            try
            {

                tv.Brand = TxtBxBrand.Text;
                tv.Type = TxtBxType.Text;
                tv.Diagonal = int.Parse(TxtBxDiagonal.Text);
                tv.Defect = TxtBxDefect.Text;
                tv.Master = TxtBxMaster.Text;
                tv.Client = TxtBxClient.Text;
                tv.RepairCost = int.Parse(TxtBxCost.Text);
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message, "Ошибка!", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            Close();
        }
        private void MakeTv_Command(object sender, RoutedEventArgs e)
        {
            try
            {
                tv = new Television(
                TxtBxBrand.Text,
                TxtBxType.Text,
                int.Parse(TxtBxDiagonal.Text),
                TxtBxDefect.Text,
                TxtBxMaster.Text,
                TxtBxClient.Text,
                int.Parse(TxtBxCost.Text));
                
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message, "Ошибка!", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            Close();
        }

        private void CloseWindow_Command(object sender, RoutedEventArgs e)
        {
            tv = null;
            Close();
        }
    }
}
