﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TvsAndSantas.Models
{
    public class Controller
    {
        //мастерская тв
        public RepairShop Shop { get; set; }

        //конструктор
        public Controller()
        {
            Shop = new RepairShop();
        }

        //создать новую коллекцию тв
        public List<Television> CreteNewList()
        {
            Shop.Tvs = RepairShop.CreateTVs();
            return Shop.Tvs;
        }

        //получить коллекцию тв
        public List<Television> Tvs() => Shop.Tvs;
        //получить заголовок
        public string Header() => Shop.GetHeader();
        //добавить тв
        public void AddTv(Television tv) => Shop.Tvs.Add(tv);
        //сортировка
        public void Sort(Comparison<Television> comparison) => Shop.Tvs.Sort(comparison);
        //индексатор
        public Television this[int index]
        {
            get => Shop.Tvs[index]; 
            set => Shop.Tvs[index] = value; 
        }
    }
}
