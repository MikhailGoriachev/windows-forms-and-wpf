﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using TvsAndSantas.Models;

namespace TvsAndSantas.Windows
{
    /// <summary>
    /// Логика взаимодействия для ShowTvsWindow.xaml
    /// </summary>
    public partial class ShowTvsWindow : Window
    {
        private List<Television> televisions;
        public ShowTvsWindow()
        {
            InitializeComponent();
        }

        public ShowTvsWindow(List<Television> tvs, string mode)
        {
            InitializeComponent();
            televisions = tvs;
            LViewTvs.ItemsSource = televisions;

            switch (mode)
            {
                case "cost":
                    BtnSearch.Click += SearchByCost_Command;
                    break;
                case "master":
                    BtnSearch.Click += SearchByMaster_Command;
                    TxBlkNotice.Text = "Поиск по мастеру.";
                    break;
                case "diagonal":
                    BtnSearch.Click += SearchByDiagonal_Command;
                    TxBlkNotice.Text = "Поиск по диагонали.";
                    break;
            }

        }

        private void SearchByCost_Command(object sender, RoutedEventArgs e)
        {
            //временный массив в который будут обираться объекты по условию
            List<Television> temp = new List<Television>();

            //если пользователь корректно ввел cтоимость
            if (int.TryParse(TxBxInput.Text, out int cost))
            {
                //ищем телевизоры с совпадающей стоимостью
                temp = televisions.FindAll(x => x.RepairCost == cost);

                //если что то нашли - показываем
                if (temp.Count != 0)
                {
                    LViewTvs.ItemsSource = temp;
                    TxBlkNotice.Text = $"Найдено {temp.Count} записей, у которых стоимость ремонта равна {cost}.";
                }
                else
                    TxBlkNotice.Text = $"Записей, у которых стоимость ремонта равна {cost} не найдено!";
            }
            else //если не корректно ввели стоимость
            {
                //уведомляем об этом
                TxBlkNotice.Text = "Некорректно введена стоимость ремонта! Попробуйте еще раз.";
                //чистим список
                LViewTvs.ItemsSource = null;
            }
        }
        private void SearchByMaster_Command(object sender, RoutedEventArgs e)
        {
            //временный массив в который будут обираться объекты по условию
            List<Television> temp = new List<Television>();

            string master = TxBxInput.Text;

            //если пользователь корректно ввел cтоимость
            if (!string.IsNullOrWhiteSpace(master))
            {
                //ищем телевизоры с совпадающей стоимостью
                temp = televisions.FindAll(x => x.Master == master);

                //если что то нашли - показываем
                if (temp.Count != 0)
                {
                    LViewTvs.ItemsSource = temp;
                    TxBlkNotice.Text = $"Найдено {temp.Count} записей, мастер {master}.";
                }
                else
                    TxBlkNotice.Text = $"Записей, c мастером {master} не найдено!";
            }
            else //если не корректно ввели стоимость
            {
                //уведомляем об этом
                TxBlkNotice.Text = "Некорректно введена ФИО мастера! Попробуйте еще раз.";
                //чистим список
                LViewTvs.ItemsSource = null;
            }
        }
        private void SearchByDiagonal_Command(object sender, RoutedEventArgs e)
        {
            //временный массив в который будут обираться объекты по условию
            List<Television> temp = new List<Television>();

            //если пользователь корректно ввел диагональ
            if (int.TryParse(TxBxInput.Text, out int diagonal))
            {
                //ищем телевизоры с совпадающей диагональю
                temp = televisions.FindAll(x => x.Diagonal == diagonal);

                //если что то нашли - показываем
                if (temp.Count != 0)
                {
                    LViewTvs.ItemsSource = temp;
                    TxBlkNotice.Text = $"Найдено {temp.Count} записей, у которых диагональ равна {diagonal}.";
                }
                else
                    TxBlkNotice.Text = $"Записей, у которых диагональ равна {diagonal} не найдено!";
            }
            else //если не корректно ввели диагональ
            {
                //уведомляем об этом
                TxBlkNotice.Text = "Некорректно введена даигональ телевизора! Попробуйте еще раз.";
                //чистим список
                LViewTvs.ItemsSource = null;
            }
        }

        private void HideWindow_Command(object sender, RoutedEventArgs e) => WindowState = WindowState.Minimized;

        private void FullWindow_Command(object sender, RoutedEventArgs e)
        => WindowState = WindowState == WindowState.Maximized ? WindowState.Normal : WindowState.Maximized;

        private void ExitWindow_Command(object sender, RoutedEventArgs e) => Close();

        private void MoveWindow_Command(object sender, MouseButtonEventArgs e) => DragMove();

    }
}
