﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TvsAndSantas.Models;

namespace TvsAndSantas.Models
{
    //класс мастерской по ремонту телевизоров
    public class RepairShop
    {
        private string _name;           //название ремонтной мастерской
        private string _address;        //адрес ремонтной мастерской




        //свойтства
        public string Address
        {
            get => _address;
            set => _address = !string.IsNullOrWhiteSpace(value) ? value :
                    throw new Exception("Поле адреса мастерской не заполнено!");
        }
        public string Name
        {
            get => _name;
            set => _name = !string.IsNullOrWhiteSpace(value) ? value :
                  throw new Exception("Поле названия мастерской не заполнено!");
        }
        public List<Television> Tvs { get; set; }
        public List<string> Masters { get; set; }
        public List<string> Clients { get; set; }

        //конструктор
        public RepairShop()
        {
            Tvs = CreateTVs();
            _name = "Гарант-Сервис";
            _address = "пр. Мира, 8";
            Masters = new List<string>{
            "Андреев П.А.",
            "Петров Ю.А.",
            "Судиловский И.М.",
            "Харин А.И."
            };
            Clients = new List<string>
            {
                "Ляшенко И.В.",
                "Чуб А.А.",
                "Чижов Ю.А.",
                "Игренко А.В.",
                "Перов П.В."
            };
        }

        //создает строку с названием и адресом мастерской
        public string GetHeader() => _name + " " + _address;

        //фабрика коллекции телевизоров
        static public List<Television> CreateTVs()
        {
            List<Television> temp = new List<Television>();
            int n = Utils.random.Next(10, 20);

            for (int i = 0; i < n; i++)
                temp.Add(Television.Create());

            return temp;
        }

        public override string ToString() => $"{_name}, {_address}";
    }
}

