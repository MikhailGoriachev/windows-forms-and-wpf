﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TvsAndSantas.Models
{
    class Utils
    {
        static public Random random = new Random();
        static public int id = 0;
    }
}
