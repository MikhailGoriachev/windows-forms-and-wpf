﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TvsAndSantas.Models
{
    //класс для представления данных актера, играющего роль Деда Мороза
    class SantaClaus
    {
        public string Surname { get; set; }         //фамилия
        public string Name { get; set; }            //имя
        public string Patronymic { get; set; }      //отчество
        public string Color { get; set; }           //цвет полушубка
        public int AmountGifts { get; set; }           //количество подарков, которые способен перенести актер

    }
}
