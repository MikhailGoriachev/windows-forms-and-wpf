﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace TvsAndSantas.Models
{
    //класс заявки на ремонт телевизора
    public class Television
    {


        public int _id;             //идентфикационный номер
        private string _brand;      //производитель
        private string _type;       //тип телевизора
        private int _diagonal;      //диагональ экрана
        private string _defect;     //строка с описанием дефекта
        private string _master;     //фамилия и инициалами мастера
        private string _client;     //фамилия и инициалы владельца
        private int _repairCost;    //стоимость ремонта

        //свойства
        public int Id => _id;
        public string Brand
        {
            get { return _brand; }
            set
            {
                _brand = !string.IsNullOrWhiteSpace(value) ? value :
                  throw new Exception("Поле бренд не заполнено!");
            }
        }
        public string Type
        {
            get { return _type; }
            set
            {
                _type = !string.IsNullOrWhiteSpace(value) ? value :
                  throw new Exception("Поле тип не заполнено!");
            }
        }
        public int Diagonal
        {
            get { return _diagonal; }
            set
            {
                _diagonal = value > 0 ? value :
                  throw new Exception("Диагональ не может быть отрицательной!");
            }
        }
        public string Defect
        {
            get { return _defect; }
            set
            {
                _defect = !string.IsNullOrWhiteSpace(value) ? value :
                  throw new Exception("Поле описания деффекта не заполнено!");
            }
        }
        public string Master
        {
            get { return _master; }
            set
            {
                _master = !string.IsNullOrWhiteSpace(value) ? value :
                  throw new Exception("Поле ответственного мастера не заполнено!"); ;
            }
        }
        public string Client
        {
            get { return _client; }
            set
            {
                _client = !string.IsNullOrWhiteSpace(value) ? value :
                  throw new Exception("Поле ФИО клиента не заполнено!"); ;
            }
        }
        public int RepairCost
        {
            get { return _repairCost; }
            set
            {
                _repairCost = value > 0 ? value :
                  throw new Exception("Стоимость не может быть отрицательной!");
            }
        }

        //присваивание id
        private int getId()
        {
            Utils.id++;
            return Utils.id;
        }

        //конструкторы
        public Television()
        {
            _id = getId();
            _brand = "Sony";
            _type = "OLED";
            _diagonal = 40;
            _defect = "Полосы на экране";
            _master = "Судиловский И.М.";
            _client = "Ляшенко В.И.";
            _repairCost = 5000;
        }
        public Television(string brand, string type, int diagonal, string defect,
            string master, string client, int repairCost)
        {
            _id = getId();
            Brand = brand;
            Type = type;
            Diagonal = diagonal;
            Defect = defect;
            Master = master;
            Client = client;
            RepairCost = repairCost;
        }

        //фабрика телевизоров
        static public Television Create()
        {
            string[] brands = {
                "Bravis",
                "JVC",
                "Lenovo",
                "LG",
                "Panasonic",
                "Philips",
                "Samsung",
                "Sony",
                "Toshiba",
                "Xiaomi"
            };
            string[] types =
            {
                "LCD",
                "MicroLED",
                "NanoCell",
                "OLED",
                "QLED"
            };
            string[] defects =
            {
                "Проблемы с включением и выключением питания",
                "Неисправность матрицы",
                "Неисправная материнская плата",
                "Неисправный пульт управления",
                "Проблемы со звуком"
            };
            string[] masters =
            {
                "Андреев П.А.",
                "Петров Ю.А.",
                "Судиловский И.М.",
                "Харин А.И."
            };
            string[] clients =
            {
                "Ляшенко И.В.",
                "Чуб А.А.",
                "Чижов Ю.А.",
                "Игренко А.В.",
                "Перов П.В."
            };

            return new Television(
                brands[Utils.random.Next(0, brands.Length)],
                types[Utils.random.Next(0, types.Length)],
                Utils.random.Next(1, 100),
                defects[Utils.random.Next(0, defects.Length)],
                masters[Utils.random.Next(0, masters.Length)],
                clients[Utils.random.Next(0, clients.Length)],
                Utils.random.Next(1, 20) * 100
                );
        }

        public override string ToString() => $" id{_id} клиент: {_client} к мастеру {_master}";
        public string ToTable
            => $" {_id,-3}│ {_brand,-10} │ {_type,-8} | {_diagonal,-2} | {_master,-17}| {_client,-17}| {_repairCost,5}₽| {_defect}";
    }
}
