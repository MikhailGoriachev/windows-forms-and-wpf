﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Forms;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using TvsAndSantas.Models;

namespace TvsAndSantas.Windows
{
    /// <summary>
    /// Логика взаимодействия для RepairTvsWindow.xaml
    /// </summary>
    public partial class RepairTvsWindow : Window
    {
        public Controller controller;
        public RepairTvsWindow()
        {
            InitializeComponent();

            controller = new Controller();

            LViewTvs.ItemsSource = controller.Tvs();
            TxtBlkAddress.Text = controller.Header();
        }

        private void CreateTvs_Command(object sender, RoutedEventArgs e)
        {
            LViewTvs.ItemsSource = controller.CreteNewList();
            TxBlkNotice.Text = "Создана новая коллекция телевизоров!";
        }

        private void AddTv_Command(object sender, RoutedEventArgs e)
        {
            AddTelevisionWindow window = new AddTelevisionWindow();
            window.ShowDialog();
            if (window.tv != null)
            {
                //добавление телевизора в коллекцию
                controller.AddTv(window.tv);
                TxBlkNotice.Text = "Добавлена запись: " + window.tv.ToString();
                LViewTvs.ItemsSource = null;
                LViewTvs.ItemsSource = controller.Shop.Tvs;
            }
        }

        private void EditTv_Command(object sender, RoutedEventArgs e)
        {
            AddTelevisionWindow window;
            int index = LViewTvs.SelectedIndex;
            if (index != -1)
            {
                window = new AddTelevisionWindow(controller[index]);
                window.ShowDialog();
                if (window.tv != null)
                {
                    controller[index] = window.tv;
                    TxBlkNotice.Text = "Отредактирована запись: " + window.tv.ToString();
                    LViewTvs.ItemsSource = null;
                    LViewTvs.ItemsSource = controller.Shop.Tvs;
                }
            }
        }

        private void SortByBrand_Command(object sender, RoutedEventArgs e)
        {
            controller.Sort((Television x, Television y) => x.Brand.CompareTo(y.Brand));
            LViewTvs.ItemsSource = null;
            LViewTvs.ItemsSource = controller.Tvs();
        }

        private void SortByDiagonal_Command(object sender, RoutedEventArgs e)
        {
            controller.Sort((Television x, Television y) => y.Diagonal.CompareTo(x.Diagonal));
            LViewTvs.ItemsSource = null;
            LViewTvs.ItemsSource = controller.Tvs();
        }

        private void SortByMaster_Command(object sender, RoutedEventArgs e)
        {
            controller.Sort((Television x, Television y) => x.Master.CompareTo(y.Master));
            LViewTvs.ItemsSource = null;
            LViewTvs.ItemsSource = controller.Tvs();
        }
        
        private void SortByOwner_Command(object sender, RoutedEventArgs e)
        {
            controller.Sort((Television x, Television y) => x.Client.CompareTo(y.Client));
            LViewTvs.ItemsSource = null;
            LViewTvs.ItemsSource = controller.Tvs();
        }

        private void ShowByCost_Command(object sender, RoutedEventArgs e) 
            => new ShowTvsWindow(controller.Tvs(), "cost").ShowDialog();

        private void ShowByMaster_Command(object sender, RoutedEventArgs e)
            => new ShowTvsWindow(controller.Tvs(), "master").ShowDialog();

        private void ShowByDiagonal_Command(object sender, RoutedEventArgs e)
            => new ShowTvsWindow(controller.Tvs(), "diagonal").ShowDialog();

        private void HideWindow_Command(object sender, RoutedEventArgs e) => WindowState = WindowState.Minimized;

        private void FullWindow_Command(object sender, RoutedEventArgs e)
        => WindowState = WindowState == WindowState.Maximized ? WindowState.Normal : WindowState.Maximized;

        private void ExitWindow_Command(object sender, RoutedEventArgs e) => Close();

        private void MoveWindow_Command(object sender, MouseButtonEventArgs e) => DragMove();
    }
}
