﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HomeWork.Models.Actors
{
    // класс,описующий Деда Мороза
    class Santa : Actors
    {
        // Фамилия      
        private string _surName;
        public string SurName
        {
            get { return _surName; }
            set {
                if (string.IsNullOrWhiteSpace(value))
                    throw new Exception("Santa: ошибка фамилии актера");
                _surName = value; }
        }

        // Имя
        private string _name;
        public string Name
        {
            get { return _name; }
            set
            {
                if (string.IsNullOrWhiteSpace(value))
                    throw new Exception("Santa: ошибка имени актера");
                _name = value;
            }
        }

        // Отчество 
        private string _patronymic;
        public string Patronymic
        {
            get { return _patronymic; }
            set
            {
                if (string.IsNullOrWhiteSpace(value))
                    throw new Exception("Santa: ошибка отчества актера");
                _patronymic = value;
            }
        }

        // цвет полушубка
        private string _coatColor;
        public string CoatColor
        {
            get { return _coatColor; }
            set
            {
                if (string.IsNullOrWhiteSpace(value))
                    throw new Exception("Santa: ошибка цвета наряда актера");
                _coatColor = value;
            }
        }

        // количество подарков, которые способен перенести актер
        private int _param1;

        public int Param1
        {
            get { return _param1; }
            set {
                if (value <= 0)
                    throw new Exception("Santa: ошибка количества подарков, которые способен перенести актер"); 
                _param1 = value; }
        }     

        // строковое представление параметров актер
        public string Params => "";
    }
}
