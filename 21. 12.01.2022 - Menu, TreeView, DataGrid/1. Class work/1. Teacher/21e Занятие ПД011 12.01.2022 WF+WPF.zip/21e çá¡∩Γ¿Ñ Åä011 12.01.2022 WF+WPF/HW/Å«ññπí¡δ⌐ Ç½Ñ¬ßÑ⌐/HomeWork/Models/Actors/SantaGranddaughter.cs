﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HomeWork.Models.Actors
{
    class SnowMaiden : Actors
    {
        // Фамилия      
        private string _surName;
        public string SurName
        {
            get { return _surName; }
            set
            {
                if (string.IsNullOrWhiteSpace(value))
                    throw new Exception("SantaGranddaughter: ошибка фамилии актрисы");
                    _surName = value;
            }
        }

        // Имя
        private string _name;
        public string Name
        {
            get { return _name; }
            set
            {
                if (string.IsNullOrWhiteSpace(value))
                    throw new Exception("SantaGranddaughter: ошибка имени актрисы");
                _name = value;
            }
        }

        // Отчество 
        private string _patronymic;
        public string Patronymic
        {
            get { return _patronymic; }
            set
            {
                if (string.IsNullOrWhiteSpace(value))
                    throw new Exception("SantaGranddaughter: ошибка отчества актрисы");
                _patronymic = value;
            }
        }

        // цвет полушубка
        private string _coatColor;
        public string CoatColor
        {
            get { return _coatColor; }
            set
            {
                if (string.IsNullOrWhiteSpace(value))
                    throw new Exception("SantaGranddaughter: ошибка цвета наряда актрисы");
                _coatColor = value;
            }
        }

        // количество стихотворений, которые знает актриса
        private int _param1;

        public int Param1
        {
            get { return _param1; }
            set { 
                if(value<=0)
                    throw new Exception("SantaGranddaughter: ошибка количества стихотворений, которые знает актриса");
                _param1 = value; }
        }


        // количество игр для детей, которые может организовать актриса
        private int _param2;

        public int Param2
        {
            get { return _param2; }
            set {
                if (value <= 0)
                    throw new Exception("SantaGranddaughter: ошибка количества игр для детей, которые может организовать актриса"); 
                _param2 = value; }
        }


        // строковое представление параметров актер
        public string Params => "";

    }
}
