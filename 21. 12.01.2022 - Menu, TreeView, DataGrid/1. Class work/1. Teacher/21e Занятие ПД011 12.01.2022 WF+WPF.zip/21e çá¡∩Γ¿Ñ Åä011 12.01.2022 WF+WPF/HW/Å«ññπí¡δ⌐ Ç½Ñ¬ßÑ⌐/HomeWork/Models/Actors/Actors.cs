﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HomeWork.Models.Actors
{
    // интерфейс для актеров
    public interface Actors
    {
        // Фамилия
        string SurName { get; set; }

        // Имя
        string Name { get; set; }

        // Отчество 
        string Patronymic { get; set; }

        // цвет полушубка
        string CoatColor { get; set; }

        // параметр 1
        int Param1 { get; }

        // строковое представление параметров актеров
        string Params { get; }

    }
}
