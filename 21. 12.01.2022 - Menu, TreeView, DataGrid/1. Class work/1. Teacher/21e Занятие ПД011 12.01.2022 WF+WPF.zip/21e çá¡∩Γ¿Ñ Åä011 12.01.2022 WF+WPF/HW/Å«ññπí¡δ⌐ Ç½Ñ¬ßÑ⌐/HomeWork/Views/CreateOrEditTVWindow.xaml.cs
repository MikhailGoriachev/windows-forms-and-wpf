﻿using HomeWork.Models.RepairShop;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace HomeWork.Views
{
    /// <summary>
    /// Логика взаимодействия для CreateOrEditTVWindow.xaml
    /// </summary>
    public partial class CreateOrEditTVWindow : Window
    {
        // для добавления
        public CreateOrEditTVWindow()
        {
            InitializeComponent();
            Title = "Добавить телевизор";
            Btn_ok.Content = "Добавить";

        }

        // для изменения
        public CreateOrEditTVWindow(Television tv)
        {
            InitializeComponent();
            Title = "Изменить телевизор";
            Txb_type.Text = tv.Type;
            Txb_diagonal.Text = tv.Diagonal.ToString();
            Txb_defect.Text = tv.Defect;
            Txb_repairName.Text = tv.RepairerName;
            Txb_ownerName.Text = tv.OwnerName;
            Txb_price.Text = tv.RepairCost.ToString();

            Btn_ok.Content = "Сохранить";

        }

        public Television GetTV() {

            return new Television(
                    Txb_type.Text,
                    double.Parse(Txb_diagonal.Text),
                    Txb_defect.Text,
                    Txb_repairName.Text,
                    Txb_ownerName.Text,
                    double.Parse(Txb_price.Text)
                    );
        
        
        }

        private void Click_Close(object sender, RoutedEventArgs e)
        {
            DialogResult = false;

            Close();
        }
        private void Click_Ok(object sender, RoutedEventArgs e)
        {
            DialogResult = true;
            Close();
        }


    }
}
