﻿using HomeWork.Helpers;
using HomeWork.Models.RepairShop;
using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace HomeWork.Views
{
    /// <summary>
    /// Логика взаимодействия для ViewRepairShopWindow.xaml
    /// </summary>
    public partial class ViewRepairShopWindow : Window
    {
        RepairShop repairShop;


        public ViewRepairShopWindow()
        {
            InitializeComponent();
            repairShop = new RepairShop() { RepairShopName = "Быстрый ремонт", RepairShopAddress = "ул.Артема 112а" };
            // привязка коллекции телевизоров к listView
            LsvTV.ItemsSource = repairShop.TeleList;
            Cbx_reapair.ItemsSource = ToDictionary().Values;
        }

        private Dictionary<string, string> ToDictionary() {

            Dictionary<string, string> repairNames = new Dictionary<string, string>();

            foreach (var item in repairShop.TeleList)
            {
                if(!repairNames.ContainsKey(item.RepairerName)) repairNames.Add(item.RepairerName, item.RepairerName);                
            }

            return repairNames;


        }



        // заполнение колекции
        private void Click_InitCollection(object sender, RoutedEventArgs e)
        {
            repairShop.CreateTVList(Utils.GetRandom(12, 16));
            Cbx_reapair.ItemsSource = ToDictionary().Values;


        }


        // добавить телевизор
        private void Click_AddTV(object sender, RoutedEventArgs e)
        {
            try
            {
                CreateOrEditTVWindow editWindow = new CreateOrEditTVWindow();

                if (editWindow.ShowDialog() != true) return;

                repairShop.TeleList.Add(editWindow.GetTV());
            }
            catch (Exception ex)
            {
                Interaction.MsgBox(ex.Message, MsgBoxStyle.Critical | MsgBoxStyle.OkOnly, "Ошибка");
            }
           
        }

        // изменить телевизор
        private void Click_EditTV(object sender, RoutedEventArgs e)
        {
            try
            {
                CreateOrEditTVWindow editWindow = new CreateOrEditTVWindow((Television)LsvTV.SelectedItem);

                if (editWindow.ShowDialog() != true) return;

                repairShop.TeleList[LsvTV.SelectedIndex] = editWindow.GetTV();

            }
            catch (Exception ex)
            {
                Interaction.MsgBox(ex.Message, MsgBoxStyle.Critical | MsgBoxStyle.OkOnly, "Ошибка");
            }

            

        }

        // удалить телевизор
        private void Click_DeleteTV(object sender, RoutedEventArgs e)
        {
            try
            {
                repairShop.TeleList.RemoveAt(LsvTV.SelectedIndex);

            }
            catch (Exception ex)
            {
                Interaction.MsgBox(ex.Message, MsgBoxStyle.Critical | MsgBoxStyle.OkOnly, "Ошибка");
            }
           
        }

        // сортировка
        private void Select_Sorts(object sender, RoutedEventArgs e)
        {
            ComboBox cmb = (ComboBox)sender;
            switch (cmb.SelectedItem.ToString())
            {

                case "По производителю и типу":
                    repairShop.SortByType();
                    break;

                case "По убыванию диагонали экрана":
                    repairShop.SortByDiagonal();
                    break;

                case "По мастеру, выполняющему ремонт":
                    repairShop.SortByRepairName();
                    break;

                case "По владельцу телевизора":
                    repairShop.SortByOwnerName();
                    break;



            }

        }

        // выборки
        private void Select_selection(object sender, RoutedEventArgs e)
        {
            SelectionTVWindow selectWindow;

            try
            {
                          

                switch (Cbx_selection.SelectedItem.ToString())
                {


                    case "Коллекция телевизоров с минимальной стоимостью ремонта":
                        selectWindow = new SelectionTVWindow(repairShop.SelectMinRepairCost(), "Коллекция телевизоров с минимальной стоимостью ремонта");
                        selectWindow.ShowDialog();
                        break;

                    case "Коллекция телевизоров, ремонтируемых выбранным мастером":
                        Cbx_reapair.IsEnabled = true;
                        Cbx_reapair.SelectedItem = 1;
                        selectWindow = new SelectionTVWindow(repairShop.SelectRepairName(Cbx_reapair.SelectedItem.ToString()), "Коллекция телевизоров, ремонтируемых выбранным мастером");
                        selectWindow.ShowDialog();
                        break;

                    case "Коллекция телевизоров, с заданной диагональю экрана":
                        Txb_diagonal.IsEnabled = true;
                        Txb_diagonal.Text = repairShop.TeleList[0].Diagonal.ToString();
                        selectWindow = new SelectionTVWindow(repairShop.SelectDiagonal(double.Parse(Txb_diagonal.Text)), "Коллекция телевизоров, с заданной диагональю экрана");
                        selectWindow.ShowDialog();
                        break;

                    default:
                        break;

                }

            }
            catch (Exception ex)
            {

                Interaction.MsgBox(ex.Message, MsgBoxStyle.Critical | MsgBoxStyle.OkOnly, "Ошибка");
            }
            

        }

        // выбор выборки
        private void Select_selection_type(object sender, RoutedEventArgs e)
        {
            try
            {

           
                ComboBox cmb = (ComboBox)sender;
                switch (cmb.SelectedItem.ToString())
                {

                    case "Коллекция телевизоров, ремонтируемых выбранным мастером":
                        Cbx_reapair.IsEnabled = true;
                        Txb_diagonal.IsEnabled = false;
                        Txb_diagonal.Text = "";
                        Cbx_reapair.ItemsSource = ToDictionary().Values;
                        Cbx_reapair.SelectedItem = 1;                   
                        break;

                    case "Коллекция телевизоров, с заданной диагональю экрана":
                        Txb_diagonal.IsEnabled = true;
                        Cbx_reapair.IsEnabled = false;
                        Txb_diagonal.Text = repairShop.TeleList[0].Diagonal.ToString();                    
                        break;

                    default:
                        Cbx_reapair.IsEnabled = false;
                        Cbx_reapair.ItemsSource = "";
                        Txb_diagonal.IsEnabled = false;
                        Txb_diagonal.Text = "";
                        break;

                }

            }
            catch (Exception ex)
            {

                Interaction.MsgBox(ex.Message, MsgBoxStyle.Critical | MsgBoxStyle.OkOnly, "Ошибка");
            }

        }

    }
}
