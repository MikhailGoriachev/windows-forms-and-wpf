﻿using Homework.Helpers;
using Homework.Controllers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Homework.Models.Task2;

namespace Homework.Views
{
    /// <summary>
    /// Логика взаимодействия для RepairShopWindow.xaml
    /// </summary>
    public partial class RepairShopWindow : Window
    {
        // контроллер для работы с формой
        private RepairShopController _repairShopController;

        public RepairShopWindow() : this(new RepairShopController()){}
        public RepairShopWindow(RepairShopController repairShopController) {
            InitializeComponent();

            _repairShopController = repairShopController;

            TbxAddress.Text =
                $"  Ремонтная мастерская \"{_repairShopController.RepairShop.Title}\", " +
                $"{_repairShopController.RepairShop.Address}";

            BindCollection(_repairShopController.RepairShop.Televisions, LsvTelevision);
        } // RepairShopWindow

        #region Изменение цвета надписи на кнопке при перемещении курсора мыши на кнопку
        private void Button_MouseEnter(object sender, MouseEventArgs e) {
            Button btn = e.OriginalSource as Button;
            btn.Foreground = new SolidColorBrush(Color.FromArgb(255, 0, 0, 0));
        } // Button_MouseEnter

        private void Button_MouseLeave(object sender, MouseEventArgs e) {
            Button btn = e.OriginalSource as Button;
            btn.Foreground = new SolidColorBrush(Colors.White);
        } // Button_MouseLeave
        #endregion

        // выполнение привязки коллекции
        private void BindCollection(List<Television> list, ListView listView) {
            // остановить привязку
            listView.ItemsSource = null;

            // задать привязку
            listView.ItemsSource = list;
        } // BindCollection

        private void Exit_Click(object sender, RoutedEventArgs e) => Close();

        // выполнение формирования данных ремонтной мастерской 
        private void NewRepairShop_Command(object sender, RoutedEventArgs e) {
            TbxAddress.Text =
                $"  Ремонтная мастерская \"{_repairShopController.RepairShop.Title}\", " +
                $"{_repairShopController.RepairShop.Address}";

            _repairShopController.RepairShop.Initialize(Utils.GetRandom(12, 15));

            BindCollection(_repairShopController.RepairShop.Televisions, LsvTelevision);
        } // NewRepairShop_Command

         // сортировка коллекции телевизоров по производителю и типу
        private void OrderByBrand_Command(object sender, RoutedEventArgs e) {
            _repairShopController.OrderByBrand();

            BindCollection(_repairShopController.RepairShop.Televisions, LsvTelevision);

            // формирование заголовка поля вывода данных о телевизорах
            TbxAddress.Text =
                $"  Ремонтная мастерская \"{_repairShopController.RepairShop.Title}\", " +
                $"{_repairShopController.RepairShop.Address}, телевизоры по производителю и типу";
        } // OrderByBrand_Command


        // сортировка коллекции телевизоров по убыванию диагонали экрана
        private void OrderByDiagonalDesc_Command(object sender, RoutedEventArgs e) {
            _repairShopController.OrderByDiagonalDesc();

            BindCollection(_repairShopController.RepairShop.Televisions, LsvTelevision);

            // формирование заголовка поля вывода данных о телевизорах
            TbxAddress.Text =
                $"  Ремонтная мастерская \"{_repairShopController.RepairShop.Title}\", " +
                $"{_repairShopController.RepairShop.Address}, телевизоры по убыванию диагонали экрана";
        } // OrderByDiagonalDesc_Command


        // сортировка коллекции телевизоров по мастеру, выполняющему ремонт
        private void OrderByArtisan_Command(object sender, RoutedEventArgs e) {
            _repairShopController.OrderByArtisan();

            BindCollection(_repairShopController.RepairShop.Televisions, LsvTelevision);

            // формирование заголовка поля вывода данных о телевизорах
            TbxAddress.Text =
                $"  Ремонтная мастерская \"{_repairShopController.RepairShop.Title}\", " +
                $"{_repairShopController.RepairShop.Address}, телевизоры по мастеру, выполняющему ремонт";
        } // OrderByArtisan_Command


        // сортировка коллекции телевизоров по владельцу телевизора
        private void OrderByOwner_Command(object sender, RoutedEventArgs e) {
            _repairShopController.OrderByOwner();

            BindCollection(_repairShopController.RepairShop.Televisions, LsvTelevision);

            // формирование заголовка поля вывода данных о телевизорах
            TbxAddress.Text =
                $"  Ремонтная мастерская \"{_repairShopController.RepairShop.Title}\", " +
                $"{_repairShopController.RepairShop.Address}, телевизоры по владельцу телевизора";
        } // OrderByOwner_Command

        // выборка коллекции телевизоров с минимальной
        // стоимостью ремонта
        private void SelectMinPrice_Command(object sender, RoutedEventArgs e) {
            SelectionsWindow selectionsWindow = 
                new SelectionsWindow(_repairShopController.SelectWhereMinPrice(), 
                $"  Ремонтная мастерская \"{_repairShopController.RepairShop.Title}\", " +
                $"{_repairShopController.RepairShop.Address}, телевизоры с минимальной стоимостью ремонта");

            selectionsWindow.ShowDialog();
        } // SelectMinPrice_Command

        // выборка ремонтов, выполняемых мастером, команда для меню  
        private void SelectArtisan_Command(object sender, RoutedEventArgs e) {
            // получить список фамилий из коллекции ремонтов
            List<string> artisans = _repairShopController.GetArtitans();

            // создание окна выбора мастера, передача в окно списка мастеров
            ChoiceWindow ChoiceWindow = new ChoiceWindow(artisans, "Мастер для выборки:");

            if (ChoiceWindow.ShowDialog() == false) return;

            // выбор мастера произведен, получим мастера, построим выборку
            SelectionsWindow selectionsWindow =
                new SelectionsWindow(_repairShopController.SelectWhereArtisan(ChoiceWindow.Choice),
                $"  Ремонтная мастерская \"{_repairShopController.RepairShop.Title}\", " +
                $"{_repairShopController.RepairShop.Address}");

            selectionsWindow.ShowDialog();
        } // SelectArtisan_Command

        // выборка телевизоров, с заданной диагональю экрана 
        private void SelectDiagonal_Command(object sender, RoutedEventArgs e) {
            // получить список диагоналей из коллекции ремонтов
            List<string> diagonals = _repairShopController.GetDiagonals();

            // создание окна выбора мастера, передача в окно списка мастеров
            ChoiceWindow ChoiceWindow = new ChoiceWindow(diagonals, "Диагональ для выборки:");

            if (ChoiceWindow.ShowDialog() == false) return;

            // выбор диагонали произведен, построим выборку
            SelectionsWindow selectionsWindow =
                new SelectionsWindow(_repairShopController.SelectWhereDiagonal(double.Parse(ChoiceWindow.Choice)),
                $"  Ремонтная мастерская \"{_repairShopController.RepairShop.Title}\", " +
                $"{_repairShopController.RepairShop.Address}");

            selectionsWindow.ShowDialog();
        } // SelectDiagonal_Command

        // прием телевизора в ремонт
        private void AddTelevision_Command(object sender, RoutedEventArgs e) {
            // создать окно для ввода параметров телевизора, принимаемого в ремонт
            TelevisionWindow televisionWindow = new TelevisionWindow();

            // показать окно ввода модально, если форма завершается не по ОК, молча уходим
            if(televisionWindow.ShowDialog() == false) return;

            // добавить телевизор в коллекцию ремонтируемых телевизоров
            _repairShopController.RepairShop.Add(televisionWindow.Television);

            BindCollection(_repairShopController.RepairShop.Televisions, LsvTelevision);
        } // AddTelevision_Command

        // ]редактирование данных телевизора в ремонте
        private void EditTelevision_Command(object sender, RoutedEventArgs e) {
            int index = LsvTelevision.SelectedIndex;
            if (index == -1) return;
            // создать окно для ввода параметров телевизора
            TelevisionWindow televisionWindow = new TelevisionWindow("Редактирование телевизора", "Сохранить");
            televisionWindow.Television = _repairShopController.RepairShop.Televisions[index];

            // показать окно ввода модально, если форма завершается не по ОК, молча уходим
            if (televisionWindow.ShowDialog() == false) return;

            // редактировать телевизор 
            _repairShopController.RepairShop.Televisions[index] = televisionWindow.Television;

            BindCollection(_repairShopController.RepairShop.Televisions, LsvTelevision);
        } // EditTelevision_Command

    }
}
