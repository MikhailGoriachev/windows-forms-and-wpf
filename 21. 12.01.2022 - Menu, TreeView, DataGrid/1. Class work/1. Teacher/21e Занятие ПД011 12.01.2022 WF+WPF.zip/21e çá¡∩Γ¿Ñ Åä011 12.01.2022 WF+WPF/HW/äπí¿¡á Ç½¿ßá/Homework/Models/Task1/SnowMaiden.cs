﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Homework.Models.Task1
{
    // класс для представления данных актрисы, играющей роль Снегурочки:
    // фамилия, имя, отчество, цвет полушубка, количество стихотворений,
    // которые знает актриса, количество игр для детей, которые может организовать актриса
    internal class SnowMaiden {
        // фамилия
        private string _surname;
        public string Surname {
            get => _surname; 
            set { if (String.IsNullOrWhiteSpace(value)) throw new Exception("SnowMaiden: Некорректное значение фамилии!");
                _surname = value; } // set
        } // Surname

        // имя
        private string _name;
        public string Name {
            get => _name; 
            set { if (String.IsNullOrWhiteSpace(value)) throw new Exception("SnowMaiden: Некорректное значение имени!");
                _name = value; } // set
        } // Name


        // отчество
        private string _patronymic;
        public string Patronymic {
            get => _patronymic;
            set { if (String.IsNullOrWhiteSpace(value)) throw new Exception("SnowMaiden: Некорректное значение отчества!");
                _patronymic = value;
            } // set
        } // Patronymic

        // цвет полушубка
        private string _color;
        public string Color  {
            get => _color;
            set {
                if (String.IsNullOrWhiteSpace(value)) throw new Exception("SnowMaiden: Некорректное значение цветa полушубка!");
                _color = value; } // set
        } // Color

        // количество стихотворений, которые знает актриса
        private int _poetries;
        public int Poetries {
            get => _poetries;
            set { if(value < 0) throw new Exception("SnowMaiden: Некорректное значение количества стихотворений, которые знает актриса!");
                _poetries = value; }
        } // Poetries

        // количество игр для детей, которые может организовать актриса
        private int _games;
        public int Games {
            get => _games;
            set { if(value < 0) throw new Exception("SnowMaiden: Некорректное значение количества игр для детей, которые может организовать актриса!");
                _games = value; }
        } // Games
    } // SnowMaiden
}
