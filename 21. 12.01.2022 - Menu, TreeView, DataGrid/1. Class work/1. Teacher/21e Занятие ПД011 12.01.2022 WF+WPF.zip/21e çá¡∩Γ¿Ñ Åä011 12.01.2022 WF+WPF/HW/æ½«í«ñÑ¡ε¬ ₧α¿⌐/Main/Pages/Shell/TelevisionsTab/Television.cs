﻿using Stylet;


namespace Main.Pages.Shell.TelevisionsTab
{
	public sealed class Television : PropertyChangedBase
	{
		public string Producer { get; set; }
		public int Diagonal { get; set; }
		public string Defect { get; set; }
		public string Repairer { get; set; }
		public string Owner { get; set; }
		public decimal RepairCost { get; set; }
	}
}