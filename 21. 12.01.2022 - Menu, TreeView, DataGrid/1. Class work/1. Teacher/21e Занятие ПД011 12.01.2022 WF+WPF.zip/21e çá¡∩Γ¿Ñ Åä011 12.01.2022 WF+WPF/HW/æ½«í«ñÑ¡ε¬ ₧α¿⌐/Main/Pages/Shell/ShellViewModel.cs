﻿using Main.Pages.Shell.TelevisionsTab;
using Stylet;


namespace Main.Pages.Shell
{
	public sealed class ShellViewModel : Conductor<Screen>.Collection.OneActive
	{
		public ShellViewModel() { }


		public ShellViewModel(IWindowManager manager) =>
			ActivateItem(new TelevisionsTabViewModel(manager));
	}
}