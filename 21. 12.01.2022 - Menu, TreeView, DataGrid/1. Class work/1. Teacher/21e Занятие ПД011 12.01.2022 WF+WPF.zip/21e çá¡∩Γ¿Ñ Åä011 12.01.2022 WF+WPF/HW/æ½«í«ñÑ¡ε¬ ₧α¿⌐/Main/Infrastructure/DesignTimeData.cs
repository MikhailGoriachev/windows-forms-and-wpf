﻿using System.Collections.Generic;
using Main.Pages.Shell.TelevisionsTab;


namespace Main.Infrastructure
{
	public static class DesignTimeData
	{
		public static readonly Television[] Televisions;


		static DesignTimeData()
		{
			Televisions = new TelevisionFactory().Make(7).ToArray();
		}
	}
}