﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Santas.Models
{
    public class RepairShop
    {
        public string Name { get; set; } // название мастерской

        public string Address { get; set; } // адрес мастерской

        public ObservableCollection<Television> Teles { get; set; }= new ObservableCollection<Television>();  //коллекция телевизоров
    }
}
