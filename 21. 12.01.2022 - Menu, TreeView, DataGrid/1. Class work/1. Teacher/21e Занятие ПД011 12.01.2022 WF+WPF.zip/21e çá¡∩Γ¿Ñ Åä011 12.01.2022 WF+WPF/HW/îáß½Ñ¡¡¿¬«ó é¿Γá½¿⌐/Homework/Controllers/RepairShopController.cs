﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Homework.Models.TvRepairShop;


namespace Homework.Controllers
{
	public class RepairShopController
	{
		// объект для обработки
		private RepairShop _repairShop;

		public RepairShop RepairShop
		{
			get => _repairShop;
			private set => _repairShop = value;
		}

		// конструкторы
		public RepairShopController() : this(new RepairShop())
		{
			_repairShop.Initialize();
		}
		public RepairShopController(RepairShop repairShop)
		{
			_repairShop = repairShop;
		}

		// получить список мастеров
		public List<string> GetRepairers => _repairShop.GetRepairers;

		// получить список диагоналей
		public List<string> GetDiagonal => _repairShop.GetDiagonals;
		

		#region Сортировки

		// Запрос на упорядочивание коллекции по производителю и типу
		public void OrderByBrand() => RepairShop.OrderBy((t1, t2) =>
			t1.BrandType.CompareTo(t2.BrandType));

		public static void OrderByBrand(List<Television> list) => RepairShop.OrderBy(list, (t1, t2) =>
			t1.BrandType.CompareTo(t2.BrandType));

		// Запрос на упорядочивание коллекции по убыванию диагонали экрана
		public void OrderByDiagonalDesc() => RepairShop.OrderBy((t1, t2) =>
			t2.Diagonal.CompareTo(t1.Diagonal));

		public static void OrderByDiagonalDesc(List<Television> list) => RepairShop.OrderBy(list, (t1, t2) =>
			t2.Diagonal.CompareTo(t1.Diagonal));

		// Запрос на упорядочивание коллекции по мастеру, выполняющему ремонт
		public void OrderByRepairer() => RepairShop.OrderBy((t1, t2) =>
			t1.Repairer.CompareTo(t2.Repairer));

		public static void OrderByRepairer(List<Television> list) => RepairShop.OrderBy(list, (t1, t2) =>
			t1.Repairer.CompareTo(t2.Repairer));
		// Запрос на упорядочивание коллекции по владельцу телевизора
		public void OrderByOwner() => RepairShop.OrderBy((t1, t2) =>
			t1.Owner.CompareTo(t2.Owner));

		public static void OrderByOwner(List<Television> list) => RepairShop.OrderBy(list, (t1, t2) =>
			t1.Owner.CompareTo(t2.Owner));
		// Запрос на упорядочивание коллекции по стоимости
		public void OrderByPrice() => RepairShop.OrderBy((t1, t2) =>
			t1.Price.CompareTo(t2.Price));

		public static void OrderByPrice(List<Television> list) => RepairShop.OrderBy(list, (t1, t2) =>
			t1.Price.CompareTo(t2.Price));
		#endregion


		#region Выборки

		// Запрос на выборку в коллекцию телевизоров с минимальной стоимостью ремонта
		public List<Television> SelectWhereMinPrice()
		{
			int minPrice = _repairShop.MinPrice;
			return _repairShop.Filter(t => t.Price == minPrice);
		}

		// Запрос на выборку в коллекцию телевизоров, ремонтируемых заданным мастером
		public List<Television> SelectWhereRepairer(string repairer) =>
			_repairShop.Filter(t => t.Repairer == repairer);

		// Запрос на выборку в коллекцию телевизоров с заданной диагональю экран
		public List<Television> SelectWhereDiagonal(int diagonal) =>
			_repairShop.Filter(t => t.Diagonal == diagonal);

		// Запрос на выборку в коллекцию телевизоров с заданной диагональю экран
		public List<Television> SelectWhereOwner(string owner) =>
			_repairShop.Filter(t => t.Owner == owner);

		#endregion

	}
}
