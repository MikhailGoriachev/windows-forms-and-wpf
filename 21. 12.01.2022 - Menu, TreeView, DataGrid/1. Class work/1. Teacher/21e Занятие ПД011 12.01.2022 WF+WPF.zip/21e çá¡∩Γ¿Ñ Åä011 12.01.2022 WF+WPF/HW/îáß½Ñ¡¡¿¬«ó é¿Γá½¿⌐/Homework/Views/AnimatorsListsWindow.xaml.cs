﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Homework.Helpers;
using Homework.Models.Animators;

namespace Homework.Views
{
	/// <summary>
	/// Логика взаимодействия для AnimatorsListsWindow.xaml
	/// </summary>
	public partial class AnimatorsListsWindow : Window
	{
		public AnimatorsListsWindow()
		{
			InitializeComponent();

			// данные для отображения в listView
			List<SnowMaiden> snowMaidens = new List<SnowMaiden>();

			int amount = Utils.GetRandom(12, 20);

			for (int i = 0; i < amount; i++)
				snowMaidens.Add(SnowMaiden.Generate());
			
			// привязка данных
			LsvSnowMaidens.ItemsSource = snowMaidens;
		}
	}
}
