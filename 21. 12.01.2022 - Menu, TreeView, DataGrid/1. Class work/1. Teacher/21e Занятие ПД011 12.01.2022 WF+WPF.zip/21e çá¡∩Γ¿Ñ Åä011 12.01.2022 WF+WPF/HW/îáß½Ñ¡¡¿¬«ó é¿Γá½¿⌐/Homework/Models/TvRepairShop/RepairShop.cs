﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Homework.Models;

namespace Homework.Models.TvRepairShop
{
	/*
	 * класс RepairShop (коллекция Television, название ремонтной мастерской, адрес ремонтной мастерской).
	 */
	public class RepairShop
	{
		//коллекция Television
		private List<Television> _televisions;
		public List<Television> Televisions
		{
			get => _televisions;
			private set => _televisions = value;
		}

		//название ремонтной мастерской
		private string _title;
		public string  Title
		{
			get => _title;
			set
			{
				if (string.IsNullOrEmpty(value))
					throw new ArgumentNullException("Пустая строка в названии мастерской");
				_title = value;
			}
		}

		//адрес ремонтной мастерской
		private string _address;
		public string Address
		{
			get =>_address;
			set
			{
				if (string.IsNullOrEmpty(value))
					throw new ArgumentNullException("Пустая строка в указании адреса мастерской");
				_address = value;
			}
		}

		public RepairShop() :this(new List<Television>(), "Телевизионная мастерская \"TvFix\"", "ул. Гурова, 25")
		{}

		public RepairShop(List<Television> televisions, string title, string address)
		{
			Televisions = televisions;
			Title = title;
			Address = address;
		}

		public int Count => _televisions.Count;

		public bool IsEmpty => _televisions.Count == 0;

		// Реинициализация коллекции
		public void Initialize(int n = 15)
		{
			_televisions.Clear();
			_televisions = TelevisionFabric.GenerateCollection(n);
		}

		public Television this[int index]
		{
			get
			{
				if (index < 0 || index >= Count)
					throw new IndexOutOfRangeException("Попытка доступа к элементу вне диапазона");
				return _televisions[index];
			}
			set
			{
				if (index < 0 || index >= Count)
					throw new IndexOutOfRangeException("Попытка доступа к элементу вне диапазона");

				_televisions[index] = value;
			}
		}


		// добавление телевизора в коллекцию
		public void AddTelevision(Television television) => _televisions.Add(television);

		// удаление выбранного телевизора
		public void RemoveAt(int index) => _televisions.RemoveAt(index);

		// удаление всех телевизоров
		public void RemoveAll() => _televisions.Clear();


		// упорядочивание коллекции по заданному компаратору
		public void OrderBy(Comparison<Television> comparison) => _televisions.Sort(comparison);
		public static void OrderBy(List<Television> list, Comparison<Television> comparison) 
			=> list.Sort(comparison);

		public int MinPrice => _televisions.Min(tv => tv.Price);


		// выборка данных из коллекции по заданному предикату
		public List<Television> Filter(Predicate<Television> predicate) =>
			_televisions.FindAll(predicate);

		
		// Получить список фамилий мастеров
		public List<string> GetRepairers => _televisions.Select(tv => tv.Repairer).Distinct().ToList();

		// Получить список фамилий клиентов
		public List<string> GetOwners => _televisions.Select(tv => tv.Owner).Distinct().ToList();

		// Получить список диагоналей
		public List<string> GetDiagonals => _televisions.Select(tv => tv.Diagonal.ToString()).Distinct().ToList();

	}
}
