﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Homework.Models.TvRepairShop;

namespace Homework.Views
{
	/// <summary>
	/// Логика взаимодействия для SelectedListWindow.xaml
	/// </summary>
	public partial class SelectedListWindow : Window
	{
		private List<Television> _televisions;

		public SelectedListWindow(List<Television> televisions, string prompt)
		{
			InitializeComponent();

			_televisions = televisions;
			Title = prompt;
			LsvTelevisions.ItemsSource = _televisions;
		}
	}
}
