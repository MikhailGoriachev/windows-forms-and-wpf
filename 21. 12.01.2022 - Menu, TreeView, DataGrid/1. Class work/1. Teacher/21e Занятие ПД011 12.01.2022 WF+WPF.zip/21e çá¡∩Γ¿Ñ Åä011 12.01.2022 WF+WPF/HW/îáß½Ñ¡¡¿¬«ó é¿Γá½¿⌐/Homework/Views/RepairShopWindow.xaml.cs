﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Homework.Controllers;
using Homework.Helpers;
using Homework.Models.TvRepairShop;

namespace Homework.Views
{
	/// <summary>
	/// Логика взаимодействия для RepairShopWindow.xaml
	/// </summary>
	public partial class RepairShopWindow : Window
	{
		private RepairShopController _repairShopController;
		public RepairShopWindow(RepairShopController repairShopController)
		{
			InitializeComponent();

			_repairShopController = repairShopController;

			Title = _repairShopController.RepairShop.Title;
			LblShopName.Content = _repairShopController.RepairShop.Title;
			LblShopAddress.Content = "Адрес: " + _repairShopController.RepairShop.Address;

			LsvTelevisions.ItemsSource = _repairShopController.RepairShop.Televisions;

			LsvTelevisions.SelectedIndex = 0;
		}
		private void MniExit_Command(object sender, RoutedEventArgs e) => Close();
		private void MniAbout_Command(object sender, RoutedEventArgs e) => new AboutWindow().ShowDialog();


		private void Generate_Command(object sender, RoutedEventArgs e)
		{
			_repairShopController.RepairShop.Initialize(Utils.GetRandom(12,20));
			LsvTelevisions.ItemsSource = null;
			LsvTelevisions.ItemsSource = _repairShopController.RepairShop.Televisions;
		}

		private void Add_Command(object sender, RoutedEventArgs e)
		{
			TvWindow tvWindow = new TvWindow();
			
			if(tvWindow.ShowDialog() == false) return;

			// получить данные из свойства формы
			_repairShopController.RepairShop.AddTelevision(tvWindow.Tv);
			
			LsvTelevisions.ItemsSource = null;
			LsvTelevisions.ItemsSource = _repairShopController.RepairShop.Televisions;

			LsvTelevisions.SelectedIndex = LsvTelevisions.Items.Count - 1;
			LsvTelevisions.ScrollIntoView(LsvTelevisions.SelectedItem);
			LsvTelevisions.Focus();

		}

		private void Edit_Command(object sender, RoutedEventArgs e)
		{
			if (LsvTelevisions.SelectedIndex == -1) return;

			// индекс выбранного элемента
			int selected = LsvTelevisions.SelectedIndex;

			// передача данных в форму
			TvWindow tvWindow = new TvWindow("Редактировать данные о телевизоре", "Сохранить")
			{
				Tv = _repairShopController.RepairShop[selected]
			};

			if (tvWindow.ShowDialog() == false) return;

			// получить данные
			_repairShopController.RepairShop[selected] = tvWindow.Tv;
			
			LsvTelevisions.ItemsSource = null;
			LsvTelevisions.ItemsSource = _repairShopController.RepairShop.Televisions;

			LsvTelevisions.SelectedIndex = selected;
			LsvTelevisions.ScrollIntoView(LsvTelevisions.SelectedItem);
			LsvTelevisions.Focus();
		}

		#region Сортировки

		private void OrderByBrand_Command(object sender, RoutedEventArgs e)
		{
			_repairShopController.OrderByBrand();
			LsvTelevisions.ItemsSource = null;
			LsvTelevisions.ItemsSource = _repairShopController.RepairShop.Televisions;
		}

		private void OrderByDiagonalDesc_Command(object sender, RoutedEventArgs e)
		{
			_repairShopController.OrderByDiagonalDesc();
			LsvTelevisions.ItemsSource = null;
			LsvTelevisions.ItemsSource = _repairShopController.RepairShop.Televisions;
		}

		private void OrderByRepairer_Command(object sender, RoutedEventArgs e)
		{
			_repairShopController.OrderByRepairer();
			
			LsvTelevisions.ItemsSource = null;
			LsvTelevisions.ItemsSource = _repairShopController.RepairShop.Televisions;
		}

		private void OrderByOwner_Command(object sender, RoutedEventArgs e)
		{
			_repairShopController.OrderByOwner();
			LsvTelevisions.ItemsSource = null;
			LsvTelevisions.ItemsSource = _repairShopController.RepairShop.Televisions;
		}

		#endregion

		#region Выборка

		private void SelectMinPrice_Command(object sender, RoutedEventArgs e)
		{
			List<Television> reported = _repairShopController.SelectWhereMinPrice();
			
			string prompt = $"Телевизоры с минимальной стоимостью ремонта:";

			new SelectedListWindow(reported, prompt).ShowDialog();
		}

		private void SelectWhereRepairer_Command(object sender, RoutedEventArgs e)
		{
			// Получение списка мастеров
			List<string> repairers = _repairShopController.RepairShop.GetRepairers;

			// Создание формы выбора мастера
			SelectingWindow choiceForm = new SelectingWindow(repairers, "Выбор мастера", "Выберите мастера:");

			if(choiceForm.ShowDialog() == false) return;

			string prompt = $"Телевизоры, ремонтируемые мастером {choiceForm.Choosen}:";

			// Отобразить выборку ремонтов мастера в отдельной форме
			new SelectedListWindow(_repairShopController.SelectWhereRepairer(choiceForm.Choosen), prompt)
				.ShowDialog();
		}

		// Выборка по владельцу
		private void SelectWhereDiagonal_Command(object sender, RoutedEventArgs e)
		{
			// Получение списка диагоналей
			List<string> diagonals = _repairShopController.RepairShop.GetDiagonals;

			// Создание формы выбора владельца
			SelectingWindow choiceForm = new SelectingWindow(diagonals, "Выбор диагонали", "Выберите диагональ:");

			if (choiceForm.ShowDialog() == false) return;

			string prompt = $"Телевизоры c диагональю {choiceForm.Choosen}:";

			// Отобразить выборку в отдельной форме
			new SelectedListWindow(_repairShopController.SelectWhereDiagonal(int.Parse(choiceForm.Choosen)), prompt)
				.ShowDialog();
		}

		#endregion

		private void LsvTelevisions_SelectionChanged(object sender, SelectionChangedEventArgs e) =>
			MniEdit.IsEnabled = BtnEdit.IsEnabled = LsvTelevisions.SelectedIndex != -1;

		private void LsvTelevisions_MouseDoubleClick(object sender, MouseButtonEventArgs e) =>
			Edit_Command(sender, e);
	}
}
