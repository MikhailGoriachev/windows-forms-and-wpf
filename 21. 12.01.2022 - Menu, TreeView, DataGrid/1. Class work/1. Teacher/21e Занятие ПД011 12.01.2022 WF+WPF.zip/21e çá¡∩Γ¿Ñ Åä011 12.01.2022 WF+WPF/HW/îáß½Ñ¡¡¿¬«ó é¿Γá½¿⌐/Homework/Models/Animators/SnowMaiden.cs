﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Homework.Helpers;


namespace Homework.Models.Animators
{
	/*
	 Снегурочка: 
	- фамилия,
	- имя,
	- отчество,
	- цвет полушубка,
	- количество стихотворений, которые знает актриса,
	- количество игр для детей, которые может организовать актриса.   
	 */
	public class SnowMaiden
	{
		// имя
		private string _name;
		public string Name
		{
			get => _name;
			set
			{
				if (string.IsNullOrEmpty(value))
					throw new ArgumentNullException("Пустая строка имени актрисы роли снегурочки");
				_name = value;
			}
		}
		
		// фамилия
		private string _surname;

		public string Surname
		{
			get => _surname;
			set
			{
				if (string.IsNullOrEmpty(value))
					throw new ArgumentNullException("Пустая строка фамилии актрисы роли снегурочки");
				_surname = value;
			}
		}

		// отчество
		private string _patronymic;

		public string Patronymic
		{
			get => _patronymic;
			set
			{
				if (string.IsNullOrEmpty(value))
					throw new ArgumentNullException("Пустая строка отчества актрисы роли снегурочки");
				_patronymic = value;
			}
		}

		// цвет полушубка
		private string _furcoatColor;

		public string FurcoatColor
		{
			get => _furcoatColor;
			set
			{
				if (string.IsNullOrEmpty(value))
					throw new ArgumentNullException("Пустая строка цвета полушубка актёра роли деда мороза");
				_furcoatColor = value;
			}
		}

		// количество стихотворений, которые знает актриса,
		private int _poems;

		public int Poems
		{
			get => _poems;
			set
			{
				if (value < 0)
					throw new ArgumentOutOfRangeException($"Недопустимое значение количества стихотворений: {value}");
				_poems = value;
			}
		}

		// количество игр для детей, которые может организовать актриса.

		private int _games;
			
		public int Games
		{
			get => _games;
			set
			{
				if (value < 0)
					throw new ArgumentOutOfRangeException($"Недопустимое значение количества игр: {value}");
				_games = value;
			}
		}

		public static SnowMaiden Generate()
		{
			string[] surnames =
			{
				"Макарова", "Субботина", "Горшкова", "Минаева", "Виноградова", "Вешнякова", "Маркова", "Кочетова", "Чернова",
				"Демина", "Орлова", "Блинова", "Фролова", "Пастухова", "Петрова", "Смирнова", "Кузьмина", "Белова", "Крылова",
				"Николаева", "Григорьева", "Корнеева", "Чернышева", "Головина", "Моисеева", "Цветкова", "Фокина", "Морозова",
				"Максимова", "Егорова"
			};
			string[] names =
			{
				"Кира", "Дарья", "Александра", "Таисия", "Анастасия", "София", "Анна", "Анастасия", "Мирослава", "Кира", "Ксения",
				"Александра", "Варвара", "Алиса", "Полина", "Арина", "Полина", "Ясмина", "Анастасия", "Вероника", "Ольга", "Дарья",
				"Алиса", "Алёна", "Мария", "София", "Варвара", "Зоя", "Агата", "Алиса"
			};
			string[] patronymics =
			{
				"Алексеевна", "Тимуровна", "Григорьевна", "Борисовна", "Петровна", "Александровна", "Данииловна", "Алексеевна",
				"Григорьевна", "Львовна", "Кирилловна", "Захаровна", "Александровна", "Егоровна", "Матвеевна", "Платоновна",
				"Даниловна", "Игоревна", "Григорьевна", "Львовна", "Марковна", "Андреевна", "Дмитриевна", "Александровна",
				"Егоровна", "Львовна", "Демьяновна", "Артёмовна", "Тимуровна", "Фёдоровна"
			};

			string[] furcoatColors =
			{
				"Красный", "Синий", "Белый", "Голубой"
			};

			return new SnowMaiden
			{
				Surname = surnames[Utils.GetRandom(0, surnames.Length - 1)],
				Name = names[Utils.GetRandom(0, names.Length - 1)],
				Patronymic = patronymics[Utils.GetRandom(0, patronymics.Length - 1)],
				FurcoatColor = furcoatColors[Utils.GetRandom(0, furcoatColors.Length - 1)],
				Poems = Utils.GetRandom(1, 20),
				Games = Utils.GetRandom(1, 10)
			};
		}
	}
}
