﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Homework.Models.Animators
{
	/*
	   Деда Мороз: 
		- string фамилия,
		- string имя, 
		- string отчество,
		- цвет полушубка,
		- int количество подарков, которые способен перенести актер.
	 */
	public class SantaClaus
	{
		// имя
		private string _name;

		public string Name
		{
			get => _name;
			set
			{
				if (string.IsNullOrEmpty(value))
					throw new ArgumentNullException("Пустая строка имени актёра роли деда мороза");
				_name = value;
			}
		}

		// фамилия
		private string _surname;

		public string Surname
		{
			get => _surname;
			set
			{
				if (string.IsNullOrEmpty(value))
					throw new ArgumentNullException("Пустая строка фамилии актёра роли деда мороза");
				_surname = value;
			}
		}

		// отчество
		private string _patronymic;

		public string Patronymic
		{
			get => _patronymic;
			set
			{
				if (string.IsNullOrEmpty(value))
					throw new ArgumentNullException("Пустая строка отчества актёра роли деда мороза");
				_patronymic = value;
			}
		}

		// цвет полушубка
		private string _furcoatColor;

		public string FurcoatColor
		{
			get => _furcoatColor;
			set
			{
				if (string.IsNullOrEmpty(value))
					throw new ArgumentNullException("Пустая строка цвета полушубка актёра роли деда мороза");
				_furcoatColor = value;
			}
		}

		// кол-во подарков, которые способен перенести актер
		private int _giftsCapacity;

		public int GiftsCapacity
		{
			get => _giftsCapacity;
			set
			{
				if (value <= 0)
					throw new ArgumentOutOfRangeException($"Недопустимое значение количества переносимх подарков: {value}");
				_giftsCapacity = value;
			}
		}

		public override string ToString() =>
			$"{_surname} {_name} {_patronymic}, полушубок: {_furcoatColor}, подарков: {_giftsCapacity},";

	}
}
