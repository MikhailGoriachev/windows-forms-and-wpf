﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using ListViewDataSource.Models;

namespace ListViewDataSource.Views
{
    /// <summary>
    /// Логика взаимодействия для ActorsListWindow.xaml
    /// </summary>
    public partial class ActorsListWindow : Window
    {
        public ActorsListWindow() {
            InitializeComponent();

            LsvActresses.ItemsSource = new List<Actress>(new [] {
                new Actress {Surname="Миронова",   Name="Ольга",   Patronymic="Семеновна",    Color="синий",   NumberOfPoems=13, NumberOfGames = 5},
                new Actress {Surname="Котова",     Name="Мария",   Patronymic="Олеговна",     Color="зеленый", NumberOfPoems=11, NumberOfGames = 8},
                new Actress {Surname="Аникеева",   Name="Арина",   Patronymic="Петровна",     Color="белый",   NumberOfPoems=11, NumberOfGames = 8},
                new Actress {Surname="Штурлак",    Name="Дарья",   Patronymic="Олеговна",     Color="белый",   NumberOfPoems=13, NumberOfGames = 9},
                new Actress {Surname="Михайленко", Name="Людмила", Patronymic="Игоревна",     Color="синий",   NumberOfPoems=13, NumberOfGames = 9},
                new Actress {Surname="Каплун",     Name="Оксана",  Patronymic="Алексеевна",   Color="синий",   NumberOfPoems=14, NumberOfGames = 7},
                new Actress {Surname="Коротаева",  Name="Лариса",  Patronymic="Юрьевна",      Color="белый",   NumberOfPoems=14, NumberOfGames = 7},
                new Actress {Surname="Грамакова",  Name="Мария",   Patronymic="Леонидовна",   Color="зеленый", NumberOfPoems=18, NumberOfGames = 4},
                new Actress {Surname="Бакина",     Name="Дарья",   Patronymic="Денисовна",    Color="зеленый", NumberOfPoems=18, NumberOfGames = 9},
                new Actress {Surname="Новоселова", Name="Тамара",  Patronymic="Владимировна", Color="синий",   NumberOfPoems=12, NumberOfGames = 6},
                new Actress {Surname="Штакина",    Name="Арина",   Patronymic="Ивановна",     Color="белый",   NumberOfPoems=16, NumberOfGames = 5},
                new Actress {Surname="Курочкина",  Name="Лариса",  Patronymic="Павловна",     Color="синий",   NumberOfPoems=19, NumberOfGames = 8}
            });
        } // ActorsListWindow

    } // class ActorsListWindow
}
