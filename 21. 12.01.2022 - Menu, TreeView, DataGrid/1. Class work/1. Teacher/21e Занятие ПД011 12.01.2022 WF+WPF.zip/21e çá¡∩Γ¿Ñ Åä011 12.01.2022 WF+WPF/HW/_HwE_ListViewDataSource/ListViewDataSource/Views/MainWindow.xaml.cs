﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;

namespace ListViewDataSource.Views
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow() {
            InitializeComponent();
        } // MainWindow

                
        // Завершить работу приложения
        private void Exit_Click(object sender, RoutedEventArgs e) {
            Close();
        } // Exit_Click


        // Открыть окно со сведениями о приложении и разработчике
        private void About_Click(object sender, RoutedEventArgs e) {
            AboutWindow aboutWindow = new AboutWindow();
            aboutWindow.ShowDialog();
        } // About_Click


        // Обработка клика по кнопке "Списки Дедов Морозов и Снегурочек"
        private void ActorsList_Click(object sender, RoutedEventArgs e) {
            ActorsListWindow bodyListWindow = new ActorsListWindow();
            bodyListWindow.ShowDialog();
        } // ActorsList_Click


        // Обработка клика по кнопке "Ремонт телевизоров"
        private void RepairShop_Click(object sender, RoutedEventArgs e) {
            RepairShopWindow bodyListWindow = new RepairShopWindow();
            bodyListWindow.ShowDialog();
        } // RepairShop_Click


        #region Изменение цвета надписи на кнопке при перемещении курсора мыши на кнопку
        private void Button_MouseEnter(object sender, MouseEventArgs e) {
            Button btn = e.OriginalSource as Button;
            btn.Foreground = new SolidColorBrush(Color.FromArgb(255, 0, 0, 0));
        } // Button_MouseEnter

        private void Button_MouseLeave(object sender, MouseEventArgs e) {
            Button btn = e.OriginalSource as Button;
            btn.Foreground = new SolidColorBrush(Colors.White);
        } // Button_MouseLeave
        #endregion
    } // class MainWindow
}
