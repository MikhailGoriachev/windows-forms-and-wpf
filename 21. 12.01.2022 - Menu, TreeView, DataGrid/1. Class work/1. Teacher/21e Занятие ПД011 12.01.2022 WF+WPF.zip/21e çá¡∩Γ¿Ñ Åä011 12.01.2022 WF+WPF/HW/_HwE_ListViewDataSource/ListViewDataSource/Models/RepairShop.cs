﻿using System;
using System.Collections.Generic;

namespace ListViewDataSource.Models
{
    /*
     * Класс RepairShop (коллекция Television, название ремонтной
     * мастерской, адрес ремонтной мастерской).
     *
     */
    public class RepairShop
    {
        // коллекция Television - телевизоры в ремонте
        private List<Television> _televisions;
        public List<Television> Televisions {
            get => _televisions;
            private set => _televisions = value;
        } // Televisions


        // название ремонтной мастерской
        private string _title;
        public string Title {
            get => _title;
            set {
                if (string.IsNullOrWhiteSpace(value))
                    throw new ArgumentException("RepairShop. Должно быть задано название ремонтной мастерской");

                _title = value;
            }
        } // Title


        // адрес ремонтной мастерской
        private string _address;
        public string Address {
            get => _address;
            set {
                if (string.IsNullOrWhiteSpace(value))
                    throw new ArgumentException("RepairShop. Должен быть задан адрес ремонтной мастерской");

                _address = value;
            }
        } // Address


        // конструкторы
        public RepairShop():this(new List<Television>(), "Ремонт ТВ", "пр. Мира, 13") {
            Initialize();
        } // Repairshop

        public RepairShop(List<Television> televisions, string title, string address) {
            Televisions = televisions;
            Title = title;
            Address = address;
        } // RepairShop


        // формирование коллекции телевизоров в ремонте
        public void Initialize(int n = 12) {
            _televisions.Clear();

            for (int i = 0; i < n; i++) {
                _televisions.Add(Television.Generate());
            } // for i
        } // Initialize


        // индексатор для телевизоров
        public Television this[int index] {
            get => _televisions[index];
            set => _televisions[index] = value;
        } // indexer


        // получение текущего количества телевизоров в коллекции
        public int Count => _televisions.Count;


        // добавление телевизора в коллекцию
        public void Add(Television television) => _televisions.Add(television);


        // удаление телевизора из коллекции
        public void RemoveAt(int index) => _televisions.RemoveAt(index);


        // получить минимальную стоимость ремонта телевизора
        public int MinPrice() {
            int minPrice = _televisions[0].Price;
            _televisions.ForEach(t => minPrice = t.Price < minPrice?t.Price:minPrice);

            return minPrice;
        } // MinPrice


        // получить максимальную стоимость ремонта телевизора
        public int MaxPrice() {
            int maxPrice = _televisions[0].Price;
            _televisions.ForEach(t => maxPrice = t.Price > maxPrice ? t.Price : maxPrice);

            return maxPrice;
        } // MaxPrice

        
        // упорядочивание копии коллекции по заданному компаратору
        public List<Television> OrderCopyBy(Comparison<Television> comparison) {
            // получить копию коллекции телевизоров
            List<Television> list = new List<Television>(_televisions);

            // упорядочить копию коллекции телевизоров и вернуть эту копию
            list.Sort(comparison);
            return list;
        } // OrderCopyBy

        // выборка данных из коллекции по заданному предикату
        public List<Television> Filter(Predicate<Television> predicate) =>
            _televisions.FindAll(predicate);
    } // class RepairShop
}
