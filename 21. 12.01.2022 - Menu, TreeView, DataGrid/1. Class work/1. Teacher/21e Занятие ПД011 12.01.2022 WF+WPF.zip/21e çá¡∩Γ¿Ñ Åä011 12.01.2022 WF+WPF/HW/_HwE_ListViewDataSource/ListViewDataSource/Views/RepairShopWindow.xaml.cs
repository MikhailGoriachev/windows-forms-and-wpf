﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using ListViewDataSource.Controllers;
using ListViewDataSource.Models;

namespace ListViewDataSource.Views
{
    /// <summary>
    /// Логика взаимодействия для RepairShopWindow.xaml
    /// </summary>
    public partial class RepairShopWindow : Window
    {
        // контроллер для работы с ремонтной мастерской
        private RepairShopController _repairShopController;

        public RepairShopWindow():this(new RepairShopController()) {}

        public RepairShopWindow(RepairShopController repairShopController) {
            InitializeComponent();

            // внедрение зависимости
            _repairShopController = repairShopController;

            // задать данные ремонтной мастерской в строку заголовка
            TxbRepairShop.Text = "Ремонтная мастерская \"" + _repairShopController.RepairShop.Title + "\" по адресу " +
                                 _repairShopController.RepairShop.Address;

            // задать телевизоры для отображения в ListView
            LsvTelevisions.ItemsSource = _repairShopController.RepairShop.Televisions;
        } // RepairShopWindow


        // Формирование нового набора данных
        private void GenerateNew_Click(object sender, RoutedEventArgs e) {
            _repairShopController.CreateNewRepairShop("Отремонтируем все", "ул. Овнатаняна, 21в");
            _repairShopController.RepairShop.Initialize();

            // задать данные ремонтной мастерской в строку заголовка
            TxbRepairShop.Text = "Ремонтная мастерская \"" + _repairShopController.RepairShop.Title + "\" по адресу " +
                                 _repairShopController.RepairShop.Address;

            // задать телевизоры для отображения в ListView
            LsvTelevisions.ItemsSource = null;
            LsvTelevisions.ItemsSource = _repairShopController.RepairShop.Televisions;
        } // GenerateNew_Click


        #region Изменение цвета надписи на кнопке при перемещении курсора мыши на кнопку
        private void Button_MouseEnter(object sender, MouseEventArgs e) {
            Button btn = sender as Button;
            btn.Foreground = new SolidColorBrush(Color.FromArgb(255, 0, 0, 0));
        } // Button_MouseEnter

        private void Button_MouseLeave(object sender, MouseEventArgs e) {
            Button btn = sender as Button;
            btn.Foreground = new SolidColorBrush(Color.FromArgb(255, 255, 255, 255));
        } // Button_MouseLeave
        #endregion

        // Добавление телевизра в коллекцию - черновой вариант, без формы
        private void AddTv_Click(object sender, RoutedEventArgs e) {
            // добавить телевизор в коллекцию
            _repairShopController.RepairShop.Add(Television.Generate());

            // обновить привязку коллекции к ListView
            LsvTelevisions.ItemsSource = null;
            LsvTelevisions.ItemsSource = _repairShopController.RepairShop.Televisions;
        } // AddTv_Click
    }
}
