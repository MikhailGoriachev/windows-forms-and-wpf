﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ListViewDataSource.Models
{
    // Представление данных актера, играющего роль Деда Мороза:
    // фамилия, имя, отчество, цвет полушубка, количество подарков,
    // которые способен перенести актер.
    public class Actor: Person
    {
        // количество подарков, которые способен перенести актер
        public int CurriedPresents { get; set; }
    } // class Actor
}
