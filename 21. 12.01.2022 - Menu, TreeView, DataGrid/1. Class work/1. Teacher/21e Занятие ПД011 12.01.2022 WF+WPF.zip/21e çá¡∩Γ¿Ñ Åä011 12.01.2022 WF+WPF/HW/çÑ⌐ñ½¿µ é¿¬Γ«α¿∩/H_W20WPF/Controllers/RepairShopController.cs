﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using H_W20WPF.Models.RepairShop;

namespace H_W20WPF.Controllers
{
    // Реализация функционала приложения
    // • Упорядочивание коллекции телевизоров
    //    o По производителю и типу
    //    o По убыванию диагонали экрана
    //    o По мастеру, выполняющему ремонт
    //    o По владельцу телевизора
    // • Выборка и вывод в отдельном окне коллекции телевизоров с минимальной стоимостью ремонта
    // • Выборка и вывод в отдельном окне коллекции телевизоров, ремонтируемых выбранным мастером
    // • Выборка и вывод в отдельном окне коллекции телевизоров, с заданной диагональю экрана

    public class RepairShopController
    {

        // объект для обработки
        private RepairShop _repairShop;

        public RepairShop RepairShop
        {
            get => _repairShop;
            private set => _repairShop = value;
        } // RepairShop


        // конструкторы
        public RepairShopController() : this(new RepairShop()) { }

        public RepairShopController(RepairShop repairShop)
        {
            _repairShop = repairShop;
        } // RepairShopController

        // Упорядочивание коллекции по производителю и типу
        public void OrderByBrand() => RepairShop.OrderBy((tv1, tv2) =>
            tv1.TvBrand.CompareTo(tv2.TvBrand));

        // Упорядочивание коллекции по убыванию диагонали экрана
        public void OrderByDiagonalDesc() => RepairShop.OrderBy((tv1, tv2) =>
            tv2.Diagonal.CompareTo(tv1.Diagonal));

        // Упорядочивание коллекции по мастеру, выполняющему ремонт
        public void OrderByMaster() => RepairShop.OrderBy((tv1, tv2) =>
            tv1.FullnameMaster.CompareTo(tv2.FullnameMaster));

        // Упорядочивание коллекции по владельцу телевизора
        public void OrderByOwner() => RepairShop.OrderBy((tv1, tv2) =>
            tv1.FullnameOwner.CompareTo(tv2.FullnameOwner));


        // Выборка в коллекцию телевизоров с минимальной стоимостью ремонта
        public List<Television> SelectWhereMinPrice()
        {
            int minPrice = _repairShop.MinPrice();
            return _repairShop.Filter(tv => tv.CostRepair == minPrice);
        } // SelectWhereMinPrice


        // Выборка в коллекцию телевизоров, ремонтируемых выбранным мастером
        public List<Television> SelectWhereMaster(string master) =>
            _repairShop.Filter(tv => tv.FullnameMaster == master);

        // Выборка в коллекцию телевизоров с заданной диагональю экран
        public List<Television> SelectWhereDiagonal(int diagonal) =>
            _repairShop.Filter(tv => tv.Diagonal == diagonal);




    }// class RepairShopController
}
