﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using H_W20WPF.Models.NewYear;

namespace H_W20WPF.Views
{
    /// <summary>
    /// Логика взаимодействия для NewYear.xaml
    /// </summary>
    public partial class NewYear : Window
    {
        public NewYear()
        {
            InitializeComponent();


            LsvSnowMaiden.ItemsSource = new List<SnowMaiden>(new SnowMaiden[]
            {
                new SnowMaiden{Surname = "Николаева", Name = "Зинаида",    Patronymic = "Романовна",   CoatColor = "голубой", AmountPoems = 5, AmountGames = 1},
                new SnowMaiden{Surname = "Денисова",  Name = "Александра", Patronymic = "Ивановна",    CoatColor = "синий",   AmountPoems = 8, AmountGames = 3},
                new SnowMaiden{Surname = "Воронина",  Name = "Василиса",   Patronymic = "Кирилловна",  CoatColor = "голубой", AmountPoems = 6, AmountGames = 5},
                new SnowMaiden{Surname = "Рыбакова",  Name = "Дарья",      Patronymic = "Григорьевна", CoatColor = "голубой", AmountPoems = 3, AmountGames = 8},
                new SnowMaiden{Surname = "Грибова",   Name = "Софья",      Patronymic = "Никитична",   CoatColor = "синий",   AmountPoems = 2, AmountGames = 12},
                new SnowMaiden{Surname = "Смирнова",  Name = "Валентина",  Patronymic = "Данииловна",  CoatColor = "голубой", AmountPoems = 7, AmountGames = 4},
                new SnowMaiden{Surname = "Гончарова", Name = "Арина",      Patronymic = "Алексеевна",  CoatColor = "синий",   AmountPoems = 5, AmountGames = 3},
                new SnowMaiden{Surname = "Грачёва",   Name = "Василиса",   Patronymic = "Романовна",   CoatColor = "голубой", AmountPoems = 3, AmountGames = 2},
                new SnowMaiden{Surname = "Морозова",  Name = "Таисия",     Patronymic = "Платоновна",  CoatColor = "голубой", AmountPoems = 5, AmountGames = 6},
                new SnowMaiden{Surname = "Семёнова",  Name = "Дарина",     Patronymic = "Марковна",    CoatColor = "синий",   AmountPoems = 9, AmountGames = 9},
                new SnowMaiden{Surname = "Васютина",  Name = "Светлана",   Patronymic = "Максимовна",  CoatColor = "голубой", AmountPoems = 5, AmountGames = 3},
                new SnowMaiden{Surname = "Жукова",    Name = "Зинаида",    Patronymic = "Витальевна",  CoatColor = "голубой", AmountPoems = 8, AmountGames = 8},
            });
        }

        



    }// class NewYear 
}
