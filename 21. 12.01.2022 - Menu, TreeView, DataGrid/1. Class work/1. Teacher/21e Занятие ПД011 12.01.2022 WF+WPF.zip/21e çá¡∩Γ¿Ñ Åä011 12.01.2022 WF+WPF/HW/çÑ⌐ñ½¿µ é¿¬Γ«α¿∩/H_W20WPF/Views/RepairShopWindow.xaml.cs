﻿
using H_W20WPF.Controllers;
using H_W20WPF.Models.RepairShop;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace H_W20WPF.Views
{
    /// <summary>
    /// Логика взаимодействия для RepairShopWindow.xaml
    /// </summary>
    public partial class RepairShopWindow : Window
    {
        // контроллер для работы с формой
        private RepairShopController _repairShopController;

        // конструкторы формы
        public RepairShopWindow() : this(new RepairShopController()) { }
        public RepairShopWindow(RepairShopController repairShopController)
        {
            InitializeComponent();

            // получить контроллер для работы с данными ремонтной мастерской
            _repairShopController = repairShopController;

            LsvTelevision.ItemsSource = _repairShopController.RepairShop.Televisions;
        }// RepairShopWindow

        // выполнение привязки коллекции
        private void BindCollection()
        {
            // остановить привязку
            LsvTelevision.ItemsSource = null;

            // задать привязку
            LsvTelevision.ItemsSource = _repairShopController.RepairShop.Televisions;
        } // BindCollection

        #region Сортировка коллекции
        // сортировка коллекции телевизоров по производителю и типу
        private void OrderByBrand_Click(object sender, RoutedEventArgs e)
        {
            _repairShopController.OrderByBrand();

            BindCollection();
        }// OrderByBrand_Click


        // сортировка коллекции телевизоров по убыванию диагонали экрана
        private void OrderByDiagonalDesc_Click(object sender, RoutedEventArgs e)
        {
            _repairShopController.OrderByDiagonalDesc();

            BindCollection();
        }// OrderByDiagonalDesc_Click


        // сортировка коллекции телевизоров по мастеру, выполняющему ремонт
        private void OrderByMaster_Click(object sender, RoutedEventArgs e)
        {
            _repairShopController.OrderByMaster();

            BindCollection();
        }// OrderByMaster_Click


        // сортировка коллекции телевизоров по владельцу телевизора
        private void OrderByOwner_Click(object sender, RoutedEventArgs e)
        {
            _repairShopController.OrderByOwner();

            BindCollection();
        }// OrderByOwner_Click

        #endregion

        // выборка и вывод в отдельном окне коллекции телевизоров с минимальной стоимостью ремонта
        private void SelectMinPrice_Click(object sender, RoutedEventArgs e)
        {
            List<Television> televisions = _repairShopController.SelectWhereMinPrice();

            string prompt = $"Телевизоры с минимальной стоимостью ремонта:";

            SelectionsWindow selections = new SelectionsWindow(televisions, prompt);

            selections.Show();

        }// SelectMinPrice_Click

    
        // выборка и вывод в отдельном окне коллекции телевизоров, ремонтируемых выбранным мастером
        private void SelectByMaster_Click(object sender, RoutedEventArgs e)
        {
            // Получение списка мастеров
            List<string> repairs = _repairShopController.RepairShop.GetMasters;

            // Создание формы выбора мастера
            ChoiceWindow choiceWindow = new ChoiceWindow(repairs, "Выбор мастера", "Выберите мастера:");

            //if (choiceWindow.ShowDialog() != DialogResult) return;

            string prompt = $"Телевизоры, ремонтируемые мастером {choiceWindow.Choosen}:";

            // Отобразить выборку ремонтов мастера в отдельном окне
            new SelectionsWindow(_repairShopController.SelectWhereMaster(choiceWindow.Choosen), prompt).ShowDialog();
            
        }// SelectByMaster_Click


        // выборка и вывод в отдельном окне коллекции телевизоров, с заданной диагональю экрана 
        private void SelectByDiagonal_Click(object sender, RoutedEventArgs e)
        {
            // Получение списка диагонали
            List<string> repairs = _repairShopController.RepairShop.GetDiagonals;

            // Создание формы выбора мастера
            ChoiceWindow choiceWindow = new ChoiceWindow(repairs, "Выбор диагонали", "Выберите диагональ:");

            //if (choiceWindow.ShowDialog() != DialogResult.Ok) return;

            string prompt = $"Телевизоры, c диагональю {choiceWindow.Choosen}:";

            // Отобразить выборку диагонали в отдельном окне
            new SelectionsWindow(_repairShopController.SelectWhereDiagonal(int.Parse(choiceWindow.Choosen)), prompt).ShowDialog();
        }// SelectByDiagonal_Click


        // Изменение цвета надписи на кнопке при перемещении курсора мыши на кнопку
        private void Button_MouseEnter(object sender, MouseEventArgs e)
        {
            Button btn = e.OriginalSource as Button;
            btn.Foreground = new SolidColorBrush(Color.FromArgb(255, 0, 0, 0));
        } // Button_MouseEnter

        private void Button_MouseLeave(object sender, MouseEventArgs e)
        {
            Button btn = e.OriginalSource as Button;
            btn.Foreground = new SolidColorBrush(Colors.White);
        } // Button_MouseLeave


        private void Close_Click(object sender, RoutedEventArgs e) => Close();


    }// class RepairShopWindow
}
