﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace H_W20WPF.Views
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        // Завершить работу приложения
        private void Exit_Click(object sender, RoutedEventArgs e) => Close();


        // Открыть окно со сведениями о приложении и разработчике
        private void About_Click(object sender, RoutedEventArgs e)
        {
            AboutWindow aboutWindow = new AboutWindow();
            aboutWindow.ShowDialog();
        } // About_Click


        // Обработка клика по кнопке "Списки Дедов Морозов и Снегурочек"
        private void NewYear_Click(object sender, RoutedEventArgs e)
        {
            NewYear newYear = new NewYear();
            newYear.ShowDialog();
        }// NewYear_Click


        // Обработка клика по кнопке "Ремонт телевизоров"
        private void RepairShop_Click(object sender, RoutedEventArgs e)
        {
            RepairShopWindow shopWindow = new RepairShopWindow();
            shopWindow.ShowDialog();
        }// RepairShop_Click

        // Изменение цвета надписи на кнопке при перемещении курсора мыши на кнопку
        private void Button_MouseEnter(object sender, MouseEventArgs e)
        {
            Button btn = e.OriginalSource as Button;
            btn.Foreground = new SolidColorBrush(Color.FromArgb(255, 0, 0, 0));
        } // Button_MouseEnter

        private void Button_MouseLeave(object sender, MouseEventArgs e)
        {
            Button btn = e.OriginalSource as Button;
            btn.Foreground = new SolidColorBrush(Colors.White);
        } // Button_MouseLeave

    }// class MainWindow
}
