﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace H_W20WPF.Models.NewYear
{
    // Класс для представления данных актера, играющего роль Деда Мороза:
    // *фамилия,
    // *имя,
    // *отчество,
    // *цвет полушубка,
    // *количество подарков, которые способен перенести актер
    public class SantaClaus
    {
        // фамилия
        private string _surname;
        public string Surname {
            get => _surname;
            set {
                if (string.IsNullOrWhiteSpace(value))
                    throw new ArgumentException("SantaClaus: Не верно задано фамилия дед мороза или задано пустой строкой");
                _surname = value;
            }
        }// Surname


        // имя
        private string _name;
        public string Name
        {
            get => _name;
            set
            {
                if (string.IsNullOrWhiteSpace(value))
                    throw new ArgumentException("SantaClaus: Не верно задано имя дед мороза или задано пустой строкой");
                _name = value;
            }
        }// Name

        // отчество
        private string _patronymic;
        public string Patronymic
        {
            get => _patronymic;
            set
            {
                if (string.IsNullOrWhiteSpace(value))
                    throw new ArgumentException("SantaClaus: Не верно задано отчество дед мороза или задано пустой строкой");
                _patronymic = value;
            }
        }// Patronymic

        // цвет полушубка
        private string _coatColor;
        public string CoatColor {
            get => _coatColor;
            set {
                if (string.IsNullOrWhiteSpace(value))
                    throw new ArgumentException("SantaClaus: Не верно задан цвет полушубка или задан пустой строкой");
                _coatColor = value;
            }
        }// CoatColor

        // количество подарков
        private int _amountPresents;
        public int AmountPresents {
            get => _amountPresents;
            set {
                if (value < 0)
                    throw new ArgumentException($"SantaClaus: Недопустимое значение количества подарков: {value}");
                _amountPresents = value;
            }
        }// AmountPresents


        // конструкторы объекта класса
        public SantaClaus(): this("Иванов", "Иван", "Иванович", "зелёный", 5) { }
        public SantaClaus(string surname, string name, string patronymic, string color, int presents)
        {
            Surname        = surname;
            Name           = name;
            Patronymic     = patronymic;
            CoatColor      = color;
            AmountPresents = presents;
        }// SantaClaus


        // строковое представление деда мороза (метод ToString()) 
        public override string ToString() =>
            $"Фамилия Деда Мороза(актёра): {_surname}, " +
            $"Имя Деда Мороза(актёра): {_name}, " +
            $"Отчество Деда Мороза(актёра): {_patronymic}, " +
            $"в полушубке цвета {_coatColor}, " +
            $"подарков всего {_amountPresents}.";

    }// class SantaClaus
}
