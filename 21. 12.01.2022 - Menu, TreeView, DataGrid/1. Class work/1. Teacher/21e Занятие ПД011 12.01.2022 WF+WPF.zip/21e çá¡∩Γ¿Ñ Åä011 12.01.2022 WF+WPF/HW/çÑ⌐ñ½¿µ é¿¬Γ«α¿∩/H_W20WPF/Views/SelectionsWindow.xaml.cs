﻿
using H_W20WPF.Models.RepairShop;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace H_W20WPF.Views
{
    /// <summary>
    /// Логика взаимодействия для SelectionsWindow.xaml
    /// </summary>
    public partial class SelectionsWindow : Window
    {
        private List<Television> _televisions;
        public SelectionsWindow(List<Television> televisions, string prompt)
        {
            InitializeComponent();

            _televisions = televisions;

            TxbPrompt.Text = prompt;

            LsvTelevision.ItemsSource = _televisions;
        }
    }
}
