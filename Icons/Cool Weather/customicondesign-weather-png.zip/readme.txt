Free for non-commercial use.

Title: Cool Wheather

Author:  Custom Icon Design 
                 http://www.customicondesign.com