﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Santas.Helpers;

namespace Santas.Models
{
    public class RepairShop
    {
        public string Name { get; set; } // название мастерской

        public string Address { get; set; } // адрес мастерской

        public ObservableCollection<Television> Teles { get; set; } = new ObservableCollection<Television>();  //коллекция телевизоров


        // формирование данных коллекции
        public void Initialization()
        {
            Teles = RepairShop.GenerateTeles();
        }

        // формирование списка телевизоров данных коллекции
        static public ObservableCollection<Television> GenerateTeles(int n =10)
        {
            ObservableCollection<Television> televisions = new ObservableCollection<Television>();

            //формирование данных
            for(int i =0; i<n; i++)
            {
                televisions.Add(Factory());
            }

            return televisions;

        }


        // фабричный метод создания телевизора
        static public Television Factory()
        {
            //строки с дефектами
            string[] defect =
            {
                "эффект снега",
                "мигающее изображение",
                "вертикальные полосы",
                "битый пиксел",
                "буйство красок",
                "нет изображения",
                "неисправность матрицы",
                "спонтанное отключение"
            };

            //имена мастеров 
            string[] masters =
            {
                "Иванов И.И.",
                "Крыгин В.И.",
                "Кожухов Н.К.",
                "Андреев К.В."
            };

            // имена клиентов
            string[] clients =
            {
                "Тихонов Р.В.",
                "Замятин У.К.",
                "Маленков С.П.",
                "Егоров Н.З",
                "Сысоев В.Л.",
                "Громов М.А.",
                "Маяков Г.Е.",
                "Никонорова Р.В",
                "Григорян Е.У."
            };

            return new Television()
            {
                ManufactureType = Utils.Brands[Utils.GetRand(0, Utils.Brands.Length)],
                Diagonal = double.Parse(Utils.Diagonals[Utils.GetRand(0, Utils.Diagonals.Count)]),
                Defect = defect[Utils.GetRand(0, defect.Length)],
                MastersSurnameNP = masters[Utils.GetRand(0, masters.Length)],
                OwnersSurnameNP = clients[Utils.GetRand(0, clients.Length)],
                FixPrice = Utils.GetRand(3000, 7000)
            };
        }

        //добавление телевизора
        public void Add(Television television) => Teles.Add(television);

        //удаление телевизора
        public void Remove(Television television) => Teles.Remove(television);

        //удаление по индексу
        public void RemoveAt(int index) => Teles.RemoveAt(index);

        //очистка коллекции
        public void Clear() => Teles.Clear();

        //упорядочивание по компаратору
        public void OrderBy<TKey>(Func<Television, TKey> keySelector)
        {
            Teles = new ObservableCollection<Television>(Teles.OrderBy(keySelector));
        }
    }// Televison



    
}
