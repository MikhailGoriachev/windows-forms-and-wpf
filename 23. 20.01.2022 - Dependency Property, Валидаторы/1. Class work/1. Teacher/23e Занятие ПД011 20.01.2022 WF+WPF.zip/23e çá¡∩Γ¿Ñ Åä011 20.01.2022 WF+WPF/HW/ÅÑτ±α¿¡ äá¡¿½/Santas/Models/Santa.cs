﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Santas.Models
{
    //класс для представления данных актера, играющего роль Деда Мороза: 
    public class Santa
    {
        public string Name { get; set; } // имя актера

        public string Surname { get; set; } // фамилия актера

        public string Patronymic { get; set; } // отчество

        public string CoatColor { get; set; } // цвет полушубка

        private int _numberOfPresents;  // количество подарков

        public int NumberOfPresents
        {
            get => _numberOfPresents;
            set
            {
                if (value <= 0)
                    throw new ArgumentException(" Количество подарков не может быть открицательным");
                _numberOfPresents = value;
            }//set
        }

        public Santa() {}
        public Santa(string name, string surname, string patronymic, string color, int number)
        {
            Name = name;
            Surname = surname;
            Patronymic = patronymic;
            CoatColor = color;
            NumberOfPresents = number;
        }


    }
}
