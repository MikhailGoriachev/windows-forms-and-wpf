﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Santas.Models
{
    //класс для представления данных актрисы, играющей роль Снегурочки: 
    public class SnowGirl
    {
        public string Name { get; set; } // имя актрисы
        public string Surname { get; set; } // фамилия актрисы

        public string Patronymic { get; set; } // отчество актрисы

        public string CoatColor { get; set; } // цвет полушубка

        private int _numberOfVerses;          // количество стихов, которые знает Снегурочка

        public int NumberOfVerses
        {
            get => _numberOfVerses;
            set
            {
                if (value <= 0) 
                    throw new ArgumentException("Количество стихо не может быть отричательным");
                _numberOfVerses = value;
            }
        }

        private int _numberOfGames;     // количесто игра, которые знает Снегурочка

        public int NumberOfGames
        {
            get => _numberOfGames;
            set
            {
                if (value <= 0) 
                    throw new ArgumentException(" Количество игр не может быть отрицательным");
                _numberOfGames = value;
            }
        }

        public SnowGirl() {}
        public SnowGirl(string name, string surname, string patronymic, string color, int verses, int games)
        {
            Name = name;
            Surname = surname;
            Patronymic = patronymic;
            CoatColor = color;
            NumberOfVerses = verses;
            NumberOfGames = games;
        }
    }
}
