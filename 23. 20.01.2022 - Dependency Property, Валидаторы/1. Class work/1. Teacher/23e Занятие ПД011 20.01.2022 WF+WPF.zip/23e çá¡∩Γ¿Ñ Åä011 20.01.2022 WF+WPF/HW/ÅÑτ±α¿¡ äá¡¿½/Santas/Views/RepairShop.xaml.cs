﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Santas.Controllers;
using Santas.Models;
using Santas.Helpers;
using Santas.Views;

namespace Santas.Views
{
    /// <summary>
    /// Interaction logic for RepairShop.xaml
    /// </summary>
    public partial class RepairShop : Window
    {
        //контроллер по заданию
        private RepairShopController _controller;
        public RepairShop()
        {
            InitializeComponent();

            //установка значений
            _controller = new RepairShopController();
        }

        private void AddTelevision_Click(object sender, RoutedEventArgs e)
        {
            //создать окно для ввода параметров телевизора, принимаемого
            AddTelevisionWindow televisionWindow = new AddTelevisionWindow();

            //показать окно ввода модально, если форма завершается не по ОК
            if (televisionWindow.ShowDialog() == false) return;

            //добавить телевизор
            _controller.Repairshop.Add(televisionWindow.Television);
        }

        private void EditTelevision_Click(object sender, RoutedEventArgs e)
        {
            int index = Items.SelectedIndex;
            if (index == -1) return;
            // создать окно для ввода параметров телевизора
            AddTelevisionWindow televisionWindow = new AddTelevisionWindow("Редактирование телевизора", "Сохранить");
            televisionWindow.Television = _controller.Repairshop.Teles[index];

            //показать окно ввода модально
            if (televisionWindow.ShowDialog() == false) return;

            //редактировать телевизор
            _controller.Repairshop.Teles[index] = null;
           _controller.Repairshop.Teles[index] = televisionWindow.Television;
        }

        private void DeleteTelevision_Click(object sender, RoutedEventArgs e)
        {
            _controller.Remove((Television)Items.SelectedItem);
        }

        private void CreateCollection_Click(object sender, RoutedEventArgs e)
        {
            _controller.Initialization();

            Items.ItemsSource = _controller.Televisions;
        }

        private void Order_Click(object sender, RoutedEventArgs e)
        {
            //сортировка
            switch (CmbOrderBy.SelectedItem)
            {
                case "По производителю":
                    _controller.OrderByManufacture();
                    break;
                case "По убыванию диагонали экрана":
                    _controller.OrderByDiagonal();
                    break;
                case "По мастеру, выполняющему ремонт":
                    _controller.OrderByMaster();
                    break;
                case "По владельцу телевизора": 
                    _controller.OrderByOwner();
                    break;
            }
            //обновление привязки
            Items.ItemsSource = null;
            Items.ItemsSource = _controller.Televisions;

        }

        private void Select_Click(object sender, RoutedEventArgs e)
        {
            //выборка
            switch (CmbSelectionBy.SelectedItem)
            {
                case "Минимальная стоимость ремонта":
                    new SelectionWindow(_controller.SelectedMinPrice()).ShowDialog();
                    break;
                case "По мастеру":
                    SelectWindow windowMaster = new SelectWindow("Выборка телевизоров по мастеру", "Выбор мастера",
                        _controller.Televisions.Select(x => x.MastersSurnameNP).Distinct().ToList());

                    if (windowMaster.ShowDialog() == false) return;
                    new SelectionWindow(_controller.SelectedMaster(windowMaster.SelectionValue)).ShowDialog();
                    break;
                case "По диагонали экрана":

                    SelectWindow windowDiagonal = new SelectWindow("Выборка телевизора по диагонали", "Выбор диагонали",
                        _controller.Televisions.Select(x => x.Diagonal.ToString()).Distinct().ToList());

                    if (windowDiagonal.ShowDialog() == false) return;

                    new SelectionWindow(_controller.SelectedDiagonal(double.Parse(windowDiagonal.SelectionValue))).ShowDialog();
                    break;
                

            }//switch
        }

        
    }
}
