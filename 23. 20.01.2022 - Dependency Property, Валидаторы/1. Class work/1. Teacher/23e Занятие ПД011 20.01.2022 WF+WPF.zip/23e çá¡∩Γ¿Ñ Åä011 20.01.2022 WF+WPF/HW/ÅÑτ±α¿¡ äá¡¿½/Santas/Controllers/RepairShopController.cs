﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Santas.Models;
using Santas.Helpers;

namespace Santas.Controllers
{
    // Класс Контроллер обработки по заданию
    class RepairShopController
    {
        //ремонтная мастерская 
        private RepairShop _repairshop;

        public RepairShop Repairshop
        {
            get => _repairshop;
            set => _repairshop = value;
        }

        //доступ к телевизорам мастерской
        public ObservableCollection<Television> Televisions {
            get => _repairshop.Teles;
            set => _repairshop.Teles = value;
        }

        //конструктор инициализирующий
        public RepairShopController(RepairShop repairShop)
        {
            _repairshop = repairShop;
        }

        //конструктор по умолчанию 
        public RepairShopController():this(new RepairShop {Address = Utils.GetInfoRepairShop().Address,
                                                            Name = Utils.GetInfoRepairShop().Name, 
                                                            Teles = RepairShop.GenerateTeles() }){ }

        // переформирование коллекции телевизоров
        public void Initialization(int n = 15) =>
            _repairshop.Teles = RepairShop.GenerateTeles(n);

        //добавление телевизора
        public void Add(Television tele) => _repairshop.Add(tele);

        // удаление телевизора
        public void Remove(Television television) => _repairshop.Remove(television);

        //удаление телевизора по индексу
        public void RemoveAt(int index) => _repairshop.RemoveAt(index);

        //упорядочивание по производителю
        public void OrderByManufacture() => _repairshop.OrderBy(x => x.ManufactureType);

        // упорядочивание по владельцу телевизора
        public void OrderByOwner() => _repairshop.OrderBy(x => x.OwnersSurnameNP);

        //упорядочивание по мастеру
        public void OrderByMaster() => _repairshop.OrderBy(x => x.MastersSurnameNP);

        //упорядочивание по диагонали 
        public void OrderByDiagonal() => _repairshop.OrderBy(x => x.Diagonal);

        // Выборка и вывод в отдельном окне коллекции телевизоров, с заданной диагональю экрана
        public List<Television> SelectedDiagonal(double diagonal) => Televisions
            .Where(item => item.Diagonal == diagonal)
            .ToList();

        //выборка и вывод в отдельном окне коллекции телевизоров с минимальной стоимостью ремонта 
        public List<Television> SelectedMinPrice() => Televisions
            .Where(item => item.FixPrice == Televisions.Min(i => i.FixPrice))
            .ToList();
        // Выборка и вывод в отдельном окне коллекции телевизоров, ремонтируемых выбранным мастером
        public List<Television> SelectedMaster(string master) => Televisions
            .Where(item => item.MastersSurnameNP == master)
            .ToList();

    }
}
