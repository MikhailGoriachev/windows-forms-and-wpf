﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using H_W22WPF.Models.RepairShop;

namespace H_W22WPF.Controllers
{
    // Реализация функционала приложения
    // • Упорядочивание коллекции телевизоров
    //    o По производителю и типу
    //    o По убыванию диагонали экрана
    //    o По мастеру, выполняющему ремонт
    //    o По владельцу телевизора
    // • Выборка и вывод в отдельном окне коллекции телевизоров с минимальной стоимостью ремонта
    // • Выборка и вывод в отдельном окне коллекции телевизоров, ремонтируемых выбранным мастером
    // • Выборка и вывод в отдельном окне коллекции телевизоров, с заданной диагональю экрана

    public class RepairShopController
    {

        // объект для обработки
        private RepairShop _repairShop;

        public RepairShop RepairShop
        {
            get => _repairShop;
            private set => _repairShop = value;
        } // RepairShop


        // конструкторы
        public RepairShopController() : this(new RepairShop()) { }

        public RepairShopController(RepairShop repairShop)
        {
            _repairShop = repairShop;
        } // RepairShopController

        // Упорядочивание коллекции по производителю и типу
        public void OrderByBrand() => RepairShop.OrderBy(t => t.TvBrand);

        public static ObservableCollection<Television> OrderByBrand(ObservableCollection<Television> list) =>
             RepairShop.OrderBy(list, t => t.TvBrand);

        // Упорядочивание коллекции по убыванию диагонали экрана
        public void OrderByDiagonalDesc() => RepairShop.OrderBy(tv => tv.Diagonal);

        public static ObservableCollection<Television> OrderByDiagonalDesc(ObservableCollection<Television> list) =>
             RepairShop.OrderByDescending(list, t => t.Diagonal);

        // Упорядочивание коллекции по мастеру, выполняющему ремонт
        public void OrderByMaster() => RepairShop.OrderBy(tv=>tv.FullnameMaster);

        public static ObservableCollection<Television> OrderByMaster(ObservableCollection<Television> list) =>
              RepairShop.OrderBy(list, t => t.FullnameMaster);

        // Упорядочивание коллекции по владельцу телевизора
        public void OrderByOwner() => RepairShop.OrderBy(tv => tv.FullnameOwner);

        public static ObservableCollection<Television> OrderByOwner(ObservableCollection<Television> list) =>
            RepairShop.OrderBy(list, t => t.FullnameOwner);


        // Запрос на выборку в коллекцию телевизоров с минимальной стоимостью ремонта
        public ObservableCollection<Television> SelectWhereMinPrice() =>
            _repairShop.Filter(t => t.CostRepair == _repairShop.MinPrice);

        // Запрос на выборку в коллекцию телевизоров, ремонтируемых заданным мастером
        public ObservableCollection<Television> SelectWhereMaster(string repairer) =>
            _repairShop.Filter(t => t.FullnameMaster == repairer);

        // Запрос на выборку в коллекцию телевизоров с заданной диагональю экран
        public ObservableCollection<Television> SelectWhereDiagonal(int diagonal) =>
            _repairShop.Filter(t => t.Diagonal == diagonal);



    }// class RepairShopController
}
