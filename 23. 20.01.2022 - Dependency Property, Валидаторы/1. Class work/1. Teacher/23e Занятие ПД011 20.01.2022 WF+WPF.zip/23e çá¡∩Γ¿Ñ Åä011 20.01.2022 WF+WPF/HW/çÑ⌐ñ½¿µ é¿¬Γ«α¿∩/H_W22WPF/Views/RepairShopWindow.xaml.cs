﻿using H_W22WPF.Controllers;
using H_W22WPF.Models.RepairShop;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace H_W22WPF.Views
{
    /// <summary>
    /// Логика взаимодействия для RepairShopWindow.xaml
    /// </summary>
    public partial class RepairShopWindow : Window
    {
        // контроллер для работы с формой
        private RepairShopController _shopController;

        public RepairShopWindow(): this(new RepairShopController()) { }
        public RepairShopWindow(RepairShopController shopController)
        {
            InitializeComponent();

            _shopController = shopController;

            LblShopName.Content = _shopController.RepairShop.Name;
            LblShopAddress.Content = "Адрес: " + _shopController.RepairShop.Address;


            DgRepairShop.ItemsSource = _shopController.RepairShop.Televisions;

            // обновить строку состояния
            TbStatusBar.Text = $"Телевизоров в ремонте: {_shopController.RepairShop.Count}";
        }// RepairShopWindow

        // Закрыть окно
        private void Exit_Click(object sender, RoutedEventArgs e) => Close();


        // Обработка клика по кнопке "Ремонт телевизоров"
        private void RepairShop_Click(object sender, RoutedEventArgs e)
        {
            TbcMain.SelectedItem = TbcRepairShop;

            DgRepairShop.ItemsSource = _shopController.RepairShop.Televisions;

            // обновить строку состояния
            TbStatusBar.Text = $"Телевизоров в ремонте: {_shopController.RepairShop.Count}";
        }// RepairShop_Click

        #region Сортировка коллекции
        // сортировка коллекции телевизоров по производителю и типу
        private void OrderByBrand_Click(object sender, RoutedEventArgs e)
        {
            _shopController.OrderByBrand();

            // делаем страницу отсортированных данных текущей
            TbcMain.SelectedItem = TbcOrderBy;

            // остановить привязку
            DgOrderBy.ItemsSource = null;
            DgOrderBy.ItemsSource = _shopController.RepairShop.Televisions;

            // обновить строку состояния
            TbStatusBar.Text = $"Телевизоры отсортированы по бренду: {_shopController.RepairShop.Count}";
        }// OrderByBrand_Click


        // сортировка коллекции телевизоров по убыванию диагонали экрана
        private void OrderByDiagonalDesc_Click(object sender, RoutedEventArgs e)
        {
            _shopController.OrderByDiagonalDesc();

            // делаем страницу отсортированных данных текущей
            TbcMain.SelectedItem = TbcOrderBy;

            // остановить привязку
            DgOrderBy.ItemsSource = null;
            DgOrderBy.ItemsSource = _shopController.RepairShop.Televisions;

            // обновить строку состояния
            TbStatusBar.Text = $"Телевизоры отсортированы по убыванию диагонали: {_shopController.RepairShop.Count}";
        }// OrderByDiagonalDesc_Click


        // сортировка коллекции телевизоров по мастеру, выполняющему ремонт
        private void OrderByMaster_Click(object sender, RoutedEventArgs e)
        {
            _shopController.OrderByMaster();

            // делаем страницу отсортированных данных текущей
            TbcMain.SelectedItem = TbcOrderBy;

            // остановить привязку
            DgOrderBy.ItemsSource = null;
            DgOrderBy.ItemsSource = _shopController.RepairShop.Televisions;

            // обновить строку состояния
            TbStatusBar.Text = $"Телевизоры отсортированы по мастеру, выполняющему ремонт: {_shopController.RepairShop.Count}";
        }// OrderByMaster_Click


        // сортировка коллекции телевизоров по владельцу телевизора
        private void OrderByOwner_Click(object sender, RoutedEventArgs e)
        {
            _shopController.OrderByOwner();

            // делаем страницу отсортированных данных текущей
            TbcMain.SelectedItem = TbcOrderBy;

            // остановить привязку
            DgOrderBy.ItemsSource = null;
            DgOrderBy.ItemsSource = _shopController.RepairShop.Televisions;

            // обновить строку состояния
            TbStatusBar.Text = $"Телевизоры отсортированы по владельцу: {_shopController.RepairShop.Count}";
        }// OrderByOwner_Click

        #endregion


        #region Выборка 
        // выборка и вывод в отдельном окне коллекции телевизоров с минимальной стоимостью ремонта
        private void SelectMinPrice_Click(object sender, RoutedEventArgs e)
        {
            // делаем страницу отсортированных данных текущей
            TbcMain.SelectedItem = TbcSelected;

            // остановить привязку
            DgSelected.ItemsSource = null;
            DgSelected.ItemsSource = _shopController.SelectWhereMinPrice();

            // обновить строку состояния
            TbStatusBar.Text = $"Телевизорoв с минимальной стоимостью ремонта.";
        }// SelectMinPrice_Click

        // выборка и вывод в отдельном окне коллекции телевизоров, ремонтируемых выбранным мастером
        private void SelectByMaster_Click(object sender, RoutedEventArgs e)
        {
            // Создание формы выбора мастера
            ChoiceWindow choiceWindow = new ChoiceWindow(_shopController.RepairShop.GetMasters, "Выбор мастера", "Выберите мастера:");

            if (choiceWindow.ShowDialog() == false) return;

            // выбор мастера произведен, получим мастера, построим выборку
            SelectMaster(choiceWindow.Choosen);

            // обновить строку состояния
            TbStatusBar.Text = $"Телевизоры, ремонтируемые выбранным мастером.";
        }// SelectByMaster_Click


        // выборка и вывод в отдельном окне коллекции телевизоров, с заданной диагональю экрана 
        private void SelectByDiagonal_Click(object sender, RoutedEventArgs e)
        {
            // Создание формы выбора диагонали
            ChoiceWindow choiceWindow = new ChoiceWindow(_shopController.RepairShop.GetDiagonals,
                "Выбор диагонали", "Выберите диагональ:");

            if (choiceWindow.ShowDialog() == false) return;


            // выбор диагонали произведен, получим диагональ, построим выборку
            SelectDiagonal(choiceWindow.Choosen);
            // обновить строку состояния
            TbStatusBar.Text = $"Телевизоры, с заданной диагональю.";
        }// SelectByDiagonal_Click


        // формирование выборки ремонтов заданного мастера
        private void SelectMaster(string master)
        {
            // выбрать ремонты заданного мастера
            ObservableCollection<Television> list = _shopController.SelectWhereMaster(master);

            // вывести выборку в отдельной вкладку
            BindCollection(list, DgSelected);

            // делаем страницу выбранных данных текущей
            TbcMain.SelectedItem = TbcSelected;
        } // SelectMaster


        // формирование выборки ремонтов заданного мастера
        private void SelectDiagonal(string diagonal)
        {
            // выбрать телевизоры с заданной диагональю
            int numDiagonal = int.Parse(diagonal.Replace(@"""", ""));
            ObservableCollection<Television> list = _shopController.SelectWhereDiagonal(numDiagonal);

            // вывести выборку в отдельной вкладку
            BindCollection(list, DgSelected);

            // делаем страницу выбранных данных текущей
            TbcMain.SelectedItem = TbcSelected;

        } // SelectDiagonal

        #endregion

        // редактирование данных телевизора в ремонте
        private void EditTelevision_Click(object sender, RoutedEventArgs e)
        {
            TbcMain.SelectedItem = TbcRepairShop;

            // индекс выбранного элемента
            int selected = DgRepairShop.SelectedIndex;
            if (selected == -1) return;

            // передача данных в форму
            TelevisionWindow televisionWindow = new TelevisionWindow("Редактировать данные о телевизоре", "Сохранить");
            televisionWindow.Tv = _shopController.RepairShop.Televisions[selected];

            if (televisionWindow.ShowDialog() == false) return;

            // редактировать телевизор 
            _shopController.RepairShop.Televisions[selected] = televisionWindow.Tv;

            // остановить привязку
            DgRepairShop.ItemsSource = null;
            DgRepairShop.ItemsSource = _shopController.RepairShop.Televisions;

            // обновить строку состояния
            TbStatusBar.Text = $"Телевизоров в ремонте: {_shopController.RepairShop.Count}";
        }// EditTelevision_Click


        // прием телевизора в ремонт
        private void AddTelevision_Click(object sender, RoutedEventArgs e)
        {
            TbcMain.SelectedItem = TbcRepairShop;

            // создать окно для ввода параметров телевизора, принимаемого в ремонт
            TelevisionWindow televisionWindow = new TelevisionWindow();

            if (televisionWindow.ShowDialog() == false) return;

            // добавить телевизор в коллекцию ремонтируемых телевизоров
            _shopController.RepairShop.AddTelevizion(televisionWindow.Tv);

            // остановить привязку
            DgRepairShop.ItemsSource = null;
            DgRepairShop.ItemsSource = _shopController.RepairShop.Televisions;

            // обновить строку состояния
            TbStatusBar.Text = $"Телевизоров в ремонте: {_shopController.RepairShop.Count}";
        }// AddTelevision_Click


        // выдача телевизора с ремонта
        private void RemoveAtTv_Click(object sender, RoutedEventArgs e)
        {
            TbcMain.SelectedItem = TbcRepairShop;

            // индекс выбранного элемента
            int selected = DgRepairShop.SelectedIndex;
            if (selected == -1) return;

            _shopController.RepairShop.RemoveAt(selected);

            // остановить привязку
            DgRepairShop.ItemsSource = null;
            DgRepairShop.ItemsSource = _shopController.RepairShop.Televisions;

            // обновить строку состояния
            TbStatusBar.Text = $"Телевизоров в ремонте: {_shopController.RepairShop.Count}";
        }// RemoveAtTv_Click

        // выполнение привязки коллекции
        private void BindCollection(ObservableCollection<Television> list, DataGrid dataGrid)
        {
            // остановить привязку
            dataGrid.ItemsSource = null;

            // задать привязку
            dataGrid.ItemsSource = list;
        } // BindCollection
    }
}
