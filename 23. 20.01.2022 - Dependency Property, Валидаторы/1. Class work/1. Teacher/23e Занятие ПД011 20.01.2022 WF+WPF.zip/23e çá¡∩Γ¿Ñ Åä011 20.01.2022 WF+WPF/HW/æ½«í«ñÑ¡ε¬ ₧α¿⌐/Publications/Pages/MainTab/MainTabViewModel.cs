﻿using System;
using System.Collections;
using System.Collections.Specialized;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Controls;
using Microsoft.Win32;
using Publications.Infrastructure;
using Publications.Models;
using Publications.Pages.PublicationInput;
using Publications.Pages.SelectBy;
using Stylet;


namespace Publications.Pages.MainTab
{
	public class MainTabViewModel : TabScreen
	{
		private readonly IWindowManager _windowManager;

		public BindableCollection<Publication> Publications { get; } = new();
		public IList? SelectedPublications { get; set; }

		public int SelectedIndex { get; set; }

		public bool CanEdit => SelectedPublications is not null && SelectedPublications.Count == 1;
		public bool CanRemove => SelectedPublications is not null && SelectedPublications.Count > 0;

		private bool CanSelect { get; set; }
		public bool CanSelectByType => CanSelect;
		public bool CanSelectByDuration => CanSelect;
		public bool CanSelectBySubscriber => CanSelect;
		public bool CanSave => CanSelect;


		public MainTabViewModel(IWindowManager windowManager) : base("Главная вкладка")
		{
			_windowManager = windowManager;

			Publications.CollectionChanged += PublicationsOnCollectionChanged;
		}


		public void Fill()
		{
			Publications.Clear();

			var size = new Random().Next(12, 16);

			var maked = new PublicationFactory().Make(size);

			Publications.AddRange(maked);
		}


		public void Add()
		{
			var publicationViewModel = new PublicationViewModel();

			var result = _windowManager.ShowDialog(publicationViewModel);

			if (result == true)
				Publications.Add(publicationViewModel.Result);
		}


		public void Edit()
		{
			var selectedPublication = Publications[SelectedIndex];
			var copyOfSelectedPublication = (Publication)selectedPublication.Clone();
			var publicationViewModel = new PublicationViewModel(copyOfSelectedPublication);

			var result = _windowManager.ShowDialog(publicationViewModel);

			if (result == true)
				Publications[SelectedIndex] = publicationViewModel.Result;
		}


		public void Remove()
		{
			Publications.RemoveRange(SelectedPublications!.Cast<Publication>());
			SelectedPublications = null;
		}


		public void Save()
		{
			var dialog = new OpenFileDialog();

			ShowJsonFileDialog(dialog);

			var repo = new JsonRepository<Publication>(dialog.FileName);

			repo.SaveRange(Publications);
		}


		public void Load()
		{
			var dialog = new OpenFileDialog();

			ShowJsonFileDialog(dialog);

			var repo = new JsonRepository<Publication>(dialog.FileName);

			Publications.Clear();
			Publications.AddRange(repo.LoadRange());
		}


		private bool ShowJsonFileDialog(FileDialog dialog)
		{
			dialog.Filter       = "JSON documents|*.json";
			dialog.DefaultExt   = ".json";
			dialog.AddExtension = true;

			var result = dialog.ShowDialog();

			return result == true;
		}


		public void SelectByType()
		{
			var selectables = Publications
							  .Select(t => t.Type!)
							  .Distinct()
							  .ToArray();

			var selectRunner = new SelectByRunner<string>(this, _windowManager);

			selectRunner.SelectBy("Выборка по типу", selectables, type =>
				Publications
					.Where(publication => publication?.Type?.Equals(
											  type,
											  StringComparison.CurrentCultureIgnoreCase)
										  ?? false));
		}


		public void SelectByDuration()
		{
			var selectables = Publications
							  .Select(t => t.Subscription!.Duration)
							  .Distinct()
							  .ToArray();

			var selectRunner = new SelectByRunner<int>(this, _windowManager);

			selectRunner.SelectBy("Выборка по периоду подписки", selectables, duration =>
				Publications
					.Where(publication => publication.Subscription.Duration == duration));
		}


		public void SelectBySubscriber()
		{
			var selectables = Publications
							  .Select(t => t.Subscriber!)
							  .Distinct()
							  .ToArray();

			var selectRunner = new SelectByRunner<string>(this, _windowManager);

			selectRunner.SelectBy("Выборка по подписчику", selectables, type =>
				Publications
					.Where(publication => publication?.Subscriber?.Equals(
											  type,
											  StringComparison.CurrentCultureIgnoreCase)
										  ?? false));
		}


		public void SelectionChanged(object sender, SelectionChangedEventArgs e) =>
			SelectedPublications = ((DataGrid)sender).SelectedItems;


		private void PublicationsOnCollectionChanged(object? sender, NotifyCollectionChangedEventArgs e) =>
			CanSelect = Publications.Count > 0;
	}
}