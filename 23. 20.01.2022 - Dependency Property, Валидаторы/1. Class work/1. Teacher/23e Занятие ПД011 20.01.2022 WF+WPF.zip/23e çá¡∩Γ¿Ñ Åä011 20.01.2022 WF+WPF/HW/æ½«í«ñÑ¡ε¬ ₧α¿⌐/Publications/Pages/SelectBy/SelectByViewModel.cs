﻿using System.Collections;
using Stylet;


namespace Publications.Pages.SelectBy
{
	public sealed class SelectByViewModel : Screen
	{
		public string Title { get; }

		public ICollection SelectableItems { get; }
		public object SelectedItem { get; set; }


		public SelectByViewModel(string title, IList selectableItems)
		{
			Title           = title;
			SelectableItems = selectableItems;
			SelectedItem    = selectableItems[0]!;
		}


		public void Accept() => RequestClose(dialogResult: true);
	}
}