﻿using System;
using System.Collections.Generic;
using Publications.Models;


namespace Publications.Infrastructure
{
	public sealed class PublicationFactory
	{
		private int _filler = 0;

		public Publication Make()
		{
			_filler++;

			return new()
			{
				Subscriber = $"Subscriber{_filler}",
				Address = new()
				{
					Flat   = $"Flat{_filler}",
					House  = $"House{_filler}",
					Street = $"Street{_filler}"
				},
				Index = $"Index{_filler}",
				Title = $"Title{_filler}",
				Type = $"Type{_filler}",
				Subscription = new()
				{
					Duration   = _filler,
					Start = DateTime.UtcNow.AddDays(_filler),
				}
			};
		}

		public List<Publication> Make(int size)
		{
			var list = new List<Publication>();

			for (int i = 0; i < size; i++)
				list.Add(Make());

			return list;
		}
	}
}