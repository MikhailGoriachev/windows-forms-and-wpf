﻿using Stylet;


namespace Publications.Infrastructure
{
	public interface IShell
	{
		void ActivateItem(Screen screen);
	}
}