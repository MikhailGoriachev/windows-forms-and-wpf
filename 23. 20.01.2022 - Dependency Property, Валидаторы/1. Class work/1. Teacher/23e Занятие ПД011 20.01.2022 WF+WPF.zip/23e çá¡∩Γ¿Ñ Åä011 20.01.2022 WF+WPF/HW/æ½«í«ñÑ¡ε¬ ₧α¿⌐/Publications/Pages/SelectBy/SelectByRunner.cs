﻿using System;
using System.Collections;
using System.Collections.Generic;
using Publications.Infrastructure;
using Publications.Models;
using Publications.Pages.SelectionTab;
using Stylet;


namespace Publications.Pages.SelectBy
{
	public class SelectByRunner<TSelected>
	{
		private readonly TabScreen _ownerTabScreen;
		private readonly IWindowManager _windowManager;


		public SelectByRunner(TabScreen ownerTabScreen, IWindowManager windowManager)
		{
			_ownerTabScreen = ownerTabScreen;
			_windowManager  = windowManager;
		}


		public void SelectBy(string selectDescription, IList<TSelected> selectables, 
										Func<TSelected, IEnumerable<Publication>> getSelectedItems)
		{
			if (TryGetSelectByWithDialog(selectDescription, (IList)selectables, out var selectByViewModel) == false)
				return;

			var selectedType = (TSelected)selectByViewModel.SelectedItem;

			var selectedItems = getSelectedItems(selectedType);

			OpenSelectionTab(selectByViewModel.Title, selectedType, selectedItems);
		}


		private bool TryGetSelectByWithDialog(string selectDescription, IList selectables, out SelectByViewModel selectByViewModel)
		{
			selectByViewModel = new(selectDescription, selectables);

			var dialogResult = _windowManager.ShowDialog(selectByViewModel);

			return dialogResult == true;
		}


		private void OpenSelectionTab(string selectDescription, TSelected selectedItem, IEnumerable<Publication> selected)
		{
			var bindableSelectedItems = new BindableCollection<Publication>(selected);

			var selectedViewModel = new SelectionTabViewModel($"{selectDescription} \"{selectedItem}\"", bindableSelectedItems);

			_ownerTabScreen.ActivateOtherTab(selectedViewModel);
		}
	}
}