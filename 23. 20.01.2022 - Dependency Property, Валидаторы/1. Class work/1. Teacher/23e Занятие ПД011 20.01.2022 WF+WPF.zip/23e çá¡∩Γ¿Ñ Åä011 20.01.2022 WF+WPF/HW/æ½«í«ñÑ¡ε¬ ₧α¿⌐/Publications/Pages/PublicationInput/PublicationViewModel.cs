﻿using System.Globalization;
using System.Windows.Markup;
using Publications.Models;
using Stylet;


namespace Publications.Pages.PublicationInput
{
	public sealed class PublicationViewModel : Screen
	{
		public static XmlLanguage DatePickerLanguage =>
			XmlLanguage.GetLanguage(CultureInfo.CurrentCulture.IetfLanguageTag);

		public Publication Result { get; private set; } = null!;
		public string Title { get; private set; } = null!;


		public PublicationViewModel() =>
			InitializeWith(new() { Address = new(), Subscription = new() }, "Добавление новой подписки");


		public PublicationViewModel(Publication itemToEdit) =>
			InitializeWith(itemToEdit, "Изменение сущестующей подписки");


		public void Accept() => RequestClose(true);


		private void InitializeWith(Publication item, string title) =>
			(Result, Title) = (item, title);
	}
}