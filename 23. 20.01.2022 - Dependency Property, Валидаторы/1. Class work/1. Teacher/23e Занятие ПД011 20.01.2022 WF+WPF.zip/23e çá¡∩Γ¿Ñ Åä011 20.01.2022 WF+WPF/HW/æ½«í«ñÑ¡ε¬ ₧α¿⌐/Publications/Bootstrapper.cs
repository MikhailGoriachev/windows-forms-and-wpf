﻿using Publications.Pages.Shell;
using Stylet;


namespace Publications
{
	public sealed class Bootstrapper : Bootstrapper<ShellViewModel> { }
}