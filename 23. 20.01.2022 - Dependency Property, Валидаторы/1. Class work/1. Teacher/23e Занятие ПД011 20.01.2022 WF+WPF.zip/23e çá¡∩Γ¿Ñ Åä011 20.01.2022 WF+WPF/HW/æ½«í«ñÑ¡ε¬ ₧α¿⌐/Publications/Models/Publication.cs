﻿using System;
using System.ComponentModel;


namespace Publications.Models
{
	public sealed class Publication : INotifyPropertyChanged, ICloneable
	{
		public string? Subscriber { get; set; }
		public Address? Address { get; set; }
		public string? Title { get; set; }
		public string? Type { get; set; }
		public string? Index { get; set; }
		public Subscription? Subscription { get; set; }


		public event PropertyChangedEventHandler? PropertyChanged;


		public object Clone() => new Publication
		{
			Subscriber   = (string)Subscriber.Clone(),
			Address      = (Address)Address.Clone(),
			Title        = (string)Title.Clone(),
			Type         = (string)Type.Clone(),
			Index        = (string)Index.Clone(),
			Subscription = (Subscription)Subscription.Clone()
		};
	}
}