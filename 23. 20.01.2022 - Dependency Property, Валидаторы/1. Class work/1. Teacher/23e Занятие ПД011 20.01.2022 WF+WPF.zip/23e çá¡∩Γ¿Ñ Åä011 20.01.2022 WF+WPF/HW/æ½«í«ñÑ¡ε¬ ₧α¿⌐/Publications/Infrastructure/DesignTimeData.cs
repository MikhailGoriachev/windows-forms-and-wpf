﻿using Publications.Models;


namespace Publications.Infrastructure
{
	public static class DesignTimeData
	{
		public static readonly Publication[] Publications;


		static DesignTimeData()
		{
			Publications = new PublicationFactory().Make(7).ToArray();
		}
	}
}