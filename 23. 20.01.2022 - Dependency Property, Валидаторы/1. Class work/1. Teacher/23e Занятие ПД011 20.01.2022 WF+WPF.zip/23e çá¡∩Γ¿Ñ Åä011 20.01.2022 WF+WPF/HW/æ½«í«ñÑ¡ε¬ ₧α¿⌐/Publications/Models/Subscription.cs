﻿using System;
using System.ComponentModel;


namespace Publications.Models
{
	public sealed class Subscription : INotifyPropertyChanged, ICloneable
	{
		public static readonly int[] Durations = { 1, 3, 6, 12 };

		public DateTime Start { get; set; }
		public int Duration { get; set; }


		public event PropertyChangedEventHandler? PropertyChanged;


		public object Clone() => new Subscription
		{
			Start    = Start,
			Duration = Duration
		};
	}
}