﻿using System;
using System.Collections.Generic;
using System.Linq;


namespace Main.Infrastructure
{
	internal static class Extensions
	{
		public static T MaxBy<T, TKey>(this IEnumerable<T> enumerable, Func<T, TKey> selector) =>
			enumerable.OrderByDescending(selector).First();
	}
}