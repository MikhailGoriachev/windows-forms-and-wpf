﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Stylet;


namespace Main.Pages.Shell.TelevisionsTab
{
	public sealed class SelectByViewModel : Screen
	{
		public string Title { get; }

		public ICollection SelectableItems { get; }
		public object SelectedItem { get; set; }

		public ICollection<Television> SourceItems { get; }

		public Func<Television, object, bool> Filter { get; }
		public ICollection<Television> FilteredItems { get; private set; }


		public SelectByViewModel() { }


		public SelectByViewModel(string title,
								 ICollection selectableItems,
								 ICollection<Television> sourceItems,
								 Func<Television, object, bool> filter)
		{
			Title                  = title;
			SelectableItems        = selectableItems;
			SourceItems            = sourceItems;
			Filter                 = filter;
		}


		public void FilterItems() =>
			FilteredItems = SourceItems.Where(t => Filter.Invoke(t, SelectedItem)).ToArray();
	}
}