﻿using System.Collections.Generic;
using Main.Pages.Shell.TelevisionsTab;


namespace Main.Infrastructure
{
	public class TelevisionFactory
	{
		private int _filler = 0;

		public Television Make()
		{
			_filler++;

			return new()
			{
				Producer = $"Producer {_filler}",
				Owner = $"Owner {_filler}",
				Repairer = $"Repairer {_filler}",
				Defect = $"Defect {_filler}",
				Diagonal = _filler,
				RepairCost = _filler,
			};
		}


		public List<Television> Make(int size)
		{
			var list = new List<Television>();

			for (int i = 0; i < size; i++)
				list.Add(Make());

			return list;
		}
	}
}