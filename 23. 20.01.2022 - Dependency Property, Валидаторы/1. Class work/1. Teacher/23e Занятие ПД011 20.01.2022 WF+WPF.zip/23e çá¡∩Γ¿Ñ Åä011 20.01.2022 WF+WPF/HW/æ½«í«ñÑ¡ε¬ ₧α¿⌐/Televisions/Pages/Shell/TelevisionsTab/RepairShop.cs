﻿using Stylet;


namespace Main.Pages.Shell.TelevisionsTab
{
	public sealed class RepairShop : PropertyChangedBase
	{
		public string Title { get; set; }
		public string Address { get; set; }
		public BindableCollection<Television> Televisions { get; } = new();
	}
}