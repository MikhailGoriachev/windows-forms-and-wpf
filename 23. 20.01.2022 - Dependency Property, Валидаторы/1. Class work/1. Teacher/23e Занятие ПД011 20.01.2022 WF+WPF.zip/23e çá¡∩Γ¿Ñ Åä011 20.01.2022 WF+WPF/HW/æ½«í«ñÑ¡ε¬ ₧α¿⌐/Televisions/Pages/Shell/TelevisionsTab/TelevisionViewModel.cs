﻿using Stylet;


namespace Main.Pages.Shell.TelevisionsTab
{
	public sealed class TelevisionViewModel : Screen
	{
		public Television Result { get; private set; }
		public string Title { get; private set; }


		public TelevisionViewModel() => InitializeWith(new(), "Добавление нового");


		public TelevisionViewModel(Television itemToEdit) => InitializeWith(itemToEdit, "Изменение сущестующего");


		public void Accept() => RequestClose(true);


		private void InitializeWith(Television item, string title) =>
			(Result, Title) = (item, title);
	}
}