﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Controls;
using Main.Infrastructure;
using Stylet;


namespace Main.Pages.Shell.TelevisionsTab
{
	public sealed class TelevisionsTabViewModel : Screen
	{
		private readonly IWindowManager _manager;


		public RepairShop RepairShop { get; } = new()
			{ Address = "Адрес", Title = "Название" };

		public IList<Television> SelectedTelevisions { get; set; }

		public bool CanEdit => SelectedTelevisions is not null && SelectedTelevisions.Count == 1;

		public bool CanRemove => SelectedTelevisions is not null && SelectedTelevisions.Count >= 1;


		public TelevisionsTabViewModel(IWindowManager manager)
		{
			DisplayName = "Ремонт телевизоров";
			_manager    = manager;
		}


		public TelevisionsTabViewModel() { }


		public void Fill()
		{
			RepairShop.Televisions.Clear();

			var size = new Random().Next(12, 16);

			var maked = new TelevisionFactory().Make(size);

			RepairShop.Televisions.AddRange(maked);
		}


		public void Add()
		{
			var televisionViewModel = new TelevisionViewModel();

			var result = _manager.ShowDialog(televisionViewModel);

			if (result is true)
				RepairShop.Televisions.Add(televisionViewModel.Result);
		}


		public void Remove() =>
			RepairShop.Televisions.RemoveRange(SelectedTelevisions);


		public void Edit()
		{
			var televisionViewModel = new TelevisionViewModel(SelectedTelevisions.First());

			_manager.ShowDialog(televisionViewModel);
		}


		public void SelectByRepairer()
		{
			var selectables = RepairShop.Televisions
										.Select(t => t.Repairer)
										.Distinct()
										.ToArray();

			var selectBy = new SelectByViewModel(
				"Выборка по мастеру",
				selectables,
				RepairShop.Televisions, (t, o) =>
				{
					var selectedRepairer = o as string;

					return t.Repairer.Equals(selectedRepairer, StringComparison.CurrentCulture);
				});

			_manager.ShowDialog(selectBy);
		}


		public void SelectByDiagonal()
		{
			var selectables = RepairShop.Televisions
										.Select(t => t.Diagonal)
										.Distinct()
										.ToArray();

			var selectBy = new SelectByViewModel(
				"Выборка по диагонали",
				selectables,
				RepairShop.Televisions, (t, o) =>
				{
					var selectedDiagonal = (int)o;

					return t.Diagonal == selectedDiagonal;
				});

			_manager.ShowDialog(selectBy);
		}


		public void SelectByCost()
		{
			var selectables = RepairShop.Televisions
										.Select(t => t.RepairCost)
										.Distinct()
										.ToArray();

			var selectBy = new SelectByViewModel(
				"Выборка по цене",
				selectables,
				RepairShop.Televisions, (t, o) =>
				{
					var selectedCost = (decimal)o;

					return t.RepairCost == selectedCost;
				})
			{
				SelectedItem = RepairShop.Televisions.Min(t => t.RepairCost)
			};
			selectBy.FilterItems();

			_manager.ShowDialog(selectBy);
		}


		public void SelectionChanged(object sender, SelectionChangedEventArgs e) =>
			SelectedTelevisions = ((DataGrid)sender).SelectedItems
													.Cast<Television>()
													.ToArray();
	}
}