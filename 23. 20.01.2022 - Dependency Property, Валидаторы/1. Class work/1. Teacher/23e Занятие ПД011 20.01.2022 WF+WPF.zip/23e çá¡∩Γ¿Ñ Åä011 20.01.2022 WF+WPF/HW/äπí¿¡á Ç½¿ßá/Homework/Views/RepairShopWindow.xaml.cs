﻿using Homework.Helpers;
using Homework.Controllers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Homework.Models.Task2;

namespace Homework.Views
{
    /// <summary>
    /// Логика взаимодействия для RepairShopWindow.xaml
    /// </summary>
    public partial class RepairShopWindow : Window
    {
        // контроллер
        private RepairShopController _repairShopController;

        public RepairShopWindow() : this(new RepairShopController()){}
        public RepairShopWindow(RepairShopController repairShopController) {
            InitializeComponent();

            _repairShopController = repairShopController;

            TbxAddress.Text =
                $"  Ремонтная мастерская \"{_repairShopController.RepairShop.Title}\", " +
                $"{_repairShopController.RepairShop.Address}";

            BindCollection(_repairShopController.RepairShop.Televisions, DgvTelevision);
            TbStatusBar.Text = $"Телевизоров в ремонте: {_repairShopController.RepairShop.Televisions.Count}";
        } // RepairShopWindow

        #region Изменение цвета надписи на кнопке при перемещении курсора мыши на кнопку
        private void Button_MouseEnter(object sender, MouseEventArgs e) {
            Button btn = e.OriginalSource as Button;
            btn.Foreground = new SolidColorBrush(Color.FromArgb(255, 0, 0, 0));
        } // Button_MouseEnter

        private void Button_MouseLeave(object sender, MouseEventArgs e) {
            Button btn = e.OriginalSource as Button;
            btn.Foreground = new SolidColorBrush(Colors.White);
        } // Button_MouseLeave
        #endregion

        // выполнение привязки коллекции
        private void BindCollection(List<Television> list, DataGrid dataGrid) {
            // остановить привязку
            dataGrid.ItemsSource = null;

            // задать привязку
            dataGrid.ItemsSource = list;
        } // BindCollection

        private void Exit_Click(object sender, RoutedEventArgs e) => Close();

        // выполнение формирования данных ремонтной мастерской 
        private void NewRepairShop_Command(object sender, RoutedEventArgs e) {
            TbcTelevisions.SelectedItem = MainTab;
            TbxAddress.Text =
                $"  Ремонтная мастерская \"{_repairShopController.RepairShop.Title}\", " +
                $"{_repairShopController.RepairShop.Address}";

            _repairShopController.RepairShop.Initialize(Utils.GetRandom(12, 15));

            BindCollection(_repairShopController.RepairShop.Televisions, DgvTelevision);
            TbStatusBar.Text = $"Телевизоров в ремонте: {_repairShopController.RepairShop.Televisions.Count}";
        } // NewRepairShop_Command

        // сортировка коллекции телевизоров по производителю и типу
        private void OrderByBrand_Command(object sender, RoutedEventArgs e) {
            BindCollection(_repairShopController.OrderByBrand(), DgvSorted);

            TbcTelevisions.SelectedItem = SortedTab;

            // формирование заголовка поля вывода данных о телевизорах
            TbxAddress.Text =
                $"  Ремонтная мастерская \"{_repairShopController.RepairShop.Title}\", " +
                $"{_repairShopController.RepairShop.Address}, телевизоры по производителю и типу";
        } // OrderByBrand_Command


        // сортировка коллекции телевизоров по убыванию диагонали экрана
        private void OrderByDiagonalDesc_Command(object sender, RoutedEventArgs e) {
            BindCollection(_repairShopController.OrderByDiagonalDesc(), DgvSorted);

            TbcTelevisions.SelectedItem = SortedTab;

            // формирование заголовка поля вывода данных о телевизорах
            TbxAddress.Text =
                $"  Ремонтная мастерская \"{_repairShopController.RepairShop.Title}\", " +
                $"{_repairShopController.RepairShop.Address}, телевизоры по убыванию диагонали экрана";
        } // OrderByDiagonalDesc_Command


        // сортировка коллекции телевизоров по мастеру, выполняющему ремонт
        private void OrderByArtisan_Command(object sender, RoutedEventArgs e) {
            BindCollection(_repairShopController.OrderByArtisan(), DgvSorted);

            TbcTelevisions.SelectedItem = SortedTab;

            // формирование заголовка поля вывода данных о телевизорах
            TbxAddress.Text =
                $"  Ремонтная мастерская \"{_repairShopController.RepairShop.Title}\", " +
                $"{_repairShopController.RepairShop.Address}, телевизоры по мастеру, выполняющему ремонт";
        } // OrderByArtisan_Command


        // сортировка коллекции телевизоров по владельцу телевизора
        private void OrderByOwner_Command(object sender, RoutedEventArgs e) {
            BindCollection(_repairShopController.OrderByOwner(), DgvSorted);

            TbcTelevisions.SelectedItem = SortedTab;

            // формирование заголовка поля вывода данных о телевизорах
            TbxAddress.Text =
                $"  Ремонтная мастерская \"{_repairShopController.RepairShop.Title}\", " +
                $"{_repairShopController.RepairShop.Address}, телевизоры по владельцу телевизора";
        } // OrderByOwner_Command

        // выборка коллекции телевизоров с минимальной
        // стоимостью ремонта
        private void SelectMinPrice_Command(object sender, RoutedEventArgs e) {
            TbxAddress.Text =  $"  Ремонтная мастерская \"{_repairShopController.RepairShop.Title}\", " +
                $"{_repairShopController.RepairShop.Address}, телевизоры с минимальной стоимостью ремонта";

            BindCollection(_repairShopController.SelectWhereMinPrice(), DgvSelected);
            TbcTelevisions.SelectedItem = SelectedTab;
        } // SelectMinPrice_Command

        // выборка ремонтов, выполняемых мастером, команда для меню  
        private void SelectArtisan_Command(object sender, RoutedEventArgs e) {
            // получить список фамилий из коллекции ремонтов
            List<string> artisans = _repairShopController.GetArtitans();

            // создание окна выбора мастера, передача в окно списка мастеров
            ChoiceWindow ChoiceWindow = new ChoiceWindow(artisans, "Мастер для выборки:");

            if (ChoiceWindow.ShowDialog() == false) return;

            BindCollection(_repairShopController.SelectWhereArtisan(ChoiceWindow.Choice), DgvSelected);
            TbcTelevisions.SelectedItem = SelectedTab;
        } // SelectArtisan_Command

        // выборка телевизоров, с заданной диагональю экрана 
        private void SelectDiagonal_Command(object sender, RoutedEventArgs e) {
            // получить список диагоналей из коллекции ремонтов
            List<string> diagonals = _repairShopController.GetDiagonals();

            // создание окна выбора мастера, передача в окно списка мастеров
            ChoiceWindow ChoiceWindow = new ChoiceWindow(diagonals, "Диагональ для выборки:");

            if (ChoiceWindow.ShowDialog() == false) return;

            BindCollection(_repairShopController.SelectWhereDiagonal(double.Parse(ChoiceWindow.Choice)), DgvSelected);
            TbcTelevisions.SelectedItem = SelectedTab;
        } // SelectDiagonal_Command

        // Выдача телевизора
        private void DeleteTelevision_Command(object sender, RoutedEventArgs e) {
            TbcTelevisions.SelectedItem = MainTab;
            int index = DgvTelevision.SelectedIndex;
            if (index == -1) return;

            _repairShopController.RepairShop.RemoveAt(index);

            BindCollection(_repairShopController.RepairShop.Televisions, DgvTelevision);
            TbStatusBar.Text = $"Телевизоров в ремонте: {_repairShopController.RepairShop.Televisions.Count}";
        } // DeleteTelevision_Command

        private void TbcTelevisions_SelectionChanged(object sender, SelectionChangedEventArgs e) =>
            TbxAddress.Text =
                $"  Ремонтная мастерская \"{_repairShopController.RepairShop.Title}\", " +
                $"{_repairShopController.RepairShop.Address}";

        // при обновлении/добавлении данных - коллекция обновляется
        private void DgvTelevision_LoadingRow(object sender, DataGridRowEventArgs e) {
            _repairShopController.RepairShop.Televisions = DgvTelevision.ItemsSource as List<Television>;
            TbStatusBar.Text = $"Телевизоров в ремонте: {_repairShopController.RepairShop.Televisions.Count}";
        } // DgvTelevision_LoadingRow
    }
}
