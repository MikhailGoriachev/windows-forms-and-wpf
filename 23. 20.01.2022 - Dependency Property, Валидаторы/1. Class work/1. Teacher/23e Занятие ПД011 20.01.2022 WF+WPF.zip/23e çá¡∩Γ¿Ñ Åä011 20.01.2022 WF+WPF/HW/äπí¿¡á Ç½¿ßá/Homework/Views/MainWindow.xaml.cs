﻿using Homework.Models.Task1;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
// using Homework.Models;

namespace Homework.Views { 
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow() {
            InitializeComponent();

            List<SnowMaiden> snowMaidens = new List<SnowMaiden>(new SnowMaiden[] {
                new SnowMaiden{ Surname = "Якубовская",  Name = "Диана",     Patronymic = "Павловна",      Color = "красный",  Poetries =  8, Games = 21},
                new SnowMaiden{ Surname = "Пелых",       Name = "Марина",    Patronymic = "Ульяновна",     Color = "синий",    Poetries =  9, Games =  6},
                new SnowMaiden{ Surname = "Лапотникова", Name = "Тамара",    Patronymic = "Оскаровна",     Color = "зеленый",  Poetries = 11, Games =  9},
                new SnowMaiden{ Surname = "Яйло",        Name = "Екатерина", Patronymic = "Николаевна",    Color = "бордовый", Poetries = 13, Games = 10},
                new SnowMaiden{ Surname = "Лосева",      Name = "Инна",      Patronymic = "Степановна",    Color = "белый",    Poetries = 21, Games = 16},
                new SnowMaiden{ Surname = "Михайлова",   Name = "Анна",      Patronymic = "Валентиновна",  Color = "красный",  Poetries =  5, Games = 18},
                new SnowMaiden{ Surname = "Потемкина",   Name = "Наталья",   Patronymic = "Павловна",      Color = "синий",    Poetries =  6, Games =  6},
                new SnowMaiden{ Surname = "Царькова",    Name = "Лариса",    Patronymic = "Ильинична",     Color = "зеленый",  Poetries =  9, Games =  9},
                new SnowMaiden{ Surname = "Хавалджи",    Name = "Любовь",    Patronymic = "Амировна",      Color = "белый",    Poetries =  7, Games = 10},
                new SnowMaiden{ Surname = "Пархоменко",  Name = "Ирина",     Patronymic = "Владимировна",  Color = "белый",    Poetries =  4, Games =  3},
                new SnowMaiden{ Surname = "Демидова",    Name = "Алина",     Patronymic = "Александровна", Color = "желтый",   Poetries = 15, Games =  7},
                new SnowMaiden{ Surname = "Лысенко",     Name = "Елена",     Patronymic = "Егоровна",      Color = "красный",  Poetries = 17, Games =  3},
                new SnowMaiden{ Surname = "Федосенко",   Name = "Оксана",    Patronymic = "Владимировна",  Color = "синий",    Poetries = 19, Games = 18},
                new SnowMaiden{ Surname = "Богатырева",  Name = "Екатерина", Patronymic = "Алексеевна",    Color = "бордовый", Poetries =  4, Games = 21},
                new SnowMaiden{ Surname = "Иванова",     Name = "Валентина", Patronymic = "Степановна",    Color = "красный",  Poetries =  3, Games = 11}
            });

            DgvActresses.ItemsSource = snowMaidens;

            TxbStatus2.Text = $"{DgvActors.Items.Count}";
            TxbStatus4.Text = $"{DgvActresses.Items.Count}";
        } // MainWindow

        #region Изменение цвета надписи на кнопке при перемещении курсора мыши на кнопку
        private void Button_MouseEnter(object sender, MouseEventArgs e) {
            Button btn = e.OriginalSource as Button;
            btn.Foreground = new SolidColorBrush(Color.FromArgb(255, 0, 0, 0));
        } // Button_MouseEnter

        private void Button_MouseLeave(object sender, MouseEventArgs e) {
            Button btn = e.OriginalSource as Button;
            btn.Foreground = new SolidColorBrush(Colors.White);
        } // Button_MouseLeave
        #endregion
        private void Exit_Click(object sender, RoutedEventArgs e) => Close();

        // Открыть окно со сведениями о приложении и разработчике
        private void About_Click(object sender, RoutedEventArgs e) {
            AboutWindow aboutWindow = new AboutWindow();
            aboutWindow.ShowDialog();
        } // About_Click

        private void Televisions_Click(object sender, RoutedEventArgs e) {
            RepairShopWindow repairShopWindow = new RepairShopWindow();
            repairShopWindow.ShowDialog();
        } // RepairShop_Click
    }
}
