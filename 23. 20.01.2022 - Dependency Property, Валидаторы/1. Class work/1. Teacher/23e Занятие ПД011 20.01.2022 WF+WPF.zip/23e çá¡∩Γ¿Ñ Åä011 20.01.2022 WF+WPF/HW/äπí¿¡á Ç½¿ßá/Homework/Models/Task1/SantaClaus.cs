﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Homework.Models.Task1
{
    // класс для представления данных актера, играющего роль Деда Мороза:
    // фамилия, имя, отчество, цвет полушубка, количество подарков, которые способен перенести актер.
    internal class SantaClaus {
        // фамилия
        private string _surname;
        public string Surname {
            get => _surname; 
            set { if (String.IsNullOrWhiteSpace(value)) throw new Exception("SantaClaus: Некорректное значение фамилии!");
                _surname = value; } // set
        } // Surname

        // имя
        private string _name;
        public string Name {
            get => _name; 
            set { if (String.IsNullOrWhiteSpace(value)) throw new Exception("SantaClaus: Некорректное значение имени!");
                _name = value; } // set
        } // Name


        // отчество
        private string _patronymic;
        public string Patronymic {
            get => _patronymic;
            set { if (String.IsNullOrWhiteSpace(value)) throw new Exception("SantaClaus: Некорректное значение отчества!");
                _patronymic = value;
            } // set
        } // Patronymic

        // цвет полушубка
        private string _color;
        public string Color  {
            get => _color;
            set {
                if (String.IsNullOrWhiteSpace(value)) throw new Exception("SantaClaus: Некорректное значение цветa полушубка!");
                _color = value; } // set
        } // Color

        // количество подарков, которые способен перенести актер
        private int _presents;
        public int Presents {
            get => _presents;
            set { if(value < 0) throw new Exception("SantaClaus: Некорректное значение количества подарков, которые способен перенести актер!");
                _presents = value; }
        } // Presents
    } // SantaClaus
}
