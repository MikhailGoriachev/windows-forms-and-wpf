﻿using Homework.Helpers;
using Homework.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Publications.Views
{
    /// <summary>
    /// Логика взаимодействия для PublicationWindow.xaml
    /// </summary>
    public partial class PublicationWindow : Window
    {
        Subscriber _subscriber;
        public Subscriber Subscriber {
            get => _subscriber;
            set {
                _subscriber = value;
                TbxFullName.Text         = _subscriber.FullName;
                TbxStreet.Text           = _subscriber.Street;
                TbxBuilding.Text         = _subscriber.Building;
                TbxFlat.Text             = $"{_subscriber.Flat}";
                TbxTitle.Text            = _subscriber.Title;
                TbxPubType.Text          = _subscriber.PubType;
                DpDateStart.SelectedDate = _subscriber.DateStart;
                CmbDuration.Text         = $"{_subscriber.Duration}";        
            } // set
        }
        public PublicationWindow() : this("Добавление подписки", "Добавить") { }
        public PublicationWindow(string header, string button) {
            InitializeComponent();
            Title = header;
            BtnOK.Content = button;

            CmbDuration.ItemsSource = new string[]{ "1", "3", "6", "12"};
            CmbDuration.SelectedIndex = 0;

            _subscriber = new Subscriber();
            _subscriber.PubIndex = Utils.GetRandom(10000, 99999);
        } // PublicationWindow

        #region Изменение цвета надписи на кнопке при перемещении курсора мыши на кнопку
        private void Button_MouseEnter(object sender, MouseEventArgs e)
        {
            Button btn = e.OriginalSource as Button;
            btn.Foreground = new SolidColorBrush(Color.FromArgb(255, 0, 0, 0));
        } // Button_MouseEnter

        private void Button_MouseLeave(object sender, MouseEventArgs e)
        {
            Button btn = e.OriginalSource as Button;
            btn.Foreground = new SolidColorBrush(Colors.White);
        } // Button_MouseLeave
        #endregion

        // Обработка клика по кнопке ОК - скрываем окно
        private void Add_Click(object sender, RoutedEventArgs e) {
            try {
                // Получить данные от элементов управления
                _subscriber.FullName  = TbxFullName.Text;
                _subscriber.Street    = TbxStreet.Text;
                _subscriber.Building  = TbxBuilding.Text;
                _subscriber.Flat      = int.Parse(TbxFlat.Text);
                _subscriber.Title     = TbxTitle.Text;
                _subscriber.PubType   = TbxPubType.Text;
                _subscriber.DateStart = DpDateStart.SelectedDate.Value.Date;
                _subscriber.Duration  =  int.Parse(CmbDuration.Text);
                DialogResult = true;
                Close();
            }
            catch (Exception ex) {
                MessageBox.Show(ex.Message, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            } // try-catch
        } // Ok_Click
    }
}
