﻿using Homework.Helpers;
using System;


namespace Homework.Models
{
    // модель подписчика 
    public class Subscriber {

        // Фамилия И.О.
        private string _fullName;
        public string FullName { 
            get => _fullName;
            set { if (String.IsNullOrWhiteSpace(value)) throw new Exception("Subscriber: Некорректное значение имени подписчика!");
                _fullName = value; } 
        } // FullName

        // улица
        private string _street;
        public string Street { 
            get => _street;
            set { if (String.IsNullOrWhiteSpace(value)) throw new Exception("Subscriber: Некорректное значение улицы!");
                _street = value; }
        } // Street

        // дом
        private string _building;
        public string Building { 
            get => _building;
            set { if (String.IsNullOrWhiteSpace(value)) throw new Exception("Subscriber: Некорректное значение дома!");
                _building = value; }
        } // Building

        // квартира
        private int _flat;
        public int Flat  {
            get => _flat;
            set {
                if (value <= 0) throw new Exception("Subscriber: Некорректное значение квартиры!");
                _flat = value; }
        } // Flat

        // Адрес подписчика
        public string Address { get => $"{_street}, д. {_building}, кв. {_flat}"; }

        // вид издания
        private string _pubType;
        public string PubType {
            get => _pubType;
            set { if (String.IsNullOrWhiteSpace(value)) throw new Exception("Subscriber: Некорректное значение вида издания!");
                _pubType = value; }
        } // PubType

        // индекс издания
        private int _pubIndex;
        public int PubIndex {
            get => _pubIndex;
            set {
                if (value <= 0) throw new Exception("Subscriber: Некорректное значение индекса издания!");
                _pubIndex = value; }
        } // PubIndex

        // наименование (название) издания
        private string _title;
        public string Title {
            get => _title;
            set { if (String.IsNullOrWhiteSpace(value)) throw new Exception("Subscriber: Некорректное значение наименования издания!");
                _title = value; }
        } // Title

        // дата начала подписки
        private DateTime _dateStart;
        public DateTime DateStart { 
            get => _dateStart; 
            set => _dateStart = value; 
        } // DateStart

        // период подписки
        private int _duration;
        public int Duration { 
            get=>_duration;
            set {
                if (value != 1 && value != 3 && value != 6 && value != 12) throw new Exception("Subscriber: Некорректное значение индекса издания!");
                _duration = value;
            }
        } // Duration

        // фабричный метод для создания подписчика
        public static Subscriber Generate()  {
            // индексы из массивов данных для создания телевизора
            int indexFullName = Utils.GetRandom(0, Utils.FullNames.Length - 1);
            int indexStreet = Utils.GetRandom(0, Utils.Streets.Length - 1);
            int indexPublication = Utils.GetRandom(0, Utils.Publications.Length - 1);
            int duration = Utils.GetRandom(0, 3);

            // создание объекта из массивов шаблонных данных, валидация при создании не нужна
            return new Subscriber {
                FullName = Utils.FullNames[indexFullName],
                Building = $"{Utils.GetRandom(1, 200)}",
                DateStart = new DateTime(Utils.GetRandom(2020, 2022), Utils.GetRandom(1, 12), Utils.GetRandom(1, 28)),
                Flat = Utils.GetRandom(1, 500),
                Street = Utils.Streets[indexStreet],
                PubIndex = Utils.GetRandom(10000, 99999),
                Title = Utils.Publications[indexPublication].Name,
                PubType = Utils.Publications[indexPublication].pubType,
                Duration = duration == 0 ? 1 : duration == 1 ? 3 : duration == 2 ? 6 : duration == 3 ? 12 :0,
            };
        } // Television
    } // Subscriber
}
