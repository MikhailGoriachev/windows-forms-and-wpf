﻿using System.Collections.Generic;
using System.Windows;
using DataGridMenu.Models;

namespace DataGridMenu.Views
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow() {
            InitializeComponent();

            DgvActresses.ItemsSource = new List<Actress>(new[] {
                new Actress {Surname="Миронова",   Name="Ольга",   Patronymic="Семеновна",    Color="синий",   NumberOfPoems=13, NumberOfGames = 5},
                new Actress {Surname="Котова",     Name="Мария",   Patronymic="Олеговна",     Color="зеленый", NumberOfPoems=11, NumberOfGames = 8},
                new Actress {Surname="Аникеева",   Name="Арина",   Patronymic="Петровна",     Color="белый",   NumberOfPoems=11, NumberOfGames = 8},
                new Actress {Surname="Штурлак",    Name="Дарья",   Patronymic="Олеговна",     Color="белый",   NumberOfPoems=13, NumberOfGames = 9},
                new Actress {Surname="Михайленко", Name="Людмила", Patronymic="Игоревна",     Color="синий",   NumberOfPoems=13, NumberOfGames = 9},
                new Actress {Surname="Каплун",     Name="Оксана",  Patronymic="Алексеевна",   Color="синий",   NumberOfPoems=14, NumberOfGames = 7},
                new Actress {Surname="Коротаева",  Name="Лариса",  Patronymic="Юрьевна",      Color="белый",   NumberOfPoems=14, NumberOfGames = 7},
                new Actress {Surname="Грамакова",  Name="Мария",   Patronymic="Леонидовна",   Color="зеленый", NumberOfPoems=18, NumberOfGames = 4},
                new Actress {Surname="Бакина",     Name="Дарья",   Patronymic="Денисовна",    Color="зеленый", NumberOfPoems=18, NumberOfGames = 9},
                new Actress {Surname="Новоселова", Name="Тамара",  Patronymic="Владимировна", Color="синий",   NumberOfPoems=12, NumberOfGames = 6},
                new Actress {Surname="Штакина",    Name="Арина",   Patronymic="Ивановна",     Color="белый",   NumberOfPoems=16, NumberOfGames = 5},
                new Actress {Surname="Курочкина",  Name="Лариса",  Patronymic="Павловна",     Color="синий",   NumberOfPoems=19, NumberOfGames = 8}
            });


            // установить цвет фона полей вывода в строке состояния таким же, как фон строки состояния 
            TxbStatus1.Background = TxbStatus2.Background = TxbStatus3.Background = TxbStatus4.Background = StbMain.Background;
            TxbStatus2.Text = $"{DgvActors.Items.Count}";
            TxbStatus4.Text = $"{DgvActresses.Items.Count}";
        } // MainWindow


        // открыть окно с данными ремонтной мастерской телевизоров
        private void Televisions_Click(object sender, RoutedEventArgs e) {
            RepairShopWindow repairShopWindow = new RepairShopWindow();
            repairShopWindow.ShowDialog();
        } // Televisions_Click


        // открыть окно со сведениями о приложении и разработчике
        private void About_Click(object sender, RoutedEventArgs e) {
            AboutWindow aboutWindow = new AboutWindow();
            aboutWindow.ShowDialog();
        } // About_Click

        // завершение работы приложения 
        private void Exit_Click(object sender, RoutedEventArgs e) => 
            Application.Current.Shutdown();
    } // class MainWindow
}
