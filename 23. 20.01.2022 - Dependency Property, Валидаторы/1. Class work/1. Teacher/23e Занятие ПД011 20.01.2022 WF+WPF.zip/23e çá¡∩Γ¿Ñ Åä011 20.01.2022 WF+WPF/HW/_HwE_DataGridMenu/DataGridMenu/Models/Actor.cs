﻿namespace DataGridMenu.Models
{
    // Представление данных актера, играющего роль Деда Мороза:
    // фамилия, имя, отчество, цвет полушубка, количество подарков,
    // которые способен перенести актер.
    public class Actor: Person
    {
        // количество подарков, которые способен перенести актер
        public int CurriedPresents { get; set; }
    } // class Actor
}
