﻿namespace DataGridMenu.Models
{
    // Базовый класс - персональные данные актеров:
    // фамилия, имя, отчество, цвет полушубка
    public class Person
    {
        // фамилия
        public string Surname { get; set; }

        // имя
        public string Name { get; set; }

        // отчество
        public string Patronymic { get; set; }
        
        // цвет полушубка
        public string Color { get; set; }

    } // class Person
}
