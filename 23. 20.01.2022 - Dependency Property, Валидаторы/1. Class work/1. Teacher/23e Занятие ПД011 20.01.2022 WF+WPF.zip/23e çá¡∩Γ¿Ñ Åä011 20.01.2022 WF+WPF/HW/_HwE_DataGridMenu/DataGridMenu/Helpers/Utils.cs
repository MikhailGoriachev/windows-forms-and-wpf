﻿using System;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace DataGridMenu.Helpers
{
    public class Utils
    {
        // представление для пустой строки результата
        public const string EmptyResult = "--- '' ---";
        public static string CalcDontNeed = "Расчет не задан";

        // формирование Uri из имени файла, файлы изображений в папке проекта
        // Images, действие при построении для каждого файла изображения - Resource
        // формат Uri для имени файла в ресурсах проекта
        // pack://application:,,,/Папка/файл.ext, так, для нашего проекта это будет
        // pack://application:,,,/Images/Cat0.jpg
        public static ImageSource BuildImageSource(string folderName, string fileName) {
            BitmapImage image = new BitmapImage();

            image.BeginInit();
            image.UriSource = new Uri($"pack://application:,,,/Images/{folderName}/{fileName}");
            image.EndInit();

            return image;
        } // BuildImageSource
		
		        // формирование случайных целых чисел в заданном диапазоне (lo, hi),
        // исключая указанное параметром exclude число
        public static int GetRandomExclude(int lo, int hi, int exclude) {
            int number = 0;
            do
                number = Random.Next(lo, hi);
            while (number == exclude);

            return number;
        } // GetRandomExclude

        // объект для получения случайных чисел
        public static readonly Random Random = new Random(Environment.TickCount);

        // Получение случайного числа
        // краткая форма записи метода - это не лямбда выражение
        public static int GetRandom(int lo, int hi) => Random.Next(lo, hi + 1);
        public static double GetRandom(double lo, double hi) => lo + (hi - lo) * Random.NextDouble();


        // бренды и модели телевизоров
        public static string[] Brands = new [] {
             "Samsung", "AIWA", "Panasonic", "Phillips", "BQ",
             "Sony", "Prestigio", "Xiaomi", "BBK", "DIGMA"
        };

        // номенклатура диагоналей экранов телевизоров
        public static double[] Diagonals = new[] {
            17, 21.5, 22, 23.5, 32, 33.5, 36, 40.5, 42, 43.5, 50, 52.5, 55, 56, 80.5
        };

        // фамилии и инициалы для формирования персональных данных
        public static string[] FullNames = new[] {
            "Петрова Д.А.", "Цыбенко Р.А.", "Юдина Н.А.", "Фортранова Б.В.", "Шавыркина П.А.",
            "Фаронова Р.В.", "Щупак Д.Ю.", "Златопольский Д.М.", "Абрамян М.Э.", "Васильев А.Н.",
            "Федорова В.О.", "Мурадов И.с.", "Штурлак А.В.", "Гамджашвили Ю.И.", "Баранова Е.В.",
            "Маслова Е.В", "Федорин М.Н."
        };

        // описания дефекта и стоимость ремонта дефекта 
        public static (string Desc, int Price)[] DefectDescriptions = new[] {
            ("нет звука", 150),            ("искажения цвета", 230),  ("полосы на изображении", 1800), 
            ("не принимает сигнал", 320),  ("не работает USB", 340),  ("не включается", 400),
            ("дымит и потрескивает", 600), ("экран отвалился", 2300), ("не управляется от пульта", 520), 
            ("не выключается", 230),       ("унылый контент", 3400)
        };
    }
}
