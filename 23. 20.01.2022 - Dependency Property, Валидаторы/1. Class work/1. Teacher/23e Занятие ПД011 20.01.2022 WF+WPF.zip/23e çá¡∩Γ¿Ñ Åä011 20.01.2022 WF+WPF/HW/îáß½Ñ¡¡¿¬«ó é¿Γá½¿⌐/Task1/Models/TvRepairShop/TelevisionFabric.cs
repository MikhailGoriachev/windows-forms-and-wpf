﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Homework.Helpers;

namespace Homework.Models.TvRepairShop
{
	// Класс-фабрика объектов телевизоров, находящихся в ремонте
	public static class TelevisionFabric
	{
		// Генерация коллекциии телевизоров указанного количества
		public static ObservableCollection<Television> GenerateCollection(int n = 15)
		{
			ObservableCollection<Television> televisions = new ObservableCollection<Television>();
			for (int i = 0; i < n; i++)
			{
				Television tv;
				do tv = Generate();
				while (televisions.Any(x => x.Owner == tv.Owner));
				televisions.Add(tv);
			}
			
			return televisions;
		}

		public static Television Generate()
		{
			// индексы из массивов данных для создания телевизора
			int indexBrand = Utils.GetRandom(0, Brands.Length - 1);
			int indexType = Utils.GetRandom(0, Types.Length - 1);
			int indexDiagonal = Utils.GetRandom(0, Diagonals.Length - 1);
			int indexRepairer = Utils.GetRandom(0, Repairers.Length - 1);
			int indexOwner = Utils.GetRandom(0, Utils.FullNames.Length - 1);
			int indexDefect = Utils.GetRandom(0, DefectDescriptions.Length - 1);

			// создание объекта из массивов шаблонных данных, валидация при создании не нужна
			return new Television
			{
				BrandType = Brands[indexBrand] + " " + Types[indexType],
				Diagonal = Diagonals[indexDiagonal],
				Defect = DefectDescriptions[indexDefect].Desc,
				Repairer = Repairers[indexRepairer],
				Owner = Utils.FullNames[indexOwner],
				Price = DefectDescriptions[indexDefect].Price
			};
		}


		// бренды телевизоров
		public static readonly string[] Brands = {
			"Samsung", "AIWA", "Panasonic", "Phillips", "BQ",
			"Sony", "Prestigio", "Xiaomi", "BBK", "DIGMA", "LG"
		};

		// типы телевизоров
		public static readonly string[] Types =
		{
			"LED", "OLED", "LCD", "PDP"
		};


		// номенклатура диагоналей экранов телевизоров
		public static readonly int[] Diagonals = {
			20, 22, 24, 27, 32, 37, 42, 46, 48, 50, 55, 60, 64, 70, 80, 84, 99, 102, 108, 111, 152
		};

		// описания дефекта и стоимость ремонта дефекта 
		public static readonly (string Desc, int Price)[] DefectDescriptions = {
			("нет звука", 150),            ("искажения цвета", 230),  ("полосы на изображении", 1800),
			("не принимает сигнал", 320),  ("не работает USB", 340),  ("не включается", 400),
			("дымит и потрескивает", 600), ("экран отвалился", 700), ("не управляется от пульта", 520),
			("не выключается", 230),       ("битые пиксели", 1700),   ("неисправность матрицы", 5600),
			("вертикальные полосы", 1100)
		};

		// фамилии и инициалы мастеров
		public static readonly string[] Repairers = {
			"Казаков Д.В.",
			"Михайлов Ю.Т.",
			"Кудрявцев А.А.",
			"Михайлов Ю.Т.",
			"Кудрявцев А.А.",
			"Казаков Д.В."
		};


	}
}
