﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Homework.Models.TvRepairShop
{
	/*
	 * класс Television (производитель и тип телевизора, диагональ экрана,
	 * строка с описанием дефекта, фамилия и инициалами мастера, фамилия и
	 * инициалы владельца, стоимость ремонта
	 */
	public class Television
	{
		//производитель и тип телевизора
		private string _brandType;
		public string BrandType
		{
			get => _brandType; 
			set
			{
				if (string.IsNullOrEmpty(value))
					throw new ArgumentNullException($"Пустая строка в названии телевизора");
				_brandType = value;
			}
		}

		//диагональ экрана
		private int _diagonal;
		public int Diagonal
		{
			get => _diagonal;
			set
			{
				if (value <= 0)
					throw new ArgumentOutOfRangeException($"Недопустимая диагональ телевизора: {value}");
				_diagonal = value;
			}
		}

		//строка с описанием дефекта
		private string _defect;
		public string Defect
		{
			get => _defect;
			set
			{
				if (string.IsNullOrEmpty(value))
					throw new ArgumentNullException($"Пустая строка в описании деффекта телевизора");
				_defect = value;
			}
		}

		//фамилия и инициалы мастера
		private string _repairer;

		public string Repairer
		{
			get => _repairer;
			set
			{
				if (string.IsNullOrEmpty(value))
					throw new ArgumentNullException("Пустая строка фамилии и инициалов мастера");
				_repairer = value;
			}
		}

		//фамилия и инициалы владельца
		private string _owner;

		public string Owner
		{
			get =>  _owner;
			set
			{
				if (string.IsNullOrEmpty(value))
					throw new ArgumentNullException("Пустая строка фамилии и инициалов владельца телевизора");
				_owner = value;
			}
		}

		//стоимость ремонта
		private int _price;

		public int Price
		{
			get => _price;
			set
			{
				if (value < 0)
					throw new ArgumentOutOfRangeException($"Недопустимая стоимость ремонта телевизора: {value}");
				_price = value;
			}
		}

		// ансамбль конструкторов

		public Television() 
			: this("н/д", 1, "н/д", "н/д", "н/д", 1)
		{}


		public Television(string brandType, int diagonal, string defect, string repairer, string owner, int price)
		{
			BrandType = brandType;
			Diagonal = diagonal;
			Defect = defect;
			Repairer = repairer;
			Owner = owner;
			Price = price;
		}


		// строковое представление объекта
		public override string ToString() =>
			$"Телевизор: {_brandType}, деффект:{_defect}, владелец: {_owner}";

		// формирование строки таблицы, свойство
		public string TableRow =>
			$"│ {_brandType,-19} │ {_diagonal,10} │ {_defect,-31} │ {_repairer,-14} │ {_owner,-14} │ {_price, 9} │";


		// Шапка таблицы, статическое свойство
		public static string Header =>
			$"┌─────────────────────┬────────────┬─────────────────────────────────┬────────────────┬────────────────┬───────────┐\r\n" +
			$"│ Производитель и тип │  Диагональ │         Описание деффекта       │  Фамилия И.О.  │  Фамилия И.О.  │ Стоимость │\r\n" +
			$"│      телевизора     │ телевизора │                                 │    мастера     │   владельца    │  ремонта  │\r\n" +
			$"├─────────────────────┼────────────┼─────────────────────────────────┼────────────────┼────────────────┼───────────┤\r\n";

		// Подвал таблицы, статическое свойство
		public static string Footer =>
			 "└─────────────────────┴────────────┴─────────────────────────────────┴────────────────┴────────────────┴───────────┘";


	}
}
