﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Homework.Controllers;

namespace Homework.Views
{
	/// <summary>
	/// Логика взаимодействия для MainWindow.xaml
	/// </summary>
	public partial class MainWindow : Window
	{
		private RepairShopController _repairShopController;

		public MainWindow():this(new RepairShopController())
		{
		}

		public MainWindow(RepairShopController repairShopController)
		{
			InitializeComponent();
			_repairShopController = repairShopController;
		}

		// Завершить работу приложения
		private void Exit_Click(object sender, RoutedEventArgs e) => Close();

		private void About_Click(object sender, RoutedEventArgs e) => new AboutWindow().ShowDialog();

		#region Изменение цвета надписи на кнопке при перемещении курсора мыши на кнопку

		private void Button_MouseEnter(object sender, MouseEventArgs e)
		{
			Button btn = e.OriginalSource as Button; 
			btn.Foreground = new SolidColorBrush(Color.FromArgb(255, 13, 82, 120));
			//btn.Background = new SolidColorBrush(Color.FromArgb(128, 23, 43, 33));
			btn.Height += 5;
			btn.Width += 5;
		}

		private void Button_MouseLeave(object sender, MouseEventArgs e)
		{
			Button btn = e.OriginalSource as Button;
			btn.Foreground = new SolidColorBrush(Colors.White);
			//btn.Background = new SolidColorBrush(Colors.CornflowerBlue);
			btn.Height -= 5;
			btn.Width -= 5;
		}

		#endregion

		private void AnimatorsLists_Click(object sender, RoutedEventArgs e) =>
			new AnimatorsListsWindow().ShowDialog();

		private void RepairShop_Click(object sender, RoutedEventArgs e)
		{
			//new RepairShopWindow(_repairShopController).ShowDialog();
		}

	}
}
