﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Homework.Controllers;
using Homework.Helpers;
using Homework.Models.TvRepairShop;

namespace Homework.Views
{
	/// <summary>
	/// Логика взаимодействия для RepairShopWindow.xaml
	/// </summary>
	
	public partial class RepairShopWindow : Window
	{
		private RepairShopController _repairShopController;

		private static readonly int MinElementsToGenerate = 12;
		private static readonly int MaxElementsToGenerate = 20;


		public RepairShopWindow()
		{
			InitializeComponent();

			_repairShopController = new RepairShopController();

			// установка текстовой информации элементов окна
			Title = _repairShopController.RepairShop.Title;
			LblShopName.Content = _repairShopController.RepairShop.Title;
			LblShopAddress.Content = "Адрес: " + _repairShopController.RepairShop.Address;

			// привязка данных DataGrid
			DgTelevisions.ItemsSource = _repairShopController.RepairShop.Televisions;
			DgTelevisionsOrdered.ItemsSource = RepairShopController.OrderByBrand(_repairShopController.TelevisionsCopy());

			CbxSelectRepairInit();
			CbxSelectDiagonalInit();
		}

		private void MniExit_Command(object sender, RoutedEventArgs e) => Close();
		private void MniAbout_Command(object sender, RoutedEventArgs e) => new AboutWindow().ShowDialog();

		// Инициализация ComboBox выбора мастера для условия выборки
		private void CbxSelectRepairInit() =>
			CbxRepairers.ItemsSource = _repairShopController.RepairShop.GetRepairers;

		// Инициализация ComboBox выбора диагонали для условия выборки
		private void CbxSelectDiagonalInit() =>
			CbxDiagonals.ItemsSource = _repairShopController.RepairShop.GetDiagonals;

		#region CRUD
		// Перегенерация коллекции с заполнеием основного DataGrid
		private void Generate_Command(object sender, RoutedEventArgs e)
		{
			// Перегенерация коллекции 
			_repairShopController.RepairShop.Initialize(Utils.GetRandom(MinElementsToGenerate, MaxElementsToGenerate));
			
			// Привязка
			DgTelevisions.ItemsSource = _repairShopController.RepairShop.Televisions;
			
			// Переинициализация Combobox'ов 
			CbxSelectRepairInit();
			CbxSelectDiagonalInit();
			
			// Переход на главную вкладку TabControl
			TbcTelevisions.SelectedItem = TabItemHome;
			DgTelevisionsOrdered.Items.Clear();
		}

		// Добавление данных о телевизоре в ремонте
		private void Add_Command(object sender, RoutedEventArgs e)
		{
			TvWindow tvWindow = new TvWindow();

			if (tvWindow.ShowDialog() == false) return;

			// получить данные из свойства формы
			_repairShopController.RepairShop.AddTelevision(tvWindow.Tv);
			
			TbcTelevisions.SelectedItem = TabItemHome;

			// Переинициализация Combobox'ов
			CbxSelectRepairInit();
			CbxSelectDiagonalInit();

			// установка выделения в DataGrid
			DgTelevisionsSetSelecting(DgTelevisions.Items.Count - 1);
		}

		// Редактирования данных о выбранном телевизоре
		private void Edit_Command(object sender, RoutedEventArgs e)
		{
			if (DgTelevisions.SelectedIndex == -1) return;

			// индекс выбранного элемента
			int selected = DgTelevisions.SelectedIndex;

			// передача данных в форму
			TvWindow tvWindow = new TvWindow("Редактировать данные о телевизоре", "Сохранить")
			{
				Tv = _repairShopController.RepairShop[selected]
			};

			if (tvWindow.ShowDialog() == false) return;

			// получить данные
			_repairShopController.RepairShop[selected] = tvWindow.Tv;

			// Переинициализация Combobox'ов
			CbxSelectRepairInit();
			CbxSelectDiagonalInit();

			DgTelevisionsSetSelecting(selected);
		}

		// Удаление данных о телевизоре в ремонте
		private void Delete_Command(object sender, RoutedEventArgs e)
		{
			if (DgTelevisions.SelectedIndex == -1) return;

			// индекс выбранного элемента
			int selected = DgTelevisions.SelectedIndex;

			// удаление записи данных 
			_repairShopController.RepairShop.RemoveAt(selected);

			// Переинициализация Combobox'ов
			CbxSelectRepairInit();
			CbxSelectDiagonalInit();

			// Возврат выделения элемента на место удаленного, если это возможно
			if (!_repairShopController.RepairShop.IsEmpty)
				DgTelevisionsSetSelecting(selected < _repairShopController.RepairShop.Count
					? selected
					: _repairShopController.RepairShop.Count - 1);
		}
		#endregion
		
		#region Сортировки

		// сортировка по производителю и бренду
		private void OrderByBrand_Command(object sender, RoutedEventArgs e)
		{
			TbcTelevisions.SelectedItem = TabItemOrdered;
			DgTelevisionsOrdered.ItemsSource = RepairShopController.OrderByBrand(_repairShopController.TelevisionsCopy());
		}

		// сортировка по убыванию диагонали
		private void OrderByDiagonalDesc_Command(object sender, RoutedEventArgs e)
		{
			TbcTelevisions.SelectedItem = TabItemOrdered;
			DgTelevisionsOrdered.ItemsSource = RepairShopController.OrderByDiagonalDesc(_repairShopController.TelevisionsCopy());
		}

		// осртировка по мастеру, выполняющему ремонт
		private void OrderByRepairer_Command(object sender, RoutedEventArgs e)
		{
			TbcTelevisions.SelectedItem = TabItemOrdered;
			DgTelevisionsOrdered.ItemsSource = RepairShopController.OrderByRepairer(_repairShopController.TelevisionsCopy());
		}

		// сортировка по владельцу телевизора
		private void OrderByOwner_Command(object sender, RoutedEventArgs e)
		{
			TbcTelevisions.SelectedItem = TabItemOrdered;
			DgTelevisionsOrdered.ItemsSource = RepairShopController.OrderByOwner(_repairShopController.TelevisionsCopy());
		}

		#endregion

		#region Выборка

		// выборка по минимальной цене
		private void SelectMinPrice_Command(object sender, RoutedEventArgs e)
		{
			TbcTelevisions.SelectedItem = TabItemSelected;
			DgTelevisionsSelected.ItemsSource = null;
			DgTelevisionsSelected.ItemsSource = _repairShopController.SelectWhereMinPrice();
		}
		// выборка по мастеру, выполняющему ремонт
		private void SelectWhereRepairer_Command(object sender, RoutedEventArgs e)
		{
			// Создание формы выбора мастера
			SelectingWindow choiceForm = new SelectingWindow(_repairShopController.RepairShop.GetRepairers,
				"Выбор мастера", "Выберите мастера:");

			if (choiceForm.ShowDialog() == false) return;

			DgTelevisionsSelected.ItemsSource = _repairShopController.SelectWhereRepairer(choiceForm.Choosen);
			TbcTelevisions.SelectedItem = TabItemSelected;

			CbxRepairers.SelectedItem = choiceForm.Choosen;
		}

		// Выборка по владельцу
		private void SelectWhereDiagonal_Command(object sender, RoutedEventArgs e)
		{
			// Создание формы выбора владельца
			SelectingWindow choiceForm = new SelectingWindow(_repairShopController.RepairShop.GetDiagonals,
				"Выбор диагонали", "Выберите диагональ:");

			if (choiceForm.ShowDialog() == false) return;

			DgTelevisionsSelected.ItemsSource = _repairShopController.SelectWhereDiagonal(Convert.ToInt32(choiceForm.Choosen));
			TbcTelevisions.SelectedItem = TabItemOrdered;

			CbxDiagonals.SelectedItem = choiceForm.Choosen;
		}

		#endregion

		// Обработка смены выделения главной таблицы данных о телевизорах
		private void DgTelevisions_SelectionChanged(object sender, SelectionChangedEventArgs e) =>
			EditionControlsAccess(DgTelevisions.SelectedIndex != -1);

		// Обработка двойного щелчка мыши по таблице данных о телевизорах
		private void DgTelevisions_MouseDoubleClick(object sender, MouseButtonEventArgs e) =>
			Edit_Command(sender, e);

		// Установка выделения элемента DataGrid, прокрутка до элемента, установка фокуса
		private void DgTelevisionsSetSelecting(int position)
		{
			DgTelevisions.SelectedIndex = position;
			DgTelevisions.ScrollIntoView(DgTelevisions.SelectedItem);
			DgTelevisions.Focus();
		}
		
		

		// Выборка при смене в списке ComboBox мастеров
		private void CbxRepairers_OnSelectionChanged(object sender, SelectionChangedEventArgs e)
		{
			if (CbxRepairers.SelectedIndex == -1) return;
			TbcTelevisions.SelectedItem = TabItemSelected;
			DgTelevisionsSelected.ItemsSource = _repairShopController.SelectWhereRepairer(CbxRepairers.SelectedValue.ToString());
		}

		// Выборка при смене в списке ComboBox диагонали
		private void CbxDiagonals_OnSelectionChanged(object sender, SelectionChangedEventArgs e)
		{
			if (CbxDiagonals.SelectedIndex == -1) return;
			TbcTelevisions.SelectedItem = TabItemSelected;
			DgTelevisionsSelected.ItemsSource = _repairShopController.SelectWhereDiagonal(Convert.ToInt32(CbxDiagonals.SelectedValue));
		}

		// Действия при смене вкладки
		private void TabChanged(object sender, SelectionChangedEventArgs e) => 
			EditionControlsAccess(Equals(TbcTelevisions.SelectedItem, TabItemHome));

		// Управление состоянием активности элементов управления, измененяющих/удаляющих данные
		private void EditionControlsAccess(bool state)
		{
			MniEdit.IsEnabled = BtnEdit.IsEnabled = MniRemove.IsEnabled = BtnRemove.IsEnabled = state;
			ImgEdit.Source = state ? Utils.GetImageFromSource("../Images/edit.png") : Utils.GetImageFromSource("../Images/edit_gray.png");
			ImgRemove.Source = state ? Utils.GetImageFromSource("../Images/remove.png") : Utils.GetImageFromSource("../Images/remove_gray.png");
		}
	}
}
