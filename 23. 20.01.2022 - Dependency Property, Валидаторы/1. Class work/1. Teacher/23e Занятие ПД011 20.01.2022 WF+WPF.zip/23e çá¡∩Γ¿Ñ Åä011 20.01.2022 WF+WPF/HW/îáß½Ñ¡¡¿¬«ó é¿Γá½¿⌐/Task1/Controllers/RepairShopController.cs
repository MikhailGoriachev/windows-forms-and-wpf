﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Homework.Models.TvRepairShop;


namespace Homework.Controllers
{
	public class RepairShopController
	{
		// объект для обработки
		private RepairShop _repairShop;

		public RepairShop RepairShop => _repairShop;

		// конструкторы
		public RepairShopController() : this(new RepairShop())
		{
			_repairShop.Initialize();
		}

		public RepairShopController(RepairShop repairShop)
		{
			_repairShop = repairShop;
		}

		// получить список мастеров
		public List<string> GetRepairers => _repairShop.GetRepairers;

		// получить список диагоналей
		public List<string> GetDiagonal => _repairShop.GetDiagonals;

		// получить копию данных о телевизорах
		public ObservableCollection<Television> TelevisionsCopy() =>
			new ObservableCollection<Television>(_repairShop.Televisions);

		#region Сортировки

		// Запрос на упорядочивание коллекции по производителю и типу
		public void OrderByBrand() => RepairShop.OrderBy(t=> t.BrandType);

		public static ObservableCollection<Television> OrderByBrand(ObservableCollection<Television> list) =>
			RepairShop.OrderBy(list,t => t.BrandType);


		// Запрос на упорядочивание коллекции по убыванию диагонали экрана
		public void OrderByDiagonalDesc() => RepairShop.OrderByDescending(t => t.Diagonal);

		public static ObservableCollection<Television> OrderByDiagonalDesc(ObservableCollection<Television> list) =>
			RepairShop.OrderByDescending(list, t => t.Diagonal);

		// Запрос на упорядочивание коллекции по мастеру, выполняющему ремонт
		public void OrderByRepairer() => RepairShop.OrderBy(t => t.Repairer);

		public static ObservableCollection<Television> OrderByRepairer(ObservableCollection<Television> list) =>
			RepairShop.OrderBy(list, t => t.Repairer);

		// Запрос на упорядочивание коллекции по владельцу телевизора
		public void OrderByOwner() => RepairShop.OrderBy(t => t.Owner);

		public static ObservableCollection<Television> OrderByOwner(ObservableCollection<Television> list) =>
			RepairShop.OrderBy(list, t => t.Owner);

		// Запрос на упорядочивание коллекции по стоимости
		public void OrderByPrice() => RepairShop.OrderBy(t => t.Price);

		public static ObservableCollection<Television> OrderByPrice(ObservableCollection<Television> list) =>
			RepairShop.OrderBy(list, t => t.Price);

		#endregion


		#region Выборки

		// Запрос на выборку в коллекцию телевизоров с минимальной стоимостью ремонта
		public ObservableCollection<Television> SelectWhereMinPrice() =>
			_repairShop.Filter(t => t.Price == _repairShop.MinPrice);

		// Запрос на выборку в коллекцию телевизоров, ремонтируемых заданным мастером
		public ObservableCollection<Television> SelectWhereRepairer(string repairer) =>
			_repairShop.Filter(t => t.Repairer == repairer);

		// Запрос на выборку в коллекцию телевизоров с заданной диагональю экран
		public ObservableCollection<Television> SelectWhereDiagonal(int diagonal) =>
			_repairShop.Filter(t => t.Diagonal == diagonal);

		// Запрос на выборку в коллекцию телевизоров с заданной диагональю экран
		public ObservableCollection<Television> SelectWhereOwner(string owner) =>
			_repairShop.Filter(t => t.Owner == owner);

		#endregion
	}
}
