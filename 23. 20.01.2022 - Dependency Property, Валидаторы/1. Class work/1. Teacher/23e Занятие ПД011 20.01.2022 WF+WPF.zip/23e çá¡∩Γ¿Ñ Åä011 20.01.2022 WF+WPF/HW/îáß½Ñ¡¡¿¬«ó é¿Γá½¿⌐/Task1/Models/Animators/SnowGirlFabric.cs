﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Homework.Helpers;

namespace Homework.Models.Animators
{
	public static class SnowGirlFabric
	{
		public static List<SnowGirl> GenerateCollection(int amount)
		{
			List<SnowGirl> snowGirls = new List<SnowGirl>();

			for (int i = 0; i < amount; i++)
				snowGirls.Add(Generate());

			return snowGirls;
		}

		public static SnowGirl Generate() => new SnowGirl
			{
				Surname = Surnames[Utils.GetRandom(0, Surnames.Length - 1)],
				Name = Names[Utils.GetRandom(0, Names.Length - 1)],
				Patronymic = Patronymics[Utils.GetRandom(0, Patronymics.Length - 1)],
				FurcoatColor = FurcoatColors[Utils.GetRandom(0, FurcoatColors.Length - 1)],
				Poems = Utils.GetRandom(1, 20),
				Games = Utils.GetRandom(1, 10)
			};

		public static readonly string[] Surnames =
		{
			"Макарова", "Субботина", "Горшкова", "Минаева", "Виноградова", "Вешнякова", "Маркова", "Кочетова", "Чернова",
			"Демина", "Орлова", "Блинова", "Фролова", "Пастухова", "Петрова", "Смирнова", "Кузьмина", "Белова", "Крылова",
			"Николаева", "Григорьева", "Корнеева", "Чернышева", "Головина", "Моисеева", "Цветкова", "Фокина", "Морозова",
			"Максимова", "Егорова"
		};
		public static readonly string[] Names =
		{
			"Кира", "Дарья", "Александра", "Таисия", "Анастасия", "София", "Анна", "Анастасия", "Мирослава", "Кира", "Ксения",
			"Александра", "Варвара", "Алиса", "Полина", "Арина", "Полина", "Ясмина", "Анастасия", "Вероника", "Ольга", "Дарья",
			"Алиса", "Алёна", "Мария", "София", "Варвара", "Зоя", "Агата", "Алиса"
		};
		public static readonly string[] Patronymics =
		{
			"Алексеевна", "Тимуровна", "Григорьевна", "Борисовна", "Петровна", "Александровна", "Данииловна", "Алексеевна",
			"Григорьевна", "Львовна", "Кирилловна", "Захаровна", "Александровна", "Егоровна", "Матвеевна", "Платоновна",
			"Даниловна", "Игоревна", "Григорьевна", "Львовна", "Марковна", "Андреевна", "Дмитриевна", "Александровна",
			"Егоровна", "Львовна", "Демьяновна", "Артёмовна", "Тимуровна", "Фёдоровна"
		};

		public static readonly string[] FurcoatColors =
		{
			"Красный", "Синий", "Белый", "Голубой"
		};
	}
}
