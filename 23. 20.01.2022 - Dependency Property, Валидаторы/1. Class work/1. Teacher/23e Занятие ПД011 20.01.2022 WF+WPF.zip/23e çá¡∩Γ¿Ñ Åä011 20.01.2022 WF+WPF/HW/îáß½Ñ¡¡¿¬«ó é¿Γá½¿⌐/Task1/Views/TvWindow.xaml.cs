﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Homework.Models.TvRepairShop;

namespace Homework.Views
{
	/// <summary>
	/// Логика взаимодействия для TvWindow.xaml
	/// </summary>
	public partial class TvWindow : Window
	{
		private Television _tv;

		public Television Tv
		{
			get => _tv;
			set
			{
				_tv = value;

				TxbBrandType.Text = _tv.BrandType;
				TxbDefect.Text = _tv.Defect;
				TxbRepairer.Text = _tv.Repairer;
				TxbOwner.Text = _tv.Owner;
				TxbDiag.Text = _tv.Diagonal.ToString();
				TxbPrice.Text = _tv.Price.ToString();
			}
		}

		public TvWindow()
		{
			InitializeComponent();
			_tv = new Television();
		}

		public TvWindow(string windowTitle, string btnTitle)
		{
			InitializeComponent();
			_tv = new Television();

			// Заголовок формы
			Title = windowTitle;
			BtnOk.Content = btnTitle;
		}

		// Обработка нажатия кнопки подтверждения
		private void BtnOk_Click(object sender, RoutedEventArgs e)
		{
			if (!Validate())
			{
				MessageBox.Show("Не все данные заполнены корректно", 
					"Ошибка",
					MessageBoxButton.OK,
					MessageBoxImage.Exclamation);
				return;
			}

			_tv = new Television()
			{
				BrandType = TxbBrandType.Text,
				Defect = TxbDefect.Text,
				Diagonal = int.Parse(TxbDiag.Text),
				Owner = TxbOwner.Text,
				Price = int.Parse(TxbPrice.Text),
				Repairer = TxbRepairer.Text
			};

			DialogResult = true;
		}

		// Проверка валидации введенных данных
		public bool Validate() =>
			!string.IsNullOrWhiteSpace(TxbBrandType.Text) &&
			!string.IsNullOrWhiteSpace(TxbDefect.Text) &&
			!string.IsNullOrWhiteSpace(TxbOwner.Text) &&
			!string.IsNullOrWhiteSpace(TxbRepairer.Text) &&
			!string.IsNullOrWhiteSpace(TxbDiag.Text) &&
			!string.IsNullOrWhiteSpace(TxbPrice.Text) &&
			int.TryParse(TxbDiag.Text, out _) ||
			int.TryParse(TxbPrice.Text, out _);

		// Обработка туннельного события ввода текста в случае, если парсится в целочисленный тип данных
		private void Txb_PreviewTextInput(object sender, TextCompositionEventArgs e) =>
			e.Handled = !int.TryParse(e.Text, out _);
	}
}
