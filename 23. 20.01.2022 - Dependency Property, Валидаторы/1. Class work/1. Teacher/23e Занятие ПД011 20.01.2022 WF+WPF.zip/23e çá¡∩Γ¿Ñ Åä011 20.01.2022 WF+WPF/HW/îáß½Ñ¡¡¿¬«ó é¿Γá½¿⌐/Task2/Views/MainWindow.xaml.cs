﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Task2.Controllers;
using Task2.Helpers;

namespace Task2.Views
{
	/// <summary>
	/// Логика взаимодействия для MainWindow.xaml
	/// </summary>
	public partial class MainWindow : Window
	{
		private PostalServiceController _postalServiceController;

		public MainWindow() : this(new PostalServiceController()) {}

		public MainWindow(PostalServiceController postalServiceController)
		{
			InitializeComponent();
			
			_postalServiceController = postalServiceController;

			// привязка данных DataGrid
			DgSubscriptions.ItemsSource = _postalServiceController.PostalService.Subscribes;
			DgSubscriptionsOrdered.ItemsSource = _postalServiceController.OrderByAddress();

			CbxDurationsInit();
			CbxSurnamesInit();
			CbxTypesInit();
		}

		private void MniExit_Command(object sender, RoutedEventArgs e) => Close();

		private void MniAbout_Command(object sender, RoutedEventArgs e) => new AboutWindow().ShowDialog();

		public void CbxDurationsInit() =>
			CbxDurations.ItemsSource = _postalServiceController.GetDurationsList;

		public void CbxSurnamesInit() =>
			CbxSurnames.ItemsSource = _postalServiceController.GetSurnamesList;

		public void CbxTypesInit() =>
			CbxTypes.ItemsSource = _postalServiceController.GetPubTypesList;

		private void Add_Command(object sender, RoutedEventArgs e)
		{
			SubscribeWindow subscribeWindow = new SubscribeWindow();

			if (subscribeWindow.ShowDialog() == false) return;

			// получить данные из свойства формы

			_postalServiceController.PostalService.AddSubscribe(subscribeWindow.Subscribe);

			TbcSubscriptions.SelectedItem = TabItemHome;

			// Переинициализация Combobox'ов
			CbxDurationsInit();
			CbxSurnamesInit();
			CbxTypesInit();

			// установка выделения в DataGrid
			DgSubscriptionsSetSelecting(DgSubscriptions.Items.Count - 1);
		}

		private void Edit_Command(object sender, RoutedEventArgs e)
		{
			if (DgSubscriptions.SelectedIndex == -1) return;

			// индекс выбранного элемента
			int selected = DgSubscriptions.SelectedIndex;

			// передача данных в форму
			SubscribeWindow subscribeWindow = new SubscribeWindow("Редактировать данные о телевизоре", "Сохранить")
			{
				Subscribe = _postalServiceController.PostalService[selected]
			};

			if (subscribeWindow.ShowDialog() == false) return;

			// получить данные
			_postalServiceController.PostalService[selected] = subscribeWindow.Subscribe;

			// Переинициализация Combobox'ов
			CbxDurationsInit();
			CbxSurnamesInit();
			CbxTypesInit();

			DgSubscriptionsSetSelecting(selected);
		}

		private void Delete_Command(object sender, RoutedEventArgs e)
		{
			if (DgSubscriptions.SelectedIndex == -1) return;

			// индекс выбранного элемента
			int selected = DgSubscriptions.SelectedIndex;

			// удаление записи данных 
			_postalServiceController.PostalService.RemoveAt(selected);

			// Переинициализация Combobox'ов
			CbxDurationsInit();
			CbxSurnamesInit();
			CbxTypesInit();

			// Возврат выделения элемента на место удаленного, если это возможно
			if (!_postalServiceController.PostalService.IsEmpty)
				DgSubscriptionsSetSelecting(selected < _postalServiceController.PostalService.Count
					? selected
					: _postalServiceController.PostalService.Count - 1);
		}

		private void OrderByPubIndex_Command(object sender, RoutedEventArgs e)
		{
			TbcSubscriptions.SelectedItem = TabItemOrdered;
			DgSubscriptionsOrdered.ItemsSource = _postalServiceController.OrderByPubIndex();
		}

		private void OrderByAddress_Command(object sender, RoutedEventArgs e)
		{
			TbcSubscriptions.SelectedItem = TabItemOrdered;
			DgSubscriptionsOrdered.ItemsSource = _postalServiceController.OrderByAddress();
		}

		private void OrderByDurationDesc_Command(object sender, RoutedEventArgs e)
		{
			TbcSubscriptions.SelectedItem = TabItemOrdered;
			DgSubscriptionsOrdered.ItemsSource = _postalServiceController.OrderByDurationDescend();
		}

		private void SelectWherePubType_Command(object sender, RoutedEventArgs e)
		{
			// Создание формы выбора 
			ChoiceWindow choiceWindow = new ChoiceWindow(_postalServiceController.PostalService.GetPubTypesList,
				"Выбор типа издания", "Выберите тип издания:");

			if (choiceWindow.ShowDialog() == false) return;

			DgSubscriptionsSelected.ItemsSource = _postalServiceController.SelectWherePubType(choiceWindow.Choosen);
			TbcSubscriptions.SelectedItem = TabItemSelected;

			CbxTypes.SelectedItem = choiceWindow.Choosen;
		}

		private void SelectWhereDuration_Command(object sender, RoutedEventArgs e)
		{
			// Создание формы выбора 
			ChoiceWindow choiceWindow = new ChoiceWindow(_postalServiceController.PostalService.GetDurationsList,
				"Выбор длительность подписки", "Выберите длительность подписки:");

			if (choiceWindow.ShowDialog() == false) return;

			DgSubscriptionsSelected.ItemsSource = _postalServiceController.SelectWhereDuration(int.Parse(choiceWindow.Choosen));
			TbcSubscriptions.SelectedItem = TabItemSelected;

			CbxTypes.SelectedItem = choiceWindow.Choosen;
		}

		private void SelectWhereSurname_Command(object sender, RoutedEventArgs e)
		{
			// Создание формы выбора 
			ChoiceWindow choiceWindow = new ChoiceWindow(_postalServiceController.PostalService.GetSurnamesList,
				"Выбор фамилии и инициалов", "Выберите фамилию и инициалы:");

			if (choiceWindow.ShowDialog() == false) return;

			DgSubscriptionsSelected.ItemsSource = _postalServiceController.SelectWhereSurname(choiceWindow.Choosen);
			TbcSubscriptions.SelectedItem = TabItemSelected;

			CbxTypes.SelectedItem = choiceWindow.Choosen;
		}

		

		private void CbxTypes_OnSelectionChanged(object sender, SelectionChangedEventArgs e)
		{
			if (CbxTypes.SelectedIndex == -1) return;
			TbcSubscriptions.SelectedItem = TabItemSelected;
			DgSubscriptionsSelected.ItemsSource =
				_postalServiceController.SelectWherePubType(CbxTypes.SelectedValue.ToString());
		}

		private void CbxDurations_OnSelectionChanged(object sender, SelectionChangedEventArgs e)
		{
			if (CbxDurations.SelectedIndex == -1) return;
			TbcSubscriptions.SelectedItem = TabItemSelected;
			DgSubscriptionsSelected.ItemsSource =
				_postalServiceController.SelectWhereDuration(int.Parse(CbxDurations.SelectedValue.ToString()));
		}

		private void CbxSurnames_OnSelectionChanged(object sender, SelectionChangedEventArgs e)
		{
			if (CbxSurnames.SelectedIndex == -1) return;
			TbcSubscriptions.SelectedItem = TabItemSelected;
			DgSubscriptionsSelected.ItemsSource =
				_postalServiceController.SelectWhereSurname(CbxSurnames.SelectedValue.ToString());
		}

		private void TabChanged(object sender, SelectionChangedEventArgs e)
		{
			EditionControlsAccess(Equals(TbcSubscriptions.SelectedItem, TabItemHome));
		}

		private void DgSubscriptions_OnSelectionChanged(object sender, SelectionChangedEventArgs e)
		{
			EditionControlsAccess(DgSubscriptions.SelectedIndex != -1);
		}


		// Установка выделения элемента DataGrid, прокрутка до элемента, установка фокуса
		private void DgSubscriptionsSetSelecting(int position)
		{
			DgSubscriptions.SelectedIndex = position;
			DgSubscriptions.ScrollIntoView(DgSubscriptions.SelectedItem);
			DgSubscriptions.Focus();
		}


		// Управление состоянием активности элементов управления, измененяющих/удаляющих данные
		private void EditionControlsAccess(bool state)
		{
			MniEdit.IsEnabled = BtnEdit.IsEnabled = MniRemove.IsEnabled = BtnRemove.IsEnabled = state;
			ImgEdit.Source = state ? Utils.GetImageFromSource("../Images/edit.png") : Utils.GetImageFromSource("../Images/edit_gray.png");
			ImgRemove.Source = state ? Utils.GetImageFromSource("../Images/remove.png") : Utils.GetImageFromSource("../Images/remove_gray.png");
		}

	}
}
