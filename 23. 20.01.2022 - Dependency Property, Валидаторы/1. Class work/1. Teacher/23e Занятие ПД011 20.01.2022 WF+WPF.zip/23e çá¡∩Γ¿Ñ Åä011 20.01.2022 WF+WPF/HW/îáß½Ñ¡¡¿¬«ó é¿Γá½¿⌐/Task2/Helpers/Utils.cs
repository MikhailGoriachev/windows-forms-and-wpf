﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media.Imaging;
using Task2.Models;

namespace Task2.Helpers
{
	class Utils
	{
		public static ObservableCollection<Subscribe> MakeTestData() =>
			new ObservableCollection<Subscribe>()
			{
				new Subscribe
				{
					SurnameNP = "Петрова Д.А.", Street = "ул. Садовая", Building = "2", Apartment = 12,
					Title = "Мурзилка", PubType = "Журнал", PubIndex = "43246", StartDate = new DateTime(2021, 05, 12),
					Duration = 3
				},
				new Subscribe
				{
					SurnameNP = "Цыбенко Р.А.", Street = "ул. Зайцева", Building = "1", Apartment = 4,
					Title = "Здравушка. 100 лет без бед!", PubType = "Журнал", PubIndex = "81670",
					StartDate = new DateTime(2020, 01, 15), Duration = 1
				},
				new Subscribe
				{
					SurnameNP = "Юдина Н.А.", Street = "пр. Титова", Building = "12", Apartment = 35,
					Title = "Известия", PubType = "Газета", PubIndex = "13133", StartDate = new DateTime(2021, 02, 16),
					Duration = 6
				},
				new Subscribe
				{
					SurnameNP = "Фортранов Б.В.", Street = "ул. Челюскинцев", Building = "53", Apartment = 85,
					Title = "Земляные черви", PubType = "Книга", PubIndex = "12112",
					StartDate = new DateTime(2021, 05, 05), Duration = 3
				},
				new Subscribe
				{
					SurnameNP = "Шавыркина П.А.", Street = "пл. Конституции", Building = "86", Apartment = 12,
					Title = "Лабораторная диагностика инфекционных болезней", PubType = "Книга", PubIndex = "79127",
					StartDate = new DateTime(2021, 02, 01), Duration = 12
				},
				new Subscribe
				{
					SurnameNP = "Фаронова Р.В.", Street = "пр. Ленинский", Building = "124", Apartment = 75,
					Title = "Лабораторная диагностика инфекционных болезней", PubType = "Газета", PubIndex = "79127",
					StartDate = new DateTime(2020, 07, 17), Duration = 6
				},
				new Subscribe
				{
					SurnameNP = "Щупак Д.Ю.", Street = "Щорса", Building = "111", Apartment = 43,
					Title = "Интеллектуальная собственность: словарь терминов и определений", PubType = "Газета",
					PubIndex = "11774", StartDate = new DateTime(2020, 12, 15), Duration = 12
				},
				new Subscribe
				{
					SurnameNP = "Польский Д.М.", Street = "ул. Щорса", Building = "35", Apartment = 87,
					Title = "Карусель времени", PubType = "Газета", PubIndex = "85493",
					StartDate = new DateTime(2020, 08, 08), Duration = 3
				},
				new Subscribe
				{
					SurnameNP = "Абрамян М.Э.", Street = "ул. Овнатаняна", Building = "7", Apartment = 55,
					Title = "Паровозик", PubType = "Журнал", PubIndex = "80125", StartDate = new DateTime(2021, 09, 08),
					Duration = 6
				},
				new Subscribe
				{
					SurnameNP = "Васильев А.Н.", Street = "ул. Чкалова", Building = "46", Apartment = 61,
					Title = "Интеллектуальная собственность: словарь терминов и определений", PubType = "Журнал",
					PubIndex = "11774", StartDate = new DateTime(2021, 04, 12), Duration = 1
				},
				new Subscribe
				{
					SurnameNP = "Федорова В.О.", Street = "ул. Антонова", Building = "86", Apartment = 15,
					Title = "Земля в иллюминаторе", PubType = "Журнал", PubIndex = "10123",
					StartDate = new DateTime(2020, 12, 12), Duration = 1
				},
				new Subscribe
				{
					SurnameNP = "Мурадов И.с.", Street = "пр. Ильича", Building = "44", Apartment = 6,
					Title = "Здравушка. 100 лет без бед!", PubType = "Газета", PubIndex = "13838",
					StartDate = new DateTime(2007, 07, 07), Duration = 12
				},
			};

		public static BitmapImage GetImageFromSource(string source)
		{
			BitmapImage bitmapImage = new BitmapImage();
			bitmapImage.BeginInit();
			bitmapImage.UriSource = new Uri(source, UriKind.Relative);
			bitmapImage.EndInit();
			return bitmapImage;
		}

		// формирование случайных целых чисел в заданном диапазоне (lo, hi),
		// исключая указанное параметром exclude число
		public static int GetRandomExclude(int lo, int hi, int exclude)
		{
			int number = 0;
			do
				number = Random.Next(lo, hi);
			while (number == exclude);

			return number;
		} // GetRandomExclude

		// объект для получения случайных чисел
		public static readonly Random Random = new Random(Environment.TickCount);

		// Получение случайного числа
		// краткая форма записи метода - это не лямбда выражение
		public static int GetRandom(int lo, int hi) => Random.Next(lo, hi + 1);
		public static double GetRandom(double lo, double hi) => lo + (hi - lo) * Random.NextDouble();


		// фамилии и инициалы для формирования персональных данных
		public static string[] FullNames = {
			"Петрова Д.А.", 
			"Цыбенко Р.А.",
			"Юдина Н.А.", 
			"Фортранов Б.В.",
			"Шавыркина П.А.",
			"Фаронова Р.В.", 
			"Щупак Д.Ю.", 
			"Польский Д.М.",
			"Абрамян М.Э.",
			"Васильев А.Н.",
			"Федорова В.О.",
			"Мурадов И.с.", 
			"Штурлак А.В.", 
			"Баранова Е.В.",
			"Маслова Е.В", "Федорин М.Н.", "Семенов Б.В."  , "Семенова Р.Т." , "Дунаев О.Ю." , "Дунаева Г.Т.",
			"Харламова П.А.", "Харламов т.Р." , "Олегова В.Ф.", "Олегов В.Ф.",
			"Янковский Т.Р.", "Янковская О.Л.", "Абалкин Н.Р.", "Абалкина П.Р.",
			"Романова Р.Л." , "Воликов О.П."  , "Жукова Н.К." , "Соколов Р.Ж."
		};


	}
}
