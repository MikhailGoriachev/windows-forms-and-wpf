﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Task2.Helpers;

namespace Task2.Models
{
	public class PostalService
	{
		// коллекция данных
		private ObservableCollection<Subscribe> _subscribes;

		public ObservableCollection<Subscribe> Subscribes => _subscribes;

		public PostalService() : this(new ObservableCollection<Subscribe>(Utils.MakeTestData())) { }

		public PostalService(ObservableCollection<Subscribe> subscribes)
		{
			_subscribes = subscribes;
		}

		public int Count => _subscribes.Count;

		public bool IsEmpty => _subscribes.Count == 0;

		public Subscribe this[int index]
		{
			get
			{
				if (index < 0 || index >= Count)
					throw new IndexOutOfRangeException("Попытка доступа к элементу вне диапазона");
				return _subscribes[index];
			}
			set
			{
				if (index < 0 || index >= Count)
					throw new IndexOutOfRangeException("Попытка доступа к элементу вне диапазона");

				_subscribes[index] = value;
			}
		}

		// добавление подписки в коллекцию
		public void AddSubscribe(Subscribe subscribe) => _subscribes.Add(subscribe);

		// удаление выбранной подписки
		public void RemoveAt(int index) => _subscribes.RemoveAt(index);

		// удаление всех подписок
		public void RemoveAll() => _subscribes.Clear();

		// упорядочивание копии коллекции по заданному компаратору
		public List<Subscribe> OrderBy<Tkey>(Func<Subscribe, Tkey> selector) =>
			new List<Subscribe>(_subscribes.OrderBy(selector));

		public static List<Subscribe> OrderBy<Tkey>(ObservableCollection<Subscribe> list, Func<Subscribe, Tkey> selector) =>
			new List<Subscribe>(list.OrderBy(selector));

		public List<Subscribe> OrderByDescending<Tkey>(Func<Subscribe, Tkey> selector) =>
			new List<Subscribe>(_subscribes.OrderByDescending(selector));

		public static List<Subscribe> OrderByDescending<Tkey>(ObservableCollection<Subscribe> list, Func<Subscribe, Tkey> selector) =>
			new List<Subscribe>(list.OrderByDescending(selector));


		// выборка данных из коллекции по заданному предикату
		public List<Subscribe> Filter(Predicate<Subscribe> predicate) =>
			new List<Subscribe>(_subscribes.Where(x => predicate(x)));


		// Получить список типов издания, фигурирующих в коллекции
		public List<string> GetPubTypesList => _subscribes.Select(subscribe => subscribe.PubType).Distinct().ToList();

		// Получить список периодов подписок, фигурирующих в коллекции
		public List<string> GetDurationsList => _subscribes.Select(subscribe => subscribe.Duration.ToString()).Distinct().ToList();

		// Получить список фамилий и инициалов, фигурирующих в коллекции
		public List<string> GetSurnamesList => _subscribes.Select(subscribe => subscribe.SurnameNP).Distinct().ToList();
	}
}
