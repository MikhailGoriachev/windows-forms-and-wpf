﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task2.Models
{
	// класс, представляющий подписку на периодические издания
	public class Subscribe
	{
		// фамилию и инициалы подписчика
		private string _surnameNP;

		public string SurnameNP
		{
			get => _surnameNP;
			set
			{
				if (string.IsNullOrEmpty(value))
					throw new ArgumentNullException($"Пустая строка фамилии и инициалов подписчика");
				_surnameNP = value;
			}
		}

		// его адрес (улицу, дом и квартиру)

		private string _street;

		public string Street
		{
			get => _street;
			set
			{
				if (string.IsNullOrEmpty(value))
					throw new ArgumentNullException($"Пустая строка улицы адреса доставки");
				_street = value;
			}
		}

		private string _building;

		public string Building
		{
			get => _building;
			set
			{
				if (string.IsNullOrEmpty(value))
					throw new ArgumentNullException($"Пустая строка дом адреса доставки");
				_building = value;
			}
		}

		private int _apartment;

		public int Apartment
		{
			get => _apartment;
			set
			{
				if (value <= 0)
					throw new ArgumentOutOfRangeException($"Недопустимое значение квартиры адреса доставки: {value}");
				_apartment = value;
			}
		}

		// название издания
		private string _title;

		public string Title
		{
			get => _title;
			set
			{
				if (string.IsNullOrEmpty(value))
					throw new ArgumentNullException($"Пустая строка в названии издания");
				_title = value;
			}
		}

		// тип издания
		private string _pubType;

		public string PubType
		{
			get => _pubType;
			set
			{
				if (string.IsNullOrEmpty(value))
					throw new ArgumentNullException($"Пустая строка в типе издания");
				_pubType = value;
			}
		}

		// индекс издания
		private string _pubIndex;

		public string PubIndex
		{
			get => _pubIndex;
			set
			{
				if (string.IsNullOrEmpty(value))
					throw new ArgumentNullException($"Пустая строка в индексе издания");
				_pubIndex = value;
			}
		}

		// дата начала подписки
		private DateTime _startDate;

		public DateTime StartDate
		{
			get => _startDate;
			set
			{
				_startDate = value;
			}
		}

		// период подписки
		private int _duration;

		public int Duration
		{
			get => _duration;
			set
			{
				if (value <= 0)
					throw new ArgumentOutOfRangeException($"Недопустимое значения периода подписки: {value}");
				_duration = value;
			}
		}

	}
}
