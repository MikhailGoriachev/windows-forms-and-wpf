﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Task2.Models;

namespace Task2.Views
{
	/// <summary>
	/// Логика взаимодействия для SubscribeWindow.xaml
	/// </summary>
	public partial class SubscribeWindow : Window
	{
		private Subscribe _subscribe;

		public Subscribe Subscribe
		{
			get => _subscribe;
			set
			{
				_subscribe = value;
			}
		}

		public SubscribeWindow()
		{
			InitializeComponent();

			_subscribe = new Subscribe();
		}

		public SubscribeWindow(string windowTitle, string btnTitle)
		{
			InitializeComponent();
			_subscribe = new Subscribe();
		}
	}
}
