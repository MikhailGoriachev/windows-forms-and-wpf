﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace H_W6WF.Models
{
    // Цилиндр
    class Cylinder {
        // радиус основания
        private double _radius;
        public double Radius {
            get => _radius;
            set {
                if (value <= 0)
                    throw new ArgumentException("Cylinder. Отрицательный или нулевой радиус основания");
                _radius = value;
            } // set
        } // Radius

        // высота
        private double _height;
        public double Height {
            get => _height;
            set {
                if (value <= 0)
                    throw new ArgumentException("Cylinder. Отрицательная или нулевая высота");
                _height = value;
            } // set
        }

        // плотность материала
        private double _density;
        public double Density {
            get => _density;
            set {
                if (value <= 0)
                    throw new ArgumentException("Cylinder. Отрицательная или нулевая плотность материала");
                _density = value;
            } // set
        }

        public Cylinder() : this(1d, 1d, 1d) { }
        public Cylinder(double r, double h, double d) {
            Radius = r;
            Height = h;
            Density = d;
        } // Cone

        // Вычисление площади цилиндрa
        public double CalcArea() => 2d * Math.PI * _radius * (_height + _radius);

        // Вычисление объема цилиндрa
        public double CalcVolume() => Math.PI * _radius * _radius * _height;

        // Вычисление массы цилиндрa
        public double CalcMassa() =>
            CalcVolume() * Density;
    }
}
