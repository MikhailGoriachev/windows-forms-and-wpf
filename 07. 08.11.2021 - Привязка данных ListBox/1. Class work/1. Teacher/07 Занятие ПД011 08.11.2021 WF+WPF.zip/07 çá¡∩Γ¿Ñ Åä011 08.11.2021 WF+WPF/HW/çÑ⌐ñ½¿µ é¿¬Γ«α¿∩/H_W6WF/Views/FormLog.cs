﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace H_W6WF.Views
{
    public partial class FormLog : Form
    {
        private string _logFileName;

        public FormLog() : this("figures.log") { } // FormLog

        public FormLog(string logFileName)
        {
            InitializeComponent();

            // получить имя файла-журнала
            _logFileName = logFileName;
        }

        private void FormLog_Load(object sender, EventArgs e)
        {
            TxbLog.Lines = File.ReadAllLines(_logFileName, Encoding.UTF8);
        } // FormLog_Load

        private void BtnLogExit_Click(object sender, EventArgs e)
        {
            File.WriteAllText(_logFileName, "", Encoding.UTF8);
            TxbLog.Text = "";
        }
        
            
        
    }
}
