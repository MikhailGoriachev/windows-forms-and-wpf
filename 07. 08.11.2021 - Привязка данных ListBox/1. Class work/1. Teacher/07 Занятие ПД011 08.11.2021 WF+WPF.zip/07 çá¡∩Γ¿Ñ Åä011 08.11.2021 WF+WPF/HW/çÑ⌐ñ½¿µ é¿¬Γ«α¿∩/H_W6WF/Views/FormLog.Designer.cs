﻿
namespace H_W6WF.Views
{
    partial class FormLog
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.TxbLog = new System.Windows.Forms.TextBox();
            this.BtnLogExit = new System.Windows.Forms.Button();
            this.LblLogText = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // TxbLog
            // 
            this.TxbLog.BackColor = System.Drawing.Color.LightYellow;
            this.TxbLog.Font = new System.Drawing.Font("Consolas", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TxbLog.Location = new System.Drawing.Point(12, 39);
            this.TxbLog.Multiline = true;
            this.TxbLog.Name = "TxbLog";
            this.TxbLog.ReadOnly = true;
            this.TxbLog.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.TxbLog.Size = new System.Drawing.Size(354, 347);
            this.TxbLog.TabIndex = 0;
            this.TxbLog.WordWrap = false;
            // 
            // BtnLogExit
            // 
            this.BtnLogExit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.BtnLogExit.Font = new System.Drawing.Font("Lucida Console", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BtnLogExit.Location = new System.Drawing.Point(388, 336);
            this.BtnLogExit.Name = "BtnLogExit";
            this.BtnLogExit.Size = new System.Drawing.Size(184, 50);
            this.BtnLogExit.TabIndex = 1;
            this.BtnLogExit.Text = "Очистка";
            this.BtnLogExit.UseVisualStyleBackColor = false;
            this.BtnLogExit.Click += new System.EventHandler(this.BtnLogExit_Click);
            // 
            // LblLogText
            // 
            this.LblLogText.AutoSize = true;
            this.LblLogText.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblLogText.Location = new System.Drawing.Point(12, 23);
            this.LblLogText.Name = "LblLogText";
            this.LblLogText.Size = new System.Drawing.Size(224, 17);
            this.LblLogText.TabIndex = 2;
            this.LblLogText.Text = "Сведения о работе приложения: ";
            // 
            // FormLog
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.BackColor = System.Drawing.Color.LightCyan;
            this.ClientSize = new System.Drawing.Size(584, 411);
            this.Controls.Add(this.LblLogText);
            this.Controls.Add(this.BtnLogExit);
            this.Controls.Add(this.TxbLog);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "FormLog";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Журнал";
            this.Load += new System.EventHandler(this.FormLog_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox TxbLog;
        private System.Windows.Forms.Button BtnLogExit;
        private System.Windows.Forms.Label LblLogText;
    }
}