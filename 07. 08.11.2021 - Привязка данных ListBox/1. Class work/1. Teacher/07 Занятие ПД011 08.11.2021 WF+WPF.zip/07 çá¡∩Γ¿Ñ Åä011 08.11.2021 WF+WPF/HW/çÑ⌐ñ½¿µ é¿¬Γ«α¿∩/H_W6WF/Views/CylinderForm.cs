﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using H_W6WF.Models;

namespace H_W6WF
{
    public partial class CylinderForm : Form
    {
        // Данные для обработки
        private Cylinder _cylinder;
        public CylinderForm() {
            InitializeComponent();
            _cylinder = new Cylinder { Density = Program.steelDensity};
        } // CylinderForm

        private void btnExit_Click(object sender, EventArgs e) => Close();

        private void btnCalculate_Click(object sender, EventArgs e) {
            double area;   // площадь 
            double massa;   // масса 
            double volume;  // объем 

            // Получить исходные данные для расчета
            _cylinder.Radius = MainForm.ParseValue(NudRadius, ErpRadius, out bool res1);
            _cylinder.Height = MainForm.ParseValue(NudHight, ErpHeight, out bool res2);

            // расчет объема
            if (chbVolume.Checked) {
                volume = _cylinder.CalcVolume();
                lblVolume.Text = $"Объем цилиндра: {volume:n3}";
            }
            else
                lblVolume.Text = "Объем цилиндра: расчет не требуется";

            // расчет площади
            if (chbArea.Checked) {
                area = _cylinder.CalcArea();
                LblArea.Text = $"Площадь цилиндра: {area:n3}";
            }
            else
                LblArea.Text = "Площадь цилиндра: расчет не требуется";

            // расчет массы
            if (chbMassa.Checked) {
                massa = _cylinder.CalcMassa();
                LblMassa.Text = $"Масса цилиндра: {massa:n3}";
            }
            else
                LblMassa.Text = "Масса цилиндра: расчет не требуется";

            if (!res1 || !res2) ClearResult();
            File.AppendAllText("figures.log", contents: $"{DateTime.Now:dd.MM.yyyy HH:mm:ss}\r\n{lblVolume.Text:n3}\r\n{LblArea.Text:n3}\r\n{LblMassa.Text:n3}\n", Encoding.UTF8);
        } // btnCalculate_Click

       private void ClearResult() {
            lblVolume.Text = "Объем цилиндра: ";
            LblArea.Text = "Площадь цилиндра: ";
            LblMassa.Text = "Масса цилиндра: ";
        } // ClearResult

        private void TbxRadius_TextChanged(object sender, EventArgs e) {
            ErpRadius.SetError(NudRadius, "");
            ClearResult();
        } // TbxRadius_TextChanged

        private void TbxHeight_TextChanged(object sender, EventArgs e) { 
            ErpHeight.SetError(NudHight, "");
            ClearResult();
        } // TbxHeight_TextChanged

        private void RbtSteel_CheckedChanged(object sender, EventArgs e) {
            _cylinder.Density = Program.steelDensity;
            // смена картинки 
            PcbMaterial.Image = Properties.Resources.steel;
        } // RbtSteel_CheckedChanged

        private void RbtCopper_CheckedChanged(object sender, EventArgs e) {
            _cylinder.Density = Program.copperDensity;
            // смена картинки 
            PcbMaterial.Image = Properties.Resources.copper;
        } // RbtCopper_CheckedChanged

        private void RbtIce_CheckedChanged(object sender, EventArgs e) {
            _cylinder.Density = Program.iceDensity;
            // смена картинки 
            PcbMaterial.Image = Properties.Resources.ice;
        } // RbtIce_CheckedChanged

        private void RbtGranite_CheckedChanged(object sender, EventArgs e) {
            _cylinder.Density = Program.graniteDensity;
            // смена картинки 
            PcbMaterial.Image = Properties.Resources.granite;
        } // RbtGranite_CheckedChanged
    }
}
