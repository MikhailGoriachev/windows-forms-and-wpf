﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace H_W6WF
{
    static class Program
    {
        public const double steelDensity = 7950d, // плотность стали (нержавеющей)
                           copperDensity = 8900d, // плотность меди
                              iceDensity = 920d,  // плотность водяного льда
                          graniteDensity = 2700d; // плотность гранита

        /// <summary>
        /// Главная точка входа для приложения.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new MainForm());
        }
    }
}
