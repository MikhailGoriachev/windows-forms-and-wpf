﻿using H_W6WF.Views;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace H_W6WF
{
    public partial class MainForm : Form
    {
        // формы приложения
        private FormAboutPrgm _first;
        private FormLog _second;
        private ListBoxForm _listForm;
        private ConoidForm _conoidForm;
        private SphereForm _sphereForm;
        private CylinderForm _cylinderForm;
        private ParallelepipedForm _parallelepipedForm;

        public MainForm()
        {
            InitializeComponent();
        }

        private void MnuFigures_Click(object sender, EventArgs e) { }

        private void MnuExit_Click(object sender, EventArgs e) => Application.Exit();

        // форма о программе, сведения о приложении и разработчике
        private void MnuAboutPrm_Click(object sender, EventArgs e)
        {
            _first = new FormAboutPrgm();

            _first.SetText("Студент: Зейдлиц Виктория\nГруппа: ПД011\nКА Шаг г.Донецк 2021");

            // Отобразить форму в модальном режиме
            _first.ShowDialog();
        }// MnuAboutPrm_Click

        // форма записи журнала работы о программе
        private void MenuViewing_Click(object sender, EventArgs e)
        {
            _second = new FormLog();
            _second.ShowDialog();
        }// MenuViewing_Click

        public static double ParseValue(TextBox textBox, ErrorProvider errorProvider, out bool res)
        {
            bool result = double.TryParse(textBox.Text, out double value);
            errorProvider.SetError(textBox, !result || value <= 0 ? "Недопустимый формат" : "");
            res = !result || value <= 0 ? false : true;
            return !result || value <= 0 ? 1d : value;
        } // ParseValue

        public static double ParseValue(NumericUpDown numericUpDown, ErrorProvider errorProvider, out bool res)
        {
            bool result = double.TryParse(numericUpDown.Text, out double value);
            errorProvider.SetError(numericUpDown, !result || value <= 0 ? "Недопустимый формат" : "");
            res = !result || value <= 0 ? false : true;
            return !result || value <= 0 ? 1d : value;
        } // ParseValue

        public static double ParseValue(TextBox textBox, ErrorProvider errorProvider)
        {
            bool result = double.TryParse(textBox.Text, out double value);
            errorProvider.SetError(textBox, !result || value <= 0 ? "Недопустимый формат" : "");
            return value;
        } // ParseValue


        private void MnuConoid_Click(object sender, EventArgs e)
        {
            _conoidForm = new ConoidForm();
            _conoidForm.ShowDialog();  // модальное отображение формы

            TxbMainFormLog.Lines = File.ReadAllLines("figures.log", Encoding.UTF8);
        }// MnuConoid_Click

        private void MnuSphere_Click(object sender, EventArgs e)
        {
            _sphereForm = new SphereForm();
            _sphereForm.ShowDialog();  // модальное отображение формы

            TxbMainFormLog.Lines = File.ReadAllLines("figures.log", Encoding.UTF8);
        }// MnuSphere_Click

        private void MnuCylinder_Click(object sender, EventArgs e)
        {
            _cylinderForm = new CylinderForm();

            _cylinderForm.ShowDialog();  // модальное отображение формы

            TxbMainFormLog.Lines = File.ReadAllLines("figures.log", Encoding.UTF8);
        }// MnuCylinder_Click

        private void MnuParallelepiped_Click(object sender, EventArgs e)
        {
            _parallelepipedForm = new ParallelepipedForm();

            _parallelepipedForm.ShowDialog();  // модальное отображение формы

            TxbMainFormLog.Lines = File.ReadAllLines("figures.log", Encoding.UTF8);
        }// MnuParallelepiped_Click

        private void MnuClear_Click(object sender, EventArgs e)
        {
            File.WriteAllText("figures.log", "", Encoding.UTF8);
            TxbMainFormLog.Text = "";
        }// MnuClear_Click

        //-------------------------------------------------------------------
        // Задача 2
        
        private void MnuListBox_Click(object sender, EventArgs e)
        {
            _listForm = new ListBoxForm();
            _listForm.ShowDialog();
        }// MnuListBox_Click
    }
}
