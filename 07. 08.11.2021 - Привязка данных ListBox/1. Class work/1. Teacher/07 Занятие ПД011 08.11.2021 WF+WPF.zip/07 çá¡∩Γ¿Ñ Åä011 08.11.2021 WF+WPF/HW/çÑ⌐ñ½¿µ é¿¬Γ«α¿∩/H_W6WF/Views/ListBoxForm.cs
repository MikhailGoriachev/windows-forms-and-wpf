﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace H_W6WF.Views
{
    public partial class ListBoxForm : Form
    {
        public ListBoxForm()
        {
            InitializeComponent();
        }

        // перемещение выбранного элемента из первого лист-бокса во второй
        private void BtnAdd_Click(object sender, EventArgs e)
        {
            string city = LbxFirst.Text;

            // если ничего не выбрано - молча уходим
            if (string.IsNullOrWhiteSpace(city)) return;

            LbxSecond.Items.Add(city);
        }

        // перемещение всех элементов из первого лист-бокса во второй
        private void BtnAddAll_Click(object sender, EventArgs e)
        {
            LbxSecond.Items.AddRange(LbxFirst.Items);
        }

        // перемещение выбранного элемента из второго лист-бокса в первый
        private void BtnSecondAddFirst_Click(object sender, EventArgs e)
        {
            foreach(var item in LbxSecond.SelectedItems)  
               LbxFirst.Items.Add(item);
        }

        // перемещение всех элементов из второго лист-бокса в первый
        private void BtnAllCityFromSecToFir_Click(object sender, EventArgs e)
        {
            LbxFirst.Items.AddRange(LbxSecond.Items);
        }

        // очистка обоих лист-боксов
        private void BtnClear_Click(object sender, EventArgs e)
        {
            LbxFirst.Items.Clear();
            LbxSecond.Items.Clear();
        }

        // ввод названия города в строку ввода и добавление города по кнопке в первый лист-бокс
        private void BtnAddFromCmbToLbxFirst_Click(object sender, EventArgs e)
        {
            // чтение из комбобокса  
            string city = CmbAddWrite.Text;

            if (string.IsNullOrWhiteSpace(city)) return;

            // добавление в листбокс
            LbxFirst.Items.Add(city);
        }

        private void BtnFromCmbToCmb2_Click(object sender, EventArgs e)
        {
            // чтение из комбобокса  
            string city = CmbAddWrite.Text;

            if (string.IsNullOrWhiteSpace(city)) return;

            // добавление в комбобокс
            Cmb2.Items.Add(city);
        }

    }// class ListBoxForm
}
