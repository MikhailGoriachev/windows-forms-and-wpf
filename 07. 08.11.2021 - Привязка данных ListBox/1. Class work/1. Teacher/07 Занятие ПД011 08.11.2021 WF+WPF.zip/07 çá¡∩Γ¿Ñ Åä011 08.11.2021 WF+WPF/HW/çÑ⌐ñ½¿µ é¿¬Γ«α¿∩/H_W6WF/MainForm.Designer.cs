﻿
namespace H_W6WF
{
    partial class MainForm
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.MnuMain = new System.Windows.Forms.MenuStrip();
            this.MnuVolumeFigure = new System.Windows.Forms.ToolStripMenuItem();
            this.MnuLog = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuViewing = new System.Windows.Forms.ToolStripMenuItem();
            this.MnuClear = new System.Windows.Forms.ToolStripMenuItem();
            this.MnuHelp = new System.Windows.Forms.ToolStripMenuItem();
            this.MnuAboutPrm = new System.Windows.Forms.ToolStripMenuItem();
            this.MnuDash = new System.Windows.Forms.ToolStripSeparator();
            this.MnuExit = new System.Windows.Forms.ToolStripMenuItem();
            this.TxbMainFormLog = new System.Windows.Forms.TextBox();
            this.LblLogText = new System.Windows.Forms.Label();
            this.MnuListBox = new System.Windows.Forms.ToolStripMenuItem();
            this.MnuFile = new System.Windows.Forms.ToolStripMenuItem();
            this.MnuConoid = new System.Windows.Forms.ToolStripMenuItem();
            this.MnuSphere = new System.Windows.Forms.ToolStripMenuItem();
            this.MnuCylinder = new System.Windows.Forms.ToolStripMenuItem();
            this.MnuParallelepiped = new System.Windows.Forms.ToolStripMenuItem();
            this.MnuMain.SuspendLayout();
            this.SuspendLayout();
            // 
            // MnuMain
            // 
            this.MnuMain.Font = new System.Drawing.Font("Tahoma", 10F);
            this.MnuMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MnuFile,
            this.MnuVolumeFigure,
            this.MnuListBox,
            this.MnuLog,
            this.MnuHelp});
            this.MnuMain.Location = new System.Drawing.Point(0, 0);
            this.MnuMain.Name = "MnuMain";
            this.MnuMain.Size = new System.Drawing.Size(624, 25);
            this.MnuMain.TabIndex = 0;
            this.MnuMain.Text = "menuStrip1";
            // 
            // MnuVolumeFigure
            // 
            this.MnuVolumeFigure.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MnuConoid,
            this.MnuSphere,
            this.MnuCylinder,
            this.MnuParallelepiped});
            this.MnuVolumeFigure.Name = "MnuVolumeFigure";
            this.MnuVolumeFigure.Size = new System.Drawing.Size(121, 21);
            this.MnuVolumeFigure.Text = "&Объёмные тела";
            // 
            // MnuLog
            // 
            this.MnuLog.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MenuViewing,
            this.MnuClear});
            this.MnuLog.Name = "MnuLog";
            this.MnuLog.Size = new System.Drawing.Size(73, 21);
            this.MnuLog.Text = "Ж&урнал";
            // 
            // MenuViewing
            // 
            this.MenuViewing.Name = "MenuViewing";
            this.MenuViewing.Size = new System.Drawing.Size(141, 22);
            this.MenuViewing.Text = "Просмотр";
            this.MenuViewing.Click += new System.EventHandler(this.MenuViewing_Click);
            // 
            // MnuClear
            // 
            this.MnuClear.Name = "MnuClear";
            this.MnuClear.Size = new System.Drawing.Size(141, 22);
            this.MnuClear.Text = "Очистка";
            this.MnuClear.Click += new System.EventHandler(this.MnuClear_Click);
            // 
            // MnuHelp
            // 
            this.MnuHelp.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MnuAboutPrm,
            this.MnuDash,
            this.MnuExit});
            this.MnuHelp.Name = "MnuHelp";
            this.MnuHelp.Size = new System.Drawing.Size(72, 21);
            this.MnuHelp.Text = "П&омощь";
            // 
            // MnuAboutPrm
            // 
            this.MnuAboutPrm.Name = "MnuAboutPrm";
            this.MnuAboutPrm.Size = new System.Drawing.Size(168, 22);
            this.MnuAboutPrm.Text = "О программе..";
            this.MnuAboutPrm.Click += new System.EventHandler(this.MnuAboutPrm_Click);
            // 
            // MnuDash
            // 
            this.MnuDash.Name = "MnuDash";
            this.MnuDash.Size = new System.Drawing.Size(165, 6);
            // 
            // MnuExit
            // 
            this.MnuExit.Name = "MnuExit";
            this.MnuExit.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.F4)));
            this.MnuExit.Size = new System.Drawing.Size(168, 22);
            this.MnuExit.Text = "В&ыход";
            this.MnuExit.Click += new System.EventHandler(this.MnuExit_Click);
            // 
            // TxbMainFormLog
            // 
            this.TxbMainFormLog.BackColor = System.Drawing.Color.LightYellow;
            this.TxbMainFormLog.Font = new System.Drawing.Font("Consolas", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TxbMainFormLog.Location = new System.Drawing.Point(63, 156);
            this.TxbMainFormLog.Multiline = true;
            this.TxbMainFormLog.Name = "TxbMainFormLog";
            this.TxbMainFormLog.ReadOnly = true;
            this.TxbMainFormLog.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.TxbMainFormLog.Size = new System.Drawing.Size(470, 273);
            this.TxbMainFormLog.TabIndex = 1;
            // 
            // LblLogText
            // 
            this.LblLogText.AutoSize = true;
            this.LblLogText.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblLogText.Location = new System.Drawing.Point(63, 136);
            this.LblLogText.Name = "LblLogText";
            this.LblLogText.Size = new System.Drawing.Size(224, 17);
            this.LblLogText.TabIndex = 3;
            this.LblLogText.Text = "Сведения о работе приложения: ";
            // 
            // MnuListBox
            // 
            this.MnuListBox.Name = "MnuListBox";
            this.MnuListBox.Size = new System.Drawing.Size(67, 21);
            this.MnuListBox.Text = "С&писки";
            this.MnuListBox.Click += new System.EventHandler(this.MnuListBox_Click);
            // 
            // MnuFile
            // 
            this.MnuFile.Image = global::H_W6WF.Properties.Resources.icon_menu;
            this.MnuFile.Name = "MnuFile";
            this.MnuFile.Size = new System.Drawing.Size(69, 21);
            this.MnuFile.Text = "Ф&айл";
            // 
            // MnuConoid
            // 
            this.MnuConoid.Image = global::H_W6WF.Properties.Resources.geometric_shapes;
            this.MnuConoid.Name = "MnuConoid";
            this.MnuConoid.Size = new System.Drawing.Size(291, 22);
            this.MnuConoid.Text = "Усечённый конус";
            this.MnuConoid.Click += new System.EventHandler(this.MnuConoid_Click);
            // 
            // MnuSphere
            // 
            this.MnuSphere.Image = global::H_W6WF.Properties.Resources.geometric_shapes;
            this.MnuSphere.Name = "MnuSphere";
            this.MnuSphere.Size = new System.Drawing.Size(291, 22);
            this.MnuSphere.Text = "Сфера";
            this.MnuSphere.Click += new System.EventHandler(this.MnuSphere_Click);
            // 
            // MnuCylinder
            // 
            this.MnuCylinder.Image = global::H_W6WF.Properties.Resources.geometric_shapes;
            this.MnuCylinder.Name = "MnuCylinder";
            this.MnuCylinder.Size = new System.Drawing.Size(291, 22);
            this.MnuCylinder.Text = "Цилиндр";
            this.MnuCylinder.Click += new System.EventHandler(this.MnuCylinder_Click);
            // 
            // MnuParallelepiped
            // 
            this.MnuParallelepiped.Image = global::H_W6WF.Properties.Resources.geometric_shapes;
            this.MnuParallelepiped.Name = "MnuParallelepiped";
            this.MnuParallelepiped.Size = new System.Drawing.Size(291, 22);
            this.MnuParallelepiped.Text = "Прямоугольный параллелепипед";
            this.MnuParallelepiped.Click += new System.EventHandler(this.MnuParallelepiped_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(624, 441);
            this.Controls.Add(this.LblLogText);
            this.Controls.Add(this.TxbMainFormLog);
            this.Controls.Add(this.MnuMain);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MainMenuStrip = this.MnuMain;
            this.MinimizeBox = false;
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Домашнее задание №6";
            this.MnuMain.ResumeLayout(false);
            this.MnuMain.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip MnuMain;
        private System.Windows.Forms.ToolStripMenuItem MnuFile;
        private System.Windows.Forms.ToolStripMenuItem MnuLog;
        private System.Windows.Forms.ToolStripMenuItem MenuViewing;
        private System.Windows.Forms.ToolStripMenuItem MnuClear;
        private System.Windows.Forms.ToolStripMenuItem MnuHelp;
        private System.Windows.Forms.ToolStripMenuItem MnuAboutPrm;
        private System.Windows.Forms.ToolStripSeparator MnuDash;
        private System.Windows.Forms.ToolStripMenuItem MnuExit;
        private System.Windows.Forms.ToolStripMenuItem MnuVolumeFigure;
        private System.Windows.Forms.ToolStripMenuItem MnuConoid;
        private System.Windows.Forms.ToolStripMenuItem MnuSphere;
        private System.Windows.Forms.ToolStripMenuItem MnuCylinder;
        private System.Windows.Forms.ToolStripMenuItem MnuParallelepiped;
        private System.Windows.Forms.TextBox TxbMainFormLog;
        private System.Windows.Forms.Label LblLogText;
        private System.Windows.Forms.ToolStripMenuItem MnuListBox;
    }
}

