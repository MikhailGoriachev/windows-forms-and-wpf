﻿
namespace H_W6WF.Views
{
    partial class ListBoxForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.LbxFirst = new System.Windows.Forms.ListBox();
            this.LblListB1 = new System.Windows.Forms.Label();
            this.LbxSecond = new System.Windows.Forms.ListBox();
            this.BtnAdd = new System.Windows.Forms.Button();
            this.BtnAddAll = new System.Windows.Forms.Button();
            this.BtnSecondAddFirst = new System.Windows.Forms.Button();
            this.BtnAllCityFromSecToFir = new System.Windows.Forms.Button();
            this.BtnClear = new System.Windows.Forms.Button();
            this.CmbAddWrite = new System.Windows.Forms.ComboBox();
            this.BtnAddFromCmbToLbxFirst = new System.Windows.Forms.Button();
            this.LblTxt = new System.Windows.Forms.Label();
            this.LblCmb1 = new System.Windows.Forms.Label();
            this.Cmb2 = new System.Windows.Forms.ComboBox();
            this.BtnFromCmbToCmb2 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // LbxFirst
            // 
            this.LbxFirst.FormattingEnabled = true;
            this.LbxFirst.ItemHeight = 12;
            this.LbxFirst.Items.AddRange(new object[] {
            "Москва",
            "Стамбул",
            "Лондон",
            "Берлин",
            "Мадрид",
            "Киев",
            "Рим",
            "Бухарест",
            "Париж",
            "Минск",
            "Вена",
            "Гамбург",
            "Варшава",
            "Барселона"});
            this.LbxFirst.Location = new System.Drawing.Point(17, 54);
            this.LbxFirst.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.LbxFirst.Name = "LbxFirst";
            this.LbxFirst.Size = new System.Drawing.Size(155, 280);
            this.LbxFirst.TabIndex = 0;
            // 
            // LblListB1
            // 
            this.LblListB1.AutoSize = true;
            this.LblListB1.Location = new System.Drawing.Point(17, 38);
            this.LblListB1.Name = "LblListB1";
            this.LblListB1.Size = new System.Drawing.Size(131, 12);
            this.LblListB1.TabIndex = 2;
            this.LblListB1.Text = "Названия городов: ";
            // 
            // LbxSecond
            // 
            this.LbxSecond.FormattingEnabled = true;
            this.LbxSecond.ItemHeight = 12;
            this.LbxSecond.Location = new System.Drawing.Point(198, 54);
            this.LbxSecond.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.LbxSecond.Name = "LbxSecond";
            this.LbxSecond.Size = new System.Drawing.Size(155, 280);
            this.LbxSecond.TabIndex = 3;
            // 
            // BtnAdd
            // 
            this.BtnAdd.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.BtnAdd.Font = new System.Drawing.Font("Lucida Console", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BtnAdd.Location = new System.Drawing.Point(367, 54);
            this.BtnAdd.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.BtnAdd.Name = "BtnAdd";
            this.BtnAdd.Size = new System.Drawing.Size(198, 25);
            this.BtnAdd.TabIndex = 4;
            this.BtnAdd.Text = "Перемещение города из L1 в L2";
            this.BtnAdd.UseVisualStyleBackColor = false;
            this.BtnAdd.Click += new System.EventHandler(this.BtnAdd_Click);
            // 
            // BtnAddAll
            // 
            this.BtnAddAll.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.BtnAddAll.Font = new System.Drawing.Font("Lucida Console", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BtnAddAll.Location = new System.Drawing.Point(367, 92);
            this.BtnAddAll.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.BtnAddAll.Name = "BtnAddAll";
            this.BtnAddAll.Size = new System.Drawing.Size(198, 25);
            this.BtnAddAll.TabIndex = 5;
            this.BtnAddAll.Text = "Перемещение городов из L1 в L2";
            this.BtnAddAll.UseVisualStyleBackColor = false;
            this.BtnAddAll.Click += new System.EventHandler(this.BtnAddAll_Click);
            // 
            // BtnSecondAddFirst
            // 
            this.BtnSecondAddFirst.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.BtnSecondAddFirst.Font = new System.Drawing.Font("Lucida Console", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BtnSecondAddFirst.Location = new System.Drawing.Point(369, 135);
            this.BtnSecondAddFirst.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.BtnSecondAddFirst.Name = "BtnSecondAddFirst";
            this.BtnSecondAddFirst.Size = new System.Drawing.Size(198, 25);
            this.BtnSecondAddFirst.TabIndex = 6;
            this.BtnSecondAddFirst.Text = "Перемещение города из L2 в L1";
            this.BtnSecondAddFirst.UseVisualStyleBackColor = false;
            this.BtnSecondAddFirst.Click += new System.EventHandler(this.BtnSecondAddFirst_Click);
            // 
            // BtnAllCityFromSecToFir
            // 
            this.BtnAllCityFromSecToFir.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.BtnAllCityFromSecToFir.Font = new System.Drawing.Font("Lucida Console", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BtnAllCityFromSecToFir.Location = new System.Drawing.Point(369, 178);
            this.BtnAllCityFromSecToFir.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.BtnAllCityFromSecToFir.Name = "BtnAllCityFromSecToFir";
            this.BtnAllCityFromSecToFir.Size = new System.Drawing.Size(198, 25);
            this.BtnAllCityFromSecToFir.TabIndex = 7;
            this.BtnAllCityFromSecToFir.Text = "Перемещение городов из L2 в L1";
            this.BtnAllCityFromSecToFir.UseVisualStyleBackColor = false;
            this.BtnAllCityFromSecToFir.Click += new System.EventHandler(this.BtnAllCityFromSecToFir_Click);
            // 
            // BtnClear
            // 
            this.BtnClear.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.BtnClear.Font = new System.Drawing.Font("Lucida Console", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BtnClear.Location = new System.Drawing.Point(369, 221);
            this.BtnClear.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.BtnClear.Name = "BtnClear";
            this.BtnClear.Size = new System.Drawing.Size(198, 25);
            this.BtnClear.TabIndex = 8;
            this.BtnClear.Text = "Очистить ListBoxes";
            this.BtnClear.UseVisualStyleBackColor = false;
            this.BtnClear.Click += new System.EventHandler(this.BtnClear_Click);
            // 
            // CmbAddWrite
            // 
            this.CmbAddWrite.FormattingEnabled = true;
            this.CmbAddWrite.Items.AddRange(new object[] {
            "Токио",
            "Дели",
            "Шанхай",
            "Сан-Паулу",
            "Мехико",
            "Каир",
            "Пекин",
            "Нью-Йорк"});
            this.CmbAddWrite.Location = new System.Drawing.Point(17, 365);
            this.CmbAddWrite.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.CmbAddWrite.Name = "CmbAddWrite";
            this.CmbAddWrite.Size = new System.Drawing.Size(155, 20);
            this.CmbAddWrite.TabIndex = 9;
            // 
            // BtnAddFromCmbToLbxFirst
            // 
            this.BtnAddFromCmbToLbxFirst.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.BtnAddFromCmbToLbxFirst.Font = new System.Drawing.Font("Lucida Console", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BtnAddFromCmbToLbxFirst.Location = new System.Drawing.Point(369, 264);
            this.BtnAddFromCmbToLbxFirst.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.BtnAddFromCmbToLbxFirst.Name = "BtnAddFromCmbToLbxFirst";
            this.BtnAddFromCmbToLbxFirst.Size = new System.Drawing.Size(198, 25);
            this.BtnAddFromCmbToLbxFirst.TabIndex = 10;
            this.BtnAddFromCmbToLbxFirst.Text = "Добавить город в ListBox";
            this.BtnAddFromCmbToLbxFirst.UseVisualStyleBackColor = false;
            this.BtnAddFromCmbToLbxFirst.Click += new System.EventHandler(this.BtnAddFromCmbToLbxFirst_Click);
            // 
            // LblTxt
            // 
            this.LblTxt.AutoSize = true;
            this.LblTxt.Location = new System.Drawing.Point(367, 38);
            this.LblTxt.Name = "LblTxt";
            this.LblTxt.Size = new System.Drawing.Size(131, 12);
            this.LblTxt.TabIndex = 11;
            this.LblTxt.Text = "Выберите действие:";
            // 
            // LblCmb1
            // 
            this.LblCmb1.AutoSize = true;
            this.LblCmb1.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblCmb1.Location = new System.Drawing.Point(14, 349);
            this.LblCmb1.Name = "LblCmb1";
            this.LblCmb1.Size = new System.Drawing.Size(240, 14);
            this.LblCmb1.TabIndex = 12;
            this.LblCmb1.Text = "Выберите или введите название города:";
            // 
            // Cmb2
            // 
            this.Cmb2.FormattingEnabled = true;
            this.Cmb2.Location = new System.Drawing.Point(198, 366);
            this.Cmb2.Name = "Cmb2";
            this.Cmb2.Size = new System.Drawing.Size(155, 20);
            this.Cmb2.TabIndex = 13;
            // 
            // BtnFromCmbToCmb2
            // 
            this.BtnFromCmbToCmb2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.BtnFromCmbToCmb2.Font = new System.Drawing.Font("Lucida Console", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BtnFromCmbToCmb2.Location = new System.Drawing.Point(367, 307);
            this.BtnFromCmbToCmb2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.BtnFromCmbToCmb2.Name = "BtnFromCmbToCmb2";
            this.BtnFromCmbToCmb2.Size = new System.Drawing.Size(198, 25);
            this.BtnFromCmbToCmb2.TabIndex = 14;
            this.BtnFromCmbToCmb2.Text = "Добавить город в ComboBox2";
            this.BtnFromCmbToCmb2.UseVisualStyleBackColor = false;
            this.BtnFromCmbToCmb2.Click += new System.EventHandler(this.BtnFromCmbToCmb2_Click);
            // 
            // ListBoxForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.BackColor = System.Drawing.Color.OldLace;
            this.ClientSize = new System.Drawing.Size(578, 428);
            this.Controls.Add(this.BtnFromCmbToCmb2);
            this.Controls.Add(this.Cmb2);
            this.Controls.Add(this.LblCmb1);
            this.Controls.Add(this.LblTxt);
            this.Controls.Add(this.BtnAddFromCmbToLbxFirst);
            this.Controls.Add(this.CmbAddWrite);
            this.Controls.Add(this.BtnClear);
            this.Controls.Add(this.BtnAllCityFromSecToFir);
            this.Controls.Add(this.BtnSecondAddFirst);
            this.Controls.Add(this.BtnAddAll);
            this.Controls.Add(this.BtnAdd);
            this.Controls.Add(this.LbxSecond);
            this.Controls.Add(this.LblListB1);
            this.Controls.Add(this.LbxFirst);
            this.Font = new System.Drawing.Font("Lucida Console", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.MaximizeBox = false;
            this.Name = "ListBoxForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Списки";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox LbxFirst;
        private System.Windows.Forms.Label LblListB1;
        private System.Windows.Forms.ListBox LbxSecond;
        private System.Windows.Forms.Button BtnAdd;
        private System.Windows.Forms.Button BtnAddAll;
        private System.Windows.Forms.Button BtnSecondAddFirst;
        private System.Windows.Forms.Button BtnAllCityFromSecToFir;
        private System.Windows.Forms.Button BtnClear;
        private System.Windows.Forms.ComboBox CmbAddWrite;
        private System.Windows.Forms.Button BtnAddFromCmbToLbxFirst;
        private System.Windows.Forms.Label LblTxt;
        private System.Windows.Forms.Label LblCmb1;
        private System.Windows.Forms.ComboBox Cmb2;
        private System.Windows.Forms.Button BtnFromCmbToCmb2;
    }
}