﻿
namespace H_W6WF.Views
{
    partial class FormAboutPrgm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.LblAboutPrgm = new System.Windows.Forms.Label();
            this.TmrAboutPrgm = new System.Windows.Forms.Timer(this.components);
            this.SuspendLayout();
            // 
            // LblAboutPrgm
            // 
            this.LblAboutPrgm.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.LblAboutPrgm.Location = new System.Drawing.Point(57, 39);
            this.LblAboutPrgm.Name = "LblAboutPrgm";
            this.LblAboutPrgm.Size = new System.Drawing.Size(238, 260);
            this.LblAboutPrgm.TabIndex = 0;
            this.LblAboutPrgm.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // TmrAboutPrgm
            // 
            this.TmrAboutPrgm.Interval = 10000;
            this.TmrAboutPrgm.Tick += new System.EventHandler(this.TmrAboutPrgm_Tick);
            // 
            // FormAboutPrgm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(358, 339);
            this.Controls.Add(this.LblAboutPrgm);
            this.Font = new System.Drawing.Font("Lucida Console", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.MaximizeBox = false;
            this.Name = "FormAboutPrgm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "О программе";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label LblAboutPrgm;
        private System.Windows.Forms.Timer TmrAboutPrgm;
    }
}