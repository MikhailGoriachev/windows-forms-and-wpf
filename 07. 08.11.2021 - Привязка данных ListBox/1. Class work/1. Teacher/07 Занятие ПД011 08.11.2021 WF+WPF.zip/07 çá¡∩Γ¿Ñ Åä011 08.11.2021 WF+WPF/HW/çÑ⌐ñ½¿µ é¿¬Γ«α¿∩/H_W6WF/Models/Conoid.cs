﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace H_W6WF.Models {
    // Усеченный конус
    class Conoid {
         // радиус нижнего основания
        private double _radius1;
        public double Radius1 {
            get => _radius1;
            set {
                if (value <= 0)
                    throw new ArgumentException("Conoid. Отрицательное или нулевое нижнее основание");
                _radius1 = value;
            } // set
        } // Radius1


        // радиус верхнего основания
        private double _radius2;
        public double Radius2 {
            get => _radius2;
            set {
                if (value <= 0)
                    throw new ArgumentException("Conoid. Отрицательное или нулевое верхнее основание");
                _radius2 = value;
            } // set
        } // Radius2


        // высота
        private double _height;
        public double Height {
            get => _height;
            set {
                if (value <= 0)
                    throw new ArgumentException("Conoid. Отрицательная или нулевая высота");
                _height = value;
            } // set
        } // Height

        // образующая
        public double L {
            get => Math.Sqrt(_height * _height + (_radius1 - _radius2) * (_radius1 - _radius2));
        } // L


        // плотность материала
        private double _density;
        public double Density {
            get => _density;
            set {
                if (value <= 0)
                    throw new ArgumentException("Conoid. Отрицательная или нулевая плотность материала");
                _density = value;
            } // set
        } // Density


        // Вычисление площади  конуса
        public double CalcArea() => 
            Math.PI * (_radius1 * _radius1 + (_radius1 * _radius2) * L + _radius2 * _radius2);


        // Вычисление объема конуса
        public double CalcVolume() => 
            1d / 3d * Math.PI * _height * (_radius1 * _radius1 + _radius1 * _radius2 + _radius2 * _radius2);


        // Вычисление массы конуса
        public double CalcMassa() =>
            CalcVolume() * Density;
    } // Conoid
}
