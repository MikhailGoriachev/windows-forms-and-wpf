﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Figures.Views;

namespace Figures
{
    public partial class MainForm : Form
    {
        private static string _fileName;
        public static string FileName { get => _fileName; private set => _fileName = value; }
        public MainForm(): this("Figures.log") { }
        public MainForm(string fileName) {
            InitializeComponent();
            _fileName = fileName;
        } // MainForm

        private void Quit_Click(object sender, EventArgs e) => Application.Exit();


        private void TsmAbout_Click(object sender, EventArgs e) {
            FormAbout formAbout = new FormAbout();
            formAbout.ShowDialog();
            MainForm_Load(this, e);
        } // TsmAbout_Click


        private void MainForm_Load(object sender, EventArgs e) {
            TbxLog.Text =
                "┌─────────────────────┬──────────────────────┬─────────────────────────────────────────┐\r\n" +
                "│                     │                      │           Выполненные расчеты           │\r\n" +
                "│     Дата и время    │      Вид фигуры      ├─────────────┬─────────────┬─────────────┤\r\n" +
                "│                     │                      │   Площадь   │    Объем    │    Масса    │\r\n" +
                "├─────────────────────┼──────────────────────┼─────────────┼─────────────┼─────────────┤\r\n";

            TbxLog.Text += File.ReadAllText(@"..\..\" + FileName, Encoding.UTF8);

            TbxLog.Text +=
                "└─────────────────────┴──────────────────────┴─────────────┴─────────────┴─────────────┘\r\n";

        } // MainForm_Load

        private void TsmConoid_Click(object sender, EventArgs e) {
            ConoidForm conoidForm = new ConoidForm();
            conoidForm.ShowDialog();
            MainForm_Load(this, e);
        } // TsmConoid_Click

        private void Clear_Click(object sender, EventArgs e) {
            File.WriteAllText(@"..\..\" + FileName, "", Encoding.UTF8);
            MainForm_Load(this, e);
        } // Clear_Click

        private void TsmSphere_Click(object sender, EventArgs e){
            SphereForm sphereForm = new SphereForm();
            sphereForm.ShowDialog();
            MainForm_Load(this, e);
        } // TsmSphere_Click

        private void TsmCylinder_Click(object sender, EventArgs e) {
            CylinderForm cylinderForm = new CylinderForm();
            cylinderForm.ShowDialog();
            MainForm_Load(this, e);
        } // TsmCylinder_Click

        private void TsmParallelepiped_Click(object sender, EventArgs e){
            ParallelepipedForm parallelepipedForm = new ParallelepipedForm();
            parallelepipedForm.ShowDialog();
            MainForm_Load(this, e);
        } // TsmParallelepiped_Click

        private void TsmViewing_Click(object sender, EventArgs e) {
            LogForm logForm = new LogForm();
            logForm.ShowDialog();
            MainForm_Load(this, e);
        } // TsmViewing_Click

        private void TsmLists_Click(object sender, EventArgs e) {
            ListsForm listsForm = new ListsForm();
            listsForm.ShowDialog();
        } // TsmLists_Click
    }
}
