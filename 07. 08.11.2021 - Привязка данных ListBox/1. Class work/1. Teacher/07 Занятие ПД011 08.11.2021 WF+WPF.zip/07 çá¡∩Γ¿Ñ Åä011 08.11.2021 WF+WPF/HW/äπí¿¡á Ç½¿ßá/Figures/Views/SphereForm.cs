﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Figures.Models;

namespace Figures.Views
{
    public partial class SphereForm : Form
    {
        // модель для формы
        private Sphere _sphere;

        // представление для пустой строки результата
        private const string EmptyResult = "---''---";
        public SphereForm(){
            InitializeComponent();
            CbxMaterial.SelectedIndex = 0;

            // создать модель для работы формы
            _sphere = new Sphere();

            // начальное значение меток вывода результата
            LblAreaResult.Text = LblVolumeResult.Text = LblMassResult.Text = EmptyResult;
        }

        private void CbxMaterial_TextChanged(object sender, EventArgs e) {
            MaterialViewModel viewModel = Materials.Data[CbxMaterial.Text];

            // задать картинку материала
            PbxMaterial.Image = Image.FromFile(@"..\..\Resources\" + viewModel?.ImageFile);
            
            //отобразить плотность материала в TextBox
            NudDensity.Value = (decimal)viewModel.Density;
            
            // т.к. данные для расчета изменились, очищаем поле вывода результата
            LblAreaResult.Text = LblVolumeResult.Text = LblMassResult.Text = EmptyResult;
        } // CbxMaterial_TextChanged


        private void BtnClose_Click(object sender, EventArgs e) => Close();


        private void BtnCalc_Click(object sender, EventArgs e) {
            // получить текущие данные из полей ввода
            _sphere.Radius = (double)NudRadius.Value;
            _sphere.Density = (double)NudDensity.Value;

            // вычисление параметров, если это задано
            LblAreaResult.Text = ChbArea.Checked ? $"{_sphere.CalcArea():n3}" : "Расчет не требуется";
            LblVolumeResult.Text = ChbVolume.Checked ? $"{_sphere.CalcVolume():n3}" : "Расчет не требуется";
            LblMassResult.Text = ChbMass.Checked ? $"{_sphere.CalcMassa():n3}" : "Расчет не требуется";

            // записать операцию в файл
            File.AppendAllText(@"..\..\" + MainForm.FileName, $"│ {DateTime.Now:dd/MM/yyyy HH.mm.ss} │ {"Сфера",-20} " +
                $"│ {(ChbArea.Checked ? $"{_sphere.CalcArea(),11:n3}" : " ".PadRight(11))} " +
                $"│ {(ChbVolume.Checked ? $"{_sphere.CalcVolume(),11:n3}" : " ".PadRight(11))} " +
                $"│ {(ChbMass.Checked ? $"{_sphere.CalcMassa(),11:n3}" : " ".PadRight(11))} │" +
                $"\r\n", Encoding.UTF8);
        } // BtnCalc_Click


        private void Nud_ValueChanged(object sender, EventArgs e) {
            LblAreaResult.Text = LblVolumeResult.Text = LblMassResult.Text = EmptyResult;
        } // Nud_ValueChanged
    }
}
