﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Figures.Views
{
    public partial class LogForm : Form
    {
        public LogForm() {
            InitializeComponent();
            Lbl.Text = $"\"{MainForm.FileName}\"";
        } // LogForm

        private void LogForm_Load(object sender, EventArgs e) {
            TbxLog.Text =
                "┌─────────────────────┬──────────────────────┬─────────────────────────────────────────┐\r\n" +
                "│                     │                      │           Выполненные расчеты           │\r\n" +
                "│     Дата и время    │      Вид фигуры      ├─────────────┬─────────────┬─────────────┤\r\n" +
                "│                     │                      │   Площадь   │    Объем    │    Масса    │\r\n" +
                "├─────────────────────┼──────────────────────┼─────────────┼─────────────┼─────────────┤\r\n";

            TbxLog.Text += File.ReadAllText(@"..\..\" + MainForm.FileName, Encoding.UTF8);

            TbxLog.Text +=
                "└─────────────────────┴──────────────────────┴─────────────┴─────────────┴─────────────┘\r\n";

        } // LogForm_Load

        private void BtnQuit_Click(object sender, EventArgs e) => Close();

        private void BtnClear_Click(object sender, EventArgs e) {
            File.WriteAllText(@"..\..\" + MainForm.FileName, "", Encoding.UTF8);
            LogForm_Load(this, e);
        } // BtnClear_Click
    }
}
