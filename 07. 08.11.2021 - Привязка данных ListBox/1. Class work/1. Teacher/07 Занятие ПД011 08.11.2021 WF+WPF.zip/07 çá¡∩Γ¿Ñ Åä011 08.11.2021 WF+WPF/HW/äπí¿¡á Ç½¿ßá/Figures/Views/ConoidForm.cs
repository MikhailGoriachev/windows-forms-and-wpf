﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Figures.Models;

namespace Figures.Views
{
    public partial class ConoidForm : Form
    {
        // модель для формы
        private Conoid _conoid;

        // представление для пустой строки результата
        private const string EmptyResult = "---''---";
        public ConoidForm() {
            InitializeComponent();
            CbxMaterial.SelectedIndex = 0;

            // создать модель для работы формы
            _conoid = new Conoid();

            // начальное значение меток вывода результата
            LblAreaResult.Text = LblVolumeResult.Text = LblMassResult.Text = EmptyResult;
        }

        private void CbxMaterial_TextChanged(object sender, EventArgs e) {
            MaterialViewModel viewModel = Materials.Data[CbxMaterial.Text];

            // задать картинку материала
            PbxMaterial.Image = Image.FromFile(@"..\..\Resources\" + viewModel?.ImageFile);
            
            //отобразить плотность материала в TextBox
            NudDensity.Value = (decimal)viewModel.Density;
            // NudDensity.SelectionLength = 0;
            
            // т.к. данные для расчета изменились, очищаем поле вывода результата
            LblAreaResult.Text = LblVolumeResult.Text = LblMassResult.Text = EmptyResult;
        } // CbxMaterial_TextChanged

        private void BtnClose_Click(object sender, EventArgs e) => Close();

        private void BtnCalc_Click(object sender, EventArgs e) {
            try {
                // получить текущие данные из полей ввода
                _conoid.Radius1 = (double)NudRadius1.Value;
                _conoid.Radius2 = (double)NudRadius2.Value;
                _conoid.Height  = (double)NudHeight.Value;
                _conoid.Density = (double)NudDensity.Value;

                // проверка на уровне модели
                if (_conoid.Radius1 <= _conoid.Radius2)
                    throw new InvalidDataException($"Нижнее основание конуса меньше или равно верхнему");

                // вычисление параметров, если это задано
                LblAreaResult.Text = ChbArea.Checked ? $"{_conoid.CalcArea():n3}" : "Расчет не требуется";
                LblVolumeResult.Text = ChbVolume.Checked ? $"{_conoid.CalcVolume():n3}" : "Расчет не требуется";
                LblMassResult.Text = ChbMass.Checked ? $"{_conoid.CalcMassa():n3}" : "Расчет не требуется";

                // записать операцию
                File.AppendAllText(@"..\..\" + MainForm.FileName, $"│ {DateTime.Now:dd/MM/yyyy HH.mm.ss} │ {"Усеченный конуc",-20} " +
                    $"│ {(ChbArea.Checked ? $"{_conoid.CalcArea(),11:n3}" : " ".PadRight(11))} " +
                    $"│ {(ChbVolume.Checked ? $"{_conoid.CalcVolume(),11:n3}" : " ".PadRight(11))} " +
                    $"│ {(ChbMass.Checked ? $"{_conoid.CalcMassa(),11:n3}" : " ".PadRight(11))} │" +
                    $"\r\n", Encoding.UTF8);
            }
            catch (Exception ex)
            {
                // обработка ошибки уровня модели 

                // начальное значение меток вывода результата
                LblAreaResult.Text = LblVolumeResult.Text = LblMassResult.Text = EmptyResult;

                // сообщить об ошибке
                MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);

                // Передать фокус ввода на первое поле ввода
                NudRadius1.Focus();
                File.AppendAllText(@"..\..\" + MainForm.FileName, $"│ {DateTime.Now:dd/MM/yyyy HH.mm.ss} │ {"Усеченный конуc",-20} " +
                    $"│ {"Ошибка".PadLeft(22), -39} │\r\n", Encoding.UTF8);
            } // try-catch
        } // BtnCalc_Click

        private void Nud_ValueChanged(object sender, EventArgs e) {
            LblAreaResult.Text = LblVolumeResult.Text = LblMassResult.Text = EmptyResult;
        } // Nud_ValueChanged
    }
}
