﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Figures.Views
{
    public partial class ListsForm : Form
    {
        public ListsForm() {
            InitializeComponent();
        }

        private void BtnQuit_Click(object sender, EventArgs e) => Close();


         // перемещение выбранного элемента из первого лист-бокса во второй
        private void BtnMoveSelectedElemFirst_Click(object sender, EventArgs e) {
            if (LbxFirst.SelectedIndex < 0) return;
            LbxSecnd.Items.Add(LbxFirst.SelectedItem);
            LbxFirst.Items.RemoveAt(LbxFirst.SelectedIndex);
        } //BtnMoveSelectedElemFirst_Click


         // перемещение всех элементов из первого лист-бокса во второй
        private void BtnMoveSelectedElemSecnd_Click(object sender, EventArgs e) {
            if (LbxSecnd.SelectedIndex < 0) return;
            LbxFirst.Items.Add(LbxSecnd.SelectedItem);
            LbxSecnd.Items.RemoveAt(LbxSecnd.SelectedIndex);
        } // BtnMoveSelectedElemSecnd_Click


         // перемещение выбранного элемента из второго лист-бокса в первый
        private void BtnMoveAllElemsFirst_Click(object sender, EventArgs e) {
            LbxSecnd.Items.AddRange(LbxFirst.Items);
            LbxFirst.Items.Clear();
        }// BtnMoveAllElemsFirst_Click


         // перемещение всех элементов из второго лист-бокса в первый
        private void BtnMoveAllElemsSecnd_Click(object sender, EventArgs e){
            LbxFirst.Items.AddRange(LbxSecnd.Items);
            LbxSecnd.Items.Clear();
        } // BtnMoveAllElemsSecnd_Click


         // ввод названия города в строку ввода и добавление
         // города по кнопке в первый лист-бокс
        private void BtnAddToLbxFirst_Click(object sender, EventArgs e) {
            if(!String.IsNullOrEmpty(TbxAddToLbxFirst.Text))
                LbxFirst.Items.Add((object)TbxAddToLbxFirst.Text);
        } // BtnAddToLbxFirst_Click


         // выбор названия города из комбо-бокса и добавление
         // города по событию выбора во второй комбо-бокс 
        private void BtnAddToLbxSecnd_Click(object sender, EventArgs e){
            if (!String.IsNullOrEmpty(CbxAddToLbxSecnd.Text))
                LbxSecnd.Items.Add((object)CbxAddToLbxSecnd.Text);
        } // BtnAddToLbxSecnd_Click


        // очистка обоих лист-боксов
        private void BntClear_Click(object sender, EventArgs e) {
            LbxFirst.Items.Clear();
            LbxSecnd.Items.Clear();
        }// BntClear_Click
    }
}
