﻿
namespace Figures.Views
{
    partial class ListsForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.LbxFirst = new System.Windows.Forms.ListBox();
            this.LbxSecnd = new System.Windows.Forms.ListBox();
            this.LblListBox1 = new System.Windows.Forms.Label();
            this.LblListBox2 = new System.Windows.Forms.Label();
            this.BtnMoveSelectedElemFirst = new System.Windows.Forms.Button();
            this.BtnMoveAllElemsFirst = new System.Windows.Forms.Button();
            this.BtnMoveAllElemsSecnd = new System.Windows.Forms.Button();
            this.BtnMoveSelectedElemSecnd = new System.Windows.Forms.Button();
            this.GbxMove = new System.Windows.Forms.GroupBox();
            this.BtnAddToLbxSecnd = new System.Windows.Forms.Button();
            this.BtnAddToLbxFirst = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.TbxAddToLbxFirst = new System.Windows.Forms.TextBox();
            this.CbxAddToLbxSecnd = new System.Windows.Forms.ComboBox();
            this.BntClear = new System.Windows.Forms.Button();
            this.BtnQuit = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // LbxFirst
            // 
            this.LbxFirst.FormattingEnabled = true;
            this.LbxFirst.ItemHeight = 16;
            this.LbxFirst.Items.AddRange(new object[] {
            "Донецк",
            "Горловка",
            "Бахмут",
            "Славянск",
            "Енакиево",
            "Мариуполь",
            "Торез",
            "Краматорск",
            "Покровск",
            "Макеевка",
            "Торецк",
            "Шахтерск"});
            this.LbxFirst.Location = new System.Drawing.Point(32, 37);
            this.LbxFirst.Name = "LbxFirst";
            this.LbxFirst.Size = new System.Drawing.Size(173, 196);
            this.LbxFirst.TabIndex = 0;
            // 
            // LbxSecnd
            // 
            this.LbxSecnd.FormattingEnabled = true;
            this.LbxSecnd.ItemHeight = 16;
            this.LbxSecnd.Location = new System.Drawing.Point(251, 37);
            this.LbxSecnd.Name = "LbxSecnd";
            this.LbxSecnd.Size = new System.Drawing.Size(173, 196);
            this.LbxSecnd.TabIndex = 1;
            // 
            // LblListBox1
            // 
            this.LblListBox1.AutoSize = true;
            this.LblListBox1.Location = new System.Drawing.Point(69, 18);
            this.LblListBox1.Name = "LblListBox1";
            this.LblListBox1.Size = new System.Drawing.Size(98, 16);
            this.LblListBox1.TabIndex = 2;
            this.LblListBox1.Text = "Лист-бокс №1:";
            // 
            // LblListBox2
            // 
            this.LblListBox2.AutoSize = true;
            this.LblListBox2.Location = new System.Drawing.Point(288, 18);
            this.LblListBox2.Name = "LblListBox2";
            this.LblListBox2.Size = new System.Drawing.Size(98, 16);
            this.LblListBox2.TabIndex = 3;
            this.LblListBox2.Text = "Лист-бокс №2:";
            // 
            // BtnMoveSelectedElemFirst
            // 
            this.BtnMoveSelectedElemFirst.BackColor = System.Drawing.Color.MidnightBlue;
            this.BtnMoveSelectedElemFirst.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.BtnMoveSelectedElemFirst.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BtnMoveSelectedElemFirst.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.BtnMoveSelectedElemFirst.Location = new System.Drawing.Point(32, 273);
            this.BtnMoveSelectedElemFirst.Name = "BtnMoveSelectedElemFirst";
            this.BtnMoveSelectedElemFirst.Size = new System.Drawing.Size(392, 23);
            this.BtnMoveSelectedElemFirst.TabIndex = 4;
            this.BtnMoveSelectedElemFirst.Text = "Переместить выбранный элемент из первого лист-бокса во второй\r\n";
            this.BtnMoveSelectedElemFirst.UseVisualStyleBackColor = false;
            this.BtnMoveSelectedElemFirst.Click += new System.EventHandler(this.BtnMoveSelectedElemFirst_Click);
            // 
            // BtnMoveAllElemsFirst
            // 
            this.BtnMoveAllElemsFirst.BackColor = System.Drawing.Color.MidnightBlue;
            this.BtnMoveAllElemsFirst.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.BtnMoveAllElemsFirst.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BtnMoveAllElemsFirst.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.BtnMoveAllElemsFirst.Location = new System.Drawing.Point(32, 302);
            this.BtnMoveAllElemsFirst.Name = "BtnMoveAllElemsFirst";
            this.BtnMoveAllElemsFirst.Size = new System.Drawing.Size(392, 23);
            this.BtnMoveAllElemsFirst.TabIndex = 5;
            this.BtnMoveAllElemsFirst.Text = "Переместить все элементы из первого лист-бокса во второй\r\n";
            this.BtnMoveAllElemsFirst.UseVisualStyleBackColor = false;
            this.BtnMoveAllElemsFirst.Click += new System.EventHandler(this.BtnMoveAllElemsFirst_Click);
            // 
            // BtnMoveAllElemsSecnd
            // 
            this.BtnMoveAllElemsSecnd.BackColor = System.Drawing.Color.MidnightBlue;
            this.BtnMoveAllElemsSecnd.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.BtnMoveAllElemsSecnd.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BtnMoveAllElemsSecnd.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.BtnMoveAllElemsSecnd.Location = new System.Drawing.Point(32, 360);
            this.BtnMoveAllElemsSecnd.Name = "BtnMoveAllElemsSecnd";
            this.BtnMoveAllElemsSecnd.Size = new System.Drawing.Size(392, 23);
            this.BtnMoveAllElemsSecnd.TabIndex = 7;
            this.BtnMoveAllElemsSecnd.Text = "Переместить все элементы из второго лист-бокса в первый\r\n";
            this.BtnMoveAllElemsSecnd.UseVisualStyleBackColor = false;
            this.BtnMoveAllElemsSecnd.Click += new System.EventHandler(this.BtnMoveAllElemsSecnd_Click);
            // 
            // BtnMoveSelectedElemSecnd
            // 
            this.BtnMoveSelectedElemSecnd.BackColor = System.Drawing.Color.MidnightBlue;
            this.BtnMoveSelectedElemSecnd.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.BtnMoveSelectedElemSecnd.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BtnMoveSelectedElemSecnd.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.BtnMoveSelectedElemSecnd.Location = new System.Drawing.Point(32, 331);
            this.BtnMoveSelectedElemSecnd.Name = "BtnMoveSelectedElemSecnd";
            this.BtnMoveSelectedElemSecnd.Size = new System.Drawing.Size(392, 23);
            this.BtnMoveSelectedElemSecnd.TabIndex = 6;
            this.BtnMoveSelectedElemSecnd.Text = "Переместить выбранный элемент из второго лист-бокса в первый\r\n";
            this.BtnMoveSelectedElemSecnd.UseVisualStyleBackColor = false;
            this.BtnMoveSelectedElemSecnd.Click += new System.EventHandler(this.BtnMoveSelectedElemSecnd_Click);
            // 
            // GbxMove
            // 
            this.GbxMove.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.GbxMove.Location = new System.Drawing.Point(12, 252);
            this.GbxMove.Name = "GbxMove";
            this.GbxMove.Size = new System.Drawing.Size(438, 141);
            this.GbxMove.TabIndex = 8;
            this.GbxMove.TabStop = false;
            this.GbxMove.Text = " Перемещение элементов: ";
            // 
            // BtnAddToLbxSecnd
            // 
            this.BtnAddToLbxSecnd.BackColor = System.Drawing.Color.MidnightBlue;
            this.BtnAddToLbxSecnd.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.BtnAddToLbxSecnd.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BtnAddToLbxSecnd.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.BtnAddToLbxSecnd.Location = new System.Drawing.Point(239, 74);
            this.BtnAddToLbxSecnd.Name = "BtnAddToLbxSecnd";
            this.BtnAddToLbxSecnd.Size = new System.Drawing.Size(173, 23);
            this.BtnAddToLbxSecnd.TabIndex = 10;
            this.BtnAddToLbxSecnd.Text = "Добавить во второй лист-бокс";
            this.BtnAddToLbxSecnd.UseVisualStyleBackColor = false;
            this.BtnAddToLbxSecnd.Click += new System.EventHandler(this.BtnAddToLbxSecnd_Click);
            // 
            // BtnAddToLbxFirst
            // 
            this.BtnAddToLbxFirst.BackColor = System.Drawing.Color.MidnightBlue;
            this.BtnAddToLbxFirst.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.BtnAddToLbxFirst.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BtnAddToLbxFirst.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.BtnAddToLbxFirst.Location = new System.Drawing.Point(239, 36);
            this.BtnAddToLbxFirst.Name = "BtnAddToLbxFirst";
            this.BtnAddToLbxFirst.Size = new System.Drawing.Size(173, 23);
            this.BtnAddToLbxFirst.TabIndex = 9;
            this.BtnAddToLbxFirst.Text = "Добавить в первый лист-бокс";
            this.BtnAddToLbxFirst.UseVisualStyleBackColor = false;
            this.BtnAddToLbxFirst.Click += new System.EventHandler(this.BtnAddToLbxFirst_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.CbxAddToLbxSecnd);
            this.groupBox1.Controls.Add(this.TbxAddToLbxFirst);
            this.groupBox1.Controls.Add(this.BtnAddToLbxFirst);
            this.groupBox1.Controls.Add(this.BtnAddToLbxSecnd);
            this.groupBox1.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.groupBox1.Location = new System.Drawing.Point(12, 399);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(438, 121);
            this.groupBox1.TabIndex = 13;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Добавление элементов: ";
            // 
            // TbxAddToLbxFirst
            // 
            this.TbxAddToLbxFirst.Location = new System.Drawing.Point(20, 36);
            this.TbxAddToLbxFirst.Name = "TbxAddToLbxFirst";
            this.TbxAddToLbxFirst.Size = new System.Drawing.Size(189, 23);
            this.TbxAddToLbxFirst.TabIndex = 11;
            // 
            // CbxAddToLbxSecnd
            // 
            this.CbxAddToLbxSecnd.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CbxAddToLbxSecnd.FormattingEnabled = true;
            this.CbxAddToLbxSecnd.Items.AddRange(new object[] {
            "Докучаевск",
            "Харцызск",
            "Ясиноватая",
            "Новоазовск",
            "Волноваха",
            "Угледар",
            "Курахово",
            "Моспино"});
            this.CbxAddToLbxSecnd.Location = new System.Drawing.Point(20, 75);
            this.CbxAddToLbxSecnd.Name = "CbxAddToLbxSecnd";
            this.CbxAddToLbxSecnd.Size = new System.Drawing.Size(189, 24);
            this.CbxAddToLbxSecnd.TabIndex = 12;
            // 
            // BntClear
            // 
            this.BntClear.BackColor = System.Drawing.Color.MidnightBlue;
            this.BntClear.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.BntClear.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BntClear.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.BntClear.Location = new System.Drawing.Point(21, 535);
            this.BntClear.Name = "BntClear";
            this.BntClear.Size = new System.Drawing.Size(184, 23);
            this.BntClear.TabIndex = 13;
            this.BntClear.Text = "Очистить лист-боксы";
            this.BntClear.UseVisualStyleBackColor = false;
            this.BntClear.Click += new System.EventHandler(this.BntClear_Click);
            // 
            // BtnQuit
            // 
            this.BtnQuit.BackColor = System.Drawing.Color.MidnightBlue;
            this.BtnQuit.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.BtnQuit.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BtnQuit.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.BtnQuit.Location = new System.Drawing.Point(254, 535);
            this.BtnQuit.Name = "BtnQuit";
            this.BtnQuit.Size = new System.Drawing.Size(187, 23);
            this.BtnQuit.TabIndex = 14;
            this.BtnQuit.Text = "Выход";
            this.BtnQuit.UseVisualStyleBackColor = false;
            this.BtnQuit.Click += new System.EventHandler(this.BtnQuit_Click);
            // 
            // ListsForm
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.ClientSize = new System.Drawing.Size(462, 577);
            this.Controls.Add(this.BtnQuit);
            this.Controls.Add(this.BntClear);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.BtnMoveAllElemsSecnd);
            this.Controls.Add(this.BtnMoveSelectedElemSecnd);
            this.Controls.Add(this.BtnMoveAllElemsFirst);
            this.Controls.Add(this.BtnMoveSelectedElemFirst);
            this.Controls.Add(this.GbxMove);
            this.Controls.Add(this.LblListBox2);
            this.Controls.Add(this.LblListBox1);
            this.Controls.Add(this.LbxSecnd);
            this.Controls.Add(this.LbxFirst);
            this.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "ListsForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ListsForm";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox LbxFirst;
        private System.Windows.Forms.ListBox LbxSecnd;
        private System.Windows.Forms.Label LblListBox1;
        private System.Windows.Forms.Label LblListBox2;
        private System.Windows.Forms.Button BtnMoveSelectedElemFirst;
        private System.Windows.Forms.Button BtnMoveAllElemsFirst;
        private System.Windows.Forms.Button BtnMoveAllElemsSecnd;
        private System.Windows.Forms.Button BtnMoveSelectedElemSecnd;
        private System.Windows.Forms.GroupBox GbxMove;
        private System.Windows.Forms.Button BtnAddToLbxSecnd;
        private System.Windows.Forms.Button BtnAddToLbxFirst;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ComboBox CbxAddToLbxSecnd;
        private System.Windows.Forms.TextBox TbxAddToLbxFirst;
        private System.Windows.Forms.Button BntClear;
        private System.Windows.Forms.Button BtnQuit;
    }
}