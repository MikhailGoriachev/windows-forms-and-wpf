﻿
namespace Figures
{
    partial class MainForm
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.TmsHelp = new System.Windows.Forms.ToolStripMenuItem();
            this.TbxLog = new System.Windows.Forms.TextBox();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.TsmFile = new System.Windows.Forms.ToolStripMenuItem();
            this.TsmQuit = new System.Windows.Forms.ToolStripMenuItem();
            this.TsmFigures = new System.Windows.Forms.ToolStripMenuItem();
            this.TsmLog = new System.Windows.Forms.ToolStripMenuItem();
            this.TsmViewing = new System.Windows.Forms.ToolStripMenuItem();
            this.TsmClear = new System.Windows.Forms.ToolStripMenuItem();
            this.TsmHelp = new System.Windows.Forms.ToolStripMenuItem();
            this.TsmAbout = new System.Windows.Forms.ToolStripMenuItem();
            this.BtnQuit = new System.Windows.Forms.Button();
            this.BtnClear = new System.Windows.Forms.Button();
            this.TsmLists = new System.Windows.Forms.ToolStripMenuItem();
            this.TsmConoid = new System.Windows.Forms.ToolStripMenuItem();
            this.TsmSphere = new System.Windows.Forms.ToolStripMenuItem();
            this.TsmCylinder = new System.Windows.Forms.ToolStripMenuItem();
            this.TsmParallelepiped = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // TmsHelp
            // 
            this.TmsHelp.Name = "TmsHelp";
            this.TmsHelp.Size = new System.Drawing.Size(180, 22);
            this.TmsHelp.Text = "По&мощь";
            // 
            // TbxLog
            // 
            this.TbxLog.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.TbxLog.Font = new System.Drawing.Font("Consolas", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TbxLog.Location = new System.Drawing.Point(18, 45);
            this.TbxLog.Multiline = true;
            this.TbxLog.Name = "TbxLog";
            this.TbxLog.ReadOnly = true;
            this.TbxLog.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.TbxLog.Size = new System.Drawing.Size(668, 346);
            this.TbxLog.TabIndex = 0;
            this.TbxLog.TabStop = false;
            this.TbxLog.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // menuStrip1
            // 
            this.menuStrip1.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.TsmFile,
            this.TsmFigures,
            this.TsmLog,
            this.TsmHelp,
            this.TsmLists});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(704, 24);
            this.menuStrip1.TabIndex = 2;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // TsmFile
            // 
            this.TsmFile.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.TsmQuit});
            this.TsmFile.Name = "TsmFile";
            this.TsmFile.Size = new System.Drawing.Size(55, 20);
            this.TsmFile.Text = "&Файл";
            // 
            // TsmQuit
            // 
            this.TsmQuit.Name = "TsmQuit";
            this.TsmQuit.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.F4)));
            this.TsmQuit.Size = new System.Drawing.Size(171, 22);
            this.TsmQuit.Text = "&Выход";
            this.TsmQuit.Click += new System.EventHandler(this.Quit_Click);
            // 
            // TsmFigures
            // 
            this.TsmFigures.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.TsmConoid,
            this.TsmSphere,
            this.TsmCylinder,
            this.TsmParallelepiped});
            this.TsmFigures.Name = "TsmFigures";
            this.TsmFigures.Size = new System.Drawing.Size(128, 20);
            this.TsmFigures.Text = "&Объемные тела";
            // 
            // TsmLog
            // 
            this.TsmLog.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.TsmViewing,
            this.TsmClear});
            this.TsmLog.Name = "TsmLog";
            this.TsmLog.Size = new System.Drawing.Size(74, 20);
            this.TsmLog.Text = "&Журнал";
            // 
            // TsmViewing
            // 
            this.TsmViewing.Name = "TsmViewing";
            this.TsmViewing.Size = new System.Drawing.Size(180, 22);
            this.TsmViewing.Text = "П&росмотр";
            this.TsmViewing.Click += new System.EventHandler(this.TsmViewing_Click);
            // 
            // TsmClear
            // 
            this.TsmClear.Name = "TsmClear";
            this.TsmClear.Size = new System.Drawing.Size(180, 22);
            this.TsmClear.Text = "О&чистка";
            this.TsmClear.Click += new System.EventHandler(this.Clear_Click);
            // 
            // TsmHelp
            // 
            this.TsmHelp.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.TsmHelp.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.TsmAbout});
            this.TsmHelp.Name = "TsmHelp";
            this.TsmHelp.Size = new System.Drawing.Size(75, 20);
            this.TsmHelp.Text = "По&мощь";
            // 
            // TsmAbout
            // 
            this.TsmAbout.Name = "TsmAbout";
            this.TsmAbout.Size = new System.Drawing.Size(163, 22);
            this.TsmAbout.Text = "О про&грамме";
            this.TsmAbout.Click += new System.EventHandler(this.TsmAbout_Click);
            // 
            // BtnQuit
            // 
            this.BtnQuit.BackColor = System.Drawing.Color.MidnightBlue;
            this.BtnQuit.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.BtnQuit.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.BtnQuit.Location = new System.Drawing.Point(566, 410);
            this.BtnQuit.Name = "BtnQuit";
            this.BtnQuit.Size = new System.Drawing.Size(119, 26);
            this.BtnQuit.TabIndex = 3;
            this.BtnQuit.Text = "Выход";
            this.BtnQuit.UseVisualStyleBackColor = false;
            this.BtnQuit.Click += new System.EventHandler(this.Quit_Click);
            // 
            // BtnClear
            // 
            this.BtnClear.BackColor = System.Drawing.Color.MidnightBlue;
            this.BtnClear.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.BtnClear.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.BtnClear.Location = new System.Drawing.Point(427, 410);
            this.BtnClear.Name = "BtnClear";
            this.BtnClear.Size = new System.Drawing.Size(119, 26);
            this.BtnClear.TabIndex = 4;
            this.BtnClear.Text = "Очистить";
            this.BtnClear.UseVisualStyleBackColor = false;
            this.BtnClear.Click += new System.EventHandler(this.Clear_Click);
            // 
            // TsmLists
            // 
            this.TsmLists.Name = "TsmLists";
            this.TsmLists.Size = new System.Drawing.Size(65, 20);
            this.TsmLists.Text = "&Списки";
            this.TsmLists.Click += new System.EventHandler(this.TsmLists_Click);
            // 
            // TsmConoid
            // 
            this.TsmConoid.Image = global::Figures.Properties.Resources.Conoid;
            this.TsmConoid.Name = "TsmConoid";
            this.TsmConoid.Size = new System.Drawing.Size(193, 22);
            this.TsmConoid.Text = "&Усеченный конус";
            this.TsmConoid.Click += new System.EventHandler(this.TsmConoid_Click);
            // 
            // TsmSphere
            // 
            this.TsmSphere.Image = global::Figures.Properties.Resources.Sphere;
            this.TsmSphere.Name = "TsmSphere";
            this.TsmSphere.Size = new System.Drawing.Size(193, 22);
            this.TsmSphere.Text = "&Сфера";
            this.TsmSphere.Click += new System.EventHandler(this.TsmSphere_Click);
            // 
            // TsmCylinder
            // 
            this.TsmCylinder.Image = global::Figures.Properties.Resources.Cylinder;
            this.TsmCylinder.Name = "TsmCylinder";
            this.TsmCylinder.Size = new System.Drawing.Size(193, 22);
            this.TsmCylinder.Text = "&Цилиндр";
            this.TsmCylinder.Click += new System.EventHandler(this.TsmCylinder_Click);
            // 
            // TsmParallelepiped
            // 
            this.TsmParallelepiped.Image = global::Figures.Properties.Resources.Parallelepiped;
            this.TsmParallelepiped.Name = "TsmParallelepiped";
            this.TsmParallelepiped.Size = new System.Drawing.Size(193, 22);
            this.TsmParallelepiped.Text = "&Параллелепипед";
            this.TsmParallelepiped.Click += new System.EventHandler(this.TsmParallelepiped_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLight;
            this.ClientSize = new System.Drawing.Size(704, 450);
            this.Controls.Add(this.BtnClear);
            this.Controls.Add(this.BtnQuit);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.TbxLog);
            this.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.MaximizeBox = false;
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "MainForm";
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.ToolStripMenuItem TmsHelp;
        private System.Windows.Forms.TextBox TbxLog;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem TsmFile;
        private System.Windows.Forms.ToolStripMenuItem TsmQuit;
        private System.Windows.Forms.ToolStripMenuItem TsmFigures;
        private System.Windows.Forms.ToolStripMenuItem TsmConoid;
        private System.Windows.Forms.ToolStripMenuItem TsmSphere;
        private System.Windows.Forms.ToolStripMenuItem TsmCylinder;
        private System.Windows.Forms.ToolStripMenuItem TsmParallelepiped;
        private System.Windows.Forms.ToolStripMenuItem TsmLog;
        private System.Windows.Forms.ToolStripMenuItem TsmViewing;
        private System.Windows.Forms.ToolStripMenuItem TsmClear;
        private System.Windows.Forms.ToolStripMenuItem TsmHelp;
        private System.Windows.Forms.ToolStripMenuItem TsmAbout;
        private System.Windows.Forms.Button BtnQuit;
        private System.Windows.Forms.Button BtnClear;
        private System.Windows.Forms.ToolStripMenuItem TsmLists;
    }
}

