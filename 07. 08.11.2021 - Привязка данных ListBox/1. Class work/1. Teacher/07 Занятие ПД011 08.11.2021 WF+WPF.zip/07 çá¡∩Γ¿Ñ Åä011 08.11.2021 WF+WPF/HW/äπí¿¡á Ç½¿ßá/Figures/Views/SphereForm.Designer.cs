﻿
namespace Figures.Views
{
    partial class SphereForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.GrbResult = new System.Windows.Forms.GroupBox();
            this.LblMassResult = new System.Windows.Forms.Label();
            this.LblMass = new System.Windows.Forms.Label();
            this.LblVolumeResult = new System.Windows.Forms.Label();
            this.LblVolume = new System.Windows.Forms.Label();
            this.LblAreaResult = new System.Windows.Forms.Label();
            this.LblArea = new System.Windows.Forms.Label();
            this.BtnClose = new System.Windows.Forms.Button();
            this.BtnCalc = new System.Windows.Forms.Button();
            this.GrbCalcParams = new System.Windows.Forms.GroupBox();
            this.ChbMass = new System.Windows.Forms.CheckBox();
            this.ChbVolume = new System.Windows.Forms.CheckBox();
            this.ChbArea = new System.Windows.Forms.CheckBox();
            this.GbxMaterial = new System.Windows.Forms.GroupBox();
            this.CbxMaterial = new System.Windows.Forms.ComboBox();
            this.GbxInput = new System.Windows.Forms.GroupBox();
            this.NudDensity = new System.Windows.Forms.NumericUpDown();
            this.NudRadius = new System.Windows.Forms.NumericUpDown();
            this.LblDensity = new System.Windows.Forms.Label();
            this.LblRadius = new System.Windows.Forms.Label();
            this.PbxMaterial = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.GrbResult.SuspendLayout();
            this.GrbCalcParams.SuspendLayout();
            this.GbxMaterial.SuspendLayout();
            this.GbxInput.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.NudDensity)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NudRadius)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PbxMaterial)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // GrbResult
            // 
            this.GrbResult.Controls.Add(this.LblMassResult);
            this.GrbResult.Controls.Add(this.LblMass);
            this.GrbResult.Controls.Add(this.LblVolumeResult);
            this.GrbResult.Controls.Add(this.LblVolume);
            this.GrbResult.Controls.Add(this.LblAreaResult);
            this.GrbResult.Controls.Add(this.LblArea);
            this.GrbResult.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.GrbResult.Location = new System.Drawing.Point(14, 449);
            this.GrbResult.Name = "GrbResult";
            this.GrbResult.Size = new System.Drawing.Size(376, 136);
            this.GrbResult.TabIndex = 18;
            this.GrbResult.TabStop = false;
            this.GrbResult.Text = "  Результаты расчета: ";
            // 
            // LblMassResult
            // 
            this.LblMassResult.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblMassResult.Location = new System.Drawing.Point(104, 96);
            this.LblMassResult.Name = "LblMassResult";
            this.LblMassResult.Size = new System.Drawing.Size(186, 19);
            this.LblMassResult.TabIndex = 8;
            this.LblMassResult.Text = "Вычисленное значение параметра";
            // 
            // LblMass
            // 
            this.LblMass.AutoSize = true;
            this.LblMass.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblMass.Location = new System.Drawing.Point(16, 96);
            this.LblMass.Name = "LblMass";
            this.LblMass.Size = new System.Drawing.Size(57, 19);
            this.LblMass.TabIndex = 7;
            this.LblMass.Text = "Масса:";
            // 
            // LblVolumeResult
            // 
            this.LblVolumeResult.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblVolumeResult.Location = new System.Drawing.Point(104, 64);
            this.LblVolumeResult.Name = "LblVolumeResult";
            this.LblVolumeResult.Size = new System.Drawing.Size(186, 19);
            this.LblVolumeResult.TabIndex = 6;
            this.LblVolumeResult.Text = "Вычисленное значение параметра";
            // 
            // LblVolume
            // 
            this.LblVolume.AutoSize = true;
            this.LblVolume.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblVolume.Location = new System.Drawing.Point(16, 64);
            this.LblVolume.Name = "LblVolume";
            this.LblVolume.Size = new System.Drawing.Size(63, 19);
            this.LblVolume.TabIndex = 5;
            this.LblVolume.Text = "Объем:";
            // 
            // LblAreaResult
            // 
            this.LblAreaResult.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblAreaResult.Location = new System.Drawing.Point(104, 32);
            this.LblAreaResult.Name = "LblAreaResult";
            this.LblAreaResult.Size = new System.Drawing.Size(186, 19);
            this.LblAreaResult.TabIndex = 4;
            this.LblAreaResult.Text = "Вычисленное значение параметра";
            // 
            // LblArea
            // 
            this.LblArea.AutoSize = true;
            this.LblArea.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblArea.Location = new System.Drawing.Point(16, 32);
            this.LblArea.Name = "LblArea";
            this.LblArea.Size = new System.Drawing.Size(82, 19);
            this.LblArea.TabIndex = 3;
            this.LblArea.Text = "Площадь:";
            // 
            // BtnClose
            // 
            this.BtnClose.BackColor = System.Drawing.Color.MidnightBlue;
            this.BtnClose.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.BtnClose.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.BtnClose.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BtnClose.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.BtnClose.Location = new System.Drawing.Point(404, 539);
            this.BtnClose.Name = "BtnClose";
            this.BtnClose.Size = new System.Drawing.Size(139, 40);
            this.BtnClose.TabIndex = 17;
            this.BtnClose.Text = "Закрыть";
            this.BtnClose.UseVisualStyleBackColor = true;
            this.BtnClose.Click += new System.EventHandler(this.BtnClose_Click);
            // 
            // BtnCalc
            // 
            this.BtnCalc.BackColor = System.Drawing.Color.MidnightBlue;
            this.BtnCalc.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.BtnCalc.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BtnCalc.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.BtnCalc.Location = new System.Drawing.Point(404, 467);
            this.BtnCalc.Name = "BtnCalc";
            this.BtnCalc.Size = new System.Drawing.Size(139, 40);
            this.BtnCalc.TabIndex = 16;
            this.BtnCalc.Text = "Вычислить";
            this.BtnCalc.UseVisualStyleBackColor = false;
            this.BtnCalc.Click += new System.EventHandler(this.BtnCalc_Click);
            // 
            // GrbCalcParams
            // 
            this.GrbCalcParams.Controls.Add(this.ChbMass);
            this.GrbCalcParams.Controls.Add(this.ChbVolume);
            this.GrbCalcParams.Controls.Add(this.ChbArea);
            this.GrbCalcParams.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.GrbCalcParams.Location = new System.Drawing.Point(282, 276);
            this.GrbCalcParams.Name = "GrbCalcParams";
            this.GrbCalcParams.Size = new System.Drawing.Size(240, 161);
            this.GrbCalcParams.TabIndex = 15;
            this.GrbCalcParams.TabStop = false;
            this.GrbCalcParams.Text = "  Что рассчитывать: ";
            // 
            // ChbMass
            // 
            this.ChbMass.AutoSize = true;
            this.ChbMass.Checked = true;
            this.ChbMass.CheckState = System.Windows.Forms.CheckState.Checked;
            this.ChbMass.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ChbMass.Location = new System.Drawing.Point(24, 118);
            this.ChbMass.Name = "ChbMass";
            this.ChbMass.Size = new System.Drawing.Size(176, 20);
            this.ChbMass.TabIndex = 5;
            this.ChbMass.Text = "Масса усеченного конуса";
            this.ChbMass.UseVisualStyleBackColor = true;
            this.ChbMass.CheckedChanged += new System.EventHandler(this.Nud_ValueChanged);
            // 
            // ChbVolume
            // 
            this.ChbVolume.AutoSize = true;
            this.ChbVolume.Checked = true;
            this.ChbVolume.CheckState = System.Windows.Forms.CheckState.Checked;
            this.ChbVolume.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ChbVolume.Location = new System.Drawing.Point(24, 75);
            this.ChbVolume.Name = "ChbVolume";
            this.ChbVolume.Size = new System.Drawing.Size(178, 20);
            this.ChbVolume.TabIndex = 4;
            this.ChbVolume.Text = "Объем усеченного конуса";
            this.ChbVolume.UseVisualStyleBackColor = true;
            this.ChbVolume.CheckedChanged += new System.EventHandler(this.Nud_ValueChanged);
            // 
            // ChbArea
            // 
            this.ChbArea.AutoSize = true;
            this.ChbArea.Checked = true;
            this.ChbArea.CheckState = System.Windows.Forms.CheckState.Checked;
            this.ChbArea.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ChbArea.Location = new System.Drawing.Point(24, 32);
            this.ChbArea.Name = "ChbArea";
            this.ChbArea.Size = new System.Drawing.Size(159, 20);
            this.ChbArea.TabIndex = 3;
            this.ChbArea.Text = "Площадь поверхности";
            this.ChbArea.UseVisualStyleBackColor = true;
            this.ChbArea.CheckedChanged += new System.EventHandler(this.Nud_ValueChanged);
            // 
            // GbxMaterial
            // 
            this.GbxMaterial.Controls.Add(this.PbxMaterial);
            this.GbxMaterial.Controls.Add(this.CbxMaterial);
            this.GbxMaterial.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.GbxMaterial.Location = new System.Drawing.Point(14, 158);
            this.GbxMaterial.Name = "GbxMaterial";
            this.GbxMaterial.Size = new System.Drawing.Size(243, 279);
            this.GbxMaterial.TabIndex = 13;
            this.GbxMaterial.TabStop = false;
            this.GbxMaterial.Text = " Выбор материала: ";
            // 
            // CbxMaterial
            // 
            this.CbxMaterial.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.CbxMaterial.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.CbxMaterial.DisplayMember = "нержавеющая сталь";
            this.CbxMaterial.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CbxMaterial.FormattingEnabled = true;
            this.CbxMaterial.Items.AddRange(new object[] {
            "нержавеющая сталь",
            "медь",
            "водяной лед",
            "гранит"});
            this.CbxMaterial.Location = new System.Drawing.Point(26, 31);
            this.CbxMaterial.Name = "CbxMaterial";
            this.CbxMaterial.Size = new System.Drawing.Size(193, 24);
            this.CbxMaterial.TabIndex = 2;
            this.CbxMaterial.TextChanged += new System.EventHandler(this.CbxMaterial_TextChanged);
            // 
            // GbxInput
            // 
            this.GbxInput.Controls.Add(this.NudDensity);
            this.GbxInput.Controls.Add(this.NudRadius);
            this.GbxInput.Controls.Add(this.LblDensity);
            this.GbxInput.Controls.Add(this.LblRadius);
            this.GbxInput.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.GbxInput.Location = new System.Drawing.Point(14, 16);
            this.GbxInput.Name = "GbxInput";
            this.GbxInput.Size = new System.Drawing.Size(284, 136);
            this.GbxInput.TabIndex = 12;
            this.GbxInput.TabStop = false;
            this.GbxInput.Text = " Параметры: ";
            // 
            // NudDensity
            // 
            this.NudDensity.DecimalPlaces = 3;
            this.NudDensity.Increment = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.NudDensity.Location = new System.Drawing.Point(153, 78);
            this.NudDensity.Maximum = new decimal(new int[] {
            1874919424,
            2328306,
            0,
            0});
            this.NudDensity.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            196608});
            this.NudDensity.Name = "NudDensity";
            this.NudDensity.ReadOnly = true;
            this.NudDensity.Size = new System.Drawing.Size(125, 23);
            this.NudDensity.TabIndex = 4;
            this.NudDensity.TabStop = false;
            this.NudDensity.ThousandsSeparator = true;
            this.NudDensity.Value = new decimal(new int[] {
            7850,
            0,
            0,
            0});
            // 
            // NudRadius
            // 
            this.NudRadius.DecimalPlaces = 3;
            this.NudRadius.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.NudRadius.Location = new System.Drawing.Point(153, 44);
            this.NudRadius.Maximum = new decimal(new int[] {
            1874919424,
            2328306,
            0,
            0});
            this.NudRadius.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            196608});
            this.NudRadius.Name = "NudRadius";
            this.NudRadius.Size = new System.Drawing.Size(125, 23);
            this.NudRadius.TabIndex = 0;
            this.NudRadius.ThousandsSeparator = true;
            this.NudRadius.Value = new decimal(new int[] {
            15,
            0,
            0,
            65536});
            this.NudRadius.ValueChanged += new System.EventHandler(this.Nud_ValueChanged);
            // 
            // LblDensity
            // 
            this.LblDensity.AutoSize = true;
            this.LblDensity.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblDensity.Location = new System.Drawing.Point(6, 81);
            this.LblDensity.Name = "LblDensity";
            this.LblDensity.Size = new System.Drawing.Size(141, 16);
            this.LblDensity.TabIndex = 7;
            this.LblDensity.Text = "Плотность материала:";
            // 
            // LblRadius
            // 
            this.LblRadius.AutoSize = true;
            this.LblRadius.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblRadius.Location = new System.Drawing.Point(6, 47);
            this.LblRadius.Name = "LblRadius";
            this.LblRadius.Size = new System.Drawing.Size(53, 16);
            this.LblRadius.TabIndex = 1;
            this.LblRadius.Text = "Радиус:";
            // 
            // PbxMaterial
            // 
            this.PbxMaterial.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.PbxMaterial.Image = global::Figures.Properties.Resources.steel;
            this.PbxMaterial.Location = new System.Drawing.Point(26, 73);
            this.PbxMaterial.Name = "PbxMaterial";
            this.PbxMaterial.Size = new System.Drawing.Size(193, 186);
            this.PbxMaterial.TabIndex = 3;
            this.PbxMaterial.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Figures.Properties.Resources.Picture_Sphere;
            this.pictureBox1.Location = new System.Drawing.Point(305, 24);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(259, 232);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 14;
            this.pictureBox1.TabStop = false;
            // 
            // SphereForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(553, 600);
            this.Controls.Add(this.GrbResult);
            this.Controls.Add(this.BtnClose);
            this.Controls.Add(this.BtnCalc);
            this.Controls.Add(this.GrbCalcParams);
            this.Controls.Add(this.GbxMaterial);
            this.Controls.Add(this.GbxInput);
            this.Controls.Add(this.pictureBox1);
            this.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.MaximizeBox = false;
            this.Name = "SphereForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Сфера";
            this.GrbResult.ResumeLayout(false);
            this.GrbResult.PerformLayout();
            this.GrbCalcParams.ResumeLayout(false);
            this.GrbCalcParams.PerformLayout();
            this.GbxMaterial.ResumeLayout(false);
            this.GbxInput.ResumeLayout(false);
            this.GbxInput.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.NudDensity)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NudRadius)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PbxMaterial)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox GrbResult;
        private System.Windows.Forms.Label LblMassResult;
        private System.Windows.Forms.Label LblMass;
        private System.Windows.Forms.Label LblVolumeResult;
        private System.Windows.Forms.Label LblVolume;
        private System.Windows.Forms.Label LblAreaResult;
        private System.Windows.Forms.Label LblArea;
        private System.Windows.Forms.Button BtnClose;
        private System.Windows.Forms.Button BtnCalc;
        private System.Windows.Forms.GroupBox GrbCalcParams;
        private System.Windows.Forms.CheckBox ChbMass;
        private System.Windows.Forms.CheckBox ChbVolume;
        private System.Windows.Forms.CheckBox ChbArea;
        private System.Windows.Forms.GroupBox GbxMaterial;
        private System.Windows.Forms.PictureBox PbxMaterial;
        private System.Windows.Forms.ComboBox CbxMaterial;
        private System.Windows.Forms.GroupBox GbxInput;
        private System.Windows.Forms.NumericUpDown NudDensity;
        private System.Windows.Forms.NumericUpDown NudRadius;
        private System.Windows.Forms.Label LblDensity;
        private System.Windows.Forms.Label LblRadius;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}