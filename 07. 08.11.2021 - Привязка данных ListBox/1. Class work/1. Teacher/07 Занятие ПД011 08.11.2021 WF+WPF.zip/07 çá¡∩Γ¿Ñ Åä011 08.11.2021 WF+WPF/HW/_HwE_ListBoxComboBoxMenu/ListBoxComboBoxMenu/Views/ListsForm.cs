﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/*
 * Задача 2.
 * В приложение задачи 1 добавьте пункт меню Списки по которому выполните
 * переход на отдельную форму, на которой разместите два лист-бокса. В одном
 * разместите не менее 12 строк – названия городов, второй оставьте пустым.
 * По командным кнопкам выполните:
 *     • перемещение выбранного элемента из первого лист-бокса во второй
 *     • перемещение всех элементов из первого лист-бокса во второй
 *     • перемещение выбранного элемента из второго лист-бокса в первый
 *     • перемещение всех элементов из второго лист-бокса в первый
 *     • очистка обоих лист-боксов
 *     • ввод названия города в строку ввода и добавление города по кнопке
 *       в первый лист-бокс
 *     • выбор названия города из комбо-бокса и добавление города по событию
 *       выбора во второй лист-бокс 
 */
namespace ListBoxComboBoxMenu.Views
{
    public partial class ListsForm : Form
    {
        public ListsForm () {
            InitializeComponent();
        } // ListsForms


        // Сформировать списки в исходном состоянии
        private void Generate_Command(object sender, EventArgs e) {
            // очистка списков, воспользуемся уже готовой командой
            ClearAllLists_Command(sender, e);

            // записать начальный список в коллекцию городов первого списка
            LbxFirst.Items.AddRange(new object[] {
                "Донецк", "Макеевка", "Ясиноватая", "Харцызск", "Снежное",
                "Иловайск",  "Моспино", "Старобешево", "Горловка", "Енакиево",
                "Новоазовск", "Дебальцево", "Луганск", "Краснодон", "Алчевск"});
        } // Generate_Command


        // перемещение выбранного элемента из первого лист-бокса во второй
        private void MoveItemToSecond(object sender, EventArgs e) =>
            MoveListBoxItem(LbxFirst, LbxSecond);

        // перемещение выбранного элемента из второго лист-бокса в первый
        private void MoveItemToFirst (object sender, EventArgs e) =>
            MoveListBoxItem(LbxSecond, LbxFirst);

        // перемещение выбранного элемента из лист-бокса src в лист-бокс dst
        private void MoveListBoxItem(ListBox src, ListBox dst) {
            
            // нет выбранного элемента - молча уходим
            if (src.SelectedIndex < 0) return;

            // запись элемента в лист-бокс dst
            int selectedIndex = src.SelectedIndex;
            dst.Items.Add(src.Items[selectedIndex]);

            // удаление выбранного элемента из лист-бокса src
            src.Items.RemoveAt(selectedIndex);
            
            // TODO: исправить падение приложения при выборе последнего элемента
            src.SetSelected(selectedIndex, true);
        } // MoveListBoxItem


        // перемещение всех элементов из первого лист-бокса во второй
        private void MoveAllToSecond_Command(object sender, EventArgs e) =>
            MoveListBoxeItems(LbxFirst, LbxSecond);

        // перемещение всех элементов из второго лист-бокса в первый
        private void MoveAllToFirst_Command(object sender, EventArgs e) =>
            MoveListBoxeItems(LbxSecond, LbxFirst);

        // код перемещения всех данных из лист-бокса src в лист-бокс dst
        private void MoveListBoxeItems(ListBox src, ListBox dst) {
            // переместить все элементы в лист-бокс приемник
            dst.Items.AddRange(src.Items);

            // очистить лист-бокс источник
            src.Items.Clear();
        } // MoveListBoxeItems


        // Очистка всех ListBox на форме
        private void ClearAllLists_Command (object sender, EventArgs e) {
            LbxFirst.Items.Clear();
            LbxSecond.Items.Clear();
        } // ClearAllLists_Command


        // ввод названия города в строку ввода и добавление города по кнопке
        // в первый лист-бокс - 
        private void AddCity_Command(object sender, EventArgs e) {
            // если ничего не ввели в строку ввода - молча уходим
            if (string.IsNullOrWhiteSpace(TxbCity.Text)) return;

            // добавить название города в первый лист-бокс, очистка строки ввода
            LbxFirst.Items.Add(TxbCity.Text);
            TxbCity.Text = "";
        } // AddCity_Command


        // Обработчик события выбора города в комбобоксе, запись выбранного города
        // во второй лист-бокс
        private void CbxCities_SelectedIndexChanged (object sender, EventArgs e) {
            if (CbxCities.SelectedIndex < 0)
                return;

            // получить выбранный элемент комбо-бокса
            string item = (string)CbxCities.Items[CbxCities.SelectedIndex];

            // добавить выбранный элемент в лист-бокс
            LbxSecond.Items.Add(item);
        } // CbxCities_SelectedIndexChanged

    } // class ListsForm
}
