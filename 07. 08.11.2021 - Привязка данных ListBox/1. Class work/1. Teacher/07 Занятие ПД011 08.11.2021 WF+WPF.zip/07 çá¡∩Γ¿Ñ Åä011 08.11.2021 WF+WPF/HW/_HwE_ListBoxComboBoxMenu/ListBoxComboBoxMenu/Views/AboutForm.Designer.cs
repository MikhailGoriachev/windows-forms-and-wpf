﻿namespace ListBoxComboBoxMenu.Views
{
    partial class AboutForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AboutForm));
            this.BtnOK = new System.Windows.Forms.Button();
            this.TmrAbout = new System.Windows.Forms.Timer(this.components);
            this.LblAbout1 = new System.Windows.Forms.Label();
            this.LblAbout2 = new System.Windows.Forms.Label();
            this.PcbParallelepiped = new System.Windows.Forms.PictureBox();
            this.PcbSphere = new System.Windows.Forms.PictureBox();
            this.PcbCylinder = new System.Windows.Forms.PictureBox();
            this.PcbConoid = new System.Windows.Forms.PictureBox();
            this.LblDeveloper = new System.Windows.Forms.Label();
            this.LblTitle = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.PcbParallelepiped)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PcbSphere)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PcbCylinder)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PcbConoid)).BeginInit();
            this.SuspendLayout();
            // 
            // BtnOK
            // 
            this.BtnOK.BackColor = System.Drawing.Color.MidnightBlue;
            this.BtnOK.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.BtnOK.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.BtnOK.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BtnOK.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.BtnOK.Location = new System.Drawing.Point(536, 416);
            this.BtnOK.Name = "BtnOK";
            this.BtnOK.Size = new System.Drawing.Size(232, 40);
            this.BtnOK.TabIndex = 2;
            this.BtnOK.Text = "OK";
            this.BtnOK.UseVisualStyleBackColor = true;
            // 
            // TmrAbout
            // 
            this.TmrAbout.Interval = 10000;
            this.TmrAbout.Tick += new System.EventHandler(this.TmrAbout_Tick);
            // 
            // LblAbout1
            // 
            this.LblAbout1.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblAbout1.Location = new System.Drawing.Point(24, 232);
            this.LblAbout1.Name = "LblAbout1";
            this.LblAbout1.Size = new System.Drawing.Size(360, 160);
            this.LblAbout1.TabIndex = 12;
            this.LblAbout1.Text = "Текст1";
            this.LblAbout1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // LblAbout2
            // 
            this.LblAbout2.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblAbout2.Location = new System.Drawing.Point(412, 232);
            this.LblAbout2.Name = "LblAbout2";
            this.LblAbout2.Size = new System.Drawing.Size(364, 160);
            this.LblAbout2.TabIndex = 13;
            this.LblAbout2.Text = "Текст2";
            this.LblAbout2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // PcbParallelepiped
            // 
            this.PcbParallelepiped.Image = global::ListBoxComboBoxMenu.Properties.Resources.parallelepiped;
            this.PcbParallelepiped.Location = new System.Drawing.Point(606, 64);
            this.PcbParallelepiped.Name = "PcbParallelepiped";
            this.PcbParallelepiped.Size = new System.Drawing.Size(168, 136);
            this.PcbParallelepiped.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.PcbParallelepiped.TabIndex = 11;
            this.PcbParallelepiped.TabStop = false;
            // 
            // PcbSphere
            // 
            this.PcbSphere.Image = global::ListBoxComboBoxMenu.Properties.Resources.sphere;
            this.PcbSphere.Location = new System.Drawing.Point(412, 64);
            this.PcbSphere.Name = "PcbSphere";
            this.PcbSphere.Size = new System.Drawing.Size(168, 136);
            this.PcbSphere.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.PcbSphere.TabIndex = 10;
            this.PcbSphere.TabStop = false;
            // 
            // PcbCylinder
            // 
            this.PcbCylinder.Image = global::ListBoxComboBoxMenu.Properties.Resources.cylinder;
            this.PcbCylinder.Location = new System.Drawing.Point(218, 64);
            this.PcbCylinder.Name = "PcbCylinder";
            this.PcbCylinder.Size = new System.Drawing.Size(168, 136);
            this.PcbCylinder.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.PcbCylinder.TabIndex = 9;
            this.PcbCylinder.TabStop = false;
            // 
            // PcbConoid
            // 
            this.PcbConoid.Image = global::ListBoxComboBoxMenu.Properties.Resources.conoid;
            this.PcbConoid.Location = new System.Drawing.Point(24, 64);
            this.PcbConoid.Name = "PcbConoid";
            this.PcbConoid.Size = new System.Drawing.Size(168, 136);
            this.PcbConoid.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.PcbConoid.TabIndex = 8;
            this.PcbConoid.TabStop = false;
            // 
            // LblDeveloper
            // 
            this.LblDeveloper.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblDeveloper.Location = new System.Drawing.Point(24, 409);
            this.LblDeveloper.Name = "LblDeveloper";
            this.LblDeveloper.Size = new System.Drawing.Size(504, 55);
            this.LblDeveloper.TabIndex = 14;
            this.LblDeveloper.Text = "Студент Программер, группа ПД011, КА Шаг, Донецк, 2021";
            this.LblDeveloper.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // LblTitle
            // 
            this.LblTitle.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblTitle.Location = new System.Drawing.Point(24, 0);
            this.LblTitle.Name = "LblTitle";
            this.LblTitle.Size = new System.Drawing.Size(752, 55);
            this.LblTitle.TabIndex = 15;
            this.LblTitle.Text = "Задание на 28.10.2021- элементы управления, применение моделей данных";
            this.LblTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // AboutForm
            // 
            this.AcceptButton = this.BtnOK;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 481);
            this.Controls.Add(this.LblTitle);
            this.Controls.Add(this.LblDeveloper);
            this.Controls.Add(this.LblAbout2);
            this.Controls.Add(this.LblAbout1);
            this.Controls.Add(this.PcbParallelepiped);
            this.Controls.Add(this.PcbSphere);
            this.Controls.Add(this.PcbCylinder);
            this.Controls.Add(this.PcbConoid);
            this.Controls.Add(this.BtnOK);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(816, 520);
            this.MinimizeBox = false;
            this.MinimumSize = new System.Drawing.Size(816, 520);
            this.Name = "AboutForm";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "О программе";
            this.Load += new System.EventHandler(this.AboutForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.PcbParallelepiped)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PcbSphere)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PcbCylinder)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PcbConoid)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button BtnOK;
        private System.Windows.Forms.Timer TmrAbout;
        private System.Windows.Forms.PictureBox PcbConoid;
        private System.Windows.Forms.PictureBox PcbCylinder;
        private System.Windows.Forms.PictureBox PcbSphere;
        private System.Windows.Forms.PictureBox PcbParallelepiped;
        private System.Windows.Forms.Label LblAbout1;
        private System.Windows.Forms.Label LblAbout2;
        private System.Windows.Forms.Label LblDeveloper;
        private System.Windows.Forms.Label LblTitle;
    }
}