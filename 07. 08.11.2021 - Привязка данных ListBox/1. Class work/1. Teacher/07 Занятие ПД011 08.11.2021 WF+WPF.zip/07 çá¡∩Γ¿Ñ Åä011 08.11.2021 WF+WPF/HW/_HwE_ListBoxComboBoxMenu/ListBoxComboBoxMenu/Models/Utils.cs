﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ListBoxComboBoxMenu.Models
{
    static class Utils
    {

        // выбранный в комбо-бокс текст преобразуем в ключ материала
        public static string ToMaterial(string text) {
            string material;
            switch (text) {
                case "нержавейка":
                    material = "steel";
                    break;

                case "медь":
                    material = "copper";
                    break;

                case "водяной лед":
                    material = "water_ice";
                    break;

                case "гранит":
                    material = "granite";
                    break;

                default:
                    material = "steel";
                    break;
            }; // switch

            return material;
        } // ToMaterial
    } // class Utils
}
