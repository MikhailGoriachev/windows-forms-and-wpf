﻿
namespace ListBoxComboBoxMenu.Views
{
    partial class MainForm
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose (bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent () {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.MnuMain = new System.Windows.Forms.MenuStrip();
            this.MniFile = new System.Windows.Forms.ToolStripMenuItem();
            this.MniQuit = new System.Windows.Forms.ToolStripMenuItem();
            this.MniVolumetric = new System.Windows.Forms.ToolStripMenuItem();
            this.MniVolumetricConoid = new System.Windows.Forms.ToolStripMenuItem();
            this.MniVolumetricSphere = new System.Windows.Forms.ToolStripMenuItem();
            this.MniVolumetricCylinder = new System.Windows.Forms.ToolStripMenuItem();
            this.MniVolumetricSep1 = new System.Windows.Forms.ToolStripSeparator();
            this.MniVolumetricBrick = new System.Windows.Forms.ToolStripMenuItem();
            this.mniLog = new System.Windows.Forms.ToolStripMenuItem();
            this.MniLogView = new System.Windows.Forms.ToolStripMenuItem();
            this.MniLogClear = new System.Windows.Forms.ToolStripMenuItem();
            this.MniHelp = new System.Windows.Forms.ToolStripMenuItem();
            this.MniHelpAbout = new System.Windows.Forms.ToolStripMenuItem();
            this.TxbLog = new System.Windows.Forms.TextBox();
            this.MniLists = new System.Windows.Forms.ToolStripMenuItem();
            this.MnuMain.SuspendLayout();
            this.SuspendLayout();
            // 
            // MnuMain
            // 
            this.MnuMain.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.MnuMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniFile,
            this.MniVolumetric,
            this.MniLists,
            this.mniLog,
            this.MniHelp});
            this.MnuMain.Location = new System.Drawing.Point(0, 0);
            this.MnuMain.Name = "MnuMain";
            this.MnuMain.Size = new System.Drawing.Size(1084, 28);
            this.MnuMain.TabIndex = 0;
            this.MnuMain.Text = "menuStrip1";
            // 
            // MniFile
            // 
            this.MniFile.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniQuit});
            this.MniFile.Name = "MniFile";
            this.MniFile.Size = new System.Drawing.Size(57, 24);
            this.MniFile.Text = "&Файл";
            // 
            // MniQuit
            // 
            this.MniQuit.Name = "MniQuit";
            this.MniQuit.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.F4)));
            this.MniQuit.Size = new System.Drawing.Size(180, 24);
            this.MniQuit.Text = "&Выход";
            this.MniQuit.Click += new System.EventHandler(this.Exit_Command);
            // 
            // MniVolumetric
            // 
            this.MniVolumetric.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniVolumetricConoid,
            this.MniVolumetricSphere,
            this.MniVolumetricCylinder,
            this.MniVolumetricSep1,
            this.MniVolumetricBrick});
            this.MniVolumetric.Name = "MniVolumetric";
            this.MniVolumetric.Size = new System.Drawing.Size(131, 24);
            this.MniVolumetric.Text = "&Объемные тела";
            // 
            // MniVolumetricConoid
            // 
            this.MniVolumetricConoid.Name = "MniVolumetricConoid";
            this.MniVolumetricConoid.Size = new System.Drawing.Size(314, 24);
            this.MniVolumetricConoid.Text = "Усеченный конус";
            this.MniVolumetricConoid.Click += new System.EventHandler(this.Coniod_Command);
            // 
            // MniVolumetricSphere
            // 
            this.MniVolumetricSphere.Name = "MniVolumetricSphere";
            this.MniVolumetricSphere.Size = new System.Drawing.Size(314, 24);
            this.MniVolumetricSphere.Text = "Сфера";
            this.MniVolumetricSphere.Click += new System.EventHandler(this.Sphere_Command);
            // 
            // MniVolumetricCylinder
            // 
            this.MniVolumetricCylinder.Name = "MniVolumetricCylinder";
            this.MniVolumetricCylinder.Size = new System.Drawing.Size(314, 24);
            this.MniVolumetricCylinder.Text = "Цилиндр";
            this.MniVolumetricCylinder.Click += new System.EventHandler(this.Cylinder_Command);
            // 
            // MniVolumetricSep1
            // 
            this.MniVolumetricSep1.Name = "MniVolumetricSep1";
            this.MniVolumetricSep1.Size = new System.Drawing.Size(311, 6);
            // 
            // MniVolumetricBrick
            // 
            this.MniVolumetricBrick.Name = "MniVolumetricBrick";
            this.MniVolumetricBrick.Size = new System.Drawing.Size(314, 24);
            this.MniVolumetricBrick.Text = "Прямоугольный параллелепипед";
            this.MniVolumetricBrick.Click += new System.EventHandler(this.Parallelepiped_Command);
            // 
            // mniLog
            // 
            this.mniLog.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniLogView,
            this.MniLogClear});
            this.mniLog.Name = "mniLog";
            this.mniLog.Size = new System.Drawing.Size(75, 24);
            this.mniLog.Text = "&Журнал";
            this.mniLog.Click += new System.EventHandler(this.LogView_Command);
            // 
            // MniLogView
            // 
            this.MniLogView.Name = "MniLogView";
            this.MniLogView.Size = new System.Drawing.Size(180, 24);
            this.MniLogView.Text = "Просмотр...";
            // 
            // MniLogClear
            // 
            this.MniLogClear.Name = "MniLogClear";
            this.MniLogClear.Size = new System.Drawing.Size(180, 24);
            this.MniLogClear.Text = "Очистка";
            // 
            // MniHelp
            // 
            this.MniHelp.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.MniHelp.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniHelpAbout});
            this.MniHelp.Name = "MniHelp";
            this.MniHelp.Size = new System.Drawing.Size(79, 24);
            this.MniHelp.Text = "&Справка";
            // 
            // MniHelpAbout
            // 
            this.MniHelpAbout.Name = "MniHelpAbout";
            this.MniHelpAbout.Size = new System.Drawing.Size(182, 24);
            this.MniHelpAbout.Text = "О программе...";
            this.MniHelpAbout.Click += new System.EventHandler(this.About_Command);
            // 
            // TxbLog
            // 
            this.TxbLog.BackColor = System.Drawing.SystemColors.Window;
            this.TxbLog.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TxbLog.Font = new System.Drawing.Font("Courier New", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TxbLog.Location = new System.Drawing.Point(0, 28);
            this.TxbLog.Multiline = true;
            this.TxbLog.Name = "TxbLog";
            this.TxbLog.ReadOnly = true;
            this.TxbLog.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.TxbLog.Size = new System.Drawing.Size(1084, 533);
            this.TxbLog.TabIndex = 1;
            this.TxbLog.TabStop = false;
            // 
            // MniLists
            // 
            this.MniLists.Name = "MniLists";
            this.MniLists.Size = new System.Drawing.Size(71, 24);
            this.MniLists.Text = "&Списки";
            this.MniLists.Click += new System.EventHandler(this.Lists_Command);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1084, 561);
            this.Controls.Add(this.TxbLog);
            this.Controls.Add(this.MnuMain);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.MnuMain;
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(1100, 600);
            this.MinimizeBox = false;
            this.MinimumSize = new System.Drawing.Size(1100, 600);
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Задание на 08.11.2021 - меню, списки, выпадающие списки";
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.MnuMain.ResumeLayout(false);
            this.MnuMain.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip MnuMain;
        private System.Windows.Forms.ToolStripMenuItem MniFile;
        private System.Windows.Forms.ToolStripMenuItem MniQuit;
        private System.Windows.Forms.ToolStripMenuItem MniVolumetric;
        private System.Windows.Forms.ToolStripMenuItem MniVolumetricConoid;
        private System.Windows.Forms.ToolStripMenuItem MniVolumetricSphere;
        private System.Windows.Forms.ToolStripMenuItem MniVolumetricCylinder;
        private System.Windows.Forms.ToolStripSeparator MniVolumetricSep1;
        private System.Windows.Forms.ToolStripMenuItem MniVolumetricBrick;
        private System.Windows.Forms.ToolStripMenuItem mniLog;
        private System.Windows.Forms.ToolStripMenuItem MniLogView;
        private System.Windows.Forms.ToolStripMenuItem MniLogClear;
        private System.Windows.Forms.ToolStripMenuItem MniHelp;
        private System.Windows.Forms.ToolStripMenuItem MniHelpAbout;
        private System.Windows.Forms.TextBox TxbLog;
        private System.Windows.Forms.ToolStripMenuItem MniLists;
    }
}

