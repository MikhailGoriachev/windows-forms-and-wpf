﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ListBoxComboBoxMenu.Models
{
    /* 
     * Класс Conoid, представляющий усеченный конус (радиус верхнего
     * основания, радиус нижнего основания, высота и плотность – тип
     * полей double). 
     */
    internal class Conoid
    {
        // Радиус верхнего основания
        private double _radiusUp;
        public double RadiusUp {
            get => _radiusUp; 
            set {
				if (value <= 0)
                    throw new ArgumentException("Conoid. Отрицательное или нулевое верхнее основание");
                _radiusUp = value;
			} // set
        } // RadiusUp

        // Радиус нижнего основания
        private double _radiusDown;
        public double RadiusDown {
            get => _radiusDown;
            set {
				if (value <= 0)
					throw new ArgumentException("Conoid. Отрицательное или нулевое нижнее основание");
				_radiusDown = value;
			} // set
        } // RadiusDown

        // Высота
        private double _height;
        public double Height {
            get => _height;
            set {
				if (value <= 0)
					throw new ArgumentException("Conoid. Отрицательная или нулевая высота");
				_height = value;
			} // set
        } // Height

        // Плотность материала усеченного конуса
        private double _density;
        public double Density {
            get => _density;
            set {
                if (value <= 0)
                    throw new ArgumentException("Conoid. Отрицательная или нулевая плотность материала");
                _density = value;
            } // set
        } // Density

        // конструкторы объекта класса, плотность по умолчанию - нержавеющая стпль 304
        public Conoid():this(1d, 2d, 1d, 7850d) { } // Conoid

        public Conoid(double radiusUp, double radiusDown, double height, double density) {
            RadiusUp = radiusUp;
            RadiusDown = radiusDown;
            Height = height;
            Density = density;
        } // Conoid

        // вычисляемые свойства для площади и объема усеченного конуса
        // площадь поверхности усеченного конуса
        // https://www-formula.ru/2011-09-21-04-35-14
        public double Area { get {
                double delta = _radiusDown - _radiusUp; 
                double l = Math.Sqrt(_height*_height + delta*delta);
                double area = Math.PI * (l * _radiusUp + l * _radiusDown +
                    _radiusDown * _radiusDown + _radiusUp * _radiusUp);
                return area;
            } 
        } // Area

        // объем усеченного конуса
        // https://www-formula.ru/2011-09-21-10-55-40
        public double Volume => Math.PI * _height * 
            (_radiusDown*_radiusDown + _radiusDown*_radiusUp + 
             _radiusUp*_radiusUp) / 3d;

        // масса усеченного конуса
        public double Mass => Volume * _density;

        // строковое представление конуса (метод ToString(), выводить только
        // радиусы, высоту и плотность) 
        public override string ToString() => 
            $"радиус основания: {_radiusDown:f3}; верхний радиус: {_radiusUp:f3}; " +
            $"высота: {_height:f3}; плотность: {_density:f3}";

    } // class Conoid
}
