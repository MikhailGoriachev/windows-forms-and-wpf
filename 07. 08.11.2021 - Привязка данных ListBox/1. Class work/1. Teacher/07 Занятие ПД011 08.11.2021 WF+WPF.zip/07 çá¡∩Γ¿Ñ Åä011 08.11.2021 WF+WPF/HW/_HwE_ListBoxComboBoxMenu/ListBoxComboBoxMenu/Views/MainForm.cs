﻿using System;
using System.IO;
using System.Text;
using System.Windows.Forms;

// Главная форма приложения - меню, вывод журнала для просмотра
namespace ListBoxComboBoxMenu.Views
{
    public partial class MainForm : Form
    {
        // имя файла журнала
        private string _fileLog;

        // конструкторы формы
        public MainForm ():this(@"./listbox.log") { }

        public MainForm(string fileLog) {
            InitializeComponent();

            _fileLog = fileLog;
        } // MainForm


        // при загрузке формы прочитать данные из файла журнала в TextBox
        // для упрощения данные в журнале отформатированы :) 
        // так, конечно, никто не делает
        private void MainForm_Load (object sender, EventArgs e) {
            if (!File.Exists(_fileLog)) {
                TxbLog.Text = $"{DateTime.Now:dd/MM/yyyy HH:mm:ss}. Нет файла журнала";
                return;
            } // if
            TxbLog.Lines = File.ReadAllLines(_fileLog, Encoding.UTF8);
        } // MainForm_Load


        // Завершение работы приложения
        private void Exit_Command(object sender, EventArgs e) => Application.Exit();

        // отображение формы со сведениями о программе
        private void About_Command (object sender, EventArgs e) {
            AboutForm aboutForm = new AboutForm();
            aboutForm.ShowDialog();
        } // About_Command


        // отображение формы для расчета усеченного конуса
        private void Coniod_Command (object sender, EventArgs e) {
            ConoidForm conoidForm = new ConoidForm();
            conoidForm.ShowDialog();
        } // Coniod_Command


        // отображение формы для расчета сферы
        private void Sphere_Command (object sender, EventArgs e) {
            SphereForm sphereForm = new SphereForm();
            sphereForm.ShowDialog();
        } // Sphere_Command


        // отображение формы для расчета цилиндра
        private void Cylinder_Command (object sender, EventArgs e) {
            CylinderForm cylinderForm = new CylinderForm();
            cylinderForm.ShowDialog();
        } // Cylinder_Command


        // отображение формы для расчета прямоугольного параллелепипеда
        private void Parallelepiped_Command (object sender, EventArgs e) {
            ParallelepipedForm parallelepipedForm = new ParallelepipedForm();
            parallelepipedForm.ShowDialog();
        } // Parallelepiped_Command


        // отображение формы для работы c ListBox, ComboBox
        private void Lists_Command(object sender, EventArgs e) {
            ListsForm listsForm = new ListsForm();
            listsForm.ShowDialog();
        } // Lists_Command


        // просмотр журнала работы приложения
        private void LogView_Command (object sender, EventArgs e) {

        } // LogView_Command


        // очистка журнала работы приложения
        private void LogClear_Command (object sender, EventArgs e) {
            if (!File.Exists(_fileLog)) {
                TxbLog.Text = $"{DateTime.Now:dd/MM/yyyy HH:mm:ss}. Нет файла журнала";
                return;
            } // if

            File.WriteAllText(_fileLog, "");
            TxbLog.Text = $"{DateTime.Now:dd/MM/yyyy HH:mm:ss}. Файл журнала очищен от записей";
        } // LogClear_Command
    } // class MainForm
}
