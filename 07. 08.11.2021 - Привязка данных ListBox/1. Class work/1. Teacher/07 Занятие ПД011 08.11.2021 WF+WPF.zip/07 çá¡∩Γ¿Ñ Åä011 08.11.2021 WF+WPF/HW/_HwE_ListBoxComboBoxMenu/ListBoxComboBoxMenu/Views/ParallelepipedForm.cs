﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


// модели приложения ткт
using ListBoxComboBoxMenu.Models;

/*
 * Форма для работы с прямоугольным параллелепипедом
 */
namespace ListBoxComboBoxMenu.Views
{
    public partial class ParallelepipedForm : Form
    {
        // модель для формы
        private Parallelepiped _parallelepiped;

        // представление для пустой строки результата
        private const string EmptyResult = "---''---";

        // конструктор формы
        public ParallelepipedForm() {
            InitializeComponent();

            // создать модель для работы формы
            _parallelepiped = new Parallelepiped();

            // хардкодим :( 
            // установить материал и изображение по плотности
            // по умолчанию плотность - плотность стали
            CbxMaterial.Text = CbxMaterial.Items[3].ToString();
            PcbMaterial.Image = Image.FromFile(@"..\..\Images\Materials\" + Materials.Data["steel"].ImageFile);

            // начальное значение полей ввода TextBox
            NudSideA.Value = (decimal)_parallelepiped.C;
            NudSideB.Value = (decimal)_parallelepiped.B;
            NudSideC.Value = (decimal)_parallelepiped.C;
            TxbDensity.Text = $"{_parallelepiped.Density:f3}";

            // начальное значение меток вывода результата
            LblAreaResult.Text = LblVolumeResult.Text = LblMassResult.Text = EmptyResult;
        } // ParallelepipedForm


        // вычисление параметров прямоугольного параллелепипеда по заданию
        private void BtnCalc_Click(object sender, EventArgs e) {
            // ошибок уровня модели на прямоугольном параллелепипеде нет
            
            // получить текущие данные из полей ввода
            _parallelepiped.A = (double)NudSideA.Value;
            _parallelepiped.B = (double)NudSideB.Value;
            _parallelepiped.C = (double)NudSideC.Value;
            
            // плотность получаем из радио-кнопок, следующую строку вообще
            // можем удалить :) 
            // _parallelepiped.Density = double.Parse(TxbDensity.Text);

            // вычисление параметров, если это задано
            LblAreaResult.Text   = ChbArea.Checked   ? $"{_parallelepiped.Area:n3}" : "Расчет не требуется";
            LblVolumeResult.Text = ChbVolume.Checked ? $"{_parallelepiped.Volume:n3}" : "Расчет не требуется";
            LblMassResult.Text   = ChbMass.Checked   ? $"{_parallelepiped.Mass:n3}" : "Расчет не требуется";
        } // BtnCalc_Click


        // при вводе данных:
        // очищаем поле вывода результата
        private void Nud_ValueChanged (object sender, EventArgs e) {
            LblAreaResult.Text = LblVolumeResult.Text = LblMassResult.Text = EmptyResult;
        } // Nud_ValueChanged


        // обработчик выбора в комбо-боксе материала, из которого создано тело 
        private void CbxMaterial_SelectItem (object sender, EventArgs e) {

            string material = Utils.ToMaterial(CbxMaterial.Text);

            MaterialViewModel viewModel = Materials.Data[material];

            // задать картинку материала
            PcbMaterial.Image = Image.FromFile(@"..\..\Images\Materials\" + viewModel?.ImageFile);

            // задать плотность материала
            _parallelepiped.Density = viewModel.Density;

            // отобразить плотность материала в TextBox
            TxbDensity.Text = $"{_parallelepiped.Density:f3}";
            TxbDensity.SelectionLength = 0;

            // т.к. данные для расчета изменились, очищаем поле вывода результата
            LblAreaResult.Text = LblVolumeResult.Text = LblMassResult.Text = EmptyResult;
        } // CbxMaterial_SelectItem
    }
}
