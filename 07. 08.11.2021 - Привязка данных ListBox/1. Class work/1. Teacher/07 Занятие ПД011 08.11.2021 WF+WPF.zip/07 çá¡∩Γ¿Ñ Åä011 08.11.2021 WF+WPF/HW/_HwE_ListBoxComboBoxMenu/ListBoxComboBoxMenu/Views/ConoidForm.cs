﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

// модели приложения ткт
using ListBoxComboBoxMenu.Models;

/*
 * Форма для работы с усеченным конусом
 */
namespace ListBoxComboBoxMenu.Views
{
    public partial class ConoidForm : Form
    {
        // модель для формы
        private Conoid _conoid;

        // представление для пустой строки результата
        private const string EmptyResult = "---''---";

        // конструктор формы
        public ConoidForm() {
            InitializeComponent();

            // создать модель для работы формы
            _conoid = new Conoid();

            // хардкодим :( 
            // установить материал и изображение по плотности
            // по умолчанию плотность - плотность стали
            CbxMaterial.Text = CbxMaterial.Items[3].ToString();
            PcbMaterial.Image = Image.FromFile(@"..\..\Images\Materials\" + Materials.Data["steel"].ImageFile);

            // начальное значение полей ввода TextBox
            NudRadiusDown.Value = (decimal)_conoid.RadiusDown;
            NudRadiusUp.Value   = (decimal)_conoid.RadiusUp;
            NudHeight.Value     = (decimal)_conoid.Height;
            TxbDensity.Text    = $"{_conoid.Density:f3}";

            // начальное значение меток вывода результата
            LblAreaResult.Text = LblVolumeResult.Text = LblMassResult.Text = EmptyResult;
        } // ConoidForm


        // вычисление параметров конуса по заданию
        private void BtnCalc_Click(object sender, EventArgs e) {
            try {
                // получить текущие данные из полей ввода
                _conoid.RadiusDown = (double)NudRadiusDown.Value;
                _conoid.RadiusUp   = (double)NudRadiusUp.Value;
                _conoid.Height     = (double)NudHeight.Value;

                // проверка на уровне модели
                if (_conoid.RadiusDown <= _conoid.RadiusUp) 
                    throw new InvalidDataException($"Нижнее основание конуса меньше или равно верхнему");

                // вычисление параметров, если это задано
                LblAreaResult.Text = ChbArea.Checked ? $"{_conoid.Area:n3}" : "Расчет не требуется";
                LblVolumeResult.Text = ChbVolume.Checked ? $"{_conoid.Volume:n3}" : "Расчет не требуется";
                LblMassResult.Text = ChbMass.Checked ? $"{_conoid.Mass:n3}" : "Расчет не требуется";

            } catch (Exception ex) {
                // обработка ошибки уровня модели 

                // начальное значение меток вывода результата
                LblAreaResult.Text = LblVolumeResult.Text = LblMassResult.Text = EmptyResult;

                // запрет кнопки вычисления
                BtnCalc.Enabled = false;

                // сообщить об ошибке
                MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                
                // Передать фокус ввода на первое поле ввода
                NudRadiusDown.Focus();
            } // try-catch
        } // BtnCalc_Click


        // при вводе данных:
        // очищаем поле вывода результата
        private void Nud_ValueChanged (object sender, EventArgs e) {
            LblAreaResult.Text = LblVolumeResult.Text = LblMassResult.Text = EmptyResult;
        } // Nud_ValueChanged


        // обработчик выбора в комбо-боксе материала, из которого создано тело 
        private void CbxMaterial_SelectItem (object sender, EventArgs e) {

            string material = Utils.ToMaterial(CbxMaterial.Text);

            MaterialViewModel viewModel = Materials.Data[material];

            // задать картинку материала
            PcbMaterial.Image = Image.FromFile(@"..\..\Images\Materials\" + viewModel?.ImageFile);

            // задать плотность материала
            _conoid.Density = viewModel.Density;

            // отобразить плотность материала в TextBox
            TxbDensity.Text = $"{_conoid.Density:f3}";
            TxbDensity.SelectionLength = 0;

            // т.к. данные для расчета изменились, очищаем поле вывода результата
            LblAreaResult.Text = LblVolumeResult.Text = LblMassResult.Text = EmptyResult;
        } // CbxMaterial_SelectItem
    } // class ConoidForm
}
