﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using ListBoxComboBoxMenu.Models;

/*
 * Форма для работы с цилиндром
 */
namespace ListBoxComboBoxMenu.Views
{
    public partial class CylinderForm : Form
    {
        // модель для формы
        private Cylinder _cylinder;

        // представление для пустой строки результата
        private const string EmptyResult = "---''---";

        // конструктор формы
        public CylinderForm() {
            InitializeComponent();

            // создать модель для работы формы
            _cylinder = new Cylinder();

            // хардкодим :( 
            // установить материал и изображение по плотности
            // по умолчанию плотность - плотность стали
            CbxMaterial.Text = CbxMaterial.Items[3].ToString();
            PcbMaterial.Image = Image.FromFile(@"..\..\Images\Materials\" + Materials.Data["steel"].ImageFile);

            // начальное значение полей ввода NumericUpDown
            NudRadius.Value = (decimal)_cylinder.Radius;
            NudHeight.Value = (decimal)_cylinder.Height;
            TxbDensity.Text    = $"{_cylinder.Density:f3}";

            // начальное значение меток вывода результата
            LblAreaResult.Text = LblVolumeResult.Text = LblMassResult.Text = EmptyResult;
        } // ConoidForm


        // вычисление параметров конуса по заданию
        private void BtnCalc_Click(object sender, EventArgs e) {
            // получить текущие данные из полей ввода
            _cylinder.Radius = (double)NudRadius.Value;
            _cylinder.Height = (double)NudHeight.Value;

            // вычисление параметров, если это задано
            LblAreaResult.Text   = ChbArea.Checked   ? $"{_cylinder.Area:n3}" : "Расчет не требуется";
            LblVolumeResult.Text = ChbVolume.Checked ? $"{_cylinder.Volume:n3}" : "Расчет не требуется";
            LblMassResult.Text   = ChbMass.Checked   ? $"{_cylinder.Mass:n3}" : "Расчет не требуется";
        } // BtnCalc_Click



        // при вводе данных:
        // очищаем поле вывода результата
        private void Nud_ValueChanged (object sender, EventArgs e) {
            LblAreaResult.Text = LblVolumeResult.Text = LblMassResult.Text = EmptyResult;
        } // Nud_ValueChanged

        
        // обработчик выбора в комбо-боксе материала, из которого создано тело 
        private void CbxMaterial_SelectItem (object sender, EventArgs e) {

            string material = Utils.ToMaterial(CbxMaterial.Text);

            MaterialViewModel viewModel = Materials.Data[material];

            // задать картинку материала
            PcbMaterial.Image = Image.FromFile(@"..\..\Images\Materials\" + viewModel?.ImageFile);

            // задать плотность материала
            _cylinder.Density = viewModel.Density;

            // отобразить плотность материала в TextBox
            TxbDensity.Text = $"{_cylinder.Density:f3}";
            TxbDensity.SelectionLength = 0;

            // т.к. данные для расчета изменились, очищаем поле вывода результата
            LblAreaResult.Text = LblVolumeResult.Text = LblMassResult.Text = EmptyResult;
        } // CbxMaterial_SelectItem
    } // class CylinderForm
}
