﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using ListBoxComboBoxMenu.Models;

namespace ListBoxComboBoxMenu.Views
{
    public partial class SphereForm : Form
    {
        // модель  для работы 
        private Sphere _sphere;

        // представление для пустой строки результата
        private const string EmptyResult = "---''---";

        public SphereForm() {
            InitializeComponent();


            // создать модель для работы формы
            _sphere = new Sphere();

            // хардкодим :( 
            // установить материал и изображение по плотности
            // по умолчанию плотность - плотность стали
            CbxMaterial.Text = CbxMaterial.Items[3].ToString();
            PcbMaterial.Image = Image.FromFile(@"..\..\Images\Materials\" + Materials.Data["steel"].ImageFile);

            // начальное значение полей ввода TextBox
            NudRadius.Value = (decimal)_sphere.Radius;
            TxbDensity.Text = $"{_sphere.Density:f3}";

            // начальное значение меток вывода результата
            LblAreaResult.Text = LblVolumeResult.Text = LblMassResult.Text = EmptyResult;
        } // SphereForm


        // TODO: защита от пустого поля NumericUpDown
        // вычисление параметров сферы по заданию
        private void BtnCalc_Click(object sender, EventArgs e) {
            // для сферы нет ошибок уровня модели

            // получить текущие данные из полей ввода
            _sphere.Radius = (double)NudRadius.Value;

            // вычисление параметров, если это задано
            LblAreaResult.Text = ChbArea.Checked ? $"{_sphere.Area:n3}" : "Расчет не требуется";
            LblVolumeResult.Text = ChbVolume.Checked ? $"{_sphere.Volume:n3}" : "Расчет не требуется";
            LblMassResult.Text = ChbMass.Checked ? $"{_sphere.Mass:n3}" : "Расчет не требуется";
        } // BtnCalc_Click


        // при вводе данных:
        // очищаем поле вывода результата
        private void Nud_ValueChanged(object sender, EventArgs e) {
            // BtnCalc.Enabled = NudRadius.Text.Length > 0;
            LblAreaResult.Text = LblVolumeResult.Text = LblMassResult.Text = EmptyResult;
        } // Nud_ValueChanged


        // обработчик выбора в комбо-боксе материала, из которого создано тело 
        private void CbxMaterial_SelectItem(object sender, EventArgs e) {

            string material = Utils.ToMaterial(CbxMaterial.Text);

            MaterialViewModel viewModel = Materials.Data[material];

            // задать картинку материала
            PcbMaterial.Image = Image.FromFile(@"..\..\Images\Materials\" + viewModel?.ImageFile);

            // задать плотность материала
            _sphere.Density = viewModel.Density;

            // отобразить плотность материала в TextBox
            TxbDensity.Text = $"{_sphere.Density:f3}";
            TxbDensity.SelectionLength = 0;

            // т.к. данные для расчета изменились, очищаем поле вывода результата
            LblAreaResult.Text = LblVolumeResult.Text = LblMassResult.Text = EmptyResult;
        } // CbxMaterial_SelectItem

        // фильтрация нажатия клавиш "минус" - на основной и доп. цифровой клавиатуре 
        // если e.SuppressKeyPress установлен в true, то клавиша не доходит до элемента интерфейса 
        private void NudRadius_KeyDown (object sender, KeyEventArgs e) =>
            e.SuppressKeyPress = e.KeyData == Keys.OemMinus || e.KeyData == Keys.Subtract;
    } // class SphereForm
}
