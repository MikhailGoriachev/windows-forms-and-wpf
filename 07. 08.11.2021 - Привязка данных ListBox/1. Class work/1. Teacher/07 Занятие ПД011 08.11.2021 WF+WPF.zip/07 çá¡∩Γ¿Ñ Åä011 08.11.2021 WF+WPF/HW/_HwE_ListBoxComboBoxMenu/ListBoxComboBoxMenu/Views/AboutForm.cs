﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ListBoxComboBoxMenu.Views
{
    public partial class AboutForm : Form
    {
        public AboutForm() {
            InitializeComponent();

            // переводы строк указывать не обязательно, Label по умолчанию
            // сам выполняет переход на новую строку
            LblAbout1.Text =
                "Для объемных геометрических тел:\n" +
                "     • усеченный конус\n" +
                "     • сфера\n" +
                "     • цилиндр\n" +
                "     • прямоугольный параллелепипед\n";

            LblAbout2.Text =
                "Вычисялются параметры:\n" +
                "    • площадь поверхности\n" +
                "    • объем\n" +
                "    • масса\n" +
                "Каждое тело размещено в собственной\n" +
                "форме, выводим изображения тела,\n" +
                "материала";

        } // AboutForm


        // после загрузки формы запустить таймер, время срабатывания - 10 с,
        // по заданию
        private void AboutForm_Load(object sender, EventArgs e) {
            TmrAbout.Interval = 10_000;
            TmrAbout.Enabled = true;
        } // AboutForm_Load


        // при срабатывании таймера: отключить таймер, закрыть форму
        private void TmrAbout_Tick(object sender, EventArgs e) {
            TmrAbout.Enabled = false;
            Close();
        } // TmrAbout_Tick
    }
}
