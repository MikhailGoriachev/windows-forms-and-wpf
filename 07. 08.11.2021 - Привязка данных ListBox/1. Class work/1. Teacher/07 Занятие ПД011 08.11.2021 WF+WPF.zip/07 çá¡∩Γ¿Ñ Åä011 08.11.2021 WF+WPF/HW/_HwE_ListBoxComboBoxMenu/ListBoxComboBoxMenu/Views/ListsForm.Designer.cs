﻿
namespace ListBoxComboBoxMenu.Views
{
    partial class ListsForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose (bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent () {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ListsForm));
            this.LbxFirst = new System.Windows.Forms.ListBox();
            this.TxbCity = new System.Windows.Forms.TextBox();
            this.BtnMoveAllToSecond = new System.Windows.Forms.Button();
            this.LblFirstListBox = new System.Windows.Forms.Label();
            this.LblEnterCity = new System.Windows.Forms.Label();
            this.LblChoiceCity = new System.Windows.Forms.Label();
            this.LblSecondListBox = new System.Windows.Forms.Label();
            this.LbxSecond = new System.Windows.Forms.ListBox();
            this.CbxCities = new System.Windows.Forms.ComboBox();
            this.BtnMoveSelectedToSecond = new System.Windows.Forms.Button();
            this.BtnMoveAllToFirst = new System.Windows.Forms.Button();
            this.BtnClearAll = new System.Windows.Forms.Button();
            this.BtnMakeLists = new System.Windows.Forms.Button();
            this.BtnClose = new System.Windows.Forms.Button();
            this.BtnMoveSelectedToFirst = new System.Windows.Forms.Button();
            this.BtnAddCity = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // LbxFirst
            // 
            this.LbxFirst.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LbxFirst.FormattingEnabled = true;
            this.LbxFirst.ItemHeight = 19;
            this.LbxFirst.Items.AddRange(new object[] {
            "Алчевск",
            "Горловка",
            "Дебальцево",
            "Донецк",
            "Енакиево",
            "Иловайск",
            "Краснодон",
            "Луганск",
            "Макеевка",
            "Моспино",
            "Новоазовск",
            "Снежное",
            "Старобешево",
            "Харцызск",
            "Ясиноватая"});
            this.LbxFirst.Location = new System.Drawing.Point(40, 48);
            this.LbxFirst.Name = "LbxFirst";
            this.LbxFirst.Size = new System.Drawing.Size(304, 365);
            this.LbxFirst.Sorted = true;
            this.LbxFirst.TabIndex = 1;
            // 
            // TxbCity
            // 
            this.TxbCity.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TxbCity.Location = new System.Drawing.Point(40, 456);
            this.TxbCity.Name = "TxbCity";
            this.TxbCity.Size = new System.Drawing.Size(216, 27);
            this.TxbCity.TabIndex = 2;
            // 
            // BtnMoveAllToSecond
            // 
            this.BtnMoveAllToSecond.BackColor = System.Drawing.Color.MidnightBlue;
            this.BtnMoveAllToSecond.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.BtnMoveAllToSecond.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BtnMoveAllToSecond.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.BtnMoveAllToSecond.Location = new System.Drawing.Point(400, 104);
            this.BtnMoveAllToSecond.Name = "BtnMoveAllToSecond";
            this.BtnMoveAllToSecond.Size = new System.Drawing.Size(232, 40);
            this.BtnMoveAllToSecond.TabIndex = 14;
            this.BtnMoveAllToSecond.Text = "Переместить все >>";
            this.BtnMoveAllToSecond.UseVisualStyleBackColor = true;
            this.BtnMoveAllToSecond.Click += new System.EventHandler(this.MoveAllToSecond_Command);
            // 
            // LblFirstListBox
            // 
            this.LblFirstListBox.AutoSize = true;
            this.LblFirstListBox.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblFirstListBox.Location = new System.Drawing.Point(40, 24);
            this.LblFirstListBox.Name = "LblFirstListBox";
            this.LblFirstListBox.Size = new System.Drawing.Size(190, 19);
            this.LblFirstListBox.TabIndex = 15;
            this.LblFirstListBox.Text = "Первый список городов:";
            // 
            // LblEnterCity
            // 
            this.LblEnterCity.AutoSize = true;
            this.LblEnterCity.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblEnterCity.Location = new System.Drawing.Point(40, 432);
            this.LblEnterCity.Name = "LblEnterCity";
            this.LblEnterCity.Size = new System.Drawing.Size(201, 19);
            this.LblEnterCity.TabIndex = 17;
            this.LblEnterCity.Text = "Введите название города:";
            // 
            // LblChoiceCity
            // 
            this.LblChoiceCity.AutoSize = true;
            this.LblChoiceCity.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblChoiceCity.Location = new System.Drawing.Point(680, 432);
            this.LblChoiceCity.Name = "LblChoiceCity";
            this.LblChoiceCity.Size = new System.Drawing.Size(213, 19);
            this.LblChoiceCity.TabIndex = 21;
            this.LblChoiceCity.Text = "Выберите название города:";
            // 
            // LblSecondListBox
            // 
            this.LblSecondListBox.AutoSize = true;
            this.LblSecondListBox.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblSecondListBox.Location = new System.Drawing.Point(680, 24);
            this.LblSecondListBox.Name = "LblSecondListBox";
            this.LblSecondListBox.Size = new System.Drawing.Size(187, 19);
            this.LblSecondListBox.TabIndex = 20;
            this.LblSecondListBox.Text = "Второй список городов:";
            // 
            // LbxSecond
            // 
            this.LbxSecond.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LbxSecond.FormattingEnabled = true;
            this.LbxSecond.ItemHeight = 19;
            this.LbxSecond.Location = new System.Drawing.Point(680, 48);
            this.LbxSecond.Name = "LbxSecond";
            this.LbxSecond.Size = new System.Drawing.Size(304, 365);
            this.LbxSecond.Sorted = true;
            this.LbxSecond.TabIndex = 18;
            // 
            // CbxCities
            // 
            this.CbxCities.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CbxCities.Font = new System.Drawing.Font("Tahoma", 12F);
            this.CbxCities.FormattingEnabled = true;
            this.CbxCities.Items.AddRange(new object[] {
            "Амвросиевка",
            "Докучаевск",
            "Ждановка",
            "Зугрэс",
            "Кировское",
            "Комсомольское",
            "Торез",
            "Углегорск",
            "Шахтёрск",
            "Юнокоммунаровск"});
            this.CbxCities.Location = new System.Drawing.Point(680, 456);
            this.CbxCities.Name = "CbxCities";
            this.CbxCities.Size = new System.Drawing.Size(304, 27);
            this.CbxCities.Sorted = true;
            this.CbxCities.TabIndex = 22;
            this.CbxCities.SelectedIndexChanged += new System.EventHandler(this.CbxCities_SelectedIndexChanged);
            // 
            // BtnMoveSelectedToSecond
            // 
            this.BtnMoveSelectedToSecond.BackColor = System.Drawing.Color.MidnightBlue;
            this.BtnMoveSelectedToSecond.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.BtnMoveSelectedToSecond.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BtnMoveSelectedToSecond.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.BtnMoveSelectedToSecond.Location = new System.Drawing.Point(400, 48);
            this.BtnMoveSelectedToSecond.Name = "BtnMoveSelectedToSecond";
            this.BtnMoveSelectedToSecond.Size = new System.Drawing.Size(232, 40);
            this.BtnMoveSelectedToSecond.TabIndex = 23;
            this.BtnMoveSelectedToSecond.Text = "Выбранный >";
            this.BtnMoveSelectedToSecond.UseVisualStyleBackColor = true;
            this.BtnMoveSelectedToSecond.Click += new System.EventHandler(this.MoveItemToSecond);
            // 
            // BtnMoveAllToFirst
            // 
            this.BtnMoveAllToFirst.BackColor = System.Drawing.Color.MidnightBlue;
            this.BtnMoveAllToFirst.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.BtnMoveAllToFirst.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BtnMoveAllToFirst.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.BtnMoveAllToFirst.Location = new System.Drawing.Point(400, 160);
            this.BtnMoveAllToFirst.Name = "BtnMoveAllToFirst";
            this.BtnMoveAllToFirst.Size = new System.Drawing.Size(232, 40);
            this.BtnMoveAllToFirst.TabIndex = 24;
            this.BtnMoveAllToFirst.Text = "<< Переместить все";
            this.BtnMoveAllToFirst.UseVisualStyleBackColor = true;
            this.BtnMoveAllToFirst.Click += new System.EventHandler(this.MoveAllToFirst_Command);
            // 
            // BtnClearAll
            // 
            this.BtnClearAll.BackColor = System.Drawing.Color.MidnightBlue;
            this.BtnClearAll.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.BtnClearAll.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BtnClearAll.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.BtnClearAll.Location = new System.Drawing.Point(400, 320);
            this.BtnClearAll.Name = "BtnClearAll";
            this.BtnClearAll.Size = new System.Drawing.Size(232, 40);
            this.BtnClearAll.TabIndex = 25;
            this.BtnClearAll.Text = "Очистка списков";
            this.BtnClearAll.UseVisualStyleBackColor = true;
            this.BtnClearAll.Click += new System.EventHandler(this.ClearAllLists_Command);
            // 
            // BtnMakeLists
            // 
            this.BtnMakeLists.BackColor = System.Drawing.Color.MidnightBlue;
            this.BtnMakeLists.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.BtnMakeLists.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BtnMakeLists.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.BtnMakeLists.Location = new System.Drawing.Point(400, 373);
            this.BtnMakeLists.Name = "BtnMakeLists";
            this.BtnMakeLists.Size = new System.Drawing.Size(232, 40);
            this.BtnMakeLists.TabIndex = 26;
            this.BtnMakeLists.Text = "Сформировать списки";
            this.BtnMakeLists.UseVisualStyleBackColor = true;
            this.BtnMakeLists.Click += new System.EventHandler(this.Generate_Command);
            // 
            // BtnClose
            // 
            this.BtnClose.BackColor = System.Drawing.Color.MidnightBlue;
            this.BtnClose.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.BtnClose.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.BtnClose.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BtnClose.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.BtnClose.Location = new System.Drawing.Point(752, 512);
            this.BtnClose.Name = "BtnClose";
            this.BtnClose.Size = new System.Drawing.Size(232, 40);
            this.BtnClose.TabIndex = 27;
            this.BtnClose.Text = "Закрыть";
            this.BtnClose.UseVisualStyleBackColor = true;
            // 
            // BtnMoveSelectedToFirst
            // 
            this.BtnMoveSelectedToFirst.BackColor = System.Drawing.Color.MidnightBlue;
            this.BtnMoveSelectedToFirst.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.BtnMoveSelectedToFirst.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BtnMoveSelectedToFirst.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.BtnMoveSelectedToFirst.Location = new System.Drawing.Point(400, 216);
            this.BtnMoveSelectedToFirst.Name = "BtnMoveSelectedToFirst";
            this.BtnMoveSelectedToFirst.Size = new System.Drawing.Size(232, 40);
            this.BtnMoveSelectedToFirst.TabIndex = 28;
            this.BtnMoveSelectedToFirst.Text = "< Выбранный";
            this.BtnMoveSelectedToFirst.UseVisualStyleBackColor = true;
            this.BtnMoveSelectedToFirst.Click += new System.EventHandler(this.MoveItemToFirst);
            // 
            // BtnAddCity
            // 
            this.BtnAddCity.BackColor = System.Drawing.Color.MidnightBlue;
            this.BtnAddCity.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.BtnAddCity.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BtnAddCity.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.BtnAddCity.Location = new System.Drawing.Point(264, 448);
            this.BtnAddCity.Name = "BtnAddCity";
            this.BtnAddCity.Size = new System.Drawing.Size(80, 40);
            this.BtnAddCity.TabIndex = 29;
            this.BtnAddCity.Text = "Ввод";
            this.BtnAddCity.UseVisualStyleBackColor = true;
            this.BtnAddCity.Click += new System.EventHandler(this.AddCity_Command);
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(40, 488);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(304, 40);
            this.label1.TabIndex = 30;
            this.label1.Text = "Введите название города, затем кликните кнопку \"Ввод\" для добавления в первый спи" +
    "сок";
            // 
            // ListsForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1027, 568);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.BtnAddCity);
            this.Controls.Add(this.BtnMoveSelectedToFirst);
            this.Controls.Add(this.BtnClose);
            this.Controls.Add(this.BtnMakeLists);
            this.Controls.Add(this.BtnClearAll);
            this.Controls.Add(this.BtnMoveAllToFirst);
            this.Controls.Add(this.BtnMoveSelectedToSecond);
            this.Controls.Add(this.CbxCities);
            this.Controls.Add(this.LblChoiceCity);
            this.Controls.Add(this.LblSecondListBox);
            this.Controls.Add(this.LbxSecond);
            this.Controls.Add(this.LblEnterCity);
            this.Controls.Add(this.LblFirstListBox);
            this.Controls.Add(this.BtnMoveAllToSecond);
            this.Controls.Add(this.TxbCity);
            this.Controls.Add(this.LbxFirst);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(1043, 607);
            this.MinimizeBox = false;
            this.MinimumSize = new System.Drawing.Size(1043, 607);
            this.Name = "ListsForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Задача 2 - Изучение ListBox, ComboBox";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.ListBox LbxFirst;
        private System.Windows.Forms.TextBox TxbCity;
        private System.Windows.Forms.Button BtnMoveAllToSecond;
        private System.Windows.Forms.Label LblFirstListBox;
        private System.Windows.Forms.Label LblEnterCity;
        private System.Windows.Forms.Label LblChoiceCity;
        private System.Windows.Forms.Label LblSecondListBox;
        private System.Windows.Forms.ListBox LbxSecond;
        private System.Windows.Forms.ComboBox CbxCities;
        private System.Windows.Forms.Button BtnMoveSelectedToSecond;
        private System.Windows.Forms.Button BtnMoveAllToFirst;
        private System.Windows.Forms.Button BtnClearAll;
        private System.Windows.Forms.Button BtnMakeLists;
        private System.Windows.Forms.Button BtnClose;
        private System.Windows.Forms.Button BtnMoveSelectedToFirst;
        private System.Windows.Forms.Button BtnAddCity;
        private System.Windows.Forms.Label label1;
    }
}