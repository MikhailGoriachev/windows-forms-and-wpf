﻿
namespace Main.Views
{
	sealed partial class LoggerForm
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.LogContentTextBox = new System.Windows.Forms.TextBox();
			this.SuspendLayout();
			// 
			// LogContentTextBox
			// 
			this.LogContentTextBox.Dock = System.Windows.Forms.DockStyle.Fill;
			this.LogContentTextBox.Font = new System.Drawing.Font("Consolas", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
			this.LogContentTextBox.Location = new System.Drawing.Point(0, 0);
			this.LogContentTextBox.Multiline = true;
			this.LogContentTextBox.Name = "LogContentTextBox";
			this.LogContentTextBox.ReadOnly = true;
			this.LogContentTextBox.Size = new System.Drawing.Size(1055, 550);
			this.LogContentTextBox.TabIndex = 0;
			// 
			// LoggerForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(1055, 550);
			this.Controls.Add(this.LogContentTextBox);
			this.Name = "LoggerForm";
			this.ShowInTaskbar = false;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "LoggerForm";
			this.Load += new System.EventHandler(this.OnLogLoadRequested);
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.TextBox LogContentTextBox;
	}
}