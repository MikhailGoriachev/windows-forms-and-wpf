﻿using System;
using System.Windows.Forms;
using Main.Common;
using Microsoft.Extensions.Configuration;
using Serilog;


namespace Main.ApplicationControl
{
	internal interface IApplicationController
	{
		IConfiguration AppConfig { get; }
		ILogger AppLogger { get; }


		TPresenter Run<TPresenter>() where TPresenter : IPresenter;


		TPresenter Run<TPresenter>(Action<Form> onStartup) where TPresenter : IPresenter;
	}
}