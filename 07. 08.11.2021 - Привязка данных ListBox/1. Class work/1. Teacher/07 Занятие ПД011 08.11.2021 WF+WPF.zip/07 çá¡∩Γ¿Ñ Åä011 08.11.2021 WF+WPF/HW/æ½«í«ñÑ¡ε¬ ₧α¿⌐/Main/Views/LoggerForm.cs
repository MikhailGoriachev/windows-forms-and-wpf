﻿using System;
using Main.Common;


namespace Main.Views
{
	internal interface ILoggerView : IView
	{
		string[] LogText { set; }

		event Action LogLoadRequested;
	}


	public sealed partial class LoggerForm : BaseForm, ILoggerView
	{
		public string[] LogText { set => LogContentTextBox.Lines = value; }


		public LoggerForm() =>
			InitializeComponent();


		public event Action LogLoadRequested;


		public new void Show() => ShowDialog();


		private void OnLogLoadRequested(object sender, EventArgs e) =>
			LogLoadRequested?.Invoke();
	}
}