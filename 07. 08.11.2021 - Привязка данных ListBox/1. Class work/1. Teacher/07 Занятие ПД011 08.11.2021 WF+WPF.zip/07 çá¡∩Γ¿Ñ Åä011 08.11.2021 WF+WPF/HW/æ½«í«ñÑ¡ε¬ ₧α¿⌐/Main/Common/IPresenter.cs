﻿using System;
using System.Windows.Forms;


namespace Main.Common
{
	internal interface IPresenter
	{
		void Run();
		void Run(Action<Form> onStartup);
	}
}