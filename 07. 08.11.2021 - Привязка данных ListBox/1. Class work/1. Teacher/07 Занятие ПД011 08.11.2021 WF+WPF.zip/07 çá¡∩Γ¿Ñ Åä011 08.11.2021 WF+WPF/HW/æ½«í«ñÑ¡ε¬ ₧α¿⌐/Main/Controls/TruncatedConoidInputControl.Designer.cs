﻿
namespace Main.Controls
{
	sealed partial class TruncatedConoidInputControl
	{
		/// <summary> 
		/// Обязательная переменная конструктора.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary> 
		/// Освободить все используемые ресурсы.
		/// </summary>
		/// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Код, автоматически созданный конструктором компонентов

		/// <summary> 
		/// Требуемый метод для поддержки конструктора — не изменяйте 
		/// содержимое этого метода с помощью редактора кода.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			this.MainGrid = new System.Windows.Forms.TableLayoutPanel();
			this.UpperRadiusNumeric = new System.Windows.Forms.NumericUpDown();
			this.LowerRadiusNumeric = new System.Windows.Forms.NumericUpDown();
			this.HeightNumeric = new System.Windows.Forms.NumericUpDown();
			this.UpperRadiusLabel = new System.Windows.Forms.Label();
			this.LowerRadiusLabel = new System.Windows.Forms.Label();
			this.HeightLabel = new System.Windows.Forms.Label();
			this.MainErrorProvider = new System.Windows.Forms.ErrorProvider(this.components);
			this.MainGrid.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.UpperRadiusNumeric)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.LowerRadiusNumeric)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.HeightNumeric)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.MainErrorProvider)).BeginInit();
			this.SuspendLayout();
			// 
			// MainGrid
			// 
			this.MainGrid.ColumnCount = 2;
			this.MainGrid.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 43.20713F));
			this.MainGrid.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 56.79287F));
			this.MainGrid.Controls.Add(this.UpperRadiusNumeric, 1, 3);
			this.MainGrid.Controls.Add(this.LowerRadiusNumeric, 1, 2);
			this.MainGrid.Controls.Add(this.HeightNumeric, 1, 1);
			this.MainGrid.Controls.Add(this.UpperRadiusLabel, 0, 3);
			this.MainGrid.Controls.Add(this.LowerRadiusLabel, 0, 2);
			this.MainGrid.Controls.Add(this.HeightLabel, 0, 1);
			this.MainGrid.Dock = System.Windows.Forms.DockStyle.Fill;
			this.MainGrid.Location = new System.Drawing.Point(0, 0);
			this.MainGrid.Name = "MainGrid";
			this.MainGrid.RowCount = 4;
			this.MainGrid.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 18.75F));
			this.MainGrid.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 27.30263F));
			this.MainGrid.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 26.97368F));
			this.MainGrid.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 26.97368F));
			this.MainGrid.Size = new System.Drawing.Size(449, 249);
			this.MainGrid.TabIndex = 0;
			// 
			// UpperRadiusNumeric
			// 
			this.UpperRadiusNumeric.Dock = System.Windows.Forms.DockStyle.Top;
			this.UpperRadiusNumeric.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
			this.UpperRadiusNumeric.Location = new System.Drawing.Point(197, 183);
			this.UpperRadiusNumeric.Name = "UpperRadiusNumeric";
			this.UpperRadiusNumeric.Size = new System.Drawing.Size(249, 29);
			this.UpperRadiusNumeric.TabIndex = 12;
			// 
			// LowerRadiusNumeric
			// 
			this.LowerRadiusNumeric.Dock = System.Windows.Forms.DockStyle.Top;
			this.LowerRadiusNumeric.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
			this.LowerRadiusNumeric.Location = new System.Drawing.Point(197, 116);
			this.LowerRadiusNumeric.Name = "LowerRadiusNumeric";
			this.LowerRadiusNumeric.Size = new System.Drawing.Size(249, 29);
			this.LowerRadiusNumeric.TabIndex = 11;
			// 
			// HeightNumeric
			// 
			this.HeightNumeric.Dock = System.Windows.Forms.DockStyle.Top;
			this.HeightNumeric.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
			this.HeightNumeric.Location = new System.Drawing.Point(197, 49);
			this.HeightNumeric.Name = "HeightNumeric";
			this.HeightNumeric.Size = new System.Drawing.Size(249, 29);
			this.HeightNumeric.TabIndex = 10;
			// 
			// UpperRadiusLabel
			// 
			this.UpperRadiusLabel.Dock = System.Windows.Forms.DockStyle.Top;
			this.UpperRadiusLabel.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
			this.UpperRadiusLabel.Location = new System.Drawing.Point(3, 180);
			this.UpperRadiusLabel.Name = "UpperRadiusLabel";
			this.UpperRadiusLabel.Size = new System.Drawing.Size(188, 34);
			this.UpperRadiusLabel.TabIndex = 4;
			this.UpperRadiusLabel.Text = "Верхний радиус";
			this.UpperRadiusLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// LowerRadiusLabel
			// 
			this.LowerRadiusLabel.Dock = System.Windows.Forms.DockStyle.Top;
			this.LowerRadiusLabel.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
			this.LowerRadiusLabel.Location = new System.Drawing.Point(3, 113);
			this.LowerRadiusLabel.Name = "LowerRadiusLabel";
			this.LowerRadiusLabel.Size = new System.Drawing.Size(188, 34);
			this.LowerRadiusLabel.TabIndex = 2;
			this.LowerRadiusLabel.Text = "Нижний радиус";
			this.LowerRadiusLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// HeightLabel
			// 
			this.HeightLabel.Dock = System.Windows.Forms.DockStyle.Top;
			this.HeightLabel.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
			this.HeightLabel.Location = new System.Drawing.Point(3, 46);
			this.HeightLabel.Name = "HeightLabel";
			this.HeightLabel.Size = new System.Drawing.Size(188, 34);
			this.HeightLabel.TabIndex = 0;
			this.HeightLabel.Text = "Высота";
			this.HeightLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// MainErrorProvider
			// 
			this.MainErrorProvider.ContainerControl = this;
			this.MainErrorProvider.RightToLeft = true;
			// 
			// TruncatedConoidInputControl
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.Controls.Add(this.MainGrid);
			this.Name = "TruncatedConoidInputControl";
			this.Size = new System.Drawing.Size(449, 249);
			this.MainGrid.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.UpperRadiusNumeric)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.LowerRadiusNumeric)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.HeightNumeric)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.MainErrorProvider)).EndInit();
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.TableLayoutPanel MainGrid;
		private System.Windows.Forms.Label HeightLabel;
		private System.Windows.Forms.Label UpperRadiusLabel;
		private System.Windows.Forms.Label LowerRadiusLabel;
		private System.Windows.Forms.ErrorProvider MainErrorProvider;
		private System.Windows.Forms.NumericUpDown UpperRadiusNumeric;
		private System.Windows.Forms.NumericUpDown LowerRadiusNumeric;
		private System.Windows.Forms.NumericUpDown HeightNumeric;
	}
}
