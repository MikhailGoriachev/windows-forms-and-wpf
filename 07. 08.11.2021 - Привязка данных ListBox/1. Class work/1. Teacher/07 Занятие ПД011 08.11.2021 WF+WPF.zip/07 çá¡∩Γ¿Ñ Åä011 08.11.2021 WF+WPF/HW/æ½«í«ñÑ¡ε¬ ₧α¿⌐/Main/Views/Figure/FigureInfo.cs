﻿using System.Drawing;
using System.Windows.Forms;
using Main.Controls;


namespace Main.Views.Figure
{
	public readonly struct FigureInfo
	{
		public UserControl Input { get; }
		public string Name { get; }
		public Bitmap Picture { get; }


		public FigureInfo(UserControl input, string name, Bitmap picture)
		{
			Input   = input;
			Name    = name;
			Picture = picture;
		}
	}
}