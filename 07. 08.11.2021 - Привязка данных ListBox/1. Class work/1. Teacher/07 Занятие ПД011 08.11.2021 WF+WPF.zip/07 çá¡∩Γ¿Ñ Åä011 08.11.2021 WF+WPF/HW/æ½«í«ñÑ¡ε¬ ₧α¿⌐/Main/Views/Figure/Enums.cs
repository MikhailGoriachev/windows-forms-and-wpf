﻿using System;


namespace Main.Views.Figure
{
	[Flags]
	public enum SolverOptions
	{
		Volume = 1, 
		Area = 2, 
		Massa = 4
	}


	public enum MaterialType
	{
		Steel, Copper, WaterIce, Granite
	}
}