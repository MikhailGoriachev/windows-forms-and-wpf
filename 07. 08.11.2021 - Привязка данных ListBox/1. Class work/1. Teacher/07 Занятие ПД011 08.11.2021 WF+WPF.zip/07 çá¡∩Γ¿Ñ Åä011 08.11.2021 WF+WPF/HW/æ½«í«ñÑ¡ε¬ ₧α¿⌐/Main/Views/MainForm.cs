﻿using System;
using System.Windows.Forms;
using Main.Common;
using Main.Models;


namespace Main.Views
{
	internal interface IMainView : IView
	{
		Panel FormContainer { get; }

		event Action<Type> FigureFormRequested;
		event Action ListBoxesRequested;
		event Action LogClearRequested;
		event Action LogViewRequested;
	}


	public sealed partial class MainForm : BaseForm, IMainView
	{
		private readonly ApplicationContext _context;

		public Panel FormContainer => FormsPanel;


		public MainForm(ApplicationContext context)
		{
			_context = context;
			InitializeComponent();

			CylinderToolStrip.Tag        = typeof(Cylinder);
			SphereToolStrip.Tag          = typeof(Sphere);
			ParallelepipedToolStrip.Tag  = typeof(Parallelepiped);
			TruncatedConoidToolStrip.Tag = typeof(TruncatedConoid);
		}


		public event Action<Type> FigureFormRequested;
		public event Action ListBoxesRequested;
		public event Action LogClearRequested;
		public event Action LogViewRequested;


		public new void Show()
		{
			_context.MainForm = this;
			Application.Run(_context);
		}


		private void OnFigureFormRequested(object sender, EventArgs e) =>
			FigureFormRequested?.Invoke((sender as ToolStripMenuItem).Tag as Type);


		private void OnListBoxesRequested(object sender, EventArgs e) =>
			ListBoxesRequested?.Invoke();


		private void OnLogClearRequested(object sender, EventArgs e) =>
			LogClearRequested?.Invoke();


		private void OnLogViewRequested(object sender, EventArgs e) =>
			LogViewRequested?.Invoke();
	}
}