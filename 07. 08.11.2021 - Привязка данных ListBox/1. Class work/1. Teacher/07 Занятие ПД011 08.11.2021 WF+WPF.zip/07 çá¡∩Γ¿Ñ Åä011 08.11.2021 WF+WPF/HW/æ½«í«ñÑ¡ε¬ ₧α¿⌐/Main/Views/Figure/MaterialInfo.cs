﻿using System.Drawing;


namespace Main.Views.Figure
{
	public readonly struct MaterialInfo
	{
		public double Density { get; }
		public Bitmap Image { get; }


		public MaterialInfo(double density, Bitmap image)
		{
			Density = density;
			Image   = image;
		}
	}
}