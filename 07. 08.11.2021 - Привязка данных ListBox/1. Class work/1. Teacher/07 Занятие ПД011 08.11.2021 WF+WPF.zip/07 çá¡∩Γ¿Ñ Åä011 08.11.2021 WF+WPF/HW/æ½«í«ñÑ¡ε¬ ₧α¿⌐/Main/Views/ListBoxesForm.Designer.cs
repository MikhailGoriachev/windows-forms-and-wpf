﻿
namespace Main.Views
{
	sealed partial class ListBoxesForm
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.BoxesSplitContainer = new System.Windows.Forms.SplitContainer();
			this.LeftListBox = new System.Windows.Forms.ListBox();
			this.RightListBox = new System.Windows.Forms.ListBox();
			this.CommandsFlowPanel = new System.Windows.Forms.FlowLayoutPanel();
			this.MoveLeftToRightButton = new System.Windows.Forms.Button();
			this.MoveAllLeftToRightButton = new System.Windows.Forms.Button();
			this.MoveRightToLeftButton = new System.Windows.Forms.Button();
			this.MoveAllRightToLeftButton = new System.Windows.Forms.Button();
			this.ClearAllButton = new System.Windows.Forms.Button();
			this.AddWithTextBoxSplitContainer = new System.Windows.Forms.SplitContainer();
			this.InputTextBox = new System.Windows.Forms.TextBox();
			this.AddToLeftButton = new System.Windows.Forms.Button();
			this.AddWithComboBoxSplitContainer = new System.Windows.Forms.SplitContainer();
			this.InputComboBox = new System.Windows.Forms.ComboBox();
			this.AddToRightButton = new System.Windows.Forms.Button();
			((System.ComponentModel.ISupportInitialize)(this.BoxesSplitContainer)).BeginInit();
			this.BoxesSplitContainer.Panel1.SuspendLayout();
			this.BoxesSplitContainer.Panel2.SuspendLayout();
			this.BoxesSplitContainer.SuspendLayout();
			this.CommandsFlowPanel.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.AddWithTextBoxSplitContainer)).BeginInit();
			this.AddWithTextBoxSplitContainer.Panel1.SuspendLayout();
			this.AddWithTextBoxSplitContainer.Panel2.SuspendLayout();
			this.AddWithTextBoxSplitContainer.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.AddWithComboBoxSplitContainer)).BeginInit();
			this.AddWithComboBoxSplitContainer.Panel1.SuspendLayout();
			this.AddWithComboBoxSplitContainer.Panel2.SuspendLayout();
			this.AddWithComboBoxSplitContainer.SuspendLayout();
			this.SuspendLayout();
			// 
			// BoxesSplitContainer
			// 
			this.BoxesSplitContainer.Cursor = System.Windows.Forms.Cursors.VSplit;
			this.BoxesSplitContainer.Dock = System.Windows.Forms.DockStyle.Top;
			this.BoxesSplitContainer.IsSplitterFixed = true;
			this.BoxesSplitContainer.Location = new System.Drawing.Point(0, 0);
			this.BoxesSplitContainer.Name = "BoxesSplitContainer";
			// 
			// BoxesSplitContainer.Panel1
			// 
			this.BoxesSplitContainer.Panel1.Controls.Add(this.LeftListBox);
			// 
			// BoxesSplitContainer.Panel2
			// 
			this.BoxesSplitContainer.Panel2.Controls.Add(this.RightListBox);
			this.BoxesSplitContainer.Size = new System.Drawing.Size(919, 224);
			this.BoxesSplitContainer.SplitterDistance = 428;
			this.BoxesSplitContainer.TabIndex = 0;
			// 
			// LeftListBox
			// 
			this.LeftListBox.Dock = System.Windows.Forms.DockStyle.Fill;
			this.LeftListBox.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
			this.LeftListBox.FormattingEnabled = true;
			this.LeftListBox.ItemHeight = 21;
			this.LeftListBox.Location = new System.Drawing.Point(0, 0);
			this.LeftListBox.Name = "LeftListBox";
			this.LeftListBox.Size = new System.Drawing.Size(428, 224);
			this.LeftListBox.TabIndex = 2;
			// 
			// RightListBox
			// 
			this.RightListBox.Dock = System.Windows.Forms.DockStyle.Fill;
			this.RightListBox.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
			this.RightListBox.FormattingEnabled = true;
			this.RightListBox.ItemHeight = 21;
			this.RightListBox.Location = new System.Drawing.Point(0, 0);
			this.RightListBox.Name = "RightListBox";
			this.RightListBox.Size = new System.Drawing.Size(487, 224);
			this.RightListBox.TabIndex = 1;
			// 
			// CommandsFlowPanel
			// 
			this.CommandsFlowPanel.Controls.Add(this.MoveLeftToRightButton);
			this.CommandsFlowPanel.Controls.Add(this.MoveAllLeftToRightButton);
			this.CommandsFlowPanel.Controls.Add(this.MoveRightToLeftButton);
			this.CommandsFlowPanel.Controls.Add(this.MoveAllRightToLeftButton);
			this.CommandsFlowPanel.Controls.Add(this.ClearAllButton);
			this.CommandsFlowPanel.Controls.Add(this.AddWithTextBoxSplitContainer);
			this.CommandsFlowPanel.Controls.Add(this.AddWithComboBoxSplitContainer);
			this.CommandsFlowPanel.Dock = System.Windows.Forms.DockStyle.Fill;
			this.CommandsFlowPanel.Location = new System.Drawing.Point(0, 224);
			this.CommandsFlowPanel.Name = "CommandsFlowPanel";
			this.CommandsFlowPanel.Size = new System.Drawing.Size(919, 208);
			this.CommandsFlowPanel.TabIndex = 1;
			// 
			// MoveLeftToRightButton
			// 
			this.MoveLeftToRightButton.AutoSize = true;
			this.MoveLeftToRightButton.Location = new System.Drawing.Point(3, 3);
			this.MoveLeftToRightButton.Name = "MoveLeftToRightButton";
			this.MoveLeftToRightButton.Size = new System.Drawing.Size(207, 69);
			this.MoveLeftToRightButton.TabIndex = 0;
			this.MoveLeftToRightButton.Text = "Перемещение из левого в правый";
			this.MoveLeftToRightButton.UseVisualStyleBackColor = true;
			this.MoveLeftToRightButton.Click += new System.EventHandler(this.OnMoveSingleFromLeftToRight);
			// 
			// MoveAllLeftToRightButton
			// 
			this.MoveAllLeftToRightButton.AutoSize = true;
			this.MoveAllLeftToRightButton.Location = new System.Drawing.Point(216, 3);
			this.MoveAllLeftToRightButton.Name = "MoveAllLeftToRightButton";
			this.MoveAllLeftToRightButton.Size = new System.Drawing.Size(234, 69);
			this.MoveAllLeftToRightButton.TabIndex = 1;
			this.MoveAllLeftToRightButton.Text = "Перемещение всех из левого в правый";
			this.MoveAllLeftToRightButton.UseVisualStyleBackColor = true;
			this.MoveAllLeftToRightButton.Click += new System.EventHandler(this.OnMoveAllFromLeftToRight);
			// 
			// MoveRightToLeftButton
			// 
			this.MoveRightToLeftButton.AutoSize = true;
			this.MoveRightToLeftButton.Location = new System.Drawing.Point(456, 3);
			this.MoveRightToLeftButton.Name = "MoveRightToLeftButton";
			this.MoveRightToLeftButton.Size = new System.Drawing.Size(207, 69);
			this.MoveRightToLeftButton.TabIndex = 2;
			this.MoveRightToLeftButton.Text = "Перемещение из правого в левый";
			this.MoveRightToLeftButton.UseVisualStyleBackColor = true;
			this.MoveRightToLeftButton.Click += new System.EventHandler(this.OnMoveSingleFromRightToLeft);
			// 
			// MoveAllRightToLeftButton
			// 
			this.MoveAllRightToLeftButton.AutoSize = true;
			this.MoveAllRightToLeftButton.Location = new System.Drawing.Point(669, 3);
			this.MoveAllRightToLeftButton.Name = "MoveAllRightToLeftButton";
			this.MoveAllRightToLeftButton.Size = new System.Drawing.Size(234, 69);
			this.MoveAllRightToLeftButton.TabIndex = 3;
			this.MoveAllRightToLeftButton.Text = "Перемещение всех из правого в левый";
			this.MoveAllRightToLeftButton.UseVisualStyleBackColor = true;
			this.MoveAllRightToLeftButton.Click += new System.EventHandler(this.OnMoveAllFromRightToLeft);
			// 
			// ClearAllButton
			// 
			this.ClearAllButton.AutoSize = true;
			this.ClearAllButton.Location = new System.Drawing.Point(3, 78);
			this.ClearAllButton.Name = "ClearAllButton";
			this.ClearAllButton.Size = new System.Drawing.Size(234, 69);
			this.ClearAllButton.TabIndex = 4;
			this.ClearAllButton.Text = "Очистка обоих";
			this.ClearAllButton.UseVisualStyleBackColor = true;
			this.ClearAllButton.Click += new System.EventHandler(this.OnClearAll);
			// 
			// AddWithTextBoxSplitContainer
			// 
			this.AddWithTextBoxSplitContainer.Cursor = System.Windows.Forms.Cursors.HSplit;
			this.AddWithTextBoxSplitContainer.IsSplitterFixed = true;
			this.AddWithTextBoxSplitContainer.Location = new System.Drawing.Point(243, 78);
			this.AddWithTextBoxSplitContainer.Name = "AddWithTextBoxSplitContainer";
			this.AddWithTextBoxSplitContainer.Orientation = System.Windows.Forms.Orientation.Horizontal;
			// 
			// AddWithTextBoxSplitContainer.Panel1
			// 
			this.AddWithTextBoxSplitContainer.Panel1.Controls.Add(this.InputTextBox);
			// 
			// AddWithTextBoxSplitContainer.Panel2
			// 
			this.AddWithTextBoxSplitContainer.Panel2.Controls.Add(this.AddToLeftButton);
			this.AddWithTextBoxSplitContainer.Size = new System.Drawing.Size(250, 100);
			this.AddWithTextBoxSplitContainer.SplitterDistance = 37;
			this.AddWithTextBoxSplitContainer.TabIndex = 7;
			// 
			// InputTextBox
			// 
			this.InputTextBox.Dock = System.Windows.Forms.DockStyle.Fill;
			this.InputTextBox.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
			this.InputTextBox.Location = new System.Drawing.Point(0, 0);
			this.InputTextBox.Name = "InputTextBox";
			this.InputTextBox.Size = new System.Drawing.Size(250, 33);
			this.InputTextBox.TabIndex = 5;
			// 
			// AddToLeftButton
			// 
			this.AddToLeftButton.AutoSize = true;
			this.AddToLeftButton.Dock = System.Windows.Forms.DockStyle.Fill;
			this.AddToLeftButton.Location = new System.Drawing.Point(0, 0);
			this.AddToLeftButton.Name = "AddToLeftButton";
			this.AddToLeftButton.Size = new System.Drawing.Size(250, 59);
			this.AddToLeftButton.TabIndex = 9;
			this.AddToLeftButton.Text = "Добавить в левый";
			this.AddToLeftButton.UseVisualStyleBackColor = true;
			this.AddToLeftButton.Click += new System.EventHandler(this.OnAddToLeft);
			// 
			// AddWithComboBoxSplitContainer
			// 
			this.AddWithComboBoxSplitContainer.Cursor = System.Windows.Forms.Cursors.HSplit;
			this.AddWithComboBoxSplitContainer.IsSplitterFixed = true;
			this.AddWithComboBoxSplitContainer.Location = new System.Drawing.Point(499, 78);
			this.AddWithComboBoxSplitContainer.Name = "AddWithComboBoxSplitContainer";
			this.AddWithComboBoxSplitContainer.Orientation = System.Windows.Forms.Orientation.Horizontal;
			// 
			// AddWithComboBoxSplitContainer.Panel1
			// 
			this.AddWithComboBoxSplitContainer.Panel1.Controls.Add(this.InputComboBox);
			// 
			// AddWithComboBoxSplitContainer.Panel2
			// 
			this.AddWithComboBoxSplitContainer.Panel2.Controls.Add(this.AddToRightButton);
			this.AddWithComboBoxSplitContainer.Size = new System.Drawing.Size(250, 100);
			this.AddWithComboBoxSplitContainer.SplitterDistance = 37;
			this.AddWithComboBoxSplitContainer.TabIndex = 8;
			// 
			// InputComboBox
			// 
			this.InputComboBox.Dock = System.Windows.Forms.DockStyle.Fill;
			this.InputComboBox.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
			this.InputComboBox.FormattingEnabled = true;
			this.InputComboBox.Location = new System.Drawing.Point(0, 0);
			this.InputComboBox.Name = "InputComboBox";
			this.InputComboBox.Size = new System.Drawing.Size(250, 33);
			this.InputComboBox.TabIndex = 6;
			this.InputComboBox.SelectedIndexChanged += new System.EventHandler(this.OnAddToRight);
			// 
			// AddToRightButton
			// 
			this.AddToRightButton.AutoSize = true;
			this.AddToRightButton.Dock = System.Windows.Forms.DockStyle.Fill;
			this.AddToRightButton.Location = new System.Drawing.Point(0, 0);
			this.AddToRightButton.Name = "AddToRightButton";
			this.AddToRightButton.Size = new System.Drawing.Size(250, 59);
			this.AddToRightButton.TabIndex = 10;
			this.AddToRightButton.Text = "Добавить в правый";
			this.AddToRightButton.UseVisualStyleBackColor = true;
			this.AddToRightButton.Click += new System.EventHandler(this.OnAddToRight);
			// 
			// ListBoxesForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.AutoSize = true;
			this.ClientSize = new System.Drawing.Size(919, 432);
			this.Controls.Add(this.CommandsFlowPanel);
			this.Controls.Add(this.BoxesSplitContainer);
			this.Name = "ListBoxesForm";
			this.ShowInTaskbar = false;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "ListBoxesForm";
			this.BoxesSplitContainer.Panel1.ResumeLayout(false);
			this.BoxesSplitContainer.Panel2.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.BoxesSplitContainer)).EndInit();
			this.BoxesSplitContainer.ResumeLayout(false);
			this.CommandsFlowPanel.ResumeLayout(false);
			this.CommandsFlowPanel.PerformLayout();
			this.AddWithTextBoxSplitContainer.Panel1.ResumeLayout(false);
			this.AddWithTextBoxSplitContainer.Panel1.PerformLayout();
			this.AddWithTextBoxSplitContainer.Panel2.ResumeLayout(false);
			this.AddWithTextBoxSplitContainer.Panel2.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.AddWithTextBoxSplitContainer)).EndInit();
			this.AddWithTextBoxSplitContainer.ResumeLayout(false);
			this.AddWithComboBoxSplitContainer.Panel1.ResumeLayout(false);
			this.AddWithComboBoxSplitContainer.Panel2.ResumeLayout(false);
			this.AddWithComboBoxSplitContainer.Panel2.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.AddWithComboBoxSplitContainer)).EndInit();
			this.AddWithComboBoxSplitContainer.ResumeLayout(false);
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.SplitContainer BoxesSplitContainer;
		private System.Windows.Forms.FlowLayoutPanel CommandsFlowPanel;
		private System.Windows.Forms.ListBox LeftListBox;
		private System.Windows.Forms.ListBox RightListBox;
		private System.Windows.Forms.Button MoveLeftToRightButton;
		private System.Windows.Forms.Button MoveAllLeftToRightButton;
		private System.Windows.Forms.Button MoveRightToLeftButton;
		private System.Windows.Forms.Button MoveAllRightToLeftButton;
		private System.Windows.Forms.Button ClearAllButton;
		private System.Windows.Forms.TextBox InputTextBox;
		private System.Windows.Forms.ComboBox InputComboBox;
		private System.Windows.Forms.SplitContainer AddWithTextBoxSplitContainer;
		private System.Windows.Forms.Button AddToLeftButton;
		private System.Windows.Forms.SplitContainer AddWithComboBoxSplitContainer;
		private System.Windows.Forms.Button AddToRightButton;
	}
}