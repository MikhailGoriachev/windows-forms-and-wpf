using System;
using System.Windows.Forms;
using Main.ApplicationControl;
using Main.Presenters;


namespace Main
{
	internal static class Program
	{
		[STAThread]
		private static void Main()
		{
			Application.SetHighDpiMode(HighDpiMode.SystemAware);
			Application.EnableVisualStyles();
			Application.SetCompatibleTextRenderingDefault(false);

			try
			{
				new ApplicationController().Run<MainPresenter>();
			}
			catch (Exception e)
			{
				MessageBox.Show(e.ToString(),
					"Error has occured",
					MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
		}
	}
}