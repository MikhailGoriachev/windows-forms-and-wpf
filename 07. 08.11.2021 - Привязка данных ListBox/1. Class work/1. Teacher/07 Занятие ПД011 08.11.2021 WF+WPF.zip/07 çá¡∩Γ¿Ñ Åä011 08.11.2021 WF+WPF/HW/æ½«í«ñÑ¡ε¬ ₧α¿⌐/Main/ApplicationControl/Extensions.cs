﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using Main.Views.Figure;
using Microsoft.Extensions.Configuration;
using Serilog;


namespace Main.ApplicationControl
{
	internal static class Extensions
	{
		public static string GetFilePathForSerilog(this IConfiguration configuration) =>
			configuration.GetValue<string>("Serilog:WriteTo:0:Args:path");


		public static FileStream GetSharedWithLoggerFile(this ILogger logger, string path) =>
			File.Open(path, FileMode.Open, FileAccess.ReadWrite, FileShare.ReadWrite);


		public static bool HasFlagFast(this SolverOptions value, SolverOptions flag)
		{
			return (value & flag) != 0;
		}


		public static void SetNumericsToDefault(this Control container, 
			decimal min = 0m, decimal max = decimal.MaxValue)
		{
			foreach (var numericUpDown in container.Controls.OfType<NumericUpDown>())
			{
				numericUpDown.Minimum = min;
				numericUpDown.Maximum = max;
			}
		}
	}
}