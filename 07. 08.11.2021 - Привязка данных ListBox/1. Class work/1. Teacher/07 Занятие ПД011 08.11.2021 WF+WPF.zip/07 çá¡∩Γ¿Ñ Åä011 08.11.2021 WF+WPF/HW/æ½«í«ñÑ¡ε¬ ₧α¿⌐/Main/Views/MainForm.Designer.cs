﻿
namespace Main.Views
{
	sealed partial class MainForm
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.MenuBar = new System.Windows.Forms.MenuStrip();
			this.FiguresToolStrip = new System.Windows.Forms.ToolStripMenuItem();
			this.CylinderToolStrip = new System.Windows.Forms.ToolStripMenuItem();
			this.ParallelepipedToolStrip = new System.Windows.Forms.ToolStripMenuItem();
			this.SphereToolStrip = new System.Windows.Forms.ToolStripMenuItem();
			this.TruncatedConoidToolStrip = new System.Windows.Forms.ToolStripMenuItem();
			this.LogToolStrip = new System.Windows.Forms.ToolStripMenuItem();
			this.LogViewToolStrip = new System.Windows.Forms.ToolStripMenuItem();
			this.LogClearToolStrip = new System.Windows.Forms.ToolStripMenuItem();
			this.FormsPanel = new System.Windows.Forms.Panel();
			this.ListBoxesToolStrip = new System.Windows.Forms.ToolStripMenuItem();
			this.MenuBar.SuspendLayout();
			this.SuspendLayout();
			// 
			// MenuBar
			// 
			this.MenuBar.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.FiguresToolStrip,
            this.LogToolStrip,
            this.ListBoxesToolStrip});
			this.MenuBar.Location = new System.Drawing.Point(0, 0);
			this.MenuBar.Name = "MenuBar";
			this.MenuBar.Padding = new System.Windows.Forms.Padding(7, 3, 0, 3);
			this.MenuBar.Size = new System.Drawing.Size(980, 25);
			this.MenuBar.TabIndex = 0;
			this.MenuBar.Text = "menuStrip1";
			// 
			// FiguresToolStrip
			// 
			this.FiguresToolStrip.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.CylinderToolStrip,
            this.ParallelepipedToolStrip,
            this.SphereToolStrip,
            this.TruncatedConoidToolStrip});
			this.FiguresToolStrip.Name = "FiguresToolStrip";
			this.FiguresToolStrip.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.F)));
			this.FiguresToolStrip.Size = new System.Drawing.Size(106, 19);
			this.FiguresToolStrip.Text = "Объемные тела";
			// 
			// CylinderToolStrip
			// 
			this.CylinderToolStrip.Name = "CylinderToolStrip";
			this.CylinderToolStrip.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.C)));
			this.CylinderToolStrip.Size = new System.Drawing.Size(302, 22);
			this.CylinderToolStrip.Text = "Цилиндр";
			this.CylinderToolStrip.Click += new System.EventHandler(this.OnFigureFormRequested);
			// 
			// ParallelepipedToolStrip
			// 
			this.ParallelepipedToolStrip.Name = "ParallelepipedToolStrip";
			this.ParallelepipedToolStrip.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.P)));
			this.ParallelepipedToolStrip.Size = new System.Drawing.Size(302, 22);
			this.ParallelepipedToolStrip.Text = "Прямоугольный параллелепипед";
			this.ParallelepipedToolStrip.Click += new System.EventHandler(this.OnFigureFormRequested);
			// 
			// SphereToolStrip
			// 
			this.SphereToolStrip.Name = "SphereToolStrip";
			this.SphereToolStrip.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.S)));
			this.SphereToolStrip.Size = new System.Drawing.Size(302, 22);
			this.SphereToolStrip.Text = "Сфера";
			this.SphereToolStrip.Click += new System.EventHandler(this.OnFigureFormRequested);
			// 
			// TruncatedConoidToolStrip
			// 
			this.TruncatedConoidToolStrip.Name = "TruncatedConoidToolStrip";
			this.TruncatedConoidToolStrip.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.T)));
			this.TruncatedConoidToolStrip.Size = new System.Drawing.Size(302, 22);
			this.TruncatedConoidToolStrip.Text = "Усеченный конус";
			this.TruncatedConoidToolStrip.Click += new System.EventHandler(this.OnFigureFormRequested);
			// 
			// LogToolStrip
			// 
			this.LogToolStrip.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.LogViewToolStrip,
            this.LogClearToolStrip});
			this.LogToolStrip.Name = "LogToolStrip";
			this.LogToolStrip.Size = new System.Drawing.Size(63, 19);
			this.LogToolStrip.Text = "Журнал";
			// 
			// LogViewToolStrip
			// 
			this.LogViewToolStrip.Name = "LogViewToolStrip";
			this.LogViewToolStrip.Size = new System.Drawing.Size(131, 22);
			this.LogViewToolStrip.Text = "Просмотр";
			this.LogViewToolStrip.Click += new System.EventHandler(this.OnLogViewRequested);
			// 
			// LogClearToolStrip
			// 
			this.LogClearToolStrip.Name = "LogClearToolStrip";
			this.LogClearToolStrip.Size = new System.Drawing.Size(131, 22);
			this.LogClearToolStrip.Text = "Очистка";
			this.LogClearToolStrip.Click += new System.EventHandler(this.OnLogClearRequested);
			// 
			// FormsPanel
			// 
			this.FormsPanel.Dock = System.Windows.Forms.DockStyle.Fill;
			this.FormsPanel.Location = new System.Drawing.Point(0, 25);
			this.FormsPanel.Name = "FormsPanel";
			this.FormsPanel.Size = new System.Drawing.Size(980, 466);
			this.FormsPanel.TabIndex = 1;
			// 
			// ListBoxesToolStrip
			// 
			this.ListBoxesToolStrip.Name = "ListBoxesToolStrip";
			this.ListBoxesToolStrip.Size = new System.Drawing.Size(60, 19);
			this.ListBoxesToolStrip.Text = "Списки";
			this.ListBoxesToolStrip.Click += new System.EventHandler(this.OnListBoxesRequested);
			// 
			// MainForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(980, 491);
			this.Controls.Add(this.FormsPanel);
			this.Controls.Add(this.MenuBar);
			this.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
			this.MainMenuStrip = this.MenuBar;
			this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.Name = "MainForm";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Главная форма";
			this.MenuBar.ResumeLayout(false);
			this.MenuBar.PerformLayout();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.MenuStrip MenuBar;
		private System.Windows.Forms.ToolStripMenuItem FiguresToolStrip;
		private System.Windows.Forms.ToolStripMenuItem CylinderToolStrip;
		private System.Windows.Forms.ToolStripMenuItem ParallelepipedToolStrip;
		private System.Windows.Forms.ToolStripMenuItem SphereToolStrip;
		private System.Windows.Forms.ToolStripMenuItem TruncatedConoidToolStrip;
		private System.Windows.Forms.Panel FormsPanel;
		private System.Windows.Forms.ToolStripMenuItem LogToolStrip;
		private System.Windows.Forms.ToolStripMenuItem LogViewToolStrip;
		private System.Windows.Forms.ToolStripMenuItem LogClearToolStrip;
		private System.Windows.Forms.ToolStripMenuItem ListBoxesToolStrip;
	}
}