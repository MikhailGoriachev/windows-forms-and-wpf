﻿using System.Collections.Generic;
using Main.Controls;
using Main.Models;
using Main.Properties;


namespace Main.Views.Figure
{
	internal sealed class Storage
	{
		private readonly Dictionary<MaterialType, MaterialInfo> _materials = new()
		{
			[MaterialType.Steel]    = new(7800d, Resources.Steel),
			[MaterialType.Copper]   = new(920d, Resources.Copper),
			[MaterialType.WaterIce] = new(900d, Resources.WaterIce),
			[MaterialType.Granite]  = new(2700d, Resources.Granite)
		};


		public FigureInfo GetFigureInfoByType(IFigure figure) => figure switch
		{
			Cylinder c => new(new CylinderInputControl(c),
				"Цилиндр", Resources.CylinderImage),

			Parallelepiped p => new(new ParallelepipedInputControl(p),
				"Параллелепипед", Resources.ParallelepipedImage),

			Sphere s => new(new SphereInputControl(s),
				"Сфера", Resources.SphereImage),

			TruncatedConoid t => new(new TruncatedConoidInputControl(t),
				"Усеченный конус", Resources.TruncatedConoidImage),

			_ => throw new($"Фигура {figure.GetType().FullName} не имеет настроек в {typeof(Storage).FullName}")
		};


		public MaterialInfo GetMaterialInfoByType(MaterialType type) => _materials[type];
	}
}