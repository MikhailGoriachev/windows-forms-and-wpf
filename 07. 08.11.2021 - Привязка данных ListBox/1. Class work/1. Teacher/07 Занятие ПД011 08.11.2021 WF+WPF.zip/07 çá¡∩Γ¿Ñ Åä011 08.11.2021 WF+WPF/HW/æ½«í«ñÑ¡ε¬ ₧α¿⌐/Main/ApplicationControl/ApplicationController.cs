﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Windows.Forms;
using Autofac;
using Autofac.Features.ResolveAnything;
using Main.Common;
using Microsoft.Extensions.Configuration;
using Serilog;


namespace Main.ApplicationControl
{
	internal sealed class ApplicationController : IApplicationController
	{
		private IContainer Container { get; }
		public IConfiguration AppConfig { get; }
		public ILogger AppLogger { get; }



		public ApplicationController()
		{
			Container = PrepareDependencies();
			AppConfig = GetConfigurationOfApplication();
			AppLogger = CreateJsonLogger();
		}


		public TPresenter Run<TPresenter>() where TPresenter : IPresenter
		{
			var presenter = Container.Resolve<TPresenter>();

			presenter.Run();

			return presenter;
		}


		public TPresenter Run<TPresenter>(Action<Form> onStartup) where TPresenter : IPresenter
		{
			var presenter = Container.Resolve<TPresenter>();

			presenter.Run(onStartup);

			return presenter;
		}


		private IContainer PrepareDependencies()
		{
			var builder = new ContainerBuilder();

			builder.RegisterInstance(this).As<IApplicationController>();
			builder.RegisterInstance(new ApplicationContext()).AsSelf();

			foreach (var (form, view) in SelectFormWithView())
				builder.RegisterType(form).As(view);

			builder.RegisterSource<AnyConcreteTypeNotAlreadyRegisteredSource>();
			return builder.Build();
		}


		private IEnumerable<(Type Form, Type View)> SelectFormWithView() =>
			Assembly.GetExecutingAssembly()
					.GetTypes()
					.Where(t => t.BaseType == typeof(BaseForm))
					.Select(t =>
						(
							Form: t,
							View: t.GetInterfaces()
								   .FirstOrDefault(i => i.GetInterfaces().Contains(typeof(IView)))
								  ?? throw new($"Форма {t.FullName} не реализует {typeof(IView)}")
						));


		private IConfiguration GetConfigurationOfApplication() =>
			new ConfigurationBuilder()
				.SetBasePath(Directory.GetCurrentDirectory())
				.AddJsonFile("AppSettings.json")
				.Build();


		private ILogger CreateJsonLogger() =>
			new LoggerConfiguration()
				.ReadFrom.Configuration(AppConfig)
				.CreateLogger();
	}
}