﻿using System;
using System.ComponentModel;
using System.Linq;
using Main.Common;


namespace Main.Views
{
	internal interface IListBoxesView : IView
	{
		BindingList<string> LeftList { get; }
		BindingList<string> RightList { get; }

		event Action<string> AddToLeft;
		event Action<string> AddToRight;
		event Action ClearAll;

		event Action MoveAllFromLeftToRight;
		event Action MoveAllFromRightToLeft;

		event Action<int> MoveSingleFromLeftToRight;
		event Action<int> MoveSingleFromRightToLeft;
	}


	public sealed partial class ListBoxesForm : BaseForm, IListBoxesView
	{
		public BindingList<string> LeftList { get; } = new()
		{
			"Берлин", "Париж", "Вена", "Копенгаген", "Сингапур", "Рим",
			"Венеция", "Константинополь", "Иерусалим", "Мекка", "Тегеран",
			"Лиссабон", "Бостон", "Сидней", "Мемфис", "Мадрид",
			"Тунис", "Амстердам"
		};
		public BindingList<string> RightList { get; } = new();


		public ListBoxesForm()
		{
			InitializeComponent();

			InputComboBox.DataSource = LeftList.ToArray();

			LeftListBox.DataSource  = LeftList;
			RightListBox.DataSource = RightList;
		}


		public event Action<string> AddToLeft;
		public event Action<string> AddToRight;
		public event Action ClearAll;

		public event Action MoveAllFromLeftToRight;
		public event Action MoveAllFromRightToLeft;

		public event Action<int> MoveSingleFromLeftToRight;
		public event Action<int> MoveSingleFromRightToLeft;


		public new void Show() => ShowDialog();


		private void OnAddToLeft(object sender, EventArgs e) =>
			AddToLeft?.Invoke(InputTextBox.Text);


		private void OnAddToRight(object sender, EventArgs e) =>
			AddToRight?.Invoke((string)InputComboBox.SelectedItem);


		private void OnClearAll(object sender, EventArgs e) =>
			ClearAll?.Invoke();


		private void OnMoveAllFromLeftToRight(object sender, EventArgs e) =>
			MoveAllFromLeftToRight?.Invoke();


		private void OnMoveAllFromRightToLeft(object sender, EventArgs e) =>
			MoveAllFromRightToLeft?.Invoke();


		private void OnMoveSingleFromLeftToRight(object sender, EventArgs e) =>
			MoveSingleFromLeftToRight?.Invoke(LeftListBox.SelectedIndex);


		private void OnMoveSingleFromRightToLeft(object sender, EventArgs e) =>
			MoveSingleFromRightToLeft?.Invoke(RightListBox.SelectedIndex);
	}
}