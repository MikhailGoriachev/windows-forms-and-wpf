﻿using System.Windows.Forms;
using Main.ApplicationControl;
using Main.Models;


namespace Main.Controls
{
	public sealed partial class ParallelepipedInputControl : UserControl
	{
		public ParallelepipedInputControl(Parallelepiped par)
		{
			InitializeComponent();
			MainGrid.SetNumericsToDefault();

			ASideNumeric
				.DataBindings
				.Add("Value", par, "A");

			BSideNumeric
				.DataBindings
				.Add("Value", par, "B");

			CSideNumeric
				.DataBindings
				.Add("Value", par, "C");
		}
	}
}