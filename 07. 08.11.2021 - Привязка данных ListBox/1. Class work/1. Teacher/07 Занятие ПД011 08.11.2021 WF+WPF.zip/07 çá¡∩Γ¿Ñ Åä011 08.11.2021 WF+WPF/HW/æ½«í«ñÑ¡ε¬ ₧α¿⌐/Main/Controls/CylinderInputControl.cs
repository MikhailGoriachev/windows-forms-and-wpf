﻿using System.Windows.Forms;
using Main.ApplicationControl;
using Main.Models;


namespace Main.Controls
{
	public sealed partial class CylinderInputControl : UserControl
	{
		public CylinderInputControl(Cylinder cylinder)
		{
			InitializeComponent();
			MainGrid.SetNumericsToDefault();	
			
			HeightNumeric
				.DataBindings
				.Add("Value", cylinder, "Height");

			RadiusNumeric
				.DataBindings
				.Add("Value", cylinder, "Radius");
		}
	}
}