﻿
namespace Main.Controls
{
	sealed partial class SphereInputControl
	{
		/// <summary> 
		/// Обязательная переменная конструктора.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary> 
		/// Освободить все используемые ресурсы.
		/// </summary>
		/// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Код, автоматически созданный конструктором компонентов

		/// <summary> 
		/// Требуемый метод для поддержки конструктора — не изменяйте 
		/// содержимое этого метода с помощью редактора кода.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			this.MainGrid = new System.Windows.Forms.TableLayoutPanel();
			this.RadiusLabel = new System.Windows.Forms.Label();
			this.MainErrorProvider = new System.Windows.Forms.ErrorProvider(this.components);
			this.RadiusNumeric = new System.Windows.Forms.NumericUpDown();
			this.MainGrid.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.MainErrorProvider)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.RadiusNumeric)).BeginInit();
			this.SuspendLayout();
			// 
			// MainGrid
			// 
			this.MainGrid.ColumnCount = 2;
			this.MainGrid.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 43.20713F));
			this.MainGrid.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 56.79287F));
			this.MainGrid.Controls.Add(this.RadiusNumeric, 0, 1);
			this.MainGrid.Controls.Add(this.RadiusLabel, 0, 1);
			this.MainGrid.Dock = System.Windows.Forms.DockStyle.Fill;
			this.MainGrid.Location = new System.Drawing.Point(0, 0);
			this.MainGrid.Name = "MainGrid";
			this.MainGrid.RowCount = 2;
			this.MainGrid.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 41.77632F));
			this.MainGrid.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 58.22368F));
			this.MainGrid.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
			this.MainGrid.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
			this.MainGrid.Size = new System.Drawing.Size(449, 224);
			this.MainGrid.TabIndex = 1;
			// 
			// RadiusLabel
			// 
			this.RadiusLabel.Dock = System.Windows.Forms.DockStyle.Top;
			this.RadiusLabel.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
			this.RadiusLabel.Location = new System.Drawing.Point(3, 93);
			this.RadiusLabel.Name = "RadiusLabel";
			this.RadiusLabel.Size = new System.Drawing.Size(188, 34);
			this.RadiusLabel.TabIndex = 4;
			this.RadiusLabel.Text = "Радиус";
			this.RadiusLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// MainErrorProvider
			// 
			this.MainErrorProvider.ContainerControl = this;
			this.MainErrorProvider.RightToLeft = true;
			// 
			// RadiusNumeric
			// 
			this.RadiusNumeric.Dock = System.Windows.Forms.DockStyle.Top;
			this.RadiusNumeric.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
			this.RadiusNumeric.Location = new System.Drawing.Point(197, 96);
			this.RadiusNumeric.Name = "RadiusNumeric";
			this.RadiusNumeric.Size = new System.Drawing.Size(249, 29);
			this.RadiusNumeric.TabIndex = 10;
			// 
			// SphereInputControl
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.Controls.Add(this.MainGrid);
			this.Name = "SphereInputControl";
			this.Size = new System.Drawing.Size(449, 224);
			this.MainGrid.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.MainErrorProvider)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.RadiusNumeric)).EndInit();
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.TableLayoutPanel MainGrid;
		private System.Windows.Forms.Label RadiusLabel;
		private System.Windows.Forms.ErrorProvider MainErrorProvider;
		private System.Windows.Forms.NumericUpDown RadiusNumeric;
	}
}
