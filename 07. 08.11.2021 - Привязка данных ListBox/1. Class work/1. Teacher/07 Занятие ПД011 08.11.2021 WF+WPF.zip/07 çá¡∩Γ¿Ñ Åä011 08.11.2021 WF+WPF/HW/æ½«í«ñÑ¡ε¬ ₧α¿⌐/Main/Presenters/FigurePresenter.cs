﻿using System;
using Main.ApplicationControl;
using Main.Common;
using Main.Models;
using Main.Views.Figure;


namespace Main.Presenters
{
	internal sealed class FigurePresenter : BasePresenter<IFigureView>
	{
		private IFigure _figure;
		private SolverOptions _options;
		private readonly Storage _storage = new();


		public FigurePresenter(IFigureView view, IApplicationController controller)
			: base(view, controller)
		{
			View.MaterialCnahgeRequested += ViewOnMaterialCnahgeRequested;
			View.SolveRequested          += ViewOnSolveRequested;
			View.OptionsChanged          += ViewOnOptionsChanged;
		}


		private void ViewOnMaterialCnahgeRequested(MaterialType requestedMaterial)
		{
			var material = _storage.GetMaterialInfoByType(requestedMaterial);

			_figure.Density = material.Density;
			View.ApplyMaterialImage(material.Image);
		}


		private void ViewOnOptionsChanged(SolverOptions changedOption) => _options ^= changedOption;


		private void ViewOnSolveRequested()
		{
			View.Area = View.Massa = View.Volume = 0d;

			if (_options.HasFlagFast(SolverOptions.Area))
				View.Area = _figure.Area();

			if (_options.HasFlagFast(SolverOptions.Massa))
				View.Massa = _figure.Massa();

			if (_options.HasFlagFast(SolverOptions.Volume))
				View.Volume = _figure.Volume();

			Controller.AppLogger.Information("{@Figure}{@SolveOptions}", _figure, _options);
		}


		public void WithFigure(Type figure)
		{
			_figure = (IFigure)Activator.CreateInstance(figure);

			View.ApplyFigure(_storage.GetFigureInfoByType(_figure));
		}
	}
}