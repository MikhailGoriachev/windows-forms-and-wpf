﻿using System;
using System.Collections.Generic;
using System.IO;
using Main.ApplicationControl;
using Main.Common;
using Main.Views;


namespace Main.Presenters
{
	internal sealed class LoggerPresenter : BasePresenter<ILoggerView>
	{
		public LoggerPresenter(ILoggerView view, IApplicationController controller)
			: base(view, controller) =>
			View.LogLoadRequested += ViewOnLogLoadRequested;


		private void ViewOnLogLoadRequested()
		{
			var path = Controller.AppConfig.GetFilePathForSerilog();

			using var logFile = Controller.AppLogger.GetSharedWithLoggerFile(path);

			List<string> lines = new List<string>();
			using (var reader = new StreamReader(logFile))
			{
				while (!reader.EndOfStream)
					lines.Add($"{reader.ReadLine()}{Environment.NewLine}");
			}

			View.LogText = lines.ToArray();
		}
	}
}