﻿using System.Windows.Forms;
using Main.ApplicationControl;
using Main.Models;


namespace Main.Controls
{
	public sealed partial class TruncatedConoidInputControl : UserControl
	{
		public TruncatedConoidInputControl(TruncatedConoid cone)
		{
			InitializeComponent();
			MainGrid.SetNumericsToDefault();

			HeightNumeric
				.DataBindings
				.Add("Value", cone, "Height");

			LowerRadiusNumeric
				.DataBindings
				.Add("Value", cone, "LowerRadius");

			UpperRadiusNumeric
				.DataBindings
				.Add("Value", cone, "UpperRadius");
		}
	}
}