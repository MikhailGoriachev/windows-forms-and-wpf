﻿using System;
using System.Windows.Forms;
using Main.ApplicationControl;
using Main.Common;
using Main.Views;


namespace Main.Presenters
{
	internal sealed class MainPresenter : BasePresenter<IMainView>
	{
		public MainPresenter(IMainView view, IApplicationController controller)
			: base(view, controller)
		{
			View.FigureFormRequested += ViewOnFigureFormRequested;
			View.LogViewRequested    += ViewOnLogViewRequested;
			View.LogClearRequested   += ViewOnLogClearRequested;
			View.ListBoxesRequested  += ViewOnListBoxesRequested;
		}


		private void ViewOnFigureFormRequested(Type figure) =>
			Controller.Run<FigurePresenter>(f =>
			{
				f.Dock     = DockStyle.Fill;
				f.TopLevel = false;

				View.FormContainer.Controls.Clear();
				View.FormContainer.Controls.Add(f);

				f.BringToFront();
				f.Show();
			}).WithFigure(figure);


		private void ViewOnListBoxesRequested() =>
			Controller.Run<ListBoxesPresenter>();


		private void ViewOnLogClearRequested()
		{
			var path = Controller.AppConfig.GetFilePathForSerilog();

			using var logFile = Controller.AppLogger.GetSharedWithLoggerFile(path);
			logFile.SetLength(0L);
		}


		private void ViewOnLogViewRequested() =>
			Controller.Run<LoggerPresenter>();
	}
}