﻿using System.Windows.Forms;
using Main.ApplicationControl;
using Main.Models;


namespace Main.Controls
{
	public sealed partial class SphereInputControl : UserControl
	{
		public SphereInputControl(Sphere sphere)
		{
			InitializeComponent();
			MainGrid.SetNumericsToDefault();

			RadiusNumeric
				.DataBindings
				.Add("Value", sphere, "Radius");
		}
	}
}