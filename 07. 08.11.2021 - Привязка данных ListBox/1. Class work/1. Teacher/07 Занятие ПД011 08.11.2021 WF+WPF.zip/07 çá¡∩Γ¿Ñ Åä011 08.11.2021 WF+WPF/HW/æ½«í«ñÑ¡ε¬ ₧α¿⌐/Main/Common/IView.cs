﻿using System;
using System.Windows.Forms;


namespace Main.Common
{
	internal interface IView
	{
		void Close();

		void Show();

		void Show(Action<Form> onStartup) { onStartup((Form)this); }
	}
}