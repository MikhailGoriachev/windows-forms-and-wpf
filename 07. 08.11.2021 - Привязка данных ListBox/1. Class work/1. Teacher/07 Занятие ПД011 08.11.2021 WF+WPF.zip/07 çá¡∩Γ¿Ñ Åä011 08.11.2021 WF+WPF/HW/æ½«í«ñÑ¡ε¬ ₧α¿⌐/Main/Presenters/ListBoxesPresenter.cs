﻿using System.Collections.Generic;
using System.Linq;
using Main.ApplicationControl;
using Main.Common;
using Main.Views;


namespace Main.Presenters
{
	internal class ListBoxesPresenter : BasePresenter<IListBoxesView>
	{
		public ListBoxesPresenter(IListBoxesView view, IApplicationController controller)
			: base(view, controller)
		{
			View.MoveSingleFromLeftToRight += i => MoveSingle(View.LeftList, View.RightList, i);
			View.MoveAllFromLeftToRight    += () => MoveAll(View.LeftList, View.RightList);

			View.MoveSingleFromRightToLeft += i => MoveSingle(View.RightList, View.LeftList, i);
			View.MoveAllFromRightToLeft    += () => MoveAll(View.RightList, View.LeftList);

			View.ClearAll += ViewOnClearAll;

			View.AddToLeft  += s => AddTo(View.LeftList, s);
			View.AddToRight += s => AddTo(View.RightList, s);
		}


		private void AddTo(IList<string> to, string value)
		{
			if (string.IsNullOrWhiteSpace(value))
				return;

			to.Add(value);
		}


		private void ViewOnClearAll()
		{
			View.LeftList.Clear();
			View.RightList.Clear();
		}


		private void MoveAll(IList<string> from, IList<string> to)
		{
			foreach (var s in from)
				to.Add(s);

			from.Clear();
		}


		private void MoveSingle(IList<string> from, IList<string> to, int index)
		{
			var value = from.ElementAtOrDefault(index);

			if (value is null)
				return;

			to.Add(value);

			from.RemoveAt(index);
		}
	}
}