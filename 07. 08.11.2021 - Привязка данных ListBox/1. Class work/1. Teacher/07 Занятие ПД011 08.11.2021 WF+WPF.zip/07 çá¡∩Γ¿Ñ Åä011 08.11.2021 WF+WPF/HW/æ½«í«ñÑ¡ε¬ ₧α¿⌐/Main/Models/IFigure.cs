﻿namespace Main.Models
{
	public interface IFigure
	{
		double Density { get; set; }

		double Area();

		double Volume();

		double Massa() => Volume() * Density;
	}
}