﻿using System;
using System.Drawing;
using System.Windows.Forms;
using Main.Common;


namespace Main.Views.Figure
{
	internal interface IFigureView : IView
	{
		public double Area { set; }
		public double Massa { set; }
		public double Volume { set; }

		void ApplyFigure(FigureInfo info);

		void ApplyMaterialImage(Bitmap materialImage);

		event Action<MaterialType> MaterialCnahgeRequested;
		event Action<SolverOptions> OptionsChanged;
		event Action SolveRequested;
	}


	public sealed partial class FigureForm : BaseForm, IFigureView
	{
		public double Area { set => AreaResult.Text = ConvertResult(value); }
		public double Massa { set => MassaResult.Text = ConvertResult(value); }
		public double Volume { set => VolumeResult.Text = ConvertResult(value); }


		public FigureForm()
		{
			InitializeComponent();

			CopperRadioButton.Tag   = MaterialType.Copper;
			GraniteRadioButton.Tag  = MaterialType.Granite;
			SteelRadioButton.Tag    = MaterialType.Steel;
			WaterIceRadioButton.Tag = MaterialType.WaterIce;

			AreaCheckbox.Tag   = SolverOptions.Area;
			VolumeCheckbox.Tag = SolverOptions.Volume;
			MassaCheckbox.Tag  = SolverOptions.Massa;
		}


		public void ApplyFigure(FigureInfo info)
		{
			FigureGroupBox.Text    = info.Name;
			FigurePictureBox.Image = info.Picture;

			info.Input.Dock = DockStyle.Fill;
			InputGroupBox.Controls.Add(info.Input);
			info.Input.BringToFront();
		}


		public void ApplyMaterialImage(Bitmap materialImage) =>
			MaterialPictureBox.Image = materialImage;


		public event Action<MaterialType> MaterialCnahgeRequested;
		public event Action<SolverOptions> OptionsChanged;
		public event Action SolveRequested;


		private string ConvertResult(double value) => value.ToString("F");


		private void OnMaterialCnahgeRequested(object sender, EventArgs e)
		{
			var radioButton = (RadioButton)sender;

			MaterialCnahgeRequested?.Invoke((MaterialType)radioButton.Tag);
		}


		private void OnOptionsChanged(object sender, EventArgs e)
		{
			var box = (CheckBox)sender;

			OptionsChanged?.Invoke((SolverOptions)box.Tag);
		}


		private void OnSolveRequested(object sender, EventArgs e) =>
			SolveRequested?.Invoke();
	}
}