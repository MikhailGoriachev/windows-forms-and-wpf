﻿
namespace Main.Views.Figure
{
	sealed partial class FigureForm
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.MainGrid = new System.Windows.Forms.TableLayoutPanel();
			this.FigureGroupBox = new System.Windows.Forms.GroupBox();
			this.FigurePictureBox = new System.Windows.Forms.PictureBox();
			this.MaterialGroupBox = new System.Windows.Forms.GroupBox();
			this.MaterialPictureBox = new System.Windows.Forms.PictureBox();
			this.SelectMaterialGroupBox = new System.Windows.Forms.GroupBox();
			this.GraniteRadioButton = new System.Windows.Forms.RadioButton();
			this.WaterIceRadioButton = new System.Windows.Forms.RadioButton();
			this.CopperRadioButton = new System.Windows.Forms.RadioButton();
			this.SteelRadioButton = new System.Windows.Forms.RadioButton();
			this.OptionsGroupBox = new System.Windows.Forms.GroupBox();
			this.MassaCheckbox = new System.Windows.Forms.CheckBox();
			this.VolumeCheckbox = new System.Windows.Forms.CheckBox();
			this.AreaCheckbox = new System.Windows.Forms.CheckBox();
			this.InputGroupBox = new System.Windows.Forms.GroupBox();
			this.ResultsGroupBox = new System.Windows.Forms.GroupBox();
			this.SolveButton = new System.Windows.Forms.Button();
			this.ResultsTable = new System.Windows.Forms.TableLayoutPanel();
			this.MassaResult = new System.Windows.Forms.Label();
			this.MassInfo = new System.Windows.Forms.Label();
			this.VolumeInfo = new System.Windows.Forms.Label();
			this.VolumeResult = new System.Windows.Forms.Label();
			this.AreaResult = new System.Windows.Forms.Label();
			this.AreaInfo = new System.Windows.Forms.Label();
			this.MainGrid.SuspendLayout();
			this.FigureGroupBox.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.FigurePictureBox)).BeginInit();
			this.MaterialGroupBox.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.MaterialPictureBox)).BeginInit();
			this.SelectMaterialGroupBox.SuspendLayout();
			this.OptionsGroupBox.SuspendLayout();
			this.ResultsGroupBox.SuspendLayout();
			this.ResultsTable.SuspendLayout();
			this.SuspendLayout();
			// 
			// MainGrid
			// 
			this.MainGrid.ColumnCount = 3;
			this.MainGrid.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 21.64668F));
			this.MainGrid.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 56.70665F));
			this.MainGrid.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 21.64668F));
			this.MainGrid.Controls.Add(this.FigureGroupBox, 0, 0);
			this.MainGrid.Controls.Add(this.MaterialGroupBox, 2, 0);
			this.MainGrid.Controls.Add(this.SelectMaterialGroupBox, 2, 1);
			this.MainGrid.Controls.Add(this.OptionsGroupBox, 0, 1);
			this.MainGrid.Controls.Add(this.InputGroupBox, 1, 0);
			this.MainGrid.Controls.Add(this.ResultsGroupBox, 1, 1);
			this.MainGrid.Dock = System.Windows.Forms.DockStyle.Fill;
			this.MainGrid.Location = new System.Drawing.Point(0, 0);
			this.MainGrid.Name = "MainGrid";
			this.MainGrid.RowCount = 2;
			this.MainGrid.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 57.29614F));
			this.MainGrid.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 42.70386F));
			this.MainGrid.Size = new System.Drawing.Size(980, 491);
			this.MainGrid.TabIndex = 2;
			// 
			// FigureGroupBox
			// 
			this.FigureGroupBox.Controls.Add(this.FigurePictureBox);
			this.FigureGroupBox.Dock = System.Windows.Forms.DockStyle.Fill;
			this.FigureGroupBox.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
			this.FigureGroupBox.Location = new System.Drawing.Point(3, 3);
			this.FigureGroupBox.Name = "FigureGroupBox";
			this.FigureGroupBox.Size = new System.Drawing.Size(206, 275);
			this.FigureGroupBox.TabIndex = 4;
			this.FigureGroupBox.TabStop = false;
			// 
			// FigurePictureBox
			// 
			this.FigurePictureBox.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.FigurePictureBox.Location = new System.Drawing.Point(3, 72);
			this.FigurePictureBox.Name = "FigurePictureBox";
			this.FigurePictureBox.Size = new System.Drawing.Size(200, 200);
			this.FigurePictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
			this.FigurePictureBox.TabIndex = 0;
			this.FigurePictureBox.TabStop = false;
			// 
			// MaterialGroupBox
			// 
			this.MaterialGroupBox.Controls.Add(this.MaterialPictureBox);
			this.MaterialGroupBox.Dock = System.Windows.Forms.DockStyle.Fill;
			this.MaterialGroupBox.Location = new System.Drawing.Point(770, 3);
			this.MaterialGroupBox.Name = "MaterialGroupBox";
			this.MaterialGroupBox.Size = new System.Drawing.Size(207, 275);
			this.MaterialGroupBox.TabIndex = 5;
			this.MaterialGroupBox.TabStop = false;
			this.MaterialGroupBox.Text = "Текущий материал";
			// 
			// MaterialPictureBox
			// 
			this.MaterialPictureBox.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.MaterialPictureBox.Location = new System.Drawing.Point(3, 40);
			this.MaterialPictureBox.Name = "MaterialPictureBox";
			this.MaterialPictureBox.Size = new System.Drawing.Size(201, 232);
			this.MaterialPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			this.MaterialPictureBox.TabIndex = 0;
			this.MaterialPictureBox.TabStop = false;
			// 
			// SelectMaterialGroupBox
			// 
			this.SelectMaterialGroupBox.Controls.Add(this.GraniteRadioButton);
			this.SelectMaterialGroupBox.Controls.Add(this.WaterIceRadioButton);
			this.SelectMaterialGroupBox.Controls.Add(this.CopperRadioButton);
			this.SelectMaterialGroupBox.Controls.Add(this.SteelRadioButton);
			this.SelectMaterialGroupBox.Dock = System.Windows.Forms.DockStyle.Fill;
			this.SelectMaterialGroupBox.Location = new System.Drawing.Point(770, 284);
			this.SelectMaterialGroupBox.Name = "SelectMaterialGroupBox";
			this.SelectMaterialGroupBox.Size = new System.Drawing.Size(207, 204);
			this.SelectMaterialGroupBox.TabIndex = 6;
			this.SelectMaterialGroupBox.TabStop = false;
			this.SelectMaterialGroupBox.Text = "Материал";
			// 
			// GraniteRadioButton
			// 
			this.GraniteRadioButton.Anchor = System.Windows.Forms.AnchorStyles.None;
			this.GraniteRadioButton.AutoSize = true;
			this.GraniteRadioButton.Location = new System.Drawing.Point(46, 160);
			this.GraniteRadioButton.Name = "GraniteRadioButton";
			this.GraniteRadioButton.Size = new System.Drawing.Size(75, 24);
			this.GraniteRadioButton.TabIndex = 3;
			this.GraniteRadioButton.Text = "Гранит";
			this.GraniteRadioButton.UseVisualStyleBackColor = true;
			this.GraniteRadioButton.CheckedChanged += new System.EventHandler(this.OnMaterialCnahgeRequested);
			// 
			// WaterIceRadioButton
			// 
			this.WaterIceRadioButton.Anchor = System.Windows.Forms.AnchorStyles.None;
			this.WaterIceRadioButton.AutoSize = true;
			this.WaterIceRadioButton.Location = new System.Drawing.Point(46, 120);
			this.WaterIceRadioButton.Name = "WaterIceRadioButton";
			this.WaterIceRadioButton.Size = new System.Drawing.Size(116, 24);
			this.WaterIceRadioButton.TabIndex = 2;
			this.WaterIceRadioButton.Text = "Водяной лед";
			this.WaterIceRadioButton.UseVisualStyleBackColor = true;
			this.WaterIceRadioButton.CheckedChanged += new System.EventHandler(this.OnMaterialCnahgeRequested);
			// 
			// CopperRadioButton
			// 
			this.CopperRadioButton.Anchor = System.Windows.Forms.AnchorStyles.None;
			this.CopperRadioButton.AutoSize = true;
			this.CopperRadioButton.Location = new System.Drawing.Point(46, 80);
			this.CopperRadioButton.Name = "CopperRadioButton";
			this.CopperRadioButton.Size = new System.Drawing.Size(64, 24);
			this.CopperRadioButton.TabIndex = 1;
			this.CopperRadioButton.Text = "Медь";
			this.CopperRadioButton.UseVisualStyleBackColor = true;
			this.CopperRadioButton.CheckedChanged += new System.EventHandler(this.OnMaterialCnahgeRequested);
			// 
			// SteelRadioButton
			// 
			this.SteelRadioButton.Anchor = System.Windows.Forms.AnchorStyles.None;
			this.SteelRadioButton.AutoSize = true;
			this.SteelRadioButton.Location = new System.Drawing.Point(46, 40);
			this.SteelRadioButton.Name = "SteelRadioButton";
			this.SteelRadioButton.Size = new System.Drawing.Size(66, 24);
			this.SteelRadioButton.TabIndex = 0;
			this.SteelRadioButton.Text = "Сталь";
			this.SteelRadioButton.UseVisualStyleBackColor = true;
			this.SteelRadioButton.CheckedChanged += new System.EventHandler(this.OnMaterialCnahgeRequested);
			// 
			// OptionsGroupBox
			// 
			this.OptionsGroupBox.Controls.Add(this.MassaCheckbox);
			this.OptionsGroupBox.Controls.Add(this.VolumeCheckbox);
			this.OptionsGroupBox.Controls.Add(this.AreaCheckbox);
			this.OptionsGroupBox.Dock = System.Windows.Forms.DockStyle.Fill;
			this.OptionsGroupBox.Location = new System.Drawing.Point(3, 284);
			this.OptionsGroupBox.Name = "OptionsGroupBox";
			this.OptionsGroupBox.Size = new System.Drawing.Size(206, 204);
			this.OptionsGroupBox.TabIndex = 7;
			this.OptionsGroupBox.TabStop = false;
			this.OptionsGroupBox.Text = "Настройки";
			// 
			// MassaCheckbox
			// 
			this.MassaCheckbox.Anchor = System.Windows.Forms.AnchorStyles.None;
			this.MassaCheckbox.AutoSize = true;
			this.MassaCheckbox.Location = new System.Drawing.Point(54, 152);
			this.MassaCheckbox.Name = "MassaCheckbox";
			this.MassaCheckbox.Size = new System.Drawing.Size(71, 24);
			this.MassaCheckbox.TabIndex = 2;
			this.MassaCheckbox.Text = "Масса";
			this.MassaCheckbox.UseVisualStyleBackColor = true;
			this.MassaCheckbox.CheckStateChanged += new System.EventHandler(this.OnOptionsChanged);
			// 
			// VolumeCheckbox
			// 
			this.VolumeCheckbox.Anchor = System.Windows.Forms.AnchorStyles.None;
			this.VolumeCheckbox.AutoSize = true;
			this.VolumeCheckbox.Location = new System.Drawing.Point(54, 96);
			this.VolumeCheckbox.Name = "VolumeCheckbox";
			this.VolumeCheckbox.Size = new System.Drawing.Size(76, 24);
			this.VolumeCheckbox.TabIndex = 1;
			this.VolumeCheckbox.Text = "Объем";
			this.VolumeCheckbox.UseVisualStyleBackColor = true;
			this.VolumeCheckbox.CheckStateChanged += new System.EventHandler(this.OnOptionsChanged);
			// 
			// AreaCheckbox
			// 
			this.AreaCheckbox.Anchor = System.Windows.Forms.AnchorStyles.None;
			this.AreaCheckbox.AutoSize = true;
			this.AreaCheckbox.Location = new System.Drawing.Point(54, 40);
			this.AreaCheckbox.Name = "AreaCheckbox";
			this.AreaCheckbox.Size = new System.Drawing.Size(92, 24);
			this.AreaCheckbox.TabIndex = 0;
			this.AreaCheckbox.Text = "Площадь";
			this.AreaCheckbox.UseVisualStyleBackColor = true;
			this.AreaCheckbox.CheckStateChanged += new System.EventHandler(this.OnOptionsChanged);
			// 
			// InputGroupBox
			// 
			this.InputGroupBox.Dock = System.Windows.Forms.DockStyle.Fill;
			this.InputGroupBox.Location = new System.Drawing.Point(215, 3);
			this.InputGroupBox.Name = "InputGroupBox";
			this.InputGroupBox.Size = new System.Drawing.Size(549, 275);
			this.InputGroupBox.TabIndex = 8;
			this.InputGroupBox.TabStop = false;
			// 
			// ResultsGroupBox
			// 
			this.ResultsGroupBox.Controls.Add(this.SolveButton);
			this.ResultsGroupBox.Controls.Add(this.ResultsTable);
			this.ResultsGroupBox.Dock = System.Windows.Forms.DockStyle.Fill;
			this.ResultsGroupBox.Location = new System.Drawing.Point(215, 284);
			this.ResultsGroupBox.Name = "ResultsGroupBox";
			this.ResultsGroupBox.Size = new System.Drawing.Size(549, 204);
			this.ResultsGroupBox.TabIndex = 9;
			this.ResultsGroupBox.TabStop = false;
			this.ResultsGroupBox.Text = "Результаты";
			// 
			// SolveButton
			// 
			this.SolveButton.Anchor = System.Windows.Forms.AnchorStyles.None;
			this.SolveButton.Location = new System.Drawing.Point(197, 40);
			this.SolveButton.Name = "SolveButton";
			this.SolveButton.Size = new System.Drawing.Size(155, 47);
			this.SolveButton.TabIndex = 4;
			this.SolveButton.Text = "Вычисление";
			this.SolveButton.UseVisualStyleBackColor = true;
			this.SolveButton.Click += new System.EventHandler(this.OnSolveRequested);
			// 
			// ResultsTable
			// 
			this.ResultsTable.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
			this.ResultsTable.ColumnCount = 2;
			this.ResultsTable.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 24.72325F));
			this.ResultsTable.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 75.27676F));
			this.ResultsTable.Controls.Add(this.MassaResult, 1, 2);
			this.ResultsTable.Controls.Add(this.MassInfo, 0, 2);
			this.ResultsTable.Controls.Add(this.VolumeInfo, 0, 1);
			this.ResultsTable.Controls.Add(this.VolumeResult, 1, 1);
			this.ResultsTable.Controls.Add(this.AreaResult, 1, 0);
			this.ResultsTable.Controls.Add(this.AreaInfo, 0, 0);
			this.ResultsTable.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.ResultsTable.Location = new System.Drawing.Point(3, 99);
			this.ResultsTable.Margin = new System.Windows.Forms.Padding(0);
			this.ResultsTable.Name = "ResultsTable";
			this.ResultsTable.RowCount = 3;
			this.ResultsTable.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
			this.ResultsTable.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
			this.ResultsTable.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
			this.ResultsTable.Size = new System.Drawing.Size(543, 102);
			this.ResultsTable.TabIndex = 3;
			// 
			// MassaResult
			// 
			this.MassaResult.AutoSize = true;
			this.MassaResult.Dock = System.Windows.Forms.DockStyle.Fill;
			this.MassaResult.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
			this.MassaResult.Location = new System.Drawing.Point(138, 67);
			this.MassaResult.Name = "MassaResult";
			this.MassaResult.Size = new System.Drawing.Size(401, 34);
			this.MassaResult.TabIndex = 5;
			this.MassaResult.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// MassInfo
			// 
			this.MassInfo.AutoSize = true;
			this.MassInfo.Dock = System.Windows.Forms.DockStyle.Fill;
			this.MassInfo.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
			this.MassInfo.Location = new System.Drawing.Point(4, 67);
			this.MassInfo.Name = "MassInfo";
			this.MassInfo.Size = new System.Drawing.Size(127, 34);
			this.MassInfo.TabIndex = 4;
			this.MassInfo.Text = "Масса: ";
			this.MassInfo.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// VolumeInfo
			// 
			this.VolumeInfo.AutoSize = true;
			this.VolumeInfo.Dock = System.Windows.Forms.DockStyle.Fill;
			this.VolumeInfo.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
			this.VolumeInfo.Location = new System.Drawing.Point(4, 34);
			this.VolumeInfo.Name = "VolumeInfo";
			this.VolumeInfo.Size = new System.Drawing.Size(127, 32);
			this.VolumeInfo.TabIndex = 3;
			this.VolumeInfo.Text = "Объем:";
			this.VolumeInfo.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// VolumeResult
			// 
			this.VolumeResult.AutoSize = true;
			this.VolumeResult.Dock = System.Windows.Forms.DockStyle.Fill;
			this.VolumeResult.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
			this.VolumeResult.Location = new System.Drawing.Point(138, 34);
			this.VolumeResult.Name = "VolumeResult";
			this.VolumeResult.Size = new System.Drawing.Size(401, 32);
			this.VolumeResult.TabIndex = 2;
			this.VolumeResult.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// AreaResult
			// 
			this.AreaResult.AutoSize = true;
			this.AreaResult.Dock = System.Windows.Forms.DockStyle.Fill;
			this.AreaResult.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
			this.AreaResult.Location = new System.Drawing.Point(138, 1);
			this.AreaResult.Name = "AreaResult";
			this.AreaResult.Size = new System.Drawing.Size(401, 32);
			this.AreaResult.TabIndex = 1;
			this.AreaResult.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// AreaInfo
			// 
			this.AreaInfo.AutoSize = true;
			this.AreaInfo.Dock = System.Windows.Forms.DockStyle.Fill;
			this.AreaInfo.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
			this.AreaInfo.Location = new System.Drawing.Point(4, 1);
			this.AreaInfo.Name = "AreaInfo";
			this.AreaInfo.Size = new System.Drawing.Size(127, 32);
			this.AreaInfo.TabIndex = 0;
			this.AreaInfo.Text = "Площадь:";
			this.AreaInfo.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// FigureForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(980, 491);
			this.Controls.Add(this.MainGrid);
			this.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
			this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.Name = "FigureForm";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "FigureForm";
			this.MainGrid.ResumeLayout(false);
			this.FigureGroupBox.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.FigurePictureBox)).EndInit();
			this.MaterialGroupBox.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.MaterialPictureBox)).EndInit();
			this.SelectMaterialGroupBox.ResumeLayout(false);
			this.SelectMaterialGroupBox.PerformLayout();
			this.OptionsGroupBox.ResumeLayout(false);
			this.OptionsGroupBox.PerformLayout();
			this.ResultsGroupBox.ResumeLayout(false);
			this.ResultsTable.ResumeLayout(false);
			this.ResultsTable.PerformLayout();
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.TableLayoutPanel MainGrid;
		private System.Windows.Forms.GroupBox FigureGroupBox;
		private System.Windows.Forms.PictureBox FigurePictureBox;
		private System.Windows.Forms.GroupBox MaterialGroupBox;
		private System.Windows.Forms.PictureBox MaterialPictureBox;
		private System.Windows.Forms.GroupBox SelectMaterialGroupBox;
		private System.Windows.Forms.RadioButton WaterIceRadioButton;
		private System.Windows.Forms.RadioButton CopperRadioButton;
		private System.Windows.Forms.RadioButton SteelRadioButton;
		private System.Windows.Forms.GroupBox OptionsGroupBox;
		private System.Windows.Forms.CheckBox MassaCheckbox;
		private System.Windows.Forms.CheckBox VolumeCheckbox;
		private System.Windows.Forms.CheckBox AreaCheckbox;
		private System.Windows.Forms.GroupBox InputGroupBox;
		private System.Windows.Forms.GroupBox ResultsGroupBox;
		private System.Windows.Forms.Button SolveButton;
		private System.Windows.Forms.TableLayoutPanel ResultsTable;
		private System.Windows.Forms.Label MassaResult;
		private System.Windows.Forms.Label MassInfo;
		private System.Windows.Forms.Label VolumeInfo;
		private System.Windows.Forms.Label VolumeResult;
		private System.Windows.Forms.Label AreaResult;
		private System.Windows.Forms.Label AreaInfo;
		private System.Windows.Forms.RadioButton GraniteRadioButton;
	}
}