﻿using System;
using Main.Views.Figure;


namespace Main.Models
{
	public sealed class TruncatedConoid : IFigure
	{
		public double Height { get; set; }

		public double LowerRadius { get; set; }

		public double UpperRadius { get; set; }

		public double Density { get; set; }


		public double Generatrix()
		{
			double poweredRadius = (LowerRadius - UpperRadius) * (LowerRadius - UpperRadius);

			return Math.Sqrt(Height * Height + poweredRadius);
		}


		public double Area()
		{
			double l = Generatrix();

			var (poweredLow, poweredUp) = PoweredRadiuses();

			return Math.PI * (l * LowerRadius + l * UpperRadius + poweredLow + poweredUp);
		}


		private (double poweredLow, double poweredUp) PoweredRadiuses()
		{
			double poweredLow = LowerRadius * LowerRadius;
			double poweredUp = UpperRadius * UpperRadius;
			return (poweredLow, poweredUp);
		}


		public double Volume()
		{
			var (low, up) = PoweredRadiuses();

			return 1d / 3d * Math.PI * Height * (low + LowerRadius * UpperRadius + up);
		}
	}
}