﻿
using System.Drawing;

namespace Homework6
{
	partial class MainForm
	{
		/// <summary>
		/// Обязательная переменная конструктора.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Освободить все используемые ресурсы.
		/// </summary>
		/// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Код, автоматически созданный конструктором форм Windows

		/// <summary>
		/// Требуемый метод для поддержки конструктора — не изменяйте 
		/// содержимое этого метода с помощью редактора кода.
		/// </summary>
		private void InitializeComponent()
		{
			this.MnuMain = new System.Windows.Forms.MenuStrip();
			this.MnuFile = new System.Windows.Forms.ToolStripMenuItem();
			this.MnuFileExit = new System.Windows.Forms.ToolStripMenuItem();
			this.MnuFigures = new System.Windows.Forms.ToolStripMenuItem();
			this.MnuFiguresConoid = new System.Windows.Forms.ToolStripMenuItem();
			this.MnuFiguresCylinder = new System.Windows.Forms.ToolStripMenuItem();
			this.MnuFiguresSphere = new System.Windows.Forms.ToolStripMenuItem();
			this.MnuFiguresParallelepiped = new System.Windows.Forms.ToolStripMenuItem();
			this.MnuJournal = new System.Windows.Forms.ToolStripMenuItem();
			this.MnuJournalView = new System.Windows.Forms.ToolStripMenuItem();
			this.MnuJournalClear = new System.Windows.Forms.ToolStripMenuItem();
			this.MnuLists = new System.Windows.Forms.ToolStripMenuItem();
			this.MnuHelp = new System.Windows.Forms.ToolStripMenuItem();
			this.MnuHelpAbout = new System.Windows.Forms.ToolStripMenuItem();
			this.TxbHistory = new System.Windows.Forms.TextBox();
			this.LblHistory = new System.Windows.Forms.Label();
			this.MnuMain.SuspendLayout();
			this.SuspendLayout();
			// 
			// MnuMain
			// 
			this.MnuMain.BackColor = System.Drawing.Color.Azure;
			this.MnuMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MnuFile,
            this.MnuFigures,
            this.MnuJournal,
            this.MnuLists,
            this.MnuHelp});
			this.MnuMain.Location = new System.Drawing.Point(0, 0);
			this.MnuMain.Name = "MnuMain";
			this.MnuMain.RenderMode = System.Windows.Forms.ToolStripRenderMode.System;
			this.MnuMain.Size = new System.Drawing.Size(469, 24);
			this.MnuMain.TabIndex = 0;
			// 
			// MnuFile
			// 
			this.MnuFile.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MnuFileExit});
			this.MnuFile.Image = global::Homework6.Properties.Resources.file;
			this.MnuFile.Name = "MnuFile";
			this.MnuFile.ShortcutKeyDisplayString = "Ф";
			this.MnuFile.Size = new System.Drawing.Size(64, 20);
			this.MnuFile.Text = "&Файл";
			this.MnuFile.ToolTipText = "&Файл";
			// 
			// MnuFileExit
			// 
			this.MnuFileExit.Image = global::Homework6.Properties.Resources.exit;
			this.MnuFileExit.Name = "MnuFileExit";
			this.MnuFileExit.Size = new System.Drawing.Size(109, 22);
			this.MnuFileExit.Text = "&Выход";
			this.MnuFileExit.Click += new System.EventHandler(this.MnuFileExit_Click);
			// 
			// MnuFigures
			// 
			this.MnuFigures.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MnuFiguresConoid,
            this.MnuFiguresCylinder,
            this.MnuFiguresSphere,
            this.MnuFiguresParallelepiped});
			this.MnuFigures.Image = global::Homework6.Properties.Resources.figure;
			this.MnuFigures.Name = "MnuFigures";
			this.MnuFigures.Size = new System.Drawing.Size(141, 20);
			this.MnuFigures.Text = "&Объемные фигуры";
			// 
			// MnuFiguresConoid
			// 
			this.MnuFiguresConoid.Image = global::Homework6.Properties.Resources.cone;
			this.MnuFiguresConoid.Name = "MnuFiguresConoid";
			this.MnuFiguresConoid.Size = new System.Drawing.Size(180, 22);
			this.MnuFiguresConoid.Text = "Усеченный &конус";
			this.MnuFiguresConoid.Click += new System.EventHandler(this.MnuFiguresConoid_Click);
			// 
			// MnuFiguresCylinder
			// 
			this.MnuFiguresCylinder.Image = global::Homework6.Properties.Resources.cylinder;
			this.MnuFiguresCylinder.Name = "MnuFiguresCylinder";
			this.MnuFiguresCylinder.Size = new System.Drawing.Size(180, 22);
			this.MnuFiguresCylinder.Text = "&Цилиндр";
			this.MnuFiguresCylinder.Click += new System.EventHandler(this.MnuFiguresCylinder_Click);
			// 
			// MnuFiguresSphere
			// 
			this.MnuFiguresSphere.Image = global::Homework6.Properties.Resources.sphere;
			this.MnuFiguresSphere.Name = "MnuFiguresSphere";
			this.MnuFiguresSphere.Size = new System.Drawing.Size(180, 22);
			this.MnuFiguresSphere.Text = "&Сфера";
			this.MnuFiguresSphere.Click += new System.EventHandler(this.MnuFiguresSphere_Click);
			// 
			// MnuFiguresParallelepiped
			// 
			this.MnuFiguresParallelepiped.Image = global::Homework6.Properties.Resources.parallelepiped;
			this.MnuFiguresParallelepiped.Name = "MnuFiguresParallelepiped";
			this.MnuFiguresParallelepiped.Size = new System.Drawing.Size(180, 22);
			this.MnuFiguresParallelepiped.Text = "&Параллелепипед";
			this.MnuFiguresParallelepiped.Click += new System.EventHandler(this.MnuFiguresParallelepiped_Click);
			// 
			// MnuJournal
			// 
			this.MnuJournal.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MnuJournalView,
            this.MnuJournalClear});
			this.MnuJournal.Image = global::Homework6.Properties.Resources.journal;
			this.MnuJournal.Name = "MnuJournal";
			this.MnuJournal.Size = new System.Drawing.Size(79, 20);
			this.MnuJournal.Text = "&Журнал";
			// 
			// MnuJournalView
			// 
			this.MnuJournalView.Name = "MnuJournalView";
			this.MnuJournalView.Size = new System.Drawing.Size(131, 22);
			this.MnuJournalView.Text = "&Просмотр";
			this.MnuJournalView.Click += new System.EventHandler(this.MnuJournalView_Click);
			// 
			// MnuJournalClear
			// 
			this.MnuJournalClear.Name = "MnuJournalClear";
			this.MnuJournalClear.Size = new System.Drawing.Size(131, 22);
			this.MnuJournalClear.Text = "&Очистка";
			this.MnuJournalClear.Click += new System.EventHandler(this.MnuJournalClear_Click);
			// 
			// MnuLists
			// 
			this.MnuLists.Image = global::Homework6.Properties.Resources.list;
			this.MnuLists.Name = "MnuLists";
			this.MnuLists.Size = new System.Drawing.Size(76, 20);
			this.MnuLists.Text = "&Списки";
			this.MnuLists.Click += new System.EventHandler(this.MnuLists_Click);
			// 
			// MnuHelp
			// 
			this.MnuHelp.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MnuHelpAbout});
			this.MnuHelp.Image = global::Homework6.Properties.Resources.help;
			this.MnuHelp.Name = "MnuHelp";
			this.MnuHelp.Size = new System.Drawing.Size(84, 20);
			this.MnuHelp.Text = "&Помощь";
			// 
			// MnuHelpAbout
			// 
			this.MnuHelpAbout.Name = "MnuHelpAbout";
			this.MnuHelpAbout.Size = new System.Drawing.Size(158, 22);
			this.MnuHelpAbout.Text = "&О программе...";
			this.MnuHelpAbout.Click += new System.EventHandler(this.MnuHelpAbout_Click);
			// 
			// TxbHistory
			// 
			this.TxbHistory.Font = new System.Drawing.Font("Consolas", 9F);
			this.TxbHistory.Location = new System.Drawing.Point(23, 56);
			this.TxbHistory.Multiline = true;
			this.TxbHistory.Name = "TxbHistory";
			this.TxbHistory.ReadOnly = true;
			this.TxbHistory.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
			this.TxbHistory.Size = new System.Drawing.Size(424, 256);
			this.TxbHistory.TabIndex = 17;
			// 
			// LblHistory
			// 
			this.LblHistory.AutoSize = true;
			this.LblHistory.Font = new System.Drawing.Font("Tahoma", 9F);
			this.LblHistory.Location = new System.Drawing.Point(21, 32);
			this.LblHistory.Name = "LblHistory";
			this.LblHistory.Size = new System.Drawing.Size(118, 14);
			this.LblHistory.TabIndex = 18;
			this.LblHistory.Text = "История операций:";
			// 
			// MainForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.GhostWhite;
			this.ClientSize = new System.Drawing.Size(469, 324);
			this.Controls.Add(this.LblHistory);
			this.Controls.Add(this.TxbHistory);
			this.Controls.Add(this.MnuMain);
			this.Font = new System.Drawing.Font("Tahoma", 10F);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.MainMenuStrip = this.MnuMain;
			this.Margin = new System.Windows.Forms.Padding(4);
			this.MaximizeBox = false;
			this.Name = "MainForm";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Домашнее задание";
			this.Load += new System.EventHandler(this.MainForm_Load);
			this.MnuMain.ResumeLayout(false);
			this.MnuMain.PerformLayout();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.ToolStripMenuItem MnuFile;
		private System.Windows.Forms.ToolStripMenuItem MnuFileExit;
		private System.Windows.Forms.ToolStripMenuItem MnuFigures;
		private System.Windows.Forms.ToolStripMenuItem MnuFiguresConoid;
		private System.Windows.Forms.ToolStripMenuItem MnuFiguresSphere;
		private System.Windows.Forms.ToolStripMenuItem MnuFiguresCylinder;
		private System.Windows.Forms.ToolStripMenuItem MnuFiguresParallelepiped;
		private System.Windows.Forms.ToolStripMenuItem MnuJournal;
		private System.Windows.Forms.ToolStripMenuItem MnuJournalView;
		private System.Windows.Forms.ToolStripMenuItem MnuJournalClear;
		private System.Windows.Forms.ToolStripMenuItem MnuLists;
		private System.Windows.Forms.ToolStripMenuItem MnuHelp;
		private System.Windows.Forms.ToolStripMenuItem MnuHelpAbout;
		private System.Windows.Forms.MenuStrip MnuMain;
		private System.Windows.Forms.TextBox TxbHistory;
		private System.Windows.Forms.Label LblHistory;
	}
}

