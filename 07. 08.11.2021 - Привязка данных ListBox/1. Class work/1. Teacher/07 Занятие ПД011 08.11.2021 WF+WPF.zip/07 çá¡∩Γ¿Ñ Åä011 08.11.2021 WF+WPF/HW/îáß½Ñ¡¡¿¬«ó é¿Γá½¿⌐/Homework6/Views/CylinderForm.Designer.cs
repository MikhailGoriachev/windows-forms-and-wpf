﻿
namespace Homework6.Views
{
	partial class CylinderForm
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.RbtGranite = new System.Windows.Forms.RadioButton();
			this.RbtIceWater = new System.Windows.Forms.RadioButton();
			this.RbtCopper = new System.Windows.Forms.RadioButton();
			this.RbtCustom = new System.Windows.Forms.RadioButton();
			this.GrbMaterialType = new System.Windows.Forms.GroupBox();
			this.RbtSteel = new System.Windows.Forms.RadioButton();
			this.LblMassResult = new System.Windows.Forms.Label();
			this.BtnClose = new System.Windows.Forms.Button();
			this.LblMass = new System.Windows.Forms.Label();
			this.GrbCalcParams = new System.Windows.Forms.GroupBox();
			this.ChbMass = new System.Windows.Forms.CheckBox();
			this.ChbVolume = new System.Windows.Forms.CheckBox();
			this.ChbArea = new System.Windows.Forms.CheckBox();
			this.GrbResult = new System.Windows.Forms.GroupBox();
			this.LblVolumeResult = new System.Windows.Forms.Label();
			this.LblVolume = new System.Windows.Forms.Label();
			this.LblAreaResult = new System.Windows.Forms.Label();
			this.LblArea = new System.Windows.Forms.Label();
			this.GrbFigureData = new System.Windows.Forms.GroupBox();
			this.LblDensity = new System.Windows.Forms.Label();
			this.LblHeight = new System.Windows.Forms.Label();
			this.LblRadius = new System.Windows.Forms.Label();
			this.BtnCalc = new System.Windows.Forms.Button();
			this.NudDensity = new System.Windows.Forms.NumericUpDown();
			this.NudHeight = new System.Windows.Forms.NumericUpDown();
			this.NudRadius = new System.Windows.Forms.NumericUpDown();
			this.PcbMaterial = new System.Windows.Forms.PictureBox();
			this.PcbFigure = new System.Windows.Forms.PictureBox();
			this.GrbMaterialType.SuspendLayout();
			this.GrbCalcParams.SuspendLayout();
			this.GrbResult.SuspendLayout();
			this.GrbFigureData.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.NudDensity)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.NudHeight)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.NudRadius)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.PcbMaterial)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.PcbFigure)).BeginInit();
			this.SuspendLayout();
			// 
			// RbtGranite
			// 
			this.RbtGranite.AutoSize = true;
			this.RbtGranite.Font = new System.Drawing.Font("Tahoma", 10F);
			this.RbtGranite.Location = new System.Drawing.Point(16, 120);
			this.RbtGranite.Name = "RbtGranite";
			this.RbtGranite.Size = new System.Drawing.Size(72, 21);
			this.RbtGranite.TabIndex = 4;
			this.RbtGranite.Tag = "granite";
			this.RbtGranite.Text = "Гранит";
			this.RbtGranite.UseVisualStyleBackColor = true;
			this.RbtGranite.Click += new System.EventHandler(this.RbtMaterial_Click);
			// 
			// RbtIceWater
			// 
			this.RbtIceWater.AutoSize = true;
			this.RbtIceWater.Font = new System.Drawing.Font("Tahoma", 10F);
			this.RbtIceWater.Location = new System.Drawing.Point(16, 96);
			this.RbtIceWater.Name = "RbtIceWater";
			this.RbtIceWater.Size = new System.Drawing.Size(108, 21);
			this.RbtIceWater.TabIndex = 3;
			this.RbtIceWater.Tag = "iceWater";
			this.RbtIceWater.Text = "Лед водяной";
			this.RbtIceWater.UseVisualStyleBackColor = true;
			this.RbtIceWater.Click += new System.EventHandler(this.RbtMaterial_Click);
			// 
			// RbtCopper
			// 
			this.RbtCopper.AutoSize = true;
			this.RbtCopper.Font = new System.Drawing.Font("Tahoma", 10F);
			this.RbtCopper.Location = new System.Drawing.Point(16, 72);
			this.RbtCopper.Name = "RbtCopper";
			this.RbtCopper.Size = new System.Drawing.Size(58, 21);
			this.RbtCopper.TabIndex = 2;
			this.RbtCopper.Tag = "copper";
			this.RbtCopper.Text = "Медь";
			this.RbtCopper.UseVisualStyleBackColor = true;
			this.RbtCopper.Click += new System.EventHandler(this.RbtMaterial_Click);
			// 
			// RbtCustom
			// 
			this.RbtCustom.AutoSize = true;
			this.RbtCustom.Checked = true;
			this.RbtCustom.Font = new System.Drawing.Font("Tahoma", 10F);
			this.RbtCustom.Location = new System.Drawing.Point(16, 24);
			this.RbtCustom.Name = "RbtCustom";
			this.RbtCustom.Size = new System.Drawing.Size(146, 21);
			this.RbtCustom.TabIndex = 0;
			this.RbtCustom.TabStop = true;
			this.RbtCustom.Tag = "custom";
			this.RbtCustom.Text = "Пользовательский";
			this.RbtCustom.UseVisualStyleBackColor = true;
			this.RbtCustom.Click += new System.EventHandler(this.RbtMaterial_Click);
			// 
			// GrbMaterialType
			// 
			this.GrbMaterialType.Controls.Add(this.RbtGranite);
			this.GrbMaterialType.Controls.Add(this.RbtIceWater);
			this.GrbMaterialType.Controls.Add(this.RbtCopper);
			this.GrbMaterialType.Controls.Add(this.RbtSteel);
			this.GrbMaterialType.Controls.Add(this.RbtCustom);
			this.GrbMaterialType.Font = new System.Drawing.Font("Tahoma", 10F);
			this.GrbMaterialType.Location = new System.Drawing.Point(23, 265);
			this.GrbMaterialType.Name = "GrbMaterialType";
			this.GrbMaterialType.Size = new System.Drawing.Size(176, 144);
			this.GrbMaterialType.TabIndex = 30;
			this.GrbMaterialType.TabStop = false;
			this.GrbMaterialType.Text = "Тип материала";
			// 
			// RbtSteel
			// 
			this.RbtSteel.AutoSize = true;
			this.RbtSteel.Font = new System.Drawing.Font("Tahoma", 10F);
			this.RbtSteel.Location = new System.Drawing.Point(16, 48);
			this.RbtSteel.Name = "RbtSteel";
			this.RbtSteel.Size = new System.Drawing.Size(159, 21);
			this.RbtSteel.TabIndex = 1;
			this.RbtSteel.Tag = "steel";
			this.RbtSteel.Text = "Сталь нержавеющая";
			this.RbtSteel.UseVisualStyleBackColor = true;
			this.RbtSteel.Click += new System.EventHandler(this.RbtMaterial_Click);
			// 
			// LblMassResult
			// 
			this.LblMassResult.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.LblMassResult.Location = new System.Drawing.Point(144, 96);
			this.LblMassResult.Name = "LblMassResult";
			this.LblMassResult.Size = new System.Drawing.Size(240, 19);
			this.LblMassResult.TabIndex = 8;
			this.LblMassResult.Text = "Вычисленное значение параметра";
			// 
			// BtnClose
			// 
			this.BtnClose.BackColor = System.Drawing.Color.SteelBlue;
			this.BtnClose.DialogResult = System.Windows.Forms.DialogResult.OK;
			this.BtnClose.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.BtnClose.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.BtnClose.ForeColor = System.Drawing.Color.WhiteSmoke;
			this.BtnClose.Location = new System.Drawing.Point(471, 422);
			this.BtnClose.Name = "BtnClose";
			this.BtnClose.Size = new System.Drawing.Size(232, 40);
			this.BtnClose.TabIndex = 27;
			this.BtnClose.Text = "Закрыть";
			this.BtnClose.UseVisualStyleBackColor = false;
			// 
			// LblMass
			// 
			this.LblMass.AutoSize = true;
			this.LblMass.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.LblMass.Location = new System.Drawing.Point(16, 96);
			this.LblMass.Name = "LblMass";
			this.LblMass.Size = new System.Drawing.Size(57, 19);
			this.LblMass.TabIndex = 7;
			this.LblMass.Text = "Масса:";
			// 
			// GrbCalcParams
			// 
			this.GrbCalcParams.Controls.Add(this.ChbMass);
			this.GrbCalcParams.Controls.Add(this.ChbVolume);
			this.GrbCalcParams.Controls.Add(this.ChbArea);
			this.GrbCalcParams.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.GrbCalcParams.Location = new System.Drawing.Point(207, 262);
			this.GrbCalcParams.Name = "GrbCalcParams";
			this.GrbCalcParams.Size = new System.Drawing.Size(240, 144);
			this.GrbCalcParams.TabIndex = 24;
			this.GrbCalcParams.TabStop = false;
			this.GrbCalcParams.Text = "  Что рассчитывать: ";
			// 
			// ChbMass
			// 
			this.ChbMass.AutoSize = true;
			this.ChbMass.Location = new System.Drawing.Point(24, 96);
			this.ChbMass.Name = "ChbMass";
			this.ChbMass.Size = new System.Drawing.Size(132, 21);
			this.ChbMass.TabIndex = 5;
			this.ChbMass.Text = "Масса цилиндра";
			this.ChbMass.UseVisualStyleBackColor = true;
			// 
			// ChbVolume
			// 
			this.ChbVolume.AutoSize = true;
			this.ChbVolume.Location = new System.Drawing.Point(24, 64);
			this.ChbVolume.Name = "ChbVolume";
			this.ChbVolume.Size = new System.Drawing.Size(136, 21);
			this.ChbVolume.TabIndex = 4;
			this.ChbVolume.Text = "Объем цилиндра";
			this.ChbVolume.UseVisualStyleBackColor = true;
			// 
			// ChbArea
			// 
			this.ChbArea.AutoSize = true;
			this.ChbArea.Location = new System.Drawing.Point(24, 32);
			this.ChbArea.Name = "ChbArea";
			this.ChbArea.Size = new System.Drawing.Size(174, 21);
			this.ChbArea.TabIndex = 3;
			this.ChbArea.Text = "Площадь поверхности";
			this.ChbArea.UseVisualStyleBackColor = true;
			// 
			// GrbResult
			// 
			this.GrbResult.Controls.Add(this.LblMassResult);
			this.GrbResult.Controls.Add(this.LblMass);
			this.GrbResult.Controls.Add(this.LblVolumeResult);
			this.GrbResult.Controls.Add(this.LblVolume);
			this.GrbResult.Controls.Add(this.LblAreaResult);
			this.GrbResult.Controls.Add(this.LblArea);
			this.GrbResult.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.GrbResult.Location = new System.Drawing.Point(463, 262);
			this.GrbResult.Name = "GrbResult";
			this.GrbResult.Size = new System.Drawing.Size(408, 144);
			this.GrbResult.TabIndex = 28;
			this.GrbResult.TabStop = false;
			this.GrbResult.Text = "  Результаты расчета цилиндра:";
			// 
			// LblVolumeResult
			// 
			this.LblVolumeResult.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.LblVolumeResult.Location = new System.Drawing.Point(144, 64);
			this.LblVolumeResult.Name = "LblVolumeResult";
			this.LblVolumeResult.Size = new System.Drawing.Size(240, 19);
			this.LblVolumeResult.TabIndex = 6;
			this.LblVolumeResult.Text = "Вычисленное значение параметра";
			// 
			// LblVolume
			// 
			this.LblVolume.AutoSize = true;
			this.LblVolume.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.LblVolume.Location = new System.Drawing.Point(16, 64);
			this.LblVolume.Name = "LblVolume";
			this.LblVolume.Size = new System.Drawing.Size(63, 19);
			this.LblVolume.TabIndex = 5;
			this.LblVolume.Text = "Объем:";
			// 
			// LblAreaResult
			// 
			this.LblAreaResult.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.LblAreaResult.Location = new System.Drawing.Point(144, 32);
			this.LblAreaResult.Name = "LblAreaResult";
			this.LblAreaResult.Size = new System.Drawing.Size(240, 19);
			this.LblAreaResult.TabIndex = 4;
			this.LblAreaResult.Text = "Вычисленное значение параметра";
			// 
			// LblArea
			// 
			this.LblArea.AutoSize = true;
			this.LblArea.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.LblArea.Location = new System.Drawing.Point(16, 32);
			this.LblArea.Name = "LblArea";
			this.LblArea.Size = new System.Drawing.Size(82, 19);
			this.LblArea.TabIndex = 3;
			this.LblArea.Text = "Площадь:";
			// 
			// GrbFigureData
			// 
			this.GrbFigureData.Controls.Add(this.NudDensity);
			this.GrbFigureData.Controls.Add(this.NudHeight);
			this.GrbFigureData.Controls.Add(this.NudRadius);
			this.GrbFigureData.Controls.Add(this.LblDensity);
			this.GrbFigureData.Controls.Add(this.LblHeight);
			this.GrbFigureData.Controls.Add(this.LblRadius);
			this.GrbFigureData.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.GrbFigureData.Location = new System.Drawing.Point(15, 25);
			this.GrbFigureData.Name = "GrbFigureData";
			this.GrbFigureData.Size = new System.Drawing.Size(408, 200);
			this.GrbFigureData.TabIndex = 23;
			this.GrbFigureData.TabStop = false;
			this.GrbFigureData.Text = " Параметры цилиндра: ";
			// 
			// LblDensity
			// 
			this.LblDensity.AutoSize = true;
			this.LblDensity.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.LblDensity.Location = new System.Drawing.Point(16, 144);
			this.LblDensity.Name = "LblDensity";
			this.LblDensity.Size = new System.Drawing.Size(175, 19);
			this.LblDensity.TabIndex = 6;
			this.LblDensity.Text = "Плотность материала:";
			// 
			// LblHeight
			// 
			this.LblHeight.AutoSize = true;
			this.LblHeight.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.LblHeight.Location = new System.Drawing.Point(16, 88);
			this.LblHeight.Name = "LblHeight";
			this.LblHeight.Size = new System.Drawing.Size(143, 19);
			this.LblHeight.TabIndex = 4;
			this.LblHeight.Text = "Высота цилиндра:";
			// 
			// LblRadius
			// 
			this.LblRadius.AutoSize = true;
			this.LblRadius.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.LblRadius.Location = new System.Drawing.Point(16, 40);
			this.LblRadius.Name = "LblRadius";
			this.LblRadius.Size = new System.Drawing.Size(65, 19);
			this.LblRadius.TabIndex = 0;
			this.LblRadius.Text = "Радиус:";
			// 
			// BtnCalc
			// 
			this.BtnCalc.BackColor = System.Drawing.Color.SteelBlue;
			this.BtnCalc.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.BtnCalc.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.BtnCalc.ForeColor = System.Drawing.Color.WhiteSmoke;
			this.BtnCalc.Location = new System.Drawing.Point(223, 422);
			this.BtnCalc.Name = "BtnCalc";
			this.BtnCalc.Size = new System.Drawing.Size(232, 40);
			this.BtnCalc.TabIndex = 25;
			this.BtnCalc.Text = "Вычислить";
			this.BtnCalc.UseVisualStyleBackColor = false;
			this.BtnCalc.Click += new System.EventHandler(this.BtnCalc_Click);
			// 
			// NudDensity
			// 
			this.NudDensity.DecimalPlaces = 2;
			this.NudDensity.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
			this.NudDensity.Location = new System.Drawing.Point(248, 144);
			this.NudDensity.Maximum = new decimal(new int[] {
            -1530494976,
            232830,
            0,
            0});
			this.NudDensity.Minimum = new decimal(new int[] {
            -1530494976,
            232830,
            0,
            -2147483648});
			this.NudDensity.Name = "NudDensity";
			this.NudDensity.Size = new System.Drawing.Size(152, 24);
			this.NudDensity.TabIndex = 12;
			this.NudDensity.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			// 
			// NudHeight
			// 
			this.NudHeight.DecimalPlaces = 2;
			this.NudHeight.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
			this.NudHeight.Location = new System.Drawing.Point(248, 88);
			this.NudHeight.Maximum = new decimal(new int[] {
            -1530494976,
            232830,
            0,
            0});
			this.NudHeight.Minimum = new decimal(new int[] {
            -1530494976,
            232830,
            0,
            -2147483648});
			this.NudHeight.Name = "NudHeight";
			this.NudHeight.Size = new System.Drawing.Size(152, 24);
			this.NudHeight.TabIndex = 11;
			this.NudHeight.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			// 
			// NudRadius
			// 
			this.NudRadius.DecimalPlaces = 2;
			this.NudRadius.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
			this.NudRadius.Location = new System.Drawing.Point(248, 40);
			this.NudRadius.Maximum = new decimal(new int[] {
            -1530494976,
            232830,
            0,
            0});
			this.NudRadius.Minimum = new decimal(new int[] {
            -1530494976,
            232830,
            0,
            -2147483648});
			this.NudRadius.Name = "NudRadius";
			this.NudRadius.Size = new System.Drawing.Size(152, 24);
			this.NudRadius.TabIndex = 10;
			this.NudRadius.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			// 
			// PcbMaterial
			// 
			this.PcbMaterial.Image = global::Homework6.Properties.Resources.custom;
			this.PcbMaterial.Location = new System.Drawing.Point(695, 25);
			this.PcbMaterial.Name = "PcbMaterial";
			this.PcbMaterial.Size = new System.Drawing.Size(217, 200);
			this.PcbMaterial.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			this.PcbMaterial.TabIndex = 29;
			this.PcbMaterial.TabStop = false;
			// 
			// PcbFigure
			// 
			this.PcbFigure.Image = global::Homework6.Properties.Resources.cylinder;
			this.PcbFigure.Location = new System.Drawing.Point(463, 25);
			this.PcbFigure.Name = "PcbFigure";
			this.PcbFigure.Size = new System.Drawing.Size(176, 200);
			this.PcbFigure.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			this.PcbFigure.TabIndex = 26;
			this.PcbFigure.TabStop = false;
			// 
			// CylinderForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(926, 487);
			this.Controls.Add(this.GrbMaterialType);
			this.Controls.Add(this.PcbMaterial);
			this.Controls.Add(this.PcbFigure);
			this.Controls.Add(this.BtnClose);
			this.Controls.Add(this.GrbCalcParams);
			this.Controls.Add(this.GrbResult);
			this.Controls.Add(this.GrbFigureData);
			this.Controls.Add(this.BtnCalc);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.MaximizeBox = false;
			this.Name = "CylinderForm";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Вычисление параметров цилиндра";
			this.GrbMaterialType.ResumeLayout(false);
			this.GrbMaterialType.PerformLayout();
			this.GrbCalcParams.ResumeLayout(false);
			this.GrbCalcParams.PerformLayout();
			this.GrbResult.ResumeLayout(false);
			this.GrbResult.PerformLayout();
			this.GrbFigureData.ResumeLayout(false);
			this.GrbFigureData.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.NudDensity)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.NudHeight)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.NudRadius)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.PcbMaterial)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.PcbFigure)).EndInit();
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.RadioButton RbtGranite;
		private System.Windows.Forms.RadioButton RbtIceWater;
		private System.Windows.Forms.RadioButton RbtCopper;
		private System.Windows.Forms.RadioButton RbtCustom;
		private System.Windows.Forms.GroupBox GrbMaterialType;
		private System.Windows.Forms.RadioButton RbtSteel;
		private System.Windows.Forms.PictureBox PcbMaterial;
		private System.Windows.Forms.PictureBox PcbFigure;
		private System.Windows.Forms.Button BtnClose;
		private System.Windows.Forms.GroupBox GrbCalcParams;
		private System.Windows.Forms.CheckBox ChbMass;
		private System.Windows.Forms.CheckBox ChbVolume;
		private System.Windows.Forms.CheckBox ChbArea;
		private System.Windows.Forms.GroupBox GrbResult;
		private System.Windows.Forms.Label LblMassResult;
		private System.Windows.Forms.Label LblMass;
		private System.Windows.Forms.Label LblVolumeResult;
		private System.Windows.Forms.Label LblVolume;
		private System.Windows.Forms.Label LblAreaResult;
		private System.Windows.Forms.Label LblArea;
		private System.Windows.Forms.GroupBox GrbFigureData;
		private System.Windows.Forms.Label LblDensity;
		private System.Windows.Forms.Label LblHeight;
		private System.Windows.Forms.Label LblRadius;
		private System.Windows.Forms.Button BtnCalc;
		private System.Windows.Forms.NumericUpDown NudDensity;
		private System.Windows.Forms.NumericUpDown NudHeight;
		private System.Windows.Forms.NumericUpDown NudRadius;
	}
}