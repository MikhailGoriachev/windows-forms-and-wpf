﻿
namespace Homework6.Views
{
	partial class ConeForm
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.RbtGranite = new System.Windows.Forms.RadioButton();
			this.RbtIceWater = new System.Windows.Forms.RadioButton();
			this.RbtCopper = new System.Windows.Forms.RadioButton();
			this.RbtCustom = new System.Windows.Forms.RadioButton();
			this.GrbMaterialType = new System.Windows.Forms.GroupBox();
			this.RbtSteel = new System.Windows.Forms.RadioButton();
			this.PcbMaterial = new System.Windows.Forms.PictureBox();
			this.GrbCalcParams = new System.Windows.Forms.GroupBox();
			this.ChbMass = new System.Windows.Forms.CheckBox();
			this.ChbVolume = new System.Windows.Forms.CheckBox();
			this.ChbArea = new System.Windows.Forms.CheckBox();
			this.GrbFigureData = new System.Windows.Forms.GroupBox();
			this.LblDensity = new System.Windows.Forms.Label();
			this.LblHeight = new System.Windows.Forms.Label();
			this.LblRadiusUp = new System.Windows.Forms.Label();
			this.LblRadiusDown = new System.Windows.Forms.Label();
			this.BtnClose = new System.Windows.Forms.Button();
			this.BtnCalc = new System.Windows.Forms.Button();
			this.PcbFigure = new System.Windows.Forms.PictureBox();
			this.LblMassResult = new System.Windows.Forms.Label();
			this.LblMass = new System.Windows.Forms.Label();
			this.LblVolumeResult = new System.Windows.Forms.Label();
			this.LblVolume = new System.Windows.Forms.Label();
			this.LblAreaResult = new System.Windows.Forms.Label();
			this.LblArea = new System.Windows.Forms.Label();
			this.GrbResult = new System.Windows.Forms.GroupBox();
			this.NudRadiusDown = new System.Windows.Forms.NumericUpDown();
			this.NudRadiusUp = new System.Windows.Forms.NumericUpDown();
			this.NudHeight = new System.Windows.Forms.NumericUpDown();
			this.NudDensity = new System.Windows.Forms.NumericUpDown();
			this.GrbMaterialType.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.PcbMaterial)).BeginInit();
			this.GrbCalcParams.SuspendLayout();
			this.GrbFigureData.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.PcbFigure)).BeginInit();
			this.GrbResult.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.NudRadiusDown)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.NudRadiusUp)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.NudHeight)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.NudDensity)).BeginInit();
			this.SuspendLayout();
			// 
			// RbtGranite
			// 
			this.RbtGranite.AutoSize = true;
			this.RbtGranite.Font = new System.Drawing.Font("Tahoma", 10F);
			this.RbtGranite.Location = new System.Drawing.Point(16, 120);
			this.RbtGranite.Name = "RbtGranite";
			this.RbtGranite.Size = new System.Drawing.Size(72, 21);
			this.RbtGranite.TabIndex = 10;
			this.RbtGranite.TabStop = true;
			this.RbtGranite.Tag = "granite";
			this.RbtGranite.Text = "Гранит";
			this.RbtGranite.UseVisualStyleBackColor = true;
			this.RbtGranite.Click += new System.EventHandler(this.RbtMaterial_Click);
			// 
			// RbtIceWater
			// 
			this.RbtIceWater.AutoSize = true;
			this.RbtIceWater.Font = new System.Drawing.Font("Tahoma", 10F);
			this.RbtIceWater.Location = new System.Drawing.Point(16, 96);
			this.RbtIceWater.Name = "RbtIceWater";
			this.RbtIceWater.Size = new System.Drawing.Size(108, 21);
			this.RbtIceWater.TabIndex = 9;
			this.RbtIceWater.TabStop = true;
			this.RbtIceWater.Tag = "iceWater";
			this.RbtIceWater.Text = "Лед водяной";
			this.RbtIceWater.UseVisualStyleBackColor = true;
			this.RbtIceWater.Click += new System.EventHandler(this.RbtMaterial_Click);
			// 
			// RbtCopper
			// 
			this.RbtCopper.AutoSize = true;
			this.RbtCopper.Font = new System.Drawing.Font("Tahoma", 10F);
			this.RbtCopper.Location = new System.Drawing.Point(16, 72);
			this.RbtCopper.Name = "RbtCopper";
			this.RbtCopper.Size = new System.Drawing.Size(58, 21);
			this.RbtCopper.TabIndex = 8;
			this.RbtCopper.TabStop = true;
			this.RbtCopper.Tag = "copper";
			this.RbtCopper.Text = "Медь";
			this.RbtCopper.UseVisualStyleBackColor = true;
			this.RbtCopper.Click += new System.EventHandler(this.RbtMaterial_Click);
			// 
			// RbtCustom
			// 
			this.RbtCustom.AutoSize = true;
			this.RbtCustom.Checked = true;
			this.RbtCustom.Font = new System.Drawing.Font("Tahoma", 10F);
			this.RbtCustom.Location = new System.Drawing.Point(16, 24);
			this.RbtCustom.Name = "RbtCustom";
			this.RbtCustom.Size = new System.Drawing.Size(146, 21);
			this.RbtCustom.TabIndex = 6;
			this.RbtCustom.TabStop = true;
			this.RbtCustom.Tag = "custom";
			this.RbtCustom.Text = "Пользовательский";
			this.RbtCustom.UseVisualStyleBackColor = true;
			this.RbtCustom.Click += new System.EventHandler(this.RbtMaterial_Click);
			// 
			// GrbMaterialType
			// 
			this.GrbMaterialType.Controls.Add(this.RbtGranite);
			this.GrbMaterialType.Controls.Add(this.RbtIceWater);
			this.GrbMaterialType.Controls.Add(this.RbtCopper);
			this.GrbMaterialType.Controls.Add(this.RbtSteel);
			this.GrbMaterialType.Controls.Add(this.RbtCustom);
			this.GrbMaterialType.Font = new System.Drawing.Font("Tahoma", 10F);
			this.GrbMaterialType.Location = new System.Drawing.Point(23, 242);
			this.GrbMaterialType.Name = "GrbMaterialType";
			this.GrbMaterialType.Size = new System.Drawing.Size(176, 144);
			this.GrbMaterialType.TabIndex = 24;
			this.GrbMaterialType.TabStop = false;
			this.GrbMaterialType.Text = "Тип материала";
			// 
			// RbtSteel
			// 
			this.RbtSteel.AutoSize = true;
			this.RbtSteel.Font = new System.Drawing.Font("Tahoma", 10F);
			this.RbtSteel.Location = new System.Drawing.Point(16, 48);
			this.RbtSteel.Name = "RbtSteel";
			this.RbtSteel.Size = new System.Drawing.Size(159, 21);
			this.RbtSteel.TabIndex = 7;
			this.RbtSteel.TabStop = true;
			this.RbtSteel.Tag = "steel";
			this.RbtSteel.Text = "Сталь нержавеющая";
			this.RbtSteel.UseVisualStyleBackColor = true;
			this.RbtSteel.Click += new System.EventHandler(this.RbtMaterial_Click);
			// 
			// PcbMaterial
			// 
			this.PcbMaterial.Image = global::Homework6.Properties.Resources.custom;
			this.PcbMaterial.Location = new System.Drawing.Point(687, 42);
			this.PcbMaterial.Name = "PcbMaterial";
			this.PcbMaterial.Size = new System.Drawing.Size(164, 162);
			this.PcbMaterial.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			this.PcbMaterial.TabIndex = 23;
			this.PcbMaterial.TabStop = false;
			// 
			// GrbCalcParams
			// 
			this.GrbCalcParams.Controls.Add(this.ChbMass);
			this.GrbCalcParams.Controls.Add(this.ChbVolume);
			this.GrbCalcParams.Controls.Add(this.ChbArea);
			this.GrbCalcParams.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.GrbCalcParams.Location = new System.Drawing.Point(207, 242);
			this.GrbCalcParams.Name = "GrbCalcParams";
			this.GrbCalcParams.Size = new System.Drawing.Size(240, 144);
			this.GrbCalcParams.TabIndex = 18;
			this.GrbCalcParams.TabStop = false;
			this.GrbCalcParams.Text = "  Что рассчитывать: ";
			// 
			// ChbMass
			// 
			this.ChbMass.AutoSize = true;
			this.ChbMass.Location = new System.Drawing.Point(24, 104);
			this.ChbMass.Name = "ChbMass";
			this.ChbMass.Size = new System.Drawing.Size(193, 21);
			this.ChbMass.TabIndex = 5;
			this.ChbMass.Text = "Масса усеченного конуса";
			this.ChbMass.UseVisualStyleBackColor = true;
			// 
			// ChbVolume
			// 
			this.ChbVolume.AutoSize = true;
			this.ChbVolume.Location = new System.Drawing.Point(24, 72);
			this.ChbVolume.Name = "ChbVolume";
			this.ChbVolume.Size = new System.Drawing.Size(197, 21);
			this.ChbVolume.TabIndex = 4;
			this.ChbVolume.Text = "Объем усеченного конуса";
			this.ChbVolume.UseVisualStyleBackColor = true;
			// 
			// ChbArea
			// 
			this.ChbArea.AutoSize = true;
			this.ChbArea.Location = new System.Drawing.Point(24, 40);
			this.ChbArea.Name = "ChbArea";
			this.ChbArea.Size = new System.Drawing.Size(174, 21);
			this.ChbArea.TabIndex = 3;
			this.ChbArea.Text = "Площадь поверхности";
			this.ChbArea.UseVisualStyleBackColor = true;
			// 
			// GrbFigureData
			// 
			this.GrbFigureData.Controls.Add(this.NudDensity);
			this.GrbFigureData.Controls.Add(this.NudHeight);
			this.GrbFigureData.Controls.Add(this.NudRadiusUp);
			this.GrbFigureData.Controls.Add(this.NudRadiusDown);
			this.GrbFigureData.Controls.Add(this.LblDensity);
			this.GrbFigureData.Controls.Add(this.LblHeight);
			this.GrbFigureData.Controls.Add(this.LblRadiusUp);
			this.GrbFigureData.Controls.Add(this.LblRadiusDown);
			this.GrbFigureData.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.GrbFigureData.Location = new System.Drawing.Point(23, 18);
			this.GrbFigureData.Name = "GrbFigureData";
			this.GrbFigureData.Size = new System.Drawing.Size(408, 200);
			this.GrbFigureData.TabIndex = 17;
			this.GrbFigureData.TabStop = false;
			this.GrbFigureData.Text = " Параметры усеченного конуса: ";
			// 
			// LblDensity
			// 
			this.LblDensity.AutoSize = true;
			this.LblDensity.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.LblDensity.Location = new System.Drawing.Point(16, 166);
			this.LblDensity.Name = "LblDensity";
			this.LblDensity.Size = new System.Drawing.Size(175, 19);
			this.LblDensity.TabIndex = 6;
			this.LblDensity.Text = "Плотность материала:";
			// 
			// LblHeight
			// 
			this.LblHeight.AutoSize = true;
			this.LblHeight.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.LblHeight.Location = new System.Drawing.Point(14, 124);
			this.LblHeight.Name = "LblHeight";
			this.LblHeight.Size = new System.Drawing.Size(121, 19);
			this.LblHeight.TabIndex = 4;
			this.LblHeight.Text = "Высота конуса:";
			// 
			// LblRadiusUp
			// 
			this.LblRadiusUp.AutoSize = true;
			this.LblRadiusUp.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.LblRadiusUp.Location = new System.Drawing.Point(16, 82);
			this.LblRadiusUp.Name = "LblRadiusUp";
			this.LblRadiusUp.Size = new System.Drawing.Size(217, 19);
			this.LblRadiusUp.TabIndex = 2;
			this.LblRadiusUp.Text = "Радиус верхнего основания:";
			// 
			// LblRadiusDown
			// 
			this.LblRadiusDown.AutoSize = true;
			this.LblRadiusDown.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.LblRadiusDown.Location = new System.Drawing.Point(16, 40);
			this.LblRadiusDown.Name = "LblRadiusDown";
			this.LblRadiusDown.Size = new System.Drawing.Size(214, 19);
			this.LblRadiusDown.TabIndex = 0;
			this.LblRadiusDown.Text = "Радиус нижнего основания:";
			// 
			// BtnClose
			// 
			this.BtnClose.BackColor = System.Drawing.Color.SteelBlue;
			this.BtnClose.DialogResult = System.Windows.Forms.DialogResult.OK;
			this.BtnClose.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.BtnClose.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.BtnClose.ForeColor = System.Drawing.Color.WhiteSmoke;
			this.BtnClose.Location = new System.Drawing.Point(447, 407);
			this.BtnClose.Name = "BtnClose";
			this.BtnClose.Size = new System.Drawing.Size(232, 40);
			this.BtnClose.TabIndex = 12;
			this.BtnClose.Text = "Закрыть";
			this.BtnClose.UseVisualStyleBackColor = false;
			// 
			// BtnCalc
			// 
			this.BtnCalc.BackColor = System.Drawing.Color.SteelBlue;
			this.BtnCalc.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.BtnCalc.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.BtnCalc.ForeColor = System.Drawing.Color.WhiteSmoke;
			this.BtnCalc.Location = new System.Drawing.Point(199, 407);
			this.BtnCalc.Name = "BtnCalc";
			this.BtnCalc.Size = new System.Drawing.Size(232, 40);
			this.BtnCalc.TabIndex = 11;
			this.BtnCalc.Text = "Вычислить";
			this.BtnCalc.UseVisualStyleBackColor = false;
			this.BtnCalc.Click += new System.EventHandler(this.BtnCalc_Click);
			// 
			// PcbFigure
			// 
			this.PcbFigure.Image = global::Homework6.Properties.Resources.cone;
			this.PcbFigure.Location = new System.Drawing.Point(463, 42);
			this.PcbFigure.Name = "PcbFigure";
			this.PcbFigure.Size = new System.Drawing.Size(164, 162);
			this.PcbFigure.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
			this.PcbFigure.TabIndex = 20;
			this.PcbFigure.TabStop = false;
			// 
			// LblMassResult
			// 
			this.LblMassResult.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.LblMassResult.Location = new System.Drawing.Point(144, 104);
			this.LblMassResult.Name = "LblMassResult";
			this.LblMassResult.Size = new System.Drawing.Size(240, 19);
			this.LblMassResult.TabIndex = 8;
			this.LblMassResult.Text = "Вычисленное значение параметра";
			// 
			// LblMass
			// 
			this.LblMass.AutoSize = true;
			this.LblMass.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.LblMass.Location = new System.Drawing.Point(16, 104);
			this.LblMass.Name = "LblMass";
			this.LblMass.Size = new System.Drawing.Size(57, 19);
			this.LblMass.TabIndex = 7;
			this.LblMass.Text = "Масса:";
			// 
			// LblVolumeResult
			// 
			this.LblVolumeResult.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.LblVolumeResult.Location = new System.Drawing.Point(144, 72);
			this.LblVolumeResult.Name = "LblVolumeResult";
			this.LblVolumeResult.Size = new System.Drawing.Size(240, 19);
			this.LblVolumeResult.TabIndex = 6;
			this.LblVolumeResult.Text = "Вычисленное значение параметра";
			// 
			// LblVolume
			// 
			this.LblVolume.AutoSize = true;
			this.LblVolume.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.LblVolume.Location = new System.Drawing.Point(16, 72);
			this.LblVolume.Name = "LblVolume";
			this.LblVolume.Size = new System.Drawing.Size(63, 19);
			this.LblVolume.TabIndex = 5;
			this.LblVolume.Text = "Объем:";
			// 
			// LblAreaResult
			// 
			this.LblAreaResult.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.LblAreaResult.Location = new System.Drawing.Point(144, 40);
			this.LblAreaResult.Name = "LblAreaResult";
			this.LblAreaResult.Size = new System.Drawing.Size(240, 19);
			this.LblAreaResult.TabIndex = 4;
			this.LblAreaResult.Text = "Вычисленное значение параметра";
			// 
			// LblArea
			// 
			this.LblArea.AutoSize = true;
			this.LblArea.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.LblArea.Location = new System.Drawing.Point(16, 40);
			this.LblArea.Name = "LblArea";
			this.LblArea.Size = new System.Drawing.Size(82, 19);
			this.LblArea.TabIndex = 3;
			this.LblArea.Text = "Площадь:";
			// 
			// GrbResult
			// 
			this.GrbResult.Controls.Add(this.LblMassResult);
			this.GrbResult.Controls.Add(this.LblMass);
			this.GrbResult.Controls.Add(this.LblVolumeResult);
			this.GrbResult.Controls.Add(this.LblVolume);
			this.GrbResult.Controls.Add(this.LblAreaResult);
			this.GrbResult.Controls.Add(this.LblArea);
			this.GrbResult.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.GrbResult.Location = new System.Drawing.Point(463, 242);
			this.GrbResult.Name = "GrbResult";
			this.GrbResult.Size = new System.Drawing.Size(392, 144);
			this.GrbResult.TabIndex = 22;
			this.GrbResult.TabStop = false;
			this.GrbResult.Text = "  Результаты расчета усеченного конуса: ";
			// 
			// NudRadiusDown
			// 
			this.NudRadiusDown.DecimalPlaces = 2;
			this.NudRadiusDown.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
			this.NudRadiusDown.Location = new System.Drawing.Point(240, 40);
			this.NudRadiusDown.Maximum = new decimal(new int[] {
            -1530494976,
            232830,
            0,
            0});
			this.NudRadiusDown.Minimum = new decimal(new int[] {
            -1530494976,
            232830,
            0,
            -2147483648});
			this.NudRadiusDown.Name = "NudRadiusDown";
			this.NudRadiusDown.Size = new System.Drawing.Size(152, 24);
			this.NudRadiusDown.TabIndex = 1;
			this.NudRadiusDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			// 
			// NudRadiusUp
			// 
			this.NudRadiusUp.DecimalPlaces = 2;
			this.NudRadiusUp.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
			this.NudRadiusUp.Location = new System.Drawing.Point(240, 80);
			this.NudRadiusUp.Maximum = new decimal(new int[] {
            -1530494976,
            232830,
            0,
            0});
			this.NudRadiusUp.Minimum = new decimal(new int[] {
            -1530494976,
            232830,
            0,
            -2147483648});
			this.NudRadiusUp.Name = "NudRadiusUp";
			this.NudRadiusUp.Size = new System.Drawing.Size(152, 24);
			this.NudRadiusUp.TabIndex = 7;
			this.NudRadiusUp.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			// 
			// NudHeight
			// 
			this.NudHeight.DecimalPlaces = 2;
			this.NudHeight.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
			this.NudHeight.Location = new System.Drawing.Point(240, 120);
			this.NudHeight.Maximum = new decimal(new int[] {
            -1530494976,
            232830,
            0,
            0});
			this.NudHeight.Minimum = new decimal(new int[] {
            -1530494976,
            232830,
            0,
            -2147483648});
			this.NudHeight.Name = "NudHeight";
			this.NudHeight.Size = new System.Drawing.Size(152, 24);
			this.NudHeight.TabIndex = 8;
			this.NudHeight.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			// 
			// NudDensity
			// 
			this.NudDensity.DecimalPlaces = 2;
			this.NudDensity.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
			this.NudDensity.Location = new System.Drawing.Point(240, 160);
			this.NudDensity.Maximum = new decimal(new int[] {
            -1530494976,
            232830,
            0,
            0});
			this.NudDensity.Minimum = new decimal(new int[] {
            -1530494976,
            232830,
            0,
            -2147483648});
			this.NudDensity.Name = "NudDensity";
			this.NudDensity.Size = new System.Drawing.Size(152, 24);
			this.NudDensity.TabIndex = 9;
			this.NudDensity.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			// 
			// ConeForm
			// 
			this.AcceptButton = this.BtnCalc;
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.GhostWhite;
			this.CancelButton = this.BtnClose;
			this.ClientSize = new System.Drawing.Size(879, 465);
			this.Controls.Add(this.GrbMaterialType);
			this.Controls.Add(this.PcbMaterial);
			this.Controls.Add(this.GrbCalcParams);
			this.Controls.Add(this.GrbFigureData);
			this.Controls.Add(this.BtnClose);
			this.Controls.Add(this.BtnCalc);
			this.Controls.Add(this.PcbFigure);
			this.Controls.Add(this.GrbResult);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.MaximizeBox = false;
			this.Name = "ConeForm";
			this.ShowInTaskbar = false;
			this.Text = "Вычисление параметров усеченного конуса";
			this.GrbMaterialType.ResumeLayout(false);
			this.GrbMaterialType.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.PcbMaterial)).EndInit();
			this.GrbCalcParams.ResumeLayout(false);
			this.GrbCalcParams.PerformLayout();
			this.GrbFigureData.ResumeLayout(false);
			this.GrbFigureData.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.PcbFigure)).EndInit();
			this.GrbResult.ResumeLayout(false);
			this.GrbResult.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.NudRadiusDown)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.NudRadiusUp)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.NudHeight)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.NudDensity)).EndInit();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.RadioButton RbtGranite;
		private System.Windows.Forms.RadioButton RbtIceWater;
		private System.Windows.Forms.RadioButton RbtCopper;
		private System.Windows.Forms.RadioButton RbtCustom;
		private System.Windows.Forms.GroupBox GrbMaterialType;
		private System.Windows.Forms.RadioButton RbtSteel;
		private System.Windows.Forms.PictureBox PcbMaterial;
		private System.Windows.Forms.GroupBox GrbCalcParams;
		private System.Windows.Forms.CheckBox ChbMass;
		private System.Windows.Forms.CheckBox ChbVolume;
		private System.Windows.Forms.CheckBox ChbArea;
		private System.Windows.Forms.GroupBox GrbFigureData;
		private System.Windows.Forms.NumericUpDown NudDensity;
		private System.Windows.Forms.NumericUpDown NudHeight;
		private System.Windows.Forms.NumericUpDown NudRadiusUp;
		private System.Windows.Forms.NumericUpDown NudRadiusDown;
		private System.Windows.Forms.Label LblDensity;
		private System.Windows.Forms.Label LblHeight;
		private System.Windows.Forms.Label LblRadiusUp;
		private System.Windows.Forms.Label LblRadiusDown;
		private System.Windows.Forms.Button BtnClose;
		private System.Windows.Forms.Button BtnCalc;
		private System.Windows.Forms.PictureBox PcbFigure;
		private System.Windows.Forms.Label LblMassResult;
		private System.Windows.Forms.Label LblMass;
		private System.Windows.Forms.Label LblVolumeResult;
		private System.Windows.Forms.Label LblVolume;
		private System.Windows.Forms.Label LblAreaResult;
		private System.Windows.Forms.Label LblArea;
		private System.Windows.Forms.GroupBox GrbResult;
	}
}