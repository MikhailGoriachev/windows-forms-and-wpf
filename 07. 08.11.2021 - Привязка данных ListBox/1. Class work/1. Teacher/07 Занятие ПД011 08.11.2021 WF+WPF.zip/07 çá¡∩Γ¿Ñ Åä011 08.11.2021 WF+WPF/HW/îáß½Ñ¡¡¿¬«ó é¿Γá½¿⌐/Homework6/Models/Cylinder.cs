﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Homework6.Models
{
	// Класс определения цилиндра
	class Cylinder : IFigure
	{
		private double _radius;
		public double Radius
		{
			get => _radius;
			set
			{
				if (value <= 0)
				throw new ArgumentException(
					"Радиус должен иметь положительное значение");
				_radius = value;
			}

		}

		public double _height;
		public double Height
		{
			get => _height;
			set
			{
				if (value <= 0)
					throw new ArgumentException(
						"Высота должна иметь положительное значение");

				_height = value;
			}
		}

		private double _density;
		public double Density
		{
			get => _density;
			set
			{
				if (value <= 0)
					throw new ArgumentException("Sphere. Отрицательная или нулевая плотность материала");
				_density = value;
			}
		}

		public double Area => 2 * Math.PI * _radius * (_height + _radius);
		public double Volume => Math.PI * _radius * _radius * _height;
		public double Mass => Volume * _density;

		public Cylinder() : this(1d, 2d, 1d)
		{ }

		public Cylinder(double radius, double height, double density)
		{
			Radius = radius;
			Height = height;
			Density = density;
		}


		public override string ToString() =>
			$"Фигура: Цилиндр. Радиус: {_radius:f3}; высота: {_height}; плотность: {_density:f3}";

		public string GetCalculatedPropertiesInfo() =>
			$"Площадь поверхности:{Area:f3}; объем:{Volume}; масса:{Mass}";
	}
}
