﻿
namespace Homework6.Views
{
	partial class ListsForm
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.LbxCities1 = new System.Windows.Forms.ListBox();
			this.LbxCities2 = new System.Windows.Forms.ListBox();
			this.BtnCmd1 = new System.Windows.Forms.Button();
			this.BtnCmd2 = new System.Windows.Forms.Button();
			this.BtnCmd3 = new System.Windows.Forms.Button();
			this.BtnCmd4 = new System.Windows.Forms.Button();
			this.BtnCmd5 = new System.Windows.Forms.Button();
			this.BtnCmd6 = new System.Windows.Forms.Button();
			this.BtnCmd7 = new System.Windows.Forms.Button();
			this.TxbInputCity = new System.Windows.Forms.TextBox();
			this.CbxCities = new System.Windows.Forms.ComboBox();
			this.SuspendLayout();
			// 
			// LbxCities1
			// 
			this.LbxCities1.FormattingEnabled = true;
			this.LbxCities1.Items.AddRange(new object[] {
            "Донецк",
            "Макеевка",
            "Ясиноватая",
            "Зарцызк",
            "Докучаевск",
            "Старобешево",
            "Енакиево",
            "Горловка",
            "Дебальцево",
            "Зугрэс",
            "Иловайск",
            "Торез ",
            "Шахтерск",
            "Углегорск"});
			this.LbxCities1.Location = new System.Drawing.Point(34, 30);
			this.LbxCities1.Name = "LbxCities1";
			this.LbxCities1.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended;
			this.LbxCities1.Size = new System.Drawing.Size(256, 199);
			this.LbxCities1.TabIndex = 0;
			// 
			// LbxCities2
			// 
			this.LbxCities2.FormattingEnabled = true;
			this.LbxCities2.Location = new System.Drawing.Point(327, 30);
			this.LbxCities2.Name = "LbxCities2";
			this.LbxCities2.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended;
			this.LbxCities2.Size = new System.Drawing.Size(259, 199);
			this.LbxCities2.TabIndex = 1;
			// 
			// BtnCmd1
			// 
			this.BtnCmd1.Location = new System.Drawing.Point(34, 254);
			this.BtnCmd1.Name = "BtnCmd1";
			this.BtnCmd1.Size = new System.Drawing.Size(552, 32);
			this.BtnCmd1.TabIndex = 2;
			this.BtnCmd1.Text = "Перемещение выбранного элемента из первого лист-бокса во второй";
			this.BtnCmd1.UseVisualStyleBackColor = true;
			this.BtnCmd1.Click += new System.EventHandler(this.BtnCmd1_Click);
			// 
			// BtnCmd2
			// 
			this.BtnCmd2.Location = new System.Drawing.Point(34, 294);
			this.BtnCmd2.Name = "BtnCmd2";
			this.BtnCmd2.Size = new System.Drawing.Size(552, 32);
			this.BtnCmd2.TabIndex = 3;
			this.BtnCmd2.Text = "Перемещение всех элементов из первого лист-бокса во второй";
			this.BtnCmd2.UseVisualStyleBackColor = true;
			this.BtnCmd2.Click += new System.EventHandler(this.BtnCmd2_Click);
			// 
			// BtnCmd3
			// 
			this.BtnCmd3.Location = new System.Drawing.Point(34, 334);
			this.BtnCmd3.Name = "BtnCmd3";
			this.BtnCmd3.Size = new System.Drawing.Size(552, 32);
			this.BtnCmd3.TabIndex = 4;
			this.BtnCmd3.Text = "Перемещение выбранного элемента из второго лист-бокса в первый";
			this.BtnCmd3.UseVisualStyleBackColor = true;
			this.BtnCmd3.Click += new System.EventHandler(this.BtnCmd3_Click);
			// 
			// BtnCmd4
			// 
			this.BtnCmd4.Location = new System.Drawing.Point(34, 374);
			this.BtnCmd4.Name = "BtnCmd4";
			this.BtnCmd4.Size = new System.Drawing.Size(552, 32);
			this.BtnCmd4.TabIndex = 5;
			this.BtnCmd4.Text = "Перемещение всех элементов из второго лист-бокса в первый";
			this.BtnCmd4.UseVisualStyleBackColor = true;
			this.BtnCmd4.Click += new System.EventHandler(this.BtnCmd4_Click);
			// 
			// BtnCmd5
			// 
			this.BtnCmd5.Location = new System.Drawing.Point(34, 414);
			this.BtnCmd5.Name = "BtnCmd5";
			this.BtnCmd5.Size = new System.Drawing.Size(552, 32);
			this.BtnCmd5.TabIndex = 6;
			this.BtnCmd5.Text = "Очистка обоих лист-боксов";
			this.BtnCmd5.UseVisualStyleBackColor = true;
			this.BtnCmd5.Click += new System.EventHandler(this.BtnCmd5_Click);
			// 
			// BtnCmd6
			// 
			this.BtnCmd6.Location = new System.Drawing.Point(34, 454);
			this.BtnCmd6.Name = "BtnCmd6";
			this.BtnCmd6.Size = new System.Drawing.Size(552, 32);
			this.BtnCmd6.TabIndex = 7;
			this.BtnCmd6.Text = "Ввод названия города в строку ввода и добавление города по кнопке в первый лист-б" +
    "окс";
			this.BtnCmd6.UseVisualStyleBackColor = true;
			this.BtnCmd6.Click += new System.EventHandler(this.BtnCmd6_Click);
			// 
			// BtnCmd7
			// 
			this.BtnCmd7.Location = new System.Drawing.Point(32, 522);
			this.BtnCmd7.Name = "BtnCmd7";
			this.BtnCmd7.Size = new System.Drawing.Size(552, 32);
			this.BtnCmd7.TabIndex = 8;
			this.BtnCmd7.Text = "Выбор названия города из комбо-бокса и добавление города по событию выбора во вто" +
    "рой комбо-бокс ";
			this.BtnCmd7.UseVisualStyleBackColor = true;
			this.BtnCmd7.Click += new System.EventHandler(this.BtnCmd7_Click);
			// 
			// TxbInputCity
			// 
			this.TxbInputCity.Location = new System.Drawing.Point(32, 494);
			this.TxbInputCity.Name = "TxbInputCity";
			this.TxbInputCity.Size = new System.Drawing.Size(552, 20);
			this.TxbInputCity.TabIndex = 9;
			// 
			// CbxCities
			// 
			this.CbxCities.FormattingEnabled = true;
			this.CbxCities.Items.AddRange(new object[] {
            "Донецк",
            "Макеевка",
            "Ясиноватая",
            "Зарцызк",
            "Докучаевск",
            "Старобешево",
            "Енакиево",
            "Горловка",
            "Дебальцево",
            "Зугрэс",
            "Иловайск",
            "Торез ",
            "Шахтерск",
            "Углегорск"});
			this.CbxCities.Location = new System.Drawing.Point(32, 562);
			this.CbxCities.Name = "CbxCities";
			this.CbxCities.Size = new System.Drawing.Size(552, 21);
			this.CbxCities.TabIndex = 10;
			this.CbxCities.SelectedIndexChanged += new System.EventHandler(this.CbxCities_SelectedIndexChanged);
			// 
			// ListsForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(620, 614);
			this.Controls.Add(this.CbxCities);
			this.Controls.Add(this.TxbInputCity);
			this.Controls.Add(this.BtnCmd7);
			this.Controls.Add(this.BtnCmd6);
			this.Controls.Add(this.BtnCmd5);
			this.Controls.Add(this.BtnCmd4);
			this.Controls.Add(this.BtnCmd3);
			this.Controls.Add(this.BtnCmd2);
			this.Controls.Add(this.BtnCmd1);
			this.Controls.Add(this.LbxCities2);
			this.Controls.Add(this.LbxCities1);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.MaximizeBox = false;
			this.Name = "ListsForm";
			this.ShowInTaskbar = false;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Списки";
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.ListBox LbxCities1;
		private System.Windows.Forms.ListBox LbxCities2;
		private System.Windows.Forms.Button BtnCmd1;
		private System.Windows.Forms.Button BtnCmd2;
		private System.Windows.Forms.Button BtnCmd3;
		private System.Windows.Forms.Button BtnCmd4;
		private System.Windows.Forms.Button BtnCmd5;
		private System.Windows.Forms.Button BtnCmd6;
		private System.Windows.Forms.Button BtnCmd7;
		private System.Windows.Forms.TextBox TxbInputCity;
		private System.Windows.Forms.ComboBox CbxCities;
	}
}