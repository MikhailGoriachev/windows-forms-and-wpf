﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Homework6.Views
{
	public partial class ListsForm : Form
	{
		public ListsForm()
		{
			InitializeComponent();
		}
		// •	перемещение выбранного элемента из первого лист-бокса во второй
		private void BtnCmd1_Click(object sender, EventArgs e)
		{
			foreach (int index in LbxCities1.SelectedIndices)
			{
				LbxCities2.Items.Add(LbxCities1.Items[index]);
			}
		}

		// •	перемещение всех элементов из первого лист-бокса во второй
		private void BtnCmd2_Click(object sender, EventArgs e)
		{
			foreach (var elem in LbxCities1.Items)
			{
				LbxCities2.Items.Add(elem);
			}

			LbxCities1.Items.Clear();
		}

		// •	перемещение выбранного элемента из второго лист-бокса в первый
		private void BtnCmd3_Click(object sender, EventArgs e)
		{
			foreach (int index in LbxCities2.SelectedIndices)
			{
				LbxCities1.Items.Add(LbxCities2.Items[index]);
			}
		}

		// •	перемещение всех элементов из второго лист-бокса в первый
		private void BtnCmd4_Click(object sender, EventArgs e)
		{
			foreach (var elem in LbxCities2.Items)
			{
				LbxCities1.Items.Add(elem);
			}

			LbxCities2.Items.Clear();
		}

		// •	очистка обоих лист-боксов
		private void BtnCmd5_Click(object sender, EventArgs e)
		{
			LbxCities1.Items.Clear();
			LbxCities2.Items.Clear();
		}

		// •	ввод названия города в строку ввода и добавление города по кнопке в первый лист-бокс
		private void BtnCmd6_Click(object sender, EventArgs e)
		{
			LbxCities1.Items.Add(TxbInputCity.Text);
		}

		// •	выбор названия города из комбо-бокса и добавление города по событию выбора во второй комбо-бокс 
		private void BtnCmd7_Click(object sender, EventArgs e)
		{


		}

		private void CbxCities_SelectedIndexChanged(object sender, EventArgs e)
		{
			if (CbxCities.SelectedIndex < 0)
				return;

			string item = (string)CbxCities.Items[CbxCities.SelectedIndex];
			LbxCities2.Items.Add(item);
		}
	}
}
