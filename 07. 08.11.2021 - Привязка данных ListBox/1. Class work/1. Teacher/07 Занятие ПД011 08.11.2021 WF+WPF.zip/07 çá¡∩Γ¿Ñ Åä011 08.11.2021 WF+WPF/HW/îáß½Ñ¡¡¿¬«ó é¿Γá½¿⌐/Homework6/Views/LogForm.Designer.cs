﻿
namespace Homework6.Views
{
	partial class LogForm
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.BtnClose = new System.Windows.Forms.Button();
			this.TxbLogging = new System.Windows.Forms.TextBox();
			this.LblJournal = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// BtnClose
			// 
			this.BtnClose.BackColor = System.Drawing.Color.SteelBlue;
			this.BtnClose.DialogResult = System.Windows.Forms.DialogResult.OK;
			this.BtnClose.Font = new System.Drawing.Font("Verdana", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.BtnClose.ForeColor = System.Drawing.Color.White;
			this.BtnClose.Location = new System.Drawing.Point(24, 389);
			this.BtnClose.Margin = new System.Windows.Forms.Padding(2);
			this.BtnClose.Name = "BtnClose";
			this.BtnClose.Size = new System.Drawing.Size(689, 32);
			this.BtnClose.TabIndex = 7;
			this.BtnClose.Text = "Закрыть";
			this.BtnClose.UseVisualStyleBackColor = false;
			// 
			// TxbLogging
			// 
			this.TxbLogging.BackColor = System.Drawing.SystemColors.Window;
			this.TxbLogging.Font = new System.Drawing.Font("Consolas", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.TxbLogging.Location = new System.Drawing.Point(23, 39);
			this.TxbLogging.Margin = new System.Windows.Forms.Padding(2);
			this.TxbLogging.Multiline = true;
			this.TxbLogging.Name = "TxbLogging";
			this.TxbLogging.ReadOnly = true;
			this.TxbLogging.ScrollBars = System.Windows.Forms.ScrollBars.Both;
			this.TxbLogging.Size = new System.Drawing.Size(691, 332);
			this.TxbLogging.TabIndex = 6;
			this.TxbLogging.TabStop = false;
			this.TxbLogging.WordWrap = false;
			// 
			// LblJournal
			// 
			this.LblJournal.AutoSize = true;
			this.LblJournal.Font = new System.Drawing.Font("Tahoma", 9F);
			this.LblJournal.Location = new System.Drawing.Point(24, 16);
			this.LblJournal.Name = "LblJournal";
			this.LblJournal.Size = new System.Drawing.Size(108, 14);
			this.LblJournal.TabIndex = 9;
			this.LblJournal.Text = "Журнал событий:";
			// 
			// LogForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(736, 435);
			this.Controls.Add(this.LblJournal);
			this.Controls.Add(this.BtnClose);
			this.Controls.Add(this.TxbLogging);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.MaximizeBox = false;
			this.Name = "LogForm";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Журнал";
			this.Load += new System.EventHandler(this.LogForm_Load);
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion
		private System.Windows.Forms.Button BtnClose;
		private System.Windows.Forms.TextBox TxbLogging;
		private System.Windows.Forms.Label LblJournal;
	}
}