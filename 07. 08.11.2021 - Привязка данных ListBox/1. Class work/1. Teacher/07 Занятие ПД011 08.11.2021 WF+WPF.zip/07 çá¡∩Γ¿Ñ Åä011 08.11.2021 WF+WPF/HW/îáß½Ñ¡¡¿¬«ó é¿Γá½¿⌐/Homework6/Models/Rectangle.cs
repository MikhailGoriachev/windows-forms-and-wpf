﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Homework6.Models
{
	// Класс определения прямоугольного паралеллепипеда
	internal class Rectangle : IFigure
	{
		private double _a;
		public double A
		{
			get => _a;
			set {
				if (value <= 0)
					throw new ArgumentException(
					"Стороны прямоугольника должны иметь положительное значение");
				_a = value;
			}
		}

		private double _b;
		public double B
		{
			get => _b;
			set {
				if (value <= 0)
					throw new ArgumentException(
						"Стороны прямоугольника должны иметь положительное значение");
				_b = value;
			}
		}

		private double _c;

		public double C
		{
			get => _c;
			set
			{
				if (value <= 0)
					throw new ArgumentException(
						"Стороны прямоугольника должны иметь положительное значение");
				_c = value;
			}
		}

		private double _height;
		public double Height
		{
			get => _height;
			set
			{
				if (value <= 0)
					throw new ArgumentException(
						"Высота должна иметь положительное значение");

				_height = value;
			}
		}

		private double _density;

		public double Density
		{
			get => _density;
			set
			{
				if (value <= 0)
					throw new ArgumentException(
						"Плотность должна иметь положительное значение");
				_density = value;
			}
		}


		public double Volume => A * B * C;
		public double Area => 2 * (A * B + B * C + A * C);
		public double Mass => Volume * Density;

		public Rectangle():this(1d, 1d, 1d, 1d) {}

		Rectangle(double a, double b, double c, double density)
		{
			A = a;
			B = b;
			C = c;
			Density = density;
		}

		public override string ToString() =>
			$"Фигура: Параллелепипед. Сторона А: {A:f3}; cторона B: {B}; cторона C: {C}; плотность: {_density:f3}";

		public string GetCalculatedPropertiesInfo() =>
			$"Площадь поверхности:{Area:f3}; объем:{Volume}; масса:{Mass}";
	}
}
