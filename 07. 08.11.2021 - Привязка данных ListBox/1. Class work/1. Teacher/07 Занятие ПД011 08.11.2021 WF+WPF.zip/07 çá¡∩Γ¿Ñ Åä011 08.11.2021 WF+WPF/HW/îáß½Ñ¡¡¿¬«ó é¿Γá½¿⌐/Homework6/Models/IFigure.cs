﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Homework6.Models
{
	public interface IFigure
	{
		double Volume { get; }
		double Area { get; }
		double Mass { get; }

		string GetCalculatedPropertiesInfo();
	}
}
