﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Homework6.Models;

namespace Homework6.Helpers
{
	internal static class Logger
	{
		// константа путь и имя файла 
		public const string fileName = @"log.txt";

		// Дозаписать информацию об произведенной операции в файл
		public static void AppendRecord(string fileName, IFigure figure, string result)
		{
			File.AppendAllLines(
				fileName, (Logger.FormatMsg(figure) + result).
					Split('\n'));
		}

		public static string FormatMsg(IFigure figure)
		{
			return $"{DateTime.Now}\r\n" +
			       $"{figure}\r\n";// +
			       //$"{figure.GetCalculatedPropertiesInfo()}\r\n";
		}

		// Прочесть файл в строку
		public static string ReadLogFileIntoString(string fileName) => string.Join("\r\n", File.ReadAllLines(fileName));


		// Очистить файл журнала
		public static void ClearLog(string fileName) => File.WriteAllText(fileName, String.Empty);
	}
}
