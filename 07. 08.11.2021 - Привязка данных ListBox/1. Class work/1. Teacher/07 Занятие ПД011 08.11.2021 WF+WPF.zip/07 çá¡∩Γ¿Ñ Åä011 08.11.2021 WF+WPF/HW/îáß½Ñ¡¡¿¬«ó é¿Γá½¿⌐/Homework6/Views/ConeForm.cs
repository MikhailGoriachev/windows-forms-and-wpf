﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Homework6.Helpers;
using Homework6.Models;

namespace Homework6.Views
{
	public partial class ConeForm : Form
	{
		// модель для формы
		private Conoid _conoid;

		public ConeForm()
		{
			InitializeComponent();

			// создать модель для работы формы
			_conoid = new Conoid();


			// начальное значение полей ввода TextBox
			NudRadiusDown.Text = $"{_conoid.RadiusDown:f3}";
			NudRadiusUp.Text = $"{_conoid.RadiusUp:f3}";
			NudHeight.Text = $"{_conoid.Height:f3}";
			NudDensity.Text = $"{_conoid.Density:f3}";

			// начальное значение меток вывода результата
			LblAreaResult.Text = LblVolumeResult.Text = LblMassResult.Text = "---''---";
		}


		// обработчик кликов по радиокнопкам выбора материала
		private void RbtMaterial_Click(object sender, EventArgs e)
		{
			RadioButton rbt = sender as RadioButton;

			// если выбран один из предложенных типов материала, запретить ввод в поле плотности,
			// если пользовательский - разрешить
			if (rbt != null && (string)rbt.Tag == "custom")
			{
				NudDensity.ReadOnly = false;
				NudDensity.Increment = 0.01M;
			}
			else
			{
				NudDensity.ReadOnly = true;
				NudDensity.Increment = 0;
			}


			string imgFile = Materials.MaterialsList[(string)rbt.Tag].ImageFile;
			double density = Materials.MaterialsList[(string)rbt.Tag].Density;

			// изменение картинки и плотности в поле ввода
			NudDensity.Text = density.ToString();
			PcbMaterial.Image = Image.FromFile(@"..\..\Images\Materials\" + imgFile);
		}

		private void BtnCalc_Click(object sender, EventArgs e)
		{
			try
			{
				if(NudDensity.Text == ""  || 
				   NudHeight.Text == ""   ||
				   NudRadiusUp.Text == "" ||
				   NudRadiusDown.Text == "")
					throw new InvalidDataException($"Введена не полная информация");

				// проверка на уровне модели
				if (_conoid.RadiusDown <= _conoid.RadiusUp)
					throw new InvalidDataException($"Нижнее основание конуса меньше или равно верхнему");

				// получить текущие данные из полей ввода
				_conoid.RadiusDown = double.Parse(NudRadiusDown.Text);
				_conoid.RadiusUp = double.Parse(NudRadiusUp.Text);
				_conoid.Height = double.Parse(NudHeight.Text);
				_conoid.Density = double.Parse(NudDensity.Text);

				// вычисление параметров, если это задано
				LblAreaResult.Text = ChbArea.Checked ? $"{_conoid.Area:n3}" : "Расчет не требуется";
				LblVolumeResult.Text = ChbVolume.Checked ? $"{_conoid.Volume:n3}" : "Расчет не требуется";
				LblMassResult.Text = ChbMass.Checked ? $"{_conoid.Mass:n3}" : "Расчет не требуется";

				// Дозапись информации о вычислениях

				string material = null;

				switch (_conoid.Density)
				{
					case 7850.0: material = "Нержавеющая сталь;\n";
						break;
					case 8933.0:
						material = "Медь\n";
						break;
					case 916.7:
						material = "Водяной лёд\n";
						break;
					case 2600.0:
						material = "Гранит\n";
						break;
					default: material = "Не задано;\n";
						break;
				}


				string result = $"Материал: " + material + 
				                $"Площадь поверхности: {LblAreaResult.Text};\n" +
				                $"Объем: {LblVolumeResult.Text};\n" +
				                $"Масса: {LblMassResult.Text}\n" +
				                $"───────────────────────────────────────────";
				Logger.AppendRecord(Logger.fileName, _conoid, result);
			}
			catch (Exception ex)
			{
				// обработка ошибки уровня модели 
				LblAreaResult.Text = LblVolumeResult.Text = LblMassResult.Text = "---''---";
				MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);

				// Передать фокус ввода на первое поле ввода
				NudRadiusDown.Focus();
			}
		}

	}

}
