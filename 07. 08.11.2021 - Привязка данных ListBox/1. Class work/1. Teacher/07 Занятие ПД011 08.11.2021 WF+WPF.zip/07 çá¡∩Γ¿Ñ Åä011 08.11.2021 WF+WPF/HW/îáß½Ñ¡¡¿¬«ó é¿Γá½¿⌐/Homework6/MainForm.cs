﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Homework6.Helpers;
using Homework6.Views;

namespace Homework6
{
	public partial class MainForm : Form
	{
		public MainForm()
		{
			InitializeComponent();
		}

		private void MnuFiguresConoid_Click(object sender, EventArgs e)
		{
			ConeForm coneForm = new ConeForm();
			
			coneForm.ShowDialog();

			if (File.Exists(Logger.fileName))
				TxbHistory.Text = Logger.ReadLogFileIntoString(Logger.fileName);
		}

		private void MnuFiguresCylinder_Click(object sender, EventArgs e)
		{
			CylinderForm cylinderForm = new CylinderForm();

			cylinderForm.ShowDialog();

			if (File.Exists(Logger.fileName))
				TxbHistory.Text = Logger.ReadLogFileIntoString(Logger.fileName);
		}


		private void MainForm_Load(object sender, EventArgs e)
		{
			if (File.Exists(Logger.fileName))
				TxbHistory.Text = Logger.ReadLogFileIntoString(Logger.fileName);
		}

		private void MnuHelpAbout_Click(object sender, EventArgs e)
		{
			AboutForm aboutForm = new AboutForm();
			aboutForm.ShowDialog();
		}

		private void MnuFileExit_Click(object sender, EventArgs e) => Application.Exit();

		private void MnuJournalView_Click(object sender, EventArgs e)
		{
			LogForm logForm = new LogForm();
			logForm.ShowDialog();
		}

		private void MnuJournalClear_Click(object sender, EventArgs e) {
			Logger.ClearLog(Logger.fileName);

			MessageBox.Show("Журнал очищен", "Журнал", MessageBoxButtons.OK, MessageBoxIcon.Information);

			if (File.Exists(Logger.fileName))
				TxbHistory.Text = Logger.ReadLogFileIntoString(Logger.fileName);
		}

		private void MnuLists_Click(object sender, EventArgs e)
		{
			ListsForm listForm = new ListsForm();
			listForm.Show();
		}

		private void MnuFiguresSphere_Click(object sender, EventArgs e) =>
			MessageBox.Show("В разработке", "Уведомление", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);

		private void MnuFiguresParallelepiped_Click(object sender, EventArgs e) =>
			MessageBox.Show("В разработке", "Уведомление", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);

	}
}
