﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Homework6.Helpers;

namespace Homework6.Views
{
	public partial class LogForm : Form
	{
		public LogForm()
		{
			InitializeComponent();
		}

		private void LogForm_Load(object sender, EventArgs e)
		{
			if (File.Exists(Logger.fileName))
				TxbLogging.Text = Logger.ReadLogFileIntoString(Logger.fileName);
		}
	}
}
