﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Homework6.Helpers;
using Homework6.Models;

namespace Homework6.Views
{
	public partial class CylinderForm : Form
	{
		// модель для формы
		private Cylinder _сylinder;

		public CylinderForm()
		{
			InitializeComponent();

			// создать модель для работы формы
			_сylinder = new Cylinder();

			// начальное значение полей ввода TextBox
			NudRadius.Text = $"{_сylinder.Radius:f3}";
			NudHeight.Text = $"{_сylinder.Height:f3}";
			NudDensity.Text = $"{_сylinder.Density:f3}";

			// начальное значение меток вывода результата
			LblAreaResult.Text = LblVolumeResult.Text = LblMassResult.Text = "---''---";
		}

		// обработчик кликов по радиокнопкам выбора материала
		private void RbtMaterial_Click(object sender, EventArgs e)
		{
			RadioButton rbt = sender as RadioButton;

			// если выбран один из предложенных типов материала, запретить ввод в поле плотности,
			// если пользовательский - разрешить
			if (rbt != null && (string)rbt.Tag == "custom")
			{
				NudDensity.ReadOnly = false;
				NudDensity.Increment = 0.01M;
			}
			else
			{
				NudDensity.ReadOnly = true;
				NudDensity.Increment = 0;
			}


			string imgFile = Materials.MaterialsList[(string)rbt.Tag].ImageFile;
			double density = Materials.MaterialsList[(string)rbt.Tag].Density;

			// изменение картинки и плотности в поле ввода
			NudDensity.Text = density.ToString();
			PcbMaterial.Image = Image.FromFile(@"..\..\Images\Materials\" + imgFile);
		}

		private void BtnCalc_Click(object sender, EventArgs e)
		{
			try
			{
				if (NudDensity.Text == "" ||
				    NudHeight.Text == "" ||
				    NudRadius.Text == "")
					throw new InvalidDataException($"Введена не полная информация");
				
				// получить текущие данные из полей ввода
				_сylinder.Radius = double.Parse(NudRadius.Text);
				_сylinder.Height = double.Parse(NudHeight.Text);
				_сylinder.Density = double.Parse(NudDensity.Text);

				// вычисление параметров, если это задано
				LblAreaResult.Text = ChbArea.Checked ? $"{_сylinder.Area:n3}" : "Расчет не требуется";
				LblVolumeResult.Text = ChbVolume.Checked ? $"{_сylinder.Volume:n3}" : "Расчет не требуется";
				LblMassResult.Text = ChbMass.Checked ? $"{_сylinder.Mass:n3}" : "Расчет не требуется";

				// Дозапись информации о вычислениях

				string material = null;

				switch (_сylinder.Density)
				{
					case 7850.0:
						material = "Нержавеющая сталь;\n";
						break;
					case 8933.0:
						material = "Медь\n";
						break;
					case 916.7:
						material = "Водяной лёд\n";
						break;
					case 2600.0:
						material = "Гранит\n";
						break;
					default:
						material = "Не задано;\n";
						break;
				}


				string result = $"Материал: " + material +
				                $"Площадь поверхности: {LblAreaResult.Text};\n" +
				                $"Объем: {LblVolumeResult.Text};\n" +
				                $"Масса: {LblMassResult.Text}\n" +
				                $"───────────────────────────────────────────";
				Logger.AppendRecord(Logger.fileName, _сylinder, result);
			}
			catch (Exception ex)
			{
				LblAreaResult.Text = LblVolumeResult.Text = LblMassResult.Text = "---''---";
				MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);

				// Передать фокус ввода на первое поле ввода
				NudRadius.Focus();
			}
		}

	}
}
