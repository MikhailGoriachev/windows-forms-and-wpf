﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Homework6.Views
{
	public partial class AboutForm : Form
	{
		public AboutForm()
		{
			InitializeComponent();

			LblInfo.Text =
				"Для объемных геометрических фигур:\n" +
				"     • усеченный конус\n" +
				"     • сфера\n" +
				"     • цилиндр\n" +
				"     • прямоугольный параллелепипед\n" +
				"Вычисялются параметры:\n" +
				"    • площадь поверхности\n" +
				"    • объем\n" +
				"    • масса\n" +
				"Каждая фигура размещена в собственной форме";
		}

		private void AboutForm_Load(object sender, EventArgs e)
		{
			TmrAbout.Interval = 10_000;
			TmrAbout.Enabled = true;
		}

		private void TmrAbout_Tick(object sender, EventArgs e)
		{
			TmrAbout.Enabled = false;
			Close();
		}

		private void BtnOk_Click(object sender, EventArgs e)
		{
			TmrAbout.Enabled = false;
			Close();
		}
	}
}
