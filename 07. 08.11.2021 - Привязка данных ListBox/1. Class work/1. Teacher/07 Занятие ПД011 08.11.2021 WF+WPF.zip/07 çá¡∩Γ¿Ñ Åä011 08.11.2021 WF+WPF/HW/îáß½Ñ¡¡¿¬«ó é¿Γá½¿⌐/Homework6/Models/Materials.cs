﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Homework6.Models
{
	internal static class Materials
	{
		public struct Material
		{
			public double Density { get; set; }
			public string ImageFile { get; set; }
		}

		public static Dictionary<string, Material> MaterialsList = new Dictionary<string, Material>()
		{
			["custom"] = new Material()   { Density = 1, ImageFile = "custom.png"},
			["steel"] = new Material()    { Density = 7850.0, ImageFile = "steel.png"},
			["copper"] = new Material()   { Density = 8933.0, ImageFile = "copper.png"},
			["iceWater"] = new Material() { Density = 916.7, ImageFile = "icewater.png"},
			["granite"] = new Material()  { Density = 2600.0, ImageFile = "granite.png"}
		};
	}
}
