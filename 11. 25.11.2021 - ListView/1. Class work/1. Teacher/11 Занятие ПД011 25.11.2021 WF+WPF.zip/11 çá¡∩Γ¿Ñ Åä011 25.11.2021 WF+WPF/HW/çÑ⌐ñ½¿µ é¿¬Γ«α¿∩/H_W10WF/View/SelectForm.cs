﻿using H_W10WF.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace H_W10WF.View
{
    public partial class SelectForm : Form
    {
        public SelectForm() : this(new List<Television>(), "Нет данных для отображения")
        { } // SelectionsForm
        public SelectForm(List<Television> televisions, string header)
        {
            InitializeComponent();

            // вывести заголовок
            LblTelevisions.Text = $"{header}\r\n{Television.Header}";

            // задать привязку
            LbxTelevisions.DataSource = televisions;

            // свойство для отображения в ListBox
            LbxTelevisions.DisplayMember = "TableRow";
        }
    }
}
