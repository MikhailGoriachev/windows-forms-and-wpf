﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace H_W10WF.Views
{
	public partial class RepairShopEditForm : Form
	{
		public string NameShop { get; private set; }
		public string Address { get; private set; }

		public RepairShopEditForm(string title, string address)
		{
			InitializeComponent();

			TxbTitle.Text = title;
			TxbAddress.Text = address;
		}// RepairShopEditForm

		private void BtnSave_Click(object sender, EventArgs e)
		{
			NameShop = TxbTitle.Text;
			Address = TxbAddress.Text;
		}// BtnSave_Click

		private void BtnCancel_Click(object sender, EventArgs e) => Close();

		private void ShopSettingsForm_FormClosing(object sender, FormClosingEventArgs e)
		{
			if ((DialogResult == DialogResult.OK) 
			    & (string.IsNullOrWhiteSpace(TxbAddress.Text) ||
				   string.IsNullOrWhiteSpace(TxbAddress.Text)))
			{
				MessageBox.Show("Не все поля заполнены", "Ошибка",
					MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				e.Cancel = true;
			}
		}// ShopSettingsForm_FormClosing
	}// RepairShopEditForm
}
