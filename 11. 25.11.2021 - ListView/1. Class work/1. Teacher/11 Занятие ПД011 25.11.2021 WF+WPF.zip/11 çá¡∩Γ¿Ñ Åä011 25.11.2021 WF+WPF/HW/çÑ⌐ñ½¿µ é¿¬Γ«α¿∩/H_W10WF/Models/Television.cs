﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace H_W10WF.Models
{
    /// <summary>
    /// Класс описывающий Television (
    /// *производитель и тип телевизора,
    /// *диагональ экрана,
    /// *строка с описанием дефекта,
    /// *фамилия и инициалами мастера,
    /// *фамилия и инициалы владельца,
    /// *стоимость ремонта).
    /// </summary>
    [DataContract]  // для JSON
    public class Television
    {
        // производитель и тип телевизора
        private string _tvBrand;
        [DataMember]
        public string TvBrand {
            get => _tvBrand;
            set {
                if (string.IsNullOrEmpty(value))
                    throw new ArgumentNullException("Television:Пустая строка типа телевизора");

                _tvBrand = value;
            }
        }// TvBrand

        // диагональ экрана
        private int _diagonal;
        [DataMember]
        public int Diagonal {
            get => _diagonal;
            set {
                if (value <= 0)
                    throw new ArgumentOutOfRangeException($"Television:Недопустимая диагональ экрана: {value}");

                _diagonal = value;
            }
        }// Diagonal

        // строка с описанием дефекта
        private string _tvDefect;
        [DataMember]
        public string TvDefect {
            get => _tvDefect;
            set {
                if (string.IsNullOrEmpty(value))
                    throw new ArgumentNullException("Television:Пустая строка c описанием дефекта телевизора");

               _tvDefect = value;
            }
        }// TvDefect

        // фамилия и инициалами мастера
        private string _fullnameMaster;
        [DataMember]
        public string FullnameMaster {
            get => _fullnameMaster;
            set {
                if (string.IsNullOrEmpty(value))
                    throw new ArgumentNullException("Television:Пустая строка c ФИО мастера");

                _fullnameMaster = value;
            }
        }// FullnameMaster

        // фамилия и инициалы владельца
        private string _fullnameOwner;
        [DataMember]
        public string FullnameOwner
        {
            get => _fullnameOwner;
            set
            {
                if (string.IsNullOrEmpty(value))
                    throw new ArgumentNullException("Television:Пустая строка c ФИО владельца");

                _fullnameOwner = value;
            }
        }// FullnameOwner

        // стоимость ремонта
        private int _costRepair;
        [DataMember]
        public int CostRepair {
            get => _costRepair;
            set {
                if (value <= 0)
                    throw new ArgumentOutOfRangeException($"Television:Недопустимая стоимость ремонта: {value}");

                _costRepair = value;
            }
        }// CostRepair

        // ансамбль конструкторов
        public Television():this("Sony", 42, "Разбит монитор", "Петров А.А", "Иванов И.И.", 2000) { }

        public Television(string brand, int diagonal, string defect, string supMaster, string supOwner, int cost) {
            TvBrand        = brand;
            Diagonal       = diagonal;
            TvDefect       = defect;
            FullnameMaster = supMaster;
            FullnameOwner  = supOwner;
            CostRepair     = cost;
        }// Television


        // строковое представление объекта
        override public string ToString() =>
            $"{_tvBrand}, {_diagonal} дюйм, {_tvDefect} ; Мастер:{_fullnameMaster}; Владелец{_fullnameOwner}; Цена: {_costRepair}рубл.";

        // формирование строки таблицы, свойство
        public string TableRow =>
            $" {_tvBrand,-7} │ {_diagonal,4} │ {_tvDefect,-25} │ {_fullnameMaster,-12} │ {_fullnameOwner,-13} │ {_costRepair,6}";

        // шапка таблицы, статическое свойство
        public static string Header =>
            $"Модель  Диагональ    Описание дефекта        Мастер       Владелец      Цена, руб. ";

    }// class Television
}
