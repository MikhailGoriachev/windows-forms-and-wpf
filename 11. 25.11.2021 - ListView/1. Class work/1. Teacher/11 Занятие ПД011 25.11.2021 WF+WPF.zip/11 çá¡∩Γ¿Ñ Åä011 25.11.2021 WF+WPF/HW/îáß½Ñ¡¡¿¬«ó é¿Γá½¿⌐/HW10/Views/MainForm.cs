﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using HW10.Controllers;
using HW10.Models;
using HW10.Views;

namespace HW10.Views
{
	public partial class MainForm : Form
	{
		// объект контроллера для работы
		private RepairShopController _repairShopController;

		public MainForm() : this(new RepairShopController()) { }

		public MainForm(RepairShopController repairShopController)
		{

			InitializeComponent();

			_repairShopController = repairShopController;

			// установка делегатов сортировок в тег элементов для сокращения кода
			MnuOrderByBrandType.Tag = TsbOrderByBrand.Tag = new OrderParams
			{
				Sorter = (Action<List<Television>>) RepairShopController.OrderByBrand,
				TabName = "Сортировка - бренд", Prompt = "Телевизоры отсортированы по бренду и модели:"
			};
			MnuOrderByDiagDesc.Tag = TsbOrderByDiagonal.Tag = new OrderParams
			{
				Sorter = (Action<List<Television>>)RepairShopController.OrderByDiagonalDesc,
				TabName = "Сортировка - диагональ",
				Prompt = "Телевизоры отсортированы по диагонали по убыванию:"
			};
			MnuOrderByOwner.Tag = TsbOrderByOwner.Tag = new OrderParams
			{
				Sorter = (Action<List<Television>>)RepairShopController.OrderByOwner,
				TabName = "Сортировка - владелец",
				Prompt = "Телевизоры отсортированы по владельцу:"
			};
			MnuOrderByPrice.Tag = TsbOrderByPrice.Tag = new OrderParams
			{
				Sorter = (Action<List<Television>>)RepairShopController.OrderByPrice,
				TabName = "Сортировка - стоимость",
				Prompt = "Телевизоры отсортированы по стоимости ремонта:"
			};
			MnuOrderByRepairer.Tag = TsbOrderByRepairer.Tag = new OrderParams
			{
				Sorter = (Action<List<Television>>)RepairShopController.OrderByRepairer,
				TabName = "Сортировка - мастер",
				Prompt = "Телевизоры отсортированы по мастеру, выполняющему работы:"
			};

			BindCollection();
		}

		// выполняется после конструктора формы
		private void MainForm_Load(object sender, EventArgs e)
		{

			// установка текста в информационные элементы формы
			GrbShopTitle.Text = _repairShopController.RepairShop.Title + ". Адрес: " + _repairShopController.RepairShop.Address;
			StlMain.Text = $"Телевизоров в ремонте: {_repairShopController.RepairShop.Count}";
			LblHeader.Text = Television.Header;

			UpdateComboBoxes();

			SilentSave();
		}

		// обновление заголовка главного окна
		private void UpdateMainTitle()
		{
			// формировка заголовка с проверкой на наличией изменений с последнего сохранения
			StringBuilder sb = new StringBuilder();
			sb.Append(_repairShopController.IsSaved ? "" : "*");
			sb.Append(string.IsNullOrEmpty(_repairShopController.FileName) ? "Новая коллекция" : Path.GetFileNameWithoutExtension(_repairShopController.FileName));
			sb.Append(" - RepairShop");

			// установка заголовка в форму
			Text = sb.ToString();
		}

		private void UpdateComboBoxes()
		{
			CbxRepairer.ComboBox.DataSource = _repairShopController.RepairShop.GetRepairers;
			CbxOwners.ComboBox.DataSource = _repairShopController.RepairShop.GetOwners;
			CbxDiagonal.ComboBox.DataSource = _repairShopController.RepairShop.GetDiagonals;
		}

		// выполнение привязки коллекции
		private void BindCollection()
		{
			// остановить привязку
			LbxTelevisions.DataSource = null;

			// задать привязку
			LbxTelevisions.DataSource = _repairShopController.RepairShop.Televisions;

			LbxTelevisions.DisplayMember = "TableRow";
		}

		// команда заверешния работы приложения
		private void Exit_Command(object sender, EventArgs e) => Application.Exit();

		// обработка события закрытия формы
		private void MainForm_FormClosing(object sender, FormClosingEventArgs e)
		{
			// если изменений в данных после последнего сохранения не было - разрешаем событие
			if (_repairShopController.IsSaved) return;

			// иначе спрашиваем сохранить ли данные в файл
			DialogResult result = MessageBox.Show($"Сохранить данные?", "RepairShop", MessageBoxButtons.YesNoCancel,
				MessageBoxIcon.Question);

			switch (result)
			{
				// пользователь выбрал отмену закрытия программы (Cancel)
				case DialogResult.Cancel:
					e.Cancel = true;
					break;
				// выбрано сохранить данные - инициируем метод сохранения
				case DialogResult.Yes:
					// если открытый диалог сохранения не завершен утвердительно - отменяем событие закрытия формы
					e.Cancel = !SaveFile();
					break;
			}
		}


		// команда отображения окна сведений о программе
		private void About_Command(object sender, EventArgs e) => new AboutForm().ShowDialog();
		

		// Команда отображения формы изменения данных о ремонтной мастерской
		private void ShopSettings_Command(object sender, EventArgs e)
		{
			ShopSettingsForm settingsForm =
				new ShopSettingsForm(_repairShopController.RepairShop.Title, _repairShopController.RepairShop.Address);

			if (settingsForm.ShowDialog() != DialogResult.OK) return;

			_repairShopController.RepairShop.Title = settingsForm.Title;
			_repairShopController.RepairShop.Address = settingsForm.Address;

			GrbShopTitle.Text = _repairShopController.RepairShop.Title + ". Адрес: " + _repairShopController.RepairShop.Address;

			SilentSave();
		}

		// Обработка выделения элемента листбокса перед появлением контекстного меню
		// по нажатию на правую кнопку мыши
		private void LbxTelevisions_MouseUp(object sender, MouseEventArgs e)
		{
			if (e.Button == MouseButtons.Right)
			{
				int index = this.LbxTelevisions.IndexFromPoint(e.Location);
				if (index != ListBox.NoMatches)
					LbxTelevisions.SelectedIndex = index;
			}
		}

		// Обработка двойного щелчка по листу - изменение элемента
		private void LbxTelevisions_MouseDoubleClick(object sender, MouseEventArgs e) =>
			TelevisionEdit_Command(sender, e);



		#region Управление коллекцией записей о телевизорах

		// Сформировать коллекцию заново
		private void Regenerate_Command(object sender, EventArgs e)
		{
			_repairShopController.RepairShop.Initialize();
			BindCollection();

			UpdateComboBoxes();
			SilentSave();

			StlMain.Text = $"Сгенерирована новая коллекция. Телевизоров в ремонте: {_repairShopController.RepairShop.Count}";
			TbcMain.SelectedIndex = 0;
		}

		// Удалить выделенную запись о телевизоре
		private void TelevisionRemove_Command(object sender, EventArgs e)
		{
			if (LbxTelevisions.SelectedIndex < 0)
				return;

			// индекс выбранного элемента
			int selected = LbxTelevisions.SelectedIndex;

			// удаление записи данных 
			_repairShopController.RepairShop.RemoveAt(selected);

			// перепривязка данных
			BindCollection();

			// Возврат выделения элемента на место удаленного, если возможно
			LbxTelevisions.SelectedIndex = !_repairShopController.RepairShop.IsEmpty
				? selected < _repairShopController.RepairShop.Count
					? selected : _repairShopController.RepairShop.Count - 1 : -1;

			// обновить строку состояния
			StlMain.Text = $"Из коллекции был удалён телевизор. Текущее количество телевизоров: {_repairShopController.RepairShop.Count}";
			UpdateComboBoxes();
			SilentSave();
		}


		// Добавить запись о телевизоре
		private void TelevisionAdd_Command(object sender, EventArgs e)
		{

			TVForm tvForm = new TVForm();
			DialogResult dialogResult = tvForm.ShowDialog();

			// если окно закрыто не по кнопке "Добавить" - молча уходим
			if (dialogResult != DialogResult.OK) return;

			// получить данные из свойства формы
			Television television = tvForm.Tv;
			_repairShopController.RepairShop.AddTelevision(television);

			// обновить привязку
			BindCollection();

			// установка выделения в конец списка на новый элемент
			LbxTelevisions.SelectedIndex = _repairShopController.RepairShop.Count - 1;

			// обновить строку состояния
			StlMain.Text = $"В коллекцию был добавлен телевизор. Текущее количество телевизоров: {_repairShopController.RepairShop.Count}";
			UpdateComboBoxes();
			SilentSave();
		}

		// Редактировать выделенную запись о телевизоре
		private void TelevisionEdit_Command(object sender, EventArgs e)
		{
			// если нет выбранного телевизора - уходим
			if (LbxTelevisions.SelectedIndex < 0)
				return;

			// индекс выбранного элемента
			int selected = LbxTelevisions.SelectedIndex;

			// передача данных в форму
			TVForm tvForm = new TVForm("Редактировать данные о телевизоре", "Сохранить")
			{
				Tv = _repairShopController.RepairShop[selected]
			};

			if (tvForm.ShowDialog() != DialogResult.OK) return;

			// получить данные
			_repairShopController.RepairShop[LbxTelevisions.SelectedIndex] = tvForm.Tv;

			BindCollection();

			// Установка выделения на изменённый элемент
			LbxTelevisions.SelectedIndex = selected;

			// обновить строку состояния
			StlMain.Text = $"Были изменены данные о телевизоре. Текущее количество телевизоров: {_repairShopController.RepairShop.Count}";
			UpdateComboBoxes();
			SilentSave();
		}


		// Удалить все данные о телевизорах
		private void RemoveAll_Command(object sender, EventArgs e)
		{
			_repairShopController.RepairShop.RemoveAll();
			BindCollection();

			StlMain.Text = $"Все данные удалены.";
			UpdateComboBoxes();
			SilentSave();
		}

		#endregion



		#region Сортировка

		// Вызов сортировки c объектом параметров из тега ToolStripMenu
		private void ToolStripMenu_OrderBy_Click(object sender, EventArgs e) =>
			OrderBy_Command((OrderParams)((ToolStripMenuItem)sender).Tag);

		// Вызов сортировки c объектом параметров из тега ToolStripButton
		private void ToolStripButton_OrderBy_Click(object sender, EventArgs e) =>
			OrderBy_Command((OrderParams)((ToolStripButton)sender).Tag);

		// Сортировка по переданным параметрам
		private void OrderBy_Command(OrderParams orderParams)
		{
			// Создание копии текущего списка записей о телевизорах
			List<Television> tvs = _repairShopController.RepairShop.Televisions;
			// Сортировка делегатом из переданного объекта
			orderParams.Sorter(tvs);
			// Создание новой вкладки
			CreateTab(tvs, orderParams.TabName, orderParams.Prompt);
		}

		#endregion



		#region Выборка записей

		// Выборка и вывод в отдельной форме коллекции телевизоров с минимальной
		// стоимостью ремонта
		private void ReportMinPrice_Command(object sender, EventArgs e)
		{
			// Список телевизоров с минимальной стоимостью ремонта
			List<Television> reported = _repairShopController.SelectWhereMinPrice();

			// Создание новой вкладки
			CreateTab(reported, "Выборка стоимости", "Телевизоры с минимальной стоимостью ремонта:");
		}

		// Выборка по мастеру
		private void ReportByRepairer_Command(object sender, EventArgs e)
		{
			// Получение списка мастеров
			List<string> repairers = _repairShopController.RepairShop.GetRepairers;

			// Создание формы выбора мастера
			ChoiceReportArgForm choiceForm = new ChoiceReportArgForm(repairers, "Выбор мастера", "Выберите мастера:");

			if (choiceForm.ShowDialog() != DialogResult.OK) return;

			// Создание новой вкладки
			CreateTab(_repairShopController.SelectWhereRepairer(choiceForm.Choosen),
				$"Ремонты {choiceForm.Choosen}", $"Телевизоры ремонтируемые мастером {choiceForm.Choosen}:");
		}

		// Выборка по владельцу
		private void ReportByOwner_Command(object sender, EventArgs e)
		{
			// Получение списка владельцев
			List<string> owners = _repairShopController.RepairShop.GetOwners;

			// Создание формы выбора владельца
			ChoiceReportArgForm choiceForm = new ChoiceReportArgForm(owners, "Выбор владельца", "Выберите владельца:");

			if (choiceForm.ShowDialog() != DialogResult.OK) return;

			// Создание новой вкладки
			CreateTab(_repairShopController.SelectWhereOwner(choiceForm.Choosen),
				$"Телевизоры {choiceForm.Choosen}", $"Телевизоры владельца {choiceForm.Choosen}:");
		}

		// Выборка по диагонали
		private void ReportByDiagonal_Command(object sender, EventArgs e)
		{
			// Получение списка мастеров
			List<string> repairers = _repairShopController.RepairShop.GetDiagonals;

			// Создание формы выбора мастера
			ChoiceReportArgForm choiceForm = new ChoiceReportArgForm(repairers, "Выбор диагонали", "Выберите диагональ:");

			if (choiceForm.ShowDialog() != DialogResult.OK) return;

			// Создание новой вкладки
			CreateTab(_repairShopController.SelectWhereDiagonal(int.Parse(choiceForm.Choosen)),
				$"Дигональ {choiceForm.Choosen}\"", $"Телевизоры с диагональю {choiceForm.Choosen}\":");
		}

		// Выборка по мастеру с панели инструментов
		private void TbsRepairerSelection_Click(object sender, EventArgs e) =>
			CreateTab(_repairShopController.SelectWhereRepairer(CbxRepairer.Text),
				$"Ремонты {CbxRepairer.Text}", $"Телевизоры ремонтируемые мастером {CbxRepairer.Text}:");

		// Выборка по диагонали с панели инструментов
		private void TbsDiagonalSelection_Click(object sender, EventArgs e)=>
			CreateTab(_repairShopController.SelectWhereDiagonal(int.Parse(CbxDiagonal.Text)),
				$"Дигональ {CbxDiagonal.Text}\"", $"Телевизоры с диагональю {CbxDiagonal.Text}\":");

		// Выборка по владельцу с панели инструментов
		private void TsbOwnerSelection_Click(object sender, EventArgs e) =>
			CreateTab(_repairShopController.SelectWhereOwner(CbxOwners.Text),
				$"Телевизоры {CbxOwners.Text}", $"Телевизоры владельца {CbxOwners.Text}:");
		#endregion



		#region Сохранение и загрузка
		/*
		 * Изначально была модель сохранения "документоориентированных" программ, с отслеживанием данных,
		 * оставил обработки и добавил "тихое сохранение" для операций изменения
		 */


		// Вызов диалога выбора файла и сохранение
		private bool SaveFile()
		{
			// установка директории для выбора файла (если не была выбрана ранее - директория исполняющего файла)
			SfdMain.InitialDirectory = string.IsNullOrEmpty(_repairShopController.FileName) ?
				string.IsNullOrEmpty(_repairShopController.LastDirectory) ? Environment.CurrentDirectory : Path.GetDirectoryName(_repairShopController.LastDirectory) :
				Path.GetDirectoryName(_repairShopController.FileName);

			if (SfdMain.ShowDialog() != DialogResult.OK) return false;

			_repairShopController.FileName = SfdMain.FileName;
			_repairShopController.SaveJsonToFile(_repairShopController.FileName);

			return true;
		}

		// Тихое сохранение при операциях изменения данных
		private void SilentSave()
		{
			if (string.IsNullOrEmpty(_repairShopController.FileName))
			{
				SaveFile();
				UpdateMainTitle();
				return;
			}

			_repairShopController.SaveJsonToFile(_repairShopController.FileName);
			_repairShopController.IsSaved = true;
			UpdateMainTitle();
		}


		// Обработка команды "сохранить как"
		private void SaveAs_Command(object sender, EventArgs e)
		{
			// запуск сохраняющего метода и проверка на результат
			if (!SaveFile()) return;

			StlMain.Text = $"Коллекция сохранена в файл. Телевизоров в ремонте: {_repairShopController.RepairShop.Count}";

			// обновление флага изменений и заголовка окна
			_repairShopController.IsSaved = true;
			UpdateMainTitle();
		}


		// Обработка команды "сохранить"
		private void FileSave_Command(object sender, EventArgs e)
		{
			// если файл не был сохранён ранее - вызываем команду "сохранить как"
			if (string.IsNullOrEmpty(_repairShopController.FileName))
				SaveAs_Command(sender, e);
			else
				_repairShopController.SaveJsonToFile(_repairShopController.FileName);

			StlMain.Text = $"Коллекция сохранена в файл. Телевизоров в ремонте: {_repairShopController.RepairShop.Count}";

			// обновление флага изменений и заголовка окна
			_repairShopController.IsSaved = true;
			UpdateMainTitle();
		}

		// Команда открытия файла
		private void FileOpen_Command(object sender, EventArgs e)
		{
			// установка директории для выбора файла (если не была выбрана ранее - директория исполняющего файла)
			OfdMain.InitialDirectory = string.IsNullOrEmpty(_repairShopController.FileName) ?
				string.IsNullOrEmpty(_repairShopController.LastDirectory) ? Environment.CurrentDirectory : Path.GetDirectoryName(_repairShopController.LastDirectory) :
									Path.GetDirectoryName(_repairShopController.FileName);

			// запуск диалогового окна открытия и проверка на результат
			if (OfdMain.ShowDialog() != DialogResult.OK) return;


			_repairShopController.FileName = OfdMain.FileName;
			_repairShopController.ReadJsonFromFile(_repairShopController.FileName);

			BindCollection();

			StlMain.Text = $"Коллекция загружена из файла. Телевизоров в ремонте: {_repairShopController.RepairShop.Count}";

			// обновление флага изменений и заголовка окна
			_repairShopController.IsSaved = true;
			UpdateMainTitle();
		}

		private void FileNew_Command(object sender, EventArgs e)
		{
			// Запомнить последний путь
			_repairShopController.LastDirectory = _repairShopController.FileName;

			// Очистить текущее имя файла
			_repairShopController.FileName = "";

			ShopSettings_Command(sender, e);

			// Очистить данные и обновить листбокс
			_repairShopController.RepairShop.RemoveAll();
			BindCollection();
		}





		#endregion



		#region Смена шрифта и фона

		// Команда смены шрифта
		private void Font_Command(object sender, EventArgs e) {
			if (FdlTextFont.ShowDialog() == DialogResult.OK)
				SetFont();
		}

		// Обработка кнопки применить в диалоге смены шрифта
		private void FdlTextFont_Apply(object sender, EventArgs e) => SetFont();

		// Непосредственно установка значения фона
		public void SetFont()
		{
			LbxTelevisions.Font = FdlTextFont.Font;
			LblHeader.Font = FdlTextFont.Font;
		}
		
		// Команда смены цвета фона
		private void BackColor_Command(object sender, EventArgs e)
		{
			if (CdlBackColor.ShowDialog() == DialogResult.OK){
				LbxTelevisions.BackColor = CdlBackColor.Color;
				LblHeader.BackColor = CdlBackColor.Color;
			}
		}

		// Команда смены цвета текста
		private void ForeColor_Command(object sender, EventArgs e)
		{
			if (CdlBackColor.ShowDialog() == DialogResult.OK)
			{
				LbxTelevisions.ForeColor = CdlBackColor.Color;
				LblHeader.ForeColor = CdlBackColor.Color;
			}
		}
		#endregion



		#region Команды для трея
		// Команда сворачивания в трей
		private void ToTray_Command(object sender, EventArgs e)
		{
			this.Hide();
			NtiMain.BalloonTipText = _repairShopController.RepairShop.Title;
			NtiMain.Visible = true;
		}

		// Команда востановления из трея
		private void Restore_Command(object sender, EventArgs e)
		{
			this.Show();
			WindowState = FormWindowState.Normal;
			NtiMain.Visible = false;
		}

		// Восстановление из трея по дабл-клику
		private void CmnTray_MouseDoubleClick(object sender, MouseEventArgs e) =>
			Restore_Command(sender, e);

		#endregion


		// Обработчик поднятия кнопки мыши на TabControl
		private void TbcMain_MouseUp(object sender, MouseEventArgs e)
		{
			// Получить прямоугольник координат заголовка выбранной вкладки
			Rectangle r = TbcMain.GetTabRect(TbcMain.SelectedIndex);
			
			// Создать на основе полученного прямоугольника координаты закрывающей псевдокнопки
			Rectangle closeButton = new Rectangle(r.Left + 5, r.Top + 5, 16, 16);

			// Если координаты нажатия попадают в зону псевдокнопки и 
			if (closeButton.Contains(e.Location) && TbcMain.SelectedTab.TabIndex != 0)
				TbcMain.TabPages.Remove(TbcMain.SelectedTab);
		}

		// Обработчик нажатия кнопки мыши на TabControl (закрытие вкладок по средней кнопке мыши)
		private void TbcMain_MouseDown(object sender, MouseEventArgs e)
		{
			if (e.Button != MouseButtons.Middle) return;
			
			for (int i = 1; i < TbcMain.TabCount; i++)
				if (TbcMain.GetTabRect(i).Contains(e.Location))
					TbcMain.TabPages.RemoveAt(i);
		}

		// Смена выбранной вкладки
		private void TbcMain_SelectedIndexChanged(object sender, EventArgs e)
		{
			// Разрешить опредленные кнопки только при выбранной главной вкладке
			MnuEditAddTv.Enabled = MnuEditEditTV.Enabled = MnuEditRemove.Enabled = MnuEditRemoveAll.Enabled =
			TsbEdit.Enabled = TsbRemove.Enabled = TsbRemoveAll.Enabled = TsbAdd.Enabled = 
				TbcMain.SelectedTab.TabIndex == 0;
		}


		// Создание новой вкладки со списком телевизоров
		public void CreateTab(List<Television> listTv, string tabName, string gbxTitle)
		{
			// Создание объектов вкладки и её элементов
			TabPage newTab = new TabPage();
			GroupBox gbx = new GroupBox();
			Label lblHeader = new Label();
			Label lblTime = new Label();
			ListBox lbx = new ListBox();

			// Настройка свойств лейбела-шапки для листбокса
			lblHeader.BackColor = System.Drawing.SystemColors.Window;
			lblHeader.Font = new System.Drawing.Font("Consolas", 12F);
			lblHeader.Location = new System.Drawing.Point(16, 32);
			lblHeader.Name = "lblHeader";
			lblHeader.Size = new System.Drawing.Size(1072, 72);
			lblHeader.TabIndex = 8;
			lblHeader.Text = Television.Header;

			// Настройка свойств лейбла-штампа даты-времени
			lblTime.AutoSize = true;
			lblTime.BackColor = System.Drawing.SystemColors.Window;
			lblTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
			lblTime.Location = new System.Drawing.Point(966, 0);
			lblTime.Name = "lblTime";
			lblTime.Size = new System.Drawing.Size(46, 18);
			lblTime.TabIndex = 9;
			lblTime.Text = $"[{DateTime.Now:g}]";

			// Настройка свойств листбокса
			lbx.Font = new System.Drawing.Font("Consolas", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			lbx.FormattingEnabled = true;
			lbx.ItemHeight = 19;
			lbx.Location = new System.Drawing.Point(16, 104);
			lbx.Name = "lbx";
			lbx.ScrollAlwaysVisible = true;
			lbx.Size = new System.Drawing.Size(1072, 213);
			lbx.TabIndex = 5;
			lbx.DataSource = listTv;
			lbx.DisplayMember = "TableRow";

			// Настройка свойств групбокса, включающего элементы выше
			gbx.Controls.Add(lblHeader);
			gbx.Controls.Add(lblTime);
			gbx.Controls.Add(lbx);
			gbx.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
			gbx.Location = new System.Drawing.Point(16, 16);
			gbx.Name = "gbx";
			gbx.Size = new System.Drawing.Size(1104, 328);
			gbx.TabIndex = 14;
			gbx.TabStop = false;
			gbx.Text = gbxTitle;

			// Настройка свойств создаваемой вкладки
			newTab.Controls.Add(gbx);
			newTab.ImageIndex = 0;
			newTab.Location = new System.Drawing.Point(4, 27);
			newTab.Name = "TabSelect";
			newTab.Size = new System.Drawing.Size(1162, 358);
			newTab.TabIndex = 1;
			newTab.Text = tabName;
			newTab.UseVisualStyleBackColor = true;

			// Добавление вкладки в TabControl
			TbcMain.TabPages.Add(newTab);

			// Установка фокуса на созданную вкладку
			TbcMain.SelectedIndex = TbcMain.TabCount - 1;
		}

		
	}
}
