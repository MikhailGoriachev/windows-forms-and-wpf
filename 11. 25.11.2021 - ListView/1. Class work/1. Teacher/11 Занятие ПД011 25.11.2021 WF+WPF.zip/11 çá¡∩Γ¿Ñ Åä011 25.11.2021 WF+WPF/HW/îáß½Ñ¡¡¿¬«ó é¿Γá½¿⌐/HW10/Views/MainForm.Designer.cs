﻿
namespace HW10.Views
{
	partial class MainForm
	{
		/// <summary>
		/// Обязательная переменная конструктора.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Освободить все используемые ресурсы.
		/// </summary>
		/// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Код, автоматически созданный конструктором форм Windows

		/// <summary>
		/// Требуемый метод для поддержки конструктора — не изменяйте 
		/// содержимое этого метода с помощью редактора кода.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
			this.LbxTelevisions = new System.Windows.Forms.ListBox();
			this.CmnList = new System.Windows.Forms.ContextMenuStrip(this.components);
			this.CmnListAdd = new System.Windows.Forms.ToolStripMenuItem();
			this.CmnListEdit = new System.Windows.Forms.ToolStripMenuItem();
			this.CmnListRemove = new System.Windows.Forms.ToolStripMenuItem();
			this.CmnForm = new System.Windows.Forms.ContextMenuStrip(this.components);
			this.CmnMainAbout = new System.Windows.Forms.ToolStripMenuItem();
			this.CmnMainExit = new System.Windows.Forms.ToolStripMenuItem();
			this.StsMain = new System.Windows.Forms.StatusStrip();
			this.StlMain = new System.Windows.Forms.ToolStripStatusLabel();
			this.LblHeader = new System.Windows.Forms.Label();
			this.MnuMain = new System.Windows.Forms.MenuStrip();
			this.MnuFile = new System.Windows.Forms.ToolStripMenuItem();
			this.MnuFileNew = new System.Windows.Forms.ToolStripMenuItem();
			this.MnuFileOpen = new System.Windows.Forms.ToolStripMenuItem();
			this.MnuFileSave = new System.Windows.Forms.ToolStripMenuItem();
			this.MnuFileSaveAs = new System.Windows.Forms.ToolStripMenuItem();
			this.toolStripSeparator10 = new System.Windows.Forms.ToolStripSeparator();
			this.MnuFileExit = new System.Windows.Forms.ToolStripMenuItem();
			this.MnuEdit = new System.Windows.Forms.ToolStripMenuItem();
			this.сформироватьДанныеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
			this.MnuEditAddTv = new System.Windows.Forms.ToolStripMenuItem();
			this.MnuEditEditTV = new System.Windows.Forms.ToolStripMenuItem();
			this.MnuEditRemove = new System.Windows.Forms.ToolStripMenuItem();
			this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
			this.MnuEditRemoveAll = new System.Windows.Forms.ToolStripMenuItem();
			this.MnuOrder = new System.Windows.Forms.ToolStripMenuItem();
			this.MnuOrderByBrandType = new System.Windows.Forms.ToolStripMenuItem();
			this.MnuOrderByDiagDesc = new System.Windows.Forms.ToolStripMenuItem();
			this.MnuOrderByRepairer = new System.Windows.Forms.ToolStripMenuItem();
			this.MnuOrderByOwner = new System.Windows.Forms.ToolStripMenuItem();
			this.MnuOrderByPrice = new System.Windows.Forms.ToolStripMenuItem();
			this.MnuReport = new System.Windows.Forms.ToolStripMenuItem();
			this.MnuReportMinPrice = new System.Windows.Forms.ToolStripMenuItem();
			this.MnuReportByRepairer = new System.Windows.Forms.ToolStripMenuItem();
			this.MnuReportByOwner = new System.Windows.Forms.ToolStripMenuItem();
			this.MnuReportByDiagonal = new System.Windows.Forms.ToolStripMenuItem();
			this.MnuSettings = new System.Windows.Forms.ToolStripMenuItem();
			this.MnuSettingsEditShop = new System.Windows.Forms.ToolStripMenuItem();
			this.toolStripSeparator6 = new System.Windows.Forms.ToolStripSeparator();
			this.MnuSettingsFont = new System.Windows.Forms.ToolStripMenuItem();
			this.MnuSettingsBackColor = new System.Windows.Forms.ToolStripMenuItem();
			this.MnuSettingsForeColor = new System.Windows.Forms.ToolStripMenuItem();
			this.MnuHelp = new System.Windows.Forms.ToolStripMenuItem();
			this.MnuHelpAbout = new System.Windows.Forms.ToolStripMenuItem();
			this.MnuToTray = new System.Windows.Forms.ToolStripMenuItem();
			this.LblTitle = new System.Windows.Forms.Label();
			this.TsbMain = new System.Windows.Forms.ToolStrip();
			this.TbsNew = new System.Windows.Forms.ToolStripButton();
			this.TbsFileOpen = new System.Windows.Forms.ToolStripButton();
			this.TbsSave = new System.Windows.Forms.ToolStripButton();
			this.TbsSaveAs = new System.Windows.Forms.ToolStripButton();
			this.toolStripSeparator7 = new System.Windows.Forms.ToolStripSeparator();
			this.TbsRegenerate = new System.Windows.Forms.ToolStripButton();
			this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
			this.TsbAdd = new System.Windows.Forms.ToolStripButton();
			this.TsbEdit = new System.Windows.Forms.ToolStripButton();
			this.TsbRemove = new System.Windows.Forms.ToolStripButton();
			this.TsbRemoveAll = new System.Windows.Forms.ToolStripButton();
			this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
			this.TsbOrderByBrand = new System.Windows.Forms.ToolStripButton();
			this.TsbOrderByDiagonal = new System.Windows.Forms.ToolStripButton();
			this.TsbOrderByRepairer = new System.Windows.Forms.ToolStripButton();
			this.TsbOrderByOwner = new System.Windows.Forms.ToolStripButton();
			this.TsbOrderByPrice = new System.Windows.Forms.ToolStripButton();
			this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
			this.TbsShopSettings = new System.Windows.Forms.ToolStripButton();
			this.TbsAbout = new System.Windows.Forms.ToolStripButton();
			this.toolStripSeparator9 = new System.Windows.Forms.ToolStripSeparator();
			this.TsbMinPrice = new System.Windows.Forms.ToolStripButton();
			this.CbxRepairer = new System.Windows.Forms.ToolStripComboBox();
			this.TsbRepairerSelection = new System.Windows.Forms.ToolStripButton();
			this.CbxDiagonal = new System.Windows.Forms.ToolStripComboBox();
			this.TsbDiagonalSelection = new System.Windows.Forms.ToolStripButton();
			this.CbxOwners = new System.Windows.Forms.ToolStripComboBox();
			this.TsbOwnerSelection = new System.Windows.Forms.ToolStripButton();
			this.toolStripSeparator8 = new System.Windows.Forms.ToolStripSeparator();
			this.OfdMain = new System.Windows.Forms.OpenFileDialog();
			this.SfdMain = new System.Windows.Forms.SaveFileDialog();
			this.GrbShopTitle = new System.Windows.Forms.GroupBox();
			this.FdlTextFont = new System.Windows.Forms.FontDialog();
			this.CdlBackColor = new System.Windows.Forms.ColorDialog();
			this.NtiMain = new System.Windows.Forms.NotifyIcon(this.components);
			this.CmnTray = new System.Windows.Forms.ContextMenuStrip(this.components);
			this.CmnTrayRestore = new System.Windows.Forms.ToolStripMenuItem();
			this.toolStripSeparator11 = new System.Windows.Forms.ToolStripSeparator();
			this.CmnTrayExit = new System.Windows.Forms.ToolStripMenuItem();
			this.TbcMain = new System.Windows.Forms.TabControl();
			this.TabMain = new System.Windows.Forms.TabPage();
			this.ImgList = new System.Windows.Forms.ImageList(this.components);
			this.CmnTrayAbout = new System.Windows.Forms.ToolStripMenuItem();
			this.CmnList.SuspendLayout();
			this.CmnForm.SuspendLayout();
			this.StsMain.SuspendLayout();
			this.MnuMain.SuspendLayout();
			this.TsbMain.SuspendLayout();
			this.GrbShopTitle.SuspendLayout();
			this.CmnTray.SuspendLayout();
			this.TbcMain.SuspendLayout();
			this.TabMain.SuspendLayout();
			this.SuspendLayout();
			// 
			// LbxTelevisions
			// 
			this.LbxTelevisions.ContextMenuStrip = this.CmnList;
			this.LbxTelevisions.Font = new System.Drawing.Font("Consolas", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.LbxTelevisions.FormattingEnabled = true;
			this.LbxTelevisions.ItemHeight = 19;
			this.LbxTelevisions.Location = new System.Drawing.Point(16, 104);
			this.LbxTelevisions.Name = "LbxTelevisions";
			this.LbxTelevisions.ScrollAlwaysVisible = true;
			this.LbxTelevisions.Size = new System.Drawing.Size(1072, 213);
			this.LbxTelevisions.TabIndex = 5;
			this.LbxTelevisions.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.LbxTelevisions_MouseDoubleClick);
			this.LbxTelevisions.MouseUp += new System.Windows.Forms.MouseEventHandler(this.LbxTelevisions_MouseUp);
			// 
			// CmnList
			// 
			this.CmnList.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
			this.CmnList.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.CmnListAdd,
            this.CmnListEdit,
            this.CmnListRemove});
			this.CmnList.Name = "CmnList";
			this.CmnList.Size = new System.Drawing.Size(158, 70);
			// 
			// CmnListAdd
			// 
			this.CmnListAdd.Image = global::HW10.Properties.Resources.add;
			this.CmnListAdd.Name = "CmnListAdd";
			this.CmnListAdd.Size = new System.Drawing.Size(157, 22);
			this.CmnListAdd.Text = "Добавить...";
			this.CmnListAdd.Click += new System.EventHandler(this.TelevisionAdd_Command);
			// 
			// CmnListEdit
			// 
			this.CmnListEdit.Image = global::HW10.Properties.Resources.edit;
			this.CmnListEdit.Name = "CmnListEdit";
			this.CmnListEdit.Size = new System.Drawing.Size(157, 22);
			this.CmnListEdit.Text = "Изменить...";
			this.CmnListEdit.Click += new System.EventHandler(this.TelevisionEdit_Command);
			// 
			// CmnListRemove
			// 
			this.CmnListRemove.Image = global::HW10.Properties.Resources.delete;
			this.CmnListRemove.Name = "CmnListRemove";
			this.CmnListRemove.Size = new System.Drawing.Size(157, 22);
			this.CmnListRemove.Text = "Удалить";
			this.CmnListRemove.Click += new System.EventHandler(this.TelevisionRemove_Command);
			// 
			// CmnForm
			// 
			this.CmnForm.Font = new System.Drawing.Font("Segoe UI", 12F);
			this.CmnForm.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.CmnMainAbout,
            this.CmnMainExit});
			this.CmnForm.Name = "CmnForm";
			this.CmnForm.Size = new System.Drawing.Size(186, 56);
			// 
			// CmnMainAbout
			// 
			this.CmnMainAbout.Image = global::HW10.Properties.Resources.about;
			this.CmnMainAbout.Name = "CmnMainAbout";
			this.CmnMainAbout.Size = new System.Drawing.Size(185, 26);
			this.CmnMainAbout.Text = "О программе...";
			this.CmnMainAbout.Click += new System.EventHandler(this.About_Command);
			// 
			// CmnMainExit
			// 
			this.CmnMainExit.Image = global::HW10.Properties.Resources.exit;
			this.CmnMainExit.Name = "CmnMainExit";
			this.CmnMainExit.Size = new System.Drawing.Size(185, 26);
			this.CmnMainExit.Text = "Выход";
			this.CmnMainExit.Click += new System.EventHandler(this.Exit_Command);
			// 
			// StsMain
			// 
			this.StsMain.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.StsMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.StlMain});
			this.StsMain.Location = new System.Drawing.Point(0, 456);
			this.StsMain.Name = "StsMain";
			this.StsMain.Size = new System.Drawing.Size(1149, 25);
			this.StsMain.TabIndex = 7;
			this.StsMain.Text = "statusStrip1";
			// 
			// StlMain
			// 
			this.StlMain.AutoSize = false;
			this.StlMain.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.StlMain.Name = "StlMain";
			this.StlMain.Size = new System.Drawing.Size(1237, 20);
			this.StlMain.Spring = true;
			this.StlMain.Text = "toolStripStatusLabel1";
			this.StlMain.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// LblHeader
			// 
			this.LblHeader.BackColor = System.Drawing.SystemColors.Window;
			this.LblHeader.Font = new System.Drawing.Font("Consolas", 12F);
			this.LblHeader.Location = new System.Drawing.Point(16, 32);
			this.LblHeader.Name = "LblHeader";
			this.LblHeader.Size = new System.Drawing.Size(1072, 72);
			this.LblHeader.TabIndex = 8;
			this.LblHeader.Text = "label1";
			// 
			// MnuMain
			// 
			this.MnuMain.Font = new System.Drawing.Font("Segoe UI", 11.25F);
			this.MnuMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MnuFile,
            this.MnuEdit,
            this.MnuOrder,
            this.MnuReport,
            this.MnuSettings,
            this.MnuHelp,
            this.MnuToTray});
			this.MnuMain.Location = new System.Drawing.Point(0, 0);
			this.MnuMain.Margin = new System.Windows.Forms.Padding(5, 0, 0, 5);
			this.MnuMain.Name = "MnuMain";
			this.MnuMain.Size = new System.Drawing.Size(1149, 28);
			this.MnuMain.TabIndex = 9;
			this.MnuMain.Text = "menuStrip1";
			// 
			// MnuFile
			// 
			this.MnuFile.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MnuFileNew,
            this.MnuFileOpen,
            this.MnuFileSave,
            this.MnuFileSaveAs,
            this.toolStripSeparator10,
            this.MnuFileExit});
			this.MnuFile.Name = "MnuFile";
			this.MnuFile.Size = new System.Drawing.Size(57, 24);
			this.MnuFile.Text = "Файл";
			// 
			// MnuFileNew
			// 
			this.MnuFileNew.Image = global::HW10.Properties.Resources.file_new;
			this.MnuFileNew.Name = "MnuFileNew";
			this.MnuFileNew.Size = new System.Drawing.Size(187, 24);
			this.MnuFileNew.Text = "Новый";
			this.MnuFileNew.Click += new System.EventHandler(this.FileNew_Command);
			// 
			// MnuFileOpen
			// 
			this.MnuFileOpen.Image = global::HW10.Properties.Resources.file_open;
			this.MnuFileOpen.Name = "MnuFileOpen";
			this.MnuFileOpen.Size = new System.Drawing.Size(187, 24);
			this.MnuFileOpen.Text = "Открыть...";
			this.MnuFileOpen.Click += new System.EventHandler(this.FileOpen_Command);
			// 
			// MnuFileSave
			// 
			this.MnuFileSave.Image = global::HW10.Properties.Resources.file_save;
			this.MnuFileSave.Name = "MnuFileSave";
			this.MnuFileSave.Size = new System.Drawing.Size(187, 24);
			this.MnuFileSave.Text = "Сохранить";
			this.MnuFileSave.Click += new System.EventHandler(this.FileSave_Command);
			// 
			// MnuFileSaveAs
			// 
			this.MnuFileSaveAs.Image = global::HW10.Properties.Resources.file_saveas;
			this.MnuFileSaveAs.Name = "MnuFileSaveAs";
			this.MnuFileSaveAs.Size = new System.Drawing.Size(187, 24);
			this.MnuFileSaveAs.Text = "Сохранить как...";
			this.MnuFileSaveAs.Click += new System.EventHandler(this.SaveAs_Command);
			// 
			// toolStripSeparator10
			// 
			this.toolStripSeparator10.Name = "toolStripSeparator10";
			this.toolStripSeparator10.Size = new System.Drawing.Size(184, 6);
			// 
			// MnuFileExit
			// 
			this.MnuFileExit.Image = ((System.Drawing.Image)(resources.GetObject("MnuFileExit.Image")));
			this.MnuFileExit.Name = "MnuFileExit";
			this.MnuFileExit.Size = new System.Drawing.Size(187, 24);
			this.MnuFileExit.Text = "Выход";
			this.MnuFileExit.Click += new System.EventHandler(this.Exit_Command);
			// 
			// MnuEdit
			// 
			this.MnuEdit.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.сформироватьДанныеToolStripMenuItem,
            this.toolStripSeparator3,
            this.MnuEditAddTv,
            this.MnuEditEditTV,
            this.MnuEditRemove,
            this.toolStripSeparator5,
            this.MnuEditRemoveAll});
			this.MnuEdit.Name = "MnuEdit";
			this.MnuEdit.Size = new System.Drawing.Size(72, 24);
			this.MnuEdit.Text = "Правка";
			// 
			// сформироватьДанныеToolStripMenuItem
			// 
			this.сформироватьДанныеToolStripMenuItem.Image = global::HW10.Properties.Resources.regenerate;
			this.сформироватьДанныеToolStripMenuItem.Name = "сформироватьДанныеToolStripMenuItem";
			this.сформироватьДанныеToolStripMenuItem.Size = new System.Drawing.Size(240, 24);
			this.сформироватьДанныеToolStripMenuItem.Text = "Сформировать данные";
			// 
			// toolStripSeparator3
			// 
			this.toolStripSeparator3.Name = "toolStripSeparator3";
			this.toolStripSeparator3.Size = new System.Drawing.Size(237, 6);
			// 
			// MnuEditAddTv
			// 
			this.MnuEditAddTv.Image = global::HW10.Properties.Resources.add;
			this.MnuEditAddTv.Name = "MnuEditAddTv";
			this.MnuEditAddTv.Size = new System.Drawing.Size(240, 24);
			this.MnuEditAddTv.Text = "Добавить...";
			this.MnuEditAddTv.Click += new System.EventHandler(this.TelevisionAdd_Command);
			// 
			// MnuEditEditTV
			// 
			this.MnuEditEditTV.Image = global::HW10.Properties.Resources.edit;
			this.MnuEditEditTV.Name = "MnuEditEditTV";
			this.MnuEditEditTV.Size = new System.Drawing.Size(240, 24);
			this.MnuEditEditTV.Text = "Изменить...";
			this.MnuEditEditTV.Click += new System.EventHandler(this.TelevisionEdit_Command);
			// 
			// MnuEditRemove
			// 
			this.MnuEditRemove.Image = global::HW10.Properties.Resources.delete;
			this.MnuEditRemove.Name = "MnuEditRemove";
			this.MnuEditRemove.Size = new System.Drawing.Size(240, 24);
			this.MnuEditRemove.Text = "Удалить";
			this.MnuEditRemove.Click += new System.EventHandler(this.TelevisionRemove_Command);
			// 
			// toolStripSeparator5
			// 
			this.toolStripSeparator5.Name = "toolStripSeparator5";
			this.toolStripSeparator5.Size = new System.Drawing.Size(237, 6);
			// 
			// MnuEditRemoveAll
			// 
			this.MnuEditRemoveAll.Image = global::HW10.Properties.Resources.remove_all;
			this.MnuEditRemoveAll.Name = "MnuEditRemoveAll";
			this.MnuEditRemoveAll.Size = new System.Drawing.Size(240, 24);
			this.MnuEditRemoveAll.Text = "Удалить все";
			this.MnuEditRemoveAll.Click += new System.EventHandler(this.RemoveAll_Command);
			// 
			// MnuOrder
			// 
			this.MnuOrder.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MnuOrderByBrandType,
            this.MnuOrderByDiagDesc,
            this.MnuOrderByRepairer,
            this.MnuOrderByOwner,
            this.MnuOrderByPrice});
			this.MnuOrder.Name = "MnuOrder";
			this.MnuOrder.Size = new System.Drawing.Size(104, 24);
			this.MnuOrder.Text = "Сортировка";
			// 
			// MnuOrderByBrandType
			// 
			this.MnuOrderByBrandType.Image = global::HW10.Properties.Resources.type;
			this.MnuOrderByBrandType.Name = "MnuOrderByBrandType";
			this.MnuOrderByBrandType.Size = new System.Drawing.Size(333, 24);
			this.MnuOrderByBrandType.Text = "По производителю и типу";
			this.MnuOrderByBrandType.Click += new System.EventHandler(this.ToolStripMenu_OrderBy_Click);
			// 
			// MnuOrderByDiagDesc
			// 
			this.MnuOrderByDiagDesc.Image = global::HW10.Properties.Resources.diag;
			this.MnuOrderByDiagDesc.Name = "MnuOrderByDiagDesc";
			this.MnuOrderByDiagDesc.Size = new System.Drawing.Size(333, 24);
			this.MnuOrderByDiagDesc.Text = "По убыванию диагонали экрана";
			this.MnuOrderByDiagDesc.Click += new System.EventHandler(this.ToolStripMenu_OrderBy_Click);
			// 
			// MnuOrderByRepairer
			// 
			this.MnuOrderByRepairer.Image = global::HW10.Properties.Resources.repairer;
			this.MnuOrderByRepairer.Name = "MnuOrderByRepairer";
			this.MnuOrderByRepairer.Size = new System.Drawing.Size(333, 24);
			this.MnuOrderByRepairer.Text = "По мастеру, выполняющему ремонт";
			this.MnuOrderByRepairer.Click += new System.EventHandler(this.ToolStripMenu_OrderBy_Click);
			// 
			// MnuOrderByOwner
			// 
			this.MnuOrderByOwner.Image = global::HW10.Properties.Resources.owner;
			this.MnuOrderByOwner.Name = "MnuOrderByOwner";
			this.MnuOrderByOwner.Size = new System.Drawing.Size(333, 24);
			this.MnuOrderByOwner.Text = "По владельцу телевизора";
			this.MnuOrderByOwner.Click += new System.EventHandler(this.ToolStripMenu_OrderBy_Click);
			// 
			// MnuOrderByPrice
			// 
			this.MnuOrderByPrice.Image = global::HW10.Properties.Resources.money;
			this.MnuOrderByPrice.Name = "MnuOrderByPrice";
			this.MnuOrderByPrice.Size = new System.Drawing.Size(333, 24);
			this.MnuOrderByPrice.Text = "По стоимости ремонта";
			this.MnuOrderByPrice.Click += new System.EventHandler(this.ToolStripMenu_OrderBy_Click);
			// 
			// MnuReport
			// 
			this.MnuReport.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MnuReportMinPrice,
            this.MnuReportByRepairer,
            this.MnuReportByOwner,
            this.MnuReportByDiagonal});
			this.MnuReport.Name = "MnuReport";
			this.MnuReport.Size = new System.Drawing.Size(60, 24);
			this.MnuReport.Text = "Отчет";
			// 
			// MnuReportMinPrice
			// 
			this.MnuReportMinPrice.Image = global::HW10.Properties.Resources.select_by_price;
			this.MnuReportMinPrice.Name = "MnuReportMinPrice";
			this.MnuReportMinPrice.Size = new System.Drawing.Size(280, 24);
			this.MnuReportMinPrice.Text = "Самые недорогие ремонты...";
			this.MnuReportMinPrice.Click += new System.EventHandler(this.ReportMinPrice_Command);
			// 
			// MnuReportByRepairer
			// 
			this.MnuReportByRepairer.Image = global::HW10.Properties.Resources.select_by_repairer;
			this.MnuReportByRepairer.Name = "MnuReportByRepairer";
			this.MnuReportByRepairer.Size = new System.Drawing.Size(280, 24);
			this.MnuReportByRepairer.Text = "Ремонты мастера...";
			this.MnuReportByRepairer.Click += new System.EventHandler(this.ReportByRepairer_Command);
			// 
			// MnuReportByOwner
			// 
			this.MnuReportByOwner.Image = global::HW10.Properties.Resources.select_by_owner;
			this.MnuReportByOwner.Name = "MnuReportByOwner";
			this.MnuReportByOwner.Size = new System.Drawing.Size(280, 24);
			this.MnuReportByOwner.Text = "Телевизоры клиента...";
			this.MnuReportByOwner.Click += new System.EventHandler(this.ReportByOwner_Command);
			// 
			// MnuReportByDiagonal
			// 
			this.MnuReportByDiagonal.Image = global::HW10.Properties.Resources.select_by_diagonal;
			this.MnuReportByDiagonal.Name = "MnuReportByDiagonal";
			this.MnuReportByDiagonal.Size = new System.Drawing.Size(280, 24);
			this.MnuReportByDiagonal.Text = "Телевизоры с диагональю...";
			this.MnuReportByDiagonal.Click += new System.EventHandler(this.ReportByDiagonal_Command);
			// 
			// MnuSettings
			// 
			this.MnuSettings.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MnuSettingsEditShop,
            this.toolStripSeparator6,
            this.MnuSettingsFont,
            this.MnuSettingsBackColor,
            this.MnuSettingsForeColor});
			this.MnuSettings.Name = "MnuSettings";
			this.MnuSettings.Size = new System.Drawing.Size(96, 24);
			this.MnuSettings.Text = "Настройки";
			// 
			// MnuSettingsEditShop
			// 
			this.MnuSettingsEditShop.Image = global::HW10.Properties.Resources.settings;
			this.MnuSettingsEditShop.Name = "MnuSettingsEditShop";
			this.MnuSettingsEditShop.Size = new System.Drawing.Size(353, 24);
			this.MnuSettingsEditShop.Text = "Изменить информацию о мастерской...";
			this.MnuSettingsEditShop.Click += new System.EventHandler(this.ShopSettings_Command);
			// 
			// toolStripSeparator6
			// 
			this.toolStripSeparator6.Name = "toolStripSeparator6";
			this.toolStripSeparator6.Size = new System.Drawing.Size(350, 6);
			// 
			// MnuSettingsFont
			// 
			this.MnuSettingsFont.Image = global::HW10.Properties.Resources.font;
			this.MnuSettingsFont.Name = "MnuSettingsFont";
			this.MnuSettingsFont.Size = new System.Drawing.Size(353, 24);
			this.MnuSettingsFont.Text = "Шрифт...";
			this.MnuSettingsFont.Click += new System.EventHandler(this.Font_Command);
			// 
			// MnuSettingsBackColor
			// 
			this.MnuSettingsBackColor.Image = global::HW10.Properties.Resources.color_management;
			this.MnuSettingsBackColor.Name = "MnuSettingsBackColor";
			this.MnuSettingsBackColor.Size = new System.Drawing.Size(353, 24);
			this.MnuSettingsBackColor.Text = "Цвет фона...";
			this.MnuSettingsBackColor.Click += new System.EventHandler(this.BackColor_Command);
			// 
			// MnuSettingsForeColor
			// 
			this.MnuSettingsForeColor.Image = global::HW10.Properties.Resources.font_color;
			this.MnuSettingsForeColor.Name = "MnuSettingsForeColor";
			this.MnuSettingsForeColor.Size = new System.Drawing.Size(353, 24);
			this.MnuSettingsForeColor.Text = "Цвет текста...";
			this.MnuSettingsForeColor.Click += new System.EventHandler(this.ForeColor_Command);
			// 
			// MnuHelp
			// 
			this.MnuHelp.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MnuHelpAbout});
			this.MnuHelp.Name = "MnuHelp";
			this.MnuHelp.Padding = new System.Windows.Forms.Padding(4, 0, 14, 0);
			this.MnuHelp.Size = new System.Drawing.Size(89, 24);
			this.MnuHelp.Text = "Справка";
			// 
			// MnuHelpAbout
			// 
			this.MnuHelpAbout.Name = "MnuHelpAbout";
			this.MnuHelpAbout.Size = new System.Drawing.Size(173, 24);
			this.MnuHelpAbout.Text = "О программе";
			this.MnuHelpAbout.Click += new System.EventHandler(this.About_Command);
			// 
			// MnuToTray
			// 
			this.MnuToTray.Image = global::HW10.Properties.Resources.to_tray;
			this.MnuToTray.Name = "MnuToTray";
			this.MnuToTray.Size = new System.Drawing.Size(28, 24);
			this.MnuToTray.Click += new System.EventHandler(this.ToTray_Command);
			// 
			// LblTitle
			// 
			this.LblTitle.Font = new System.Drawing.Font("Consolas", 12F);
			this.LblTitle.Location = new System.Drawing.Point(18, 32);
			this.LblTitle.Name = "LblTitle";
			this.LblTitle.Size = new System.Drawing.Size(392, 23);
			this.LblTitle.TabIndex = 10;
			this.LblTitle.Text = "Список телевизоров, находящихся в ремонте:";
			// 
			// TsbMain
			// 
			this.TsbMain.BackColor = System.Drawing.SystemColors.ControlLight;
			this.TsbMain.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
			this.TsbMain.ImageScalingSize = new System.Drawing.Size(30, 30);
			this.TsbMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.TbsNew,
            this.TbsFileOpen,
            this.TbsSave,
            this.TbsSaveAs,
            this.toolStripSeparator7,
            this.TbsRegenerate,
            this.toolStripSeparator4,
            this.TsbAdd,
            this.TsbEdit,
            this.TsbRemove,
            this.TsbRemoveAll,
            this.toolStripSeparator1,
            this.TsbOrderByBrand,
            this.TsbOrderByDiagonal,
            this.TsbOrderByRepairer,
            this.TsbOrderByOwner,
            this.TsbOrderByPrice,
            this.toolStripSeparator2,
            this.TbsShopSettings,
            this.TbsAbout,
            this.toolStripSeparator9,
            this.TsbMinPrice,
            this.CbxRepairer,
            this.TsbRepairerSelection,
            this.CbxDiagonal,
            this.TsbDiagonalSelection,
            this.CbxOwners,
            this.TsbOwnerSelection,
            this.toolStripSeparator8});
			this.TsbMain.Location = new System.Drawing.Point(0, 28);
			this.TsbMain.Name = "TsbMain";
			this.TsbMain.Padding = new System.Windows.Forms.Padding(5, 1, 15, 1);
			this.TsbMain.Size = new System.Drawing.Size(1149, 39);
			this.TsbMain.TabIndex = 12;
			this.TsbMain.Text = "toolStrip1";
			// 
			// TbsNew
			// 
			this.TbsNew.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.TbsNew.Image = global::HW10.Properties.Resources.file_new;
			this.TbsNew.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.TbsNew.Name = "TbsNew";
			this.TbsNew.Size = new System.Drawing.Size(34, 34);
			this.TbsNew.Text = "Новая коллекция";
			this.TbsNew.Click += new System.EventHandler(this.FileNew_Command);
			// 
			// TbsFileOpen
			// 
			this.TbsFileOpen.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.TbsFileOpen.Image = global::HW10.Properties.Resources.file_open;
			this.TbsFileOpen.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.TbsFileOpen.Name = "TbsFileOpen";
			this.TbsFileOpen.Size = new System.Drawing.Size(34, 34);
			this.TbsFileOpen.Text = "Открыть файл";
			this.TbsFileOpen.Click += new System.EventHandler(this.FileOpen_Command);
			// 
			// TbsSave
			// 
			this.TbsSave.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.TbsSave.Image = global::HW10.Properties.Resources.file_save;
			this.TbsSave.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.TbsSave.Name = "TbsSave";
			this.TbsSave.Size = new System.Drawing.Size(34, 34);
			this.TbsSave.Text = "Сохранить";
			this.TbsSave.Click += new System.EventHandler(this.FileSave_Command);
			// 
			// TbsSaveAs
			// 
			this.TbsSaveAs.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.TbsSaveAs.Image = global::HW10.Properties.Resources.file_saveas;
			this.TbsSaveAs.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.TbsSaveAs.Name = "TbsSaveAs";
			this.TbsSaveAs.Size = new System.Drawing.Size(34, 34);
			this.TbsSaveAs.Text = "Сохранить как...";
			this.TbsSaveAs.Click += new System.EventHandler(this.SaveAs_Command);
			// 
			// toolStripSeparator7
			// 
			this.toolStripSeparator7.Name = "toolStripSeparator7";
			this.toolStripSeparator7.Size = new System.Drawing.Size(6, 37);
			// 
			// TbsRegenerate
			// 
			this.TbsRegenerate.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.TbsRegenerate.Image = global::HW10.Properties.Resources.regenerate;
			this.TbsRegenerate.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.TbsRegenerate.Name = "TbsRegenerate";
			this.TbsRegenerate.Size = new System.Drawing.Size(34, 34);
			this.TbsRegenerate.Text = "Cформировать данные заново";
			this.TbsRegenerate.Click += new System.EventHandler(this.Regenerate_Command);
			// 
			// toolStripSeparator4
			// 
			this.toolStripSeparator4.Name = "toolStripSeparator4";
			this.toolStripSeparator4.Size = new System.Drawing.Size(6, 37);
			// 
			// TsbAdd
			// 
			this.TsbAdd.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.TsbAdd.Image = ((System.Drawing.Image)(resources.GetObject("TsbAdd.Image")));
			this.TsbAdd.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.TsbAdd.Name = "TsbAdd";
			this.TsbAdd.Size = new System.Drawing.Size(34, 34);
			this.TsbAdd.Text = "Добавить телевизор";
			this.TsbAdd.Click += new System.EventHandler(this.TelevisionAdd_Command);
			// 
			// TsbEdit
			// 
			this.TsbEdit.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.TsbEdit.Image = ((System.Drawing.Image)(resources.GetObject("TsbEdit.Image")));
			this.TsbEdit.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.TsbEdit.Name = "TsbEdit";
			this.TsbEdit.Size = new System.Drawing.Size(34, 34);
			this.TsbEdit.Text = "Изменить телевизор";
			this.TsbEdit.Click += new System.EventHandler(this.TelevisionEdit_Command);
			// 
			// TsbRemove
			// 
			this.TsbRemove.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.TsbRemove.Image = global::HW10.Properties.Resources.delete;
			this.TsbRemove.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.TsbRemove.Name = "TsbRemove";
			this.TsbRemove.Size = new System.Drawing.Size(34, 34);
			this.TsbRemove.Text = "Удалить телевизор";
			this.TsbRemove.Click += new System.EventHandler(this.TelevisionRemove_Command);
			// 
			// TsbRemoveAll
			// 
			this.TsbRemoveAll.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.TsbRemoveAll.Image = global::HW10.Properties.Resources.remove_all;
			this.TsbRemoveAll.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.TsbRemoveAll.Name = "TsbRemoveAll";
			this.TsbRemoveAll.Size = new System.Drawing.Size(34, 34);
			this.TsbRemoveAll.Text = "Удалить все";
			this.TsbRemoveAll.Click += new System.EventHandler(this.RemoveAll_Command);
			// 
			// toolStripSeparator1
			// 
			this.toolStripSeparator1.Name = "toolStripSeparator1";
			this.toolStripSeparator1.Size = new System.Drawing.Size(6, 37);
			// 
			// TsbOrderByBrand
			// 
			this.TsbOrderByBrand.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.TsbOrderByBrand.Image = ((System.Drawing.Image)(resources.GetObject("TsbOrderByBrand.Image")));
			this.TsbOrderByBrand.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.TsbOrderByBrand.Name = "TsbOrderByBrand";
			this.TsbOrderByBrand.Size = new System.Drawing.Size(34, 34);
			this.TsbOrderByBrand.Text = "Сортировка по производителю и типу";
			this.TsbOrderByBrand.Click += new System.EventHandler(this.ToolStripButton_OrderBy_Click);
			// 
			// TsbOrderByDiagonal
			// 
			this.TsbOrderByDiagonal.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.TsbOrderByDiagonal.Image = ((System.Drawing.Image)(resources.GetObject("TsbOrderByDiagonal.Image")));
			this.TsbOrderByDiagonal.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.TsbOrderByDiagonal.Name = "TsbOrderByDiagonal";
			this.TsbOrderByDiagonal.Size = new System.Drawing.Size(34, 34);
			this.TsbOrderByDiagonal.Text = "Сортировка по убыванию дигонали";
			this.TsbOrderByDiagonal.Click += new System.EventHandler(this.ToolStripButton_OrderBy_Click);
			// 
			// TsbOrderByRepairer
			// 
			this.TsbOrderByRepairer.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.TsbOrderByRepairer.Image = ((System.Drawing.Image)(resources.GetObject("TsbOrderByRepairer.Image")));
			this.TsbOrderByRepairer.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.TsbOrderByRepairer.Name = "TsbOrderByRepairer";
			this.TsbOrderByRepairer.Size = new System.Drawing.Size(34, 34);
			this.TsbOrderByRepairer.Text = "Сортировка по мастеру";
			this.TsbOrderByRepairer.Click += new System.EventHandler(this.ToolStripButton_OrderBy_Click);
			// 
			// TsbOrderByOwner
			// 
			this.TsbOrderByOwner.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.TsbOrderByOwner.Image = ((System.Drawing.Image)(resources.GetObject("TsbOrderByOwner.Image")));
			this.TsbOrderByOwner.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.TsbOrderByOwner.Name = "TsbOrderByOwner";
			this.TsbOrderByOwner.Size = new System.Drawing.Size(34, 34);
			this.TsbOrderByOwner.Text = "Сортировка по владельцу";
			this.TsbOrderByOwner.Click += new System.EventHandler(this.ToolStripButton_OrderBy_Click);
			// 
			// TsbOrderByPrice
			// 
			this.TsbOrderByPrice.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.TsbOrderByPrice.Image = global::HW10.Properties.Resources.money;
			this.TsbOrderByPrice.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.TsbOrderByPrice.Name = "TsbOrderByPrice";
			this.TsbOrderByPrice.Size = new System.Drawing.Size(34, 34);
			this.TsbOrderByPrice.Text = "Сортировка по стоимости ремонта";
			this.TsbOrderByPrice.Click += new System.EventHandler(this.ToolStripButton_OrderBy_Click);
			// 
			// toolStripSeparator2
			// 
			this.toolStripSeparator2.Name = "toolStripSeparator2";
			this.toolStripSeparator2.Size = new System.Drawing.Size(6, 37);
			// 
			// TbsShopSettings
			// 
			this.TbsShopSettings.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.TbsShopSettings.Image = ((System.Drawing.Image)(resources.GetObject("TbsShopSettings.Image")));
			this.TbsShopSettings.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.TbsShopSettings.Name = "TbsShopSettings";
			this.TbsShopSettings.Size = new System.Drawing.Size(34, 34);
			this.TbsShopSettings.Text = "Изменить информацию о мастерской";
			this.TbsShopSettings.Click += new System.EventHandler(this.ShopSettings_Command);
			// 
			// TbsAbout
			// 
			this.TbsAbout.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
			this.TbsAbout.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.TbsAbout.Image = ((System.Drawing.Image)(resources.GetObject("TbsAbout.Image")));
			this.TbsAbout.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.TbsAbout.Name = "TbsAbout";
			this.TbsAbout.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.TbsAbout.Size = new System.Drawing.Size(34, 34);
			this.TbsAbout.Text = "О программе";
			this.TbsAbout.Click += new System.EventHandler(this.About_Command);
			// 
			// toolStripSeparator9
			// 
			this.toolStripSeparator9.Name = "toolStripSeparator9";
			this.toolStripSeparator9.Size = new System.Drawing.Size(6, 37);
			// 
			// TsbMinPrice
			// 
			this.TsbMinPrice.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.TsbMinPrice.Image = global::HW10.Properties.Resources.select_by_price;
			this.TsbMinPrice.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.TsbMinPrice.Name = "TsbMinPrice";
			this.TsbMinPrice.Size = new System.Drawing.Size(34, 34);
			this.TsbMinPrice.ToolTipText = "Выборка самых недорогих ремонтов";
			this.TsbMinPrice.Click += new System.EventHandler(this.ReportMinPrice_Command);
			// 
			// CbxRepairer
			// 
			this.CbxRepairer.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.CbxRepairer.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.CbxRepairer.Margin = new System.Windows.Forms.Padding(6, 0, 1, 0);
			this.CbxRepairer.Name = "CbxRepairer";
			this.CbxRepairer.Size = new System.Drawing.Size(121, 37);
			this.CbxRepairer.ToolTipText = "Мастер, ведущий ремонт";
			// 
			// TsbRepairerSelection
			// 
			this.TsbRepairerSelection.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.TsbRepairerSelection.Image = global::HW10.Properties.Resources.select_by_repairer;
			this.TsbRepairerSelection.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.TsbRepairerSelection.Margin = new System.Windows.Forms.Padding(0, 1, 6, 2);
			this.TsbRepairerSelection.Name = "TsbRepairerSelection";
			this.TsbRepairerSelection.Size = new System.Drawing.Size(34, 34);
			this.TsbRepairerSelection.ToolTipText = "Выборка ремонтов заданного мастера";
			this.TsbRepairerSelection.Click += new System.EventHandler(this.TbsRepairerSelection_Click);
			// 
			// CbxDiagonal
			// 
			this.CbxDiagonal.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.CbxDiagonal.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.CbxDiagonal.Margin = new System.Windows.Forms.Padding(6, 0, 1, 0);
			this.CbxDiagonal.Name = "CbxDiagonal";
			this.CbxDiagonal.Size = new System.Drawing.Size(121, 37);
			this.CbxDiagonal.ToolTipText = "Выбор диагонали телевизора";
			// 
			// TsbDiagonalSelection
			// 
			this.TsbDiagonalSelection.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.TsbDiagonalSelection.Image = global::HW10.Properties.Resources.select_by_diagonal;
			this.TsbDiagonalSelection.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.TsbDiagonalSelection.Margin = new System.Windows.Forms.Padding(0, 1, 6, 2);
			this.TsbDiagonalSelection.Name = "TsbDiagonalSelection";
			this.TsbDiagonalSelection.Size = new System.Drawing.Size(34, 34);
			this.TsbDiagonalSelection.ToolTipText = "Выборка телевизоров \r\nс заданной диагональю";
			this.TsbDiagonalSelection.Click += new System.EventHandler(this.TbsDiagonalSelection_Click);
			// 
			// CbxOwners
			// 
			this.CbxOwners.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.CbxOwners.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.CbxOwners.Margin = new System.Windows.Forms.Padding(6, 0, 1, 0);
			this.CbxOwners.Name = "CbxOwners";
			this.CbxOwners.Size = new System.Drawing.Size(121, 37);
			this.CbxOwners.ToolTipText = "Владелец телевизора";
			// 
			// TsbOwnerSelection
			// 
			this.TsbOwnerSelection.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.TsbOwnerSelection.Image = global::HW10.Properties.Resources.select_by_owner;
			this.TsbOwnerSelection.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.TsbOwnerSelection.Margin = new System.Windows.Forms.Padding(0, 1, 6, 2);
			this.TsbOwnerSelection.Name = "TsbOwnerSelection";
			this.TsbOwnerSelection.Size = new System.Drawing.Size(34, 34);
			this.TsbOwnerSelection.ToolTipText = "Выборка телевизоров заданного владельца";
			this.TsbOwnerSelection.Click += new System.EventHandler(this.TsbOwnerSelection_Click);
			// 
			// toolStripSeparator8
			// 
			this.toolStripSeparator8.Name = "toolStripSeparator8";
			this.toolStripSeparator8.Size = new System.Drawing.Size(6, 37);
			// 
			// OfdMain
			// 
			this.OfdMain.Filter = "Файлы JSON(*.json)|*.json";
			this.OfdMain.Title = "Загрузить данные из файла";
			// 
			// SfdMain
			// 
			this.SfdMain.FileName = "RepairShop.json";
			this.SfdMain.Filter = "Файлы JSON(*.json)|*.json";
			this.SfdMain.SupportMultiDottedExtensions = true;
			this.SfdMain.Title = "Сохранить данные в файл";
			// 
			// GrbShopTitle
			// 
			this.GrbShopTitle.Controls.Add(this.LblHeader);
			this.GrbShopTitle.Controls.Add(this.LblTitle);
			this.GrbShopTitle.Controls.Add(this.LbxTelevisions);
			this.GrbShopTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold);
			this.GrbShopTitle.Location = new System.Drawing.Point(17, 16);
			this.GrbShopTitle.Name = "GrbShopTitle";
			this.GrbShopTitle.Size = new System.Drawing.Size(1104, 328);
			this.GrbShopTitle.TabIndex = 13;
			this.GrbShopTitle.TabStop = false;
			this.GrbShopTitle.Text = "Ремонт телевизоров";
			// 
			// FdlTextFont
			// 
			this.FdlTextFont.Font = new System.Drawing.Font("Consolas", 12F);
			this.FdlTextFont.ShowApply = true;
			this.FdlTextFont.ShowColor = true;
			this.FdlTextFont.Apply += new System.EventHandler(this.FdlTextFont_Apply);
			// 
			// CdlBackColor
			// 
			this.CdlBackColor.AnyColor = true;
			this.CdlBackColor.FullOpen = true;
			// 
			// NtiMain
			// 
			this.NtiMain.ContextMenuStrip = this.CmnTray;
			this.NtiMain.Icon = ((System.Drawing.Icon)(resources.GetObject("NtiMain.Icon")));
			this.NtiMain.Text = "RepairShop";
			this.NtiMain.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.CmnTray_MouseDoubleClick);
			// 
			// CmnTray
			// 
			this.CmnTray.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.CmnTrayRestore,
            this.CmnTrayAbout,
            this.toolStripSeparator11,
            this.CmnTrayExit});
			this.CmnTray.Name = "CmnTray";
			this.CmnTray.Size = new System.Drawing.Size(159, 76);
			this.CmnTray.Text = "RepairShop";
			// 
			// CmnTrayRestore
			// 
			this.CmnTrayRestore.Name = "CmnTrayRestore";
			this.CmnTrayRestore.Size = new System.Drawing.Size(180, 22);
			this.CmnTrayRestore.Text = "Восстановить";
			this.CmnTrayRestore.Click += new System.EventHandler(this.Restore_Command);
			// 
			// toolStripSeparator11
			// 
			this.toolStripSeparator11.Name = "toolStripSeparator11";
			this.toolStripSeparator11.Size = new System.Drawing.Size(177, 6);
			// 
			// CmnTrayExit
			// 
			this.CmnTrayExit.Image = global::HW10.Properties.Resources.exit;
			this.CmnTrayExit.Name = "CmnTrayExit";
			this.CmnTrayExit.Size = new System.Drawing.Size(180, 22);
			this.CmnTrayExit.Text = "Выход";
			this.CmnTrayExit.Click += new System.EventHandler(this.Exit_Command);
			// 
			// TbcMain
			// 
			this.TbcMain.Controls.Add(this.TabMain);
			this.TbcMain.Dock = System.Windows.Forms.DockStyle.Fill;
			this.TbcMain.ImageList = this.ImgList;
			this.TbcMain.Location = new System.Drawing.Point(0, 67);
			this.TbcMain.Name = "TbcMain";
			this.TbcMain.SelectedIndex = 0;
			this.TbcMain.Size = new System.Drawing.Size(1149, 389);
			this.TbcMain.TabIndex = 14;
			this.TbcMain.SelectedIndexChanged += new System.EventHandler(this.TbcMain_SelectedIndexChanged);
			this.TbcMain.MouseDown += new System.Windows.Forms.MouseEventHandler(this.TbcMain_MouseDown);
			this.TbcMain.MouseUp += new System.Windows.Forms.MouseEventHandler(this.TbcMain_MouseUp);
			// 
			// TabMain
			// 
			this.TabMain.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.TabMain.Controls.Add(this.GrbShopTitle);
			this.TabMain.ImageIndex = 1;
			this.TabMain.Location = new System.Drawing.Point(4, 27);
			this.TabMain.Name = "TabMain";
			this.TabMain.Padding = new System.Windows.Forms.Padding(3);
			this.TabMain.Size = new System.Drawing.Size(1141, 358);
			this.TabMain.TabIndex = 0;
			this.TabMain.Text = "Главная";
			this.TabMain.UseVisualStyleBackColor = true;
			// 
			// ImgList
			// 
			this.ImgList.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("ImgList.ImageStream")));
			this.ImgList.TransparentColor = System.Drawing.Color.Transparent;
			this.ImgList.Images.SetKeyName(0, "close_box_red.png");
			this.ImgList.Images.SetKeyName(1, "home.png");
			// 
			// CmnTrayAbout
			// 
			this.CmnTrayAbout.Image = global::HW10.Properties.Resources.about;
			this.CmnTrayAbout.Name = "CmnTrayAbout";
			this.CmnTrayAbout.Size = new System.Drawing.Size(158, 22);
			this.CmnTrayAbout.Text = "О программе...";
			this.CmnTrayAbout.Click += new System.EventHandler(this.About_Command);
			// 
			// MainForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
			this.ClientSize = new System.Drawing.Size(1149, 481);
			this.ContextMenuStrip = this.CmnForm;
			this.Controls.Add(this.TbcMain);
			this.Controls.Add(this.TsbMain);
			this.Controls.Add(this.StsMain);
			this.Controls.Add(this.MnuMain);
			this.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.MainMenuStrip = this.MnuMain;
			this.MaximizeBox = false;
			this.Name = "MainForm";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Домашняя Работа";
			this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.MainForm_FormClosing);
			this.Load += new System.EventHandler(this.MainForm_Load);
			this.CmnList.ResumeLayout(false);
			this.CmnForm.ResumeLayout(false);
			this.StsMain.ResumeLayout(false);
			this.StsMain.PerformLayout();
			this.MnuMain.ResumeLayout(false);
			this.MnuMain.PerformLayout();
			this.TsbMain.ResumeLayout(false);
			this.TsbMain.PerformLayout();
			this.GrbShopTitle.ResumeLayout(false);
			this.CmnTray.ResumeLayout(false);
			this.TbcMain.ResumeLayout(false);
			this.TabMain.ResumeLayout(false);
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.ListBox LbxTelevisions;
		private System.Windows.Forms.StatusStrip StsMain;
		private System.Windows.Forms.ToolStripStatusLabel StlMain;
		private System.Windows.Forms.Label LblHeader;
		private System.Windows.Forms.MenuStrip MnuMain;
		private System.Windows.Forms.ToolStripMenuItem MnuFile;
		private System.Windows.Forms.ToolStripMenuItem MnuFileExit;
		private System.Windows.Forms.ToolStripMenuItem MnuEdit;
		private System.Windows.Forms.ToolStripMenuItem MnuEditAddTv;
		private System.Windows.Forms.ToolStripMenuItem MnuEditEditTV;
		private System.Windows.Forms.ToolStripMenuItem MnuOrder;
		private System.Windows.Forms.ToolStripMenuItem MnuOrderByBrandType;
		private System.Windows.Forms.ToolStripMenuItem MnuOrderByDiagDesc;
		private System.Windows.Forms.ToolStripMenuItem MnuOrderByRepairer;
		private System.Windows.Forms.ToolStripMenuItem MnuEditRemove;
		private System.Windows.Forms.ToolStripMenuItem MnuOrderByOwner;
		private System.Windows.Forms.ToolStripMenuItem MnuSettings;
		private System.Windows.Forms.ToolStripMenuItem MnuSettingsEditShop;
		private System.Windows.Forms.ToolStripMenuItem MnuHelp;
		private System.Windows.Forms.ToolStripMenuItem MnuHelpAbout;
		private System.Windows.Forms.Label LblTitle;
		private System.Windows.Forms.ContextMenuStrip CmnForm;
		private System.Windows.Forms.ToolStripMenuItem CmnMainAbout;
		private System.Windows.Forms.ToolStripMenuItem CmnMainExit;
		private System.Windows.Forms.ToolStrip TsbMain;
		private System.Windows.Forms.ToolStripButton TsbAdd;
		private System.Windows.Forms.ToolStripButton TsbEdit;
		private System.Windows.Forms.ToolStripButton TsbRemove;
		private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
		private System.Windows.Forms.ToolStripButton TsbOrderByBrand;
		private System.Windows.Forms.ToolStripButton TsbOrderByDiagonal;
		private System.Windows.Forms.ToolStripButton TsbOrderByRepairer;
		private System.Windows.Forms.ToolStripButton TsbOrderByOwner;
		private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
		private System.Windows.Forms.ToolStripButton TbsShopSettings;
		private System.Windows.Forms.ToolStripButton TbsAbout;
		private System.Windows.Forms.ToolStripMenuItem MnuReport;
		private System.Windows.Forms.ToolStripMenuItem MnuReportMinPrice;
		private System.Windows.Forms.ToolStripMenuItem MnuReportByRepairer;
		private System.Windows.Forms.ToolStripMenuItem MnuReportByDiagonal;
		private System.Windows.Forms.ToolStripMenuItem MnuOrderByPrice;
		private System.Windows.Forms.ToolStripButton TsbOrderByPrice;
		private System.Windows.Forms.ToolStripMenuItem сформироватьДанныеToolStripMenuItem;
		private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
		private System.Windows.Forms.ToolStripButton TbsRegenerate;
		private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
		private System.Windows.Forms.ToolStripSeparator toolStripSeparator5;
		private System.Windows.Forms.ToolStripMenuItem MnuEditRemoveAll;
		private System.Windows.Forms.ToolStripButton TsbRemoveAll;
		private System.Windows.Forms.ToolStripMenuItem MnuFileNew;
		private System.Windows.Forms.ToolStripMenuItem MnuFileOpen;
		private System.Windows.Forms.ToolStripMenuItem MnuFileSave;
		private System.Windows.Forms.ToolStripMenuItem MnuFileSaveAs;
		private System.Windows.Forms.OpenFileDialog OfdMain;
		private System.Windows.Forms.SaveFileDialog SfdMain;
		private System.Windows.Forms.ToolStripMenuItem MnuReportByOwner;
		private System.Windows.Forms.GroupBox GrbShopTitle;
		private System.Windows.Forms.ToolStripSeparator toolStripSeparator6;
		private System.Windows.Forms.ToolStripMenuItem MnuSettingsFont;
		private System.Windows.Forms.ToolStripMenuItem MnuSettingsBackColor;
		private System.Windows.Forms.FontDialog FdlTextFont;
		private System.Windows.Forms.ColorDialog CdlBackColor;
		private System.Windows.Forms.ToolStripButton TbsNew;
		private System.Windows.Forms.ToolStripButton TbsSave;
		private System.Windows.Forms.ToolStripButton TbsSaveAs;
		private System.Windows.Forms.ToolStripSeparator toolStripSeparator7;
		private System.Windows.Forms.ToolStripButton TbsFileOpen;
		private System.Windows.Forms.ToolStripSeparator toolStripSeparator8;
		private System.Windows.Forms.ContextMenuStrip CmnList;
		private System.Windows.Forms.ToolStripMenuItem CmnListAdd;
		private System.Windows.Forms.ToolStripMenuItem CmnListEdit;
		private System.Windows.Forms.ToolStripMenuItem CmnListRemove;
		private System.Windows.Forms.ToolStripSeparator toolStripSeparator10;
		private System.Windows.Forms.ToolStripSeparator toolStripSeparator9;
		private System.Windows.Forms.NotifyIcon NtiMain;
		private System.Windows.Forms.ContextMenuStrip CmnTray;
		private System.Windows.Forms.ToolStripMenuItem CmnTrayRestore;
		private System.Windows.Forms.ToolStripSeparator toolStripSeparator11;
		private System.Windows.Forms.ToolStripMenuItem CmnTrayExit;
		private System.Windows.Forms.TabControl TbcMain;
		private System.Windows.Forms.TabPage TabMain;
		private System.Windows.Forms.ToolStripMenuItem MnuSettingsForeColor;
		private System.Windows.Forms.ImageList ImgList;
		private System.Windows.Forms.ToolStripButton TsbMinPrice;
		private System.Windows.Forms.ToolStripComboBox CbxRepairer;
		private System.Windows.Forms.ToolStripButton TsbRepairerSelection;
		private System.Windows.Forms.ToolStripComboBox CbxDiagonal;
		private System.Windows.Forms.ToolStripButton TsbDiagonalSelection;
		private System.Windows.Forms.ToolStripButton TsbOwnerSelection;
		private System.Windows.Forms.ToolStripComboBox CbxOwners;
		private System.Windows.Forms.ToolStripMenuItem MnuToTray;
		private System.Windows.Forms.ToolStripMenuItem CmnTrayAbout;
	}
}

