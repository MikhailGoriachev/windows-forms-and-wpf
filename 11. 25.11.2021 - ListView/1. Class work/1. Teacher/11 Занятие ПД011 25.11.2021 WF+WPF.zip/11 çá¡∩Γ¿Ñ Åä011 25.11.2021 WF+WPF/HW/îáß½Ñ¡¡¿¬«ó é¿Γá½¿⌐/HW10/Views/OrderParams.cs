﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HW10.Models;

namespace HW10.Views
{
	// Класс параметров сортировки для привязки к элементу управления
	public class OrderParams
	{
		public Action<List<Television>> Sorter { get; set; }
		public string TabName { get; set; }
		public string Prompt { get; set; }
	}
}
