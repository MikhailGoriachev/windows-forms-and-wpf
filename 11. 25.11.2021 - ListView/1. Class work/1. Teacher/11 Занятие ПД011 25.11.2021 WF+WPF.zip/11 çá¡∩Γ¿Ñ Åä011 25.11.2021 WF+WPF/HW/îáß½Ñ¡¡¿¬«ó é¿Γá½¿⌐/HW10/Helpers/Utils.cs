﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HW10.Helpers
{
	class Utils
	{
		// формирование случайных целых чисел в заданном диапазоне (lo, hi),
		// исключая указанное параметром exclude число
		public static int GetRandomExclude(int lo, int hi, int exclude)
		{
			int number = 0;
			do
				number = Random.Next(lo, hi);
			while (number == exclude);

			return number;
		} // GetRandomExclude

		// объект для получения случайных чисел
		public static readonly Random Random = new Random(Environment.TickCount);

		// Получение случайного числа
		// краткая форма записи метода - это не лямбда выражение
		public static int GetRandom(int lo, int hi) => Random.Next(lo, hi + 1);
		public static double GetRandom(double lo, double hi) => lo + (hi - lo) * Random.NextDouble();


		// фамилии и инициалы для формирования персональных данных
		public static string[] FullNames = {
			"Петрова Д.А.", "Цыбенко Р.А.", "Юдина Н.А.", "Фортранов Б.В.", "Шавыркина П.А.",
			"Фаронова Р.В.", "Щупак Д.Ю.", "Польский Д.М.", "Абрамян М.Э.", "Васильев А.Н.",
			"Федорова В.О.", "Мурадов И.с.", "Штурлак А.В.",  "Баранова Е.В.",
			"Маслова Е.В", "Федорин М.Н.", "Семенов Б.В."  , "Семенова Р.Т." , "Дунаев О.Ю." , "Дунаева Г.Т.",
			"Харламова П.А.", "Харламов т.Р." , "Олегова В.Ф.", "Олегов В.Ф.",
			"Янковский Т.Р.", "Янковская О.Л.", "Абалкин Н.Р.", "Абалкина П.Р.",
			"Романова Р.Л." , "Воликов О.П."  , "Жукова Н.К." , "Соколов Р.Ж."
		};


	}
}
