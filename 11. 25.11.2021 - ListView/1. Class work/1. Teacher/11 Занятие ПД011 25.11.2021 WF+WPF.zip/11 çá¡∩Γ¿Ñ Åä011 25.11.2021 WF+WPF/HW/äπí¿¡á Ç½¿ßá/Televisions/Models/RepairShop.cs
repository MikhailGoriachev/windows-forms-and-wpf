﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using Televisions.Helpers;
using System.Runtime.Serialization.Json;
using System.IO;

namespace Televisions.Models
{
    // Класс RepairShop (коллекция Television, название ремонтной мастерской, адрес ремонтной мастерской).
    [DataContract]
    public class RepairShop {
        // название ремонтной мастерской
        private string _name;
        [DataMember]
        public string Name {
            get => _name;
            set {
                if (string.IsNullOrEmpty(value))
                    throw new Exception("Пустая строка в названии ремонтной мастерской");

                _name = value;
            } // set
        } // Name

        // адрес ремонтной мастерской
        private string _address;
        [DataMember]
        public string Address {
            get => _address;
            set {
                if (string.IsNullOrEmpty(value))
                    throw new Exception("Пустая строка в адресе ремонтной мастерской");

                _address = value;
            } // set
        } // Name

        // коллекция телевизоров
        private List<Television> _televisions;
        [DataMember]
        public List<Television> Televisions {
            get => _televisions;
            private set => _televisions = value;
        } // Televisions

        // конструкторы для получения коллекции телевизоров
        public RepairShop() : this("\"Эксперт-Сервис*\"", "Ленинский проспект, 4а", new List<Television>()) {
            // создание коллекции телевизоров, количество по заданию 
            Generate(Utils.GetRandom(12, 15));
        } // AppliancesController

        public RepairShop(string name, string address, List<Television> televisions) {
            _televisions = televisions;
            _name = name;
            _address = address;
        } // AppliancesController

        // количестово телевизоров в коллекции
        public int Count => _televisions.Count;

        // формирование заданного количества телевизоров в коллекции
        public void Generate(int n) {
            _televisions.Clear();

            for (int i = 0; i < n; i++)
                _televisions.Add(Television.Generate());
        } // Generate

        // Удаление телевизора
        public void RemoveTelevision(int index) => _televisions.RemoveAt(index);

        // Добавление телевизора в коллекцию
        public void AddTelevision(Television television) => _televisions.Insert(0, television);

        // редактирование телевизора 
        public void EditTelevision(int index, Television television) => _televisions[index] = television;

        // Упорядочивание коллекции телевизоров
        public void OrderBy(Comparison<Television> comparison) =>
            _televisions.Sort(comparison);

        // минимальная стоимость ремонта
        public int MinPrice() {
            int min = _televisions[0].Price;
            _televisions.ForEach(x => min = x.Price < min ? x.Price : min);
            return min;
        } // MinCost

        // максимальная стоимость ремонта
        public int MaxPrice() {
            int max = _televisions[0].Price;
            _televisions.ForEach(x => max = x.Price > max ? x.Price : max);
            return max;
        } // MinCost

        // Выборка телевизоров 
        public List<Television> SelectTelevisions(Predicate<Television> predicate) =>
            _televisions.FindAll(predicate);

        // сериализация в формате JSON
        public void Serialization(string fileName) {
            DataContractJsonSerializer jsonFormatter = new DataContractJsonSerializer(typeof(RepairShop));

            using (FileStream fs = new FileStream(fileName, FileMode.Truncate))
                jsonFormatter.WriteObject(fs, this);
        } // Serialization

        // десериализация формате JSON
        public void Deserialization(string fileName) {
            DataContractJsonSerializer jsonFormatter = new DataContractJsonSerializer(typeof(RepairShop));

            using (FileStream fs = new FileStream(fileName, FileMode.OpenOrCreate)){
                RepairShop temp = (RepairShop)jsonFormatter.ReadObject(fs);
                Name = temp.Name;
                Address = temp.Address;
                Televisions = temp.Televisions;
            }
        } // Deserialization
    } // RepairShop
}