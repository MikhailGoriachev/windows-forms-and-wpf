﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Televisions.Models;
using Televisions.Helpers;

namespace Televisions.Controllers
{
    public class RepairShopController {
        // объект для обработки
        private RepairShop _repairShop;

        public RepairShop RepairShop {
            get => _repairShop;
            private set => _repairShop = value;
        } // RepairShop

        // имя файла для сериализация в формате JSON
        private string _fileName;

        public string FileName {
            get => _fileName;
            private set => _fileName = value;
        } // FileName

        // конструкторы
        // при создании RepairShop конструктором по умолчанию вызывается
        // метод формирования коллекции телевизоров для ремонта
        public RepairShopController() : this(new RepairShop(), "Televisions.json") { }

        public RepairShopController(RepairShop repairShop) : this(repairShop, "Televisions.json") { }

        public RepairShopController(RepairShop repairShop, string fileName) {
            _repairShop = repairShop;
            _fileName = fileName;
        } // RepairShopController

        // Запрос на упорядочивание коллекции по производителю и типу
        public void OrderByBrand() => 
            RepairShop.OrderBy((t1, t2) => t1.Brand.CompareTo(t2.Brand));


        // Запрос на упорядочивание коллекции по убыванию диагонали экрана
        public void OrderByDiagonalDesc() => RepairShop.OrderBy((t1, t2) =>
            t2.Diagonal.CompareTo(t1.Diagonal));


        // Запрос на упорядочивание коллекции по мастеру, выполняющему ремонт
        public void OrderByArtisan() => RepairShop.OrderBy((t1, t2) =>
            t1.Artisan.CompareTo(t2.Artisan));


        // Запрос на упорядочивание коллекции по владельцу телевизора
        public void OrderByOwner() => RepairShop.OrderBy((t1, t2) =>
            t1.Owner.CompareTo(t2.Owner));

        // Запрос на упорядочивание коллекции по стоимости ремонта
        public void OrderByPrice() => RepairShop.OrderBy((t1, t2) =>
            t1.Price.CompareTo(t2.Price));


        // Запрос на выборку в коллекцию телевизоров с минимальной стоимостью ремонта
        public List<Television> SelectWhereMinPrice() {
            int minPrice = _repairShop.MinPrice();
            return _repairShop.SelectTelevisions(t => t.Price == minPrice);
        } // SelectWhereMinPrice


        // Запрос на выборку в коллекцию телевизоров, ремонтируемых заданным мастером
        public List<Television> SelectWhereArtisan(string artisan) =>
            _repairShop.SelectTelevisions(t => t.Artisan == artisan);

        // Запрос на выборку в коллекцию телевизоров, заданного владельца
        public List<Television> SelectWhereOwner(string owner) =>
            _repairShop.SelectTelevisions(t => t.Owner == owner);

        // Запрос на выборку в коллекцию телевизоров с заданной диагональю экран
        public List<Television> SelectWhereDiagonal(double diagonal) =>
            _repairShop.SelectTelevisions(t => Math.Abs(t.Diagonal - diagonal) < 1e-6);


        // список мастеров из коллекции ремонтов
        public List<string> GetArtitans() {
            Dictionary<string, int> artisans = new Dictionary<string, int>();

            _repairShop.Televisions.ForEach(t => artisans[t.Artisan] = 0);

            return artisans.Keys.ToList();
        } // GetArtitans


        // список владельцев из коллекции ремонтов
        public List<string> GetOwners()  {
            Dictionary<string, int> owners = new Dictionary<string, int>();

            _repairShop.Televisions.ForEach(t => owners[t.Owner] = 0);

            return owners.Keys.ToList();
        } // GetOwners

        // список диагоналей из коллекции ремонтов
        public List<string> GetDiagonals() {
            Dictionary<string, int> diagonals = new Dictionary<string, int>();

            _repairShop.Televisions.ForEach(t => diagonals[$"{t.Diagonal:n1}"] = 0);

            return diagonals.Keys.ToList();
        } // GetDiagonals


    } // RepairShopController
}
