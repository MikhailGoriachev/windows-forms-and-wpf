﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Televisions.Models;
using Televisions.Helpers;
using Televisions.Controllers;

namespace Televisions.Views
{
    public partial class MainForm : Form
    {
        private RepairShopController _repairShopController;
        
        public MainForm() : this(new RepairShopController()) { } // MainForm

        public MainForm(RepairShopController repairShopController) {
            InitializeComponent();

            _repairShopController = repairShopController;

            // привязка ListBox к коллекции
            BindCollection(LbxTelevisions, _repairShopController);
            LblStatus.Text = $"Текущее количество телевизоров: {_repairShopController.RepairShop.Count}";
        } // MainForm

        // выполнение привязки коллекции
        private void BindCollection(ListBox listBox, RepairShopController repairShopController) =>
            BindCollection(listBox, repairShopController.RepairShop);

        private void BindCollection(ListBox listBox, RepairShop repairShop) =>
            BindCollection(listBox, repairShop.Televisions);

        private void BindCollection(ListBox listBox, List<Television> televisions) {
            // остановить привязку
            listBox.DataSource = null;

            // задать привязку
            listBox.DataSource = televisions;

            listBox.DisplayMember = "TableRow";
        } // BindCollection

        // Начальное формирование данных ремонтной мастерской (коллекция телевизоров от 12 до 15 штук)
        private void Generate_Command(object sender, EventArgs e) {
            _repairShopController.RepairShop.Generate(Utils.GetRandom(12, 15));
            BindCollection(LbxTelevisions, _repairShopController);
            LblStatus.Text = $"Коллекция телевизоров сформирована. Текущее количество телевизоров: {_repairShopController.RepairShop.Count}";
        } // Generate_Command

        // Упорядочивание коллекции телевизоров
        // по производителю и типу
        private void OrderByBrand_Command(object sender, EventArgs e) {
            RepairShopController temp = new RepairShopController(_repairShopController.RepairShop, _repairShopController.FileName);
            
            LblOrder.Text = "Коллекция телевизоров упорядочена по производителю и типу:";
            
            temp.OrderByBrand();
            BindCollection(LbxOrder, temp);
            
            TbcMain.SelectedTab = TbcMain.TabPages[1];
        } // OrderByBrand_Command

        // по убыванию диагонали экрана
        private void OrderByScreen_Command(object sender, EventArgs e) {
            RepairShopController temp = new RepairShopController(_repairShopController.RepairShop, _repairShopController.FileName);
            
            LblOrder.Text = "Коллекция телевизоров упорядочена по убыванию диагонали экрана:";
            
            temp.OrderByDiagonalDesc();
            BindCollection(LbxOrder, temp);

            TbcMain.SelectedTab = TbcMain.TabPages[1];
        } // OrderByScreen_Command

        // по мастеру, выполняющему ремонт
        private void OrderByMaster_Command(object sender, EventArgs e) {
            RepairShopController temp = new RepairShopController(_repairShopController.RepairShop, _repairShopController.FileName);
            
            LblOrder.Text = "Коллекция телевизоров упорядочена по мастеру, выполняющему ремонт:";
            
            temp.OrderByArtisan();
            BindCollection(LbxOrder, temp);
            
            TbcMain.SelectedTab = TbcMain.TabPages[1];
        } // OrderByMaster_Command

        // по владельцу телевизора
        private void OrderByOwner_Command(object sender, EventArgs e) {
            RepairShopController temp = new RepairShopController(_repairShopController.RepairShop, _repairShopController.FileName);
            
            LblOrder.Text = "Коллекция телевизоров упорядочена по владельцу телевизора:";
            
            temp.OrderByOwner();
            BindCollection(LbxOrder, temp);
            
            TbcMain.SelectedTab = TbcMain.TabPages[1];
        } // OrderByOwner_Command

        // по стоимости ремонта
        private void OrderByPrice_Command(object sender, EventArgs e) {
            RepairShopController temp = new RepairShopController(_repairShopController.RepairShop, _repairShopController.FileName);
            
            LblOrder.Text = "Коллекция телевизоров упорядочена по стоимости ремонта:";
            
            temp.OrderByPrice();
            BindCollection(LbxOrder, temp);
            
            TbcMain.SelectedTab = TbcMain.TabPages[1];
        } // OrderByPrice_Command

        // Добавление телевизора в коллекцию
        private void AddTelevision_Command(object sender, EventArgs e) {
            TelevisionForm televisionForm = new TelevisionForm();

            // если окно закрыто не по кнопке BtnOk - молча уходим
            if (televisionForm.ShowDialog() != DialogResult.OK) return;

            // получить данные из свойства формы
            _repairShopController.RepairShop.AddTelevision(televisionForm.Television);
            _repairShopController.RepairShop.Serialization(@"..\..\" + _repairShopController.FileName);

            // обновить привязку
            BindCollection(LbxTelevisions, _repairShopController);
            LblStatus.Text = $"Телевизор добавлен. Текущее количество телевизоров: {_repairShopController.RepairShop.Count}";
        } // AddTelevision_Command

        // Редактирование выбранного телевизора в отдельной форме
        private void Edit_Command(object sender, EventArgs e) {
            // если нет выбранного телевизора - уходим
            if (LbxTelevisions.SelectedIndex < 0)
                return;

            TelevisionForm televisionForm = new TelevisionForm("Редактировать данные телевизора", "Сохранить");
            televisionForm.Television = _repairShopController.RepairShop.Televisions[LbxTelevisions.SelectedIndex];

            // если окно закрыто не по кнопке BtnOk - молча уходим
            if (televisionForm.ShowDialog() != DialogResult.OK) return;

            // получить данные
            _repairShopController.RepairShop.EditTelevision(LbxTelevisions.SelectedIndex, televisionForm.Television);
            _repairShopController.RepairShop.Serialization(@"..\..\" + _repairShopController.FileName);

            BindCollection(LbxTelevisions, _repairShopController);
            LblStatus.Text = $"Телевизор отредактирован. Текущее количество телевизоров: {_repairShopController.RepairShop.Count}";
        } // Edit_Command

        private void MainForm_Load(object sender, EventArgs e) {
            LblName.Text    = $"Название ремонтной мастерской: {_repairShopController.RepairShop.Name}";
            LblAddress.Text = $"Адрес ремонтной мастерской   : {_repairShopController.RepairShop.Address}";
        } // MainForm_Load

        // Выборка и вывод в отдельной вкладке коллекции телевизоров с минимальной стоимостью ремонта
        private void SelectByMinCost_Command(object sender, EventArgs e) {
            LblSelect.Text = "Выборка коллекции телевизоров с минимальной стоимостью ремонта";
            LblSelect2.Text = $"Минимальная стоимость ремонта: {_repairShopController.RepairShop.MinPrice()} руб.";

            BindCollection(LbxSelect, _repairShopController.SelectWhereMinPrice());

            TbcMain.SelectedTab = TbcMain.TabPages[2];
        } // SelectByMinCost_Command

        // Выборка и вывод в отдельной вкладке коллекции телевизоров, ремонтируемых выбранным мастером
        private void SelectByMaster_Command(object sender, EventArgs e) {
            // получить список фамилий из коллекции ремонтов
            List<string> artisans = _repairShopController.GetArtitans();

            // создание формы выбора мастера, передача в окно списка мастеров
            ChoiceForm artisanChoiceForm = new ChoiceForm("Выбор мастера", "Мастер для выборки ремонтов:", artisans);

            if (artisanChoiceForm.ShowDialog() != DialogResult.OK) return;

            string artisan = artisanChoiceForm.Option;

            LblSelect.Text = "Выборка коллекции телевизоров, ремонтируемых выбранным мастером";
            LblSelect2.Text = $"Фамилия и инициалы мастера: {artisan}";

            BindCollection(LbxSelect, _repairShopController.SelectWhereArtisan(artisan));

            TbcMain.SelectedTab = TbcMain.TabPages[2];
        } // SelectByMaster_Command

        // Выборка и вывод в отдельной вкладке коллекции телевизоров, с заданной диагональю экрана 
        private void SelectByScreen_Command(object sender, EventArgs e) {
            // получить список фамилий из коллекции ремонтов
            List<string> diagonals = _repairShopController.GetDiagonals();

            // создание формы выбора мастера, передача в окно списка мастеров
            ChoiceForm ownerChoiceForm = new ChoiceForm("Выбор диагонали", "Диагональ для выборки ремонтов:", diagonals);

            if (ownerChoiceForm.ShowDialog() != DialogResult.OK) return;

            double diagonal = double.Parse(ownerChoiceForm.Option);
            LblSelect.Text = "Выборка коллекции телевизоров, с заданной диагональю экрана";
            LblSelect2.Text = $"Диагональ экрана: {diagonal:n1}";

            BindCollection(LbxSelect, _repairShopController.SelectWhereDiagonal(diagonal));

            TbcMain.SelectedTab = TbcMain.TabPages[2];
        } // SelectByScreen_Command

        // Выборка и вывод в отдельной вкладке коллекции телевизоров, заданного владельца
        private void SelectByOwner_Command(object sender, EventArgs e) {
            // получить список фамилий из коллекции ремонтов
            List<string> owners = _repairShopController.GetOwners();

            // создание формы выбора мастера, передача в окно списка мастеров
            ChoiceForm ownerChoiceForm = new ChoiceForm("Выбор владельца", "Владелец для выборки ремонтов:", owners);

            if (ownerChoiceForm.ShowDialog() != DialogResult.OK) return;

            string owner = ownerChoiceForm.Option;
            LblSelect.Text = "Выборка коллекции телевизоров, заданного владельца";
            LblSelect2.Text = $"Фамилия и инициалы владельца: {owner}";

            BindCollection(LbxSelect, _repairShopController.SelectWhereOwner(owner));

            TbcMain.SelectedTab = TbcMain.TabPages[2];
        } // SelectByOwner_Command

        private void Exit_Command(object sender, EventArgs e) => Application.Exit();

        private void About_Command(object sender, EventArgs e) {
            FormAbout formAbout = new FormAbout();
            formAbout.ShowDialog();
        } // About_Command

        // Редактирование данных ремонтной мастерской
        private void EditRepairShop_Command(object sender, EventArgs e) {
            RepairShopForm repairShopForm = new RepairShopForm(_repairShopController.RepairShop.Name, _repairShopController.RepairShop.Address);

            // если окно закрыто не по кнопке BtnOk - молча уходим
            if (repairShopForm.ShowDialog() != DialogResult.OK) return;

            // получить данные
            _repairShopController.RepairShop.Name    = repairShopForm.Name;
            _repairShopController.RepairShop.Address = repairShopForm.Address;
            _repairShopController.RepairShop.Serialization(@"..\..\" + _repairShopController.FileName);

            MainForm_Load(sender, e);
        } // EditRepairShop_Command

        // удаление телевизора из коллекции 
        private void RemoveTelevision_Command(object sender, EventArgs e) {
            int index = LbxTelevisions.SelectedIndex;
            if (index < 0) return;

            _repairShopController.RepairShop.RemoveTelevision(index);
            BindCollection(LbxTelevisions, _repairShopController);
            _repairShopController.RepairShop.Serialization(@"..\..\" + _repairShopController.FileName);


            if (index == _repairShopController.RepairShop.Count)
                LbxTelevisions.SelectedIndex = index - 1;
        } // OrderByPrice_Command

        // Сохранение данных ремонтной мастерской
        private void Save_Command(object sender, EventArgs e) =>
            _repairShopController.RepairShop.Serialization(@"..\..\"+_repairShopController.FileName);

        // Загрузка данных ремонтной мастерской из выбранного файла
        private void Open_Command(object sender, EventArgs e) {
            OfdMain.Title = "Открыть файл";
            OfdMain.InitialDirectory = @"../../";
            OfdMain.Filter = "Файлы JSON (*.json)|*.json";
            OfdMain.FilterIndex = 1;
            if (OfdMain.ShowDialog() == DialogResult.OK) {
                _repairShopController.RepairShop.Deserialization(OfdMain.FileName);
                BindCollection(LbxTelevisions, _repairShopController);
                MainForm_Load(sender, e);
            } // if
        } // Open_Command

        // Сохранение данных ремонтной мастерской в выбранном файле 
        private void SaveAs_Command(object sender, EventArgs e) {
            SfdMain.Title = "Сохранить файл как";
            SfdMain.InitialDirectory = @"../../";
            SfdMain.Filter = "Файлы JSON (*.json)|*.json";
            SfdMain.FilterIndex = 1;
            if (SfdMain.ShowDialog() == DialogResult.OK) {
                _repairShopController.RepairShop.Serialization(SfdMain.FileName);
            } // if
        } // SaveAs_Command

        // Изменение шрифта для отображения коллекции телевизоров в ListBox 
        private void EditFont_Command(object sender, EventArgs e) {
            if (FdlTextFont.ShowDialog() == DialogResult.OK) {
                LbxTelevisions.Font = FdlTextFont.Font;
                LbxTelevisions.ForeColor = FdlTextFont.Color;
            }
        } // EditFont_Command

        // Изменение фона ListBox отображения коллекции телевизоров
        private void BackColor_Click(object sender, EventArgs e) {
            if (CdlBackColor.ShowDialog() == DialogResult.OK)
                LbxTelevisions.BackColor = CdlBackColor.Color;
        } // BackColor_Click

        private void ToTray_Command(object sender, EventArgs e) {
            Hide();
            NtiMain.Visible = true;
        } // ToTray_Command

        private void FromTray_Command(object sender, EventArgs e) {
            Show();
            WindowState = FormWindowState.Normal;
            NtiMain.Visible = false;
        } // FromTray_Command
    }
}
