﻿
namespace Televisions.Views
{
    partial class MainForm
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.CmsLbxTelevisions = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.toolStripMenuItem4 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripMenuItem5 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripMenuItem6 = new System.Windows.Forms.ToolStripSeparator();
            this.оПрограммеToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.StsMain = new System.Windows.Forms.StatusStrip();
            this.LblStatus = new System.Windows.Forms.ToolStripStatusLabel();
            this.LblName = new System.Windows.Forms.Label();
            this.LblAddress = new System.Windows.Forms.Label();
            this.PnlMain = new System.Windows.Forms.Panel();
            this.CmnMain = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.toolStripMenuItem20 = new System.Windows.Forms.ToolStripMenuItem();
            this.MnsMain = new System.Windows.Forms.MenuStrip();
            this.MniFile = new System.Windows.Forms.ToolStripMenuItem();
            this.MniFileOpen = new System.Windows.Forms.ToolStripMenuItem();
            this.MniFileSave = new System.Windows.Forms.ToolStripMenuItem();
            this.MniFileSaveAs = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripSeparator();
            this.MniFileExit = new System.Windows.Forms.ToolStripMenuItem();
            this.MniRepairShop = new System.Windows.Forms.ToolStripMenuItem();
            this.MniTelevisions = new System.Windows.Forms.ToolStripMenuItem();
            this.MniTelevisionsSep1 = new System.Windows.Forms.ToolStripSeparator();
            this.MniOrderBy = new System.Windows.Forms.ToolStripMenuItem();
            this.MniSelectWhere = new System.Windows.Forms.ToolStripMenuItem();
            this.MniHelp = new System.Windows.Forms.ToolStripMenuItem();
            this.MniHelpAbout = new System.Windows.Forms.ToolStripMenuItem();
            this.MniService = new System.Windows.Forms.ToolStripMenuItem();
            this.MniServiceFont = new System.Windows.Forms.ToolStripMenuItem();
            this.MniServiceBackColor = new System.Windows.Forms.ToolStripMenuItem();
            this.TspMain = new System.Windows.Forms.ToolStrip();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.OfdMain = new System.Windows.Forms.OpenFileDialog();
            this.SfdMain = new System.Windows.Forms.SaveFileDialog();
            this.CdlBackColor = new System.Windows.Forms.ColorDialog();
            this.FdlTextFont = new System.Windows.Forms.FontDialog();
            this.TbcMain = new System.Windows.Forms.TabControl();
            this.TbpName = new System.Windows.Forms.TabPage();
            this.TbpOrder = new System.Windows.Forms.TabPage();
            this.LbxTelevisions = new System.Windows.Forms.ListBox();
            this.LblTelevision = new System.Windows.Forms.Label();
            this.LbxOrder = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.PnlOrder = new System.Windows.Forms.Panel();
            this.LblOrder = new System.Windows.Forms.Label();
            this.TbpSelect = new System.Windows.Forms.TabPage();
            this.LbxSelect = new System.Windows.Forms.ListBox();
            this.label2 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.LblSelect = new System.Windows.Forms.Label();
            this.LblSelect2 = new System.Windows.Forms.Label();
            this.NtiMain = new System.Windows.Forms.NotifyIcon(this.components);
            this.CmsMain = new System.Windows.Forms.ToolStripMenuItem();
            this.новаяКоллекцияToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.редактироватьДанныеМастерскойToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.добавитьТелевизорToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.редактироватьТелевизорToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.удалитьТелевизорToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.сортировкаToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.поПроизводителюИТипуToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.поУбываниюДиагоналиЭкранаToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.поМастеруВыполняющемуРемонтToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.поВладельцуТелевизораToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.поСтоимостиРемонтаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.выбратьToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.сМинимальнойСтоимостьюРемонтаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ремонтируемыеВыбраннымМастеромToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.сЗаданнойДиагональюЭкранаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.телевизорыЗаданногоВладельцаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.выходToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.TsbGenerate = new System.Windows.Forms.ToolStripButton();
            this.TsbEditRepairShop = new System.Windows.Forms.ToolStripButton();
            this.TsbAddTelevision = new System.Windows.Forms.ToolStripButton();
            this.TsbEdit = new System.Windows.Forms.ToolStripButton();
            this.TsbRemove = new System.Windows.Forms.ToolStripButton();
            this.TsbOrder = new System.Windows.Forms.ToolStripSplitButton();
            this.MniByBrand = new System.Windows.Forms.ToolStripMenuItem();
            this.MniByScreen = new System.Windows.Forms.ToolStripMenuItem();
            this.MniByMaster = new System.Windows.Forms.ToolStripMenuItem();
            this.MniByOwner = new System.Windows.Forms.ToolStripMenuItem();
            this.MniByPrice = new System.Windows.Forms.ToolStripMenuItem();
            this.TsbSelect = new System.Windows.Forms.ToolStripSplitButton();
            this.ByMinCost = new System.Windows.Forms.ToolStripMenuItem();
            this.ByMaster = new System.Windows.Forms.ToolStripMenuItem();
            this.ByScreen = new System.Windows.Forms.ToolStripMenuItem();
            this.ByOwner = new System.Windows.Forms.ToolStripMenuItem();
            this.TsbExit = new System.Windows.Forms.ToolStripButton();
            this.TsbToTray = new System.Windows.Forms.ToolStripButton();
            this.MniRepairShopNew = new System.Windows.Forms.ToolStripMenuItem();
            this.MniRepairShopEdit = new System.Windows.Forms.ToolStripMenuItem();
            this.MniTelevisionsAdd = new System.Windows.Forms.ToolStripMenuItem();
            this.MniTelevisionsEdit = new System.Windows.Forms.ToolStripMenuItem();
            this.MniTelevisionsRemoveAt = new System.Windows.Forms.ToolStripMenuItem();
            this.MniOrderByBrand = new System.Windows.Forms.ToolStripMenuItem();
            this.MniOrderByDiagonalDesc = new System.Windows.Forms.ToolStripMenuItem();
            this.MniOrderByArtisan = new System.Windows.Forms.ToolStripMenuItem();
            this.MniOrderByOwner = new System.Windows.Forms.ToolStripMenuItem();
            this.MniOrderByPrice = new System.Windows.Forms.ToolStripMenuItem();
            this.MniSelectWhereInexpensive = new System.Windows.Forms.ToolStripMenuItem();
            this.MniSelectWhereArtisan = new System.Windows.Forms.ToolStripMenuItem();
            this.MniSelectWhereDiagonal = new System.Windows.Forms.ToolStripMenuItem();
            this.MniSelectWhereOwner = new System.Windows.Forms.ToolStripMenuItem();
            this.свернутьВТрейToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.CmnTray = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.toolStripMenuItem7 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem8 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem9 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem10 = new System.Windows.Forms.ToolStripSeparator();
            this.CmsLbxTelevisions.SuspendLayout();
            this.StsMain.SuspendLayout();
            this.PnlMain.SuspendLayout();
            this.CmnMain.SuspendLayout();
            this.MnsMain.SuspendLayout();
            this.TspMain.SuspendLayout();
            this.TbcMain.SuspendLayout();
            this.TbpName.SuspendLayout();
            this.TbpOrder.SuspendLayout();
            this.PnlOrder.SuspendLayout();
            this.TbpSelect.SuspendLayout();
            this.panel1.SuspendLayout();
            this.CmnTray.SuspendLayout();
            this.SuspendLayout();
            // 
            // CmsLbxTelevisions
            // 
            this.CmsLbxTelevisions.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.новаяКоллекцияToolStripMenuItem,
            this.редактироватьДанныеМастерскойToolStripMenuItem1,
            this.toolStripMenuItem4,
            this.добавитьТелевизорToolStripMenuItem1,
            this.редактироватьТелевизорToolStripMenuItem,
            this.удалитьТелевизорToolStripMenuItem,
            this.toolStripMenuItem3,
            this.сортировкаToolStripMenuItem1,
            this.toolStripMenuItem5,
            this.выбратьToolStripMenuItem1,
            this.toolStripMenuItem6,
            this.выходToolStripMenuItem,
            this.оПрограммеToolStripMenuItem1});
            this.CmsLbxTelevisions.Name = "CmsLbxTelevisions";
            this.CmsLbxTelevisions.Size = new System.Drawing.Size(276, 226);
            // 
            // toolStripMenuItem4
            // 
            this.toolStripMenuItem4.Name = "toolStripMenuItem4";
            this.toolStripMenuItem4.Size = new System.Drawing.Size(272, 6);
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(272, 6);
            // 
            // toolStripMenuItem5
            // 
            this.toolStripMenuItem5.Name = "toolStripMenuItem5";
            this.toolStripMenuItem5.Size = new System.Drawing.Size(272, 6);
            // 
            // toolStripMenuItem6
            // 
            this.toolStripMenuItem6.Name = "toolStripMenuItem6";
            this.toolStripMenuItem6.Size = new System.Drawing.Size(272, 6);
            // 
            // оПрограммеToolStripMenuItem1
            // 
            this.оПрограммеToolStripMenuItem1.Name = "оПрограммеToolStripMenuItem1";
            this.оПрограммеToolStripMenuItem1.Size = new System.Drawing.Size(275, 22);
            this.оПрограммеToolStripMenuItem1.Text = "О программе...";
            this.оПрограммеToolStripMenuItem1.Click += new System.EventHandler(this.About_Command);
            // 
            // StsMain
            // 
            this.StsMain.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.StsMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.LblStatus});
            this.StsMain.Location = new System.Drawing.Point(0, 480);
            this.StsMain.Name = "StsMain";
            this.StsMain.Size = new System.Drawing.Size(800, 24);
            this.StsMain.TabIndex = 2;
            this.StsMain.Text = "statusStrip1";
            // 
            // LblStatus
            // 
            this.LblStatus.AutoSize = false;
            this.LblStatus.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblStatus.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.LblStatus.Name = "LblStatus";
            this.LblStatus.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.LblStatus.Size = new System.Drawing.Size(760, 19);
            this.LblStatus.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // LblName
            // 
            this.LblName.AutoSize = true;
            this.LblName.Font = new System.Drawing.Font("Consolas", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblName.Location = new System.Drawing.Point(3, 6);
            this.LblName.Name = "LblName";
            this.LblName.Size = new System.Drawing.Size(40, 18);
            this.LblName.TabIndex = 5;
            this.LblName.Text = "Name";
            // 
            // LblAddress
            // 
            this.LblAddress.AutoSize = true;
            this.LblAddress.Font = new System.Drawing.Font("Consolas", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblAddress.Location = new System.Drawing.Point(3, 26);
            this.LblAddress.Name = "LblAddress";
            this.LblAddress.Size = new System.Drawing.Size(64, 18);
            this.LblAddress.TabIndex = 6;
            this.LblAddress.Text = "Address";
            // 
            // PnlMain
            // 
            this.PnlMain.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.PnlMain.Controls.Add(this.LblAddress);
            this.PnlMain.Controls.Add(this.LblName);
            this.PnlMain.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.PnlMain.Location = new System.Drawing.Point(19, 9);
            this.PnlMain.Name = "PnlMain";
            this.PnlMain.Size = new System.Drawing.Size(754, 50);
            this.PnlMain.TabIndex = 7;
            // 
            // CmnMain
            // 
            this.CmnMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.свернутьВТрейToolStripMenuItem,
            this.CmsMain,
            this.toolStripMenuItem20});
            this.CmnMain.Name = "CmsLbxTelevisions";
            this.CmnMain.Size = new System.Drawing.Size(163, 70);
            // 
            // toolStripMenuItem20
            // 
            this.toolStripMenuItem20.Name = "toolStripMenuItem20";
            this.toolStripMenuItem20.Size = new System.Drawing.Size(162, 22);
            this.toolStripMenuItem20.Text = "О программе...";
            // 
            // MnsMain
            // 
            this.MnsMain.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.MnsMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniFile,
            this.MniRepairShop,
            this.MniTelevisions,
            this.MniOrderBy,
            this.MniSelectWhere,
            this.MniHelp,
            this.MniService});
            this.MnsMain.Location = new System.Drawing.Point(0, 0);
            this.MnsMain.Name = "MnsMain";
            this.MnsMain.Size = new System.Drawing.Size(800, 29);
            this.MnsMain.TabIndex = 8;
            this.MnsMain.Text = "menuStrip1";
            // 
            // MniFile
            // 
            this.MniFile.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniFileOpen,
            this.MniFileSave,
            this.MniFileSaveAs,
            this.toolStripMenuItem1,
            this.toolStripMenuItem2,
            this.MniFileExit});
            this.MniFile.Name = "MniFile";
            this.MniFile.Size = new System.Drawing.Size(59, 25);
            this.MniFile.Text = "Файл";
            // 
            // MniFileOpen
            // 
            this.MniFileOpen.Name = "MniFileOpen";
            this.MniFileOpen.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.O)));
            this.MniFileOpen.Size = new System.Drawing.Size(291, 26);
            this.MniFileOpen.Text = "Открыть...";
            this.MniFileOpen.Click += new System.EventHandler(this.Open_Command);
            // 
            // MniFileSave
            // 
            this.MniFileSave.Name = "MniFileSave";
            this.MniFileSave.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.S)));
            this.MniFileSave.Size = new System.Drawing.Size(291, 26);
            this.MniFileSave.Text = "Сохранить";
            this.MniFileSave.Click += new System.EventHandler(this.Save_Command);
            // 
            // MniFileSaveAs
            // 
            this.MniFileSaveAs.Name = "MniFileSaveAs";
            this.MniFileSaveAs.ShortcutKeys = ((System.Windows.Forms.Keys)(((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Shift) 
            | System.Windows.Forms.Keys.S)));
            this.MniFileSaveAs.Size = new System.Drawing.Size(291, 26);
            this.MniFileSaveAs.Text = "Сохранить как...";
            this.MniFileSaveAs.Click += new System.EventHandler(this.SaveAs_Command);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(288, 6);
            // 
            // MniFileExit
            // 
            this.MniFileExit.Image = global::Televisions.Properties.Resources.exit;
            this.MniFileExit.Name = "MniFileExit";
            this.MniFileExit.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.F4)));
            this.MniFileExit.Size = new System.Drawing.Size(291, 26);
            this.MniFileExit.Text = "Выход";
            this.MniFileExit.Click += new System.EventHandler(this.Exit_Command);
            // 
            // MniRepairShop
            // 
            this.MniRepairShop.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniRepairShopNew,
            this.MniRepairShopEdit});
            this.MniRepairShop.Name = "MniRepairShop";
            this.MniRepairShop.Size = new System.Drawing.Size(106, 25);
            this.MniRepairShop.Text = "Мастерская";
            // 
            // MniTelevisions
            // 
            this.MniTelevisions.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniTelevisionsAdd,
            this.MniTelevisionsEdit,
            this.MniTelevisionsSep1,
            this.MniTelevisionsRemoveAt});
            this.MniTelevisions.Name = "MniTelevisions";
            this.MniTelevisions.Size = new System.Drawing.Size(180, 25);
            this.MniTelevisions.Text = "Ремонты телевизоров";
            // 
            // MniTelevisionsSep1
            // 
            this.MniTelevisionsSep1.Name = "MniTelevisionsSep1";
            this.MniTelevisionsSep1.Size = new System.Drawing.Size(216, 6);
            // 
            // MniOrderBy
            // 
            this.MniOrderBy.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniOrderByBrand,
            this.MniOrderByDiagonalDesc,
            this.MniOrderByArtisan,
            this.MniOrderByOwner,
            this.MniOrderByPrice});
            this.MniOrderBy.Name = "MniOrderBy";
            this.MniOrderBy.Size = new System.Drawing.Size(108, 25);
            this.MniOrderBy.Text = "Сортировка";
            // 
            // MniSelectWhere
            // 
            this.MniSelectWhere.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniSelectWhereInexpensive,
            this.MniSelectWhereArtisan,
            this.MniSelectWhereDiagonal,
            this.MniSelectWhereOwner});
            this.MniSelectWhere.Name = "MniSelectWhere";
            this.MniSelectWhere.Size = new System.Drawing.Size(85, 25);
            this.MniSelectWhere.Text = "Выборка";
            // 
            // MniHelp
            // 
            this.MniHelp.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.MniHelp.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniHelpAbout});
            this.MniHelp.Name = "MniHelp";
            this.MniHelp.Size = new System.Drawing.Size(82, 25);
            this.MniHelp.Text = "Справка";
            // 
            // MniHelpAbout
            // 
            this.MniHelpAbout.Name = "MniHelpAbout";
            this.MniHelpAbout.Size = new System.Drawing.Size(185, 26);
            this.MniHelpAbout.Text = "О программе...";
            this.MniHelpAbout.Click += new System.EventHandler(this.About_Command);
            // 
            // MniService
            // 
            this.MniService.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.MniService.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniServiceFont,
            this.MniServiceBackColor});
            this.MniService.Name = "MniService";
            this.MniService.Size = new System.Drawing.Size(73, 25);
            this.MniService.Text = "Сервис";
            // 
            // MniServiceFont
            // 
            this.MniServiceFont.Name = "MniServiceFont";
            this.MniServiceFont.Size = new System.Drawing.Size(165, 26);
            this.MniServiceFont.Text = "Шрифт...";
            this.MniServiceFont.Click += new System.EventHandler(this.EditFont_Command);
            // 
            // MniServiceBackColor
            // 
            this.MniServiceBackColor.Name = "MniServiceBackColor";
            this.MniServiceBackColor.Size = new System.Drawing.Size(165, 26);
            this.MniServiceBackColor.Text = "Цвет фона...";
            this.MniServiceBackColor.Click += new System.EventHandler(this.BackColor_Click);
            // 
            // TspMain
            // 
            this.TspMain.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TspMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.TsbGenerate,
            this.TsbEditRepairShop,
            this.toolStripSeparator2,
            this.TsbAddTelevision,
            this.TsbEdit,
            this.TsbRemove,
            this.toolStripSeparator1,
            this.TsbOrder,
            this.toolStripSeparator3,
            this.TsbSelect,
            this.TsbExit,
            this.TsbToTray});
            this.TspMain.Location = new System.Drawing.Point(0, 29);
            this.TspMain.Name = "TspMain";
            this.TspMain.Size = new System.Drawing.Size(800, 37);
            this.TspMain.TabIndex = 9;
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 37);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 37);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(6, 37);
            // 
            // OfdMain
            // 
            this.OfdMain.FileName = "Televisions.json";
            this.OfdMain.InitialDirectory = "..\\..\\";
            // 
            // SfdMain
            // 
            this.SfdMain.FileName = "Televisions.json";
            // 
            // CdlBackColor
            // 
            this.CdlBackColor.FullOpen = true;
            // 
            // FdlTextFont
            // 
            this.FdlTextFont.ShowColor = true;
            // 
            // TbcMain
            // 
            this.TbcMain.Controls.Add(this.TbpName);
            this.TbcMain.Controls.Add(this.TbpOrder);
            this.TbcMain.Controls.Add(this.TbpSelect);
            this.TbcMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TbcMain.Location = new System.Drawing.Point(0, 66);
            this.TbcMain.Name = "TbcMain";
            this.TbcMain.SelectedIndex = 0;
            this.TbcMain.Size = new System.Drawing.Size(800, 414);
            this.TbcMain.TabIndex = 7;
            // 
            // TbpName
            // 
            this.TbpName.Controls.Add(this.LbxTelevisions);
            this.TbpName.Controls.Add(this.LblTelevision);
            this.TbpName.Controls.Add(this.PnlMain);
            this.TbpName.Location = new System.Drawing.Point(4, 28);
            this.TbpName.Name = "TbpName";
            this.TbpName.Padding = new System.Windows.Forms.Padding(3);
            this.TbpName.Size = new System.Drawing.Size(792, 382);
            this.TbpName.TabIndex = 0;
            this.TbpName.Text = "Главная";
            this.TbpName.UseVisualStyleBackColor = true;
            // 
            // TbpOrder
            // 
            this.TbpOrder.Controls.Add(this.LbxOrder);
            this.TbpOrder.Controls.Add(this.label1);
            this.TbpOrder.Controls.Add(this.PnlOrder);
            this.TbpOrder.Location = new System.Drawing.Point(4, 22);
            this.TbpOrder.Name = "TbpOrder";
            this.TbpOrder.Padding = new System.Windows.Forms.Padding(3);
            this.TbpOrder.Size = new System.Drawing.Size(792, 388);
            this.TbpOrder.TabIndex = 1;
            this.TbpOrder.Text = "Сортировки";
            this.TbpOrder.UseVisualStyleBackColor = true;
            // 
            // LbxTelevisions
            // 
            this.LbxTelevisions.ContextMenuStrip = this.CmsLbxTelevisions;
            this.LbxTelevisions.Font = new System.Drawing.Font("Consolas", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LbxTelevisions.FormattingEnabled = true;
            this.LbxTelevisions.Location = new System.Drawing.Point(19, 88);
            this.LbxTelevisions.Name = "LbxTelevisions";
            this.LbxTelevisions.Size = new System.Drawing.Size(754, 277);
            this.LbxTelevisions.TabIndex = 8;
            // 
            // LblTelevision
            // 
            this.LblTelevision.BackColor = System.Drawing.Color.Gainsboro;
            this.LblTelevision.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.LblTelevision.Font = new System.Drawing.Font("Consolas", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblTelevision.Location = new System.Drawing.Point(19, 69);
            this.LblTelevision.Name = "LblTelevision";
            this.LblTelevision.Size = new System.Drawing.Size(754, 41);
            this.LblTelevision.TabIndex = 9;
            this.LblTelevision.Text = "  Производитель, модель   Диагональ, \"         Описание дефекта          Владелец" +
    "              Мастер          Цена, руб. ";
            // 
            // LbxOrder
            // 
            this.LbxOrder.Font = new System.Drawing.Font("Consolas", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LbxOrder.FormattingEnabled = true;
            this.LbxOrder.Location = new System.Drawing.Point(19, 92);
            this.LbxOrder.Name = "LbxOrder";
            this.LbxOrder.Size = new System.Drawing.Size(754, 277);
            this.LbxOrder.TabIndex = 11;
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.Gainsboro;
            this.label1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.label1.Font = new System.Drawing.Font("Consolas", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(19, 73);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(754, 41);
            this.label1.TabIndex = 12;
            this.label1.Text = "  Производитель, модель   Диагональ, \"         Описание дефекта          Владелец" +
    "              Мастер          Цена, руб. ";
            // 
            // PnlOrder
            // 
            this.PnlOrder.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.PnlOrder.Controls.Add(this.LblOrder);
            this.PnlOrder.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.PnlOrder.Location = new System.Drawing.Point(19, 13);
            this.PnlOrder.Name = "PnlOrder";
            this.PnlOrder.Size = new System.Drawing.Size(754, 50);
            this.PnlOrder.TabIndex = 10;
            // 
            // LblOrder
            // 
            this.LblOrder.Font = new System.Drawing.Font("Consolas", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblOrder.Location = new System.Drawing.Point(3, 15);
            this.LblOrder.Name = "LblOrder";
            this.LblOrder.Size = new System.Drawing.Size(748, 18);
            this.LblOrder.TabIndex = 5;
            this.LblOrder.Text = "Для сортировки ремонтов требуется выбрать соответствующую команду в меню";
            this.LblOrder.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // TbpSelect
            // 
            this.TbpSelect.Controls.Add(this.LbxSelect);
            this.TbpSelect.Controls.Add(this.label2);
            this.TbpSelect.Controls.Add(this.panel1);
            this.TbpSelect.Location = new System.Drawing.Point(4, 22);
            this.TbpSelect.Name = "TbpSelect";
            this.TbpSelect.Padding = new System.Windows.Forms.Padding(3);
            this.TbpSelect.Size = new System.Drawing.Size(792, 388);
            this.TbpSelect.TabIndex = 2;
            this.TbpSelect.Text = "Выборки";
            this.TbpSelect.UseVisualStyleBackColor = true;
            // 
            // LbxSelect
            // 
            this.LbxSelect.Font = new System.Drawing.Font("Consolas", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LbxSelect.FormattingEnabled = true;
            this.LbxSelect.Location = new System.Drawing.Point(19, 92);
            this.LbxSelect.Name = "LbxSelect";
            this.LbxSelect.Size = new System.Drawing.Size(754, 277);
            this.LbxSelect.TabIndex = 14;
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.Color.Gainsboro;
            this.label2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.label2.Font = new System.Drawing.Font("Consolas", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(19, 73);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(754, 41);
            this.label2.TabIndex = 15;
            this.label2.Text = "  Производитель, модель   Диагональ, \"         Описание дефекта          Владелец" +
    "              Мастер          Цена, руб. ";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel1.Controls.Add(this.LblSelect2);
            this.panel1.Controls.Add(this.LblSelect);
            this.panel1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.panel1.Location = new System.Drawing.Point(19, 13);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(754, 50);
            this.panel1.TabIndex = 13;
            // 
            // LblSelect
            // 
            this.LblSelect.Font = new System.Drawing.Font("Consolas", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblSelect.Location = new System.Drawing.Point(3, 8);
            this.LblSelect.Name = "LblSelect";
            this.LblSelect.Size = new System.Drawing.Size(748, 18);
            this.LblSelect.TabIndex = 5;
            this.LblSelect.Text = "Для выборки ремонтов требуется выбрать соответствующую команду в меню";
            this.LblSelect.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // LblSelect2
            // 
            this.LblSelect2.Font = new System.Drawing.Font("Consolas", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblSelect2.Location = new System.Drawing.Point(3, 25);
            this.LblSelect2.Name = "LblSelect2";
            this.LblSelect2.Size = new System.Drawing.Size(748, 18);
            this.LblSelect2.TabIndex = 6;
            this.LblSelect2.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // NtiMain
            // 
            this.NtiMain.ContextMenuStrip = this.CmnTray;
            this.NtiMain.Icon = ((System.Drawing.Icon)(resources.GetObject("NtiMain.Icon")));
            this.NtiMain.Text = "Приложение свернуто в трей";
            this.NtiMain.Visible = true;
            // 
            // CmsMain
            // 
            this.CmsMain.Image = global::Televisions.Properties.Resources.exit;
            this.CmsMain.Name = "CmsMain";
            this.CmsMain.Size = new System.Drawing.Size(162, 22);
            this.CmsMain.Text = "Выход";
            // 
            // новаяКоллекцияToolStripMenuItem
            // 
            this.новаяКоллекцияToolStripMenuItem.Image = global::Televisions.Properties.Resources.Create;
            this.новаяКоллекцияToolStripMenuItem.Name = "новаяКоллекцияToolStripMenuItem";
            this.новаяКоллекцияToolStripMenuItem.Size = new System.Drawing.Size(275, 22);
            this.новаяКоллекцияToolStripMenuItem.Text = "Новая коллекция";
            this.новаяКоллекцияToolStripMenuItem.Click += new System.EventHandler(this.Generate_Command);
            // 
            // редактироватьДанныеМастерскойToolStripMenuItem1
            // 
            this.редактироватьДанныеМастерскойToolStripMenuItem1.Image = global::Televisions.Properties.Resources.EditRepairShop;
            this.редактироватьДанныеМастерскойToolStripMenuItem1.Name = "редактироватьДанныеМастерскойToolStripMenuItem1";
            this.редактироватьДанныеМастерскойToolStripMenuItem1.Size = new System.Drawing.Size(275, 22);
            this.редактироватьДанныеМастерскойToolStripMenuItem1.Text = "Редактировать данные мастерской...";
            this.редактироватьДанныеМастерскойToolStripMenuItem1.Click += new System.EventHandler(this.EditRepairShop_Command);
            // 
            // добавитьТелевизорToolStripMenuItem1
            // 
            this.добавитьТелевизорToolStripMenuItem1.Image = global::Televisions.Properties.Resources.Add;
            this.добавитьТелевизорToolStripMenuItem1.Name = "добавитьТелевизорToolStripMenuItem1";
            this.добавитьТелевизорToolStripMenuItem1.Size = new System.Drawing.Size(275, 22);
            this.добавитьТелевизорToolStripMenuItem1.Text = "Добавить телевизор...";
            this.добавитьТелевизорToolStripMenuItem1.Click += new System.EventHandler(this.AddTelevision_Command);
            // 
            // редактироватьТелевизорToolStripMenuItem
            // 
            this.редактироватьТелевизорToolStripMenuItem.Image = global::Televisions.Properties.Resources.Edit;
            this.редактироватьТелевизорToolStripMenuItem.Name = "редактироватьТелевизорToolStripMenuItem";
            this.редактироватьТелевизорToolStripMenuItem.Size = new System.Drawing.Size(275, 22);
            this.редактироватьТелевизорToolStripMenuItem.Text = "Редактировать телевизор..";
            this.редактироватьТелевизорToolStripMenuItem.Click += new System.EventHandler(this.Edit_Command);
            // 
            // удалитьТелевизорToolStripMenuItem
            // 
            this.удалитьТелевизорToolStripMenuItem.Image = global::Televisions.Properties.Resources.remove;
            this.удалитьТелевизорToolStripMenuItem.Name = "удалитьТелевизорToolStripMenuItem";
            this.удалитьТелевизорToolStripMenuItem.Size = new System.Drawing.Size(275, 22);
            this.удалитьТелевизорToolStripMenuItem.Text = "Удалить телевизор";
            this.удалитьТелевизорToolStripMenuItem.Click += new System.EventHandler(this.RemoveTelevision_Command);
            // 
            // сортировкаToolStripMenuItem1
            // 
            this.сортировкаToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.поПроизводителюИТипуToolStripMenuItem1,
            this.поУбываниюДиагоналиЭкранаToolStripMenuItem1,
            this.поМастеруВыполняющемуРемонтToolStripMenuItem1,
            this.поВладельцуТелевизораToolStripMenuItem1,
            this.поСтоимостиРемонтаToolStripMenuItem});
            this.сортировкаToolStripMenuItem1.Image = global::Televisions.Properties.Resources.OrderBy;
            this.сортировкаToolStripMenuItem1.Name = "сортировкаToolStripMenuItem1";
            this.сортировкаToolStripMenuItem1.Size = new System.Drawing.Size(275, 22);
            this.сортировкаToolStripMenuItem1.Text = "Сортировка";
            // 
            // поПроизводителюИТипуToolStripMenuItem1
            // 
            this.поПроизводителюИТипуToolStripMenuItem1.Image = global::Televisions.Properties.Resources.name;
            this.поПроизводителюИТипуToolStripMenuItem1.Name = "поПроизводителюИТипуToolStripMenuItem1";
            this.поПроизводителюИТипуToolStripMenuItem1.Size = new System.Drawing.Size(279, 22);
            this.поПроизводителюИТипуToolStripMenuItem1.Text = "По производителю и типу";
            this.поПроизводителюИТипуToolStripMenuItem1.Click += new System.EventHandler(this.OrderByBrand_Command);
            // 
            // поУбываниюДиагоналиЭкранаToolStripMenuItem1
            // 
            this.поУбываниюДиагоналиЭкранаToolStripMenuItem1.Image = global::Televisions.Properties.Resources.Screen;
            this.поУбываниюДиагоналиЭкранаToolStripMenuItem1.Name = "поУбываниюДиагоналиЭкранаToolStripMenuItem1";
            this.поУбываниюДиагоналиЭкранаToolStripMenuItem1.Size = new System.Drawing.Size(279, 22);
            this.поУбываниюДиагоналиЭкранаToolStripMenuItem1.Text = "По убыванию диагонали экрана";
            this.поУбываниюДиагоналиЭкранаToolStripMenuItem1.Click += new System.EventHandler(this.OrderByScreen_Command);
            // 
            // поМастеруВыполняющемуРемонтToolStripMenuItem1
            // 
            this.поМастеруВыполняющемуРемонтToolStripMenuItem1.Image = global::Televisions.Properties.Resources.Master;
            this.поМастеруВыполняющемуРемонтToolStripMenuItem1.Name = "поМастеруВыполняющемуРемонтToolStripMenuItem1";
            this.поМастеруВыполняющемуРемонтToolStripMenuItem1.Size = new System.Drawing.Size(279, 22);
            this.поМастеруВыполняющемуРемонтToolStripMenuItem1.Text = "По мастеру, выполняющему ремонт";
            this.поМастеруВыполняющемуРемонтToolStripMenuItem1.Click += new System.EventHandler(this.OrderByMaster_Command);
            // 
            // поВладельцуТелевизораToolStripMenuItem1
            // 
            this.поВладельцуТелевизораToolStripMenuItem1.Image = global::Televisions.Properties.Resources.Owner;
            this.поВладельцуТелевизораToolStripMenuItem1.Name = "поВладельцуТелевизораToolStripMenuItem1";
            this.поВладельцуТелевизораToolStripMenuItem1.Size = new System.Drawing.Size(279, 22);
            this.поВладельцуТелевизораToolStripMenuItem1.Text = "По владельцу телевизора";
            this.поВладельцуТелевизораToolStripMenuItem1.Click += new System.EventHandler(this.OrderByOwner_Command);
            // 
            // поСтоимостиРемонтаToolStripMenuItem
            // 
            this.поСтоимостиРемонтаToolStripMenuItem.Image = global::Televisions.Properties.Resources.Cost;
            this.поСтоимостиРемонтаToolStripMenuItem.Name = "поСтоимостиРемонтаToolStripMenuItem";
            this.поСтоимостиРемонтаToolStripMenuItem.Size = new System.Drawing.Size(279, 22);
            this.поСтоимостиРемонтаToolStripMenuItem.Text = "По стоимости ремонта";
            this.поСтоимостиРемонтаToolStripMenuItem.Click += new System.EventHandler(this.OrderByPrice_Command);
            // 
            // выбратьToolStripMenuItem1
            // 
            this.выбратьToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.сМинимальнойСтоимостьюРемонтаToolStripMenuItem,
            this.ремонтируемыеВыбраннымМастеромToolStripMenuItem,
            this.сЗаданнойДиагональюЭкранаToolStripMenuItem,
            this.телевизорыЗаданногоВладельцаToolStripMenuItem});
            this.выбратьToolStripMenuItem1.Image = global::Televisions.Properties.Resources.Select;
            this.выбратьToolStripMenuItem1.Name = "выбратьToolStripMenuItem1";
            this.выбратьToolStripMenuItem1.Size = new System.Drawing.Size(275, 22);
            this.выбратьToolStripMenuItem1.Text = "Выбрать";
            // 
            // сМинимальнойСтоимостьюРемонтаToolStripMenuItem
            // 
            this.сМинимальнойСтоимостьюРемонтаToolStripMenuItem.Image = global::Televisions.Properties.Resources.Cost;
            this.сМинимальнойСтоимостьюРемонтаToolStripMenuItem.Name = "сМинимальнойСтоимостьюРемонтаToolStripMenuItem";
            this.сМинимальнойСтоимостьюРемонтаToolStripMenuItem.Size = new System.Drawing.Size(293, 22);
            this.сМинимальнойСтоимостьюРемонтаToolStripMenuItem.Text = "с минимальной стоимостью ремонта";
            this.сМинимальнойСтоимостьюРемонтаToolStripMenuItem.Click += new System.EventHandler(this.SelectByMinCost_Command);
            // 
            // ремонтируемыеВыбраннымМастеромToolStripMenuItem
            // 
            this.ремонтируемыеВыбраннымМастеромToolStripMenuItem.Image = global::Televisions.Properties.Resources.Master;
            this.ремонтируемыеВыбраннымМастеромToolStripMenuItem.Name = "ремонтируемыеВыбраннымМастеромToolStripMenuItem";
            this.ремонтируемыеВыбраннымМастеромToolStripMenuItem.Size = new System.Drawing.Size(293, 22);
            this.ремонтируемыеВыбраннымМастеромToolStripMenuItem.Text = "ремонтируемые выбранным мастером";
            this.ремонтируемыеВыбраннымМастеромToolStripMenuItem.Click += new System.EventHandler(this.SelectByMaster_Command);
            // 
            // сЗаданнойДиагональюЭкранаToolStripMenuItem
            // 
            this.сЗаданнойДиагональюЭкранаToolStripMenuItem.Image = global::Televisions.Properties.Resources.Screen;
            this.сЗаданнойДиагональюЭкранаToolStripMenuItem.Name = "сЗаданнойДиагональюЭкранаToolStripMenuItem";
            this.сЗаданнойДиагональюЭкранаToolStripMenuItem.Size = new System.Drawing.Size(293, 22);
            this.сЗаданнойДиагональюЭкранаToolStripMenuItem.Text = "с заданной диагональю экрана";
            this.сЗаданнойДиагональюЭкранаToolStripMenuItem.Click += new System.EventHandler(this.SelectByScreen_Command);
            // 
            // телевизорыЗаданногоВладельцаToolStripMenuItem
            // 
            this.телевизорыЗаданногоВладельцаToolStripMenuItem.Image = global::Televisions.Properties.Resources.Owner;
            this.телевизорыЗаданногоВладельцаToolStripMenuItem.Name = "телевизорыЗаданногоВладельцаToolStripMenuItem";
            this.телевизорыЗаданногоВладельцаToolStripMenuItem.Size = new System.Drawing.Size(293, 22);
            this.телевизорыЗаданногоВладельцаToolStripMenuItem.Text = "телевизоры заданного владельца";
            this.телевизорыЗаданногоВладельцаToolStripMenuItem.Click += new System.EventHandler(this.SelectByOwner_Command);
            // 
            // выходToolStripMenuItem
            // 
            this.выходToolStripMenuItem.Image = global::Televisions.Properties.Resources.exit;
            this.выходToolStripMenuItem.Name = "выходToolStripMenuItem";
            this.выходToolStripMenuItem.Size = new System.Drawing.Size(275, 22);
            this.выходToolStripMenuItem.Text = "Выход";
            this.выходToolStripMenuItem.Click += new System.EventHandler(this.Exit_Command);
            // 
            // TsbGenerate
            // 
            this.TsbGenerate.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbGenerate.Image = global::Televisions.Properties.Resources.Create;
            this.TsbGenerate.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbGenerate.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbGenerate.Name = "TsbGenerate";
            this.TsbGenerate.Size = new System.Drawing.Size(34, 34);
            this.TsbGenerate.Text = "toolStripButton1";
            this.TsbGenerate.ToolTipText = "Начальное формирование данных ";
            this.TsbGenerate.Click += new System.EventHandler(this.Generate_Command);
            // 
            // TsbEditRepairShop
            // 
            this.TsbEditRepairShop.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbEditRepairShop.Image = global::Televisions.Properties.Resources.EditRepairShop;
            this.TsbEditRepairShop.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbEditRepairShop.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbEditRepairShop.Name = "TsbEditRepairShop";
            this.TsbEditRepairShop.Size = new System.Drawing.Size(34, 34);
            this.TsbEditRepairShop.Text = "toolStripButton1";
            this.TsbEditRepairShop.ToolTipText = "Редактировать данные мастерской";
            this.TsbEditRepairShop.Click += new System.EventHandler(this.EditRepairShop_Command);
            // 
            // TsbAddTelevision
            // 
            this.TsbAddTelevision.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbAddTelevision.Image = global::Televisions.Properties.Resources.Add;
            this.TsbAddTelevision.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbAddTelevision.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbAddTelevision.Name = "TsbAddTelevision";
            this.TsbAddTelevision.Size = new System.Drawing.Size(34, 34);
            this.TsbAddTelevision.Text = "toolStripButton1";
            this.TsbAddTelevision.ToolTipText = "Добавить телевизор";
            this.TsbAddTelevision.Click += new System.EventHandler(this.AddTelevision_Command);
            // 
            // TsbEdit
            // 
            this.TsbEdit.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbEdit.Image = global::Televisions.Properties.Resources.Edit;
            this.TsbEdit.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbEdit.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbEdit.Name = "TsbEdit";
            this.TsbEdit.Size = new System.Drawing.Size(34, 34);
            this.TsbEdit.Text = "toolStripButton1";
            this.TsbEdit.ToolTipText = "Редактировать выбранный телевизор ";
            this.TsbEdit.Click += new System.EventHandler(this.Edit_Command);
            // 
            // TsbRemove
            // 
            this.TsbRemove.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbRemove.Image = global::Televisions.Properties.Resources.remove;
            this.TsbRemove.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbRemove.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbRemove.Name = "TsbRemove";
            this.TsbRemove.Size = new System.Drawing.Size(34, 34);
            this.TsbRemove.Text = "toolStripButton1";
            this.TsbRemove.ToolTipText = "Выдать телевизор\r\n(удалить из коллекции)";
            this.TsbRemove.Click += new System.EventHandler(this.RemoveTelevision_Command);
            // 
            // TsbOrder
            // 
            this.TsbOrder.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbOrder.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniByBrand,
            this.MniByScreen,
            this.MniByMaster,
            this.MniByOwner,
            this.MniByPrice});
            this.TsbOrder.Image = global::Televisions.Properties.Resources.OrderBy;
            this.TsbOrder.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbOrder.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbOrder.Name = "TsbOrder";
            this.TsbOrder.Size = new System.Drawing.Size(46, 34);
            this.TsbOrder.Text = "toolStripSplitButton1";
            this.TsbOrder.ToolTipText = "Упорядочть коллекцию телевизоров";
            // 
            // MniByBrand
            // 
            this.MniByBrand.Image = global::Televisions.Properties.Resources.name;
            this.MniByBrand.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MniByBrand.Name = "MniByBrand";
            this.MniByBrand.Size = new System.Drawing.Size(357, 36);
            this.MniByBrand.Text = "По производителю и типу";
            this.MniByBrand.Click += new System.EventHandler(this.OrderByBrand_Command);
            // 
            // MniByScreen
            // 
            this.MniByScreen.Image = global::Televisions.Properties.Resources.Screen;
            this.MniByScreen.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MniByScreen.Name = "MniByScreen";
            this.MniByScreen.Size = new System.Drawing.Size(357, 36);
            this.MniByScreen.Text = "По убыванию диагонали экрана";
            this.MniByScreen.Click += new System.EventHandler(this.OrderByScreen_Command);
            // 
            // MniByMaster
            // 
            this.MniByMaster.Image = global::Televisions.Properties.Resources.Master;
            this.MniByMaster.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MniByMaster.Name = "MniByMaster";
            this.MniByMaster.Size = new System.Drawing.Size(357, 36);
            this.MniByMaster.Text = "По мастеру, выполняющему ремонт";
            this.MniByMaster.Click += new System.EventHandler(this.OrderByMaster_Command);
            // 
            // MniByOwner
            // 
            this.MniByOwner.Image = global::Televisions.Properties.Resources.Owner;
            this.MniByOwner.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MniByOwner.Name = "MniByOwner";
            this.MniByOwner.Size = new System.Drawing.Size(357, 36);
            this.MniByOwner.Text = "По владельцу телевизора";
            this.MniByOwner.Click += new System.EventHandler(this.OrderByOwner_Command);
            // 
            // MniByPrice
            // 
            this.MniByPrice.Image = global::Televisions.Properties.Resources.Cost;
            this.MniByPrice.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MniByPrice.Name = "MniByPrice";
            this.MniByPrice.Size = new System.Drawing.Size(357, 36);
            this.MniByPrice.Text = "По стоимость ремонта";
            this.MniByPrice.Click += new System.EventHandler(this.OrderByPrice_Command);
            // 
            // TsbSelect
            // 
            this.TsbSelect.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbSelect.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ByMinCost,
            this.ByMaster,
            this.ByScreen,
            this.ByOwner});
            this.TsbSelect.Image = global::Televisions.Properties.Resources.Select;
            this.TsbSelect.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbSelect.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbSelect.Name = "TsbSelect";
            this.TsbSelect.Size = new System.Drawing.Size(46, 34);
            this.TsbSelect.Text = "toolStripSplitButton1";
            this.TsbSelect.ToolTipText = "Выбрать телевизоры ";
            // 
            // ByMinCost
            // 
            this.ByMinCost.Image = global::Televisions.Properties.Resources.Cost;
            this.ByMinCost.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.ByMinCost.Name = "ByMinCost";
            this.ByMinCost.Size = new System.Drawing.Size(371, 36);
            this.ByMinCost.Text = "с минимальной стоимостью ремонта";
            this.ByMinCost.Click += new System.EventHandler(this.SelectByMinCost_Command);
            // 
            // ByMaster
            // 
            this.ByMaster.Image = global::Televisions.Properties.Resources.Master;
            this.ByMaster.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.ByMaster.Name = "ByMaster";
            this.ByMaster.Size = new System.Drawing.Size(371, 36);
            this.ByMaster.Text = "ремонтируемые выбранным мастером";
            this.ByMaster.Click += new System.EventHandler(this.SelectByMaster_Command);
            // 
            // ByScreen
            // 
            this.ByScreen.Image = global::Televisions.Properties.Resources.Screen;
            this.ByScreen.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.ByScreen.Name = "ByScreen";
            this.ByScreen.Size = new System.Drawing.Size(371, 36);
            this.ByScreen.Text = "с заданной диагональю экрана";
            this.ByScreen.Click += new System.EventHandler(this.SelectByScreen_Command);
            // 
            // ByOwner
            // 
            this.ByOwner.Image = global::Televisions.Properties.Resources.Owner;
            this.ByOwner.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.ByOwner.Name = "ByOwner";
            this.ByOwner.Size = new System.Drawing.Size(371, 36);
            this.ByOwner.Text = "заданного владельца";
            this.ByOwner.Click += new System.EventHandler(this.SelectByOwner_Command);
            // 
            // TsbExit
            // 
            this.TsbExit.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.TsbExit.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbExit.Image = global::Televisions.Properties.Resources.exit;
            this.TsbExit.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbExit.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbExit.Name = "TsbExit";
            this.TsbExit.Padding = new System.Windows.Forms.Padding(0, 0, 15, 0);
            this.TsbExit.Size = new System.Drawing.Size(49, 34);
            this.TsbExit.Text = "toolStripButton1";
            this.TsbExit.ToolTipText = "Выход";
            this.TsbExit.Click += new System.EventHandler(this.Exit_Command);
            // 
            // TsbToTray
            // 
            this.TsbToTray.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.TsbToTray.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbToTray.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TsbToTray.Image = global::Televisions.Properties.Resources.ToTray;
            this.TsbToTray.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbToTray.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbToTray.Name = "TsbToTray";
            this.TsbToTray.Size = new System.Drawing.Size(34, 34);
            this.TsbToTray.Text = "в трей";
            this.TsbToTray.ToolTipText = "Свернуть в трей";
            this.TsbToTray.Click += new System.EventHandler(this.ToTray_Command);
            // 
            // MniRepairShopNew
            // 
            this.MniRepairShopNew.Image = global::Televisions.Properties.Resources.Create;
            this.MniRepairShopNew.Name = "MniRepairShopNew";
            this.MniRepairShopNew.Size = new System.Drawing.Size(160, 26);
            this.MniRepairShopNew.Text = "Новая...";
            this.MniRepairShopNew.Click += new System.EventHandler(this.Generate_Command);
            // 
            // MniRepairShopEdit
            // 
            this.MniRepairShopEdit.Image = global::Televisions.Properties.Resources.EditRepairShop;
            this.MniRepairShopEdit.Name = "MniRepairShopEdit";
            this.MniRepairShopEdit.Size = new System.Drawing.Size(160, 26);
            this.MniRepairShopEdit.Text = "Изменить...";
            this.MniRepairShopEdit.Click += new System.EventHandler(this.EditRepairShop_Command);
            // 
            // MniTelevisionsAdd
            // 
            this.MniTelevisionsAdd.Image = global::Televisions.Properties.Resources.Add;
            this.MniTelevisionsAdd.Name = "MniTelevisionsAdd";
            this.MniTelevisionsAdd.Size = new System.Drawing.Size(219, 26);
            this.MniTelevisionsAdd.Text = "Принять в ремонт...";
            this.MniTelevisionsAdd.Click += new System.EventHandler(this.AddTelevision_Command);
            // 
            // MniTelevisionsEdit
            // 
            this.MniTelevisionsEdit.Image = global::Televisions.Properties.Resources.Edit;
            this.MniTelevisionsEdit.Name = "MniTelevisionsEdit";
            this.MniTelevisionsEdit.Size = new System.Drawing.Size(219, 26);
            this.MniTelevisionsEdit.Text = "Изменить...";
            this.MniTelevisionsEdit.Click += new System.EventHandler(this.Edit_Command);
            // 
            // MniTelevisionsRemoveAt
            // 
            this.MniTelevisionsRemoveAt.Image = global::Televisions.Properties.Resources.remove;
            this.MniTelevisionsRemoveAt.Name = "MniTelevisionsRemoveAt";
            this.MniTelevisionsRemoveAt.Size = new System.Drawing.Size(219, 26);
            this.MniTelevisionsRemoveAt.Text = "Выдать";
            this.MniTelevisionsRemoveAt.Click += new System.EventHandler(this.RemoveTelevision_Command);
            // 
            // MniOrderByBrand
            // 
            this.MniOrderByBrand.Image = global::Televisions.Properties.Resources.name;
            this.MniOrderByBrand.Name = "MniOrderByBrand";
            this.MniOrderByBrand.Size = new System.Drawing.Size(258, 26);
            this.MniOrderByBrand.Text = "По производителю";
            this.MniOrderByBrand.Click += new System.EventHandler(this.OrderByBrand_Command);
            // 
            // MniOrderByDiagonalDesc
            // 
            this.MniOrderByDiagonalDesc.Image = global::Televisions.Properties.Resources.Screen;
            this.MniOrderByDiagonalDesc.Name = "MniOrderByDiagonalDesc";
            this.MniOrderByDiagonalDesc.Size = new System.Drawing.Size(258, 26);
            this.MniOrderByDiagonalDesc.Text = "По убыванию диагонали";
            this.MniOrderByDiagonalDesc.Click += new System.EventHandler(this.OrderByScreen_Command);
            // 
            // MniOrderByArtisan
            // 
            this.MniOrderByArtisan.Image = global::Televisions.Properties.Resources.Master;
            this.MniOrderByArtisan.Name = "MniOrderByArtisan";
            this.MniOrderByArtisan.Size = new System.Drawing.Size(258, 26);
            this.MniOrderByArtisan.Text = "По мастеру";
            this.MniOrderByArtisan.Click += new System.EventHandler(this.OrderByMaster_Command);
            // 
            // MniOrderByOwner
            // 
            this.MniOrderByOwner.Image = global::Televisions.Properties.Resources.Owner;
            this.MniOrderByOwner.Name = "MniOrderByOwner";
            this.MniOrderByOwner.Size = new System.Drawing.Size(258, 26);
            this.MniOrderByOwner.Text = "По владельцу";
            this.MniOrderByOwner.Click += new System.EventHandler(this.OrderByOwner_Command);
            // 
            // MniOrderByPrice
            // 
            this.MniOrderByPrice.Image = global::Televisions.Properties.Resources.Cost;
            this.MniOrderByPrice.Name = "MniOrderByPrice";
            this.MniOrderByPrice.Size = new System.Drawing.Size(258, 26);
            this.MniOrderByPrice.Text = "По стоимость ремонта";
            this.MniOrderByPrice.Click += new System.EventHandler(this.OrderByPrice_Command);
            // 
            // MniSelectWhereInexpensive
            // 
            this.MniSelectWhereInexpensive.Image = global::Televisions.Properties.Resources.Cost;
            this.MniSelectWhereInexpensive.Name = "MniSelectWhereInexpensive";
            this.MniSelectWhereInexpensive.Size = new System.Drawing.Size(285, 26);
            this.MniSelectWhereInexpensive.Text = "Самые недорогие ремонты...";
            this.MniSelectWhereInexpensive.Click += new System.EventHandler(this.SelectByMinCost_Command);
            // 
            // MniSelectWhereArtisan
            // 
            this.MniSelectWhereArtisan.Image = global::Televisions.Properties.Resources.Master;
            this.MniSelectWhereArtisan.Name = "MniSelectWhereArtisan";
            this.MniSelectWhereArtisan.Size = new System.Drawing.Size(285, 26);
            this.MniSelectWhereArtisan.Text = "Ремонты мастера...";
            this.MniSelectWhereArtisan.Click += new System.EventHandler(this.SelectByMaster_Command);
            // 
            // MniSelectWhereDiagonal
            // 
            this.MniSelectWhereDiagonal.Image = global::Televisions.Properties.Resources.Screen;
            this.MniSelectWhereDiagonal.Name = "MniSelectWhereDiagonal";
            this.MniSelectWhereDiagonal.Size = new System.Drawing.Size(285, 26);
            this.MniSelectWhereDiagonal.Text = "Телевизоры с диагональю...";
            this.MniSelectWhereDiagonal.Click += new System.EventHandler(this.SelectByScreen_Command);
            // 
            // MniSelectWhereOwner
            // 
            this.MniSelectWhereOwner.Image = global::Televisions.Properties.Resources.Owner;
            this.MniSelectWhereOwner.Name = "MniSelectWhereOwner";
            this.MniSelectWhereOwner.Size = new System.Drawing.Size(285, 26);
            this.MniSelectWhereOwner.Text = "Телевизоры владельца...";
            this.MniSelectWhereOwner.Click += new System.EventHandler(this.SelectByOwner_Command);
            // 
            // свернутьВТрейToolStripMenuItem
            // 
            this.свернутьВТрейToolStripMenuItem.Image = global::Televisions.Properties.Resources.ToTray;
            this.свернутьВТрейToolStripMenuItem.Name = "свернутьВТрейToolStripMenuItem";
            this.свернутьВТрейToolStripMenuItem.Size = new System.Drawing.Size(162, 22);
            this.свернутьВТрейToolStripMenuItem.Text = "Свернуть в трей";
            this.свернутьВТрейToolStripMenuItem.Click += new System.EventHandler(this.ToTray_Command);
            // 
            // CmnTray
            // 
            this.CmnTray.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem9,
            this.toolStripMenuItem10,
            this.toolStripMenuItem7,
            this.toolStripMenuItem8});
            this.CmnTray.Name = "CmsLbxTelevisions";
            this.CmnTray.Size = new System.Drawing.Size(192, 76);
            // 
            // toolStripMenuItem7
            // 
            this.toolStripMenuItem7.Image = global::Televisions.Properties.Resources.exit;
            this.toolStripMenuItem7.Name = "toolStripMenuItem7";
            this.toolStripMenuItem7.Size = new System.Drawing.Size(191, 22);
            this.toolStripMenuItem7.Text = "Выход";
            this.toolStripMenuItem7.Click += new System.EventHandler(this.Exit_Command);
            // 
            // toolStripMenuItem8
            // 
            this.toolStripMenuItem8.Name = "toolStripMenuItem8";
            this.toolStripMenuItem8.Size = new System.Drawing.Size(191, 22);
            this.toolStripMenuItem8.Text = "О программе...";
            this.toolStripMenuItem8.Click += new System.EventHandler(this.About_Command);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Image = global::Televisions.Properties.Resources.ToTray;
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(291, 26);
            this.toolStripMenuItem2.Text = "Свернуть в трей";
            this.toolStripMenuItem2.Click += new System.EventHandler(this.ToTray_Command);
            // 
            // toolStripMenuItem9
            // 
            this.toolStripMenuItem9.Name = "toolStripMenuItem9";
            this.toolStripMenuItem9.Size = new System.Drawing.Size(191, 22);
            this.toolStripMenuItem9.Text = "Восстановить из трея";
            this.toolStripMenuItem9.Click += new System.EventHandler(this.FromTray_Command);
            // 
            // toolStripMenuItem10
            // 
            this.toolStripMenuItem10.Name = "toolStripMenuItem10";
            this.toolStripMenuItem10.Size = new System.Drawing.Size(188, 6);
            // 
            // MainForm
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.Gainsboro;
            this.ClientSize = new System.Drawing.Size(800, 504);
            this.ContextMenuStrip = this.CmnMain;
            this.Controls.Add(this.TbcMain);
            this.Controls.Add(this.TspMain);
            this.Controls.Add(this.MnsMain);
            this.Controls.Add(this.StsMain);
            this.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Задание на 25.11.2021";
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.CmsLbxTelevisions.ResumeLayout(false);
            this.StsMain.ResumeLayout(false);
            this.StsMain.PerformLayout();
            this.PnlMain.ResumeLayout(false);
            this.PnlMain.PerformLayout();
            this.CmnMain.ResumeLayout(false);
            this.MnsMain.ResumeLayout(false);
            this.MnsMain.PerformLayout();
            this.TspMain.ResumeLayout(false);
            this.TspMain.PerformLayout();
            this.TbcMain.ResumeLayout(false);
            this.TbpName.ResumeLayout(false);
            this.TbpOrder.ResumeLayout(false);
            this.PnlOrder.ResumeLayout(false);
            this.TbpSelect.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.CmnTray.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.StatusStrip StsMain;
        private System.Windows.Forms.ToolStripStatusLabel LblStatus;
        private System.Windows.Forms.Label LblName;
        private System.Windows.Forms.Label LblAddress;
        private System.Windows.Forms.Panel PnlMain;
        private System.Windows.Forms.ContextMenuStrip CmsLbxTelevisions;
        private System.Windows.Forms.ToolStripMenuItem новаяКоллекцияToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem сортировкаToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem поПроизводителюИТипуToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem поУбываниюДиагоналиЭкранаToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem поМастеруВыполняющемуРемонтToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem поВладельцуТелевизораToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem добавитьТелевизорToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem редактироватьТелевизорToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem выбратьToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem сМинимальнойСтоимостьюРемонтаToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem3;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem4;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem5;
        private System.Windows.Forms.ToolStripMenuItem ремонтируемыеВыбраннымМастеромToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem сЗаданнойДиагональюЭкранаToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem6;
        private System.Windows.Forms.ToolStripMenuItem выходToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem оПрограммеToolStripMenuItem1;
        private System.Windows.Forms.ContextMenuStrip CmnMain;
        private System.Windows.Forms.ToolStripMenuItem CmsMain;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem20;
        private System.Windows.Forms.ToolStripMenuItem редактироватьДанныеМастерскойToolStripMenuItem1;
        private System.Windows.Forms.MenuStrip MnsMain;
        private System.Windows.Forms.ToolStripMenuItem MniFile;
        private System.Windows.Forms.ToolStripMenuItem MniFileExit;
        private System.Windows.Forms.ToolStripMenuItem MniRepairShop;
        private System.Windows.Forms.ToolStripMenuItem MniRepairShopNew;
        private System.Windows.Forms.ToolStripMenuItem MniRepairShopEdit;
        private System.Windows.Forms.ToolStripMenuItem MniTelevisions;
        private System.Windows.Forms.ToolStripMenuItem MniTelevisionsAdd;
        private System.Windows.Forms.ToolStripMenuItem MniTelevisionsEdit;
        private System.Windows.Forms.ToolStripSeparator MniTelevisionsSep1;
        private System.Windows.Forms.ToolStripMenuItem MniTelevisionsRemoveAt;
        private System.Windows.Forms.ToolStripMenuItem MniOrderBy;
        private System.Windows.Forms.ToolStripMenuItem MniOrderByBrand;
        private System.Windows.Forms.ToolStripMenuItem MniOrderByDiagonalDesc;
        private System.Windows.Forms.ToolStripMenuItem MniOrderByArtisan;
        private System.Windows.Forms.ToolStripMenuItem MniOrderByOwner;
        private System.Windows.Forms.ToolStripMenuItem MniSelectWhere;
        private System.Windows.Forms.ToolStripMenuItem MniSelectWhereInexpensive;
        private System.Windows.Forms.ToolStripMenuItem MniSelectWhereArtisan;
        private System.Windows.Forms.ToolStripMenuItem MniSelectWhereDiagonal;
        private System.Windows.Forms.ToolStripMenuItem MniHelp;
        private System.Windows.Forms.ToolStripMenuItem MniHelpAbout;
        private System.Windows.Forms.ToolStrip TspMain;
        private System.Windows.Forms.ToolStripButton TsbGenerate;
        private System.Windows.Forms.ToolStripButton TsbEditRepairShop;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripSplitButton TsbOrder;
        private System.Windows.Forms.ToolStripMenuItem MniByBrand;
        private System.Windows.Forms.ToolStripMenuItem MniByScreen;
        private System.Windows.Forms.ToolStripMenuItem MniByMaster;
        private System.Windows.Forms.ToolStripMenuItem MniByOwner;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripButton TsbAddTelevision;
        private System.Windows.Forms.ToolStripButton TsbEdit;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripSplitButton TsbSelect;
        private System.Windows.Forms.ToolStripMenuItem ByMinCost;
        private System.Windows.Forms.ToolStripMenuItem ByMaster;
        private System.Windows.Forms.ToolStripMenuItem ByScreen;
        private System.Windows.Forms.ToolStripMenuItem ByOwner;
        private System.Windows.Forms.ToolStripMenuItem MniOrderByPrice;
        private System.Windows.Forms.ToolStripMenuItem MniSelectWhereOwner;
        private System.Windows.Forms.ToolStripMenuItem MniByPrice;
        private System.Windows.Forms.ToolStripButton TsbRemove;
        private System.Windows.Forms.ToolStripButton TsbExit;
        private System.Windows.Forms.ToolStripMenuItem MniFileOpen;
        private System.Windows.Forms.ToolStripMenuItem MniFileSave;
        private System.Windows.Forms.ToolStripMenuItem MniFileSaveAs;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem1;
        private System.Windows.Forms.OpenFileDialog OfdMain;
        private System.Windows.Forms.SaveFileDialog SfdMain;
        private System.Windows.Forms.ColorDialog CdlBackColor;
        private System.Windows.Forms.FontDialog FdlTextFont;
        private System.Windows.Forms.ToolStripMenuItem MniService;
        private System.Windows.Forms.ToolStripMenuItem MniServiceFont;
        private System.Windows.Forms.ToolStripMenuItem MniServiceBackColor;
        private System.Windows.Forms.ToolStripMenuItem удалитьТелевизорToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem поСтоимостиРемонтаToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem телевизорыЗаданногоВладельцаToolStripMenuItem;
        private System.Windows.Forms.TabControl TbcMain;
        private System.Windows.Forms.TabPage TbpName;
        private System.Windows.Forms.TabPage TbpOrder;
        private System.Windows.Forms.ListBox LbxTelevisions;
        private System.Windows.Forms.Label LblTelevision;
        private System.Windows.Forms.ListBox LbxOrder;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel PnlOrder;
        private System.Windows.Forms.Label LblOrder;
        private System.Windows.Forms.TabPage TbpSelect;
        private System.Windows.Forms.ListBox LbxSelect;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label LblSelect;
        private System.Windows.Forms.Label LblSelect2;
        private System.Windows.Forms.ToolStripButton TsbToTray;
        private System.Windows.Forms.NotifyIcon NtiMain;
        private System.Windows.Forms.ToolStripMenuItem свернутьВТрейToolStripMenuItem;
        private System.Windows.Forms.ContextMenuStrip CmnTray;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem7;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem8;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem9;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem10;
    }
}

