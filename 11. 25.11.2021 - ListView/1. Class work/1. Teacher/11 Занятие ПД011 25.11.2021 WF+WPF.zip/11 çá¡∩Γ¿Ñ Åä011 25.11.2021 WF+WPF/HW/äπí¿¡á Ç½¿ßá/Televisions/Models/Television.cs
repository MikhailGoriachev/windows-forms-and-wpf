﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using Televisions.Helpers;


namespace Televisions.Models
{
    // Класс, описывающий телевизор содержит: производитель и тип телевизора,
    //                                        диагональ экрана,
    //                                        строка с описанием дефекта,
    //                                        фамилия и инициалами мастера,
    //                                        фамилия и инициалы владельца,
    //                                        стоимость ремонта
    [DataContract]  // для JSON
    public class Television {
        // производитель и тип телевизора
        private string _brand;
        [DataMember]
        public string Brand {
            get => _brand;
            set {
                if (string.IsNullOrEmpty(value))
                    throw new Exception("Пустая строка в производителе и типе телевизора");

                _brand = value;
            } // set
        } // Brand

        // диагональ экрана (дюймы)
        private double _diagonal;  
        [DataMember]
        public double Diagonal {
            get => _diagonal;
            set {
                if (value <= 0)
                    throw new Exception("Некорректное значение диагонали экрана!");

                _diagonal = value;
            } // set
        } // Diagonal

        // строка с описанием дефекта
        private string _defect;
        [DataMember]
        public string Defect {
            get => _defect;
            set {
                if (string.IsNullOrEmpty(value))
                    throw new Exception("Пустая строка в строкe с описанием дефектателевизора");

                _defect = value;
            } // set
        } // Brand

        // фамилия и инициалами мастера
        private string _artisan;
        [DataMember]
        public string Artisan {
            get => _artisan;
            set {
                if (string.IsNullOrEmpty(value))
                    throw new Exception("Пустая строка в фамилии и инициалах мастера");

                _artisan = value;
            } // set
        } // Artisan

        // фамилия и инициалы владельца
        private string _owner;
        [DataMember]
        public string Owner {
            get => _owner;
            set {
                if (string.IsNullOrEmpty(value))
                    throw new Exception("Пустая строка в фамилии и инициалах владельца");

                _owner = value;
            } // set
        } // Owner

        // стоимость ремонта
        private int _price;
        [DataMember]
        public int Price {
            get => _price;
            set {
                if (value <= 0)
                    throw new Exception("Некорректное значение стоимости ремонта!");

                _price = value;
            } // set
        } // Price

        // строковое представление объекта
        public override string ToString() =>
            $"{_brand}: {_diagonal}\", '{_defect}', " +
            $"владелец {_owner}, мастер {_artisan}, стоимость {_price} руб.";

        // формирование строки таблицы, свойство
        public string TableRow =>
            $" {_brand,-22} │ {_diagonal,6:n1}       │ {_defect,-26} │ " +
            $"{_owner,-18} │ {_artisan,-18} │ {_price,11:n2}";


        // Шапка таблицы, статическое свойство
        public static string Header =>
            $"  Производитель, модель   Диагональ, \"    Описание дефекта              Владелец              Мастер          Цена, руб. ";


        // Фабричный метод для создания телевизора из случайных данных
        public static Television Generate() {
            // индексы из массивов данных для создания телевизора
            int indexBrand = Utils.GetRandom(0, Utils.Brands.Length - 1);
            int indexDiagonal = Utils.GetRandom(0, Utils.Diagonals.Length - 1);
            int indexArtisan = Utils.GetRandom(0, Utils.FullNames.Length - 1);
            int indexOwner = Utils.GetRandomExclude(0, Utils.FullNames.Length - 1, indexArtisan);
            int indexDefect = Utils.GetRandom(0, Utils.DefectDescriptions.Length - 1);

            // создание объекта из массивов шаблонных данных, валидация при создании не нужна
            return new Television {
                _brand = Utils.Brands[indexBrand],
                _diagonal = Utils.Diagonals[indexDiagonal],
                _defect = Utils.DefectDescriptions[indexDefect].Desc,
                _artisan = Utils.FullNames[indexArtisan],
                _owner = Utils.FullNames[indexOwner],
                _price = Utils.DefectDescriptions[indexDefect].Price
            };
        } // Generate

    } // Television
}
