﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HomeWork25._11._211.Views
{
    public partial class SelectOwner : Form
    {

        private string _ownerName;
        public string OwnerName
        {
            get { return _ownerName; }
            set { _ownerName = value; }
        }


        public SelectOwner(List<string> owners)
        {
            InitializeComponent();
            // привязка к коллекции, выбор первого в списке владельца
            Cbx_Owners.DataSource = owners;
            Cbx_Owners.SelectedItem = 0;
        }

        private void Choise_Owner_select(object sender, EventArgs e)
        {
            _ownerName = Cbx_Owners.SelectedItem.ToString();
        }


    }
}
