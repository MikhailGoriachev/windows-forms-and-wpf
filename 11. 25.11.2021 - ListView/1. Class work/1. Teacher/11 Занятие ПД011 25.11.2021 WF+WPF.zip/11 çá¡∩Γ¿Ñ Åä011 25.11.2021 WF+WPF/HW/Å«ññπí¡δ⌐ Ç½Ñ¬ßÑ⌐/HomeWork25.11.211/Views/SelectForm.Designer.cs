﻿
namespace HomeWork25._11._211.Views
{
    partial class SelectForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SelectForm));
            this.Lbl_header = new System.Windows.Forms.Label();
            this.Lbx_main = new System.Windows.Forms.ListBox();
            this.btn_close = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Lbl_header
            // 
            this.Lbl_header.Location = new System.Drawing.Point(14, 51);
            this.Lbl_header.Name = "Lbl_header";
            this.Lbl_header.Size = new System.Drawing.Size(1303, 31);
            this.Lbl_header.TabIndex = 9;
            this.Lbl_header.Text = resources.GetString("Lbl_header.Text");
            // 
            // Lbx_main
            // 
            this.Lbx_main.Font = new System.Drawing.Font("Consolas", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Lbx_main.FormattingEnabled = true;
            this.Lbx_main.ItemHeight = 15;
            this.Lbx_main.Location = new System.Drawing.Point(14, 85);
            this.Lbx_main.Name = "Lbx_main";
            this.Lbx_main.Size = new System.Drawing.Size(1302, 289);
            this.Lbx_main.TabIndex = 8;
            // 
            // btn_close
            // 
            this.btn_close.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btn_close.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btn_close.Location = new System.Drawing.Point(1087, 408);
            this.btn_close.Name = "btn_close";
            this.btn_close.Size = new System.Drawing.Size(189, 41);
            this.btn_close.TabIndex = 10;
            this.btn_close.Text = "Закрыть";
            this.btn_close.UseVisualStyleBackColor = true;
            // 
            // SelectForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1333, 461);
            this.Controls.Add(this.btn_close);
            this.Controls.Add(this.Lbl_header);
            this.Controls.Add(this.Lbx_main);
            this.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "SelectForm";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "SelectForm";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label Lbl_header;
        private System.Windows.Forms.ListBox Lbx_main;
        private System.Windows.Forms.Button btn_close;
    }
}