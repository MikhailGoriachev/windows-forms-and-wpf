﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HomeWork25._11._211.Views
{
    public partial class AboutProgramm : Form
    {
        public AboutProgramm()
        {
            InitializeComponent();
            // снять выделение текста
            txb_aboutprogram.SelectionStart = 0;
            txb_aboutprogram.SelectionLength = 0;
        }
    }
}
