﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HomeWork25._11._211.Views
{
    public partial class EditDefaultFileName : Form
    {
        private string _newDefaultFileName;

        public string NewDefaultFileName
        {
            get { return _newDefaultFileName; }
            set { _newDefaultFileName = value; }
        }

        public EditDefaultFileName()
        {
            InitializeComponent();
        }

        private void Edit_filename_command(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(Txb_fileName.Text)) return;
            _newDefaultFileName = Txb_fileName.Text;
        }
    }
}
