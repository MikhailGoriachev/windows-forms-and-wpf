﻿using HomeWork25._11._211.Controllers;
using HomeWork25._11._211.Models;
using HomeWork25._11._211.Views;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace HomeWork25._11._211
{
    public partial class MainForm : Form
    {
        // класс для телемастерской
        //private RepairShop RepairShop = new RepairShop() { RepairShopName = "Электрон", RepairShopAddress="ул.Артема д.12" };

        //public RepairShop GetRepairShop { get; private set; }

        private RepairShop _repairShop;

        public RepairShop RepairShop
        {
            get { return _repairShop; }
            set { _repairShop = value; }
        }

        private string serialiseDefaultName = "Автосохранение.json";
        private string serialiseDefaultPath = "C:\\RepairShop\\";

        public MainForm()
        {
            InitializeComponent();
            _repairShop = new RepairShop() { RepairShopName = "Электрон", RepairShopAddress = "ул.Артема д.12" };
            Text = "Ремонт телевизоров " + RepairShop.RepairShopName;
            RepairShop.CreateTVList();
            RepairShopBind();
            
            Lbt_statusBar_address.Text = RepairShop.RepairShopAddress;

            Sfd_main.InitialDirectory = serialiseDefaultPath;
            stb_lbl_folder_path.Text = serialiseDefaultPath;
            stb_lbl_default_name.Text = serialiseDefaultName;
            Sfd_main.RestoreDirectory = false;
            // назначить обработчик события выбора элемента в ListBox
            Tbp_listView.SelectedIndexChanged += Lbx_main_SelectedIndexChanged;
            Tcb_main.TabPages[0].Text = "Телевизоры в ремонте";

        }

        private void Lbx_main_SelectedIndexChanged(object sender, EventArgs e)
        {
            // возращаем выбраный элемент из коллекции
            //Television tv = (Television)Tbp_listView.SelectedItems;
        }

        // Выполнение привязки к данным для Листбокса         
        private void RepairShopBind()
        {
            Tbp_listView.Items.Clear();// = null;             // остановить текущую привязку
            for (int i = 0; i < RepairShop.TeleList.Count; i++)
            {
                ListViewItem newItem = new ListViewItem(RepairShop.TeleList[i].Type);
                newItem.SubItems.Add(RepairShop.TeleList[i].Diagonal.ToString());
                newItem.SubItems.Add(RepairShop.TeleList[i].Defect);
                newItem.SubItems.Add(RepairShop.TeleList[i].RepairerName);
                newItem.SubItems.Add(RepairShop.TeleList[i].OwnerName);
                newItem.SubItems.Add(RepairShop.TeleList[i].RepairCost.ToString());
                Tbp_listView.Items.Add(newItem);
            }

            Lbl_status_bar.Text = "Количество телвизоров в ремноте: " + RepairShop.Count().ToString();
            Lbl_main_aboutCompany.Text = $"Название компании : {RepairShop.RepairShopName}, адрес компании : {RepairShop.RepairShopAddress}";

        } // 

        private void ListViewSelectedBind(RepairShop rp)
        {
            Tbp_listView_Selected.Items.Clear();// = null;             // остановить текущую привязку
            for (int i = 0; i < rp.TeleList.Count; i++)
            {
                ListViewItem newItem = new ListViewItem(rp.TeleList[i].Type);
                newItem.SubItems.Add(rp.TeleList[i].Diagonal.ToString());
                newItem.SubItems.Add(rp.TeleList[i].Defect);
                newItem.SubItems.Add(rp.TeleList[i].RepairerName);
                newItem.SubItems.Add(rp.TeleList[i].OwnerName);
                newItem.SubItems.Add(rp.TeleList[i].RepairCost.ToString());
                Tbp_listView_Selected.Items.Add(newItem);
            }


        } // 

        // Выполнение привязки к данным для статусбара         
        private void DefaultPathNameBind()
        {
            stb_lbl_folder_path.Text = serialiseDefaultPath;
            stb_lbl_default_name.Text = serialiseDefaultName;

        } // 

        // сохранение и проверка директории
        private void CheckAndSerialize()
        {
            DirectoryInfo dirInfo = new DirectoryInfo(serialiseDefaultPath);
            if (!dirInfo.Exists)
            {
                dirInfo.Create();
            }
            _repairShop.Serialize(serialiseDefaultPath + "\\" + serialiseDefaultName);


        } // 


        private void добавитьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            TVForm tvform = new TVForm();
            DialogResult dialogResult = tvform.ShowDialog();

            // если окно закрыто не по кнопке "Добавить" - молча уходим
            if (dialogResult != DialogResult.OK) return;

            // получить данные из свойства формы
            Television tv = tvform.Television;
            RepairShop.Add(tv);

            // обновить привязку
            RepairShopBind();

            // сохранение
            CheckAndSerialize();


        }

        private void измениитьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // если нет выбранного работника - уходим
            if (Tbp_listView.SelectedItems.Count < 0)
                return;

            // передача данных в форму
            TVForm tvform = new TVForm("Редактировать данные телевизора", "Сохранить");
            //tvform.Television = (Television)Tbp_listView.SelectedItems;

            if (tvform.ShowDialog() != DialogResult.OK) return;

            // получить данные
            //epairShop.TeleList[Lbx_main.SelectedIndex] = tvform.Television;

            // обновить привязку
            RepairShopBind();

            // сохранение
            CheckAndSerialize();
        }

        private void редактироватьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AboutCompanyForm compForm = new AboutCompanyForm();
            compForm.RepairShop = RepairShop;

            if (compForm.ShowDialog() != DialogResult.OK) return;

            RepairShop.RepairShopName = compForm.RepairShop.RepairShopName;
            RepairShop.RepairShopAddress = compForm.RepairShop.RepairShopAddress;
            Text = "Ремонт телевизоров " + RepairShop.RepairShopName;
            Lbt_statusBar_address.Text = RepairShop.RepairShopAddress;

            Lbl_status_bar.Text = "Количество телвизоров в ремноте: " + RepairShop.Count().ToString();
            Lbl_main_aboutCompany.Text = $"Название компании : {RepairShop.RepairShopName}, адрес компании : {RepairShop.RepairShopAddress}";

            // сохранение
            CheckAndSerialize();
        }

        private void oПоПроизводителюИТипуToolStripMenuItem_Click(object sender, EventArgs e)
        {
            RepairShop.SortByType();
            RepairShopBind();

        }

        private void поУбываниюДиагоналиЭкранаToolStripMenuItem_Click(object sender, EventArgs e)
        {
            RepairShop.SortByDiagonal();
            RepairShopBind();

        }

        private void поМастеруВыполняющемуРемонтToolStripMenuItem_Click(object sender, EventArgs e)
        {
            RepairShop.SortByRepairName();
            RepairShopBind();

        }

        private void поВладельцуТелевизораToolStripMenuItem_Click(object sender, EventArgs e)
        {
            RepairShop.SortByOwnerName();
            RepairShopBind();

        }

        private void поСтоимостиРемонтаToolStripMenuItem_Click(object sender, EventArgs e)
        {
            RepairShop.SortByPriceRepair();
            RepairShopBind();

        }

        // пересобрать коллекцию телевизоров
        private void пересобратьКоллекциюДанныхToolStripMenuItem_Click(object sender, EventArgs e)
        {
            RepairShop.CreateTVList();
            RepairShopBind();
        }

        // вызов о программе
        private void оПрограммеToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AboutProgramm aboutprg = new AboutProgramm();
            aboutprg.ShowDialog();  // модальное отображение формы
        }

        // комманда удалить
        private void удалитьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Tbp_listView.SelectedIndices.Count == 0)
                return;

           
            // удаление записи данных 
            for (int j = 0, i = Tbp_listView.SelectedIndices[j] ; j < Tbp_listView.SelectedIndices.Count;  j++)
            {
                RepairShop.TeleList.RemoveAt(i);
                i = Tbp_listView.SelectedIndices[j];
            }

           // RepairShop.TeleList.RemoveRange((Television)Tbp_listView.SelectedIndices());
            RepairShopBind();

            // сохранение
            CheckAndSerialize();

        }

        // выход
        private void Exit_Command(object sender, EventArgs e) =>
           Application.Exit();

        // очистить данные списка телевизоров
        private void Clear_Command(object sender, EventArgs e)
        {
            _repairShop.Clear();
            // обновить привязку
            RepairShopBind();
        }

        //•	Выборка и вывод в отдельной форме коллекции телевизоров с минимальной стоимостью ремонта
        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            RepairShop NewList = new RepairShop();
            NewList.TeleList = _repairShop.SelectMinRepairCost();
            Lbl_Selected.Text = toolStripButton1.Text;

            ListViewSelectedBind(NewList);
            Tcb_main.SelectedTab = Tcb_main.TabPages[1];

        }

        //•	Выборка и вывод в отдельной форме коллекции телевизоров, ремонтируемых выбранным мастером
        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            // непосредственно выбор мастера
            SelectChoiseSearch choiseSearch = new SelectChoiseSearch(toolStripButton2.Text, "default");
            DialogResult dialogResultSearch = choiseSearch.ShowDialog();

            if (choiseSearch.ShowDialog() != DialogResult.OK) return;

            RepairShop NewList = new RepairShop();
            NewList.TeleList = _repairShop.SelectRepairName(choiseSearch.Choice.repairName);

            Lbl_Selected.Text = toolStripButton2.Text;

            ListViewSelectedBind(NewList);
            Tcb_main.SelectedTab = Tcb_main.TabPages[1];


        }

        //•	Выборка и вывод в отдельной форме коллекции телевизоров, с заданной диагональю экрана 
        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            // значение диагонали
            SelectChoiseSearch choiseSearch = new SelectChoiseSearch(toolStripButton3.Text, 1);
            DialogResult dialogResultSearch = choiseSearch.ShowDialog();

            if (choiseSearch.DialogResult != DialogResult.OK) return;

            RepairShop NewList = new RepairShop();
            NewList.TeleList = _repairShop.SelectDiagonal(choiseSearch.Choice.diagonal);
            Lbl_Selected.Text = toolStripButton3.Text;

            ListViewSelectedBind(NewList);
            Tcb_main.SelectedTab = Tcb_main.TabPages[1];

        }

        // Выборка и вывод в отдельной форме коллекции телевизоров, заданного владельцв
        private void toolStripButton4_Click(object sender, EventArgs e)
        {
            // значение имени владельца
            SelectOwner choiseSearch = new SelectOwner(Television.ownerNames);
            DialogResult dialogResultSearch = choiseSearch.ShowDialog();

            if (choiseSearch.DialogResult != DialogResult.OK) return;

            RepairShop NewList = new RepairShop();
            NewList.TeleList = _repairShop.SelectOwner(choiseSearch.OwnerName);
            Lbl_Selected.Text = toolStripButton3.Text;

            ListViewSelectedBind(NewList);
            Tcb_main.SelectedTab = Tcb_main.TabPages[1];


        }

        // изменение цвета фона
        private void Edit_color_background_Command(object sender, EventArgs e)
        {

            if (Cfd_main.ShowDialog() == DialogResult.OK)
            {
                Tbp_listView.BackColor = Cfd_main.Color;
            }

            // обновить привязку
            RepairShopBind();
        }

        // изменение цвета шрифта
        private void Edit_color_font_Command(object sender, EventArgs e)
        {

            if (Cdf_main_Font_Color.ShowDialog() == DialogResult.OK)
            {
                Tbp_listView.ForeColor = Cfd_main.Color;
            }

            // обновить привязку
            RepairShopBind();
        }

        // изменение шрифта
        private void Edit_font_Command(object sender, EventArgs e)
        {

            Ffd_main.ShowColor = true;
            if (Ffd_main.ShowDialog() == DialogResult.OK)
            {
                Tbp_listView.Font = Ffd_main.Font;


            }

            // обновить привязку
            RepairShopBind();
        }

        // сериализация в формате JSON
        private void Save_command(object sender, EventArgs e)
        {
            // вызов диалога сохранения файла

            Sfd_main.Title = "Сохранение результатов";
            Sfd_main.InitialDirectory = "..\\..\\";
            Sfd_main.Filter = "Файлы JSON(*.json)|*.json";
            Sfd_main.FilterIndex = 1;

            if (Sfd_main.ShowDialog() == DialogResult.OK)
            {
                _repairShop.Serialize(Sfd_main.FileName);
                stb_lbl_folder_path.Text = "Путь для сохранения: ";
                stb_lbl_folder_path.Text += Sfd_main.FileName;
            } // if

            // обновить привязку
            RepairShopBind();
        }

        // десериализация из формата JSON
        private void Open_command(object sender, EventArgs e)
        {
            // вызов диалога сохранения файла

            Ofd_main.Title = "Открыть ";
            Ofd_main.InitialDirectory = "../../";
            Ofd_main.Filter = "Файлы JSON(*.json)|*.json";
            Ofd_main.FilterIndex = 1;

            _repairShop.Clear();
            if (Ofd_main.ShowDialog() == DialogResult.OK)
            {
                _repairShop = RepairShop.Deserialize(Ofd_main.FileName);
            } // if

            // обновить привязку
            RepairShopBind();

        }

        // дериктория для дефолтной записи
        private void Chahge_default_folder_command(object sender, EventArgs e)
        {
            Fbd_main.Description = "Выберите папку для автосохранения";

            if (Fbd_main.ShowDialog() == DialogResult.OK)
            {

                serialiseDefaultPath = Fbd_main.SelectedPath;
                // обновить привязку
                DefaultPathNameBind();

            }

        }

        // изменения имени файла для автосохранения
        private void Edit_fileName_command(object sender, EventArgs e)
        {
            EditDefaultFileName editForm = new EditDefaultFileName();
            DialogResult dialogResult = editForm.ShowDialog();

            // если окно закрыто не по кнопке "Добавить" - молча уходим
            if (dialogResult != DialogResult.OK) return;

            // получить данные из свойства формы
            serialiseDefaultName = editForm.NewDefaultFileName;
            serialiseDefaultName += ".json";
            // обновить привязку
            DefaultPathNameBind();
        }

        // свернуть в трей
        private void ToTray_Command(object sender, EventArgs e)
        {
            this.Hide();
            Nti_main.Visible = true;
        }


        // восстановить из трея
        private void FromTray_Command(object sender, EventArgs e)
        {
            this.Show();
            WindowState = FormWindowState.Normal;
            Nti_main.Visible = false;
        }

        private void Fbd_main_HelpRequest(object sender, EventArgs e)
        {

        }
    }
}
