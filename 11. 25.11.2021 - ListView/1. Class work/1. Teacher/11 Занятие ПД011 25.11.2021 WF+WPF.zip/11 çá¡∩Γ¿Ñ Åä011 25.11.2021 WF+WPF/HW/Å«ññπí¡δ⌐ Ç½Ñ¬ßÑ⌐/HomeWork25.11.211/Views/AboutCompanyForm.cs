﻿using HomeWork25._11._211.Controllers;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HomeWork25._11._211.Views
{
    public partial class AboutCompanyForm : Form
    {


        private RepairShop _repairShop;

        public RepairShop RepairShop
        {
            get { return _repairShop; }
            set
            {
                _repairShop = value;
                Txb_nameComp.Text = _repairShop.RepairShopName;
                Txb_addressComp.Text = _repairShop.RepairShopAddress;

            }
        }

        public AboutCompanyForm()
        {
            InitializeComponent();
            _repairShop = new RepairShop();

        }

        private void Btn_save_Click(object sender, EventArgs e)
        {
            try
            {
                _repairShop.RepairShopName = Txb_nameComp.Text;
                _repairShop.RepairShopAddress = Txb_addressComp.Text;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
