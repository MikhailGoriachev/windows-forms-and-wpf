﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using WF_RepairShop.Utilities;

namespace WF_RepairShop.Models
{
    /*
     * •	Начальное формирование данных ремонтной мастерской (коллекция телевизоров от 12 до 15 штук)
       •	Добавление телевизора в коллекцию
       •	Редактирование выбранного телевизора в отдельной форме
       •	Редактирование данных ремонтной мастерской
       •	Упорядочивание коллекции телевизоров
             o По производителю и типу
             o По убыванию диагонали экрана
             o По мастеру, выполняющему ремонт
             o По владельцу телевизора
       •	Выборка и вывод в отдельной форме коллекции телевизоров с минимальной стоимостью ремонта
       •	Выборка и вывод в отдельной форме коллекции телевизоров, ремонтируемых выбранным мастером
       •	Выборка и вывод в отдельной форме коллекции телевизоров, с заданной диагональю экрана 

     */

    [DataContract]
    //Мастерская
    public class RepairShop
    {

        //Название ремонтной мастерской
        [DataMember]
        string _name;

        public string Name
        {

            get => _name;
            set
            {
                if (string.IsNullOrEmpty(value))
                    throw new Exception("Строка не может быть пустой!");
                _name = value;
            }

        }

        //Адрес мастерской

        [DataMember]
        string _adress;

        public string Adress
        {

            get => _adress;
            set
            {
                if (string.IsNullOrEmpty(value))
                    throw new Exception("Строка не может быть пустой!");
                _adress = value;
            }

        }

        [DataMember]
        //Телевизоры
        List<Television> _televisions;
        //Свойство
        public List<Television> Televisions { get => _televisions; }

        static public int n = Utils.Random.Next(12, 15);

        

        public RepairShop(): this(new List<Television>(),"Global service", "Будённовский просп.,19")
        {
            //Заполнение списка в диапазоне 12-15 элементов
            Generate(Utils.Random.Next(12,15));
        }//RepairShop. Default C_TOR

        //Счётчик элементов коллекции
        public int Amount => _televisions.Count;

        //Индексатор для чтения. Решил сделать именно индексатор, поскольку в любом случае для редактирования
        //нужно обращаться по индексу элемента
        public Television this [int index]
        {
            get
            {
                if (index >= 0 && index < _televisions.Count)
                    return _televisions[index];
                throw new Exception("Выход за пределы списка. Вернули последний элемент!");
            }
        }

        public RepairShop(List<Television> televisions,string name,string adress)
        {
            _televisions = televisions;
            Adress = adress;
            Name = name;
        }//RepairShop. Custom C_TOR

        public void Generate(int n)
        {
            _televisions.Clear();

            for (int i = 0; i < n; i++)
                _televisions.Add(Television.Generate());
        } // Generate


        //Добавление телевизора в коллекцию 
        public void AddToList(Television tv)
        {
            _televisions.Add(tv);
        }

        //Добавление коллекции телевизоров 
        public void AddCollectionToList(int count = 8)
        {
            //List<Television> temp = new List<Television>();
            Television[] televisions = new Television[count];

            //Создание коллекции 
            for (int i = 0; i < count; i++)
                televisions[i] = Television.Generate();
            //temp.Add(Television.Generate());

            //Добавление инициализированного массива в список 
            _televisions.AddRange(televisions);

        }

        //Вывод в строку 
        public string ShowCollection()
        {
            StringBuilder strBuilder = new StringBuilder();
            foreach(Television tv in _televisions)
            {
                strBuilder.Append(tv.ToTableRow);
                strBuilder.Append("\r\n");
            }

            return strBuilder.ToString();

        }

        #region Поиск минимального и максимального значения стоимости 

        //Максимальное число
        public double MaxPrice()
        {
            double maxPrice = _televisions[0].Price;
            foreach (Television elem in _televisions)
            {
                maxPrice = elem.Price - maxPrice >= 1e-3 ? elem.Price : maxPrice;
            }

            return maxPrice;
          
        }

        //Минимальное число 
        public double MinPrice()
        {
            double minPrice = _televisions[0].Price;
            foreach (Television elem in _televisions)
             minPrice = elem.Price - minPrice <= 1e-3 ? elem.Price : minPrice;

            return minPrice;
        }

        #endregion

        //Общий метод для сортировки 
        public void SortTv(Comparison<Television> comparator) => _televisions.Sort(comparator);

        //Метод выборки 
        public List<Television> SelectBy(Predicate<Television> condition)
            => _televisions.FindAll(condition);

        #region Рудименты

        #region Выборки 

        //Выборка телевизоров с мин стоимостью ремонта 
        public Television[]SelectMinPrice(double minPrice = 3000d)
        {
            
            //Если элемент = минимальному, тогда отбираем его
            Television [] temp = _televisions.FindAll((tv) => tv.Price.CompareTo(minPrice) == 0 ? true : false).ToArray();
            return temp;
        }

        //Выборка телевизоров ремонтируемых выбранным мастером 
        public Television[] SelectByRepairer(string Repairer = "Доронин А.Н.")
        {

            //Если элемент равен заданному, забираем его
            Television[] temp = _televisions.FindAll((tv) => tv.SurnameRepairer.CompareTo(Repairer) == 0 ? true : false).ToArray();
            return temp; //Возвращаем массив выбранных телевизоров
        }

        //Выборка телевизоров, с заданной диагональю экрана 

        public Television[] SelectByDiagona (double diagonal = 60d)
        {

            //Если элемент равен заданному, забираем его
            Television[] temp = _televisions.FindAll((tv) => tv.Diagonal.CompareTo(diagonal) == 0 ? true : false).ToArray();
            return temp; //Возвращаем массив выбранных телевизоров
        }

        #endregion
        #endregion

    }
}
