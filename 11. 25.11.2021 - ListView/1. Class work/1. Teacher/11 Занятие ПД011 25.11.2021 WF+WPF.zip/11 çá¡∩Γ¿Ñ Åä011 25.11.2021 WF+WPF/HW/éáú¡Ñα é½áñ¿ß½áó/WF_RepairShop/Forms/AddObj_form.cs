﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WF_RepairShop.Controller;
using WF_RepairShop.Models;
using WF_RepairShop.Utilities;

namespace WF_RepairShop.Forms
{
    public partial class AddObj_form : Form
    {

        //Свойство объекта 
        private Television _television;

        public Television television
        {
            get => _television;
        }

        //TODO - попробуй в конце реализовать идею из калькулятора с добавлением картинки. Но только если займёт <= 30-50 min
        public AddObj_form() : this(Television.Generate())
        {
        }

        //C_TOR с параметрами
        public AddObj_form(Television tv)
        {
            InitializeComponent();
            _television = tv;

        }

        //Привязка данных к конкретному комбобоксу
        void BindData(List<object> list,ComboBox cbx)
        {
            cbx.DataSource = null;
            cbx.DataSource = list;

        }

      

        //Проверка введенного владельца
        private void TextBoxOwner_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrEmpty(Tbx_Owner.Text))
            {
                ErpOwnerField.SetError(Tbx_Owner, "Поле должно быть заполнено!");
                //Отключаем вывод 
                Tbx_EndedObj.Clear();
                Tbx_Owner.Focus();
                //Отключаем конпку

            }
            else
            {
                ErpOwnerField.Clear();
                _television.SurnameOwner = Tbx_Owner.Text;
                //Выводим готовый объект в TextBox 
                Tbx_EndedObj.Text = $"Создан обект:\r\n{_television}";
            }
        }

        //Проверка введенных значений вещественных чисел
        private void TextBoxDouble_Validating(object sender, CancelEventArgs e)
        {
            TextBox textBox = sender as TextBox;

            //Вводим стоимость ремонта 
            if (double.TryParse(textBox.Text, out double value))
            {
                if (value.CompareTo(0) <= 0)
                {
                    textBox.Clear();
                    textBox.Focus();

                    textBox.BackColor = Color.Red;
                    Tbx_EndedObj.Clear();
                }
                else
                {
                    //Выбор поля присваивания
                    if (textBox.Equals(Tbx_Diagonal))
                        _television.Diagonal = value;
                    else if (textBox.Equals(Tbx_Price))
                        _television.Price = value;

                    //Выводим готовый объект в TextBox 
                    Tbx_EndedObj.Text = $"Создан обект:\r\n{_television}";
                }
            }
            //В случае если введено не число
            else
            {

                textBox.Clear();
                textBox.Focus();
                textBox.BackColor = Color.Red;
                Tbx_EndedObj.Clear();
            }

        }

        //При повторном вводе меняем цвет
        private void Tbx_Changed(object sender, EventArgs e)
        {
            TextBox textBox = sender as TextBox;
            textBox.BackColor = Color.White;
        }

        //Изменение картинки 
        private void Cbx_Type_IndexChanged(object sender, EventArgs e)
        {
            //Если индекс изменен не в comboBox типов - выход
            if (!((ComboBox)sender).Equals(Cbx_Type))
                return;

            _television.Type = Cbx_Type.Text;
            //Выводим готовый объект в TextBox 
            Tbx_EndedObj.Text = $"Создан обект:\r\n{_television}";

            switch ((string)Cbx_Type.SelectedItem)
            {
                //При выборе типа 
                 
                case "ЭЛТ":
                    Pcb_Type.Image = Image.FromFile(@"..\..\Images\Type_CRT.jpg");
                    Gbx_Type.Text = "ЭЛТ телевизоры";
                    break;//При выборе типа ЭЛТ
                case "RP":
                    Pcb_Type.Image = Image.FromFile(@"..\..\Images\Type_RP.jpg");
                    Gbx_Type.Text = "RP телевизоры";
                    break;//При выборе типа RP
                case "DLP":
                    Pcb_Type.Image = Image.FromFile(@"..\..\Images\Type_DLP.jpg");
                    Gbx_Type.Text = "DLP телевизоры";
                    break;//При выборе типа DLP
                case "LCD":
                    Pcb_Type.Image = Image.FromFile(@"..\..\Images\Type_LCD.jpg");
                    Gbx_Type.Text = "LCD телевизоры";
                    break;//При выборе типа LCD
                case "PDP":
                    Pcb_Type.Image = Image.FromFile(@"..\..\Images\Type_PDP.jpg");
                    Gbx_Type.Text = "PDP телевизоры";
                    break;//При выборе типа PDP
                case "LED":
                    Pcb_Type.Image = Image.FromFile(@"..\..\Images\Type_LED.jpg");
                    Gbx_Type.Text = "LED телевизоры";
                    break;//При выборе типа LED
                case "OLED":
                    Pcb_Type.Image = Image.FromFile(@"..\..\Images\Type_OLED.jpg");
                    Gbx_Type.Text = "OLED телевизоры";
                    break;


                default:
                    Pcb_Type.Image = Image.FromFile(@"..\..\Images\Gray.jpg");
                    break;
            }
        }

      
        private void Cbx_IndexChanged(object sender, EventArgs e)
        {
            ComboBox TempCbx = (ComboBox)sender;

            //Выбор получающего поля
            if (TempCbx.Equals(Cbx_Brand))
                _television.Producer = (string)TempCbx.SelectedItem;
            else if (TempCbx.Equals(Cbx_Defect))
                _television.Defect = (string)TempCbx.SelectedItem;
            else if (TempCbx.Equals(Cbx_Repairer))
                _television.SurnameRepairer = (string)TempCbx.SelectedItem;


            //Выводим готовый объект в TextBox 
            Tbx_EndedObj.Text = $"Создан обект:\r\n{_television}";

        }
        
        //Добавляем производителя
        private void Cbx_Producer_IndexChanged(object sender, EventArgs e)
        {

        }

        //Связывание данных при загрузке формы
        private void AddObj_form_Load(object sender, EventArgs e)
        {
            #region Связывание данных
            //Привязываем данные в comboboxes
            List<object> tempList = new List<object>(Utils.producers);
            BindData(tempList, Cbx_Brand);

            tempList.Clear();
            tempList.AddRange(Utils.types);
            BindData(tempList, Cbx_Type);

            //Добавляем список мастеров 
            tempList.Clear();
            tempList.AddRange(Utils.repairers);
            BindData(tempList, Cbx_Repairer);

            //Добавляем список дефектов 
            tempList.Clear();

            //Получаем все дефекты из кортежа 
            for (int i = 0; i < Utils.defects.Length; i++)
                tempList.Add(Utils.defects[i].def);

            BindData(tempList, Cbx_Defect);
            #endregion

            //Занесение данных в текстовые поля 
            Tbx_Diagonal.Text = $"{Utils.diagonals[Utils.Random.Next(0, Utils.diagonals.Length)]:f2}";

            tempList.Clear();
            for (int i = 0; i < Utils.defects.Length; i++)
                tempList.Add(Utils.defects[i].price);

            Tbx_Price.Text = $"{(double)tempList[Utils.Random.Next(0, Utils.defects.Length)]:f2}";

            Tbx_Owner.Text = $"{Utils.owners[Utils.Random.Next(0, Utils.owners.Length)]}";

            //Заполняем поля телевизора
            //FillTelevision();
        }
    }
}
