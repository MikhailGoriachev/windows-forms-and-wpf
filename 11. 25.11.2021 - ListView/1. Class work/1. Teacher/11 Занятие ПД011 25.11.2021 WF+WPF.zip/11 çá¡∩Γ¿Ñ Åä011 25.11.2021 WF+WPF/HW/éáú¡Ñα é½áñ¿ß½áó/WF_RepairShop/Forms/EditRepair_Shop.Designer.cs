﻿namespace WF_RepairShop.Forms
{
    partial class EditRepair_Shop_Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.BtnAccept = new System.Windows.Forms.Button();
            this.LbName = new System.Windows.Forms.Label();
            this.Tbx_Name = new System.Windows.Forms.TextBox();
            this.Tbx_Adress = new System.Windows.Forms.TextBox();
            this.Lbl_Adress = new System.Windows.Forms.Label();
            this.Gbx_Fields = new System.Windows.Forms.GroupBox();
            this.BtnCancel = new System.Windows.Forms.Button();
            this.Erp_Tbx_Name = new System.Windows.Forms.ErrorProvider(this.components);
            this.Erp_Tbx_Adress = new System.Windows.Forms.ErrorProvider(this.components);
            this.Gbx_Fields.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Erp_Tbx_Name)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Erp_Tbx_Adress)).BeginInit();
            this.SuspendLayout();
            // 
            // BtnAccept
            // 
            this.BtnAccept.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.BtnAccept.Location = new System.Drawing.Point(12, 200);
            this.BtnAccept.Margin = new System.Windows.Forms.Padding(4);
            this.BtnAccept.Name = "BtnAccept";
            this.BtnAccept.Size = new System.Drawing.Size(230, 37);
            this.BtnAccept.TabIndex = 0;
            this.BtnAccept.Text = "Сохранить";
            this.BtnAccept.UseVisualStyleBackColor = true;
            // 
            // LbName
            // 
            this.LbName.Location = new System.Drawing.Point(3, 47);
            this.LbName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.LbName.Name = "LbName";
            this.LbName.Size = new System.Drawing.Size(208, 33);
            this.LbName.TabIndex = 1;
            this.LbName.Text = "Название мастерской";
            this.LbName.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // Tbx_Name
            // 
            this.Tbx_Name.Location = new System.Drawing.Point(7, 68);
            this.Tbx_Name.Margin = new System.Windows.Forms.Padding(4);
            this.Tbx_Name.Name = "Tbx_Name";
            this.Tbx_Name.Size = new System.Drawing.Size(218, 25);
            this.Tbx_Name.TabIndex = 2;
            this.Tbx_Name.Tag = "Erp_Tbx_Name";
            this.Tbx_Name.Validating += new System.ComponentModel.CancelEventHandler(this.Tbx_Validating);
            // 
            // Tbx_Adress
            // 
            this.Tbx_Adress.Location = new System.Drawing.Point(283, 68);
            this.Tbx_Adress.Margin = new System.Windows.Forms.Padding(4);
            this.Tbx_Adress.Name = "Tbx_Adress";
            this.Tbx_Adress.Size = new System.Drawing.Size(203, 25);
            this.Tbx_Adress.TabIndex = 4;
            this.Tbx_Adress.Tag = "Erp_Tbx_Adress";
            this.Tbx_Adress.Validating += new System.ComponentModel.CancelEventHandler(this.Tbx_Validating);
            // 
            // Lbl_Adress
            // 
            this.Lbl_Adress.Location = new System.Drawing.Point(279, 47);
            this.Lbl_Adress.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Lbl_Adress.Name = "Lbl_Adress";
            this.Lbl_Adress.Size = new System.Drawing.Size(208, 30);
            this.Lbl_Adress.TabIndex = 3;
            this.Lbl_Adress.Text = "Адрес";
            this.Lbl_Adress.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // Gbx_Fields
            // 
            this.Gbx_Fields.Controls.Add(this.Tbx_Adress);
            this.Gbx_Fields.Controls.Add(this.Tbx_Name);
            this.Gbx_Fields.Controls.Add(this.LbName);
            this.Gbx_Fields.Controls.Add(this.Lbl_Adress);
            this.Gbx_Fields.Location = new System.Drawing.Point(12, 12);
            this.Gbx_Fields.Name = "Gbx_Fields";
            this.Gbx_Fields.Size = new System.Drawing.Size(494, 158);
            this.Gbx_Fields.TabIndex = 5;
            this.Gbx_Fields.TabStop = false;
            this.Gbx_Fields.Text = "Данные телемастерской";
            // 
            // BtnCancel
            // 
            this.BtnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.BtnCancel.Location = new System.Drawing.Point(276, 200);
            this.BtnCancel.Margin = new System.Windows.Forms.Padding(4);
            this.BtnCancel.Name = "BtnCancel";
            this.BtnCancel.Size = new System.Drawing.Size(230, 37);
            this.BtnCancel.TabIndex = 6;
            this.BtnCancel.Text = "Отмена";
            this.BtnCancel.UseVisualStyleBackColor = true;
            this.BtnCancel.Click += new System.EventHandler(this.Cancel_Command);
            // 
            // Erp_Tbx_Name
            // 
            this.Erp_Tbx_Name.ContainerControl = this;
            // 
            // Erp_Tbx_Adress
            // 
            this.Erp_Tbx_Adress.ContainerControl = this;
            // 
            // EditRepair_Shop_Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(514, 250);
            this.Controls.Add(this.BtnCancel);
            this.Controls.Add(this.Gbx_Fields);
            this.Controls.Add(this.BtnAccept);
            this.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "EditRepair_Shop_Form";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "EditRepair_Shop";
            this.Load += new System.EventHandler(this.EditRepairShop_Form_Load);
            this.Gbx_Fields.ResumeLayout(false);
            this.Gbx_Fields.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Erp_Tbx_Name)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Erp_Tbx_Adress)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button BtnAccept;
        private System.Windows.Forms.Label LbName;
        private System.Windows.Forms.TextBox Tbx_Name;
        private System.Windows.Forms.TextBox Tbx_Adress;
        private System.Windows.Forms.Label Lbl_Adress;
        private System.Windows.Forms.GroupBox Gbx_Fields;
        private System.Windows.Forms.Button BtnCancel;
        private System.Windows.Forms.ErrorProvider Erp_Tbx_Name;
        private System.Windows.Forms.ErrorProvider Erp_Tbx_Adress;
    }
}