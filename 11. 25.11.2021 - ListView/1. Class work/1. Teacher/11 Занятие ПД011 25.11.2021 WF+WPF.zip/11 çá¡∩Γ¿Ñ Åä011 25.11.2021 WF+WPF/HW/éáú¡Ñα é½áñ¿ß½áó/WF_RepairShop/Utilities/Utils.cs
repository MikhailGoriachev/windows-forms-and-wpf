﻿using System;
using System.Text;
using System.Threading;

namespace WF_RepairShop.Utilities
{
    // вспомогательные методы и объекты - статический класс, т.е. класс,
    // содержащий только статические члены и методы
    public static class Utils
    {
        
        // объект для получения случайных чисел
        public static Random Random = new Random();
        
        // формирование случайных вещественных чисел в диапазоне от lo до hi
        public static double GetRandom(double lo, double hi)
            => lo + (hi - lo)*Random.NextDouble();


        //Массив производителей
        public static string[] producers = {

                "Sony",
                "LG",
                "Haier",
                "Kivi",
                "Hisense",
                "Samsung",
                "Philips", //7 strs

            };

        static public double[] diagonals =
        {
            32d,
            42d,
            80d,
            44d,
            37d,
            40d,
            75d,
            55d,
            50d


        };

        //Типы телевизоров, виды матриц экранов
        static public string[] types =
        {
                "ЭЛТ","RP","DLP","LCD","PDP", "LED","OLED" //Max Length = 4 char
            };

        //Повреждение
        static public  (string def, double price)[] defects =
        {
                (      "Инвертор",213d),
                (       "Питание",150d),
                ("Искажены цвета",300d), //14
                ( "Не включается",550d),
                (            "ДУ",170d),
            };

        //Мастер
        static public string[] repairers =
        {
               "Лапин П.Ю.",
               "Терентьев В.И.",
               "Доронин А.Н.",
               "Большаков К.В.",
               "Ковалёв Н.К.",
               "Блохин В.И.",
               "Баранов Ю.Е.",
               "Алексиков И.С."
            };

        //Владелец
        static public string[] owners =
        {
                "Скрипниченко Р.Ю", //16
                "Трошкина В.К.",
                "Медведев А.С.",
                "Бычкова Ю.Р.",
                "Шустра Д.И.",
                "Менделеев Д.Г.",
                "Швецова Е.К.",
                "Самошкина О.Ю."
            };
    } // class Utils
}