﻿namespace WF_RepairShop.Forms
{
    partial class Del_Certain_Tv_Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.BtnDelete = new System.Windows.Forms.Button();
            this.CbxField = new System.Windows.Forms.ComboBox();
            this.LblField = new System.Windows.Forms.Label();
            this.BtnClose = new System.Windows.Forms.Button();
            this.GbxByWhat = new System.Windows.Forms.GroupBox();
            this.RbtnPrice = new System.Windows.Forms.RadioButton();
            this.RbtnRepairer = new System.Windows.Forms.RadioButton();
            this.RbtnDiagonal = new System.Windows.Forms.RadioButton();
            this.RbtnType = new System.Windows.Forms.RadioButton();
            this.RbtnProducer = new System.Windows.Forms.RadioButton();
            this.GbxByWhat.SuspendLayout();
            this.SuspendLayout();
            // 
            // BtnDelete
            // 
            this.BtnDelete.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.BtnDelete.Enabled = false;
            this.BtnDelete.Font = new System.Drawing.Font("Consolas", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BtnDelete.Location = new System.Drawing.Point(26, 267);
            this.BtnDelete.Name = "BtnDelete";
            this.BtnDelete.Size = new System.Drawing.Size(159, 53);
            this.BtnDelete.TabIndex = 0;
            this.BtnDelete.Text = "Удалить";
            this.BtnDelete.UseVisualStyleBackColor = true;
            this.BtnDelete.Click += new System.EventHandler(this.BtnDelete_Click);
            // 
            // CbxField
            // 
            this.CbxField.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CbxField.Enabled = false;
            this.CbxField.FormattingEnabled = true;
            this.CbxField.Location = new System.Drawing.Point(135, 189);
            this.CbxField.Name = "CbxField";
            this.CbxField.Size = new System.Drawing.Size(218, 23);
            this.CbxField.TabIndex = 1;
            this.CbxField.SelectedIndexChanged += new System.EventHandler(this.CbxField_SelectedIndexChanged);
            // 
            // LblField
            // 
            this.LblField.AutoSize = true;
            this.LblField.Enabled = false;
            this.LblField.Font = new System.Drawing.Font("Consolas", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblField.Location = new System.Drawing.Point(140, 168);
            this.LblField.Name = "LblField";
            this.LblField.Size = new System.Drawing.Size(104, 18);
            this.LblField.TabIndex = 2;
            this.LblField.Text = "Поле выборки";
            // 
            // BtnClose
            // 
            this.BtnClose.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.BtnClose.Font = new System.Drawing.Font("Consolas", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BtnClose.Location = new System.Drawing.Point(306, 267);
            this.BtnClose.Name = "BtnClose";
            this.BtnClose.Size = new System.Drawing.Size(169, 53);
            this.BtnClose.TabIndex = 3;
            this.BtnClose.Text = "Закрыть";
            this.BtnClose.UseVisualStyleBackColor = true;
            // 
            // GbxByWhat
            // 
            this.GbxByWhat.Controls.Add(this.RbtnPrice);
            this.GbxByWhat.Controls.Add(this.RbtnRepairer);
            this.GbxByWhat.Controls.Add(this.RbtnDiagonal);
            this.GbxByWhat.Controls.Add(this.RbtnType);
            this.GbxByWhat.Controls.Add(this.RbtnProducer);
            this.GbxByWhat.Location = new System.Drawing.Point(36, 22);
            this.GbxByWhat.Name = "GbxByWhat";
            this.GbxByWhat.Size = new System.Drawing.Size(430, 119);
            this.GbxByWhat.TabIndex = 12;
            this.GbxByWhat.TabStop = false;
            this.GbxByWhat.Text = "Критерии удаления";
            // 
            // RbtnPrice
            // 
            this.RbtnPrice.AutoSize = true;
            this.RbtnPrice.Location = new System.Drawing.Point(270, 34);
            this.RbtnPrice.Name = "RbtnPrice";
            this.RbtnPrice.Size = new System.Drawing.Size(88, 19);
            this.RbtnPrice.TabIndex = 17;
            this.RbtnPrice.TabStop = true;
            this.RbtnPrice.Text = "Стоимость";
            this.RbtnPrice.UseVisualStyleBackColor = true;
            this.RbtnPrice.CheckedChanged += new System.EventHandler(this.RbtnPrice_CheckedChanged);
            // 
            // RbtnRepairer
            // 
            this.RbtnRepairer.AutoSize = true;
            this.RbtnRepairer.Location = new System.Drawing.Point(157, 74);
            this.RbtnRepairer.Name = "RbtnRepairer";
            this.RbtnRepairer.Size = new System.Drawing.Size(67, 19);
            this.RbtnRepairer.TabIndex = 16;
            this.RbtnRepairer.TabStop = true;
            this.RbtnRepairer.Text = "Мастер";
            this.RbtnRepairer.UseVisualStyleBackColor = true;
            this.RbtnRepairer.CheckedChanged += new System.EventHandler(this.RbtnRepairer_CheckedChanged);
            // 
            // RbtnDiagonal
            // 
            this.RbtnDiagonal.AutoSize = true;
            this.RbtnDiagonal.BackColor = System.Drawing.SystemColors.Control;
            this.RbtnDiagonal.Location = new System.Drawing.Point(157, 34);
            this.RbtnDiagonal.Name = "RbtnDiagonal";
            this.RbtnDiagonal.Size = new System.Drawing.Size(88, 19);
            this.RbtnDiagonal.TabIndex = 15;
            this.RbtnDiagonal.TabStop = true;
            this.RbtnDiagonal.Text = "Диагональ";
            this.RbtnDiagonal.UseVisualStyleBackColor = false;
            this.RbtnDiagonal.CheckedChanged += new System.EventHandler(this.RbtnDiagonal_CheckedChanged);
            // 
            // RbtnType
            // 
            this.RbtnType.AutoSize = true;
            this.RbtnType.Location = new System.Drawing.Point(19, 74);
            this.RbtnType.Name = "RbtnType";
            this.RbtnType.Size = new System.Drawing.Size(123, 19);
            this.RbtnType.TabIndex = 14;
            this.RbtnType.TabStop = true;
            this.RbtnType.Text = "Тип телевизора";
            this.RbtnType.UseVisualStyleBackColor = true;
            this.RbtnType.CheckedChanged += new System.EventHandler(this.RbtnType_CheckedChanged);
            // 
            // RbtnProducer
            // 
            this.RbtnProducer.AutoSize = true;
            this.RbtnProducer.BackColor = System.Drawing.SystemColors.Control;
            this.RbtnProducer.Location = new System.Drawing.Point(18, 33);
            this.RbtnProducer.Name = "RbtnProducer";
            this.RbtnProducer.Size = new System.Drawing.Size(116, 19);
            this.RbtnProducer.TabIndex = 13;
            this.RbtnProducer.TabStop = true;
            this.RbtnProducer.Text = "Производитель";
            this.RbtnProducer.UseVisualStyleBackColor = false;
            this.RbtnProducer.CheckedChanged += new System.EventHandler(this.RbtnProducer_CheckedChanged);
            // 
            // Del_Certain_Tv_Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(515, 340);
            this.Controls.Add(this.GbxByWhat);
            this.Controls.Add(this.BtnClose);
            this.Controls.Add(this.LblField);
            this.Controls.Add(this.CbxField);
            this.Controls.Add(this.BtnDelete);
            this.Font = new System.Drawing.Font("Consolas", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Del_Certain_Tv_Form";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Удаление телевизоров";
            this.GbxByWhat.ResumeLayout(false);
            this.GbxByWhat.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button BtnDelete;
        private System.Windows.Forms.ComboBox CbxField;
        private System.Windows.Forms.Label LblField;
        private System.Windows.Forms.Button BtnClose;
        private System.Windows.Forms.GroupBox GbxByWhat;
        private System.Windows.Forms.RadioButton RbtnPrice;
        private System.Windows.Forms.RadioButton RbtnRepairer;
        private System.Windows.Forms.RadioButton RbtnDiagonal;
        private System.Windows.Forms.RadioButton RbtnType;
        private System.Windows.Forms.RadioButton RbtnProducer;
    }
}