﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WF_RepairShop.Controller;
using WF_RepairShop.Models;
using WF_RepairShop.Utilities;

namespace WF_RepairShop.Forms
{
    public partial class Edit_Obj_Form : Form
    {

        //Свойство объекта 
        private Television _television;

        public Television television
        {
            get => _television;
        }

        
        public Edit_Obj_Form() : this(Television.Generate())
        {
        }

        //C_TOR с параметрами
        public Edit_Obj_Form(Television tv)
        {
            InitializeComponent();
            _television = tv;

          
        }

        //Проверка введенной строки
        private void TextBoxStr_Validating(object sender, CancelEventArgs e)
        {
            //Получаем textBox, в котором были изменены значени
            TextBox textBox = sender as TextBox;

            if (string.IsNullOrEmpty(textBox.Text))
            {
                textBox.BackColor = Color.Red;
                //Отключаем вывод 
                Tbx_EndedObj.Clear();
                textBox.Focus();
            }
            else
            {

                //Ввод полей
                if (textBox.Equals(Tbx_Owner))
                    _television.SurnameOwner = textBox.Text;
                else if (textBox.Equals(Tbx_Producer))
                    _television.Producer = textBox.Text;
                else if (textBox.Equals(Tbx_Type))
                    _television.Type = textBox.Text;
                else if (textBox.Equals(Tbx_Defect))
                    _television.Defect = textBox.Text;
                else if (textBox.Equals(Tbx_Repairer))
                    _television.SurnameRepairer = textBox.Text;

               
                //Выводим готовый объект в TextBox 
                Tbx_EndedObj.Text = $"Обект:\r\n{_television}";
            }
        }

        //Проверка введенных значений вещественных чисел
        private void TextBoxDouble_Validating(object sender, CancelEventArgs e)
        {
            TextBox textBox = sender as TextBox;

            //Вводим стоимость ремонта 
            if (double.TryParse(textBox.Text, out double value))
            {
                if (value.CompareTo(0) <= 0)
                {
                    textBox.Clear();
                    textBox.Focus();

                    textBox.BackColor = Color.Red;
                    Tbx_EndedObj.Clear();
                }
                else
                {
                    //Выбор поля присваивания
                    if (textBox.Equals(Tbx_Diagonal))
                        _television.Diagonal = value;
                    else if (textBox.Equals(Tbx_Price))
                        _television.Price = value;

                    //Выводим готовый объект в TextBox 
                    Tbx_EndedObj.Text = $"Обект:\r\n{_television}";
                }
            }
            //В случае если введено не число
            else
            {

                textBox.Clear();
                textBox.Focus();
                textBox.BackColor = Color.Red;
                Tbx_EndedObj.Clear();
            }

        }

        //При повторном вводе меняем цвет
        private void Tbx_Changed(object sender, EventArgs e)
        {
            TextBox textBox = sender as TextBox;
            textBox.BackColor = Color.White;
        }


        //Связывание данных при загрузке формы
        private void Edit_Obj_Form_Load(object sender, EventArgs e)
        {

            //Занесение данных в текстовые поля 
            Tbx_Diagonal.Text = $"{_television.Diagonal:f2}";

            Tbx_Price.Text = $"{_television.Price:f2}";

            Tbx_Owner.Text = $"{_television.SurnameOwner}";

            Tbx_Type.Text = $"{_television.Type}";

            Tbx_Defect.Text = $"{_television.Defect}";

            Tbx_Producer.Text = $"{_television.Producer}";

            Tbx_Repairer.Text = $"{_television.SurnameRepairer}";

            //Выводим готовый объект в TextBox 
            Tbx_EndedObj.Text = $"Обект:\r\n{_television}";
        }
    }
}
