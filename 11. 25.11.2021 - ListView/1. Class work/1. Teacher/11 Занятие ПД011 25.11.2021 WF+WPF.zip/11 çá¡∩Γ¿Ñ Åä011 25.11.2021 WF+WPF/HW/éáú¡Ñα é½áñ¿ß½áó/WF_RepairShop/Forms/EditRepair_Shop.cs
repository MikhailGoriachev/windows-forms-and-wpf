﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WF_RepairShop.Models;
using WF_RepairShop.Utilities;


namespace WF_RepairShop.Forms
{
    public partial class EditRepair_Shop_Form : Form
    {
        /*private RepairShop _repairShop;
        //Свойство мастерской
        public RepairShop repairShop
        {
            get;
        }*/

        //Название мастерской 
        private string _Name;
        public string Name_
        {
            get => _Name;
        }
        //Адрес мастерской 
        private string _Adress;
        public string Adress_
        {
            get => _Adress;
        }
        //Статус изменения 
        private bool Changed = false;

        public EditRepair_Shop_Form():this("Global service", "Будённовский просп.,19")
        {}

        //C_TOR с параметрами 
        public EditRepair_Shop_Form(string name, string adress)
        {
            InitializeComponent();
            _Name = name;
            _Adress = adress;
        }

        //Проверка введенных данных
        private void Tbx_Validating(object sender, CancelEventArgs e)
        {
            //Определяем текстовое поле 
            TextBox tbxTemp = sender as TextBox;
            //Выбираем error provider
            ErrorProvider erpTemp = (String)tbxTemp.Tag == "Erp_Tbx_Name"?Erp_Tbx_Name: (String)tbxTemp.Tag == "Erp_Tbx_Adress"?Erp_Tbx_Adress:new ErrorProvider();
            erpTemp.Clear();

            if (string.IsNullOrWhiteSpace(tbxTemp.Text))
            {
                erpTemp.SetError(tbxTemp, "Введите значение");
                tbxTemp.Focus();
                tbxTemp.Clear();
                BtnAccept.Enabled = false;
            }   
            else
            {
                Changed = true;

                if (tbxTemp == Tbx_Name)
                    _Name = tbxTemp.Text;
                else if (tbxTemp == Tbx_Adress)
                    _Adress = tbxTemp.Text;

                BtnAccept.Enabled = true;
            }
        }

        private void Cancel_Command(object sender, EventArgs e)
        {
            if (Changed)
            {
                DialogResult dialogResult = MessageBox.Show("Мастерская была изменена.Сохранить?","Предупреждение" ,MessageBoxButtons.YesNo, MessageBoxIcon.Information);

                if (dialogResult == DialogResult.Yes)
                    BtnAccept.PerformClick();

            }
        }


        //Загрузка формы
        private void EditRepairShop_Form_Load(object sender, EventArgs e)
        {

            Tbx_Name.Clear();
            Tbx_Adress.Clear();

            Tbx_Name.Text = _Name;
            Tbx_Adress.Text = _Adress;
        }
    }
}
