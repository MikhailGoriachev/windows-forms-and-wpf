﻿namespace WF_RepairShop
{
    partial class Main_form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Main_form));
            System.Windows.Forms.ListViewItem listViewItem1 = new System.Windows.Forms.ListViewItem("Samsung", 0);
            System.Windows.Forms.ListViewItem listViewItem2 = new System.Windows.Forms.ListViewItem("Sony", 0);
            System.Windows.Forms.ListViewItem listViewItem3 = new System.Windows.Forms.ListViewItem("BQ", 0);
            System.Windows.Forms.ListViewItem listViewItem4 = new System.Windows.Forms.ListViewItem("LG", 0);
            System.Windows.Forms.ListViewItem listViewItem5 = new System.Windows.Forms.ListViewItem("Philips", 0);
            System.Windows.Forms.ListViewItem listViewItem6 = new System.Windows.Forms.ListViewItem("Kivi", 0);
            System.Windows.Forms.ListViewItem listViewItem7 = new System.Windows.Forms.ListViewItem("Haier", 1);
            System.Windows.Forms.ListViewItem listViewItem8 = new System.Windows.Forms.ListViewItem("Hisense", 0);
            this.LbxRepairShop = new System.Windows.Forms.ListBox();
            this.contextMenu_MainLbx = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.AddCollectionCM = new System.Windows.Forms.ToolStripMenuItem();
            this.AddTvCM = new System.Windows.Forms.ToolStripMenuItem();
            this.OpenFile_CM = new System.Windows.Forms.ToolStripMenuItem();
            this.EditTvCM = new System.Windows.Forms.ToolStripMenuItem();
            this.DelTvCM = new System.Windows.Forms.ToolStripMenuItem();
            this.DelSetTvContextM = new System.Windows.Forms.ToolStripMenuItem();
            this.DelWhole_CM = new System.Windows.Forms.ToolStripMenuItem();
            this.SortsSetCM = new System.Windows.Forms.ToolStripMenuItem();
            this.SortByProducerCM = new System.Windows.Forms.ToolStripMenuItem();
            this.SortByDiagonalCM = new System.Windows.Forms.ToolStripMenuItem();
            this.SortByRepairerCM = new System.Windows.Forms.ToolStripMenuItem();
            this.SortByOwnerCM = new System.Windows.Forms.ToolStripMenuItem();
            this.SelecetionsSetCM = new System.Windows.Forms.ToolStripMenuItem();
            this.SelectiByDiagonalCM = new System.Windows.Forms.ToolStripMenuItem();
            this.SelectiByOwnerCM = new System.Windows.Forms.ToolStripMenuItem();
            this.SelectiByRepairerCM = new System.Windows.Forms.ToolStripMenuItem();
            this.SelectiByPriceCM = new System.Windows.Forms.ToolStripMenuItem();
            this.ChangeFont_CM = new System.Windows.Forms.ToolStripMenuItem();
            this.ChangeBackColor_CM = new System.Windows.Forms.ToolStripMenuItem();
            this.ChangeForeColor_CM = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuBar = new System.Windows.Forms.MenuStrip();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.выходToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.OpenFileTSMItem = new System.Windows.Forms.ToolStripMenuItem();
            this.мастерскаяToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.редактироватьДанныеМастерскойToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.телевизорыToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.AddTvToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.EditTvToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.DeleteTvToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.ReformTSMItem = new System.Windows.Forms.ToolStripMenuItem();
            this.AddCollectionTvToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.DelTvsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.SortsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.SortByProducerTSMItem = new System.Windows.Forms.ToolStripMenuItem();
            this.SortByDiagonalTSMItem = new System.Windows.Forms.ToolStripMenuItem();
            this.SortByRepairerTSMItem = new System.Windows.Forms.ToolStripMenuItem();
            this.SortByOwnerTSMItem = new System.Windows.Forms.ToolStripMenuItem();
            this.SelectionTSMItem = new System.Windows.Forms.ToolStripMenuItem();
            this.SelectByMinPriceTSMItem = new System.Windows.Forms.ToolStripMenuItem();
            this.SelectRepairerTSMItem = new System.Windows.Forms.ToolStripMenuItem();
            this.SelectDiagonalTSMItem = new System.Windows.Forms.ToolStripMenuItem();
            this.SelectOwnerTSMItem = new System.Windows.Forms.ToolStripMenuItem();
            this.оПрограммеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.TbxTv = new System.Windows.Forms.TextBox();
            this.StsMain = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLbl = new System.Windows.Forms.ToolStripStatusLabel();
            this.GbxTv = new System.Windows.Forms.GroupBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.CbxChooseFew = new System.Windows.Forms.CheckBox();
            this.GbxCheckBox = new System.Windows.Forms.GroupBox();
            this.BtnDelSpecific = new System.Windows.Forms.Button();
            this.ToolBar = new System.Windows.Forms.ToolStrip();
            this.BtnAddToolStrip = new System.Windows.Forms.ToolStripDropDownButton();
            this.AddCollectionTSMItem = new System.Windows.Forms.ToolStripMenuItem();
            this.AddTvMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.AddFileMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.BtnEditRsToolStrip = new System.Windows.Forms.ToolStripSplitButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.BtnSortsToolStrip = new System.Windows.Forms.ToolStripDropDownButton();
            this.BtnSortByBrandTSMItem = new System.Windows.Forms.ToolStripMenuItem();
            this.BtnSortByDiagonalTSMItem = new System.Windows.Forms.ToolStripMenuItem();
            this.BtnSortByRepairerTSMItem = new System.Windows.Forms.ToolStripMenuItem();
            this.BtnSortByOwnerTSMItem = new System.Windows.Forms.ToolStripMenuItem();
            this.BtnSelectionsToolStrip = new System.Windows.Forms.ToolStripDropDownButton();
            this.SelectByPriceTSMItem = new System.Windows.Forms.ToolStripMenuItem();
            this.SelectByRepairerTSMItem = new System.Windows.Forms.ToolStripMenuItem();
            this.SelectByOwnerTSMItem = new System.Windows.Forms.ToolStripMenuItem();
            this.SelectByDiagonalTSMItem = new System.Windows.Forms.ToolStripMenuItem();
            this.BtnEditToolStrip = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.BtnDelTvToolStrip = new System.Windows.Forms.ToolStripButton();
            this.BtnManyTvStrip = new System.Windows.Forms.ToolStripDropDownButton();
            this.SubBtnDelAll = new System.Windows.Forms.ToolStripMenuItem();
            this.SubBtnDelChosen = new System.Windows.Forms.ToolStripMenuItem();
            this.BtnCloseTabStrip = new System.Windows.Forms.ToolStripButton();
            this.BtnExitToolStrip = new System.Windows.Forms.ToolStripButton();
            this.BtnHideToolStrip = new System.Windows.Forms.ToolStripButton();
            this.OFD = new System.Windows.Forms.OpenFileDialog();
            this.SFD = new System.Windows.Forms.SaveFileDialog();
            this.FND_ListBox = new System.Windows.Forms.FontDialog();
            this.CLD_ListBox = new System.Windows.Forms.ColorDialog();
            this.Tab_Control_Main = new System.Windows.Forms.TabControl();
            this.Main_tab = new System.Windows.Forms.TabPage();
            this.Selection_Tab = new System.Windows.Forms.TabPage();
            this.ContextMenu_Selection_Tab = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.Close_SelectionTab_CM = new System.Windows.Forms.ToolStripMenuItem();
            this.Lbx_Select_Tab = new System.Windows.Forms.ListBox();
            this.label2 = new System.Windows.Forms.Label();
            this.Sorts_Tab = new System.Windows.Forms.TabPage();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.Lbx_Sorted_Tab = new System.Windows.Forms.ListBox();
            this.ListView = new System.Windows.Forms.TabPage();
            this.ListView_Tv = new System.Windows.Forms.ListView();
            this.ImageL_Tv = new System.Windows.Forms.ImageList(this.components);
            this.Tmr_Leave_Tab = new System.Windows.Forms.Timer(this.components);
            this.NTI = new System.Windows.Forms.NotifyIcon(this.components);
            this.ContextMenu_NTI = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.открытьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.выходToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.оПрограммеToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.contextMenu_MainLbx.SuspendLayout();
            this.MenuBar.SuspendLayout();
            this.StsMain.SuspendLayout();
            this.GbxTv.SuspendLayout();
            this.GbxCheckBox.SuspendLayout();
            this.ToolBar.SuspendLayout();
            this.Tab_Control_Main.SuspendLayout();
            this.Main_tab.SuspendLayout();
            this.Selection_Tab.SuspendLayout();
            this.ContextMenu_Selection_Tab.SuspendLayout();
            this.Sorts_Tab.SuspendLayout();
            this.ListView.SuspendLayout();
            this.ContextMenu_NTI.SuspendLayout();
            this.SuspendLayout();
            // 
            // LbxRepairShop
            // 
            this.LbxRepairShop.ContextMenuStrip = this.contextMenu_MainLbx;
            this.LbxRepairShop.Font = new System.Drawing.Font("Consolas", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LbxRepairShop.FormattingEnabled = true;
            this.LbxRepairShop.ItemHeight = 19;
            this.LbxRepairShop.Location = new System.Drawing.Point(8, 59);
            this.LbxRepairShop.Name = "LbxRepairShop";
            this.LbxRepairShop.ScrollAlwaysVisible = true;
            this.LbxRepairShop.Size = new System.Drawing.Size(761, 403);
            this.LbxRepairShop.TabIndex = 0;
            this.LbxRepairShop.SelectedIndexChanged += new System.EventHandler(this.LbxRepairShop_SelectedIndexChanged);
            // 
            // contextMenu_MainLbx
            // 
            this.contextMenu_MainLbx.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.AddCollectionCM,
            this.AddTvCM,
            this.OpenFile_CM,
            this.EditTvCM,
            this.DelTvCM,
            this.DelSetTvContextM,
            this.DelWhole_CM,
            this.SortsSetCM,
            this.SelecetionsSetCM,
            this.ChangeFont_CM,
            this.ChangeBackColor_CM,
            this.ChangeForeColor_CM});
            this.contextMenu_MainLbx.Name = "contextMenu_MainLbx";
            this.contextMenu_MainLbx.Size = new System.Drawing.Size(254, 268);
            // 
            // AddCollectionCM
            // 
            this.AddCollectionCM.Name = "AddCollectionCM";
            this.AddCollectionCM.Size = new System.Drawing.Size(253, 22);
            this.AddCollectionCM.Text = "Добавить коллекцию ";
            this.AddCollectionCM.Click += new System.EventHandler(this.AddCollection_Command);
            // 
            // AddTvCM
            // 
            this.AddTvCM.Name = "AddTvCM";
            this.AddTvCM.Size = new System.Drawing.Size(253, 22);
            this.AddTvCM.Text = "Добавить телевизор";
            this.AddTvCM.Click += new System.EventHandler(this.AddTv_Command);
            // 
            // OpenFile_CM
            // 
            this.OpenFile_CM.Name = "OpenFile_CM";
            this.OpenFile_CM.Size = new System.Drawing.Size(253, 22);
            this.OpenFile_CM.Text = "Открыть в файле";
            this.OpenFile_CM.Visible = false;
            this.OpenFile_CM.Click += new System.EventHandler(this.OpenFile_Command);
            // 
            // EditTvCM
            // 
            this.EditTvCM.Name = "EditTvCM";
            this.EditTvCM.Size = new System.Drawing.Size(253, 22);
            this.EditTvCM.Text = "Редактировать телевизор";
            this.EditTvCM.Click += new System.EventHandler(this.EditTv_Command);
            // 
            // DelTvCM
            // 
            this.DelTvCM.Name = "DelTvCM";
            this.DelTvCM.Size = new System.Drawing.Size(253, 22);
            this.DelTvCM.Text = "Удалить телевизор";
            this.DelTvCM.Click += new System.EventHandler(this.DeleteTv_Command);
            // 
            // DelSetTvContextM
            // 
            this.DelSetTvContextM.Enabled = false;
            this.DelSetTvContextM.Name = "DelSetTvContextM";
            this.DelSetTvContextM.Size = new System.Drawing.Size(253, 22);
            this.DelSetTvContextM.Text = "Удалить выбранные телевизоры";
            this.DelSetTvContextM.Click += new System.EventHandler(this.DelTvGroup_Command);
            // 
            // DelWhole_CM
            // 
            this.DelWhole_CM.Name = "DelWhole_CM";
            this.DelWhole_CM.Size = new System.Drawing.Size(253, 22);
            this.DelWhole_CM.Text = "Удалить всю коллекцию";
            this.DelWhole_CM.Click += new System.EventHandler(this.DelAll_Command);
            // 
            // SortsSetCM
            // 
            this.SortsSetCM.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.SortByProducerCM,
            this.SortByDiagonalCM,
            this.SortByRepairerCM,
            this.SortByOwnerCM});
            this.SortsSetCM.Name = "SortsSetCM";
            this.SortsSetCM.Size = new System.Drawing.Size(253, 22);
            this.SortsSetCM.Text = "Сортировки ";
            // 
            // SortByProducerCM
            // 
            this.SortByProducerCM.Name = "SortByProducerCM";
            this.SortByProducerCM.Size = new System.Drawing.Size(247, 22);
            this.SortByProducerCM.Text = "Сортировка по производителю";
            this.SortByProducerCM.Click += new System.EventHandler(this.SortByProducerTSMItem_Command);
            // 
            // SortByDiagonalCM
            // 
            this.SortByDiagonalCM.Name = "SortByDiagonalCM";
            this.SortByDiagonalCM.Size = new System.Drawing.Size(247, 22);
            this.SortByDiagonalCM.Text = "Сортировка по диаголнали";
            this.SortByDiagonalCM.Click += new System.EventHandler(this.SortByDiagonalTSMItem_Command);
            // 
            // SortByRepairerCM
            // 
            this.SortByRepairerCM.Name = "SortByRepairerCM";
            this.SortByRepairerCM.Size = new System.Drawing.Size(247, 22);
            this.SortByRepairerCM.Text = "Сортировка по мастеру";
            this.SortByRepairerCM.Click += new System.EventHandler(this.SortByRepairerTSMItem_Command);
            // 
            // SortByOwnerCM
            // 
            this.SortByOwnerCM.Name = "SortByOwnerCM";
            this.SortByOwnerCM.Size = new System.Drawing.Size(247, 22);
            this.SortByOwnerCM.Text = "Сортировка по владельцу";
            this.SortByOwnerCM.Click += new System.EventHandler(this.SortByOwnerTSMItem_Command);
            // 
            // SelecetionsSetCM
            // 
            this.SelecetionsSetCM.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.SelectiByDiagonalCM,
            this.SelectiByOwnerCM,
            this.SelectiByRepairerCM,
            this.SelectiByPriceCM});
            this.SelecetionsSetCM.Name = "SelecetionsSetCM";
            this.SelecetionsSetCM.Size = new System.Drawing.Size(253, 22);
            this.SelecetionsSetCM.Text = "Выборки";
            // 
            // SelectiByDiagonalCM
            // 
            this.SelectiByDiagonalCM.Name = "SelectiByDiagonalCM";
            this.SelectiByDiagonalCM.Size = new System.Drawing.Size(228, 22);
            this.SelectiByDiagonalCM.Text = "Выборка по диагонали";
            this.SelectiByDiagonalCM.Click += new System.EventHandler(this.SelectByDiagonal_Command);
            // 
            // SelectiByOwnerCM
            // 
            this.SelectiByOwnerCM.Name = "SelectiByOwnerCM";
            this.SelectiByOwnerCM.Size = new System.Drawing.Size(228, 22);
            this.SelectiByOwnerCM.Text = "Выборка по владельцу";
            this.SelectiByOwnerCM.Click += new System.EventHandler(this.SelectByOwner_Command);
            // 
            // SelectiByRepairerCM
            // 
            this.SelectiByRepairerCM.Name = "SelectiByRepairerCM";
            this.SelectiByRepairerCM.Size = new System.Drawing.Size(228, 22);
            this.SelectiByRepairerCM.Text = "Выборка по мастеру";
            this.SelectiByRepairerCM.Click += new System.EventHandler(this.SelectByRepairer_Command);
            // 
            // SelectiByPriceCM
            // 
            this.SelectiByPriceCM.Name = "SelectiByPriceCM";
            this.SelectiByPriceCM.Size = new System.Drawing.Size(228, 22);
            this.SelectiByPriceCM.Text = "Выборка по мин.стоимости";
            this.SelectiByPriceCM.Click += new System.EventHandler(this.SelectByMinPrice_Command);
            // 
            // ChangeFont_CM
            // 
            this.ChangeFont_CM.Name = "ChangeFont_CM";
            this.ChangeFont_CM.Size = new System.Drawing.Size(253, 22);
            this.ChangeFont_CM.Text = "Изменить шрифт";
            this.ChangeFont_CM.Click += new System.EventHandler(this.ChangeFont_Command);
            // 
            // ChangeBackColor_CM
            // 
            this.ChangeBackColor_CM.Name = "ChangeBackColor_CM";
            this.ChangeBackColor_CM.Size = new System.Drawing.Size(253, 22);
            this.ChangeBackColor_CM.Text = "Изменить цвет фона";
            this.ChangeBackColor_CM.Click += new System.EventHandler(this.ChangeColor_Command);
            // 
            // ChangeForeColor_CM
            // 
            this.ChangeForeColor_CM.Name = "ChangeForeColor_CM";
            this.ChangeForeColor_CM.Size = new System.Drawing.Size(253, 22);
            this.ChangeForeColor_CM.Text = "Изменить цвет текста";
            this.ChangeForeColor_CM.Click += new System.EventHandler(this.ChangeColor_Command);
            // 
            // MenuBar
            // 
            this.MenuBar.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem1,
            this.мастерскаяToolStripMenuItem,
            this.телевизорыToolStripMenuItem,
            this.оПрограммеToolStripMenuItem});
            this.MenuBar.Location = new System.Drawing.Point(0, 0);
            this.MenuBar.Name = "MenuBar";
            this.MenuBar.Size = new System.Drawing.Size(1137, 24);
            this.MenuBar.TabIndex = 3;
            this.MenuBar.Text = "menuStrip1";
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.выходToolStripMenuItem,
            this.OpenFileTSMItem});
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(48, 20);
            this.toolStripMenuItem1.Text = "Файл";
            // 
            // выходToolStripMenuItem
            // 
            this.выходToolStripMenuItem.Name = "выходToolStripMenuItem";
            this.выходToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.F4)));
            this.выходToolStripMenuItem.Size = new System.Drawing.Size(167, 22);
            this.выходToolStripMenuItem.Text = "Выход";
            this.выходToolStripMenuItem.Click += new System.EventHandler(this.Exit_Command);
            // 
            // OpenFileTSMItem
            // 
            this.OpenFileTSMItem.Name = "OpenFileTSMItem";
            this.OpenFileTSMItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.O)));
            this.OpenFileTSMItem.Size = new System.Drawing.Size(167, 22);
            this.OpenFileTSMItem.Text = "Открыть ";
            this.OpenFileTSMItem.Click += new System.EventHandler(this.OpenFile_Command);
            // 
            // мастерскаяToolStripMenuItem
            // 
            this.мастерскаяToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.редактироватьДанныеМастерскойToolStripMenuItem});
            this.мастерскаяToolStripMenuItem.Name = "мастерскаяToolStripMenuItem";
            this.мастерскаяToolStripMenuItem.Size = new System.Drawing.Size(84, 20);
            this.мастерскаяToolStripMenuItem.Text = "Мастерская";
            // 
            // редактироватьДанныеМастерскойToolStripMenuItem
            // 
            this.редактироватьДанныеМастерскойToolStripMenuItem.Name = "редактироватьДанныеМастерскойToolStripMenuItem";
            this.редактироватьДанныеМастерскойToolStripMenuItem.Size = new System.Drawing.Size(266, 22);
            this.редактироватьДанныеМастерскойToolStripMenuItem.Text = "Редактировать данные мастерской";
            this.редактироватьДанныеМастерскойToolStripMenuItem.Click += new System.EventHandler(this.EditRepairShop_Command);
            // 
            // телевизорыToolStripMenuItem
            // 
            this.телевизорыToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.AddTvToolStripMenuItem,
            this.EditTvToolStripMenuItem,
            this.DeleteTvToolStripMenuItem,
            this.toolStripSeparator2,
            this.ReformTSMItem,
            this.AddCollectionTvToolStripMenuItem,
            this.DelTvsToolStripMenuItem,
            this.SortsToolStripMenuItem,
            this.SelectionTSMItem});
            this.телевизорыToolStripMenuItem.Name = "телевизорыToolStripMenuItem";
            this.телевизорыToolStripMenuItem.Size = new System.Drawing.Size(85, 20);
            this.телевизорыToolStripMenuItem.Text = "Телевизоры";
            // 
            // AddTvToolStripMenuItem
            // 
            this.AddTvToolStripMenuItem.Name = "AddTvToolStripMenuItem";
            this.AddTvToolStripMenuItem.Size = new System.Drawing.Size(244, 22);
            this.AddTvToolStripMenuItem.Text = "Добавить TV";
            this.AddTvToolStripMenuItem.Click += new System.EventHandler(this.AddTv_Command);
            // 
            // EditTvToolStripMenuItem
            // 
            this.EditTvToolStripMenuItem.Name = "EditTvToolStripMenuItem";
            this.EditTvToolStripMenuItem.Size = new System.Drawing.Size(244, 22);
            this.EditTvToolStripMenuItem.Text = "Редактировать TV";
            this.EditTvToolStripMenuItem.Click += new System.EventHandler(this.EditTv_Command);
            // 
            // DeleteTvToolStripMenuItem
            // 
            this.DeleteTvToolStripMenuItem.Name = "DeleteTvToolStripMenuItem";
            this.DeleteTvToolStripMenuItem.Size = new System.Drawing.Size(244, 22);
            this.DeleteTvToolStripMenuItem.Text = "Удалить телевизор";
            this.DeleteTvToolStripMenuItem.Click += new System.EventHandler(this.DeleteTv_Command);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(241, 6);
            // 
            // ReformTSMItem
            // 
            this.ReformTSMItem.Name = "ReformTSMItem";
            this.ReformTSMItem.Size = new System.Drawing.Size(244, 22);
            this.ReformTSMItem.Text = "Переформировать коллекцию";
            this.ReformTSMItem.Click += new System.EventHandler(this.ReformCollection_Command);
            // 
            // AddCollectionTvToolStripMenuItem
            // 
            this.AddCollectionTvToolStripMenuItem.Name = "AddCollectionTvToolStripMenuItem";
            this.AddCollectionTvToolStripMenuItem.Size = new System.Drawing.Size(244, 22);
            this.AddCollectionTvToolStripMenuItem.Text = "Добавить коллекцию";
            this.AddCollectionTvToolStripMenuItem.Click += new System.EventHandler(this.AddCollection_Command);
            // 
            // DelTvsToolStripMenuItem
            // 
            this.DelTvsToolStripMenuItem.Name = "DelTvsToolStripMenuItem";
            this.DelTvsToolStripMenuItem.Size = new System.Drawing.Size(244, 22);
            this.DelTvsToolStripMenuItem.Text = "Удалить телевизоры";
            this.DelTvsToolStripMenuItem.Click += new System.EventHandler(this.DelTvGroup_Command);
            // 
            // SortsToolStripMenuItem
            // 
            this.SortsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.SortByProducerTSMItem,
            this.SortByDiagonalTSMItem,
            this.SortByRepairerTSMItem,
            this.SortByOwnerTSMItem});
            this.SortsToolStripMenuItem.Name = "SortsToolStripMenuItem";
            this.SortsToolStripMenuItem.Size = new System.Drawing.Size(244, 22);
            this.SortsToolStripMenuItem.Text = "Сортировки";
            // 
            // SortByProducerTSMItem
            // 
            this.SortByProducerTSMItem.Name = "SortByProducerTSMItem";
            this.SortByProducerTSMItem.Size = new System.Drawing.Size(212, 22);
            this.SortByProducerTSMItem.Text = "По производителю";
            this.SortByProducerTSMItem.Click += new System.EventHandler(this.SortByProducerTSMItem_Command);
            // 
            // SortByDiagonalTSMItem
            // 
            this.SortByDiagonalTSMItem.Name = "SortByDiagonalTSMItem";
            this.SortByDiagonalTSMItem.Size = new System.Drawing.Size(212, 22);
            this.SortByDiagonalTSMItem.Text = "По убыванию диагонали";
            this.SortByDiagonalTSMItem.Click += new System.EventHandler(this.SortByDiagonalTSMItem_Command);
            // 
            // SortByRepairerTSMItem
            // 
            this.SortByRepairerTSMItem.Name = "SortByRepairerTSMItem";
            this.SortByRepairerTSMItem.Size = new System.Drawing.Size(212, 22);
            this.SortByRepairerTSMItem.Text = "По мастеру";
            this.SortByRepairerTSMItem.Click += new System.EventHandler(this.SortByRepairerTSMItem_Command);
            // 
            // SortByOwnerTSMItem
            // 
            this.SortByOwnerTSMItem.Name = "SortByOwnerTSMItem";
            this.SortByOwnerTSMItem.Size = new System.Drawing.Size(212, 22);
            this.SortByOwnerTSMItem.Text = "По владельцу";
            this.SortByOwnerTSMItem.Click += new System.EventHandler(this.SortByOwnerTSMItem_Command);
            // 
            // SelectionTSMItem
            // 
            this.SelectionTSMItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.SelectByMinPriceTSMItem,
            this.SelectRepairerTSMItem,
            this.SelectDiagonalTSMItem,
            this.SelectOwnerTSMItem});
            this.SelectionTSMItem.Name = "SelectionTSMItem";
            this.SelectionTSMItem.Size = new System.Drawing.Size(244, 22);
            this.SelectionTSMItem.Text = "Выборки";
            // 
            // SelectByMinPriceTSMItem
            // 
            this.SelectByMinPriceTSMItem.Name = "SelectByMinPriceTSMItem";
            this.SelectByMinPriceTSMItem.Size = new System.Drawing.Size(265, 22);
            this.SelectByMinPriceTSMItem.Text = "Телевизоры с мин. ценой ремонта";
            this.SelectByMinPriceTSMItem.Click += new System.EventHandler(this.SelectByMinPrice_Command);
            // 
            // SelectRepairerTSMItem
            // 
            this.SelectRepairerTSMItem.Name = "SelectRepairerTSMItem";
            this.SelectRepairerTSMItem.Size = new System.Drawing.Size(265, 22);
            this.SelectRepairerTSMItem.Text = "По выбранному мастеру";
            this.SelectRepairerTSMItem.Click += new System.EventHandler(this.SelectByRepairer_Command);
            // 
            // SelectDiagonalTSMItem
            // 
            this.SelectDiagonalTSMItem.Name = "SelectDiagonalTSMItem";
            this.SelectDiagonalTSMItem.Size = new System.Drawing.Size(265, 22);
            this.SelectDiagonalTSMItem.Text = "По диагонали экрана";
            this.SelectDiagonalTSMItem.Click += new System.EventHandler(this.SelectByDiagonal_Command);
            // 
            // SelectOwnerTSMItem
            // 
            this.SelectOwnerTSMItem.Name = "SelectOwnerTSMItem";
            this.SelectOwnerTSMItem.Size = new System.Drawing.Size(265, 22);
            this.SelectOwnerTSMItem.Text = "По владельцу";
            this.SelectOwnerTSMItem.Click += new System.EventHandler(this.SelectByOwner_Command);
            // 
            // оПрограммеToolStripMenuItem
            // 
            this.оПрограммеToolStripMenuItem.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.оПрограммеToolStripMenuItem.Name = "оПрограммеToolStripMenuItem";
            this.оПрограммеToolStripMenuItem.Size = new System.Drawing.Size(94, 20);
            this.оПрограммеToolStripMenuItem.Text = "О программе";
            this.оПрограммеToolStripMenuItem.Click += new System.EventHandler(this.About_Command);
            // 
            // TbxTv
            // 
            this.TbxTv.Font = new System.Drawing.Font("Consolas", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TbxTv.Location = new System.Drawing.Point(20, 19);
            this.TbxTv.Multiline = true;
            this.TbxTv.Name = "TbxTv";
            this.TbxTv.ReadOnly = true;
            this.TbxTv.Size = new System.Drawing.Size(244, 265);
            this.TbxTv.TabIndex = 4;
            // 
            // StsMain
            // 
            this.StsMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLbl});
            this.StsMain.Location = new System.Drawing.Point(0, 606);
            this.StsMain.Name = "StsMain";
            this.StsMain.Size = new System.Drawing.Size(1137, 22);
            this.StsMain.TabIndex = 5;
            this.StsMain.Text = "statusStrip1";
            // 
            // toolStripStatusLbl
            // 
            this.toolStripStatusLbl.Name = "toolStripStatusLbl";
            this.toolStripStatusLbl.Size = new System.Drawing.Size(0, 17);
            // 
            // GbxTv
            // 
            this.GbxTv.Controls.Add(this.TbxTv);
            this.GbxTv.Location = new System.Drawing.Point(816, 59);
            this.GbxTv.Name = "GbxTv";
            this.GbxTv.Size = new System.Drawing.Size(280, 290);
            this.GbxTv.TabIndex = 6;
            this.GbxTv.TabStop = false;
            this.GbxTv.Text = "     Выбранный телевизор. Полная информация.";
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Consolas", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox1.Location = new System.Drawing.Point(8, 31);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(761, 30);
            this.textBox1.TabIndex = 8;
            this.textBox1.Text = "Производитель    Тип    Диагональ         Дефект            Владелец            М" +
    "астер           Цена   ";
            // 
            // CbxChooseFew
            // 
            this.CbxChooseFew.Font = new System.Drawing.Font("Consolas", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.CbxChooseFew.Location = new System.Drawing.Point(6, 12);
            this.CbxChooseFew.Name = "CbxChooseFew";
            this.CbxChooseFew.Size = new System.Drawing.Size(104, 45);
            this.CbxChooseFew.TabIndex = 10;
            this.CbxChooseFew.Text = "Выбрать несколько";
            this.CbxChooseFew.UseVisualStyleBackColor = true;
            this.CbxChooseFew.CheckedChanged += new System.EventHandler(this.CbxChooseFew_CheckedChanged);
            // 
            // GbxCheckBox
            // 
            this.GbxCheckBox.Controls.Add(this.CbxChooseFew);
            this.GbxCheckBox.Location = new System.Drawing.Point(8, 461);
            this.GbxCheckBox.Name = "GbxCheckBox";
            this.GbxCheckBox.Size = new System.Drawing.Size(116, 61);
            this.GbxCheckBox.TabIndex = 11;
            this.GbxCheckBox.TabStop = false;
            // 
            // BtnDelSpecific
            // 
            this.BtnDelSpecific.BackColor = System.Drawing.Color.IndianRed;
            this.BtnDelSpecific.Enabled = false;
            this.BtnDelSpecific.Location = new System.Drawing.Point(140, 467);
            this.BtnDelSpecific.Name = "BtnDelSpecific";
            this.BtnDelSpecific.Size = new System.Drawing.Size(104, 55);
            this.BtnDelSpecific.TabIndex = 13;
            this.BtnDelSpecific.Text = "Удаление по критерию";
            this.BtnDelSpecific.UseVisualStyleBackColor = false;
            this.BtnDelSpecific.Visible = false;
            this.BtnDelSpecific.Click += new System.EventHandler(this.BtnDelCertain_Click);
            // 
            // ToolBar
            // 
            this.ToolBar.AutoSize = false;
            this.ToolBar.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.BtnAddToolStrip,
            this.BtnEditRsToolStrip,
            this.toolStripSeparator1,
            this.BtnSortsToolStrip,
            this.BtnSelectionsToolStrip,
            this.BtnEditToolStrip,
            this.toolStripSeparator3,
            this.BtnDelTvToolStrip,
            this.BtnManyTvStrip,
            this.BtnCloseTabStrip,
            this.BtnExitToolStrip,
            this.BtnHideToolStrip});
            this.ToolBar.Location = new System.Drawing.Point(0, 24);
            this.ToolBar.Name = "ToolBar";
            this.ToolBar.Size = new System.Drawing.Size(1137, 31);
            this.ToolBar.TabIndex = 14;
            this.ToolBar.Text = "toolStrip1";
            // 
            // BtnAddToolStrip
            // 
            this.BtnAddToolStrip.AutoSize = false;
            this.BtnAddToolStrip.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.BtnAddToolStrip.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.AddCollectionTSMItem,
            this.AddTvMenuItem,
            this.AddFileMenuItem});
            this.BtnAddToolStrip.Image = ((System.Drawing.Image)(resources.GetObject("BtnAddToolStrip.Image")));
            this.BtnAddToolStrip.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.BtnAddToolStrip.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.BtnAddToolStrip.Name = "BtnAddToolStrip";
            this.BtnAddToolStrip.Size = new System.Drawing.Size(39, 22);
            this.BtnAddToolStrip.Text = "toolStripDropDownButton1";
            this.BtnAddToolStrip.ToolTipText = "Добавление объекта";
            // 
            // AddCollectionTSMItem
            // 
            this.AddCollectionTSMItem.Name = "AddCollectionTSMItem";
            this.AddCollectionTSMItem.Size = new System.Drawing.Size(264, 22);
            this.AddCollectionTSMItem.Text = "Добавить коллекцию телевизоров";
            this.AddCollectionTSMItem.Click += new System.EventHandler(this.AddCollection_Command);
            // 
            // AddTvMenuItem
            // 
            this.AddTvMenuItem.Name = "AddTvMenuItem";
            this.AddTvMenuItem.Size = new System.Drawing.Size(264, 22);
            this.AddTvMenuItem.Text = "Добавить телевизор";
            this.AddTvMenuItem.Click += new System.EventHandler(this.AddTv_Command);
            // 
            // AddFileMenuItem
            // 
            this.AddFileMenuItem.Name = "AddFileMenuItem";
            this.AddFileMenuItem.Size = new System.Drawing.Size(264, 22);
            this.AddFileMenuItem.Text = "Добавить из файла";
            this.AddFileMenuItem.Click += new System.EventHandler(this.OpenFile_Command);
            // 
            // BtnEditRsToolStrip
            // 
            this.BtnEditRsToolStrip.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.BtnEditRsToolStrip.Image = ((System.Drawing.Image)(resources.GetObject("BtnEditRsToolStrip.Image")));
            this.BtnEditRsToolStrip.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.BtnEditRsToolStrip.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.BtnEditRsToolStrip.Name = "BtnEditRsToolStrip";
            this.BtnEditRsToolStrip.Size = new System.Drawing.Size(36, 28);
            this.BtnEditRsToolStrip.Text = "toolStripSplitButton2";
            this.BtnEditRsToolStrip.ToolTipText = "Редактирование мастерской";
            this.BtnEditRsToolStrip.ButtonClick += new System.EventHandler(this.EditRepairShop_Command);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 31);
            // 
            // BtnSortsToolStrip
            // 
            this.BtnSortsToolStrip.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.BtnSortsToolStrip.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.BtnSortByBrandTSMItem,
            this.BtnSortByDiagonalTSMItem,
            this.BtnSortByRepairerTSMItem,
            this.BtnSortByOwnerTSMItem});
            this.BtnSortsToolStrip.Image = ((System.Drawing.Image)(resources.GetObject("BtnSortsToolStrip.Image")));
            this.BtnSortsToolStrip.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.BtnSortsToolStrip.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.BtnSortsToolStrip.Name = "BtnSortsToolStrip";
            this.BtnSortsToolStrip.Size = new System.Drawing.Size(33, 28);
            this.BtnSortsToolStrip.ToolTipText = "Сортировки";
            // 
            // BtnSortByBrandTSMItem
            // 
            this.BtnSortByBrandTSMItem.Name = "BtnSortByBrandTSMItem";
            this.BtnSortByBrandTSMItem.Size = new System.Drawing.Size(279, 22);
            this.BtnSortByBrandTSMItem.Text = "Сортировка по бренду";
            this.BtnSortByBrandTSMItem.Click += new System.EventHandler(this.SortByProducerTSMItem_Command);
            // 
            // BtnSortByDiagonalTSMItem
            // 
            this.BtnSortByDiagonalTSMItem.Name = "BtnSortByDiagonalTSMItem";
            this.BtnSortByDiagonalTSMItem.Size = new System.Drawing.Size(279, 22);
            this.BtnSortByDiagonalTSMItem.Text = "Сортировка по убыванию диагонали";
            this.BtnSortByDiagonalTSMItem.Click += new System.EventHandler(this.SortByDiagonalTSMItem_Command);
            // 
            // BtnSortByRepairerTSMItem
            // 
            this.BtnSortByRepairerTSMItem.Name = "BtnSortByRepairerTSMItem";
            this.BtnSortByRepairerTSMItem.Size = new System.Drawing.Size(279, 22);
            this.BtnSortByRepairerTSMItem.Text = "Сортировка по мастеру";
            this.BtnSortByRepairerTSMItem.Click += new System.EventHandler(this.SortByRepairerTSMItem_Command);
            // 
            // BtnSortByOwnerTSMItem
            // 
            this.BtnSortByOwnerTSMItem.Name = "BtnSortByOwnerTSMItem";
            this.BtnSortByOwnerTSMItem.Size = new System.Drawing.Size(279, 22);
            this.BtnSortByOwnerTSMItem.Text = "Сортировка по владельцу";
            this.BtnSortByOwnerTSMItem.Click += new System.EventHandler(this.SortByOwnerTSMItem_Command);
            // 
            // BtnSelectionsToolStrip
            // 
            this.BtnSelectionsToolStrip.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.BtnSelectionsToolStrip.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.SelectByPriceTSMItem,
            this.SelectByRepairerTSMItem,
            this.SelectByOwnerTSMItem,
            this.SelectByDiagonalTSMItem});
            this.BtnSelectionsToolStrip.Image = ((System.Drawing.Image)(resources.GetObject("BtnSelectionsToolStrip.Image")));
            this.BtnSelectionsToolStrip.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.BtnSelectionsToolStrip.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.BtnSelectionsToolStrip.Name = "BtnSelectionsToolStrip";
            this.BtnSelectionsToolStrip.Size = new System.Drawing.Size(33, 28);
            this.BtnSelectionsToolStrip.Text = "toolStripDropDownButton1";
            this.BtnSelectionsToolStrip.ToolTipText = "Выборки телевизоров";
            // 
            // SelectByPriceTSMItem
            // 
            this.SelectByPriceTSMItem.Name = "SelectByPriceTSMItem";
            this.SelectByPriceTSMItem.Size = new System.Drawing.Size(242, 22);
            this.SelectByPriceTSMItem.Text = "Выборка по мин. стоимости";
            this.SelectByPriceTSMItem.Click += new System.EventHandler(this.SelectByMinPrice_Command);
            // 
            // SelectByRepairerTSMItem
            // 
            this.SelectByRepairerTSMItem.Name = "SelectByRepairerTSMItem";
            this.SelectByRepairerTSMItem.Size = new System.Drawing.Size(242, 22);
            this.SelectByRepairerTSMItem.Text = "Выборка по мастеру";
            this.SelectByRepairerTSMItem.Click += new System.EventHandler(this.SelectByRepairer_Command);
            // 
            // SelectByOwnerTSMItem
            // 
            this.SelectByOwnerTSMItem.Name = "SelectByOwnerTSMItem";
            this.SelectByOwnerTSMItem.Size = new System.Drawing.Size(242, 22);
            this.SelectByOwnerTSMItem.Text = "Выборка по владельцу";
            this.SelectByOwnerTSMItem.Click += new System.EventHandler(this.SelectByOwner_Command);
            // 
            // SelectByDiagonalTSMItem
            // 
            this.SelectByDiagonalTSMItem.Name = "SelectByDiagonalTSMItem";
            this.SelectByDiagonalTSMItem.Size = new System.Drawing.Size(242, 22);
            this.SelectByDiagonalTSMItem.Text = "Выборка по диагонали экрана";
            this.SelectByDiagonalTSMItem.Click += new System.EventHandler(this.SelectByDiagonal_Command);
            // 
            // BtnEditToolStrip
            // 
            this.BtnEditToolStrip.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.BtnEditToolStrip.Image = ((System.Drawing.Image)(resources.GetObject("BtnEditToolStrip.Image")));
            this.BtnEditToolStrip.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.BtnEditToolStrip.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.BtnEditToolStrip.Name = "BtnEditToolStrip";
            this.BtnEditToolStrip.Size = new System.Drawing.Size(24, 28);
            this.BtnEditToolStrip.ToolTipText = "Редактировать телевизор";
            this.BtnEditToolStrip.Click += new System.EventHandler(this.EditTv_Command);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(6, 31);
            // 
            // BtnDelTvToolStrip
            // 
            this.BtnDelTvToolStrip.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.BtnDelTvToolStrip.Image = ((System.Drawing.Image)(resources.GetObject("BtnDelTvToolStrip.Image")));
            this.BtnDelTvToolStrip.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.BtnDelTvToolStrip.Name = "BtnDelTvToolStrip";
            this.BtnDelTvToolStrip.Size = new System.Drawing.Size(23, 28);
            this.BtnDelTvToolStrip.Text = "toolStripButton1";
            this.BtnDelTvToolStrip.ToolTipText = "Удалить телевизор";
            this.BtnDelTvToolStrip.Click += new System.EventHandler(this.DeleteTv_Command);
            // 
            // BtnManyTvStrip
            // 
            this.BtnManyTvStrip.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.BtnManyTvStrip.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.SubBtnDelAll,
            this.SubBtnDelChosen});
            this.BtnManyTvStrip.Image = ((System.Drawing.Image)(resources.GetObject("BtnManyTvStrip.Image")));
            this.BtnManyTvStrip.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.BtnManyTvStrip.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.BtnManyTvStrip.Name = "BtnManyTvStrip";
            this.BtnManyTvStrip.Size = new System.Drawing.Size(33, 28);
            this.BtnManyTvStrip.ToolTipText = "Удаление коллекции";
            // 
            // SubBtnDelAll
            // 
            this.SubBtnDelAll.Name = "SubBtnDelAll";
            this.SubBtnDelAll.Size = new System.Drawing.Size(253, 22);
            this.SubBtnDelAll.Text = "Удалить всю коллекцию";
            this.SubBtnDelAll.Click += new System.EventHandler(this.DelAll_Command);
            // 
            // SubBtnDelChosen
            // 
            this.SubBtnDelChosen.Enabled = false;
            this.SubBtnDelChosen.Name = "SubBtnDelChosen";
            this.SubBtnDelChosen.Size = new System.Drawing.Size(253, 22);
            this.SubBtnDelChosen.Text = "Удалить выбранные телевизоры";
            this.SubBtnDelChosen.Click += new System.EventHandler(this.DelTvGroup_Command);
            // 
            // BtnCloseTabStrip
            // 
            this.BtnCloseTabStrip.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.BtnCloseTabStrip.Enabled = false;
            this.BtnCloseTabStrip.Image = ((System.Drawing.Image)(resources.GetObject("BtnCloseTabStrip.Image")));
            this.BtnCloseTabStrip.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.BtnCloseTabStrip.Name = "BtnCloseTabStrip";
            this.BtnCloseTabStrip.Size = new System.Drawing.Size(23, 28);
            this.BtnCloseTabStrip.ToolTipText = "Закрыть выбранную вкладку";
            this.BtnCloseTabStrip.Click += new System.EventHandler(this.Close_Current_Tab_Command);
            // 
            // BtnExitToolStrip
            // 
            this.BtnExitToolStrip.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.BtnExitToolStrip.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.BtnExitToolStrip.Image = ((System.Drawing.Image)(resources.GetObject("BtnExitToolStrip.Image")));
            this.BtnExitToolStrip.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.BtnExitToolStrip.Name = "BtnExitToolStrip";
            this.BtnExitToolStrip.Size = new System.Drawing.Size(23, 28);
            this.BtnExitToolStrip.Click += new System.EventHandler(this.Exit_Command);
            // 
            // BtnHideToolStrip
            // 
            this.BtnHideToolStrip.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.BtnHideToolStrip.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.BtnHideToolStrip.Image = ((System.Drawing.Image)(resources.GetObject("BtnHideToolStrip.Image")));
            this.BtnHideToolStrip.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.BtnHideToolStrip.Name = "BtnHideToolStrip";
            this.BtnHideToolStrip.Size = new System.Drawing.Size(23, 28);
            this.BtnHideToolStrip.Text = "toolStripButton1";
            this.BtnHideToolStrip.ToolTipText = "Свернуть в tray";
            this.BtnHideToolStrip.Click += new System.EventHandler(this.HideFrom_Command);
            // 
            // OFD
            // 
            this.OFD.Filter = "(*.json)|*.json";
            // 
            // SFD
            // 
            this.SFD.Filter = "(*.json)|*.json";
            // 
            // Tab_Control_Main
            // 
            this.Tab_Control_Main.Controls.Add(this.Main_tab);
            this.Tab_Control_Main.Controls.Add(this.Selection_Tab);
            this.Tab_Control_Main.Controls.Add(this.Sorts_Tab);
            this.Tab_Control_Main.Controls.Add(this.ListView);
            this.Tab_Control_Main.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Tab_Control_Main.Location = new System.Drawing.Point(0, 55);
            this.Tab_Control_Main.Name = "Tab_Control_Main";
            this.Tab_Control_Main.SelectedIndex = 0;
            this.Tab_Control_Main.Size = new System.Drawing.Size(1137, 551);
            this.Tab_Control_Main.TabIndex = 15;
            // 
            // Main_tab
            // 
            this.Main_tab.Controls.Add(this.textBox1);
            this.Main_tab.Controls.Add(this.LbxRepairShop);
            this.Main_tab.Controls.Add(this.GbxTv);
            this.Main_tab.Controls.Add(this.BtnDelSpecific);
            this.Main_tab.Controls.Add(this.GbxCheckBox);
            this.Main_tab.Location = new System.Drawing.Point(4, 22);
            this.Main_tab.Name = "Main_tab";
            this.Main_tab.Padding = new System.Windows.Forms.Padding(3);
            this.Main_tab.Size = new System.Drawing.Size(1129, 525);
            this.Main_tab.TabIndex = 0;
            this.Main_tab.Text = "Гланая вкладка";
            this.Main_tab.UseVisualStyleBackColor = true;
            this.Main_tab.Leave += new System.EventHandler(this.Tab_Leave);
            // 
            // Selection_Tab
            // 
            this.Selection_Tab.ContextMenuStrip = this.ContextMenu_Selection_Tab;
            this.Selection_Tab.Controls.Add(this.Lbx_Select_Tab);
            this.Selection_Tab.Controls.Add(this.label2);
            this.Selection_Tab.Location = new System.Drawing.Point(4, 22);
            this.Selection_Tab.Name = "Selection_Tab";
            this.Selection_Tab.Padding = new System.Windows.Forms.Padding(3);
            this.Selection_Tab.Size = new System.Drawing.Size(1129, 525);
            this.Selection_Tab.TabIndex = 1;
            this.Selection_Tab.Text = "Выборка";
            this.Selection_Tab.UseVisualStyleBackColor = true;
            this.Selection_Tab.Enter += new System.EventHandler(this.Enter_Dyn_Tab);
            this.Selection_Tab.Leave += new System.EventHandler(this.Tab_Leave);
            // 
            // ContextMenu_Selection_Tab
            // 
            this.ContextMenu_Selection_Tab.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.Close_SelectionTab_CM});
            this.ContextMenu_Selection_Tab.Name = "ContextMenu_Selection_Tab";
            this.ContextMenu_Selection_Tab.Size = new System.Drawing.Size(167, 26);
            // 
            // Close_SelectionTab_CM
            // 
            this.Close_SelectionTab_CM.Name = "Close_SelectionTab_CM";
            this.Close_SelectionTab_CM.Size = new System.Drawing.Size(166, 22);
            this.Close_SelectionTab_CM.Text = "Закрыть вкладку";
            this.Close_SelectionTab_CM.Click += new System.EventHandler(this.Close_Current_Tab_Command);
            // 
            // Lbx_Select_Tab
            // 
            this.Lbx_Select_Tab.Font = new System.Drawing.Font("Consolas", 12F);
            this.Lbx_Select_Tab.FormattingEnabled = true;
            this.Lbx_Select_Tab.ItemHeight = 19;
            this.Lbx_Select_Tab.Location = new System.Drawing.Point(11, 61);
            this.Lbx_Select_Tab.Name = "Lbx_Select_Tab";
            this.Lbx_Select_Tab.SelectionMode = System.Windows.Forms.SelectionMode.None;
            this.Lbx_Select_Tab.Size = new System.Drawing.Size(738, 346);
            this.Lbx_Select_Tab.TabIndex = 6;
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Consolas", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(8, 22);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(733, 36);
            this.label2.TabIndex = 5;
            this.label2.Text = "Производитель    Тип    Диагональ         Дефект            Владелец            М" +
    "астер           Цена   ";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Sorts_Tab
            // 
            this.Sorts_Tab.Controls.Add(this.textBox2);
            this.Sorts_Tab.Controls.Add(this.Lbx_Sorted_Tab);
            this.Sorts_Tab.Location = new System.Drawing.Point(4, 22);
            this.Sorts_Tab.Name = "Sorts_Tab";
            this.Sorts_Tab.Size = new System.Drawing.Size(1129, 525);
            this.Sorts_Tab.TabIndex = 2;
            this.Sorts_Tab.Text = "Сортировки";
            this.Sorts_Tab.UseVisualStyleBackColor = true;
            this.Sorts_Tab.Leave += new System.EventHandler(this.Tab_Leave);
            // 
            // textBox2
            // 
            this.textBox2.Font = new System.Drawing.Font("Consolas", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox2.Location = new System.Drawing.Point(8, 32);
            this.textBox2.Multiline = true;
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(761, 30);
            this.textBox2.TabIndex = 10;
            this.textBox2.Text = "Производитель    Тип    Диагональ         Дефект            Владелец            М" +
    "астер           Цена   ";
            // 
            // Lbx_Sorted_Tab
            // 
            this.Lbx_Sorted_Tab.ContextMenuStrip = this.contextMenu_MainLbx;
            this.Lbx_Sorted_Tab.Font = new System.Drawing.Font("Consolas", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Lbx_Sorted_Tab.FormattingEnabled = true;
            this.Lbx_Sorted_Tab.ItemHeight = 19;
            this.Lbx_Sorted_Tab.Location = new System.Drawing.Point(8, 60);
            this.Lbx_Sorted_Tab.Name = "Lbx_Sorted_Tab";
            this.Lbx_Sorted_Tab.ScrollAlwaysVisible = true;
            this.Lbx_Sorted_Tab.Size = new System.Drawing.Size(761, 403);
            this.Lbx_Sorted_Tab.TabIndex = 9;
            // 
            // ListView
            // 
            this.ListView.Controls.Add(this.ListView_Tv);
            this.ListView.Location = new System.Drawing.Point(4, 22);
            this.ListView.Name = "ListView";
            this.ListView.Size = new System.Drawing.Size(1129, 525);
            this.ListView.TabIndex = 3;
            this.ListView.Text = "ListVeiw";
            this.ListView.UseVisualStyleBackColor = true;
            // 
            // ListView_Tv
            // 
            this.ListView_Tv.HideSelection = false;
            this.ListView_Tv.Items.AddRange(new System.Windows.Forms.ListViewItem[] {
            listViewItem1,
            listViewItem2,
            listViewItem3,
            listViewItem4,
            listViewItem5,
            listViewItem6,
            listViewItem7,
            listViewItem8});
            this.ListView_Tv.LargeImageList = this.ImageL_Tv;
            this.ListView_Tv.Location = new System.Drawing.Point(8, 26);
            this.ListView_Tv.Name = "ListView_Tv";
            this.ListView_Tv.Size = new System.Drawing.Size(1113, 482);
            this.ListView_Tv.TabIndex = 0;
            this.ListView_Tv.UseCompatibleStateImageBehavior = false;
            // 
            // ImageL_Tv
            // 
            this.ImageL_Tv.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("ImageL_Tv.ImageStream")));
            this.ImageL_Tv.TransparentColor = System.Drawing.Color.Transparent;
            this.ImageL_Tv.Images.SetKeyName(0, "smart-tv.png");
            this.ImageL_Tv.Images.SetKeyName(1, "television.png");
            // 
            // Tmr_Leave_Tab
            // 
            this.Tmr_Leave_Tab.Tick += new System.EventHandler(this.Tmr_Leave_Tab_Tick);
            // 
            // NTI
            // 
            this.NTI.Text = "Form";
            this.NTI.Visible = true;
            // 
            // ContextMenu_NTI
            // 
            this.ContextMenu_NTI.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.открытьToolStripMenuItem,
            this.выходToolStripMenuItem1,
            this.оПрограммеToolStripMenuItem1});
            this.ContextMenu_NTI.Name = "ContextMenu_NTI";
            this.ContextMenu_NTI.Size = new System.Drawing.Size(150, 70);
            // 
            // открытьToolStripMenuItem
            // 
            this.открытьToolStripMenuItem.Name = "открытьToolStripMenuItem";
            this.открытьToolStripMenuItem.Size = new System.Drawing.Size(149, 22);
            this.открытьToolStripMenuItem.Text = "Открыть";
            this.открытьToolStripMenuItem.Click += new System.EventHandler(this.OpenFromTray_Command);
            // 
            // выходToolStripMenuItem1
            // 
            this.выходToolStripMenuItem1.Name = "выходToolStripMenuItem1";
            this.выходToolStripMenuItem1.Size = new System.Drawing.Size(149, 22);
            this.выходToolStripMenuItem1.Text = "Выход";
            this.выходToolStripMenuItem1.Click += new System.EventHandler(this.Exit_Command);
            // 
            // оПрограммеToolStripMenuItem1
            // 
            this.оПрограммеToolStripMenuItem1.Name = "оПрограммеToolStripMenuItem1";
            this.оПрограммеToolStripMenuItem1.Size = new System.Drawing.Size(149, 22);
            this.оПрограммеToolStripMenuItem1.Text = "О программе";
            this.оПрограммеToolStripMenuItem1.Click += new System.EventHandler(this.About_Command);
            // 
            // Main_form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1137, 628);
            this.Controls.Add(this.Tab_Control_Main);
            this.Controls.Add(this.ToolBar);
            this.Controls.Add(this.StsMain);
            this.Controls.Add(this.MenuBar);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.MainMenuStrip = this.MenuBar;
            this.MaximizeBox = false;
            this.Name = "Main_form";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Задание на 25.11";
            this.Load += new System.EventHandler(this.Main_form_Load);
            this.contextMenu_MainLbx.ResumeLayout(false);
            this.MenuBar.ResumeLayout(false);
            this.MenuBar.PerformLayout();
            this.StsMain.ResumeLayout(false);
            this.StsMain.PerformLayout();
            this.GbxTv.ResumeLayout(false);
            this.GbxTv.PerformLayout();
            this.GbxCheckBox.ResumeLayout(false);
            this.ToolBar.ResumeLayout(false);
            this.ToolBar.PerformLayout();
            this.Tab_Control_Main.ResumeLayout(false);
            this.Main_tab.ResumeLayout(false);
            this.Main_tab.PerformLayout();
            this.Selection_Tab.ResumeLayout(false);
            this.ContextMenu_Selection_Tab.ResumeLayout(false);
            this.Sorts_Tab.ResumeLayout(false);
            this.Sorts_Tab.PerformLayout();
            this.ListView.ResumeLayout(false);
            this.ContextMenu_NTI.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox LbxRepairShop;
        private System.Windows.Forms.MenuStrip MenuBar;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem выходToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem мастерскаяToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem телевизорыToolStripMenuItem;
        private System.Windows.Forms.TextBox TbxTv;
        private System.Windows.Forms.StatusStrip StsMain;
        private System.Windows.Forms.GroupBox GbxTv;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLbl;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.ToolStripMenuItem AddTvToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem EditTvToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem AddCollectionTvToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem DeleteTvToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripMenuItem DelTvsToolStripMenuItem;
        private System.Windows.Forms.CheckBox CbxChooseFew;
        private System.Windows.Forms.GroupBox GbxCheckBox;
        private System.Windows.Forms.ToolStripMenuItem SortsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem SortByProducerTSMItem;
        private System.Windows.Forms.ToolStripMenuItem SortByDiagonalTSMItem;
        private System.Windows.Forms.ToolStripMenuItem SortByRepairerTSMItem;
        private System.Windows.Forms.ToolStripMenuItem SortByOwnerTSMItem;
        private System.Windows.Forms.ToolStripMenuItem SelectionTSMItem;
        private System.Windows.Forms.ToolStripMenuItem SelectByMinPriceTSMItem;
        private System.Windows.Forms.ToolStripMenuItem SelectRepairerTSMItem;
        private System.Windows.Forms.ToolStripMenuItem SelectDiagonalTSMItem;
        private System.Windows.Forms.ToolStripMenuItem ReformTSMItem;
        private System.Windows.Forms.Button BtnDelSpecific;
        private System.Windows.Forms.ToolStrip ToolBar;
        private System.Windows.Forms.ToolStripSplitButton BtnEditRsToolStrip;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripDropDownButton BtnSelectionsToolStrip;
        private System.Windows.Forms.ToolStripMenuItem SelectByPriceTSMItem;
        private System.Windows.Forms.ToolStripMenuItem SelectByRepairerTSMItem;
        private System.Windows.Forms.ToolStripMenuItem SelectByOwnerTSMItem;
        private System.Windows.Forms.ToolStripMenuItem SelectByDiagonalTSMItem;
        private System.Windows.Forms.ToolStripMenuItem SelectOwnerTSMItem;
        private System.Windows.Forms.ToolStripDropDownButton BtnAddToolStrip;
        private System.Windows.Forms.ToolStripMenuItem AddCollectionTSMItem;
        private System.Windows.Forms.ToolStripMenuItem AddTvMenuItem;
        private System.Windows.Forms.ToolStripMenuItem оПрограммеToolStripMenuItem;
        private System.Windows.Forms.OpenFileDialog OFD;
        private System.Windows.Forms.SaveFileDialog SFD;
        private System.Windows.Forms.ToolStripMenuItem OpenFileTSMItem;
        private System.Windows.Forms.ContextMenuStrip contextMenu_MainLbx;
        private System.Windows.Forms.ToolStripMenuItem AddCollectionCM;
        private System.Windows.Forms.ToolStripMenuItem AddTvCM;
        private System.Windows.Forms.ToolStripMenuItem EditTvCM;
        private System.Windows.Forms.ToolStripMenuItem DelTvCM;
        private System.Windows.Forms.ToolStripMenuItem DelSetTvContextM;
        private System.Windows.Forms.ToolStripMenuItem SortsSetCM;
        private System.Windows.Forms.ToolStripMenuItem SortByProducerCM;
        private System.Windows.Forms.ToolStripMenuItem SortByDiagonalCM;
        private System.Windows.Forms.ToolStripMenuItem SortByRepairerCM;
        private System.Windows.Forms.ToolStripMenuItem SortByOwnerCM;
        private System.Windows.Forms.ToolStripMenuItem SelecetionsSetCM;
        private System.Windows.Forms.ToolStripMenuItem SelectiByDiagonalCM;
        private System.Windows.Forms.ToolStripMenuItem SelectiByOwnerCM;
        private System.Windows.Forms.ToolStripMenuItem SelectiByRepairerCM;
        private System.Windows.Forms.ToolStripMenuItem SelectiByPriceCM;
        private System.Windows.Forms.ToolStripMenuItem ChangeFont_CM;
        private System.Windows.Forms.ToolStripMenuItem ChangeBackColor_CM;
        private System.Windows.Forms.ToolStripMenuItem DelWhole_CM;
        private System.Windows.Forms.ToolStripMenuItem OpenFile_CM;
        private System.Windows.Forms.ToolStripButton BtnEditToolStrip;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripButton BtnDelTvToolStrip;
        private System.Windows.Forms.ToolStripMenuItem AddFileMenuItem;
        private System.Windows.Forms.ToolStripDropDownButton BtnManyTvStrip;
        private System.Windows.Forms.ToolStripMenuItem SubBtnDelAll;
        private System.Windows.Forms.ToolStripMenuItem SubBtnDelChosen;
        private System.Windows.Forms.ToolStripDropDownButton BtnSortsToolStrip;
        private System.Windows.Forms.ToolStripMenuItem BtnSortByBrandTSMItem;
        private System.Windows.Forms.ToolStripMenuItem BtnSortByDiagonalTSMItem;
        private System.Windows.Forms.ToolStripMenuItem BtnSortByRepairerTSMItem;
        private System.Windows.Forms.ToolStripMenuItem BtnSortByOwnerTSMItem;
        private System.Windows.Forms.FontDialog FND_ListBox;
        private System.Windows.Forms.ColorDialog CLD_ListBox;
        private System.Windows.Forms.ToolStripMenuItem редактироватьДанныеМастерскойToolStripMenuItem;
        private System.Windows.Forms.TabControl Tab_Control_Main;
        private System.Windows.Forms.TabPage Main_tab;
        private System.Windows.Forms.TabPage Selection_Tab;
        private System.Windows.Forms.ListBox Lbx_Select_Tab;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TabPage Sorts_Tab;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.ListBox Lbx_Sorted_Tab;
        private System.Windows.Forms.Timer Tmr_Leave_Tab;
        private System.Windows.Forms.ContextMenuStrip ContextMenu_Selection_Tab;
        private System.Windows.Forms.ToolStripMenuItem Close_SelectionTab_CM;
        private System.Windows.Forms.ToolStripButton BtnCloseTabStrip;
        private System.Windows.Forms.ToolStripMenuItem ChangeForeColor_CM;
        private System.Windows.Forms.TabPage ListView;
        private System.Windows.Forms.ListView ListView_Tv;
        private System.Windows.Forms.ImageList ImageL_Tv;
        private System.Windows.Forms.ToolStripButton BtnExitToolStrip;
        private System.Windows.Forms.NotifyIcon NTI;
        private System.Windows.Forms.ContextMenuStrip ContextMenu_NTI;
        private System.Windows.Forms.ToolStripMenuItem открытьToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem выходToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem оПрограммеToolStripMenuItem1;
        private System.Windows.Forms.ToolStripButton BtnHideToolStrip;
    }
}

