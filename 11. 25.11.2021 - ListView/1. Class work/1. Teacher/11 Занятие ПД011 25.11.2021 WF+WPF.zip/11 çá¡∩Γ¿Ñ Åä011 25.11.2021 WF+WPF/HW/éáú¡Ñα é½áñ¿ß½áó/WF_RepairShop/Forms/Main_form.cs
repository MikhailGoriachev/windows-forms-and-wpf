﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WF_RepairShop.Models;
using WF_RepairShop.Forms;
using WF_RepairShop.Utilities;
using WF_RepairShop.Controller;

namespace WF_RepairShop
{
    public partial class Main_form : Form
    {
        //Телемастерская
        //private RepairShop _repairShop;

        //Котроллер 
        private RepairShopController _repairShopController;

        public Main_form() : this(new RepairShopController())
        { }

        //C_TOR с параметрами
        public Main_form(RepairShopController repairShopController)
        {
            //Создание всех элементов формы
            InitializeComponent();

            _repairShopController = repairShopController;

            //Связывание данных 
            BindRepairShop();

        
            //Сохранение 
            _repairShopController.Serialize();

        }

        //Связываение данных
        private void BindRepairShop()
        {
            //Остановить предыдущую привязку
            LbxRepairShop.DataSource = null;

            //Производим привязку заново
            LbxRepairShop.DataSource = _repairShopController.RepairShop.Televisions;

            //Задаём свойство вывода
            LbxRepairShop.DisplayMember = "ToTableRow";
        }

        //Второй метод для служебных Lbx
        private void BindAnyCollection(ListBox listBox, List<Television> list)
        {
            listBox.DataSource = null;
            listBox.DataSource = list;

            //Задаём свойство вывода 
            listBox.DisplayMember = "ToTableRow";

        }


        //Выбор элемента в списке
        private void LbxRepairShop_SelectedIndexChanged(object sender, EventArgs e)
        {
            int ind = LbxRepairShop.SelectedIndex;
            if (ind < 0 || ind >= _repairShopController.RepairShop.Amount)
            {
                TbxTv.Clear();
                BtnDelSpecific.Visible = true;
                return;
            }
           BtnDelSpecific.Visible = false;
            //Выводим информацию в правый text box
            TbxTv.Text = $"{DateTime.Now:HH:mm:ss}\r\n{_repairShopController.RepairShop[ind]}";


        }

        //Загрузка всей формы
        private void Main_form_Load(object sender, EventArgs e)
        {
            //Вывод количества созданных объектов в строку состояния
            //StsMain.Text = $"Телевизоров в мастерской: {_repairShop.Amount}";
            toolStripStatusLbl.Text = $"Мастерская: {_repairShopController.RepairShop.Name} | Телевизоров в мастерской: {_repairShopController.RepairShop.Amount}";

            //Отключаем кнопку удаление нескольких телевизоров 
            DelTvsToolStripMenuItem.Enabled = false;

            //Отключение выделения
            //LbxRepairShop.ClearSelected();

            BtnDelSpecific.Visible = false;

            //Отключаем вкладки сортировки и выборки 
            Tab_Control_Main.TabPages.Remove(Selection_Tab); ;
            Tab_Control_Main.TabPages.Remove(Sorts_Tab);

            //Проверка на пустоту 
            IsColletionEmpty();

            

        }

        // завершение работы приложения
        private void Exit_Command(object sender, EventArgs e) =>
            Application.Exit();

        private void AddTv_Command(object sender, EventArgs e)
        {
            AddObj_form addForm = new AddObj_form();
            DialogResult showResult = addForm.ShowDialog();

            //Если заверешение работы формы произошло не через кнопку добавить/сохранить
            //со свойством DialogResult.Yes, тогда объект не добавляем 
            if (showResult != DialogResult.OK)
                return;

            int index = 0;
            //Если же завершение работы формы было корректным, тогда добавляем объект в списо TV
            // _repairShopController.RepairShop.AddToList(addForm.television);
            _repairShopController.RepairShop.Televisions.Add(addForm.television);
            //Повторная звязка
            BindRepairShop();

            

            //Проверка на пустоту 
            IsColletionEmpty();

            //Выбираем добавленный объект
            index = _repairShopController.Count - 1;
            LbxRepairShop.SelectedIndex = index;

            toolStripStatusLbl.Text = $"Мастерская: {_repairShopController.RepairShop.Name} | Телевизоров в мастерской: {_repairShopController.RepairShop.Amount}";
            
            //Сохранение 
            _repairShopController.Serialize();
        }

        //Добавление коллекции телевизоров в фомру
        private void AddCollection_Command(object sender, EventArgs e)
        {
            _repairShopController.RepairShop.AddCollectionToList();

            //Проводим повторную связку с List box
            BindRepairShop();

            //Выбираем последний объект
            int index = _repairShopController.Count - 1;
            LbxRepairShop.SelectedIndex = index;

            

            //Проверка на пустоту 
            IsColletionEmpty();
            toolStripStatusLbl.Text = $"Мастерская: {_repairShopController.RepairShop.Name} | Телевизоров в мастерской: {_repairShopController.RepairShop.Amount}";

            //Сохранение 
            if (_repairShopController.Count < 1000)
                _repairShopController.Serialize();
        }

        //Удаление телевизора
        private void DeleteTv_Command(object sender, EventArgs e)
        {
            int ind = LbxRepairShop.SelectedIndex;
            //Проверка на корректность выбранного элемента 
            if (ind < 0 || ind >= _repairShopController.RepairShop.Amount)
                return;
            //Удаление элемента
            _repairShopController.RepairShop.Televisions.RemoveAt(ind);

            //Повторное связывание 
            BindRepairShop();

            

            //Проверка на пустоту 
            IsColletionEmpty();

            //Выбираем последний объект
            int index = _repairShopController.Count - 1;
            if (index >= 0)
                LbxRepairShop.SelectedIndex = index;

            toolStripStatusLbl.Text = $"Мастерская: {_repairShopController.RepairShop.Name} | Телевизоров в мастерской: {_repairShopController.RepairShop.Amount}";

            //Сохранение 
            if (_repairShopController.Count >= 5)
                _repairShopController.Serialize();
        }

        //Предикат вхождения в массив
        delegate bool Predicate(int ind);

        //Удаление нескольких телевизоров 
        private void DelTvGroup_Command(object sender, EventArgs e)
        {
            int count = LbxRepairShop.SelectedItems.Count, j = 0;

            int[] inds = new int[count];

            //Сравнение индексов
            Predicate predicate = (index) =>
            {

                //Если индекс есть в списке выбранны
                for (int i = 0; i < count; i++)
                {
                    if (inds[i] == index)
                        return true;
                }
                //Если индекса нет в списке выбранных 
                return false;

            };

            //Цикл сбора индексов 
            foreach (int index in LbxRepairShop.SelectedIndices)
            {
                inds[j++] = index;
            }

            //Удаление
            for (int i = _repairShopController.RepairShop.Amount; i >= 0; i--)
            {
                //Если текущий индекс = выбранному, тогда удаляем обект с этим индексом
                if (predicate(i))
                    _repairShopController.RepairShop.Televisions.RemoveAt(i);

            }

            BindRepairShop();

            //Проверка коллекции на пустоту 
            IsColletionEmpty();
            CbxChooseFew.CheckState = CheckState.Unchecked;
            toolStripStatusLbl.Text = $"Мастерская: {_repairShopController.RepairShop.Name} | Телевизоров в мастерской: {_repairShopController.RepairShop.Amount}";

            //Выбираем последний объект
            int ind = _repairShopController.Count - 1;
            if (ind >= 0)
                LbxRepairShop.SelectedIndex = ind;

            //Сохранение если в коллекции осталось мие 5 элементов
            if (_repairShopController.Count >= 5)
                _repairShopController.Serialize();

        }

        //Удаление всей коллекции [23.11]
        private void DelAll_Command(object sender, EventArgs e) 
        {
            _repairShopController.RepairShop.Televisions.RemoveRange(0,_repairShopController.Count);

            //Перепривязка данных 
            BindRepairShop();

            //Проверка на пустоту 
            IsColletionEmpty();

            toolStripStatusLbl.Text = $"Мастерская: {_repairShopController.RepairShop.Name} | Телевизоров в мастерской нет";
        }

        //Отключение элементов управления коллекцией в случае её пустоты [23.11.21]
        private void IsColletionEmpty()
        {
            //Если коллекция не пуста
            if (!_repairShopController.IsEmpty)
            {
                
                //Изменение состояний кнопок
                EditTvToolStripMenuItem.Enabled = true;
                DeleteTvToolStripMenuItem.Enabled = true;
                AddCollectionTvToolStripMenuItem.Enabled = true;
                SortsToolStripMenuItem.Enabled = true;
                SelectionTSMItem.Enabled = true;
                DelTvsToolStripMenuItem.Enabled = true;
                //Включаем кнопку выборки 
                SelectionTSMItem.Enabled = true;

                //Включаем кнопки контекстного меню 
                DelTvCM.Enabled = true;
                DelWhole_CM.Enabled = _repairShopController.Count > 1;
                EditTvCM.Enabled = true;
                SelecetionsSetCM.Enabled = true;
                SortsSetCM.Enabled = true;
                //Отключаем возможность загрузки из файла 
                OpenFile_CM.Visible = false;

                //включаем кнопки menu strip
                BtnSortsToolStrip.Enabled =      true;
                BtnSelectionsToolStrip.Enabled = true;
                BtnEditToolStrip.Enabled =       true;
                BtnDelTvToolStrip.Enabled =      true;
                BtnManyTvStrip.Enabled =         true;


                //Включение текстового поля
                GbxTv.Visible = true;

                BtnDelSpecific.Visible = false;
                return;

            }

            //Если коллекция пуста, оставляем включенными только возможности добавления 
            //Изменение состояний кнопок 
            
            EditTvToolStripMenuItem.Enabled = false;

            //Отключаем кнопку выборки 
            SelectionTSMItem.Enabled = false;
            SortsToolStripMenuItem.Enabled = false;
            DeleteTvToolStripMenuItem.Enabled = false;

            DelTvsToolStripMenuItem.Enabled = false;
            DelWhole_CM.Enabled = false;
            //Отключаем кнопки контекстного меню 
           
            DelTvCM.Enabled = false;
            EditTvCM.Enabled = false;
            SelecetionsSetCM.Enabled = false;
            SortsSetCM.Enabled = false;
            DelSetTvContextM.Enabled = false;

            //Включаем возможность загрузки из файла 
            OpenFile_CM.Visible = true;

            //Отключаем кнопки menu strip
            BtnSortsToolStrip.Enabled = false;
            BtnSelectionsToolStrip.Enabled = false;
            BtnEditToolStrip.Enabled = false;
            BtnDelTvToolStrip.Enabled = false;
            BtnManyTvStrip.Enabled = false;

            //Очистка текстового поля
            GbxTv.Visible = false;

            BtnDelSpecific.Visible = false;

        }

        //Check box выбора нескольких телевизоров
        private void CbxChooseFew_CheckedChanged(object sender, EventArgs e)
        {
            if (CbxChooseFew.CheckState == CheckState.Checked)
            {
                

                //Изменение настроек списка
                LbxRepairShop.SelectionMode = SelectionMode.MultiSimple;

                //Проиводим перепривязку. Поскольку в противном случае иногда появляются 
                //проблемы с DiplayMember
                BindRepairShop();

                //Изменение состояний кнопок 
                AddTvToolStripMenuItem.Enabled = false;
                AddCollectionTvToolStripMenuItem.Enabled = false;
                ReformTSMItem.Enabled = false;
                EditTvToolStripMenuItem.Enabled = false;

                //Отключаем кнопку выборки 
                SelectionTSMItem.Enabled = false;

                DeleteTvToolStripMenuItem.Enabled = false;
                AddCollectionTvToolStripMenuItem.Enabled = false;

                DelTvsToolStripMenuItem.Enabled = true;

                //Отключаем кнопки контекстного меню 
                AddCollectionCM.Enabled = false;
                AddTvCM.Enabled = false;
                DelTvCM.Enabled = false;
                EditTvCM.Enabled = false;

                //Отключаем кнопки menu strip
                BtnAddToolStrip.Enabled = false;
                BtnSortsToolStrip.Enabled = false;
                BtnSelectionsToolStrip.Enabled = false;
                BtnEditToolStrip.Enabled = false;
                BtnDelTvToolStrip.Enabled = false;
                SubBtnDelAll.Enabled = false;
                SubBtnDelChosen.Enabled = true;
                //Очистка текстового поля
                GbxTv.Visible = false;

                //19.11.21 - кнопка удаления определенных телевизоров 
                BtnDelSpecific.Enabled = true;
                BtnDelSpecific.Visible = true;
                DelSetTvContextM.Enabled = true;

                
                return;
            }

            GbxTv.Visible = true;
            
            //Изменение настроек списка
            LbxRepairShop.SelectionMode = SelectionMode.One;
            //Проиводим перепривязку 
            BindRepairShop();
            //Изменение состояний кнопок
            AddTvToolStripMenuItem.Enabled = true;
            ReformTSMItem.Enabled = true;
            AddCollectionTvToolStripMenuItem.Enabled = true;
            EditTvToolStripMenuItem.Enabled = true;
            DeleteTvToolStripMenuItem.Enabled = true;
            AddCollectionTvToolStripMenuItem.Enabled = true;

            DelTvsToolStripMenuItem.Enabled = false;
            //Включаем кнопку выборки 
            SelectionTSMItem.Enabled = true;

            //Включаем кнопки контекстного меню 
            AddCollectionCM.Enabled = true;
            AddTvCM.Enabled = true;
            DelTvCM.Enabled = true;
            EditTvCM.Enabled = true;

            //Включаем кнопки menu strip
            BtnAddToolStrip.Enabled =        true;
            BtnSortsToolStrip.Enabled =      true;
            BtnSelectionsToolStrip.Enabled = true;
            BtnEditToolStrip.Enabled =       true;
            BtnDelTvToolStrip.Enabled =      true;
            SubBtnDelAll.Enabled =           true;
            SubBtnDelChosen.Enabled = false;

            //Кнопка удаления определенных телевизоров 
            BtnDelSpecific.Enabled = false;
            BtnDelSpecific.Visible = false;
            DelSetTvContextM.Enabled = false;



        }

        //

        #region Сортировки 
        //Загрузка вкладки
        private void SortsTab_Fill(List<Television> collection)
        {
            //Если вкладка открыта - закрываем
            if (Tab_Control_Main.TabPages.Contains(Sorts_Tab))
                Tab_Control_Main.TabPages.Remove(Sorts_Tab);

            //Включаем вкладку выборки 
            Tab_Control_Main.TabPages.Add(Sorts_Tab);

            //Переключаем текущую вкладку 
            Tab_Control_Main.SelectedTab = Sorts_Tab;

            BindAnyCollection(Lbx_Sorted_Tab, collection);
            //Запускаем обработчик события посещения для изменения данных статусной строки
            Enter_Dyn_Tab(Sorts_Tab, new EventArgs());
        }
        private void SortByProducerTSMItem_Command(object sender, EventArgs e)
        {
            //Сортировка коллекции
            _repairShopController.SortByProducer();

            SortsTab_Fill(_repairShopController.RepairShop.Televisions);

            
        }

        private void SortByDiagonalTSMItem_Command(object sender, EventArgs e)
        {

            //Сортировка коллекции
            _repairShopController.SortDescByDiagonal();

            SortsTab_Fill(_repairShopController.RepairShop.Televisions);

            //Запускаем обработчик события посещения для изменения данных статусной строки
            //Enter_Dyn_Tab(Sorts_Tab, e);
        }
        private void SortByRepairerTSMItem_Command(object sender, EventArgs e)
        {

            //Сортировка коллекции
            _repairShopController.SortByRapairer();

            //Открываем вкладку с привязкой данных к внутреннму ListBox
            SortsTab_Fill(_repairShopController.RepairShop.Televisions);

            //Запускаем обработчик события посещения для изменения данных статусной строки
            //Enter_Dyn_Tab(Sorts_Tab, e);
        }

        private void SortByOwnerTSMItem_Command(object sender, EventArgs e)
        {

            //Сортировка коллекции
            _repairShopController.SortByOwner();


            SortsTab_Fill(_repairShopController.RepairShop.Televisions);
            //Запускаем обработчик события посещения для изменения данных статусной строки
            //Enter_Dyn_Tab(Sorts_Tab, e);
        }
        #endregion

        private void ReformCollection_Command(object sender, EventArgs e)
        {
            _repairShopController.RepairShop.Generate(Utils.Random.Next(12, 15));

            //Производим повторную привязку коллекции в List box
            BindRepairShop();

            

            //Проверка на пустоту 
            IsColletionEmpty();

            //Выбираем последний объект
            int index = _repairShopController.Count - 1;
            LbxRepairShop.SelectedIndex = index;

            toolStripStatusLbl.Text = $"Мастерская: {_repairShopController.RepairShop.Name} | Телевизоров в мастерской: {_repairShopController.RepairShop.Amount}";
            //Сохранение 
            _repairShopController.Serialize();

        }

        #region Обработчики события на вкладках
        //Закрыть вкладку при выходе
        private void Tab_Leave(object sender, EventArgs e)
        {
            TabPage tabPage = sender as TabPage;

            //Запускаем таймер на закрытие вкладки 
            Tmr_Leave_Tab.Interval = 15000;
            Tmr_Leave_Tab.Tag = tabPage;
            Tmr_Leave_Tab.Tick += Tmr_Leave_Tab_Tick;
            Tmr_Leave_Tab.Start();

            //Включаем кнопки управления
            TurnOn_Buttons_Tab();

            toolStripStatusLbl.Text = $"Мастерская: {_repairShopController.RepairShop.Name} | Телевизоров в мастерской: {_repairShopController.RepairShop.Amount}";
        }

        //Закрыть вкладку по кнопке
        private void Close_Current_Tab_Command(object sender, EventArgs e)
        {
            TabPage currPage = Tab_Control_Main.SelectedTab;

            //Если вкладки нет в коллекции или произошла попытка закрытия главной вкладки - выходим
            if (currPage == null || currPage == Main_tab)
                return;
            
            // Закрываем вкладку 
            Tab_Control_Main.TabPages.Remove(currPage);
            TurnOn_Buttons_Tab();
            toolStripStatusLbl.Text = $"Мастерская: {_repairShopController.RepairShop.Name} | Телевизоров в мастерской: {_repairShopController.RepairShop.Amount}";
        }

        //Переход во динамическую вкладку
        private void Enter_Dyn_Tab(object sender, EventArgs e)
        {
            //Если таймер запущен - останавливаем его 
            Tmr_Leave_Tab.Stop();

            TabPage tempPage = sender as TabPage;
            //Отключаем кнопки управления коллекцией 
            TurnOf_Buttons_Tab(tempPage);

            //Создаём пустую строку для изменения статусной строки
            string AddStr = "";

            if (tempPage == Selection_Tab)
                AddStr = $"Выбрано: { Lbx_Select_Tab.Items.Count}";
            else if (tempPage == Sorts_Tab)
                AddStr = $"Отсортирвано: {Lbx_Sorted_Tab.Items.Count}";

            toolStripStatusLbl.Text = $"Мастерская: {_repairShopController.RepairShop.Name} | " + AddStr;
        }

        #endregion

        #region Выборки



        //Счётчик кол-ва вызовов
        int count = 0;

        //Загрузка вкладки
        private void SelectionTab_Fill( List<Television> collection)
        {
            //Если вкладка открыта - закрываем
            if (Tab_Control_Main.TabPages.Contains(Selection_Tab))
                Tab_Control_Main.TabPages.Remove(Selection_Tab);

            //Включаем вкладку выборки 
            Tab_Control_Main.TabPages.Add(Selection_Tab);

            //Переключаем текущую вкладку 
            Tab_Control_Main.SelectedTab = Selection_Tab;

            

            //Lbx_Select_Tab.DataSource = null;

            BindAnyCollection(Lbx_Select_Tab, collection);


            //Выводим предупреждение об ошибке
            if (count++ > 0)
            {
                Timer timer = new Timer();
                timer.Interval = 1300;
                timer.Tick += Tmr_Err_Tab_Tick;
                timer.Tag = Selection_Tab;
                timer.Start();
               
            }
        }

        //Обработчик события окончания времени тамера запущенного при ошибке
        private void Tmr_Err_Tab_Tick(object sender, EventArgs e)
        {
            Timer tempTimer = sender as Timer;
            tempTimer.Stop();

            //Получение объекта вкладки 
            TabPage tempPage = tempTimer.Tag as TabPage;

            
            DialogResult dialogResult = MessageBox.Show($"Открытие вкладки \"{tempPage?.Text}\" N-{count}.\r\nКол-во выбранных элементов: {Lbx_Select_Tab.Items.Count}\r\nКоллекция появилась (Да/Нет)?", " ", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            
            //Закрываем вкладку если была нажата кнопка "нет" и вкладка была передана в теге
            if (dialogResult == DialogResult.No && tempPage != null)
                Tab_Control_Main.TabPages.Remove(tempPage);
        }

        //Выборка телевизоров
        private void SelectByMinPrice_Command(object sender, EventArgs e)
        {
            List<Television> televisions = _repairShopController.SelectByMinPrice();

            //Открываем вкладку
            SelectionTab_Fill( televisions);

            //Status bar
            toolStripStatusLbl.Text = $"Мастерская: {_repairShopController.RepairShop.Name} | Выбрано телевизоров: {televisions.Count}";
        }

        //Выборка по мастерам 
        private void SelectByRepairer_Command(object sender, EventArgs e)
        {
            //Список для хранения возвращаемого списка 
            List<Television> Tvs = new List<Television>();

            //Создаём окно выбора подколлекции 
            Select_Certain select_Certain = new Select_Certain(_repairShopController, Select_Certain.SubObject.repairer);

            if (select_Certain.ShowDialog() != DialogResult.OK)
                return;

            //Получаем выбранного мастера
            string ChosenRepairer = (string)select_Certain.ChosenItem;

            Tvs = _repairShopController.SelectByRepairer(ChosenRepairer);

            //Открываем вкладку
             SelectionTab_Fill(Tvs);

            //Status bar
            toolStripStatusLbl.Text = $"Мастерская: {_repairShopController.RepairShop.Name} | Выбрано телевизоров: {Tvs.Count}";
        }

        //Выборка по диагонали
        private void SelectByDiagonal_Command(object sender, EventArgs e)
        {

            //Список для хранения возвращаемого списка 
            List<Television> Tvs = new List<Television>();

            //Создаём окно выбора подколлекции 
            Select_Certain select_Certain = new Select_Certain(_repairShopController, Select_Certain.SubObject.diagonal);

            if (select_Certain.ShowDialog() != DialogResult.OK)
                return;

            //Получаем выбранную
            double ChosenDiagonal = (double)select_Certain.ChosenItem;

            Tvs = _repairShopController.SelectByDiagonal(ChosenDiagonal);

            //Открываем вкладку
            SelectionTab_Fill(Tvs);

            //Status bar
            toolStripStatusLbl.Text = $"Мастерская: {_repairShopController.RepairShop.Name} | Выбрано телевизоров: {Tvs.Count}";
        }

        //Выборка по владельцу
        private void SelectByOwner_Command(object sender, EventArgs e)
        {

            //Список для хранения возвращаемого списка 
            List<Television> Tvs = new List<Television>();

            //Создаём окно выбора подколлекции 
            Select_Certain select_Certain = new Select_Certain(_repairShopController, Select_Certain.SubObject.owner);

            if (select_Certain.ShowDialog() != DialogResult.OK)
                return;

            //Получаем выбранного владельца
            string ChosenOwner = (string)select_Certain.ChosenItem;

            Tvs = _repairShopController.SelectByOwner(ChosenOwner);

            //Открываем вкладку
            SelectionTab_Fill(Tvs);

            //Status bar
            toolStripStatusLbl.Text = $"Мастерская: {_repairShopController.RepairShop.Name} | Выбрано телевизоров: {Tvs.Count}";
        }
        #endregion

        //Удаление множества телевизоров
        private void BtnDelCertain_Click(object sender, EventArgs e)
        {
            //Вызываем форму удаления 
            Del_Certain_Tv_Form del_Form = new Del_Certain_Tv_Form(_repairShopController);

            if (del_Form.ShowDialog() != DialogResult.OK)
                return;
            //Получаем измененный контроллер
            _repairShopController = del_Form.rsController;

            //Проводим повторную свяку
            BindRepairShop();

            //Сохранение если в коллекции осталось мие 5 элементов
            if (_repairShopController.Count >= 5)
                _repairShopController.Serialize();

            //Проверка на пустоту 
            IsColletionEmpty();

            CbxChooseFew.CheckState = CheckState.Unchecked;
            toolStripStatusLbl.Text = $"Мастерская: {_repairShopController.RepairShop.Name} | Телевизоров в мастерской: {_repairShopController.RepairShop.Amount}";

            //Выбираем последний объект
            int ind = _repairShopController.Count - 1;
            if (ind >= 0)
                LbxRepairShop.SelectedIndex = ind;

        }

        //Редактирование телевизора
        private void EditTv_Command(object sender, EventArgs e)
        {
            //Проверка на наличие выбранного элемента 
            if (LbxRepairShop.SelectedIndex < 0 || LbxRepairShop.SelectedIndex >= _repairShopController.RepairShop.Amount)
            {
                MessageBox.Show("Не выбран телевизор", "Ошибка", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
                return;
            }

            Edit_Obj_Form editTvForm = new Edit_Obj_Form((Television)LbxRepairShop.SelectedItem);
            DialogResult showResult = editTvForm.ShowDialog();

            //Если заверешение работы формы произошло не через кнопку добавить/сохранить
            //со свойством DialogResult.Yes, тогда объект не добавляем 
            if (showResult != DialogResult.OK)
                return;

            //Если же завершение работы формы было корректным, тогда добавляем объект в списо TV
            // _repairShopController.RepairShop.AddToList(addForm.television);
            _repairShopController.RepairShop.Televisions.Add(editTvForm.television);
            //Повторная звязка
            BindRepairShop();

            toolStripStatusLbl.Text = $"Мастерская: {_repairShopController.RepairShop.Name} | Телевизоров в мастерской: {_repairShopController.RepairShop.Amount}";
            //Сохранение 
            _repairShopController.Serialize();
        }

        //Запус формы о программе
        private void About_Command(object sender, EventArgs e)
        {
            Form fromAbout = new AboutForm();
            fromAbout.ShowDialog();
        }

        private void OpenFile_Command(object sender, EventArgs e)
        {
            DialogResult showResult = OFD.ShowDialog();
            if (showResult != DialogResult.OK)
                return;
            _repairShopController.FName = OFD.FileName;
            _repairShopController.Deserialize();
            BindRepairShop();

            //Проверка на пустоту 
            IsColletionEmpty();
            toolStripStatusLbl.Text = $"Мастерская: {_repairShopController.RepairShop.Name} | Телевизоров в мастерской: {_repairShopController.RepairShop.Amount}";

            //Выбираем последний объект
            int ind = _repairShopController.Count - 1;
            if (ind >= 0)
                LbxRepairShop.SelectedIndex = ind;
        }

        //Редактирование днанных телемастерской 
        private void EditRepairShop_Command(object sender, EventArgs e)
        {
            
            EditRepair_Shop_Form editRepairShop = new EditRepair_Shop_Form(_repairShopController.RepairShop.Name, _repairShopController.RepairShop.Adress);

            //Если форма была завершена не по кнопке "Сохранить"
            if (editRepairShop.ShowDialog() != DialogResult.OK)
                return;

            //Перезаписываем Repair shop 
            _repairShopController.RepairShop.Name = editRepairShop.Name_;
            _repairShopController.RepairShop.Adress = editRepairShop.Adress_;

            toolStripStatusLbl.Text = $"Мастерская: {_repairShopController.RepairShop.Name} по адресу {_repairShopController.RepairShop.Adress} | Телевизоров в мастерской: {_repairShopController.RepairShop.Amount}";
        }

        //Изменение шрифта
        private void ChangeFont_Command(object sender, EventArgs e)
        {
            if (FND_ListBox.ShowDialog() != DialogResult.OK)
                return;
            LbxRepairShop.Font = FND_ListBox.Font;
        }

        //Изменение цвета
        private void ChangeColor_Command(object sender, EventArgs e)
        {
            if (CLD_ListBox.ShowDialog() != DialogResult.OK)
                return;

            ToolStripMenuItem button = sender as ToolStripMenuItem;
            if (button == ChangeBackColor_CM)
                LbxRepairShop.BackColor = CLD_ListBox.Color;
            else if (button == ChangeForeColor_CM)
                LbxRepairShop.ForeColor = CLD_ListBox.Color;
            
        }

       

        //Срабатывание таймера покидания вкладки 
        private void Tmr_Leave_Tab_Tick(object sender, EventArgs e)
        {
            Timer timer = (Timer)sender;

            //Останавливаем файл
            timer.Stop();

            TabPage tempPage = timer.Tag as TabPage;

            //Если переданная в теге вкладка не равна 0 и не главная вкладка
            if (tempPage != null && tempPage != Main_tab)
                //Закрываем вкладку при выходе
                Tab_Control_Main.TabPages.Remove(tempPage);

          
        }

        //Отключение кнопок управления коллекцией при открытии вкладок Выборка и Сортировки 
        private void TurnOf_Buttons_Tab(TabPage tabPage)
        {
            //Если вкладка - выборка
            if (tabPage == Selection_Tab) {
                //Изменение состояний кнопок верхнего меню

                EditTvToolStripMenuItem.Enabled = false;
                
                SortsToolStripMenuItem.Enabled = false;
                DeleteTvToolStripMenuItem.Enabled = false;
                DelTvsToolStripMenuItem.Enabled = false;
                DelWhole_CM.Enabled = false;
                AddTvToolStripMenuItem.Enabled =           false;
                ReformTSMItem.Enabled =                    false;
                AddCollectionTvToolStripMenuItem.Enabled = false;


                //Отключаем кнопки menu strip
                BtnAddToolStrip.Enabled = false;
                BtnSortsToolStrip.Enabled = false;
                //BtnSelectionsToolStrip.Enabled = false;
                BtnEditToolStrip.Enabled = false;
                BtnDelTvToolStrip.Enabled = false;
                BtnManyTvStrip.Enabled = false;

                //Включаем кнопку закрытия вкладки 
                BtnCloseTabStrip.Enabled = true;

            }
            //Оператор else if для полного контроля
            else if (tabPage == Sorts_Tab)
            {
                //Изменение состояний кнопок 

                EditTvToolStripMenuItem.Enabled = false;
                SelectionTSMItem.Enabled = false;
                DeleteTvToolStripMenuItem.Enabled = false;
                DelTvsToolStripMenuItem.Enabled = false;
                DelWhole_CM.Enabled = false;
                AddTvToolStripMenuItem.Enabled = false;
                ReformTSMItem.Enabled = false;
                AddCollectionTvToolStripMenuItem.Enabled = false;

                //Отключаем кнопки menu strip
                BtnAddToolStrip.Enabled = false;
                //BtnSortsToolStrip.Enabled = false;
                BtnSelectionsToolStrip.Enabled = false;
                BtnEditToolStrip.Enabled = false;
                BtnDelTvToolStrip.Enabled = false;
                BtnManyTvStrip.Enabled = false;

                //Включаем кнопку закрытия вкладки 
                BtnCloseTabStrip.Enabled = true;
            }
        }
        
        //Отключение кнопок управления коллекцией при открытии вкладок Выборка и Сортировки 
        private void TurnOn_Buttons_Tab()
        {
                //Изменение состояний кнопок 
                EditTvToolStripMenuItem.Enabled =   true;
                SortsToolStripMenuItem.Enabled = true;
                SelectionTSMItem.Enabled =          true;
                DeleteTvToolStripMenuItem.Enabled = true;
                DelTvsToolStripMenuItem.Enabled =   true;
                DelWhole_CM.Enabled =               true;
                AddTvToolStripMenuItem.Enabled =           true;
                ReformTSMItem.Enabled =                    true;
                AddCollectionTvToolStripMenuItem.Enabled = true;

            //Включаем кнопки menu strip
            BtnAddToolStrip.Enabled =        true;
                BtnSortsToolStrip.Enabled =      true;
                BtnSelectionsToolStrip.Enabled = true;
                BtnEditToolStrip.Enabled =       true;
                BtnDelTvToolStrip.Enabled =      true;
                BtnManyTvStrip.Enabled =         true;

                //Отключаем кнопку закрытия вкладки 
                BtnCloseTabStrip.Enabled = false;
        }

        private void OpenFromTray_Command(object sender, EventArgs e)
        {
            this.Show();
            WindowState = FormWindowState.Normal;

            //Отключаем иконку 
            NTI.Visible = false;
        }

        private void HideFrom_Command(object sender, EventArgs e)
        {
            this.Hide();
            NTI.Visible = true;
        }
    } 

}
