﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.ComponentModel;

using TabControlsStdDialogs.Controllers;
using TabControlsStdDialogs.Helpers;
using TabControlsStdDialogs.Models;
using TabControlsStdDialogs.Views;

namespace TabControlsStdDialogs.Views
{
    public partial class MainForm : Form
    {
        // контроллер для работы с формой
        private RepairShopController _repairShopController;

        // конструкторы формы
        public MainForm(): this(new RepairShopController()) {}

        public MainForm(RepairShopController repairShopController) {
            InitializeComponent();

            // получить контроллер для работы с данными ремонтной мастерской
            _repairShopController = repairShopController;

            // формирование заголовков вывода данных о телевизорах
            LblHeaderGeneral.Text =
                $"  Ремонтная мастерская \"{_repairShopController.RepairShop.Title}\", " +
                $"{_repairShopController.RepairShop.Address}, телевизоры в ремонте\r\n" +
                $"{Television.Header}";

            LblHeaderOrdered.Text = 
                $"  Ремонтная мастерская \"{_repairShopController.RepairShop.Title}\", " +
                $"{_repairShopController.RepairShop.Address}, сортировка не выбрана\r\n" +
                $"{Television.Header}";   
            
            LblHeaderSelected.Text = 
                $"  Ремонтная мастерская \"{_repairShopController.RepairShop.Title}\", " +
                $"{_repairShopController.RepairShop.Address}, выборка не выполнена\r\n" +
                $"{Television.Header}";

            // привязка ListBox к коллекции
            BindCollection(_repairShopController.RepairShop.Televisions, LbxGeneral);

            // настроить комбобоксы в панели инструментов

            // мастера и владельцы определяются из коллекции ремонтов
            SetToolbarCombBoxes();

            // диагонали пока просто формируем, не привязываясь к коллекции телевизоров в ремонте
            // настройка комбобокса в панели инструментов со списком диагоналей телевизров,
            // начальный выбор диагонали
            Array.ForEach(Utils.Diagonals, d => CbxDiagonal.Items.Add($"{d:f1}\""));
            CbxDiagonal.Text = CbxDiagonal.Items[0].ToString();
        } // MainForm


        // настроить комбобоксы в панели инструментов
        private void SetToolbarCombBoxes() {
            // настройка комбобокса в панели инструментов со списком мастеров,
            // начальный выбор мастера
            CbxArtisans.Items.Clear();
            CbxArtisans.Items.AddRange(_repairShopController.GetArtisans().ToArray());
            CbxArtisans.Text = CbxArtisans.Items[0].ToString();


            // настройка комбобокса в панели инструментов со списком владельцев,
            // начальный выбор владельца
            CbxOwners.Items.Clear();
            CbxOwners.Items.AddRange(_repairShopController.GetOwners().ToArray());
            CbxOwners.Text = CbxOwners.Items[0].ToString();
        } // SetToolbarCombBoxes



        // выполнение привязки коллекции
        private void BindCollection(List<Television> list, ListBox listBox) {
            // остановить привязку
            listBox.DataSource = null;

            // задать привязку
            listBox.DataSource = list;

            // свойство для отображения в ListBox
            listBox.DisplayMember = "TableRow";
        } // BindCollection


        // выполняется после конструктора формы
        private void MainForm_Load(object sender, EventArgs e) {
            // вывод в строку состояния
            StlMain.Text = $"Телевизоров в ремонте: {_repairShopController.RepairShop.Televisions.Count}";
        } // MainForm_Load


        // свернуть в трей
        private void ToTray_Command(object sender, EventArgs e) {
            this.Hide();
            NtiMain.Visible = true;
        } // ToTray_Command


        // восстановить из трея
        private void FromTray_Command(object sender, EventArgs e) {
            this.Show();
            WindowState = FormWindowState.Normal;
            NtiMain.Visible = false;
        } // FromTray_Command


        // выход из приложения
        private void Exit_Command(object sender, EventArgs e) => Application.Exit();


        // вывод окна со сведениями о программе
        private void About_Command(object sender, EventArgs e) {
            AboutForm aboutForm = new AboutForm();
            aboutForm.ShowDialog();
        } // About_Command


        // сортировка коллекции телевизоров по производителю и типу
        private void OrderByBrand_Command(object sender, EventArgs e) {
            List<Television> list = _repairShopController.OrderByBrand();
            BindCollection(list, LbxOrdered);

            // делаем страницу отсортированных данных текущей
            TbcMain.SelectedTab = TbpOrdered;

            // формирование заголовка поля вывода данных о телевизорах
            LblHeaderOrdered.Text =
                $"  Ремонтная мастерская \"{_repairShopController.RepairShop.Title}\", " +
                $"{_repairShopController.RepairShop.Address}, телевизоры по производителю и типу\r\n" +
                $"{Television.Header}";
        } // OrderByBrand_Command


        // сортировка коллекции телевизоров по убыванию диагонали экрана
        private void OrderByDiagonalDesc_Command(object sender, EventArgs e) {
            List<Television> list = _repairShopController.OrderByDiagonalDesc();
            BindCollection(list, LbxOrdered);

            // делаем страницу отсортированных данных текущей
            TbcMain.SelectedTab = TbpOrdered;

            // формирование заголовка поля вывода данных о телевизорах
            LblHeaderOrdered.Text =
                $"  Ремонтная мастерская \"{_repairShopController.RepairShop.Title}\", " +
                $"{_repairShopController.RepairShop.Address}, телевизоры по убыванию диагонали экрана\r\n" +
                $"{Television.Header}";
        } // OrderByDiagonalDesc_Command


        // сортировка коллекции телевизоров по мастеру, выполняющему ремонт
        private void OrderByArtisan_Command(object sender, EventArgs e) {
            List<Television> list = _repairShopController.OrderByArtisan();
            BindCollection(list, LbxOrdered);

            // делаем страницу отсортированных данных текущей
            TbcMain.SelectedTab = TbpOrdered;

            // формирование заголовка поля вывода данных о телевизорах
            LblHeaderOrdered.Text =
                $"  Ремонтная мастерская \"{_repairShopController.RepairShop.Title}\", " +
                $"{_repairShopController.RepairShop.Address}, телевизоры по мастеру, выполняющему ремонт\r\n" +
                $"{Television.Header}";
        } // OrderByArtisan_Command


        // сортировка коллекции телевизоров по владельцу телевизора
        private void OrderByOwner_Command(object sender, EventArgs e) {
            List<Television> list = _repairShopController.OrderByOwner();
            BindCollection(list, LbxOrdered);

            // делаем страницу отсортированных данных текущей
            TbcMain.SelectedTab = TbpOrdered;

            // формирование заголовка поля вывода данных о телевизорах
            LblHeaderOrdered.Text =
                $"  Ремонтная мастерская \"{_repairShopController.RepairShop.Title}\", " +
                $"{_repairShopController.RepairShop.Address}, телевизоры по владельцу телевизора\r\n" +
                $"{Television.Header}";
        } // OrderByOwner_Command


        // сортировка по стоимости ремонта
        private void OrderByPrice_Command(object sender, EventArgs e) {
            List<Television> list = _repairShopController.OrderByPrice();
            BindCollection(list, LbxOrdered);

            // делаем страницу отсортированных данных текущей
            TbcMain.SelectedTab = TbpOrdered;

            // формирование заголовка поля вывода данных о телевизорах
            LblHeaderOrdered.Text =
                $"  Ремонтная мастерская \"{_repairShopController.RepairShop.Title}\", " +
                $"{_repairShopController.RepairShop.Address}, телевизоры по стоимости ремонта\r\n" +
                $"{Television.Header}";
        } // OrderByPrice_Command


        // выборка и вывод в отдельной вкладке главной формы коллекции телевизоров с минимальной
        // стоимостью ремонта
        private void SelectMinPrice_Command(object sender, EventArgs e) {
            // получить выборку данных
            List<Television> minPriceList = _repairShopController.SelectWhereMinPrice();

            // вывести выборку в отдельной вкладку
            BindCollection(minPriceList, LbxSelected);

            // делаем страницу выбранных данных текущей
            TbcMain.SelectedTab = TbpSelected;

            // изменить заголовок выбранных данных
            LblHeaderSelected.Text =
                $"  Ремонтная мастерская \"{_repairShopController.RepairShop.Title}\", " +
                $"{_repairShopController.RepairShop.Address}, телевизоры с минимальной стоимостью ремонта\r\n" +
                $"{Television.Header}";
        } // SelectMinPrice_Command


        // выборка ремонтов, выполняемых мастером, команда для меню  
        private void SelectArtisan_Command(object sender, EventArgs e) {
            // получить список фамилий из коллекции ремонтов
            List<string> artisans = _repairShopController.GetArtisans();

            // создание формы выбора мастера, передача в окно списка мастеров
            ArtisanChoiceForm artisanChoiceForm = new ArtisanChoiceForm(artisans);

            if (artisanChoiceForm.ShowDialog() != DialogResult.OK) return;

            // выбор мастера произведен, получим мастера, построим выборку
            SelectArtisan(artisanChoiceForm.Artisan);
        } // SelectArtisan_Command


        // запуск выборки ремонтов мастеров - команда для панели инструментов, получить
        // мастера из комбо-бокса панели интсрументов 
        private void SelectArtisanTbr_Command(object sender, EventArgs e) =>
            SelectArtisan(CbxArtisans.Text);

        // формирование выборки ремонтов заданного мастера
        private void SelectArtisan(string artisan) {
            // выбрать ремонты заданного мастера
            List<Television> list = _repairShopController.SelectWhereArtisan(artisan);

            // вывести выборку в отдельной вкладку
            BindCollection(list, LbxSelected);

            // делаем страницу выбранных данных текущей
            TbcMain.SelectedTab = TbpSelected;

            // изменить заголовок выбранных данных
            LblHeaderSelected.Text =
                $"  Ремонтная мастерская \"{_repairShopController.RepairShop.Title}\", " +
                $"{_repairShopController.RepairShop.Address}, телевизоры, ремонтируемые мастером {artisan}\r\n" +
                $"{Television.Header}";
        } // SelectArtisan


        // выборка телевизоров, принадлежащих заданному владельцу, команда для меню  
        private void SelectOwner_Command(object sender, EventArgs e) {
            // получить список фамилий из коллекции ремонтов
            List<string> owners = _repairShopController.GetOwners();

            // создание формы выбора владельца, передача в окно списка владальцев
            OwnerChoiceForm ownerChoiceForm = new OwnerChoiceForm(owners);

            if (ownerChoiceForm.ShowDialog() != DialogResult.OK) return;

            // выбор владельца произведен, получим владельца, построим выборку
            SelectOwner(ownerChoiceForm.TvOwner);
        } // SelectOwner_Command


        // запуск выборки ремонтов мастеров - команда для панели инструментов, получить
        // мастера из комбо-бокса панели интсрументов 
        private void SelectOwnerTbr_Command(object sender, EventArgs e) =>
            SelectOwner(CbxOwners.Text);

        // формирование выборки ремонтов заданного мастера
        private void SelectOwner(string owner) {
            // выбрать ремонты заданного владела
            List<Television> list = _repairShopController.SelectWhereOwner(owner);

            // вывести выборку в отдельной вкладку
            BindCollection(list, LbxSelected);

            // делаем страницу выбранных данных текущей
            TbcMain.SelectedTab = TbpSelected;

            // изменить заголовок выбранных данных
            LblHeaderSelected.Text =
                $"  Ремонтная мастерская \"{_repairShopController.RepairShop.Title}\", " +
                $"{_repairShopController.RepairShop.Address}, телевизоры, которыми влдаеет {owner}\r\n" +
                $"{Television.Header}";
        } // SelectOwner


        // выборка телевизоров с заданной диагональю, команда для меню  
        private void SelectDiagonal_Command(object sender, EventArgs e) {

            // создание формы выбора диагонали телевизора
            DiagonalChoiceForm diagonalChoiceForm = new DiagonalChoiceForm();

            // показать диалоговое окно в модальном режиме, если вернулисть не по ОК,
            // молча уходим
            if (diagonalChoiceForm.ShowDialog() != DialogResult.OK) return;

            // выбор диагонали произведен, получим диагональ, построим выборку
            SelectDiagonal(diagonalChoiceForm.Diagonal);
        } // SelectDiagonal_Command


        // запуск выборки ремонтов мастеров - команда для панели инструментов, получить
        // мастера из комбо-бокса панели интсрументов 
        private void SelectDiagonalTbr_Command(object sender, EventArgs e) =>
            SelectDiagonal(CbxDiagonal.Text);


        // формирование выборки ремонтов заданного мастера
        private void SelectDiagonal(string diagonal) {
            // выбрать телевизоры с заданной диагональю
            double numDiagonal = double.Parse(diagonal.Replace(@"""", ""));
            List<Television> list = _repairShopController.SelectWhereDiagonal(numDiagonal);

            // вывести выборку в отдельной вкладку
            BindCollection(list, LbxSelected);

            // делаем страницу выбранных данных текущей
            TbcMain.SelectedTab = TbpSelected;

            // изменить заголовок выбранных данных
            LblHeaderSelected.Text =
                $"  Ремонтная мастерская \"{_repairShopController.RepairShop.Title}\", " +
                $"{_repairShopController.RepairShop.Address}, телевизоры, с диагональю {diagonal}\"\r\n" +
                $"{Television.Header}";
        } // SelectArtisan


        // выполнение команды создания новой ремонтной мастерской
        private void NewRepairShop_Command(object sender, EventArgs e) {

            // создать форму для ввода параметров новой ремонтной мастеской
            RepairShopForm repairShopForm = new RepairShopForm();

            // если завершили не по ОК - молча уходим
            if (repairShopForm.ShowDialog() != DialogResult.OK)
                return;

            // выполнить действие контроллера для создания новой ремонтной мастерской
            // с данными, полученными от формы ввода
            _repairShopController.CreateNewRepairShop(repairShopForm.Title, repairShopForm.Address);

            // обновить отображаемые на главной форме данные
            // формирование заголовка поля вывода данных о телевизорах
            LblHeaderGeneral.Text =
                $"  Ремонтная мастерская \"{_repairShopController.RepairShop.Title}\", " +
                $"{_repairShopController.RepairShop.Address}, телевизоры в ремонте\r\n" +
                $"{Television.Header}";

            // привязка пустой коллекции к ListBox
            BindCollection(_repairShopController.RepairShop.Televisions, LbxGeneral);

            // вывод в строку состояния
            StlMain.Text = $"Телевизоров в ремонте: {_repairShopController.RepairShop.Televisions.Count}";

            // сохранить изменения в коллекции
            _repairShopController.SerializeData();
        } // NewRepairShop_Command


        // редактирование данных ремонтной мастерской - название, адрес
        private void EditRepairShop_Command(object sender, EventArgs e) {
            // создать форму для редактирования параметров новой ремонтной мастеской
            RepairShopForm repairShopForm = new RepairShopForm(
                _repairShopController.RepairShop.Title, _repairShopController.RepairShop.Address);

            // если завершили не по ОК - молча уходим
            if (repairShopForm.ShowDialog() != DialogResult.OK)
                return;

            // получить параметры ремонтной мастерской из формы
            _repairShopController.RepairShop.Title = repairShopForm.Title;
            _repairShopController.RepairShop.Address = repairShopForm.Address;

            // обновить отображаемые на главной форме данные
            // формирование заголовка поля вывода данных о телевизорах
            LblHeaderGeneral.Text =
                $"  Ремонтная мастерская \"{_repairShopController.RepairShop.Title}\", " +
                $"{_repairShopController.RepairShop.Address}, телевизоры в ремонте\r\n" +
                $"{Television.Header}";

            // сохранить изменения в коллекции
            _repairShopController.SerializeData();
        } // EditRepairShop_Command


        // прием телевизора в ремонт
        private void AddTelevision_Command(object sender, EventArgs e) {

            // создать форму для ввода параметров телевизора, принимаемого в ремонт
            TelevisionForm televisionForm = new TelevisionForm();

            // показать форму ввода модально, если форма завершается не по ОК, молча уходим
            if (televisionForm.ShowDialog() != DialogResult.OK) return;

            // добавить телевизор в коллекцию ремонтируемых телевизоров
            _repairShopController.RepairShop.Add(televisionForm.Data);

            // обновить привязку данных, строку состояния
            BindCollection(_repairShopController.RepairShop.Televisions, LbxGeneral);
            StlMain.Text = $"Телевизоров в ремонте: {_repairShopController.RepairShop.Televisions.Count}";

            // сохранить изменения в коллекции
            _repairShopController.SerializeData();

            // обновить значения в комбобксах панели инструментов
            SetToolbarCombBoxes();
        } // AddTelevision_Command


        // редактирование данных телевизора в ремонте
        private void EditTelevision_Command(object sender, EventArgs e) {

            // если нет выбранного телевизора, молча уходим
            int selectedIndex = LbxGeneral.SelectedIndex;
            if (selectedIndex == -1) return;

            // ссылка на редактируемый телевизор - для повышения читаемости кода
            Television television = _repairShopController.RepairShop[selectedIndex];

            // создать форму для редактирования параметров телевизора в ремонте
            TelevisionForm televisionForm = new TelevisionForm("Редактирование параметров телевизора", television);

            // показать форму ввода модально, если форма завершается не по ОК, молча уходим
            if (televisionForm.ShowDialog() != DialogResult.OK) return;

            // добавить телевизор в коллекцию ремонтируемых телевизоров
            _repairShopController.RepairShop[selectedIndex] = televisionForm.Data;

            // обновить привязку данных, восстановить отметку выбранного элемента ListBox
            BindCollection(_repairShopController.RepairShop.Televisions, LbxGeneral);
            LbxGeneral.SelectedIndex = selectedIndex;

            // сохранить изменения в коллекции
            _repairShopController.SerializeData();

            // обновить значения в комбобксах панели инструментов
            SetToolbarCombBoxes();
        } // EditTelevision_Command


        // выдача телевизора владельцу
        private void ServeOut_Command(object sender, EventArgs e) {

            int selectedIndex = LbxGeneral.SelectedIndex;

            // если нет выбранного телевизора, молча уходим
            if (selectedIndex == -1) return;

            // удалить выбранный телевизор из коллекции - выдать телевизор владельцу
            _repairShopController.RepairShop.RemoveAt(selectedIndex);

            // обновить привязку данных, строку состояния
            BindCollection(_repairShopController.RepairShop.Televisions, LbxGeneral);
            StlMain.Text = $"Телевизоров в ремонте: {_repairShopController.RepairShop.Televisions.Count}";

            // восстановить подсветку выбранного элемента, конечно, после восстановления привязки
            if (LbxGeneral.Items.Count > 0 && selectedIndex == LbxGeneral.Items.Count)
                LbxGeneral.SelectedIndex = LbxGeneral.Items.Count - 1;

            // сохранить изменения в коллекции
            _repairShopController.SerializeData();

            // обновить значения в комбобксах панели инструментов
            SetToolbarCombBoxes();
        } // ServeOut_Command


        // Изменение шрифта отображения коллекции телевизоров
        private void ListBoxFont_Command(object sender, EventArgs e) {
            if (FndListBox.ShowDialog() != DialogResult.OK) return;

            LbxGeneral.Font = LbxOrdered.Font = LbxSelected.Font = FndListBox.Font;
        } // ListBoxFont_Command


        // Изменение цвета фона ListBox' а отображения коллекции телевизоров
        private void ListBoxBackColor_Command(object sender, EventArgs e) {
            if (CldListBox.ShowDialog() != DialogResult.OK) return;

            LbxGeneral.BackColor = LbxOrdered.BackColor = LbxSelected.BackColor = CldListBox.Color;
        } // ListBoxBackColor_Command


        // Выбор цвета символов вывода телевизоров в ListBox
        private void ListBox_Color(object sender, EventArgs e) {
            if (CldListBox.ShowDialog() != DialogResult.OK) return;

            LbxGeneral.ForeColor = LbxOrdered.ForeColor = LbxSelected.ForeColor = CldListBox.Color;
        } // ListBox_Color

        // Загрузка файла данных
        private void LoadFile_Command(object sender, EventArgs e) {
            if (OfdMain.ShowDialog() != DialogResult.OK) return;

            // загрузка данных в контроллер
            _repairShopController.DataFileName = OfdMain.FileName;
            _repairShopController.DeserializeData();

            // формирование заголовка поля вывода данных о телевизорах
            LblHeaderGeneral.Text =
                $"  Ремонтная мастерская \"{_repairShopController.RepairShop.Title}\", " +
                $"{_repairShopController.RepairShop.Address}, телевизоры в ремонте\r\n" +
                $"{Television.Header}";

            // обновить привязку данных
            BindCollection(_repairShopController.RepairShop.Televisions, LbxGeneral);

            // вывести в строку состояния новые данные
            StlMain.Text = $"Телевизоров в ремонте: {_repairShopController.RepairShop.Televisions.Count}";
        } // LoadFile_Command


        // Сохранить файл данных с выбором имени файла
        private void SaveAsFile_Command(object sender, EventArgs e) {
            // выбор имени файла 
            if (SfdMain.ShowDialog() != DialogResult.OK) return;

            _repairShopController.DataFileName = SfdMain.FileName;
            _repairShopController.SerializeData();

            StlMain.Text = $"Данные сохранены в файле {_repairShopController.DataFileName}";
        } // SaveAsFile_Command


        // Разрешаем работу кнопок правки данных о телевизоре только на главной вкладке формы  
        private void TbcMain_SelectedIndexChanged(object sender, EventArgs e) {
            TsbAddTelevision.Enabled = TsbEditTelevision.Enabled =
                TsbRemoveTelevision.Enabled = TbcMain.SelectedTab == TbpGeneral;

            // при переходе на вкладки - запуск обработок
            if (TbcMain.SelectedTab == TbpOrdered)
                OrderByBrand_Command(sender, e);
            else if (TbcMain.SelectedTab == TbpSelected)
                SelectMinPrice_Command(sender, e);
        } // TbcMain_SelectedIndexChanged

    } // class MainForm
}
