﻿using System.Collections.Generic;
using System.Windows.Forms;

namespace TabControlsStdDialogs.Views
{
    public partial class ArtisanChoiceForm : Form
    {
        public ArtisanChoiceForm(): this(new List<string>()){ }

        public ArtisanChoiceForm(List<string> artisans) {
            InitializeComponent();

            // привязка к коллекции, выбор первого в списке мастера
            CbxArtisan.DataSource = artisans;
            CbxArtisan.Text = CbxArtisan.Items[0].ToString();
        } // ArtisanChoiceForm
           
        // вернуть выбранного мастера
        public string Artisan => CbxArtisan.Text;
    }
}
