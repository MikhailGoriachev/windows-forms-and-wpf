﻿using System;
using System.Windows.Forms;
using TabControlsStdDialogs.Helpers;
using TabControlsStdDialogs.Models;

namespace TabControlsStdDialogs.Views
{
    // форма для ввода/редактирования данных по ремонту телевизора
    public partial class TelevisionForm : Form
    {
        // данные по ремонту телевизора - для взаимодействия с контролами формы
        private Television _data;
        public Television Data {
            // собрать данные из полей формы в свойства объекта
            get {
                // данные собственно телевизора
                _data.Owner = TxbOwner.Text;
                _data.BrandModel = CbxBrandModel.Text;
                // из строкового представления диагонали убрать символ "
                _data.Diagonal = double.Parse(CbxDiagonal.Text.Replace(@"""", ""));
                
                // данные ремонта
                _data.Artisan = TxbArtisan.Text;
                _data.DefectDescription = TxbDefectDescription.Text;
                _data.Price = (int)NudPrice.Value;
                
                return _data;
            }

            // записать данные из свойств Television в поля формы
            set {
                _data = value;

                TxbOwner.Text = _data.Owner;
                CbxBrandModel.Text = CbxBrandModel.Items[CbxBrandModel.Items.IndexOf(_data.BrandModel)].ToString();
                CbxDiagonal.Text = CbxDiagonal.Items[CbxDiagonal.Items.IndexOf($"{_data.Diagonal:f1}\"")].ToString();

                TxbArtisan.Text = _data.Artisan;
                TxbDefectDescription.Text = _data.DefectDescription;
                NudPrice.Value = _data.Price;
            }
        } // Data

        // в конструктор по умолчанию передаем массив всех имен,
        // не массив имен мастеров 
        public TelevisionForm():this("Прием телевизора в ремонт", new Television()) {
        } // TelevisionForm


        // конструктор с параметрами
        public TelevisionForm(string title, Television data) {
            InitializeComponent();

            // Для комбобокса производителя и модели телевизора загрузить массив данных
            CbxBrandModel.DataSource = Utils.Brands;

            // Для комбобокса выбора диагонали загрузить массив данных
            Array.ForEach(Utils.Diagonals, d => CbxDiagonal.Items.Add($"{d:f1}\""));

            Text = title;
            Data = data;

            // снять выделение текста
            TxbOwner.SelectionStart = 0;
            TxbOwner.SelectionLength = 0;
        } // TelevisionForm
    } // class TelevisionForm
}
