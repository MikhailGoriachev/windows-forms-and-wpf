﻿using System.Collections.Generic;
using System.Windows.Forms;

namespace TabControlsStdDialogs.Views
{
    public partial class OwnerChoiceForm : Form
    {
        public OwnerChoiceForm() : this(new List<string>()) { }

        public OwnerChoiceForm(List<string> owners) {
            InitializeComponent();

            // привязка к коллекции, выбор первого в списке владельца
            CbxOwner.DataSource = owners;
            CbxOwner.Text = owners[0];
        } // OwnerChoiceForm


        // вернуть выбранного владльца
        public string TvOwner => CbxOwner.Text;
    } // class OwnerChoiceForm
}
