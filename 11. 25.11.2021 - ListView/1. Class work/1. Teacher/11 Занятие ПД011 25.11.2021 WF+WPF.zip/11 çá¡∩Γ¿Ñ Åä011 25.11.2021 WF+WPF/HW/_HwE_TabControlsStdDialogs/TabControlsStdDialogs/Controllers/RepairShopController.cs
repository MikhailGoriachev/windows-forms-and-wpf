﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization.Json;  // для JSON, добавить сборку System.Runtime.Serialization.dll
using TabControlsStdDialogs.Models;

namespace TabControlsStdDialogs.Controllers
{
    /*
     * Реализация функционала приложения
     *     • Упорядочивание коллекции телевизоров
     *         o По производителю и типу
     *         o По убыванию диагонали экрана
     *         o По мастеру, выполняющему ремонт
     *         o По владельцу телевизора
     *     • Выборка в коллекцию телевизоров с минимальной стоимостью ремонта
     *     • Выборка в коллекцию телевизоров, ремонтируемых заданным мастером
     *     • Выборка в коллекцию телевизоров с заданной диагональю экрана 
     */
    public class RepairShopController
    {
        // объект для обработки
        private RepairShop _repairShop;

        public RepairShop RepairShop {
            get => _repairShop;
            private set => _repairShop = value;
        } // RepairShop


        // имя файла для хранения данных ремонтной мастерской
        public string DataFileName { get; set; }


        // конструкторы
        // при создании RepairShop конструктором по умолчанию вызывается
        // метод формирования коллекции телевизоров для ремонта
        public RepairShopController():this(new RepairShop(), "repair_shop.json") { }

        public RepairShopController(RepairShop repairShop, string dataFileName) {
            _repairShop = repairShop;
            DataFileName = dataFileName;
        } // RepairShopController


        // Запрос на упорядочивание копии коллекции по производителю и типу
        public List<Television> OrderByBrand() {
            // получить копию коллекции телевизоров
            List<Television> list = new List<Television>(RepairShop.Televisions);
            
            // упорядочить копию коллекции телевизоров и вернуть эту копию
            list.Sort((t1, t2) => t1.BrandModel.CompareTo(t2.BrandModel));
            return list;
        } // OrderByBrand

        // Запрос на упорядочивание копии коллекции по убыванию диагонали экрана
        public List<Television> OrderByDiagonalDesc() {
            // получить копию коллекции телевизоров
            List<Television> list = new List<Television>(RepairShop.Televisions);

            // упорядочить копию коллекции телевизоров и вернуть эту копию
            list.Sort((t1, t2) => t2.Diagonal.CompareTo(t1.Diagonal));
            return list;
        } // OrderByDiagonalDesc


        // TODO: перенести созданине копии коллекции и вызоыв Sort() на копии в RepairShop
        // Запрос на упорядочивание копии коллекции по мастеру, выполняющему ремонт
        public List<Television> OrderByArtisan() {
            // получить копию коллекции телевизоров
            List<Television> list = new List<Television>(RepairShop.Televisions);

            // упорядочить копию коллекции телевизоров и вернуть эту копию
            list.Sort((t1, t2) => t2.Diagonal.CompareTo(t1.Diagonal));
            return list;
        } // OrderByArtisan


        // Запрос на упорядочивание копии коллекции по владельцу телевизора
        public List<Television> OrderByOwner() {
            // получить копию коллекции телевизоров
            List<Television> list = new List<Television>(RepairShop.Televisions);

            // упорядочить копию коллекции телевизоров и вернуть эту копию
            list.Sort((t1, t2) => t1.Owner.CompareTo(t2.Owner));
            return list;
        } // OrderByOwner


        // Запрос на упорядочивание копии коллекции по стоимости ремонта
        public List<Television> OrderByPrice() {
            // получить копию коллекции телевизоров
            List<Television> list = new List<Television>(RepairShop.Televisions);

            // упорядочить копию коллекции телевизоров и вернуть эту копию
            list.Sort((t1, t2) => t1.Price.CompareTo(t2.Price));
            return list;
        } // OrderByPrice


        // Запрос на выборку в коллекцию телевизоров с минимальной стоимостью ремонта
        public List<Television> SelectWhereMinPrice() {
            int minPrice = _repairShop.MinPrice();
            return _repairShop.Filter(t => t.Price == minPrice);
        } // SelectWhereMinPrice

        // Запрос на выборку в коллекцию телевизоров, ремонтируемых заданным мастером
        public List<Television> SelectWhereArtisan(string artisan) =>
            _repairShop.Filter(t => t.Artisan == artisan);

        // Запрос на выборку в коллекцию телевизоров с заданной диагональю экран
        public List<Television> SelectWhereDiagonal(double diagonal) =>
            _repairShop.Filter(t => Math.Abs(t.Diagonal - diagonal) < 1e-6);

        // Запрос на выборку в коллекцию телевизоров, принадлежащих заданному владельцу
        public List<Television> SelectWhereOwner(string owner) =>
            _repairShop.Filter(t => t.Owner == owner);


        // список мастеров из коллекции ремонтов
        public List<string> GetArtisans() {
            Dictionary<string, int> artisans = new Dictionary<string, int>();

            _repairShop.Televisions.ForEach(t => artisans[t.Artisan] = 0);

            return artisans.Keys.ToList();
        } // GetArtisans


        // список владельцев телевизоров из коллекции ремонтов
        public List<string> GetOwners() {
            Dictionary<string, int> owners = new Dictionary<string, int>();

            _repairShop.Televisions.ForEach(t => owners[t.Owner] = 0);

            return owners.Keys.ToList();
        } // GetOwners


        // создание новой ремонтной мастерской
        public void CreateNewRepairShop(string title, string address) =>
            _repairShop = new RepairShop(new List<Television>(), title, address);

        // -----------------------------------------------------------------------------------

        // сериализация данных в формате JSON
        public void SerializeData() {
            DataContractJsonSerializer jsonFormatter = new DataContractJsonSerializer(typeof(RepairShop));

            // Запись объекта в JSON-файл
            using (FileStream fs = new FileStream(DataFileName, FileMode.Create)) {
                jsonFormatter.WriteObject(fs, _repairShop);
            } // using
        } // SerializeData

        // десериализация данных из формата JSON
        public void DeserializeData() {
            DataContractJsonSerializer jsonFormatter = new DataContractJsonSerializer(typeof(RepairShop));

            // Читаем коллекцию из JSON-файла
            using (FileStream fs = new FileStream(DataFileName, FileMode.OpenOrCreate)) {
                _repairShop = (RepairShop)jsonFormatter.ReadObject(fs);
            } // using
        } // DeserializeData

    } // class RepairShopController
}
