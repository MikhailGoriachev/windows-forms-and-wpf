﻿using System;
using System.Windows.Forms;
using TabControlsStdDialogs.Helpers;

namespace TabControlsStdDialogs.Views
{
    public partial class DiagonalChoiceForm : Form
    {

        public DiagonalChoiceForm(){
            InitializeComponent();

            // Для комбобокса выбора диагонали загрузить массив данных
            Array.ForEach(Utils.Diagonals, d => CbxDiagonal.Items.Add($"{d:f1}\""));
            CbxDiagonal.Text = CbxDiagonal.Items[0].ToString();
        } // ArtisanChoiceForm

        // вернуть выбранную диагональ
        public string Diagonal => CbxDiagonal.Text;
    } // class DiagonalChoiceForm
}
