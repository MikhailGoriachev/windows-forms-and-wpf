﻿namespace TabControlsStdDialogs.Views
{
    partial class MainForm
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.MnsMain = new System.Windows.Forms.MenuStrip();
            this.MniFile = new System.Windows.Forms.ToolStripMenuItem();
            this.MniFileOpen = new System.Windows.Forms.ToolStripMenuItem();
            this.MniFileSave = new System.Windows.Forms.ToolStripMenuItem();
            this.MniFileSaveAs = new System.Windows.Forms.ToolStripMenuItem();
            this.MniFileSep1 = new System.Windows.Forms.ToolStripSeparator();
            this.MniFileExit = new System.Windows.Forms.ToolStripMenuItem();
            this.MniRepairShop = new System.Windows.Forms.ToolStripMenuItem();
            this.MniRepairShopNew = new System.Windows.Forms.ToolStripMenuItem();
            this.MniRepairShopEdit = new System.Windows.Forms.ToolStripMenuItem();
            this.MniTelevisions = new System.Windows.Forms.ToolStripMenuItem();
            this.MniTelevisionsAdd = new System.Windows.Forms.ToolStripMenuItem();
            this.MniTelevisionsEdit = new System.Windows.Forms.ToolStripMenuItem();
            this.MniTelevisionsSep1 = new System.Windows.Forms.ToolStripSeparator();
            this.MniTelevisionsRemoveAt = new System.Windows.Forms.ToolStripMenuItem();
            this.MniOrderBy = new System.Windows.Forms.ToolStripMenuItem();
            this.MniOrderByBrand = new System.Windows.Forms.ToolStripMenuItem();
            this.MniOrderByDiagonalDesc = new System.Windows.Forms.ToolStripMenuItem();
            this.MniOrderByArtisan = new System.Windows.Forms.ToolStripMenuItem();
            this.MniOrderByOwner = new System.Windows.Forms.ToolStripMenuItem();
            this.MniOrderByPrice = new System.Windows.Forms.ToolStripMenuItem();
            this.MniSelectWhere = new System.Windows.Forms.ToolStripMenuItem();
            this.MniSelectWhereInexpensive = new System.Windows.Forms.ToolStripMenuItem();
            this.MniSelectWhereArtisan = new System.Windows.Forms.ToolStripMenuItem();
            this.MniSelectWhereDiagonal = new System.Windows.Forms.ToolStripMenuItem();
            this.MniSelectSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.MniSelectWhereOwner = new System.Windows.Forms.ToolStripMenuItem();
            this.MniSettings = new System.Windows.Forms.ToolStripMenuItem();
            this.MniSettingsFont = new System.Windows.Forms.ToolStripMenuItem();
            this.MniSettingsBackColor = new System.Windows.Forms.ToolStripMenuItem();
            this.MniSettingsColor = new System.Windows.Forms.ToolStripMenuItem();
            this.MniSettingsSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.MniSettingsToTray = new System.Windows.Forms.ToolStripMenuItem();
            this.MniHelp = new System.Windows.Forms.ToolStripMenuItem();
            this.MniHelpAbout = new System.Windows.Forms.ToolStripMenuItem();
            this.TbsMain = new System.Windows.Forms.ToolStrip();
            this.TsbFileOpen = new System.Windows.Forms.ToolStripButton();
            this.TsbFileSave = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.TsbNewRepairShop = new System.Windows.Forms.ToolStripButton();
            this.TsbEditRepairShop = new System.Windows.Forms.ToolStripButton();
            this.TsbSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.TsbAddTelevision = new System.Windows.Forms.ToolStripButton();
            this.TsbEditTelevision = new System.Windows.Forms.ToolStripButton();
            this.TsbRemoveTelevision = new System.Windows.Forms.ToolStripButton();
            this.TsbSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.TsdOrderBy = new System.Windows.Forms.ToolStripDropDownButton();
            this.DmiOrderByBrand = new System.Windows.Forms.ToolStripMenuItem();
            this.DmiOrderByDiagonalDesc = new System.Windows.Forms.ToolStripMenuItem();
            this.DmiOrderByArtisan = new System.Windows.Forms.ToolStripMenuItem();
            this.DmiOrderByOwner = new System.Windows.Forms.ToolStripMenuItem();
            this.DmiOrderByPrice = new System.Windows.Forms.ToolStripMenuItem();
            this.TsbSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.TsbMinPrice = new System.Windows.Forms.ToolStripButton();
            this.CbxArtisans = new System.Windows.Forms.ToolStripComboBox();
            this.TsbArtisanSelection = new System.Windows.Forms.ToolStripButton();
            this.CbxDiagonal = new System.Windows.Forms.ToolStripComboBox();
            this.TsbDiagonalSelection = new System.Windows.Forms.ToolStripButton();
            this.CbxOwners = new System.Windows.Forms.ToolStripComboBox();
            this.TsbOwnerSelection = new System.Windows.Forms.ToolStripButton();
            this.TsbSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.TsbToTray = new System.Windows.Forms.ToolStripButton();
            this.TsbAbout = new System.Windows.Forms.ToolStripButton();
            this.TsbExit = new System.Windows.Forms.ToolStripButton();
            this.StsMain = new System.Windows.Forms.StatusStrip();
            this.StlMain = new System.Windows.Forms.ToolStripStatusLabel();
            this.CmnTelevisions = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.CmiTelevisionsAdd = new System.Windows.Forms.ToolStripMenuItem();
            this.CmiTelevisionsEdit = new System.Windows.Forms.ToolStripMenuItem();
            this.CmiTelevisionsRemoveAt = new System.Windows.Forms.ToolStripMenuItem();
            this.CmiTelevisionSep1 = new System.Windows.Forms.ToolStripSeparator();
            this.CmiTelevisionsAbout = new System.Windows.Forms.ToolStripMenuItem();
            this.CmiTelevisionsExit = new System.Windows.Forms.ToolStripMenuItem();
            this.CmnForm = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.CmiFormNewRepairShop = new System.Windows.Forms.ToolStripMenuItem();
            this.CmiFormEditRepairShop = new System.Windows.Forms.ToolStripMenuItem();
            this.CmiFormSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.CmiFormAbout = new System.Windows.Forms.ToolStripMenuItem();
            this.CmiFormSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.CmiFormExit = new System.Windows.Forms.ToolStripMenuItem();
            this.OfdMain = new System.Windows.Forms.OpenFileDialog();
            this.SfdMain = new System.Windows.Forms.SaveFileDialog();
            this.FndListBox = new System.Windows.Forms.FontDialog();
            this.CldListBox = new System.Windows.Forms.ColorDialog();
            this.NtiMain = new System.Windows.Forms.NotifyIcon(this.components);
            this.CmnNotify = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.CmiNotifyRestore = new System.Windows.Forms.ToolStripMenuItem();
            this.CmiNotifySeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.CmiNotifyAbout = new System.Windows.Forms.ToolStripMenuItem();
            this.CmiNotifySeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.CmiNotifyExit = new System.Windows.Forms.ToolStripMenuItem();
            this.TbcMain = new System.Windows.Forms.TabControl();
            this.TbpGeneral = new System.Windows.Forms.TabPage();
            this.LbxGeneral = new System.Windows.Forms.ListBox();
            this.LblHeaderGeneral = new System.Windows.Forms.Label();
            this.TbpOrdered = new System.Windows.Forms.TabPage();
            this.LbxOrdered = new System.Windows.Forms.ListBox();
            this.LblHeaderOrdered = new System.Windows.Forms.Label();
            this.TbpSelected = new System.Windows.Forms.TabPage();
            this.LbxSelected = new System.Windows.Forms.ListBox();
            this.LblHeaderSelected = new System.Windows.Forms.Label();
            this.ImlTabMain = new System.Windows.Forms.ImageList(this.components);
            this.MnsMain.SuspendLayout();
            this.TbsMain.SuspendLayout();
            this.StsMain.SuspendLayout();
            this.CmnTelevisions.SuspendLayout();
            this.CmnForm.SuspendLayout();
            this.CmnNotify.SuspendLayout();
            this.TbcMain.SuspendLayout();
            this.TbpGeneral.SuspendLayout();
            this.TbpOrdered.SuspendLayout();
            this.TbpSelected.SuspendLayout();
            this.SuspendLayout();
            // 
            // MnsMain
            // 
            this.MnsMain.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.MnsMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniFile,
            this.MniRepairShop,
            this.MniTelevisions,
            this.MniOrderBy,
            this.MniSelectWhere,
            this.MniSettings,
            this.MniHelp});
            this.MnsMain.Location = new System.Drawing.Point(0, 0);
            this.MnsMain.Name = "MnsMain";
            this.MnsMain.Size = new System.Drawing.Size(1169, 29);
            this.MnsMain.TabIndex = 0;
            this.MnsMain.Text = "menuStrip1";
            // 
            // MniFile
            // 
            this.MniFile.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniFileOpen,
            this.MniFileSave,
            this.MniFileSaveAs,
            this.MniFileSep1,
            this.MniFileExit});
            this.MniFile.Name = "MniFile";
            this.MniFile.Size = new System.Drawing.Size(59, 25);
            this.MniFile.Text = "Файл";
            // 
            // MniFileOpen
            // 
            this.MniFileOpen.Image = global::TabControlsStdDialogs.Properties.Resources.folder_blue;
            this.MniFileOpen.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MniFileOpen.Name = "MniFileOpen";
            this.MniFileOpen.Size = new System.Drawing.Size(209, 38);
            this.MniFileOpen.Text = "Открыть...";
            this.MniFileOpen.Click += new System.EventHandler(this.LoadFile_Command);
            // 
            // MniFileSave
            // 
            this.MniFileSave.Image = global::TabControlsStdDialogs.Properties.Resources.mario;
            this.MniFileSave.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MniFileSave.Name = "MniFileSave";
            this.MniFileSave.Size = new System.Drawing.Size(209, 38);
            this.MniFileSave.Text = "Сохранить";
            // 
            // MniFileSaveAs
            // 
            this.MniFileSaveAs.Image = global::TabControlsStdDialogs.Properties.Resources.save_as;
            this.MniFileSaveAs.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MniFileSaveAs.Name = "MniFileSaveAs";
            this.MniFileSaveAs.Size = new System.Drawing.Size(209, 38);
            this.MniFileSaveAs.Text = "Сохранить как...";
            this.MniFileSaveAs.Click += new System.EventHandler(this.SaveAsFile_Command);
            // 
            // MniFileSep1
            // 
            this.MniFileSep1.Name = "MniFileSep1";
            this.MniFileSep1.Size = new System.Drawing.Size(206, 6);
            // 
            // MniFileExit
            // 
            this.MniFileExit.Image = global::TabControlsStdDialogs.Properties.Resources.door_out;
            this.MniFileExit.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MniFileExit.Name = "MniFileExit";
            this.MniFileExit.Size = new System.Drawing.Size(209, 38);
            this.MniFileExit.Text = "Выход";
            this.MniFileExit.Click += new System.EventHandler(this.Exit_Command);
            // 
            // MniRepairShop
            // 
            this.MniRepairShop.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniRepairShopNew,
            this.MniRepairShopEdit});
            this.MniRepairShop.Name = "MniRepairShop";
            this.MniRepairShop.Size = new System.Drawing.Size(106, 25);
            this.MniRepairShop.Text = "Мастерская";
            // 
            // MniRepairShopNew
            // 
            this.MniRepairShopNew.Image = global::TabControlsStdDialogs.Properties.Resources._new;
            this.MniRepairShopNew.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MniRepairShopNew.Name = "MniRepairShopNew";
            this.MniRepairShopNew.Size = new System.Drawing.Size(176, 38);
            this.MniRepairShopNew.Text = "Новая...";
            this.MniRepairShopNew.Click += new System.EventHandler(this.NewRepairShop_Command);
            // 
            // MniRepairShopEdit
            // 
            this.MniRepairShopEdit.Image = global::TabControlsStdDialogs.Properties.Resources.edit_button;
            this.MniRepairShopEdit.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MniRepairShopEdit.Name = "MniRepairShopEdit";
            this.MniRepairShopEdit.Size = new System.Drawing.Size(176, 38);
            this.MniRepairShopEdit.Text = "Изменить...";
            this.MniRepairShopEdit.Click += new System.EventHandler(this.EditRepairShop_Command);
            // 
            // MniTelevisions
            // 
            this.MniTelevisions.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniTelevisionsAdd,
            this.MniTelevisionsEdit,
            this.MniTelevisionsSep1,
            this.MniTelevisionsRemoveAt});
            this.MniTelevisions.Name = "MniTelevisions";
            this.MniTelevisions.Size = new System.Drawing.Size(180, 25);
            this.MniTelevisions.Text = "Ремонты телевизоров";
            // 
            // MniTelevisionsAdd
            // 
            this.MniTelevisionsAdd.Image = global::TabControlsStdDialogs.Properties.Resources.add;
            this.MniTelevisionsAdd.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MniTelevisionsAdd.Name = "MniTelevisionsAdd";
            this.MniTelevisionsAdd.Size = new System.Drawing.Size(235, 38);
            this.MniTelevisionsAdd.Text = "Принять в ремонт...";
            this.MniTelevisionsAdd.Click += new System.EventHandler(this.AddTelevision_Command);
            // 
            // MniTelevisionsEdit
            // 
            this.MniTelevisionsEdit.Image = global::TabControlsStdDialogs.Properties.Resources.edit_mx_entry;
            this.MniTelevisionsEdit.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MniTelevisionsEdit.Name = "MniTelevisionsEdit";
            this.MniTelevisionsEdit.Size = new System.Drawing.Size(235, 38);
            this.MniTelevisionsEdit.Text = "Изменить...";
            this.MniTelevisionsEdit.Click += new System.EventHandler(this.EditTelevision_Command);
            // 
            // MniTelevisionsSep1
            // 
            this.MniTelevisionsSep1.Name = "MniTelevisionsSep1";
            this.MniTelevisionsSep1.Size = new System.Drawing.Size(232, 6);
            // 
            // MniTelevisionsRemoveAt
            // 
            this.MniTelevisionsRemoveAt.Image = global::TabControlsStdDialogs.Properties.Resources.delete;
            this.MniTelevisionsRemoveAt.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MniTelevisionsRemoveAt.Name = "MniTelevisionsRemoveAt";
            this.MniTelevisionsRemoveAt.Size = new System.Drawing.Size(235, 38);
            this.MniTelevisionsRemoveAt.Text = "Выдать";
            this.MniTelevisionsRemoveAt.Click += new System.EventHandler(this.ServeOut_Command);
            // 
            // MniOrderBy
            // 
            this.MniOrderBy.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniOrderByBrand,
            this.MniOrderByDiagonalDesc,
            this.MniOrderByArtisan,
            this.MniOrderByOwner,
            this.MniOrderByPrice});
            this.MniOrderBy.Name = "MniOrderBy";
            this.MniOrderBy.Size = new System.Drawing.Size(108, 25);
            this.MniOrderBy.Text = "Сортировка";
            // 
            // MniOrderByBrand
            // 
            this.MniOrderByBrand.Image = global::TabControlsStdDialogs.Properties.Resources.sort_asc_az;
            this.MniOrderByBrand.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MniOrderByBrand.Name = "MniOrderByBrand";
            this.MniOrderByBrand.Size = new System.Drawing.Size(274, 38);
            this.MniOrderByBrand.Text = "По производителю";
            this.MniOrderByBrand.Click += new System.EventHandler(this.OrderByBrand_Command);
            // 
            // MniOrderByDiagonalDesc
            // 
            this.MniOrderByDiagonalDesc.Image = global::TabControlsStdDialogs.Properties.Resources.sort_number_descending;
            this.MniOrderByDiagonalDesc.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MniOrderByDiagonalDesc.Name = "MniOrderByDiagonalDesc";
            this.MniOrderByDiagonalDesc.Size = new System.Drawing.Size(274, 38);
            this.MniOrderByDiagonalDesc.Text = "По убыванию диагонали";
            this.MniOrderByDiagonalDesc.Click += new System.EventHandler(this.OrderByDiagonalDesc_Command);
            // 
            // MniOrderByArtisan
            // 
            this.MniOrderByArtisan.Image = global::TabControlsStdDialogs.Properties.Resources.sort_alphabel;
            this.MniOrderByArtisan.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MniOrderByArtisan.Name = "MniOrderByArtisan";
            this.MniOrderByArtisan.Size = new System.Drawing.Size(274, 38);
            this.MniOrderByArtisan.Text = "По мастеру";
            this.MniOrderByArtisan.Click += new System.EventHandler(this.OrderByArtisan_Command);
            // 
            // MniOrderByOwner
            // 
            this.MniOrderByOwner.Image = global::TabControlsStdDialogs.Properties.Resources.sort_alphabel_column;
            this.MniOrderByOwner.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MniOrderByOwner.Name = "MniOrderByOwner";
            this.MniOrderByOwner.Size = new System.Drawing.Size(274, 38);
            this.MniOrderByOwner.Text = "По владельцу";
            this.MniOrderByOwner.Click += new System.EventHandler(this.OrderByOwner_Command);
            // 
            // MniOrderByPrice
            // 
            this.MniOrderByPrice.Image = global::TabControlsStdDialogs.Properties.Resources.sort_number;
            this.MniOrderByPrice.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MniOrderByPrice.Name = "MniOrderByPrice";
            this.MniOrderByPrice.Size = new System.Drawing.Size(274, 38);
            this.MniOrderByPrice.Text = "По стоимости ремонта";
            this.MniOrderByPrice.Click += new System.EventHandler(this.OrderByPrice_Command);
            // 
            // MniSelectWhere
            // 
            this.MniSelectWhere.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniSelectWhereInexpensive,
            this.MniSelectWhereArtisan,
            this.MniSelectWhereDiagonal,
            this.MniSelectSeparator1,
            this.MniSelectWhereOwner});
            this.MniSelectWhere.Name = "MniSelectWhere";
            this.MniSelectWhere.Size = new System.Drawing.Size(85, 25);
            this.MniSelectWhere.Text = "Выборка";
            // 
            // MniSelectWhereInexpensive
            // 
            this.MniSelectWhereInexpensive.Image = global::TabControlsStdDialogs.Properties.Resources.money;
            this.MniSelectWhereInexpensive.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MniSelectWhereInexpensive.Name = "MniSelectWhereInexpensive";
            this.MniSelectWhereInexpensive.Size = new System.Drawing.Size(301, 38);
            this.MniSelectWhereInexpensive.Text = "Самые недорогие ремонты...";
            this.MniSelectWhereInexpensive.Click += new System.EventHandler(this.SelectMinPrice_Command);
            // 
            // MniSelectWhereArtisan
            // 
            this.MniSelectWhereArtisan.Image = global::TabControlsStdDialogs.Properties.Resources.user_ironman;
            this.MniSelectWhereArtisan.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MniSelectWhereArtisan.Name = "MniSelectWhereArtisan";
            this.MniSelectWhereArtisan.Size = new System.Drawing.Size(301, 38);
            this.MniSelectWhereArtisan.Text = "Ремонты мастера...";
            this.MniSelectWhereArtisan.Click += new System.EventHandler(this.SelectArtisan_Command);
            // 
            // MniSelectWhereDiagonal
            // 
            this.MniSelectWhereDiagonal.Image = global::TabControlsStdDialogs.Properties.Resources.ruler;
            this.MniSelectWhereDiagonal.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MniSelectWhereDiagonal.Name = "MniSelectWhereDiagonal";
            this.MniSelectWhereDiagonal.Size = new System.Drawing.Size(301, 38);
            this.MniSelectWhereDiagonal.Text = "Телевизоры с диагональю...";
            this.MniSelectWhereDiagonal.Click += new System.EventHandler(this.SelectDiagonal_Command);
            // 
            // MniSelectSeparator1
            // 
            this.MniSelectSeparator1.Name = "MniSelectSeparator1";
            this.MniSelectSeparator1.Size = new System.Drawing.Size(298, 6);
            // 
            // MniSelectWhereOwner
            // 
            this.MniSelectWhereOwner.Image = global::TabControlsStdDialogs.Properties.Resources.user_catwomen;
            this.MniSelectWhereOwner.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MniSelectWhereOwner.Name = "MniSelectWhereOwner";
            this.MniSelectWhereOwner.Size = new System.Drawing.Size(301, 38);
            this.MniSelectWhereOwner.Text = "Телевизоры владельца...";
            this.MniSelectWhereOwner.Click += new System.EventHandler(this.SelectOwner_Command);
            // 
            // MniSettings
            // 
            this.MniSettings.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniSettingsFont,
            this.MniSettingsBackColor,
            this.MniSettingsColor,
            this.MniSettingsSeparator1,
            this.MniSettingsToTray});
            this.MniSettings.Name = "MniSettings";
            this.MniSettings.Size = new System.Drawing.Size(99, 25);
            this.MniSettings.Text = "Настройки";
            // 
            // MniSettingsFont
            // 
            this.MniSettingsFont.Image = global::TabControlsStdDialogs.Properties.Resources.font;
            this.MniSettingsFont.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MniSettingsFont.Name = "MniSettingsFont";
            this.MniSettingsFont.Size = new System.Drawing.Size(340, 38);
            this.MniSettingsFont.Text = "Шрифт вывода телевизоров...";
            this.MniSettingsFont.Click += new System.EventHandler(this.ListBoxFont_Command);
            // 
            // MniSettingsBackColor
            // 
            this.MniSettingsBackColor.Image = global::TabControlsStdDialogs.Properties.Resources.color_management;
            this.MniSettingsBackColor.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MniSettingsBackColor.Name = "MniSettingsBackColor";
            this.MniSettingsBackColor.Size = new System.Drawing.Size(340, 38);
            this.MniSettingsBackColor.Text = "Фон вывода телевизоров...";
            this.MniSettingsBackColor.Click += new System.EventHandler(this.ListBoxBackColor_Command);
            // 
            // MniSettingsColor
            // 
            this.MniSettingsColor.Image = global::TabControlsStdDialogs.Properties.Resources.font_colors;
            this.MniSettingsColor.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MniSettingsColor.Name = "MniSettingsColor";
            this.MniSettingsColor.Size = new System.Drawing.Size(340, 38);
            this.MniSettingsColor.Text = "Цвет текста вывода телевизоров...";
            this.MniSettingsColor.Click += new System.EventHandler(this.ListBox_Color);
            // 
            // MniSettingsSeparator1
            // 
            this.MniSettingsSeparator1.Name = "MniSettingsSeparator1";
            this.MniSettingsSeparator1.Size = new System.Drawing.Size(337, 6);
            // 
            // MniSettingsToTray
            // 
            this.MniSettingsToTray.Image = global::TabControlsStdDialogs.Properties.Resources.hand_point_270;
            this.MniSettingsToTray.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MniSettingsToTray.Name = "MniSettingsToTray";
            this.MniSettingsToTray.Size = new System.Drawing.Size(340, 38);
            this.MniSettingsToTray.Text = "Свернуть в трей";
            this.MniSettingsToTray.Click += new System.EventHandler(this.ToTray_Command);
            // 
            // MniHelp
            // 
            this.MniHelp.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniHelpAbout});
            this.MniHelp.Name = "MniHelp";
            this.MniHelp.Size = new System.Drawing.Size(82, 25);
            this.MniHelp.Text = "Справка";
            // 
            // MniHelpAbout
            // 
            this.MniHelpAbout.Image = global::TabControlsStdDialogs.Properties.Resources.help;
            this.MniHelpAbout.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MniHelpAbout.Name = "MniHelpAbout";
            this.MniHelpAbout.Size = new System.Drawing.Size(201, 38);
            this.MniHelpAbout.Text = "О программе...";
            this.MniHelpAbout.Click += new System.EventHandler(this.About_Command);
            // 
            // TbsMain
            // 
            this.TbsMain.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TbsMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.TsbFileOpen,
            this.TsbFileSave,
            this.toolStripSeparator1,
            this.TsbNewRepairShop,
            this.TsbEditRepairShop,
            this.TsbSeparator1,
            this.TsbAddTelevision,
            this.TsbEditTelevision,
            this.TsbRemoveTelevision,
            this.TsbSeparator2,
            this.TsdOrderBy,
            this.TsbSeparator3,
            this.TsbMinPrice,
            this.CbxArtisans,
            this.TsbArtisanSelection,
            this.CbxDiagonal,
            this.TsbDiagonalSelection,
            this.CbxOwners,
            this.TsbOwnerSelection,
            this.TsbSeparator4,
            this.TsbToTray,
            this.TsbAbout,
            this.TsbExit});
            this.TbsMain.Location = new System.Drawing.Point(0, 29);
            this.TbsMain.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.TbsMain.Name = "TbsMain";
            this.TbsMain.Size = new System.Drawing.Size(1169, 39);
            this.TbsMain.TabIndex = 1;
            this.TbsMain.Text = "toolStrip1";
            // 
            // TsbFileOpen
            // 
            this.TsbFileOpen.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbFileOpen.Image = global::TabControlsStdDialogs.Properties.Resources.folder_blue;
            this.TsbFileOpen.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbFileOpen.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbFileOpen.Name = "TsbFileOpen";
            this.TsbFileOpen.Size = new System.Drawing.Size(36, 36);
            this.TsbFileOpen.ToolTipText = "Открвыть файл данных\r\nремонтной мастерской";
            // 
            // TsbFileSave
            // 
            this.TsbFileSave.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbFileSave.Image = global::TabControlsStdDialogs.Properties.Resources.save_as;
            this.TsbFileSave.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbFileSave.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbFileSave.Name = "TsbFileSave";
            this.TsbFileSave.Size = new System.Drawing.Size(36, 36);
            this.TsbFileSave.ToolTipText = "Сохранить файл данных \r\nремонтной мастерской";
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 39);
            // 
            // TsbNewRepairShop
            // 
            this.TsbNewRepairShop.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbNewRepairShop.Image = global::TabControlsStdDialogs.Properties.Resources._new;
            this.TsbNewRepairShop.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbNewRepairShop.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbNewRepairShop.Name = "TsbNewRepairShop";
            this.TsbNewRepairShop.Size = new System.Drawing.Size(36, 36);
            this.TsbNewRepairShop.ToolTipText = "Создание новой ремонтной мастерской";
            this.TsbNewRepairShop.Click += new System.EventHandler(this.NewRepairShop_Command);
            // 
            // TsbEditRepairShop
            // 
            this.TsbEditRepairShop.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbEditRepairShop.Image = global::TabControlsStdDialogs.Properties.Resources.edit_button;
            this.TsbEditRepairShop.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbEditRepairShop.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbEditRepairShop.Name = "TsbEditRepairShop";
            this.TsbEditRepairShop.Size = new System.Drawing.Size(36, 36);
            this.TsbEditRepairShop.ToolTipText = "Редактирование данных ремонтной мастерской";
            this.TsbEditRepairShop.Click += new System.EventHandler(this.EditRepairShop_Command);
            // 
            // TsbSeparator1
            // 
            this.TsbSeparator1.Name = "TsbSeparator1";
            this.TsbSeparator1.Size = new System.Drawing.Size(6, 39);
            // 
            // TsbAddTelevision
            // 
            this.TsbAddTelevision.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbAddTelevision.Image = global::TabControlsStdDialogs.Properties.Resources.add;
            this.TsbAddTelevision.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbAddTelevision.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbAddTelevision.Name = "TsbAddTelevision";
            this.TsbAddTelevision.Size = new System.Drawing.Size(36, 36);
            this.TsbAddTelevision.ToolTipText = "Принять телевизор в ремонт";
            this.TsbAddTelevision.Click += new System.EventHandler(this.AddTelevision_Command);
            // 
            // TsbEditTelevision
            // 
            this.TsbEditTelevision.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbEditTelevision.Image = global::TabControlsStdDialogs.Properties.Resources.edit_mx_entry;
            this.TsbEditTelevision.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbEditTelevision.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbEditTelevision.Name = "TsbEditTelevision";
            this.TsbEditTelevision.Size = new System.Drawing.Size(36, 36);
            this.TsbEditTelevision.ToolTipText = "Редактирование данных \r\nремонтируемого телевизора";
            this.TsbEditTelevision.Click += new System.EventHandler(this.EditTelevision_Command);
            // 
            // TsbRemoveTelevision
            // 
            this.TsbRemoveTelevision.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbRemoveTelevision.Image = global::TabControlsStdDialogs.Properties.Resources.delete;
            this.TsbRemoveTelevision.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbRemoveTelevision.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbRemoveTelevision.Name = "TsbRemoveTelevision";
            this.TsbRemoveTelevision.Size = new System.Drawing.Size(36, 36);
            this.TsbRemoveTelevision.ToolTipText = "Выдача телевизора\r\nвладельцу";
            this.TsbRemoveTelevision.Click += new System.EventHandler(this.ServeOut_Command);
            // 
            // TsbSeparator2
            // 
            this.TsbSeparator2.Name = "TsbSeparator2";
            this.TsbSeparator2.Size = new System.Drawing.Size(6, 39);
            // 
            // TsdOrderBy
            // 
            this.TsdOrderBy.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsdOrderBy.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.DmiOrderByBrand,
            this.DmiOrderByDiagonalDesc,
            this.DmiOrderByArtisan,
            this.DmiOrderByOwner,
            this.DmiOrderByPrice});
            this.TsdOrderBy.Image = global::TabControlsStdDialogs.Properties.Resources.sort;
            this.TsdOrderBy.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsdOrderBy.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsdOrderBy.Name = "TsdOrderBy";
            this.TsdOrderBy.Size = new System.Drawing.Size(45, 36);
            this.TsdOrderBy.Text = "Сортировка";
            this.TsdOrderBy.ToolTipText = "Сортировка коллекции \r\nтелевизоров";
            // 
            // DmiOrderByBrand
            // 
            this.DmiOrderByBrand.Image = global::TabControlsStdDialogs.Properties.Resources.sort_asc_az;
            this.DmiOrderByBrand.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.DmiOrderByBrand.Name = "DmiOrderByBrand";
            this.DmiOrderByBrand.Size = new System.Drawing.Size(274, 38);
            this.DmiOrderByBrand.Text = "По производителю";
            this.DmiOrderByBrand.Click += new System.EventHandler(this.OrderByBrand_Command);
            // 
            // DmiOrderByDiagonalDesc
            // 
            this.DmiOrderByDiagonalDesc.Image = global::TabControlsStdDialogs.Properties.Resources.sort_number_descending;
            this.DmiOrderByDiagonalDesc.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.DmiOrderByDiagonalDesc.Name = "DmiOrderByDiagonalDesc";
            this.DmiOrderByDiagonalDesc.Size = new System.Drawing.Size(274, 38);
            this.DmiOrderByDiagonalDesc.Text = "По убыванию диагонали";
            this.DmiOrderByDiagonalDesc.Click += new System.EventHandler(this.OrderByDiagonalDesc_Command);
            // 
            // DmiOrderByArtisan
            // 
            this.DmiOrderByArtisan.Image = global::TabControlsStdDialogs.Properties.Resources.sort_alphabel;
            this.DmiOrderByArtisan.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.DmiOrderByArtisan.Name = "DmiOrderByArtisan";
            this.DmiOrderByArtisan.Size = new System.Drawing.Size(274, 38);
            this.DmiOrderByArtisan.Text = "По мастеру";
            this.DmiOrderByArtisan.Click += new System.EventHandler(this.OrderByArtisan_Command);
            // 
            // DmiOrderByOwner
            // 
            this.DmiOrderByOwner.Image = global::TabControlsStdDialogs.Properties.Resources.sort_alphabel_column;
            this.DmiOrderByOwner.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.DmiOrderByOwner.Name = "DmiOrderByOwner";
            this.DmiOrderByOwner.Size = new System.Drawing.Size(274, 38);
            this.DmiOrderByOwner.Text = "По владельцу";
            this.DmiOrderByOwner.Click += new System.EventHandler(this.OrderByOwner_Command);
            // 
            // DmiOrderByPrice
            // 
            this.DmiOrderByPrice.Image = global::TabControlsStdDialogs.Properties.Resources.sort_number;
            this.DmiOrderByPrice.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.DmiOrderByPrice.Name = "DmiOrderByPrice";
            this.DmiOrderByPrice.Size = new System.Drawing.Size(274, 38);
            this.DmiOrderByPrice.Text = "По стоимости ремонта";
            this.DmiOrderByPrice.Click += new System.EventHandler(this.OrderByPrice_Command);
            // 
            // TsbSeparator3
            // 
            this.TsbSeparator3.Name = "TsbSeparator3";
            this.TsbSeparator3.Size = new System.Drawing.Size(6, 39);
            // 
            // TsbMinPrice
            // 
            this.TsbMinPrice.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbMinPrice.Image = global::TabControlsStdDialogs.Properties.Resources.money;
            this.TsbMinPrice.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbMinPrice.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbMinPrice.Name = "TsbMinPrice";
            this.TsbMinPrice.Size = new System.Drawing.Size(36, 36);
            this.TsbMinPrice.ToolTipText = "Выборка самых недорогие ремонты";
            this.TsbMinPrice.Click += new System.EventHandler(this.SelectMinPrice_Command);
            // 
            // CbxArtisans
            // 
            this.CbxArtisans.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CbxArtisans.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.CbxArtisans.Margin = new System.Windows.Forms.Padding(6, 0, 1, 0);
            this.CbxArtisans.Name = "CbxArtisans";
            this.CbxArtisans.Size = new System.Drawing.Size(121, 39);
            this.CbxArtisans.ToolTipText = "Мастер, ведущий ремонт";
            // 
            // TsbArtisanSelection
            // 
            this.TsbArtisanSelection.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbArtisanSelection.Image = global::TabControlsStdDialogs.Properties.Resources.user_ironman;
            this.TsbArtisanSelection.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbArtisanSelection.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbArtisanSelection.Margin = new System.Windows.Forms.Padding(0, 1, 6, 2);
            this.TsbArtisanSelection.Name = "TsbArtisanSelection";
            this.TsbArtisanSelection.Size = new System.Drawing.Size(36, 36);
            this.TsbArtisanSelection.ToolTipText = "Выборка ремонтов заданного мастера";
            this.TsbArtisanSelection.Click += new System.EventHandler(this.SelectArtisanTbr_Command);
            // 
            // CbxDiagonal
            // 
            this.CbxDiagonal.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CbxDiagonal.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.CbxDiagonal.Margin = new System.Windows.Forms.Padding(6, 0, 1, 0);
            this.CbxDiagonal.Name = "CbxDiagonal";
            this.CbxDiagonal.Size = new System.Drawing.Size(121, 39);
            this.CbxDiagonal.ToolTipText = "Выбор диагонали телевизора";
            // 
            // TsbDiagonalSelection
            // 
            this.TsbDiagonalSelection.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbDiagonalSelection.Image = global::TabControlsStdDialogs.Properties.Resources.ruler;
            this.TsbDiagonalSelection.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbDiagonalSelection.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbDiagonalSelection.Margin = new System.Windows.Forms.Padding(0, 1, 6, 2);
            this.TsbDiagonalSelection.Name = "TsbDiagonalSelection";
            this.TsbDiagonalSelection.Size = new System.Drawing.Size(36, 36);
            this.TsbDiagonalSelection.ToolTipText = "Выборка телевизоров \r\nс заданной диагональю";
            this.TsbDiagonalSelection.Click += new System.EventHandler(this.SelectDiagonalTbr_Command);
            // 
            // CbxOwners
            // 
            this.CbxOwners.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CbxOwners.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.CbxOwners.Margin = new System.Windows.Forms.Padding(6, 0, 1, 0);
            this.CbxOwners.Name = "CbxOwners";
            this.CbxOwners.Size = new System.Drawing.Size(121, 39);
            this.CbxOwners.ToolTipText = "Владелец телевизора";
            // 
            // TsbOwnerSelection
            // 
            this.TsbOwnerSelection.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbOwnerSelection.Image = global::TabControlsStdDialogs.Properties.Resources.user_catwomen;
            this.TsbOwnerSelection.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbOwnerSelection.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbOwnerSelection.Margin = new System.Windows.Forms.Padding(0, 1, 6, 2);
            this.TsbOwnerSelection.Name = "TsbOwnerSelection";
            this.TsbOwnerSelection.Size = new System.Drawing.Size(36, 36);
            this.TsbOwnerSelection.ToolTipText = "Выборка телевизоров заданного владельца";
            this.TsbOwnerSelection.Click += new System.EventHandler(this.SelectOwnerTbr_Command);
            // 
            // TsbSeparator4
            // 
            this.TsbSeparator4.Name = "TsbSeparator4";
            this.TsbSeparator4.Size = new System.Drawing.Size(6, 39);
            // 
            // TsbToTray
            // 
            this.TsbToTray.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbToTray.Image = global::TabControlsStdDialogs.Properties.Resources.hand_point_270;
            this.TsbToTray.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbToTray.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbToTray.Name = "TsbToTray";
            this.TsbToTray.Size = new System.Drawing.Size(36, 36);
            this.TsbToTray.Text = "Свернуть в трей";
            this.TsbToTray.ToolTipText = "Свернуть в трей";
            this.TsbToTray.Click += new System.EventHandler(this.ToTray_Command);
            // 
            // TsbAbout
            // 
            this.TsbAbout.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbAbout.Image = global::TabControlsStdDialogs.Properties.Resources.help;
            this.TsbAbout.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbAbout.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbAbout.Name = "TsbAbout";
            this.TsbAbout.Size = new System.Drawing.Size(36, 36);
            this.TsbAbout.ToolTipText = "Сведения о программе";
            this.TsbAbout.Click += new System.EventHandler(this.About_Command);
            // 
            // TsbExit
            // 
            this.TsbExit.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.TsbExit.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbExit.Image = global::TabControlsStdDialogs.Properties.Resources.door_out;
            this.TsbExit.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbExit.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbExit.Name = "TsbExit";
            this.TsbExit.Size = new System.Drawing.Size(36, 36);
            this.TsbExit.ToolTipText = "Выход из приложения";
            this.TsbExit.Click += new System.EventHandler(this.Exit_Command);
            // 
            // StsMain
            // 
            this.StsMain.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.StsMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.StlMain});
            this.StsMain.Location = new System.Drawing.Point(0, 564);
            this.StsMain.Name = "StsMain";
            this.StsMain.Size = new System.Drawing.Size(1169, 22);
            this.StsMain.TabIndex = 2;
            this.StsMain.Text = "statusStrip1";
            // 
            // StlMain
            // 
            this.StlMain.Name = "StlMain";
            this.StlMain.Size = new System.Drawing.Size(1154, 17);
            this.StlMain.Spring = true;
            this.StlMain.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // CmnTelevisions
            // 
            this.CmnTelevisions.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.CmnTelevisions.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.CmiTelevisionsAdd,
            this.CmiTelevisionsEdit,
            this.CmiTelevisionsRemoveAt,
            this.CmiTelevisionSep1,
            this.CmiTelevisionsAbout,
            this.CmiTelevisionsExit});
            this.CmnTelevisions.Name = "CmnTelevisions";
            this.CmnTelevisions.Size = new System.Drawing.Size(236, 200);
            // 
            // CmiTelevisionsAdd
            // 
            this.CmiTelevisionsAdd.Image = global::TabControlsStdDialogs.Properties.Resources.add;
            this.CmiTelevisionsAdd.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.CmiTelevisionsAdd.Name = "CmiTelevisionsAdd";
            this.CmiTelevisionsAdd.Size = new System.Drawing.Size(235, 38);
            this.CmiTelevisionsAdd.Text = "Принять в ремонт...";
            this.CmiTelevisionsAdd.Click += new System.EventHandler(this.AddTelevision_Command);
            // 
            // CmiTelevisionsEdit
            // 
            this.CmiTelevisionsEdit.Image = global::TabControlsStdDialogs.Properties.Resources.edit_mx_entry;
            this.CmiTelevisionsEdit.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.CmiTelevisionsEdit.Name = "CmiTelevisionsEdit";
            this.CmiTelevisionsEdit.Size = new System.Drawing.Size(235, 38);
            this.CmiTelevisionsEdit.Text = "Изменить...";
            this.CmiTelevisionsEdit.Click += new System.EventHandler(this.EditTelevision_Command);
            // 
            // CmiTelevisionsRemoveAt
            // 
            this.CmiTelevisionsRemoveAt.Image = global::TabControlsStdDialogs.Properties.Resources.delete;
            this.CmiTelevisionsRemoveAt.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.CmiTelevisionsRemoveAt.Name = "CmiTelevisionsRemoveAt";
            this.CmiTelevisionsRemoveAt.Size = new System.Drawing.Size(235, 38);
            this.CmiTelevisionsRemoveAt.Text = "Выдать";
            this.CmiTelevisionsRemoveAt.Click += new System.EventHandler(this.ServeOut_Command);
            // 
            // CmiTelevisionSep1
            // 
            this.CmiTelevisionSep1.Name = "CmiTelevisionSep1";
            this.CmiTelevisionSep1.Size = new System.Drawing.Size(232, 6);
            // 
            // CmiTelevisionsAbout
            // 
            this.CmiTelevisionsAbout.Image = global::TabControlsStdDialogs.Properties.Resources.help;
            this.CmiTelevisionsAbout.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.CmiTelevisionsAbout.Name = "CmiTelevisionsAbout";
            this.CmiTelevisionsAbout.Size = new System.Drawing.Size(235, 38);
            this.CmiTelevisionsAbout.Text = "О программе...";
            this.CmiTelevisionsAbout.Click += new System.EventHandler(this.About_Command);
            // 
            // CmiTelevisionsExit
            // 
            this.CmiTelevisionsExit.Image = global::TabControlsStdDialogs.Properties.Resources.door_out;
            this.CmiTelevisionsExit.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.CmiTelevisionsExit.Name = "CmiTelevisionsExit";
            this.CmiTelevisionsExit.Size = new System.Drawing.Size(235, 38);
            this.CmiTelevisionsExit.Text = "Выход";
            this.CmiTelevisionsExit.Click += new System.EventHandler(this.Exit_Command);
            // 
            // CmnForm
            // 
            this.CmnForm.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.CmnForm.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.CmiFormNewRepairShop,
            this.CmiFormEditRepairShop,
            this.CmiFormSeparator1,
            this.CmiFormAbout,
            this.CmiFormSeparator2,
            this.CmiFormExit});
            this.CmnForm.Name = "CmnTelevisions";
            this.CmnForm.Size = new System.Drawing.Size(202, 168);
            // 
            // CmiFormNewRepairShop
            // 
            this.CmiFormNewRepairShop.Image = global::TabControlsStdDialogs.Properties.Resources._new;
            this.CmiFormNewRepairShop.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.CmiFormNewRepairShop.Name = "CmiFormNewRepairShop";
            this.CmiFormNewRepairShop.Size = new System.Drawing.Size(201, 38);
            this.CmiFormNewRepairShop.Text = "Новая...";
            this.CmiFormNewRepairShop.Click += new System.EventHandler(this.NewRepairShop_Command);
            // 
            // CmiFormEditRepairShop
            // 
            this.CmiFormEditRepairShop.Image = global::TabControlsStdDialogs.Properties.Resources.edit_button;
            this.CmiFormEditRepairShop.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.CmiFormEditRepairShop.Name = "CmiFormEditRepairShop";
            this.CmiFormEditRepairShop.Size = new System.Drawing.Size(201, 38);
            this.CmiFormEditRepairShop.Text = "Изменить...";
            this.CmiFormEditRepairShop.Click += new System.EventHandler(this.EditRepairShop_Command);
            // 
            // CmiFormSeparator1
            // 
            this.CmiFormSeparator1.Name = "CmiFormSeparator1";
            this.CmiFormSeparator1.Size = new System.Drawing.Size(198, 6);
            // 
            // CmiFormAbout
            // 
            this.CmiFormAbout.Image = global::TabControlsStdDialogs.Properties.Resources.help;
            this.CmiFormAbout.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.CmiFormAbout.Name = "CmiFormAbout";
            this.CmiFormAbout.Size = new System.Drawing.Size(201, 38);
            this.CmiFormAbout.Text = "О программе...";
            this.CmiFormAbout.Click += new System.EventHandler(this.About_Command);
            // 
            // CmiFormSeparator2
            // 
            this.CmiFormSeparator2.Name = "CmiFormSeparator2";
            this.CmiFormSeparator2.Size = new System.Drawing.Size(198, 6);
            // 
            // CmiFormExit
            // 
            this.CmiFormExit.Image = global::TabControlsStdDialogs.Properties.Resources.door_out;
            this.CmiFormExit.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.CmiFormExit.Name = "CmiFormExit";
            this.CmiFormExit.Size = new System.Drawing.Size(201, 38);
            this.CmiFormExit.Text = "Выход";
            this.CmiFormExit.Click += new System.EventHandler(this.Exit_Command);
            // 
            // OfdMain
            // 
            this.OfdMain.DefaultExt = "json";
            this.OfdMain.FileName = "repair_shop";
            this.OfdMain.Filter = "Файл данных (*.json)|*.json|Все файлы (*.*)|*.*";
            this.OfdMain.InitialDirectory = ".\\";
            this.OfdMain.Title = "Загрузить данные ремонтной мастерской";
            // 
            // SfdMain
            // 
            this.SfdMain.DefaultExt = "json";
            this.SfdMain.FileName = "repair_shop";
            this.SfdMain.Filter = "Файл данных (*.json)|*.json|Все файлы (*.*)|*.*";
            this.SfdMain.InitialDirectory = ".\\";
            this.SfdMain.Title = "Сохранить данные ремонтной мастерской";
            // 
            // FndListBox
            // 
            this.FndListBox.FontMustExist = true;
            // 
            // CldListBox
            // 
            this.CldListBox.AnyColor = true;
            // 
            // NtiMain
            // 
            this.NtiMain.ContextMenuStrip = this.CmnNotify;
            this.NtiMain.Icon = ((System.Drawing.Icon)(resources.GetObject("NtiMain.Icon")));
            this.NtiMain.Text = "Ремонт телевизоров";
            this.NtiMain.Visible = true;
            // 
            // CmnNotify
            // 
            this.CmnNotify.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.CmnNotify.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.CmiNotifyRestore,
            this.CmiNotifySeparator1,
            this.CmiNotifyAbout,
            this.CmiNotifySeparator2,
            this.CmiNotifyExit});
            this.CmnNotify.Name = "CmnTelevisions";
            this.CmnNotify.Size = new System.Drawing.Size(202, 130);
            // 
            // CmiNotifyRestore
            // 
            this.CmiNotifyRestore.Image = global::TabControlsStdDialogs.Properties.Resources.arrow_out;
            this.CmiNotifyRestore.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.CmiNotifyRestore.Name = "CmiNotifyRestore";
            this.CmiNotifyRestore.Size = new System.Drawing.Size(201, 38);
            this.CmiNotifyRestore.Text = "Восстановить";
            this.CmiNotifyRestore.Click += new System.EventHandler(this.FromTray_Command);
            // 
            // CmiNotifySeparator1
            // 
            this.CmiNotifySeparator1.Name = "CmiNotifySeparator1";
            this.CmiNotifySeparator1.Size = new System.Drawing.Size(198, 6);
            // 
            // CmiNotifyAbout
            // 
            this.CmiNotifyAbout.Image = global::TabControlsStdDialogs.Properties.Resources.help;
            this.CmiNotifyAbout.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.CmiNotifyAbout.Name = "CmiNotifyAbout";
            this.CmiNotifyAbout.Size = new System.Drawing.Size(201, 38);
            this.CmiNotifyAbout.Text = "О программе...";
            this.CmiNotifyAbout.Click += new System.EventHandler(this.About_Command);
            // 
            // CmiNotifySeparator2
            // 
            this.CmiNotifySeparator2.Name = "CmiNotifySeparator2";
            this.CmiNotifySeparator2.Size = new System.Drawing.Size(198, 6);
            // 
            // CmiNotifyExit
            // 
            this.CmiNotifyExit.Image = global::TabControlsStdDialogs.Properties.Resources.door_out;
            this.CmiNotifyExit.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.CmiNotifyExit.Name = "CmiNotifyExit";
            this.CmiNotifyExit.Size = new System.Drawing.Size(201, 38);
            this.CmiNotifyExit.Text = "Выход";
            this.CmiNotifyExit.Click += new System.EventHandler(this.Exit_Command);
            // 
            // TbcMain
            // 
            this.TbcMain.Controls.Add(this.TbpGeneral);
            this.TbcMain.Controls.Add(this.TbpOrdered);
            this.TbcMain.Controls.Add(this.TbpSelected);
            this.TbcMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TbcMain.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TbcMain.ImageList = this.ImlTabMain;
            this.TbcMain.Location = new System.Drawing.Point(0, 68);
            this.TbcMain.Name = "TbcMain";
            this.TbcMain.SelectedIndex = 0;
            this.TbcMain.Size = new System.Drawing.Size(1169, 496);
            this.TbcMain.TabIndex = 6;
            this.TbcMain.SelectedIndexChanged += new System.EventHandler(this.TbcMain_SelectedIndexChanged);
            // 
            // TbpGeneral
            // 
            this.TbpGeneral.Controls.Add(this.LbxGeneral);
            this.TbpGeneral.Controls.Add(this.LblHeaderGeneral);
            this.TbpGeneral.ImageIndex = 0;
            this.TbpGeneral.Location = new System.Drawing.Point(4, 29);
            this.TbpGeneral.Name = "TbpGeneral";
            this.TbpGeneral.Padding = new System.Windows.Forms.Padding(3);
            this.TbpGeneral.Size = new System.Drawing.Size(1161, 463);
            this.TbpGeneral.TabIndex = 0;
            this.TbpGeneral.Text = "Общие сведения";
            this.TbpGeneral.UseVisualStyleBackColor = true;
            // 
            // LbxGeneral
            // 
            this.LbxGeneral.ContextMenuStrip = this.CmnTelevisions;
            this.LbxGeneral.Font = new System.Drawing.Font("Consolas", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LbxGeneral.FormattingEnabled = true;
            this.LbxGeneral.ItemHeight = 19;
            this.LbxGeneral.Location = new System.Drawing.Point(12, 40);
            this.LbxGeneral.Name = "LbxGeneral";
            this.LbxGeneral.ScrollAlwaysVisible = true;
            this.LbxGeneral.Size = new System.Drawing.Size(1136, 422);
            this.LbxGeneral.TabIndex = 6;
            // 
            // LblHeaderGeneral
            // 
            this.LblHeaderGeneral.Font = new System.Drawing.Font("Consolas", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblHeaderGeneral.Location = new System.Drawing.Point(12, 0);
            this.LblHeaderGeneral.Name = "LblHeaderGeneral";
            this.LblHeaderGeneral.Size = new System.Drawing.Size(1136, 40);
            this.LblHeaderGeneral.TabIndex = 5;
            this.LblHeaderGeneral.Text = "Ремонтная мастерская, телевизоры в ремонте";
            this.LblHeaderGeneral.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // TbpOrdered
            // 
            this.TbpOrdered.Controls.Add(this.LbxOrdered);
            this.TbpOrdered.Controls.Add(this.LblHeaderOrdered);
            this.TbpOrdered.ImageIndex = 1;
            this.TbpOrdered.Location = new System.Drawing.Point(4, 29);
            this.TbpOrdered.Name = "TbpOrdered";
            this.TbpOrdered.Padding = new System.Windows.Forms.Padding(3);
            this.TbpOrdered.Size = new System.Drawing.Size(1161, 463);
            this.TbpOrdered.TabIndex = 1;
            this.TbpOrdered.Text = "Отсортированные сведения";
            this.TbpOrdered.UseVisualStyleBackColor = true;
            // 
            // LbxOrdered
            // 
            this.LbxOrdered.ContextMenuStrip = this.CmnTelevisions;
            this.LbxOrdered.Font = new System.Drawing.Font("Consolas", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LbxOrdered.FormattingEnabled = true;
            this.LbxOrdered.ItemHeight = 19;
            this.LbxOrdered.Location = new System.Drawing.Point(12, 40);
            this.LbxOrdered.Name = "LbxOrdered";
            this.LbxOrdered.ScrollAlwaysVisible = true;
            this.LbxOrdered.Size = new System.Drawing.Size(1136, 422);
            this.LbxOrdered.TabIndex = 8;
            // 
            // LblHeaderOrdered
            // 
            this.LblHeaderOrdered.Font = new System.Drawing.Font("Consolas", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblHeaderOrdered.Location = new System.Drawing.Point(12, 0);
            this.LblHeaderOrdered.Name = "LblHeaderOrdered";
            this.LblHeaderOrdered.Size = new System.Drawing.Size(1136, 40);
            this.LblHeaderOrdered.TabIndex = 7;
            this.LblHeaderOrdered.Text = "Ремонтная мастерская, телевизоры в ремонте";
            this.LblHeaderOrdered.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // TbpSelected
            // 
            this.TbpSelected.Controls.Add(this.LbxSelected);
            this.TbpSelected.Controls.Add(this.LblHeaderSelected);
            this.TbpSelected.ImageIndex = 2;
            this.TbpSelected.Location = new System.Drawing.Point(4, 29);
            this.TbpSelected.Name = "TbpSelected";
            this.TbpSelected.Size = new System.Drawing.Size(1161, 463);
            this.TbpSelected.TabIndex = 2;
            this.TbpSelected.Text = "Выборка данных";
            this.TbpSelected.UseVisualStyleBackColor = true;
            // 
            // LbxSelected
            // 
            this.LbxSelected.ContextMenuStrip = this.CmnTelevisions;
            this.LbxSelected.Font = new System.Drawing.Font("Consolas", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LbxSelected.FormattingEnabled = true;
            this.LbxSelected.ItemHeight = 19;
            this.LbxSelected.Location = new System.Drawing.Point(12, 40);
            this.LbxSelected.Name = "LbxSelected";
            this.LbxSelected.ScrollAlwaysVisible = true;
            this.LbxSelected.Size = new System.Drawing.Size(1136, 422);
            this.LbxSelected.TabIndex = 8;
            // 
            // LblHeaderSelected
            // 
            this.LblHeaderSelected.Font = new System.Drawing.Font("Consolas", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblHeaderSelected.ImageList = this.ImlTabMain;
            this.LblHeaderSelected.Location = new System.Drawing.Point(12, 0);
            this.LblHeaderSelected.Name = "LblHeaderSelected";
            this.LblHeaderSelected.Size = new System.Drawing.Size(1136, 40);
            this.LblHeaderSelected.TabIndex = 7;
            this.LblHeaderSelected.Text = "Ремонтная мастерская, телевизоры в ремонте";
            this.LblHeaderSelected.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // ImlTabMain
            // 
            this.ImlTabMain.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("ImlTabMain.ImageStream")));
            this.ImlTabMain.TransparentColor = System.Drawing.Color.Transparent;
            this.ImlTabMain.Images.SetKeyName(0, "monitor_go.png");
            this.ImlTabMain.Images.SetKeyName(1, "sort.png");
            this.ImlTabMain.Images.SetKeyName(2, "table.png");
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1169, 586);
            this.ContextMenuStrip = this.CmnForm;
            this.Controls.Add(this.TbcMain);
            this.Controls.Add(this.TbsMain);
            this.Controls.Add(this.MnsMain);
            this.Controls.Add(this.StsMain);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.MnsMain;
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(1185, 625);
            this.MinimumSize = new System.Drawing.Size(1185, 625);
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Задание на 25.11.2021 - использование нескольких форм, стандартных диалогов, вкла" +
    "док";
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.MnsMain.ResumeLayout(false);
            this.MnsMain.PerformLayout();
            this.TbsMain.ResumeLayout(false);
            this.TbsMain.PerformLayout();
            this.StsMain.ResumeLayout(false);
            this.StsMain.PerformLayout();
            this.CmnTelevisions.ResumeLayout(false);
            this.CmnForm.ResumeLayout(false);
            this.CmnNotify.ResumeLayout(false);
            this.TbcMain.ResumeLayout(false);
            this.TbpGeneral.ResumeLayout(false);
            this.TbpOrdered.ResumeLayout(false);
            this.TbpSelected.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip MnsMain;
        private System.Windows.Forms.ToolStrip TbsMain;
        private System.Windows.Forms.StatusStrip StsMain;
        private System.Windows.Forms.ToolStripMenuItem MniFile;
        private System.Windows.Forms.ToolStripMenuItem MniFileExit;
        private System.Windows.Forms.ToolStripMenuItem MniRepairShop;
        private System.Windows.Forms.ToolStripMenuItem MniRepairShopNew;
        private System.Windows.Forms.ToolStripMenuItem MniRepairShopEdit;
        private System.Windows.Forms.ToolStripMenuItem MniTelevisions;
        private System.Windows.Forms.ToolStripMenuItem MniTelevisionsAdd;
        private System.Windows.Forms.ToolStripMenuItem MniTelevisionsEdit;
        private System.Windows.Forms.ToolStripSeparator MniTelevisionsSep1;
        private System.Windows.Forms.ToolStripMenuItem MniTelevisionsRemoveAt;
        private System.Windows.Forms.ToolStripMenuItem MniOrderBy;
        private System.Windows.Forms.ToolStripMenuItem MniOrderByBrand;
        private System.Windows.Forms.ToolStripMenuItem MniOrderByDiagonalDesc;
        private System.Windows.Forms.ToolStripMenuItem MniOrderByArtisan;
        private System.Windows.Forms.ToolStripMenuItem MniOrderByOwner;
        private System.Windows.Forms.ToolStripMenuItem MniSelectWhere;
        private System.Windows.Forms.ToolStripMenuItem MniSelectWhereInexpensive;
        private System.Windows.Forms.ToolStripMenuItem MniSelectWhereArtisan;
        private System.Windows.Forms.ToolStripMenuItem MniSelectWhereDiagonal;
        private System.Windows.Forms.ToolStripMenuItem MniHelp;
        private System.Windows.Forms.ToolStripMenuItem MniHelpAbout;
        private System.Windows.Forms.ToolStripStatusLabel StlMain;
        private System.Windows.Forms.ToolStripButton TsbNewRepairShop;
        private System.Windows.Forms.ToolStripButton TsbEditRepairShop;
        private System.Windows.Forms.ToolStripSeparator TsbSeparator1;
        private System.Windows.Forms.ToolStripButton TsbAddTelevision;
        private System.Windows.Forms.ToolStripButton TsbEditTelevision;
        private System.Windows.Forms.ToolStripButton TsbRemoveTelevision;
        private System.Windows.Forms.ToolStripSeparator TsbSeparator2;
        private System.Windows.Forms.ToolStripSeparator TsbSeparator3;
        private System.Windows.Forms.ToolStripButton TsbMinPrice;
        private System.Windows.Forms.ToolStripButton TsbArtisanSelection;
        private System.Windows.Forms.ToolStripButton TsbDiagonalSelection;
        private System.Windows.Forms.ToolStripSeparator TsbSeparator4;
        private System.Windows.Forms.ToolStripButton TsbAbout;
        private System.Windows.Forms.ToolStripButton TsbExit;
        private System.Windows.Forms.ToolStripComboBox CbxArtisans;
        private System.Windows.Forms.ToolStripComboBox CbxDiagonal;
        private System.Windows.Forms.ContextMenuStrip CmnTelevisions;
        private System.Windows.Forms.ToolStripMenuItem CmiTelevisionsAdd;
        private System.Windows.Forms.ToolStripMenuItem CmiTelevisionsEdit;
        private System.Windows.Forms.ToolStripMenuItem CmiTelevisionsRemoveAt;
        private System.Windows.Forms.ToolStripSeparator CmiTelevisionSep1;
        private System.Windows.Forms.ToolStripMenuItem CmiTelevisionsAbout;
        private System.Windows.Forms.ToolStripMenuItem CmiTelevisionsExit;
        private System.Windows.Forms.ContextMenuStrip CmnForm;
        private System.Windows.Forms.ToolStripMenuItem CmiFormNewRepairShop;
        private System.Windows.Forms.ToolStripMenuItem CmiFormEditRepairShop;
        private System.Windows.Forms.ToolStripSeparator CmiFormSeparator1;
        private System.Windows.Forms.ToolStripMenuItem CmiFormAbout;
        private System.Windows.Forms.ToolStripSeparator CmiFormSeparator2;
        private System.Windows.Forms.ToolStripMenuItem CmiFormExit;
        private System.Windows.Forms.ToolStripMenuItem MniFileOpen;
        private System.Windows.Forms.ToolStripMenuItem MniFileSaveAs;
        private System.Windows.Forms.ToolStripSeparator MniFileSep1;
        private System.Windows.Forms.ToolStripButton TsbFileOpen;
        private System.Windows.Forms.ToolStripButton TsbFileSave;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.OpenFileDialog OfdMain;
        private System.Windows.Forms.SaveFileDialog SfdMain;
        private System.Windows.Forms.ToolStripSeparator MniSelectSeparator1;
        private System.Windows.Forms.ToolStripMenuItem MniSelectWhereOwner;
        private System.Windows.Forms.ToolStripButton TsbOwnerSelection;
        private System.Windows.Forms.ToolStripComboBox CbxOwners;
        private System.Windows.Forms.ToolStripMenuItem MniOrderByPrice;
        private System.Windows.Forms.ToolStripMenuItem MniSettings;
        private System.Windows.Forms.ToolStripMenuItem MniSettingsFont;
        private System.Windows.Forms.ToolStripMenuItem MniSettingsBackColor;
        private System.Windows.Forms.FontDialog FndListBox;
        private System.Windows.Forms.ColorDialog CldListBox;
        private System.Windows.Forms.ToolStripMenuItem MniFileSave;
        private System.Windows.Forms.NotifyIcon NtiMain;
        private System.Windows.Forms.ToolStripSeparator MniSettingsSeparator1;
        private System.Windows.Forms.ToolStripMenuItem MniSettingsToTray;
        private System.Windows.Forms.ToolStripDropDownButton TsdOrderBy;
        private System.Windows.Forms.ToolStripMenuItem DmiOrderByBrand;
        private System.Windows.Forms.ToolStripMenuItem DmiOrderByDiagonalDesc;
        private System.Windows.Forms.ToolStripMenuItem DmiOrderByArtisan;
        private System.Windows.Forms.ToolStripMenuItem DmiOrderByOwner;
        private System.Windows.Forms.ToolStripMenuItem DmiOrderByPrice;
        private System.Windows.Forms.ToolStripButton TsbToTray;
        private System.Windows.Forms.ContextMenuStrip CmnNotify;
        private System.Windows.Forms.ToolStripMenuItem CmiNotifyRestore;
        private System.Windows.Forms.ToolStripSeparator CmiNotifySeparator1;
        private System.Windows.Forms.ToolStripMenuItem CmiNotifyAbout;
        private System.Windows.Forms.ToolStripSeparator CmiNotifySeparator2;
        private System.Windows.Forms.ToolStripMenuItem CmiNotifyExit;
        private System.Windows.Forms.TabControl TbcMain;
        private System.Windows.Forms.TabPage TbpGeneral;
        private System.Windows.Forms.ListBox LbxGeneral;
        private System.Windows.Forms.Label LblHeaderGeneral;
        private System.Windows.Forms.TabPage TbpOrdered;
        private System.Windows.Forms.ListBox LbxOrdered;
        private System.Windows.Forms.Label LblHeaderOrdered;
        private System.Windows.Forms.TabPage TbpSelected;
        private System.Windows.Forms.ListBox LbxSelected;
        private System.Windows.Forms.Label LblHeaderSelected;
        private System.Windows.Forms.ToolStripMenuItem MniSettingsColor;
        private System.Windows.Forms.ImageList ImlTabMain;
    }
}

