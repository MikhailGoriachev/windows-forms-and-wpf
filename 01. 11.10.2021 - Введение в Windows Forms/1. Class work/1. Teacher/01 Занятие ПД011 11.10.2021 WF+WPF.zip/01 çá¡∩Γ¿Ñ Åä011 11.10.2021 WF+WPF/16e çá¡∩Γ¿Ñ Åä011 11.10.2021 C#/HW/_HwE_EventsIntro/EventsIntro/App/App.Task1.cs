﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using EventsIntro.Helpers;
using EventsIntro.Models;
using EventsIntro.Models.ApplianceEventArgs;

namespace EventsIntro.App
{
    /*
     * Методы для решения задачи 1 
     */
    internal partial class App
    {
        // заполнение массива данными, назначение наблюдателей 
        partial void InitializeAppliances() {
            for (int i = 0; i < _appliances.Length; i++) {
                // сформировать прибор
                _appliances[i] = Appliance.Generate(i+1);
                
                // подписаться на события PowerChange, StateChange
                _appliances[i].PowerChange += Appliance_PowerChange;
                _appliances[i].StateChange += Appliance_StateChange;   
            } // for i
        } // InitializeAppliances


        // наблюдатель 1 - наблюдает за событием PowerChange
        // вывести в строку, соответствующую прибору старое и новое значение мощности
        public void Appliance_PowerChange(object sender, PowerChangeEventArgs e) {
            Appliance appliance = sender as Appliance;
            
            Utils.WriteXY(90, appliance.Id + 6, $"было: {e.CurrentPower,8:n2} Вт, стало {e.NewPower,8:n2} Вт", ConsoleColor.Cyan);
        } // Appliance_PowerChange


        // наблюдатель 2 - наблюдает за событием StateChange
        // выводит состояние соответствующего прибора в консоли
        // (в строке, соответствующего прибора в таблице) : красный фон для
        // выключенного прибора, зеленый фон для включенного прибора
        public void Appliance_StateChange(object sender, StateChangeEventArgs e) {
            Appliance appliance = sender as Appliance;
            
            // установить цвет вывода, вывести и восстановить исходный цвет
            Console.BackgroundColor = e.NewState ? ConsoleColor.DarkGreen : ConsoleColor.Red;
            Utils.WriteXY(75, appliance.Id + 6, $" {(e.NewState ? "Включен" : "Выключен"),-10} ", 
                ConsoleColor.Black);
            (Console.BackgroundColor, Console.ForegroundColor) = (ConsoleColor.DarkGray, ConsoleColor.Gray);
        } // Appliance_StateChange

        // вывод массива приборов в консоль в табличном виде
        private void ShowAppliances() {
            Utils.WriteXY(0, 4, $"{Appliance.Header(12)}", ConsoleColor.Gray);
            Array.ForEach(_appliances, a => Console.WriteLine($"{a.ToTableRow(12)}"));
            Console.WriteLine(Appliance.Footer(12));

            // Вывод подсказки для нажатия на кнопки изменения мощность, изменения
            // состояния прибора 
            int y = 9 + _appliances.Length;
            Utils.WriteXY(12, y, "A", ConsoleColor.Cyan);
            Utils.WriteXY(14, y, "Мощность", ConsoleColor.Gray);
            Utils.WriteXY(24, y, "S", ConsoleColor.Cyan);
            Utils.WriteXY(26, y, "Состояние", ConsoleColor.Gray);
            Utils.WriteXY(38, y, "Z", ConsoleColor.Cyan);
            Utils.WriteXY(40, y, "В меню", ConsoleColor.Gray);
        } // ShowAppliances


        // просто вывод массива приборов в консоль в табличном виде
        public void JustShowAppliances() {
            Utils.ShowNavBarTask("  Задача 1 - массив приборов для обрабтки событий");
            Console.Write($"\n\n\n\n{Appliance.Header(12)}");

            Array.ForEach(_appliances, a => Console.WriteLine($"{a.ToTableRow(12)}"));

            Console.WriteLine(Appliance.Footer(12));
        } // JustShowAppliances


        // метод решения задачи - вывод массива в консоль, ожидание нажатия на клавиша
        public void AppliancesEventLoop() {
            Utils.ShowNavBarTask("  Задача 1 - события в массиве приборов");

            // начальный вывод данных в консоль
            ShowAppliances();

            // главный цикл - вывод таблицы, ожидание нажатия на клавиши
            while (true) {
                int index = 0;

                ConsoleKey key = Console.ReadKey(true).Key;
                switch (key) {
                    // изментить мощность некоторого случайного прибора на 
                    // случайную величину
                    case ConsoleKey.A:
                        index = Utils.GetRandom(0, _appliances.Length-1);
                        _appliances[index].Power += Utils.GetRandom(-3, 100);
                        Utils.WriteXY(47, _appliances[index].Id + 6, $" {_appliances[index].Power,12:n2} ", ConsoleColor.Green);
                        break;

                    // изментить состояние некоторого случайного прибора
                    case ConsoleKey.S:
                        index = Utils.GetRandom(0, _appliances.Length - 1);
                        _appliances[index].State = Utils.GetRandom(0, 1) == 1;
                        break;

                    case ConsoleKey.Z:
                        return;
                } // switch

            } // while

        } // AppliancesEventLoop
    } // class App
}
