﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EventsIntro.Models;
using EventsIntro.Models.PersonEventArgs;
using Microsoft.VisualBasic.CompilerServices;
using Utils = EventsIntro.Helpers.Utils;

namespace EventsIntro.App
{
    internal partial class App
    {
        // инициализация массива персон, подписываемся на события объекта
        partial void InitializePersons() {
            for (int i = 0; i < _persons.Length; i++)
            {
                // сформировать персону
                _persons[i] = Person.Generate(i + 1);

                // подписаться на события Childhood, Relocate
                // первый и второй обработчики - статический и нестатический
                // методы по заданию
                _persons[i].Childhood += Person_Childhood1;
                _persons[i].Childhood += Person_Childhood2;

                // третий наблюдатель-обработчик события Childhood, подсчитывает
                // общее количество персон с возрастом меньше 21 года, выводит
                // это количество некоторым цветом в консоль, в строку заголовка
                // таблицы
                _persons[i].Childhood += (sender, e) => {
                    int total = Array.FindAll(_persons, p => p.Age < 21).Length;
                    Utils.WriteXY(12, 3, $"В персональных данных несовершеннолетних: {total} чел. ", 
                        ConsoleColor.Cyan);
                };

                // первый обработчик события Relocate - обычный метод
                _persons[i].Relocate += Person_Relocate1;

                // второй обработчик события Relocate - лямбда-выражение
                // Выводит строку формата «старый город -> новый город» возле 
                // соответствующей строки таблицы, отображающей массив персон
                _persons[i].Relocate += (sender, e) => {
                    Person p = sender as Person;

                    // вывод сообщения в строку таблицы
                    Utils.WriteXY(120, p.Id + 6, $"{e.OldCity} -> {e.NewCity}".PadRight(30), ConsoleColor.Cyan);
                };
            } // for i
        } // InitializePersons

        // Первый обработчик события выводит возраст, фамилию и инициалы, 
        // сообщение "возраст меньше допустимого" некоторым цветом в консоль, 
        // в строку отображения персоны в таблице
        public static void Person_Childhood1(object sender, EventArgs e) {
            Person p = sender as Person;

            // вывод сообщений в строку таблицы на заданном фоне, восстановление 
            // исходного цвета фона и цвета символов 
            Console.BackgroundColor = ConsoleColor.Red;
            Utils.WriteXY(88, p.Id + 6, "  возраст меньше допустимого  ", ConsoleColor.Black);
            (Console.BackgroundColor, Console.ForegroundColor) = (ConsoleColor.DarkGray, ConsoleColor.Gray);
        } // Person_Childhood1

        // Второй обработчик события Childhood выводит строку "обнаружен
        // несовершеннолетний" в заголовок окна
        public void Person_Childhood2(object sender, EventArgs e) {
            Console.Title = $"{Title}. Обнаружен несовершеннолетний, [{sender as Person}]";
        } // Person_Childhood2


        // Первый обработчик события Relocate подсчитывает количества персон 
        // в городах, выводит результат в некоторую область консоли в виде
        // таблицы со столбцами «Город» и «Количество проживающих»
        public void Person_Relocate1(object sender, RelocateEventArgs e) {
            // массив кортежей - пары "город" - "количество", рамер массива
            // с большим запасом
            (string City, int Number)[] cities = new (string City, int Number)[30];
            int k = 0;

            // просмотр массива персональных данных, если город найден в
            // массиве кортежей, то увеличить счетчик вхождений этого города,
            // если город не найден, записать город в очередной элемент,
            // счетчик вхождений города устанавливается в 1
            foreach (var person in _persons) {
                int index = Array.FindIndex(cities, c => c.City == person.City);
                if (index < 0)
                    cities[k++] = (person.City, 1);
                else
                    cities[index].Number++;
            } // foreach valueType

            // сокращаем массив кортежей до фактического размера
            Array.Resize(ref cities, k);
            Array.Sort(cities, (c1, c2) => c1.City.CompareTo(c2.City));

            // вывод таблицы кортежей
            int x = 61, y = 22;
            Utils.WriteXY(x, y++, "┌──────────────────────┬────────────┐", ConsoleColor.Cyan);
            Utils.WriteXY(x, y++, "│ Город проживания     │ Количество │", ConsoleColor.Cyan);
            Utils.WriteXY(x, y++, "├──────────────────────┼────────────┤", ConsoleColor.Cyan);
            foreach (var c in cities) {
                Utils.WriteXY(x, y++, $"│ {c.City,-20} │ {c.Number,6}     │",
                    ConsoleColor.Cyan);
            } // foreach c
            Utils.WriteXY(x, y++, "└──────────────────────┴────────────┘", ConsoleColor.Cyan);

            // стереть строки, оставшиеся от более короткого массива результатов
            for (int i = 0; i < 3; i++)
                Utils.WriteXY(x, y++, " ".PadRight(60), ConsoleColor.Gray);
        } // Person_Relocate1

        // вывод массива персональных данных в консоль в табличном виде
        private void ShowPersins() {
            Utils.WriteXY(0, 4, $"{Person.Header(12)}", ConsoleColor.Gray);
            Array.ForEach(_persons, p => Console.WriteLine($"{p.ToTableRow(12)}"));
            Console.WriteLine(Person.Footer(12));

            // Вывод подсказки для нажатия на кнопки задания возраста, города проживания 
            int y = 9 + _persons.Length;
            Utils.WriteXY(12, y, "A", ConsoleColor.Cyan);
            Utils.WriteXY(14, y, "Задать возраст", ConsoleColor.Gray);
            Utils.WriteXY(30, y, "S", ConsoleColor.Cyan);
            Utils.WriteXY(32, y, "Задать город", ConsoleColor.Gray);
            Utils.WriteXY(45, y, "Z", ConsoleColor.Cyan);
            Utils.WriteXY(47, y, "В меню", ConsoleColor.Gray);
        } // ShowAppliances


        // просто вывод массива данных пользователей в консоль в табличном виде
        public void JustShowPersons() {
            Utils.ShowNavBarTask("  Задача 2 - массив персональных данных для обработки событий");
            Console.Write($"\n\n\n\n{Person.Header(12)}");

            Array.ForEach(_persons, p => Console.WriteLine($"{p.ToTableRow(12)}"));

            Console.WriteLine(Person.Footer(12));
        } // JustShowPersons


        // метод решения задачи - вывод массива в консоль, ожидание нажатия на клавиша
        public void PersonsEventLoop() {
            Utils.ShowNavBarTask("  Задача 2 - события в массиве персональных данных");
            
            // города для задания нового значения
            string[] cities = {
                "Донецк", "Макеевка", "Шахтерск", "Харцызск", "Ясиноватая"
            };

            // начальный вывод данных в консоль
            ShowPersins();

            // главный цикл - вывод таблицы, ожидание нажатия на клавиши
            while (true) {
                int index = 0;

                ConsoleKey key = Console.ReadKey(true).Key;
                switch (key) {
                    // задать возраст случайной персоны - случайная величина (валиндая)
                    case ConsoleKey.A:
                        index = Utils.GetRandom(0, _persons.Length - 1);
                        
                        // стереть сообщение об обнаружении несовершеннолетнего из консоли
                        // и заголовка окна
                        Utils.WriteXY(88, _persons[index].Id + 6, " ".PadRight(30), 
                            ConsoleColor.Gray);
                        Console.Title = Title;
                        _persons[index].Age = Utils.GetRandom(15, 23);

                        // обновить данные в таблице значений
                        Utils.WriteXY(47, _persons[index].Id + 6, $" {_persons[index].Age,7:f0}      ", ConsoleColor.Cyan);
                        break;

                    // изменить город проживания некоторой случайной персоны
                    case ConsoleKey.S:
                        index = Utils.GetRandom(0, _persons.Length - 1);
                        
                        // стереть сообщение об изменении города, т.к. еще не извесстно, изменится город или нет
                        Utils.WriteXY(120, _persons[index].Id + 6, " ".PadRight(30), ConsoleColor.Cyan);

                        // получить новый город
                        _persons[index].City = cities[Utils.GetRandom(0, cities.Length - 1)];

                        // обновить данные в таблице значений
                        Utils.WriteXY(62, _persons[index].Id + 6, $" {_persons[index].City,-20} ", ConsoleColor.Cyan);
                        break;

                    case ConsoleKey.Z:
                        return;
                } // switch
            } // while
        } // PersonsEventLoop
    } // class App
}
