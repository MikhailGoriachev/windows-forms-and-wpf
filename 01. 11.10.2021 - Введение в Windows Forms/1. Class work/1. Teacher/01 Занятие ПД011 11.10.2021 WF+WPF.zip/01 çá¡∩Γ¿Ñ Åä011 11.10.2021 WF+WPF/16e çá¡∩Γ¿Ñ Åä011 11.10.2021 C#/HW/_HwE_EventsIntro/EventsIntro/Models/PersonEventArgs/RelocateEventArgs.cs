﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EventsIntro.Models.PersonEventArgs
{
    // параметры события Relocate в классе Person
    internal class RelocateEventArgs: EventArgs
    {
        // старый город проживания
        public string OldCity { get; private set; }  // текущий город проживания
        
        // новый город проживания
        public string NewCity { get; private set; }  // новый город проживания


        public RelocateEventArgs():this("Старый город", "Новый город") { }

        public RelocateEventArgs(string oldCity, string newCity) : base() {
            OldCity = oldCity;
            NewCity = newCity;
        } // RelocateEventArgs
    } // class RelocateEventArgs
}
