﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EventsIntro.Models.ApplianceEventArgs
{
    // параметры события PowerChange - передаем текущее значение мощности
    // и новое значение мощности 
    internal class PowerChangeEventArgs: EventArgs
    {
        // свойства для хранения параметров события
        
        // текущее значение мощности
        public int CurrentPower {  get; private set; }

        // новое значение мощности
        public int NewPower     {  get; private set; }


        public PowerChangeEventArgs()  { } // PowerChangeEventArgs

        public PowerChangeEventArgs(int currentPower, int newPower) {
            CurrentPower = currentPower;
            NewPower = newPower;
        } // PowerChangeEventArgs
    } // class PowerChangeEventArgs
}
