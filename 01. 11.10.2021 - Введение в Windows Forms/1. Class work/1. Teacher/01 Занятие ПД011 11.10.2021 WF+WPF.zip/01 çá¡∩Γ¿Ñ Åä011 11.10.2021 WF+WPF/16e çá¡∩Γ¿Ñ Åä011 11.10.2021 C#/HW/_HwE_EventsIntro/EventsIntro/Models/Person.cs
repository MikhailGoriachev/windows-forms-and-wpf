﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using EventsIntro.Helpers;
using EventsIntro.Models.PersonEventArgs;

namespace EventsIntro.Models
{
    // Класс, представляющий персональные данные:
    // фамилия и инициалы, возраст в годах, название города проживания
    // События класса:
    //     • Childhood - при присваивании возраста меньше 21 
    //     • Relocate  - при изменении города проживания 

    // делегат для события Relocate
    internal delegate void RelocateEventHandler(object sender, RelocateEventArgs e);
    internal class Person
    {
        // события класса
        public event EventHandler Childhood;            // присваивание возраста,меньше 21
        public event RelocateEventHandler Relocate;     // изменение города проживания

        // Идентификатор персоны - для идентификации персоны при поиске в массиве
        // не заботимся об уникальности идентификатора :)
        private int _id;
        public int Id {
            get => _id;
            set => _id = value; 
        } // Id


        // Фамилия и инициалы
        private string _fullName;
        public string FullName {
            get => _fullName;
            set {
                if (string.IsNullOrWhiteSpace(value))
                    throw new ArgumentNullException("Person: не указаны фамилия и инициалы");
                _fullName = value;
            } // set
        } // FullName

        // Возраст в годах
        private int _age;
        public int Age {
            get => _age;
            set {
                if (value <= 0)
                    throw new ArgumentException("Person: недопустимое значение возраста");

                _age = value;

                // событие зажигаем, при присваивании возраста, меньшего 21
                if (_age < 21)
                    Childhood?.Invoke(this, EventArgs.Empty);
            } // set
        } // Age

        // название города проживания
        private string _city;
        public string City {
            get => _city;
            set {
                if (string.IsNullOrWhiteSpace(value))
                    throw new ArgumentNullException("Person: не указан город проживания");

                // запомнить текущее значение города - для зажигания события
                // и присвоить новое значение
                string oldCity = _city;   
                _city = value;

                // проверить условие зажигания события и зажечь при необходимости
                if (oldCity != _city) 
                    Relocate?.Invoke(this, new RelocateEventArgs(oldCity, _city));
            } // set
        } // City

        public Person() : this("Иванова Б.А.", 32, "Снежное") { }
        public Person(string fullName, int age, string city) {
            FullName = fullName;
            Age = age;
            _city = city;
        } // Person

        // вывод шапки таблицы
        // Шапка таблицы, статическое свойство
        public static string Header(int indent) {
            string spaces = " ".PadRight(indent);
            return
            $"{spaces}┌────────┬────────────────────────┬──────────────┬──────────────────────┐\n" +
            $"{spaces}│ Идент. │ Полное имя             │ Возраст, лет │ Город проживания     │\n" +
            $"{spaces}├────────┼────────────────────────┼──────────────┼──────────────────────┤\n";
        } // │

        // Подвал таблицы, статическое свойство
        public static string Footer(int indent) =>
            $"{" ".PadRight(indent)}└────────┴────────────────────────┴──────────────┴──────────────────────┘\n";

        // строковое представление класса
        public override string ToString() => $"{_id}: {_fullName}, лет: {_age}, из г. {_city}";

        public string ToTableRow(int indent) =>
            $"{" ".PadRight(indent)}│ {_id,6} │ {_fullName,-22} │ {_age,7:f0}      │ {_city,-20} │";

        
        // генерация объекта класса Person - уникальность идентификатора обеспечивает
        // внешний код
        public static Person Generate(int id) {
            string[] fullNames = {
                "Васильев А.Н.",    "Швайко О.А.",    "Дёмина Д.П.",  "Лысюк А.В.",
                "Якубовская Ю.В.",  "Пачкория Г.В.",  "Аникеев В.О.", "Мироненко Н.Я.",
                "Решетникова Н.А.", "Свиридова Т.Л.", "Репеко Д.А.",  "Лысенко Б.П.",
            };
            string[] cities = {
                "Донецк", "Макеевка", "Шахтерск", "Харцызск", "Ясиноватая"
            };

            // для ускорения доступа обращаемся напрямую к опорным полям свойств
            return new Person {
                _id = id,
                _fullName = fullNames[Utils.GetRandom(0, fullNames.Length - 1)],
                _age = Utils.GetRandom(19, 56),
                _city = cities[Utils.GetRandom(0, cities.Length - 1)]
            };
        } // Generate

    } // class Person
}
