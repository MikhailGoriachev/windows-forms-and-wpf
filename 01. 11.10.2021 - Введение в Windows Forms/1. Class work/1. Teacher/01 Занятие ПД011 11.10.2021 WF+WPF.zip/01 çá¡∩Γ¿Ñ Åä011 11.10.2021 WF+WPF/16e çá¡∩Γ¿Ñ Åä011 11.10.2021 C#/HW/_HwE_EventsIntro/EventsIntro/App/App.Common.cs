﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using EventsIntro.Helpers;
using EventsIntro.Models;

namespace EventsIntro.App
{
    // Общая часть приложения, создание объектов для выполнения задания
    internal partial class App
    {
        // массив приборов для обработки
        Appliance[] _appliances;

        // массив персон для обработки
        Person[] _persons;

        // Сообщение в заголовко окна консоли
        public static readonly string Title = "Задание на 11.10.2021 - введение в события и их обработку в C#"; 

        public App() : this(
            new Appliance[Utils.GetRandom(12, 20)], // по заданию: от 12 до 20 приборов
            new Person[Utils.GetRandom(10, 15)]) // по заданию: не менее 10 персон
        {
            InitializeAppliances();
            InitializePersons();
        } // App

        public App(Appliance[] appliances, Person[] persons) {
            _appliances = appliances;
            _persons = persons;
        } // App

        partial void InitializeAppliances();
        partial void InitializePersons();
    } // class App
}
