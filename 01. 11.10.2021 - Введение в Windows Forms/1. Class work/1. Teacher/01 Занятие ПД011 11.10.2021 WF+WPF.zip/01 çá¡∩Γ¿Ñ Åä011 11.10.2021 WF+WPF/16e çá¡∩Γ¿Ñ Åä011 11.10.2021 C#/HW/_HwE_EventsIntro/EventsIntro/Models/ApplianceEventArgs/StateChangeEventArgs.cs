﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EventsIntro.Models.ApplianceEventArgs
{
    // параметры события StateChange - передаем текущее состояние прибора
    // и новое состояние прибора 
    internal class StateChangeEventArgs: EventArgs
    {
        // свойства для хранения параметров события

        // текущее состояние прибора
        public bool CurrentState { get; private set; }

        // новое состояние прибора
        public bool NewState { get; private set; }


        public StateChangeEventArgs() { } // StateChangeEventArgs

        public StateChangeEventArgs(bool currentState, bool newState) {
            CurrentState = currentState;
            NewState = newState;
        } // StateChangeEventArgs
    } //  class StateChangeEventArgs
}
