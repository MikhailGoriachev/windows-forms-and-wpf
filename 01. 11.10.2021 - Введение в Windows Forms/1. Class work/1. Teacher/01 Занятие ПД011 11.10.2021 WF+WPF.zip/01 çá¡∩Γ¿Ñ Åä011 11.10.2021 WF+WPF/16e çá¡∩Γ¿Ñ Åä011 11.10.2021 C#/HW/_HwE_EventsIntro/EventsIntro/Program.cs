﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


using Microsoft.VisualBasic;   // для Iteraction.MsgBox
using EventsIntro.Helpers;
using EventsIntro.App;

/*
 * Задача 1.
 * Доработайте класс, описывающий электроприбор (название, мощность, цена,
 * включен/выключен) из задания на 06.10.2021. Массив приборов выводить в
 * табличном формате, в массиве должно быть от 12 до 20 приборов.
 * По командам, назначенным на клавиши, изменять мощность (на случайную
 * величину), состояние прибора (включен, выключен). Прибор для изменения
 * выбирается случайным образом из массива приборов.
 * Если новое значение мощности – нечетное число, то зажигать событие
 * PowerChange. При присваивании свойству, отражающему состояние электроприбора
 * значения, отличного от текущего, зажигать событие StateChange.
 * Создать Наблюдатель1, который будет выводить старую и новую мощность прибора
 * в консоль в строке таблицы для соответствующего прибора
 * Создать Наблюдатель2, который выводит состояние соответствующего прибора в
 * консоли (в строке, соответствующего прибора в таблице): красный фон для
 * выключенного прибора, зеленый фон для включенного прибора.
 *
 * Задача 2.
 * Для описания   персоны   используются фамилия и инициалы, возраст в годах,
 * название города проживания. Разработайте класс и следующие события для этого
 * класса: 
 *     • при присваивании возраста меньше 21 – зажигать событие Childhood
 *     • при изменении города проживания зажигать событие Relocate
 * Для проверки работы подпишите на события как минимум трех наблюдателей
 * (метод класса, статический метод класса, лямбда-выражение). 
 * Сгенерируйте массив (не менее чем 10 персон). Выводите массив в табличной
 * форме. По командам, назначенным на клавиши задавать некоторому случайно
 * выбранному элементу массива возраст (присваиванием свойству некоторого
 * случайного числа), город проживания (выбирать при помощи случайного индекса
 * название города из массива названий городов).
 * Для события Childhood обработчики события должны выполнять следующее:
 *    1. В первом обработчике выводить возраст, фамилию и инициалы, сообщение
 *       "возраст меньше допустимого" некоторым цветом в консоль, в строке
 *       отображения персоны в таблице
 *    2. Во втором обработчике выводить строку "обнаружен несовершеннолетний"
 *       в заголовок окна. 
 *    3. В третьем обработчике подсчитывать общее количество персон с возрастом
 *       меньше 21 года, выводить это количество некоторым цветом в консоль, в
 *       строку заголовка таблицы
 * Для события Relocate обработчики должны выполнять следующее:
 *    1. Подсчет количества персон в городах, выводить результат в некоторую
 *       область консоли в виде таблицы со столбцами «Город» и «Количество
 *       проживающих»
 *    2. Вывод   строки   формата   «старый город -> новый город»   возле 
 *       соответствующей строки таблицы, отображающей массив персон
 *
 */

namespace EventsIntro
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Title = App.App.Title;

            // простейшее меню приложения
            MenuItem[] menu = new[] {
                new MenuItem {HotKey = ConsoleKey.Q, Text = "Массив приборов по задаче 1"},
                new MenuItem {HotKey = ConsoleKey.W, Text = "Массив персональных данных по задаче 2"},
                new MenuItem {HotKey = ConsoleKey.E, Text = "События по задаче 1"},
                new MenuItem {HotKey = ConsoleKey.R, Text = "События по задаче 2"},
                //----------------------------------------------------------------------------------------------
                new MenuItem {HotKey = ConsoleKey.Z, Text = "Выход"},
            };

            // Создание экземпляра класса приложения
            App.App app = new App.App();

            // главный цикл приложения
            while (true) {
                try {
                    // настройка цветового оформления
                    (Console.ForegroundColor, Console.BackgroundColor) = (ConsoleColor.Gray, ConsoleColor.DarkGray);
                    Console.Clear();
                    Console.CursorVisible = false;

                    Utils.ShowNavBarTask("  ООП C# - введение в обработку событий");
                    Utils.ShowMenu(12, 5, "Меню приложения для демонстрации обработки событий в C#", menu);

                    // получить код нажатой клавиши, не отображать символ клавиши
                    Console.BackgroundColor = ConsoleColor.Gray;
                    string msg =
                        "  Нажмите выделенную цветом клавишу для выбора пункта меню".PadRight(Console.WindowWidth - 1);
                    Utils.WriteXY(0, Console.WindowHeight - 1, msg, ConsoleColor.Black);

                    ConsoleKey key = Console.ReadKey(true).Key;
                    (Console.ForegroundColor, Console.BackgroundColor) = (ConsoleColor.Gray, ConsoleColor.DarkGray);
                    Console.Clear();

                    switch (key) {
                        // ------------------------------------------------------------
                        // пункты меню, относящиеся к задаче 1

                        // Генерация и вывод массивов для обработки
                        case ConsoleKey.Q:
                            app.JustShowAppliances();
                            break;

                        // Вывод массивов для обработки
                        case ConsoleKey.W:
                            app.JustShowPersons();
                            break;

                        // Перемешать массивы данных для обработки
                        case ConsoleKey.E:
                            app.AppliancesEventLoop();
                            break;

                        // Определить количество максимальных элементов в массивах
                        case ConsoleKey.R:
                            app.PersonsEventLoop();
                            break;

                        // Выход из приложения назначен на клавишу F10 или клавишу M или клавишу Escape
                        case ConsoleKey.F10:
                        case ConsoleKey.Escape:
                        case ConsoleKey.Z:
                            Console.ResetColor(); // сброс цветового сочетания к исходному
                            Console.Clear();
                            Utils.WriteXY(0, Console.WindowHeight - 1, "Нажмите любую клавишу...", ConsoleColor.Gray);
                            Console.CursorVisible = true;
                            return;

                        default:
                            throw new Exception("Нет такой команды меню");
                    } // switch

                    // Ожидать нажатия любой клавиши по окончании работы пункта меню
                    Console.CursorVisible = true;
                    Console.BackgroundColor = ConsoleColor.Gray;
                    msg = "  Нажмите любую клавишу...".PadRight(Console.WindowWidth - 1);
                    Utils.WriteXY(0, Console.WindowHeight - 1, msg, ConsoleColor.Black);
                    Console.ReadKey(true);
                } // try

                // обработка исключений - просто вывести сообщение
                catch (Exception ex)
                {
                    Interaction.MsgBox(ex.Message, MsgBoxStyle.Critical | MsgBoxStyle.OkOnly, "Ошибка");
                } // try-catch
            } // while
        } // Main
    } // class Program
}
