﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Zodiak.Helpers;
using Zodiak.App_Data;

namespace Zodiak
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Задание на 20.10.2021. ObservableCollection";

            MenuItem[] menu = new[]
            {
                new MenuItem {HotKey = ConsoleKey.Q, Text = "Инициализация коллекции"},
                new MenuItem {HotKey = ConsoleKey.W, Text = "Добавление трех пользователей со знаком Рыбы"},
                new MenuItem {HotKey = ConsoleKey.E, Text = "Удаление всех пользователей старше 60 лет "},
                new MenuItem {HotKey = ConsoleKey.R, Text = "Заменить все записи знака Овен этими же записями, но с добавлением строки \"-бе-бе\" к фамилии "},
                new MenuItem {HotKey = ConsoleKey.A, Text = "Вывести в список и консоль записи с заданной фамилией"},
                new MenuItem {HotKey = ConsoleKey.S, Text = "Вывести в список и консоль записи с заданным знаком Зодиака"},
                new MenuItem {HotKey = ConsoleKey.D, Text = "Вывести в список и консоль записи с заданным месяцем рождения"},
                new MenuItem {HotKey = ConsoleKey.F, Text = "Сортировка по дате рождения"},
                new MenuItem {HotKey = ConsoleKey.Z, Text = "Сортировка по названиям знаков Зодиака"},
                new MenuItem {HotKey = ConsoleKey.X, Text = "Сортировка по фамилии, имени"}
            };

            App app = new App(); 

            while(true)
            {
                try
                {
                    //настройка цветового оформления
                    (Console.ForegroundColor, Console.BackgroundColor) = (ConsoleColor.Gray, ConsoleColor.DarkGray);
                    Console.Clear();
                    Console.CursorVisible = false;

                    Utils.ShowNavBarTask("  ООП С# - Знаки зодиака");
                    Utils.ShowMenu(12, 5, "Меню приложения для работы с ObservableCollection", menu);

                    // получения кода клавиши
                    Console.BackgroundColor = ConsoleColor.Gray;
                    string msg = " Нажмите выделенныую цветом клавишу для выбора ".PadRight(Console.WindowWidth - 1);
                    Utils.WriteXY(0, Console.WindowHeight - 1, msg, ConsoleColor.Black);

                    ConsoleKey key = Console.ReadKey(true).Key;
                    (Console.ForegroundColor, Console.BackgroundColor) = (ConsoleColor.Gray, ConsoleColor.DarkGray);
                    Console.Clear();

                    switch(key)
                    {
                        case ConsoleKey.Q:
                            app.Initialize();
                            break;

                        case ConsoleKey.W:
                            app.AddThreeUsers();
                            break;

                        case ConsoleKey.E:
                            app.DeleteOldOnes();
                            break;

                        case ConsoleKey.R:
                            app.ReplaceAres();
                            break;
                        case ConsoleKey.A:
                            app.ChosenSurname();
                            break;
                        case ConsoleKey.S:
                            app.ChosenSign();
                            break;
                        case ConsoleKey.D:
                            app.SelectMonth();
                            break;
                    }

                }
                catch(Exception ex)
                {
                    Console.WriteLine("\n");
                    Console.WriteLine(ex);
                    Console.ReadKey();
                }
            }
        }
    }
}
