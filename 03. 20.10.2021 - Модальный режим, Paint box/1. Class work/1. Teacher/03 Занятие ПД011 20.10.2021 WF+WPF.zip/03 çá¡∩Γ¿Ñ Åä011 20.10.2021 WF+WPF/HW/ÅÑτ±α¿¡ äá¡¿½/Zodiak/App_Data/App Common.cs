﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Zodiak.Models;

namespace Zodiak.App_Data
{
    internal partial class App
    {
        Department deps = new Department();

        public void Fill()
        {
            deps.Fill();
        }

        // обработчик событий изменения колллекции 
        



    }
}
