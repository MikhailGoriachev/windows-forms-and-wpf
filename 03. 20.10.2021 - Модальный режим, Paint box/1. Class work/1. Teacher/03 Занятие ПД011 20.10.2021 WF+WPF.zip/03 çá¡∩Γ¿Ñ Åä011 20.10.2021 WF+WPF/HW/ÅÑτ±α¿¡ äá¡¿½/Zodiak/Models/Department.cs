﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.ObjectModel;
using System.Collections;
using Zodiak.Helpers;
using Zodiak.App_Data;

namespace Zodiak.Models
{
    class Department : IEnumerable<User>
    {
        ObservableCollection<User> users;
        public Department()
        {
            users= new ObservableCollection<User>();
            users.CollectionChanged += App.ChangeUsers;
        }

           
        public void Fill(int size = 20)
        {
            users.Clear();
            for(int i =0; i<size; ++i)
            {
                users.Add(User.GenerateUser());
            }
        }

        public void Add(User user)
        {
            users.Add(user);
        }

        public void Remove(User user )
        {
            users.Remove(user);
        }

        public User this [int index]
        {
            get => users[index];
            set => users[index] = value;
        }

        public static string Header(int indent)
        {
            string spaces = " ".PadRight(indent);
            return
                $"{spaces}┌───────┬────────────────────────┬──────────────────────┬────────────────────┐\n" +
                $"{spaces}│ N п/п │ Имя и Фамилия          │ Знак Зодиака         │ Дата рождения      | \n" +
                $"{spaces}├───────┼────────────────────────┼──────────────────────┼────────────────────┤ ";
        }// Header

        // Подвал таблицы,  статическое свойство
        public static string Footer(int indent) =>
            $"{" ".PadRight(indent)}└───────┴────────────────────────┴──────────────────────┴────────────────────┘\n";

        public void Show()
        {
            Console.WriteLine($"   Список пользователей ");
            Console.WriteLine(Header(10));
            int i = 1;
            foreach(var user in users)
            {
                Console.WriteLine(user.ToTableRow(i++ , 10));
            }
            Console.WriteLine(Footer(10));
        }

        public void Show1(IEnumerable<User> enu)
        {
            Console.WriteLine($"   Список пользователей ");
            Console.WriteLine(Header(10));
            int i = 1;
            foreach (var user in enu)
            {
                Console.WriteLine(user.ToTableRow(i++, 10));
            }
            Console.WriteLine(Footer(10));
        }

        public void AddThreePieces()
        {

            for(int i =0; i<3; ++i)
            {
                User three = User.GenerateUser();
                three.ZodiacSign = "Рыбы";
                users.Add(three);
            }
        }

        public void Delete60s()
        {
            for(int i = 0; i< users.Count; ++i)
            {
                if ((DateTime.Now.Year - users[i].BirthDate.Year) > 60)
                {
                    users.RemoveAt(i);
                    i--;
                }
            }
        }

         public void Replace()
        {
            for(int i =0; i<users.Count; ++i)
            {
                var user = users[i];
                if((user.ZodiacSign =="Овен"))
                {
                    user.FullName += "бе-бе";
                }
                users[i] = user; 
            }
        }
       
        public IEnumerable<User> SelectUsers(Predicate<User> match)
        {
            foreach(var user in users) 
            {
                if (match.Invoke(user))
                    yield return user; 
            }
        }

        public IEnumerable<User> SelectedSurname()
        {
            Console.WriteLine("Введите имя и фамилию пользователя");
            var surname = Console.ReadLine();
            return SelectUsers((u1) => u1.FullName == surname);
        }

        public IEnumerable<User>  SelectSign()
        {
            var sign = User.CreateSigh();
            return SelectUsers((u1) => u1.ZodiacSign == sign);
        }

        public IEnumerable<User> SelcetMonth()
        {
            var month = User.CreateBirthDate().Month;
            return SelectUsers((u1) => u1.BirthDate.Month == month);
        }



        public IEnumerator<User> GetEnumerator()
        {
            return users.GetEnumerator();
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return GetEnumerator();
        }
    }
}
