﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Zodiak.Models;
using System.Collections.ObjectModel;
using System.Collections.Specialized;

namespace Zodiak.App_Data
{
    internal partial class App
    {
        
        public void Initialize()
        {
            Fill();
            deps.Show();

            Console.ReadKey();
        }

        public static void ChangeUsers(object sender, NotifyCollectionChangedEventArgs e)
        {
            switch (e.Action) 
            {
                case NotifyCollectionChangedAction.Add:
                    Console.WriteLine($"Добавлен новый пользователь {e.NewItems[0]}");
                    break;

                case NotifyCollectionChangedAction.Remove:
                    Console.WriteLine($"Удален пользователь {e.OldItems[0]}");
                    break;

                case NotifyCollectionChangedAction.Replace:
                    Console.WriteLine($"Пользователь {e.OldItems[0]} заменен на пользователя {e.NewItems[0]}");
                    break; 
            }
            

            
        }

        public void AddThreeUsers()
        {
            Console.WriteLine($"Таблица до добалвения");
            deps.Show();
            deps.AddThreePieces();
            Console.WriteLine($"После добавления трех пользователей ");
            deps.Show();

            Console.ReadKey(); 
        }

        public void DeleteOldOnes()
        {
            Console.WriteLine($"Таблица до удавления пользователей старше 60 лел");
            deps.Show();
            deps.Delete60s();
            Console.WriteLine($"                            Таблица после удаления ");
            deps.Show();

            Console.ReadKey();
        }

        public void ReplaceAres()
        {
            Console.WriteLine($"                Таблица до замены Овнов");
            deps.Show();
            deps.Replace();
            Console.WriteLine($"произведена замена ");
            deps.Show();

            Console.ReadKey();
        }

        public void ChosenSurname()
        {
            deps.Show();
            var perh = deps.SelectedSurname();
            deps.Show1(perh);

            Console.ReadKey();
        }

        public void ChosenSign()
        {
            deps.Show();
            var perh = deps.SelectSign();
            deps.Show1(perh);

            Console.ReadKey();
        }

        public void SelectMonth()
        {
            deps.Show();
            var perh = deps.SelcetMonth();
            deps.Show1(perh);

            Console.ReadKey();
        }

        
    }
}
