﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Globalization;
using Zodiak.Helpers;


namespace Zodiak.Models
{
    /*Задача 1. Описать класс с именем User, содержащую следующие поля:
       •	числовой идентификатор - int;
       •	фамилия, имя - string; 
       •	знак Зодиака - string;
       •	дата рождения - DateTime
*/
    class User
    {
        private int IdNumber { get; set; }
        private string _fullName;

        public string FullName
        {
            get => _fullName; 
            set
            {
                if (value == null) throw new ArgumentNullException();
                _fullName = value;
            }
        }


        public string ZodiacSign { get; set; }

        public DateTime BirthDate { get; set; }

        public string ToTableRow(int row, int indent) =>
           $"{" ".PadRight(indent)}| {row,5} | {FullName,-22} | {ZodiacSign,-20} | {BirthDate,12} |";

        public override string ToString() => $"{FullName, -22}";
        

        private static GregorianCalendar calendar = new GregorianCalendar(); 

        
        // методы генерации пользователя (фабрика) 

        public  static string  CreateName()
        {
            
            string[] names = {
                "Анна", "Александра", "Егор", "Кирилл", "Илья", "Елизавета", "Дмитрий", 
                "Дмитрий", "Арина", "Богдан","Матвей","Антон","Максим", "Таисия", "София", "Дарья", 
                "Виктор", "Юрий", "Руслан", "Михаил", "Андрей", "Василий", "Владислав"

            };

            string[] surnames =
            {  "Величко", "Гармаш", "Кононенко", "Симоненко" , "Гейда", "Андриенко", "Лукьяненко",
                "Василенко", "Григоренко", "Мельниченко", "Мирошниченко", "Жученко", "Ткач", "Скрипка", 
                 "Фурса", "Грипич"
            };

            return $"{names[Utils.GetRandomInt(0, names.Length)]} {surnames[Utils.GetRandomInt(0, surnames.Length)]}";
        }

        public static string CreateSigh()
        {
            string[] sighs = { 
                "Овен", "Телец", "Близнецы", "Рак", "Лев", "Дева", "Весы", "Скорпион", 
                "Стрелец", "Козерог", "Водолей","Рыбы"  
            };

            return $"{sighs[Utils.GetRandomInt(0, sighs.Length)]}";
        }

        public static DateTime CreateBirthDate()
        {
            int year = Utils.GetRandomInt(1900, DateTime.Now.Year);
            int month = Utils.GetRandomInt(1, calendar.GetMonthsInYear(year)+1);
            int day = Utils.GetRandomInt(1, calendar.GetDaysInMonth(year, month));

            return new DateTime(year, month, day); 

        }

        public static User GenerateUser()
        {
            return new User
            {
                IdNumber = Utils.Random.Next(),
                FullName = CreateName(),
                ZodiacSign = CreateSigh(),
                BirthDate = CreateBirthDate()

            };
        }
        


        

    }
}
