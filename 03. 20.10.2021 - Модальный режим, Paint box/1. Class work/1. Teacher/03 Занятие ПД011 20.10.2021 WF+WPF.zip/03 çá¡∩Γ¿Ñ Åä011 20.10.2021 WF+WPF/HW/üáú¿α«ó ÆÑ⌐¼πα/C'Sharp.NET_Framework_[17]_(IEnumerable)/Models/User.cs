﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace C_Sharp.NET_Framework__17___IEnumerable_.Models
{

    internal class User
    {

        // Числовой идентификатор
        private int _id;
        public int Id{
            get => _id;
        } // Id

        // Генерируем числовой идентификатор
        private void InitializeId(){
            DateTime nowDate = DateTime.Now;
            _id = nowDate.Year * 10_000 +
                  nowDate.Month * 100 +
                  nowDate.Day;
        }

        // Фамилия, имя
        private string _fio;
        public string Fio {
            get => _fio;
            set => _fio = string.IsNullOrWhiteSpace(value) ? throw new Exception("User: Недопустимое имя") : value;
        } // Fio

        // знак зодиака
        private string _zodiac;
        public string Zodiac {
            get => _zodiac;
            private set =>
                _zodiac = ValidZodiac(value) ?value: throw new Exception("User: Недопустимый знак зодика");
        } // Zodiac
        public bool ValidZodiac(string val){
            string[] zodiacs = {"Овен","Телец", "Близнецы", "Рак", "Лев", "Дева",
                                "Весы","Скорпион","Стрелец","Козерог","Водолей","Рыбы",
                                "овен","телец","близнецы","рак","лев","лева",
                                "весы","скорпион","стрелец","козерог","водолей","рыбы",};

            return (Array.FindIndex(zodiacs, item => item == val) == -1) ? false : true;
        }

        // Дата рождения
        private DateTime _date;
        public DateTime Date {
            get => _date;             
            set => _date = value;  
        } // Date                                                         

        public User() : this("Паучков Иван","Стрелец",new DateTime(2010,12,16)) { }
        public User(string fio, string zodiac, DateTime date ) {
            Fio = fio;
            Zodiac = zodiac;
            Date = date;
            InitializeId();
        } // User

        // вывод шапки таблицы
        // Шапка таблицы, статическое свойство
        public static string Header(int indent) =>
            $"┌────────┬────────────────────────┬──────────────┬───────────────┐\n" +
            $"│   id   │       Фамилия Имя      │    Зодиак    │ Дата рождения │\n" +
            $"├────────┼────────────────────────┼──────────────┼───────────────┤\n";
        

        // Подвал таблицы
        public static string Footer() =>
            $"└────────┴────────────────────────┴──────────────┴───────────────┘\n";

        // Переопределение метода, унаследованного от класса Object
        public override string ToString() => 
            $"Имя: {Fio}, дата рождения: {Date}\n" +
            $"Знак зодиака:{Zodiac}, id: {Id}";

        public string ToTableRow() =>
            $"│ {Id, 6} │ {_fio,-22} │ {Zodiac,-10} │ {Date,4:n2} │";
 
        // генерация объекта класса Person
        public static User Generate() {
            string[] fullNames = {
                "Морозов Павел",    "Лебедев Григорий",    "Субботина Марья",  "Леонтьева Светлана",
                "Сычева Любовь",  "Муравьев Николай",  "Аникин Александр", "Николаева Екатерина",
                "Дементьева Дарья", "Чернышева Ольга", "Анисимов Данил",  "Игнатов Даниил", 
            };
            string[] zodiacs = {"Овен","Телец", "Близнецы", "Рак", "Лев", "Дева",
                                "Весы","Скорпион","Стрелец","Козерог","Водолей","Рыбы",
                                "овен","телец","близнецы","рак","лев","лева",
                                "весы","скорпион","стрелец","козерог","водолей","рыбы",};

            int year  = Utils.GetRandom(1960, 2020);
            int month = Utils.GetRandom(1, 12);
            int day   = Utils.GetRandom(1, 28);

            return new User {
                Fio = fullNames[Utils.GetRandom(0, fullNames.Length - 1)],
                Zodiac = zodiacs[Utils.GetRandom(0, zodiacs.Length - 1)],
                Date = new DateTime(year, month, day)};
        } // Generate
    
    } // class User
}