﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using C_Sharp.NET_Framework__17___IEnumerable_.Models;

namespace C_Sharp.NET_Framework__17___IEnumerable_.Application
{
    partial class App
    {

        
        // ансамбль конструктлоров




        // формирование исходных данных - частичный метод



    }
}

