﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

 
using C_Sharp.NET_Framework__17___IEnumerable_.Models;

namespace C_Sharp_.NET_Framework__14___Generic_.Application
{
    partial class App{
        



    } // App
}
