﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace C_Sharp.NET_Framework__17___IEnumerable_.Models
{
    internal class Department {

        // Размер коллекции по умолчанию
        private const int DefNumber = 20;
 
        
        // Коллекция элементов типа User
        private ObservableCollection<User> _users;
        public ObservableCollection<User> Users{
            get => _users;
            set => _users = value;
        }
        
        // Набор конструкторов
        public Department():this(new ObservableCollection<User>(new User[DefNumber])){
            Initialize();
        }

        public Department(ObservableCollection<User> users){
            Users = users;
        }

        // Заполнение коллекции данными
        public void Initialize(){
            for (int i = 0; i < Users.Count(); i++)
                Users[i] = User.Generate();
        } // Initialize

    }
    
}
