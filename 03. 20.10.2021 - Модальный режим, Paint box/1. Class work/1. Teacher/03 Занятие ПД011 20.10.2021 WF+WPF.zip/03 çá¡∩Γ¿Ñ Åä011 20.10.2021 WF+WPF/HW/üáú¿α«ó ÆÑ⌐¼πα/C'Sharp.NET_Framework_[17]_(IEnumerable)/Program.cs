﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using C_Sharp.NET_Framework__17___IEnumerable_.Models;
using C_Sharp.NET_Framework__17___IEnumerable_.Application;


namespace C_Sharp.NET_Framework__17___IEnumerable_
{
    class Programs
    {
        static void Main(string[] args)
        {

            App app = new App();
            Console.SetWindowSize(140, 32);
            while (true)
            {
                try
                {

                    int y = 4;
                    int x = 17;
                    bool flu = true;

                    string sep1 = "<|-----------------------------------------------|>";
                    string[] items = {
                        "<|                       MENU                    |>",
                        "<|   №   >|<              Задания                |>",
                        "<|   1   >|<              Задача 1               |>",
                        "<|   2   >|<              Задача 2               |>",
                        "<|   3   >|<              Задача 3               |>",
                        "<|   4   >|<              Задача 4               |>",
                        "<|  ESC  >|<               EXIT                  |>"
                    };
 
                    if (!flu) Console.Clear();
                        
                    Array.ForEach(items, item => {
                        Utils.WriteXY(x, y++, sep1, ConsoleColor.Black, ConsoleColor.White);
                        Utils.WriteXY(x, y++, item, ConsoleColor.Black, ConsoleColor.White);
                    });
                    Utils.WriteXY(x, y++, sep1, ConsoleColor.Black, ConsoleColor.White);

                    Console.CursorVisible = false;
                    Console.Write("\n\n\t    Укажите номер выбранного пункта");
                    ConsoleKey key = Console.ReadKey(true).Key;
                   
                    Console.Clear();

                    
                
                    switch (key)
                    {
                         case ConsoleKey.D1:
                            //    Выдает ошибку "Process is terminated due to StackOverflowException."
                            // как я понял по статьям из интернета, у меня где-то создается рекурсия
                            // и стек переполняется, но я не могу понять где (возможно в каком-то свойстве)
                            User user = new User(); 
                            Console.WriteLine(user); 
                            break;
                         // case ConsoleKey.D2: app. ;  break;
                         // case ConsoleKey.D3: app. ;  break;
                         // case ConsoleKey.D4: app. ;  break;
                         // case ConsoleKey.Escape: Console.Write("\n\n\tДо свидания\n"); return;
                        default:
                            throw new Exception("Данный пункт меню отсутствует *.,.* ");
                    } // switch

                } // try
                
                catch (Exception ex)
                {
                    int StartX  = 37;    // координата вывода самых левых элементов
                    int FinishX = 98;   //  координата вывода самых правых элементов
                    int TitleX  = 46;  //   координата вывода исключения
                    int y       = 15; //    изменения высоты, на которой выводяться строки в консоль

                    Console.Clear();
                    Utils.WriteXY(StartX, y++, "**************************************************************", ConsoleColor.White, ConsoleColor.Red);

                    Utils.WriteXY(StartX, y, "*", ConsoleColor.White, ConsoleColor.Red);
                    Utils.WriteXY(TitleX, y, "                    Error                    ", ConsoleColor.DarkRed);
                    Utils.WriteXY(FinishX, y++, "*", ConsoleColor.White, ConsoleColor.Red);

                    Utils.WriteXY(StartX, y, "*", ConsoleColor.White, ConsoleColor.Red);
                    Utils.WriteXY(TitleX-5, y, ex.Message, ConsoleColor.Red);
                    Utils.WriteXY(FinishX, y++, "*", ConsoleColor.White, ConsoleColor.Red);

                    Utils.WriteXY(StartX, y, "**************************************************************", ConsoleColor.White, ConsoleColor.Red);
                } // try-catch
                Console.CursorVisible = true;
                Console.ReadKey(false);
                Console.ResetColor();
                Console.Clear();
            }// while
 
        } // Main

    } // Program
} // C_Sharp.NET_Framework__17___IEnumerable_
