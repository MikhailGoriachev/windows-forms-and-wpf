﻿
namespace C_Sharp.NET_Framework_WF_2__TextInputOutptut_
{
    partial class MainForm
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.GrbInputData = new System.Windows.Forms.GroupBox();
            this.LblThreadNumber = new System.Windows.Forms.Label();
            this.LblSecondNumber = new System.Windows.Forms.Label();
            this.LblFirstNumber = new System.Windows.Forms.Label();
            this.TbxThreadNumber = new System.Windows.Forms.TextBox();
            this.TbxSecondNumber = new System.Windows.Forms.TextBox();
            this.TbxFirstNumber = new System.Windows.Forms.TextBox();
            this.GrbResult = new System.Windows.Forms.GroupBox();
            this.LblResult = new System.Windows.Forms.Label();
            this.BthSumLargest = new System.Windows.Forms.Button();
            this.BthProcOrdering = new System.Windows.Forms.Button();
            this.BthQuit = new System.Windows.Forms.Button();
            this.ErpNumberFirst = new System.Windows.Forms.ErrorProvider(this.components);
            this.ErpNumberSecond = new System.Windows.Forms.ErrorProvider(this.components);
            this.ErpNumberThread = new System.Windows.Forms.ErrorProvider(this.components);
            this.GrbInputData.SuspendLayout();
            this.GrbResult.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ErpNumberFirst)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ErpNumberSecond)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ErpNumberThread)).BeginInit();
            this.SuspendLayout();
            // 
            // GrbInputData
            // 
            this.GrbInputData.Controls.Add(this.LblThreadNumber);
            this.GrbInputData.Controls.Add(this.LblSecondNumber);
            this.GrbInputData.Controls.Add(this.LblFirstNumber);
            this.GrbInputData.Controls.Add(this.TbxThreadNumber);
            this.GrbInputData.Controls.Add(this.TbxSecondNumber);
            this.GrbInputData.Controls.Add(this.TbxFirstNumber);
            this.GrbInputData.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.GrbInputData.Location = new System.Drawing.Point(24, 48);
            this.GrbInputData.Name = "GrbInputData";
            this.GrbInputData.Size = new System.Drawing.Size(432, 304);
            this.GrbInputData.TabIndex = 0;
            this.GrbInputData.TabStop = false;
            this.GrbInputData.Text = " Ввод данных: ";
            // 
            // LblThreadNumber
            // 
            this.LblThreadNumber.AutoSize = true;
            this.LblThreadNumber.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblThreadNumber.Location = new System.Drawing.Point(16, 216);
            this.LblThreadNumber.Name = "LblThreadNumber";
            this.LblThreadNumber.Size = new System.Drawing.Size(239, 27);
            this.LblThreadNumber.TabIndex = 1;
            this.LblThreadNumber.Text = "Введите третье число:";
            // 
            // LblSecondNumber
            // 
            this.LblSecondNumber.AutoSize = true;
            this.LblSecondNumber.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblSecondNumber.Location = new System.Drawing.Point(16, 136);
            this.LblSecondNumber.Name = "LblSecondNumber";
            this.LblSecondNumber.Size = new System.Drawing.Size(241, 27);
            this.LblSecondNumber.TabIndex = 1;
            this.LblSecondNumber.Text = "Введите второе число:";
            // 
            // LblFirstNumber
            // 
            this.LblFirstNumber.AutoSize = true;
            this.LblFirstNumber.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblFirstNumber.Location = new System.Drawing.Point(16, 56);
            this.LblFirstNumber.Name = "LblFirstNumber";
            this.LblFirstNumber.Size = new System.Drawing.Size(244, 27);
            this.LblFirstNumber.TabIndex = 1;
            this.LblFirstNumber.Text = "Введите первое число:";
            // 
            // TbxThreadNumber
            // 
            this.TbxThreadNumber.Location = new System.Drawing.Point(24, 248);
            this.TbxThreadNumber.Multiline = true;
            this.TbxThreadNumber.Name = "TbxThreadNumber";
            this.TbxThreadNumber.Size = new System.Drawing.Size(320, 32);
            this.TbxThreadNumber.TabIndex = 0;
            this.TbxThreadNumber.Text = "0";
            // 
            // TbxSecondNumber
            // 
            this.TbxSecondNumber.Location = new System.Drawing.Point(24, 168);
            this.TbxSecondNumber.Multiline = true;
            this.TbxSecondNumber.Name = "TbxSecondNumber";
            this.TbxSecondNumber.Size = new System.Drawing.Size(320, 32);
            this.TbxSecondNumber.TabIndex = 0;
            this.TbxSecondNumber.Text = "0";
            // 
            // TbxFirstNumber
            // 
            this.TbxFirstNumber.Location = new System.Drawing.Point(24, 88);
            this.TbxFirstNumber.Multiline = true;
            this.TbxFirstNumber.Name = "TbxFirstNumber";
            this.TbxFirstNumber.Size = new System.Drawing.Size(312, 32);
            this.TbxFirstNumber.TabIndex = 0;
            this.TbxFirstNumber.Text = "0";
            // 
            // GrbResult
            // 
            this.GrbResult.BackColor = System.Drawing.Color.Transparent;
            this.GrbResult.Controls.Add(this.LblResult);
            this.GrbResult.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.GrbResult.Location = new System.Drawing.Point(544, 48);
            this.GrbResult.Name = "GrbResult";
            this.GrbResult.Size = new System.Drawing.Size(432, 344);
            this.GrbResult.TabIndex = 1;
            this.GrbResult.TabStop = false;
            this.GrbResult.Text = " Результат: ";
            // 
            // LblResult
            // 
            this.LblResult.BackColor = System.Drawing.Color.DarkSlateGray;
            this.LblResult.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.LblResult.Location = new System.Drawing.Point(8, 32);
            this.LblResult.Name = "LblResult";
            this.LblResult.Size = new System.Drawing.Size(416, 304);
            this.LblResult.TabIndex = 0;
            this.LblResult.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // BthSumLargest
            // 
            this.BthSumLargest.BackColor = System.Drawing.Color.Snow;
            this.BthSumLargest.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BthSumLargest.Location = new System.Drawing.Point(40, 440);
            this.BthSumLargest.Name = "BthSumLargest";
            this.BthSumLargest.Size = new System.Drawing.Size(192, 64);
            this.BthSumLargest.TabIndex = 2;
            this.BthSumLargest.Text = "Сумма наибольших";
            this.BthSumLargest.UseVisualStyleBackColor = false;
            this.BthSumLargest.Click += new System.EventHandler(this.BthSumLargest_Click);
            // 
            // BthProcOrdering
            // 
            this.BthProcOrdering.BackColor = System.Drawing.Color.Snow;
            this.BthProcOrdering.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BthProcOrdering.Location = new System.Drawing.Point(272, 440);
            this.BthProcOrdering.Name = "BthProcOrdering";
            this.BthProcOrdering.Size = new System.Drawing.Size(192, 64);
            this.BthProcOrdering.TabIndex = 2;
            this.BthProcOrdering.Text = "Обработка по упорядоченности";
            this.BthProcOrdering.UseVisualStyleBackColor = false;
            this.BthProcOrdering.Click += new System.EventHandler(this.BthProcOrdering_Click);
            // 
            // BthQuit
            // 
            this.BthQuit.BackColor = System.Drawing.Color.DarkSalmon;
            this.BthQuit.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BthQuit.Location = new System.Drawing.Point(752, 440);
            this.BthQuit.Name = "BthQuit";
            this.BthQuit.Size = new System.Drawing.Size(192, 64);
            this.BthQuit.TabIndex = 2;
            this.BthQuit.Text = "Выход";
            this.BthQuit.UseVisualStyleBackColor = false;
            this.BthQuit.Click += new System.EventHandler(this.BthQuit_Click);
            // 
            // ErpNumberFirst
            // 
            this.ErpNumberFirst.ContainerControl = this;
            // 
            // ErpNumberSecond
            // 
            this.ErpNumberSecond.ContainerControl = this;
            // 
            // ErpNumberThread
            // 
            this.ErpNumberThread.ContainerControl = this;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(120F, 120F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.AutoValidate = System.Windows.Forms.AutoValidate.EnablePreventFocusChange;
            this.BackColor = System.Drawing.Color.GhostWhite;
            this.ClientSize = new System.Drawing.Size(1015, 524);
            this.ControlBox = false;
            this.Controls.Add(this.BthQuit);
            this.Controls.Add(this.BthProcOrdering);
            this.Controls.Add(this.BthSumLargest);
            this.Controls.Add(this.GrbResult);
            this.Controls.Add(this.GrbInputData);
            this.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ДЗ 20.10.2021";
            this.GrbInputData.ResumeLayout(false);
            this.GrbInputData.PerformLayout();
            this.GrbResult.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.ErpNumberFirst)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ErpNumberSecond)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ErpNumberThread)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox GrbInputData;
        private System.Windows.Forms.GroupBox GrbResult;
        private System.Windows.Forms.Label LblResult;
        private System.Windows.Forms.Label LblThreadNumber;
        private System.Windows.Forms.Label LblSecondNumber;
        private System.Windows.Forms.Label LblFirstNumber;
        private System.Windows.Forms.TextBox TbxThreadNumber;
        private System.Windows.Forms.TextBox TbxSecondNumber;
        private System.Windows.Forms.TextBox TbxFirstNumber;
        private System.Windows.Forms.Button BthSumLargest;
        private System.Windows.Forms.Button BthProcOrdering;
        private System.Windows.Forms.Button BthQuit;
        private System.Windows.Forms.ErrorProvider ErpNumberFirst;
        private System.Windows.Forms.ErrorProvider ErpNumberSecond;
        private System.Windows.Forms.ErrorProvider ErpNumberThread;
    }
}

