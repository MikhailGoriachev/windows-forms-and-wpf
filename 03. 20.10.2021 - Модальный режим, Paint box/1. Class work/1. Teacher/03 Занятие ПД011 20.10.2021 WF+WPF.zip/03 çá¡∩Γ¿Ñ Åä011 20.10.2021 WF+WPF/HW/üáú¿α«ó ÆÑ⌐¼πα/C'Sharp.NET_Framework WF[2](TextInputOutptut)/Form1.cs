﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace C_Sharp.NET_Framework_WF_2__TextInputOutptut_
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void BthSumLargest_Click(object sender, EventArgs e){
            // Цвет вывода сообщения об ошибке
            Color ErrColor = Color.GreenYellow;
            int sum = 0;
            
            // проверка на правильность ввода
            bool result = int.TryParse(TbxFirstNumber.Text, out int a);
            if (!result){
                // чтобы не добовлять еще одну переменную используем переменную sum
                // как идентификатор что в хотя бы одном из вводов была допущена ошибка
                sum = -1;
                LblResult.ForeColor = ErrColor;
                ErpNumberFirst.SetError(TbxFirstNumber, LblResult.Text = "Неверные данные!");
            }
            else ErpNumberFirst.SetError(TbxFirstNumber,  "");

            result = int.TryParse(TbxSecondNumber.Text, out int b);
            if (!result)
            {
                sum = -1;
                LblResult.ForeColor = ErrColor;
                ErpNumberSecond.SetError(TbxSecondNumber, LblResult.Text = "Неверные данные!");
            }
            else ErpNumberSecond.SetError(TbxSecondNumber,  "");

            result = int.TryParse(TbxThreadNumber.Text, out int c);
            if (!result)
            {
                sum = -1;
                LblResult.ForeColor = ErrColor;
                ErpNumberThread.SetError(TbxThreadNumber, LblResult.Text = "Неверные данные!");
            }
            else ErpNumberThread.SetError(TbxThreadNumber, "");
            

            // по скольку в одном из вводов точно была допущена ошибка,
            // то нет смысла продолжать обработку
            if (sum == -1) return;
            
            // Изменяем цвет элемента LabelResult на основной
            // т.к. возможно что в прошлой обработки данного пункта
            // была допущена ошибка и цвет был поменян
            LblResult.ForeColor = Color.WhiteSmoke;
            
            // обработка по заданию:
            // найти сумму двух наибольших чисел из трех
            if (a == b && b == c){
                sum = a + b + c;
                LblResult.Text = $"Числа {a}, {b}, {c} одинаковы по значению.\nСумма 3-х чисел: {sum}";
                return;
            }
            if (a > c && b > c)      // 9  5  2
                sum = a + b;
            else if (b >= a && c >= a) // 3  6  5
                sum = b + c;
            else sum = c + a;        // 7  2  4

            LblResult.Text = $"Из трех чисел {a}, {b}, {c}\nСумма 2-х наибольших чисел: {sum}";
        }

        private void BthQuit_Click(object sender, EventArgs e) => Close();

        private void BthProcOrdering_Click(object sender, EventArgs e){
            // Цвет вывода сообщения об ошибке
            Color ErrColor = Color.GreenYellow;
            bool flag = false;  // идентификатор о ошибке(true - допущена ошибка)

            // проверка на правильность ввода
            bool result = double.TryParse(TbxFirstNumber.Text, out double A);
            if (!result)
            {
 
                flag = true;
                LblResult.ForeColor = ErrColor;
                ErpNumberFirst.SetError(TbxFirstNumber, LblResult.Text = "Неверные данные!");
            }
            else ErpNumberFirst.SetError(TbxFirstNumber, "");

            result = double.TryParse(TbxSecondNumber.Text, out double B);
            if (!result)
            {
                flag = true;
                LblResult.ForeColor = ErrColor;
                ErpNumberSecond.SetError(TbxSecondNumber, LblResult.Text = "Неверные данные!");
            }
            else ErpNumberSecond.SetError(TbxSecondNumber, "");

            result = double.TryParse(TbxThreadNumber.Text, out double C);
            if (!result)
            {
                flag = true;
                LblResult.ForeColor = ErrColor;
                ErpNumberThread.SetError(TbxThreadNumber, LblResult.Text = "Неверные данные!");
            }
            else ErpNumberThread.SetError(TbxThreadNumber, "");


            // по скольку в одном из вводов точно была допущена ошибка,
            // то нет смысла продолжать обработку
            if (flag) return;

            // Изменяем цвет элемента LabelResult на основной
            // т.к. возможно что в прошлой обработки данного пункта
            // была допущена ошибка и цвет был поменян
            LblResult.ForeColor = Color.WhiteSmoke;

            // обработка по заданию:
            // Даны три переменные вещественного типа:
            // если их значения упорядочены по возрастанию или убыванию, то удвоить их;
            // в противном случае заменить значение каждой переменной на противоположное. 

            if(A > B && B > C || A < B && B < C){
                A = A * 2;
                B = B * 2;
                C = C * 2;
            } else{
                A = -A;
                B = -B;
                C = -C;
            }

            LblResult.Text = $"Значения переменны после обработки:\n A = {A}, B = {B}, C = {C}";
        }
    }
}
