﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HW2
{
	public partial class MainForm : Form
	{
		public MainForm() =>
			InitializeComponent();

		private void MainForm_Load(object sender, EventArgs e)
		{}
		
		// при начале ввода данных в поле ввода числа A убираем 
		// признак ошибки для ErrorProvider
		private void TbxFirstNumber_TextChanged(object sender, EventArgs e) =>
			ErpNumberA.SetError(TbxFirstNumber, "");
		
		// при начале ввода данных в поле ввода числа B убираем 
		// признак ошибки для ErrorProvider
		private void TbxSecndNumber_TextChanged(object sender, EventArgs e) =>
			ErpNumberB.SetError(TbxSecndNumber, "");
		
		// при начале ввода данных в поле ввода числа С убираем 
		// признак ошибки для ErrorProvider
		private void TbxThirdNumber_TextChanged(object sender, EventArgs e) =>
			ErpNumberC.SetError(TbxThirdNumber, "");

		// Даны три переменные вещественного типа.
		// Найти сумму двух наибольших из них (т.е. для чисел 1, 2, 3 сумма будет равна 5).
		private void BtnLf15_Click(object sender, EventArgs e)
		{
			// проверка корректности ввода данных - число A 
			bool result = double.TryParse(TbxFirstNumber.Text, out double a);
			ErpNumberA.SetError(TbxFirstNumber, !result ? "Недопустимый формат" : "");

			// аналогичный ввод и проверка для числа B
			result = double.TryParse(TbxSecndNumber.Text, out double b);
			ErpNumberB.SetError(TbxSecndNumber, !result ? "Недопустимый формат" : "");

			// аналогичный ввод и проверка для числа C
			result = double.TryParse(TbxThirdNumber.Text, out double c);
			ErpNumberC.SetError(TbxThirdNumber, !result ? "Недопустимый формат" : "");

			// Если есть невалидные данные, вывести об этом в результатах
			if (!string.IsNullOrEmpty(ErpNumberA.GetError(TbxFirstNumber)) ||
			    !string.IsNullOrEmpty(ErpNumberB.GetError(TbxSecndNumber)) ||
			    !string.IsNullOrEmpty(ErpNumberC.GetError(TbxThirdNumber)))
			{
				LblResult.Text = "Введены неверные данные";
				return;
			}

			// обработка по заданию - ищем сумму двух наибольших
			// из трех чисел A, B, C
			LblResult.Text = new List<double> {a, b, c}.OrderBy(x => x).Skip(1).Sum().ToString();
		}


		// Даны три переменные вещественного типа: A, B, C. Если их значения упорядочены по возрастанию
		// или убыванию, то удвоить их; в противном случае заменить значение каждой переменной на противоположное.
		// Вывести новые значения переменных A, B, C.
		private void BtnLf17_Click(object sender, EventArgs e)
		{
			// проверка корректности ввода данных - число A 
			bool result = double.TryParse(TbxFirstNumber.Text, out double a);
			ErpNumberA.SetError(TbxFirstNumber, !result ? "Недопустимый формат" : "");

			// аналогичный ввод и проверка для числа B
			result = double.TryParse(TbxSecndNumber.Text, out double b);
			ErpNumberB.SetError(TbxSecndNumber, !result ? "Недопустимый формат" : "");

			// аналогичный ввод и проверка для числа C
			result = double.TryParse(TbxThirdNumber.Text, out double c);
			ErpNumberC.SetError(TbxThirdNumber, !result ? "Недопустимый формат" : "");

			// Если есть невалидные данные, вывести об этом в результатах
			if (!string.IsNullOrEmpty(ErpNumberA.GetError(TbxFirstNumber)) ||
			    !string.IsNullOrEmpty(ErpNumberB.GetError(TbxSecndNumber)) ||
			    !string.IsNullOrEmpty(ErpNumberC.GetError(TbxThirdNumber)))
			{
				LblResult.Text = "Введены неверные данные";
				return;
			}

			// Выврл результатов по заданию
			LblResult.Text = ((b > a && c > b) || (b < a && c < b))
				? $"A = {(a * a),2:f}; B = {(b * b),2:f}; C = {(c * c),2:f}"
				: $"A = {(-a),2:f}; B = {(-b),2:f}; C = {(-c),2:f}";
		}

		// Кнопка выхода из приложения
		private void BtnExit_Click(object sender, EventArgs e) => Close();
	}
}
