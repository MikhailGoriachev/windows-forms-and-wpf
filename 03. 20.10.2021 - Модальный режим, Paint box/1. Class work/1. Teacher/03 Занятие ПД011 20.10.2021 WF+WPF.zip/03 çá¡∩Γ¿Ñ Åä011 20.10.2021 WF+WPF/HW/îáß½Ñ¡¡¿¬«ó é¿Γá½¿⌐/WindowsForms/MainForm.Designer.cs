﻿
namespace HW2
{
	partial class MainForm
	{
		/// <summary>
		/// Обязательная переменная конструктора.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Освободить все используемые ресурсы.
		/// </summary>
		/// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Код, автоматически созданный конструктором форм Windows

		/// <summary>
		/// Требуемый метод для поддержки конструктора — не изменяйте 
		/// содержимое этого метода с помощью редактора кода.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
			this.GrbResult = new System.Windows.Forms.GroupBox();
			this.LblResult = new System.Windows.Forms.Label();
			this.GrbInputData = new System.Windows.Forms.GroupBox();
			this.TbxThirdNumber = new System.Windows.Forms.TextBox();
			this.LblThirdNumber = new System.Windows.Forms.Label();
			this.TbxSecndNumber = new System.Windows.Forms.TextBox();
			this.LblSecndNumber = new System.Windows.Forms.Label();
			this.TbxFirstNumber = new System.Windows.Forms.TextBox();
			this.LblFirstNumber = new System.Windows.Forms.Label();
			this.ErpNumberA = new System.Windows.Forms.ErrorProvider(this.components);
			this.ErpNumberB = new System.Windows.Forms.ErrorProvider(this.components);
			this.ErpNumberC = new System.Windows.Forms.ErrorProvider(this.components);
			this.BtnLf15 = new System.Windows.Forms.Button();
			this.BtnLf17 = new System.Windows.Forms.Button();
			this.BtnExit = new System.Windows.Forms.Button();
			this.LblLf15 = new System.Windows.Forms.Label();
			this.LblLf17 = new System.Windows.Forms.Label();
			this.GrbTaskInfo = new System.Windows.Forms.GroupBox();
			this.GrbResult.SuspendLayout();
			this.GrbInputData.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.ErpNumberA)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.ErpNumberB)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.ErpNumberC)).BeginInit();
			this.GrbTaskInfo.SuspendLayout();
			this.SuspendLayout();
			// 
			// GrbResult
			// 
			this.GrbResult.Controls.Add(this.LblResult);
			this.GrbResult.Font = new System.Drawing.Font("Verdana", 10F);
			this.GrbResult.Location = new System.Drawing.Point(232, 23);
			this.GrbResult.Name = "GrbResult";
			this.GrbResult.Size = new System.Drawing.Size(269, 259);
			this.GrbResult.TabIndex = 3;
			this.GrbResult.TabStop = false;
			this.GrbResult.Text = " Результат: ";
			// 
			// LblResult
			// 
			this.LblResult.BackColor = System.Drawing.Color.Honeydew;
			this.LblResult.Dock = System.Windows.Forms.DockStyle.Fill;
			this.LblResult.Location = new System.Drawing.Point(3, 20);
			this.LblResult.Name = "LblResult";
			this.LblResult.Size = new System.Drawing.Size(263, 236);
			this.LblResult.TabIndex = 0;
			this.LblResult.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// GrbInputData
			// 
			this.GrbInputData.Controls.Add(this.TbxThirdNumber);
			this.GrbInputData.Controls.Add(this.LblThirdNumber);
			this.GrbInputData.Controls.Add(this.TbxSecndNumber);
			this.GrbInputData.Controls.Add(this.LblSecndNumber);
			this.GrbInputData.Controls.Add(this.TbxFirstNumber);
			this.GrbInputData.Controls.Add(this.LblFirstNumber);
			this.GrbInputData.Font = new System.Drawing.Font("Verdana", 10F);
			this.GrbInputData.Location = new System.Drawing.Point(21, 23);
			this.GrbInputData.Name = "GrbInputData";
			this.GrbInputData.Size = new System.Drawing.Size(191, 259);
			this.GrbInputData.TabIndex = 2;
			this.GrbInputData.TabStop = false;
			this.GrbInputData.Text = " Исходные данные: ";
			// 
			// TbxThirdNumber
			// 
			this.TbxThirdNumber.Location = new System.Drawing.Point(18, 194);
			this.TbxThirdNumber.Name = "TbxThirdNumber";
			this.TbxThirdNumber.Size = new System.Drawing.Size(114, 24);
			this.TbxThirdNumber.TabIndex = 5;
			this.TbxThirdNumber.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.TbxThirdNumber.TextChanged += new System.EventHandler(this.TbxThirdNumber_TextChanged);
			// 
			// LblThirdNumber
			// 
			this.LblThirdNumber.AutoSize = true;
			this.LblThirdNumber.Font = new System.Drawing.Font("Verdana", 10F);
			this.LblThirdNumber.Location = new System.Drawing.Point(18, 174);
			this.LblThirdNumber.Name = "LblThirdNumber";
			this.LblThirdNumber.Size = new System.Drawing.Size(111, 17);
			this.LblThirdNumber.TabIndex = 4;
			this.LblThirdNumber.Text = "Третье число:";
			// 
			// TbxSecndNumber
			// 
			this.TbxSecndNumber.Location = new System.Drawing.Point(18, 129);
			this.TbxSecndNumber.Name = "TbxSecndNumber";
			this.TbxSecndNumber.Size = new System.Drawing.Size(114, 24);
			this.TbxSecndNumber.TabIndex = 3;
			this.TbxSecndNumber.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.TbxSecndNumber.TextChanged += new System.EventHandler(this.TbxSecndNumber_TextChanged);
			// 
			// LblSecndNumber
			// 
			this.LblSecndNumber.AutoSize = true;
			this.LblSecndNumber.Font = new System.Drawing.Font("Verdana", 10F);
			this.LblSecndNumber.Location = new System.Drawing.Point(18, 109);
			this.LblSecndNumber.Name = "LblSecndNumber";
			this.LblSecndNumber.Size = new System.Drawing.Size(114, 17);
			this.LblSecndNumber.TabIndex = 2;
			this.LblSecndNumber.Text = "Второе число:";
			// 
			// TbxFirstNumber
			// 
			this.TbxFirstNumber.Location = new System.Drawing.Point(18, 69);
			this.TbxFirstNumber.Name = "TbxFirstNumber";
			this.TbxFirstNumber.Size = new System.Drawing.Size(114, 24);
			this.TbxFirstNumber.TabIndex = 1;
			this.TbxFirstNumber.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.TbxFirstNumber.TextChanged += new System.EventHandler(this.TbxFirstNumber_TextChanged);
			// 
			// LblFirstNumber
			// 
			this.LblFirstNumber.AutoSize = true;
			this.LblFirstNumber.Font = new System.Drawing.Font("Verdana", 10F);
			this.LblFirstNumber.Location = new System.Drawing.Point(18, 47);
			this.LblFirstNumber.Name = "LblFirstNumber";
			this.LblFirstNumber.Size = new System.Drawing.Size(114, 17);
			this.LblFirstNumber.TabIndex = 0;
			this.LblFirstNumber.Text = "Первое число:";
			// 
			// ErpNumberA
			// 
			this.ErpNumberA.ContainerControl = this;
			// 
			// ErpNumberB
			// 
			this.ErpNumberB.ContainerControl = this;
			// 
			// ErpNumberC
			// 
			this.ErpNumberC.ContainerControl = this;
			// 
			// BtnLf15
			// 
			this.BtnLf15.Location = new System.Drawing.Point(21, 408);
			this.BtnLf15.Name = "BtnLf15";
			this.BtnLf15.Size = new System.Drawing.Size(226, 33);
			this.BtnLf15.TabIndex = 4;
			this.BtnLf15.Text = "Посчитать";
			this.BtnLf15.UseVisualStyleBackColor = true;
			this.BtnLf15.Click += new System.EventHandler(this.BtnLf15_Click);
			// 
			// BtnLf17
			// 
			this.BtnLf17.Location = new System.Drawing.Point(267, 408);
			this.BtnLf17.Name = "BtnLf17";
			this.BtnLf17.Size = new System.Drawing.Size(228, 33);
			this.BtnLf17.TabIndex = 5;
			this.BtnLf17.Text = "Посчитать";
			this.BtnLf17.UseVisualStyleBackColor = true;
			this.BtnLf17.Click += new System.EventHandler(this.BtnLf17_Click);
			// 
			// BtnExit
			// 
			this.BtnExit.Location = new System.Drawing.Point(21, 457);
			this.BtnExit.Name = "BtnExit";
			this.BtnExit.Size = new System.Drawing.Size(474, 33);
			this.BtnExit.TabIndex = 6;
			this.BtnExit.Text = "Выход";
			this.BtnExit.UseVisualStyleBackColor = true;
			this.BtnExit.Click += new System.EventHandler(this.BtnExit_Click);
			// 
			// LblLf15
			// 
			this.LblLf15.BackColor = System.Drawing.SystemColors.ButtonHighlight;
			this.LblLf15.Location = new System.Drawing.Point(6, 16);
			this.LblLf15.Name = "LblLf15";
			this.LblLf15.Size = new System.Drawing.Size(229, 92);
			this.LblLf15.TabIndex = 7;
			this.LblLf15.Text = "Даны три переменные вещественного типа. Найти сумму двух наибольших из них (т.е. " +
    "для чисел 1, 2, 3 сумма будет равна 5).";
			this.LblLf15.TextAlign = System.Drawing.ContentAlignment.TopCenter;
			// 
			// LblLf17
			// 
			this.LblLf17.BackColor = System.Drawing.SystemColors.ButtonHighlight;
			this.LblLf17.Location = new System.Drawing.Point(251, 16);
			this.LblLf17.Name = "LblLf17";
			this.LblLf17.Size = new System.Drawing.Size(231, 92);
			this.LblLf17.TabIndex = 8;
			this.LblLf17.Text = resources.GetString("LblLf17.Text");
			this.LblLf17.TextAlign = System.Drawing.ContentAlignment.TopCenter;
			// 
			// GrbTaskInfo
			// 
			this.GrbTaskInfo.Controls.Add(this.LblLf17);
			this.GrbTaskInfo.Controls.Add(this.LblLf15);
			this.GrbTaskInfo.Location = new System.Drawing.Point(13, 288);
			this.GrbTaskInfo.Name = "GrbTaskInfo";
			this.GrbTaskInfo.Size = new System.Drawing.Size(488, 114);
			this.GrbTaskInfo.TabIndex = 9;
			this.GrbTaskInfo.TabStop = false;
			this.GrbTaskInfo.Text = "Условия заданий";
			// 
			// MainForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
			this.ClientSize = new System.Drawing.Size(523, 522);
			this.Controls.Add(this.GrbTaskInfo);
			this.Controls.Add(this.BtnExit);
			this.Controls.Add(this.BtnLf17);
			this.Controls.Add(this.BtnLf15);
			this.Controls.Add(this.GrbResult);
			this.Controls.Add(this.GrbInputData);
			this.Name = "MainForm";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Домашняя работа";
			this.Load += new System.EventHandler(this.MainForm_Load);
			this.GrbResult.ResumeLayout(false);
			this.GrbInputData.ResumeLayout(false);
			this.GrbInputData.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.ErpNumberA)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.ErpNumberB)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.ErpNumberC)).EndInit();
			this.GrbTaskInfo.ResumeLayout(false);
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.GroupBox GrbResult;
		private System.Windows.Forms.Label LblResult;
		private System.Windows.Forms.GroupBox GrbInputData;
		private System.Windows.Forms.TextBox TbxThirdNumber;
		private System.Windows.Forms.Label LblThirdNumber;
		private System.Windows.Forms.TextBox TbxSecndNumber;
		private System.Windows.Forms.Label LblSecndNumber;
		private System.Windows.Forms.TextBox TbxFirstNumber;
		private System.Windows.Forms.Label LblFirstNumber;
		private System.Windows.Forms.ErrorProvider ErpNumberA;
		private System.Windows.Forms.ErrorProvider ErpNumberB;
		private System.Windows.Forms.ErrorProvider ErpNumberC;
		private System.Windows.Forms.Button BtnExit;
		private System.Windows.Forms.Button BtnLf17;
		private System.Windows.Forms.Button BtnLf15;
		private System.Windows.Forms.Label LblLf15;
		private System.Windows.Forms.Label LblLf17;
		private System.Windows.Forms.GroupBox GrbTaskInfo;
	}
}

