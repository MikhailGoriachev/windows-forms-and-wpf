﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Threading.Tasks;

namespace HW18.Models
{
	/*
	 * Описать класс с именем User, содержащую следующие поля:
		•	числовой идентификатор - int;
		•	фамилия, имя - string;
		•	знак Зодиака - string;
		•	дата рождения - DateTime
	 */
	internal class User
	{
		// числовой идентификатор
		private int _id;
		public int Id { get; set; }

		// фамилия, имя
		private string _name;

		public string Name
		{
			get => _name;
			set
			{
				if (string.IsNullOrWhiteSpace(value))
					throw new ArgumentException("User. Пустое имя пользователя недопустимо.");
				_name = value;
			}
		}

		// дата рождения
		private DateTime _dob;

		public DateTime Dob
		{
			get => _dob;
			set
			{
				_dob = value;
				_zodiacSign = GetZodiacSign(_dob);
			}
		}

		// знак Зодиака
		private string _zodiacSign;

		public string ZodiacSign
		{
			get => _zodiacSign;
			set
			{
				if (string.IsNullOrWhiteSpace(value))
					throw new ArgumentException("User. Пустое название знака зодиака недопустимо.");
				_zodiacSign = value;
			}
		}


		public User()
		{}


		public User(int id, string name, DateTime dob)
		{
			_id = id;
			_name = name;
			_zodiacSign = GetZodiacSign(dob);
			_dob = dob;
		}


		// Определение знака зодиака по дате
		public static string GetZodiacSign(DateTime dt) => dt.Month switch
		{
			1 => dt.Day <= 20 ? "Козерог" : "Водолей",
			2 => dt.Day <= 19 ? "Водолей" : "Рыбы",
			3 => dt.Day <= 21 ? "Рыбы" : "Овен",
			4 => dt.Day <= 20 ? "Овен" : "Телец",
			5 => dt.Day <= 21 ? "Телец" : "Близнецы",
			6 => dt.Day <= 22 ? "Близнецы" : "Рак",
			7 => dt.Day <= 23 ? "Рак" : "Лев",
			8 => dt.Day <= 23 ? "Лев" : "Дева",
			9 => dt.Day <= 24 ? "Дева" : "Весы",
			10 => dt.Day <= 23 ? "Весы" : "Скорпион",
			11 => dt.Day <= 23 ? "Скорпион" : "Стрелец",
			12 => dt.Day <= 22 ? "Стрелец" : "Козерог",
			_ => throw new ArgumentOutOfRangeException(nameof(dt), "User. Не удалось определить знак зодиака")
		};

		public override string ToString() =>
			$"[ID:{Id,2}] Фамилия Имя: {_name, -20} Дата рождения: {Dob:d} Знак зодиака: {ZodiacSign}";


		public static string Header() =>
			$"{Utilities.spaces}╔════╦══════════════════════════════╦═══════════════╦══════════════╗\n" +
			$"{Utilities.spaces}║ ID ║         Фамилия Имя          ║ Дата Рождения ║ Знак Зодиака ║\n" +
			$"{Utilities.spaces}╠════╬══════════════════════════════╬═══════════════╬══════════════╣\n";


		public string ToTableRow() =>
			$"{Utilities.spaces}║ {Id,2} ║ " +
			$"{$"{(Name.Length <= 28?Name:Name.Substring(0,25)+"...")}",-28} " +
			$"║ {Dob, 13:d} ║ {ZodiacSign,-12} ║\n";


		public static string Footer() =>
			$"{Utilities.spaces}╚════╩══════════════════════════════╩═══════════════╩══════════════╝\n";


		// Генерация объекта пользователя
		public static User Generate(int id)
		{
			string[] names =
			{
				"Данилов Максим",
				"Кузнецов Владимир",
				"Прокофьева Евгения",
				"Ильина Ариана",
				"Моисеева Полина",
				"Рожков Лев",
				"Куприянова Диана",
				"Калинин Тимофей",
				"Высоцкий Юрий",
				"Баранова Милана",
				"Семенов Матвей",
				"Иванова Таисия",
				"Колесников Семён",
				"Давыдова Ева",
				"Кузнецова Алина",
				"Кузнецов Артём",
				"Смирнов Степан",
				"Ушакова Диана",
				"Сергеев Илья",
				"Жуков Илья",
				"Козлова Полина",
				"Мартынова Ольга",
				"Агеев Даниил",
				"Харитонова Мария",
				"Королева Дарья",
				"Анисимов Алексей",
				"Овчинникова Алиса",
				"Антонов Степан",
				"Голубева Мирослава",
				"Семенова Кристина",
				"Кожевникова Мария",
				"Максимов Тимофей",
				"Терехова Альбина",
				"Воробьев Степан",
				"Федоров Тимофей",
				"Черных Богдан",
				"Быкова Анна",
				"Смирнова Анастасия",
				"Никонова Евгения",
				"Круглова Анна",
				"Большаков Филипп",
				"Михайлова Екатерин",
				"Павлов Степан",
				"Власова Вера",
				"Виноградова Виктория",
				"Андреев Артём",
				"Селиванова Агата",
				"Миронова Анастасия",
				"Зотова Алия",
				"Майорова Анна"
			};

			string name = names[Utilities.GenerateInt(0, names.Length)];
			DateTime dob = Utilities.GenerateDateTime();

			return new User {Id = id, Name = name, Dob = dob};
		}

	}
}
