﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HW18.Models;

namespace HW18
{
	internal partial class App
	{
		private Menu _mainMenu;

		private Department _department;


		public App():this(new Department())
		{}

		public App(Department department)
		{
			_department = department;
			InitMenu();
		}

		// Создание объектов меню
		private void InitMenu()
		{
			// Главное меню
			_mainMenu = new Menu(new[]
				{
					new Menu.MenuItem("Заполнение коллекции пользователей", MainMenuItem1),
					new Menu.MenuItem("Вывод информации о пользователях в консоль", MainMenuItem2),
					new Menu.MenuItem("Добавление трёх пользователей со знаком рыбы", MainMenuItem3),
					new Menu.MenuItem("Удаление всех пользователей старше 60 лет", MainMenuItem4),
					new Menu.MenuItem("Добавление строки \"-бе-бе\" к фамилии всех \"Овнов\"", MainMenuItem5),
					new Menu.MenuItem("Вывести в список и консоль записи с заданной фамилией", MainMenuItem6),
					new Menu.MenuItem("Вывести в список и консоль записи с заданным знаком Зодиака", MainMenuItem7),
					new Menu.MenuItem("Вывести в список и консоль записи с заданным месяцем рождения", MainMenuItem8),
					new Menu.MenuItem("Cортировка по дате рождения", MainMenuItem9),
					new Menu.MenuItem("Cортировка по названиям знаков Зодиака", MainMenuItem10),
					new Menu.MenuItem("Cортировка по фамилии, имени", MainMenuItem11),
					new Menu.MenuItem("Выход")
				}, new Point(5, 5),
				"Меню приложения");
		}

		

		public void Run() => _mainMenu.Run();
	}
}
