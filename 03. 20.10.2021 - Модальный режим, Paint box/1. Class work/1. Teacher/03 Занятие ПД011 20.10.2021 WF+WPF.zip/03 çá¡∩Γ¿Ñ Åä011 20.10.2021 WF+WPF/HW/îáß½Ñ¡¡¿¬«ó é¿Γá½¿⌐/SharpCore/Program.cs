﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HW18
{
	class Program
	{
		static void Main(string[] args)
		{
			Console.SetWindowSize(Console.LargestWindowWidth >= 125 ? 125 : Console.LargestWindowWidth,
				Console.LargestWindowHeight >= 40 ? 40: Console.LargestWindowHeight);
			
			Utilities.Palette.Ordinary.SetToConsole();

			App app = new App();
			app.Run();
		}
	}
}
