﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace HW18.Models
{
	// Класс Department со списком пользователей – коллекцией типа ObservableCollection<User>
	internal class Department
	{
		// Название отделения
		private string _name;
		public string Name
		{
			get => _name;
			set
			{
				if (string.IsNullOrWhiteSpace(value))
					throw new ArgumentException("Department. Пустое название отделения недопустимо");
				_name = value;
			}
		}

		// Коллекция пользователей
		private ObservableCollection<User> _users;

		// Количество пользователей в коллекции
		public int UsersCounter => _users.Count;

		#region Конструкторы

		// По умолчанию
		public Department() :this("Клиенты астрологического прогноза", new ObservableCollection<User>())
		{
			Initialize();
		}

		// С внедрением зависимостей
		public Department(string name, ObservableCollection<User> users)
		{
			_name = name;
			_users = users;
			_users.CollectionChanged += CollectionChangedEventHandler;

		}

		#endregion

		// Заполнение коллекции данными
		public void Initialize()
		{
			_users.Clear();

			int count = Utilities.GenerateInt(20, 31);
		
			for (int i = 0; i < count; i++)
				_users.Add(User.Generate(i + 1));

		}

		// Индексатор
		public User this[int index]
		{
			get
			{
				if (index < 0 || index >= _users.Count)
					throw new IndexOutOfRangeException("Выход за пределы диапазона");
				return _users[index];
			}
			set
			{
				if (index < 0 || index >= _users.Count)
					throw new IndexOutOfRangeException("Выход за пределы диапазона");
				_users[index] = value;
			}
		}

		// Вывод коллекции пользователей в табличном формате
		public void Show(string title) => Show(title, _users.ToList());
		public void Show(string title, List<User> users)
		{
			Console.Write($"\n{title}\n" + $"{Utilities.spaces}\"{Name}\"\n{User.Header()}");

			users.ForEach(x => Console.Write(x.ToTableRow()));

			Console.Write(User.Footer());
		}


		// Обработчик событий коллекции
		private static void CollectionChangedEventHandler(object sender, NotifyCollectionChangedEventArgs e)
		{
			switch (e.Action)
			{
				case NotifyCollectionChangedAction.Add:
					Console.WriteLine($"{Utilities.spaces}Операция добавления. Добавлен {(User)e.NewItems[0]}");
					break;
				case NotifyCollectionChangedAction.Remove:
					Console.WriteLine($"{Utilities.spaces}Операция удаления. Удален {(User)e.OldItems[0]}");
					break;
				case NotifyCollectionChangedAction.Replace:
					Console.WriteLine($"{Utilities.spaces}Операция замены: {(User)e.OldItems[0]} на {(User)e.NewItems[0]}");
					break;
				default:
					Console.WriteLine($"{Utilities.spaces}Операция не распознана");
					break;
			}
		}

		// Добавление пользователя в коллекцию
		public void Add(User user) => _users.Add(user);

		public void Remove(Predicate<User> pred)
		{
			foreach (var toRemove in _users.ToList().Where(us => pred(us)))
				_users.Remove(toRemove);
		}

		#region Итераторы
		// Определённые именованные

		public IEnumerable EnumSurname(string surname)
		{
			foreach (var user in _users.Where(us => us.Name.Contains(surname)))
				yield return user;
		}

		public IEnumerable EnumSign(string sign)
		{
			foreach (var user in _users.Where(us => us.ZodiacSign == sign))
				yield return user;
		}

		public IEnumerable EnumMonth(int month)
		{

			foreach (var user in _users.Where(us => us.Dob.Month == month))
				yield return user;
		}

		// Свелось в итоге к такой версии с предикатом
		public IEnumerable EnumeratorCustom(Func<User, bool> pred) => _users.Where(pred);

		#endregion


		// Сортировка 
		public void OrderBy<T>(Func<User, T> pred)
		{
			_users = new ObservableCollection<User>(_users.OrderBy(pred));
			_users.CollectionChanged += CollectionChangedEventHandler;
		}

	}
}
