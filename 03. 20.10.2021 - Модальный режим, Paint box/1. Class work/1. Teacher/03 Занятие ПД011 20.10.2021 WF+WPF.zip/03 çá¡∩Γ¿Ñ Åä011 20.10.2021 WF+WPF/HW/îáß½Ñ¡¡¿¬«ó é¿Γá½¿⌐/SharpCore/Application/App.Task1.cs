﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using HW18.Models;

namespace HW18
{
	internal partial class App
	{
		// Заполнение коллекции пользователей
		private void MainMenuItem1()
		{
			Utilities.ShowNavBar("Заполнение коллекции пользователей");

			_department.Initialize();
			_department.Show($"{Utilities.spaces}Данные сформированы: ");
		}

		// Вывод информации о пользователях в консоль
		private void MainMenuItem2()
		{
			Utilities.ShowNavBar("Вывод информации о пользователях в консоль");

			_department.Show($"{Utilities.spaces}Данные пользователей: ");
		}

		// Добавление трёх пользователей со знаком рыбы
		private void MainMenuItem3()
		{
			Utilities.ShowNavBar("Добавление трёх пользователей со знаком рыбы");

			for (int i = 0; i < 3; i++)
			{
				User us = User.Generate(_department[_department.UsersCounter -1].Id + 1);
				us.Dob = new DateTime(2021, 3, Utilities.GenerateInt(1, 21));
				_department.Add(us);
			}

			_department.Show($"{Utilities.spaces}В конец коллекции добавлены три пользователя со знаком рыбы: ");
		}

		// Удаление всех пользователей старше 60 лет
		private void MainMenuItem4()
		{
			Utilities.ShowNavBar("Удаление всех пользователей старше 60 лет");

			_department.Remove(us => us.Dob.GetAge() > 60);

			_department.Show($"{Utilities.spaces}Удалены все пользователи старше 60 лет ");
		}

		// Добавление строки \"-бе-бе\" к фамилии всех \"Овнов\"",
		private void MainMenuItem5()
		{
			Utilities.ShowNavBar("Добавление строки \"-бе-бе\" к фамилии всех \"Овнов\"");
			
			for (int i = 0; i < _department.UsersCounter; i++)
			{
				if(_department[i].ZodiacSign == "Овен")
					_department[i] = new User
					{
						Dob = _department[i].Dob, 
						Id = _department[i].Id,
						Name = _department[i].Name.Insert(_department[i].Name.IndexOf(' '), "-бе-бе")
					};
			}

			_department.Show($"{Utilities.spaces}Ко всем пользователям со знаком зодиака Овен, добавлено \"бе-бе\":");
		}


		//Вывести в список и консоль записи с заданной фамилией
		private void MainMenuItem6()
		{
			Utilities.ShowNavBar("Вывести в список и консоль записи с заданной фамилией");

			string surname = _department[Utilities.GenerateInt(0, _department.UsersCounter)].Name.Split()[0];

			List<User> found = new List<User>();

			//foreach (User user in _department.EnumSurname(surname))
			//	found.Add(user);

			foreach (User user in _department.EnumeratorCustom(x => x.Name.Contains(surname)))
				found.Add(user);

			_department.Show($"{Utilities.spaces}Пользователи с фамилией {surname}:\n\n{Utilities.spaces}", found);
		}

		//Вывести в список и консоль записи с заданным знаком Зодиака
		private void MainMenuItem7()
		{
			Utilities.ShowNavBar("Вывести в список и консоль записи с заданным знаком Зодиака");

			string[] signs =
			{
				"Козерог", "Водолей", "Рыбы", "Овен", "Телец", "Близнецы", "Рак", "Лев",
				"Дева", "Весы", "Скорпион", "Стрелец"
			};

			string sign = signs[Utilities.GenerateInt(0, signs.Length)];

			List<User> found = new List<User>();

			//foreach (User user in _department.EnumSign(sign))
			//	found.Add(user);

			foreach (User user in _department.EnumeratorCustom(x => x.ZodiacSign == sign))
				found.Add(user);

			_department.Show($"{Utilities.spaces}Пользователи со знаком зодиака {sign}:\n\n{Utilities.spaces}", found);

		}

		//Вывести в список и консоль записи с заданным месяцем рождения
		private void MainMenuItem8()
		{
			Utilities.ShowNavBar("Вывести в список и консоль записи с заданным месяцем рождения");

			Dictionary<int, string> monthes = new Dictionary<int, string>
			{
				{1, "Январь"},
				{2, "Февраль"},
				{3, "Март"},
				{4, "Апрель"},
				{5, "Май"},
				{6, "Июнь"},
				{7, "Июль"},
				{8, "Август"},
				{9, "Сентябрь"},
				{10, "Октябрь"},
				{11, "Ноябрь"},
				{12, "Декабрь"},
			};

			int month = Utilities.GenerateInt(1, 13);

			List<User> found = new List<User>();

			//foreach (User user in _department.EnumMonth(month))
			//	found.Add(user);

			foreach (User user in _department.EnumeratorCustom(x => x.Dob.Month == month))
				found.Add(user);

			_department.Show($"{Utilities.spaces}Пользователи с месяцем рождения {monthes[month]}:\n\n{Utilities.spaces}", found);
		}


		// Cортировка по дате рождения
		private void MainMenuItem9()
		{
			Utilities.ShowNavBar("Cортировка по дате рождения");

			_department.OrderBy(x => x.Dob);

			_department.Show($"{Utilities.spaces}Данные пользователей отсортированы по дате рождения: ");
		}

		// Cортировка по названиям знаков Зодиака
		private void MainMenuItem10()
		{
			Utilities.ShowNavBar("Cортировка по названиям знаков Зодиака");

			_department.OrderBy(x => x.ZodiacSign);

			_department.Show($"{Utilities.spaces}Данные пользователей отсортированы по знакам зодиака: ");
		}

		// Cортировка по фамилии, имени
		private void MainMenuItem11()
		{
			Utilities.ShowNavBar("Cортировка по фамилии, имени");

			_department.OrderBy(x => x.Name);

			_department.Show($"{Utilities.spaces}Данные пользователей отсортированы по фамилии, имени: ");
		}
	}
}
