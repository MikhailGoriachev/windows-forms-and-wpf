﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace H_W18C_.Models
{
    /// <summary>
    ///  Описать класс с именем User, содержащую следующие поля:
    /// •	числовой идентификатор - int;
    /// •	фамилия, имя - string;
    /// •	знак Зодиака - string;
    /// •	дата рождения - DateTime
    /// </summary>
    internal class User : IEnumerable
    {
        // числовой идентификатор
        private int _identifier;
        public int Identifier
        {
            get => _identifier;
            set => _identifier = value;
        }// Identifier

        // фамилия, имя
        private string _fullName;
        public string FullName
        {
            get => _fullName;
            set {
                if (string.IsNullOrWhiteSpace(value))
                    throw new Exception("User: Некорректное ФИО человека");
                _fullName = value;
            }
        }// FullName

        // знак Зодиака
        private string _signZodiac;
        public string SignZodiac
        {
            get => _signZodiac;
            set {
                if (string.IsNullOrWhiteSpace(value))
                    throw new Exception("User: Некорректный знак зодиака человека");
                _signZodiac = value;
            }
        }// SignZodiac

        // дата рождения
        //private DateTime _dateOfBirth;
        public DateTime DateOfBirth { get; set; }
        /*
        { 
            get => _dateOfBirth;
            set {
                if (value.Kind < 0 || value.Year > DateTime.Now.Year)
                    throw new ArgumentException("User: Некорректная дата рождения");

                _dateOfBirth = DateOfBirth;
            }
        }// DateOfBirth
        */

        // итератор для перебора свойств класса
        public IEnumerator GetEnumerator()
        {
            yield return $"Identifier   = {Identifier}";
            yield return $"FullName     = {FullName}";
            yield return $"SignZodiac   = {SignZodiac}";
            yield return $"DateOfBirth  = {DateOfBirth}";

        } // GetEnumerator

        // шапка таблицы, статическое свойство
        public static string Header()
        {
            return
                $" ┌─────────────────┬──────────────────────┬────────────────┬───────────────┐\n" +
                $" │  Идентификатор  │  ФИО пользователя    │  Знак зодиака  │ Дата рождения │\n" +
                $" ├─────────────────┼──────────────────────┼────────────────┼───────────────┤\n";
        } // Header

        // подвал таблицы, статическое свойство
        public static string Footer()
        {
            return
                $" └─────────────────┴──────────────────────┴────────────────┴───────────────┘\n";
        } // Footer

        public override string ToString() =>
          $" │ {Identifier, 15} │ {FullName,-20} │ {SignZodiac,-14} │ {DateOfBirth.ToString("dd.MM.yyyy") ,13} │";

    }// class User
}
