﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace H_W18C_.Models
{
    /// <summary>
    /// Создать класс Department со списком пользователей –
    /// коллекцией типа ObservableCollection<User>.
    /// </summary>
    internal class Department: IEnumerable
    {
        // коллекция типа ObservableCollection<User>
        ObservableCollection<User> _users;

        public int Length => _users.Count;

        public Department() => Inizialize();

        public Department(ObservableCollection<User> users) => _users = users;

        public void Inizialize()
        {
            _users = new ObservableCollection<User> {
                new User{Identifier = 437269, FullName = "Маричко Е.С.",     SignZodiac = "Рыбы",     DateOfBirth = new DateTime(1983, 2, 21) },
                new User{Identifier = 054343, FullName = "Острожска Р.С.",   SignZodiac = "Стрелец",  DateOfBirth = new DateTime(1987, 12, 21)},
                new User{Identifier = 468645, FullName = "Костин П.З.",      SignZodiac = "Скорпион", DateOfBirth = new DateTime(1990, 11, 8) },
                new User{Identifier = 756345, FullName = "Кондратьева В.П.", SignZodiac = "Дева",     DateOfBirth = new DateTime(1958, 9, 20) },
                new User{Identifier = 976532, FullName = "Сазонов Е.Д.",     SignZodiac = "Весы",     DateOfBirth = new DateTime(1984, 10, 3) },
                new User{Identifier = 856354, FullName = "Дзюба Е.С.",       SignZodiac = "Телец",    DateOfBirth = new DateTime(1982, 5, 10) },
                new User{Identifier = 743536, FullName = "Терентьев К.С.",   SignZodiac = "Овен",     DateOfBirth = new DateTime(1960, 4, 11) },
                new User{Identifier = 565694, FullName = "Кудрявцева Е.И.",  SignZodiac = "Водолей",  DateOfBirth = new DateTime(1983, 2, 5)  },
                new User{Identifier = 073437, FullName = "Поляков И.У.",     SignZodiac = "Козерог",  DateOfBirth = new DateTime(1987, 1, 9)  },
                new User{Identifier = 198336, FullName = "Гришин Ж.С.",      SignZodiac = "Скорпион", DateOfBirth = new DateTime(1993, 11, 16)},
                new User{Identifier = 656987, FullName = "Острожска Р.С..",  SignZodiac = "Рыбы",     DateOfBirth = new DateTime(1959, 3, 16) },
                new User{Identifier = 345675, FullName = "Ткаченко Е.Н.",    SignZodiac = "Лев",      DateOfBirth = new DateTime(2000, 7, 24) },
                new User{Identifier = 434568, FullName = "Коровяк Р.С.",     SignZodiac = "Близнецы", DateOfBirth = new DateTime(1988, 6, 10) },
                new User{Identifier = 734428, FullName = "Дзюба Е.С.",       SignZodiac = "Рак",      DateOfBirth = new DateTime(2001, 6, 24) },
                new User{Identifier = 896345, FullName = "Фадеева Е.Д.",     SignZodiac = "Лев",      DateOfBirth = new DateTime(1985, 7, 26) },
                new User{Identifier = 789676, FullName = "Кириленко Т.С.",   SignZodiac = "Весы",     DateOfBirth = new DateTime(2010, 10, 8) },
                new User{Identifier = 345780, FullName = "Шевченко М.С.",    SignZodiac = "Козерог",  DateOfBirth = new DateTime(1984, 1, 8)  },
                new User{Identifier = 234781, FullName = "Поляков И.У.",     SignZodiac = "Стрелец",  DateOfBirth = new DateTime(1984, 5, 11) },
                new User{Identifier = 974638, FullName = "Тарасова Л.К.",    SignZodiac = "Рыбы",     DateOfBirth = new DateTime(2000, 3, 20) },
                new User{Identifier = 745348, FullName = "Гуляев Е.В.",      SignZodiac = "Овен",     DateOfBirth = new DateTime(1991, 4, 15) }

            };
        }
        public ICollection<User> GetAllUsers => _users; // GetAllBooks

        public IEnumerator GetEnumerator()
        {
            for (int i = 0; i < _users.Count; i++) {
                // реализация итератора 
                yield return _users[i];
            } // for i
        } // GetEnumerator

        // добавление пользователей
        public void CreateThreeUsers(User item) => _users.Add(item);

        // расчёт возраста по дате рождения
        public DateTime GetAge(DateTime age)
        {
            return new DateTime((DateTime.Now - age).Ticks);
        }

        // удаление всех пользователей старше 60 лет
        public void DeleteDepartment()
        {
            //_users.Remove();
        }

        // заменить все записи знака Овен этими же записями, но сo строкой <<-бе-бе>>
        public void ReplaceSignZodiac(string str)
        {
            for (int i = 0; i < _users.Count; i++) {
                if (_users[i].SignZodiac == str)
                    _users[i].SignZodiac = "Овен бе-бе";
            }// for i
        }// ReplaceSignZodiac

        // именованный итератор, возвращает пользователей c заданной фамилией
        public IEnumerable UserFullName(string fullName)
        {
            foreach (var user in _users)
            {
                if (fullName == user.FullName)
                    yield return user;
            } // foreach
        } // UserFullName

        // именованный итератор, возвращает пользователей c заданной знаком зодиака
        public IEnumerable UserSignZodiac(string zodiac)
        {
            foreach (var user in _users)
            {
                if (zodiac == user.SignZodiac)
                    yield return user;
            } // foreach
        } // UserSignZodiac

        // именованный итератор, возвращает пользователей c заданной месяцем рождения
        public IEnumerable UserMonthOfBirth(DateTime month)
        {
            foreach (var user in _users)
            {
                if (month.Month == user.DateOfBirth.Month)
                    yield return user;
            } // foreach
        } // UserMonthOfBirth

        // сортировка пользователей по названиям дате рождения
        public void SortByDateOfBirth()
        {
            _users = new ObservableCollection<User>(_users.OrderBy(u => u.DateOfBirth));
        }

        // сортировка пользователей по названиям знака Зодиака
        public void SortBySignZodiac()
        {
            _users = new ObservableCollection<User>(_users.OrderBy(u => u.SignZodiac));
        }

        // сортировка пользователей по ФИО
        public void SortByFullName()
        {
           _users = new ObservableCollection<User>( _users.OrderBy(u  => u.FullName));
        }
    }// class Department 
}
