﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace H_W18C_.Models
{
    /// <summary>
    /// Задача 1. Описать класс с именем User, содержащую следующие поля:
    /// •	числовой идентификатор - int;
    /// •	фамилия, имя - string;
    /// •	знак Зодиака - string;
    /// •	дата рождения - DateTime
    /// Создать класс Department со списком пользователей –
    /// коллекцией типа ObservableCollection<User>.
    /// Проинициировать ее не менее чем 20 записями о пользователях,
    /// использовать все знаки Зодиака, заполнение коллекции также выполняйте из пункта меню.
    /// Реализовать CRUD-операции, (операции Read и Update – реализовать индексатором),
    /// обрабатывать события добавления, удаления и замещения(replace) данных в коллекции.
    /// Обрабатывать события при выполнении следующих запросов, включенных в меню приложения:
    /// •	добавление трех пользователей со знаком Рыбы(create)
    /// •	удаление всех пользователей старше 60 лет(delete)
    /// •	заменить все записи знака Овен этими же записями,
    ///   но с добавлением строки "-бе-бе" к фамилии(update - replace)
    /// Таже в пунктах меню задать выполнение следующих действий:
    /// •	при помощи именованного итератора вывести в список и
    ///   консоль записи с заданной фамилией
    /// •	при помощи именованного итератора вывести в список и
    ///   консоль записи с заданным знаком Зодиака
    /// •	при помощи именованного итератора вывести в список и
    ///   консоль записи с заданным месяцем рождения
    /// •	сортировка по дате рождения
    /// •	сортировка по названиям знаков Зодиака
    /// •	сортировка по фамилии, имени
    /// </summary>
    class Program
    {
        static void Main(string[] args)
        {

            Console.Title = "Домашнее задание № 18.";
            try
            {
                // меню приложения
                MenuItem[] menu = new[] {
                new MenuItem { HotKey = ConsoleKey.Q, Text = "Начальное заполнение списка пользователей." },
                new MenuItem { HotKey = ConsoleKey.W, Text = "Добавление трех пользователей со знаком Рыбы." },
                new MenuItem { HotKey = ConsoleKey.E, Text = "Удаление всех пользователей старше 60 лет." },
                new MenuItem { HotKey = ConsoleKey.R, Text = "Заменить все записи знака Овен этими же записями, но сo строкой <<-бе-бе>>" },
                new MenuItem { HotKey = ConsoleKey.T, Text = "При помощи именованного итератора вывести записи с заданной фамилией." },
                new MenuItem { HotKey = ConsoleKey.Y, Text = "При помощи именованного итератора вывести записи с заданным знаком Зодиака." },
                new MenuItem { HotKey = ConsoleKey.U, Text = "При помощи именованного итератора вывести записи с заданным месяцем рождения." },
                new MenuItem { HotKey = ConsoleKey.I, Text = "Упорядочить пользователей по дате рождения." },
                new MenuItem { HotKey = ConsoleKey.O, Text = "Упорядочить пользователей по названиям знаков Зодиака." },
                new MenuItem { HotKey = ConsoleKey.P, Text = "Упорядочить пользователей по фамилии, имени." },
                new MenuItem { HotKey = ConsoleKey.Escape, Text = "Выход" },
            };

                // Создание экземпляра класса приложения
                App app = new App();

                // главный цикл приложения
                while (true)
                {
                    // настройка цветового оформления
                    Console.ForegroundColor = ConsoleColor.White;
                    Console.BackgroundColor = ConsoleColor.DarkCyan;
                    Console.Clear();
                    Console.CursorVisible = false;

                    Utils.ShowMenu(25, 5, "Меню приложения : ", menu);

                    // получить код нажатой клавиши, не отображать символ клавиши
                    ConsoleKey key = Console.ReadKey(true).Key;
                    Console.Clear();

                    switch (key)
                    {
                        // Начальное заполнение списка пользователей
                        case ConsoleKey.Q:
                            app.InizializeCollection();
                            break;

                        // Добавление трех пользователей со знаком Рыбы
                        case ConsoleKey.W:
                            app.AppendThreeSignFish();
                            break;

                        // Удаление всех пользователей старше 60 лет
                        case ConsoleKey.E:
                            app.DeleteDepartment();
                            break;

                        // Заменить все записи знака Овен этими же записями, но сo строкой <<-бе-бе>>
                        case ConsoleKey.R:
                            app.ReplaceDepartment();
                            break;

                        // При помощи именованного итератора вывести записи с заданной фамилией
                        case ConsoleKey.T:
                             app.ShowDepartmentFullName();
                            break;

                        // При помощи именованного итератора вывести записи с заданным знаком Зодиака
                        case ConsoleKey.Y:
                            app.ShowDepartmentZodiac();
                            break;

                        // При помощи именованного итератора вывести записи с заданным месяцем рождения
                        case ConsoleKey.U:
                             app.ShowDepartmentMonthOfBirth();
                            break;

                        // Упорядочить пользователей по дате рождения
                        case ConsoleKey.I:
                             app.SortUsersByDateOfBirth();
                            break;

                        // Упорядочить пользователей по названиям знаков Зодиака
                        case ConsoleKey.O:
                             app.SortUsersByZodiack();
                            break;

                        // Упорядочить пользователей по фамилии, имени
                        case ConsoleKey.P:
                             app.SortUsersByFullName();
                            break;

                        // Выход клавиша Esc
                        case ConsoleKey.Escape:
                            Console.ResetColor();   // сброс цветового сочетания к исходному
                            Console.Clear();
                            Utils.WriteXY(0, Console.WindowHeight - 1, "Нажмите любую клавишу...", ConsoleColor.White);
                            Console.CursorVisible = true;
                            return;
                        default:
                            continue;
                    } // switch

                    // Ожидать нажатия любой клавиши по окончании работы пункта меню
                    Console.CursorVisible = true;
                    Utils.WriteXY(0, Console.WindowHeight - 1, "Нажмите любую клавишу...", ConsoleColor.White);
                    Console.ReadKey(true);
                } // while

            }
            catch (Exception ex)
            {
                Console.ForegroundColor = ConsoleColor.Magenta;
                Console.WriteLine($"\n{ex.Message}");
                //throw;
            }
            finally
            {
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine("\nКод финализации");
                Console.ForegroundColor = ConsoleColor.Gray;
            }// try- catch- finally
            Console.ForegroundColor = ConsoleColor.White;
        }// Main
    }// class Program
}
