﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace H_W18C_.Models
{
    internal class App
    {
        Department _departments;

        // конструктор по умолчанию
        public App() : this(new Department()) { }

        // конструктор с внедрением зависимостей
        public App(Department departments)
        {
            _departments = departments;
        } // App

        // Начальное заполнение списка пользователей
        public void InizializeCollection()
        {
            Utils.ShowNavBarTask("   Начальное формирование списка пользователей");

            _departments.Inizialize();

            Show("\t\t\tДанные сформированы:", _departments.GetAllUsers);
        }// InizializeCollection

        // Добавление трех пользователей со знаком Рыбы
        public void AppendThreeSignFish()
        {
            Utils.ShowNavBarTask("   Добавление трех пользователей со знаком Рыбы");

            _departments.CreateThreeUsers(new User { Identifier = 534588, FullName = "Ирза К.В.", SignZodiac = "Рыбы", DateOfBirth = new DateTime(1962, 3, 17) });
            _departments.CreateThreeUsers(new User { Identifier = 755219, FullName = "Митин О.С..", SignZodiac = "Рыбы", DateOfBirth = new DateTime(1954, 3, 15) });
            _departments.CreateThreeUsers(new User { Identifier = 864321, FullName = "Юрко В.К.", SignZodiac = "Рыбы", DateOfBirth = new DateTime(1950, 3, 16) });

            Show("\t\tПользователи со знаком Рыбы добавлены:", _departments.GetAllUsers);
        }// AppendThreeSignFish

        // Удаление всех пользователей старше 60 лет
        public void DeleteDepartment()
        {
            Utils.ShowNavBarTask("   Удаление всех пользователей старше 60 лет");

            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("\n\n\t\t\t Метод в разработке....\n");
            Console.ForegroundColor = ConsoleColor.Gray;

           //Show("\n\t\t\tПользователи старше 60 лет удалены:\n", _departments.GetAllUsers);
        }// DeleteDepartment

        // Заменить все записи знака Овен этими же записями, но сo строкой <<-бе-бе>>
        public void ReplaceDepartment()
        {
            Utils.ShowNavBarTask("   Заменить все записи знака Овен этими же записями, но сo строкой <<-бе-бе>>");

            string str = "Овен";
            _departments.ReplaceSignZodiac(str);
            Show("\t\tПользователи с знаком зодиака Овен изменены:", _departments.GetAllUsers);
        }// ReplaceDepartment

        // При помощи именованного итератора вывести записи с заданной фамилией
        public void ShowDepartmentFullName()
        {
            Utils.ShowNavBarTask("   При помощи именованного итератора вывести записи с заданной фамилией");

            string str = "Дзюба Е.С.";
            Console.WriteLine($"\n При проходе по коллекции возвращаем только пользователей с" +
                  $" ФИО: {str}");
            Console.Write($"{ User.Header()}");
            foreach (var user in _departments.UserFullName(str))
            {
                Console.WriteLine($"{user}");
            } // foreach
            Console.WriteLine($"{ User.Footer()}");
        }// ShowDepartmentFullName

        // При помощи именованного итератора вывести записи с заданным знаком Зодиака
        public void ShowDepartmentZodiac()
        {
            Utils.ShowNavBarTask("   При помощи именованного итератора вывести записи с заданным знаком Зодиака");

            string str = "Стрелец";
            Console.WriteLine($"\n При проходе по коллекции возвращаем только пользователей сo" +
                  $" знаком зодиака: {str}");
            Console.Write($"{ User.Header()}");
            foreach (var user in _departments.UserSignZodiac(str))
            {
                Console.WriteLine($"{user}");
            } // foreach
            Console.WriteLine($"{ User.Footer()}");
        }// ShowDepartmentZodiac

        // При помощи именованного итератора вывести записи с заданным месяцем рождения
        public void ShowDepartmentMonthOfBirth()
        {
            Utils.ShowNavBarTask("   При помощи именованного итератора вывести записи с заданным месяцем рождени");

            DateTime  month = new DateTime(1982, 5, 10);
            Console.WriteLine($"\n При проходе по коллекции возвращаем только" +
                $" пользователей рождённых в {month.Month} месяце");
            Console.Write($"{ User.Header()}");
            foreach (var user in _departments.UserMonthOfBirth(month))
            {
                Console.WriteLine($"{user}");
            } // foreach
            Console.WriteLine($"{ User.Footer()}");
        }// ShowDepartmentMonthOfBirth

        // Упорядочить пользователей по дате рождения
        public void SortUsersByDateOfBirth()
        {
            Utils.ShowNavBarTask("   Упорядочить пользователей по дате рождения");

            _departments.SortByDateOfBirth();
            Show("\t\t\tПользователи упорядочены по дате рождени:", _departments.GetAllUsers);
        }// SortUsersByDateOfBirth 

        // Упорядочить пользователей по названиям знаков Зодиака
        public void SortUsersByZodiack()
        {
            Utils.ShowNavBarTask("   Упорядочить пользователей по названиям знаков Зодиака");

            _departments.SortBySignZodiac();
            Show("\t\t\tПользователи упорядочены по названиям знаков Зодиака:", _departments.GetAllUsers);
        }// SortUsersByZodiack

        // Упорядочить пользователей по фамилии, имени
        public void SortUsersByFullName()
        {
            Utils.ShowNavBarTask("   Упорядочить пользователей по фамилии, имени");

            _departments.SortByFullName();
            Show("\t\t\tПользователи упорядочены по ФИО:", _departments.GetAllUsers);
        }// SortUsersByFullName


        // вывод коллекции 
        static void Show(string title, ICollection<User> userList)
        {
            // собрать строку и вывести в консоль
            StringBuilder sb = new StringBuilder($"\n{title}\n{User.Header()}");

            foreach (var item in userList)
            {
                sb.Append($"{item}\n");
            } // foreach

            Console.WriteLine(sb.Append($"{User.Footer()}\n").ToString());
        } // Show
    }// class App

}
