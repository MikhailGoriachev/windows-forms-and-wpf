﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CS_Collections_Observable.Model;
using CS_Collections_Observable.Utilities;

namespace CS_Collections_Observable.Controllers
{
    public class Departement
    {
       
    }
}
