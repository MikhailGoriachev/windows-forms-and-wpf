﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CS_Collections_Observable.Utilities;

namespace CS_Collections_Observable.Model
{
   public class User
    {
        //Статическое свойство идентификатора, иначе не сможем контролировать уникальность
        public static int Id
        {
            get
            { return Id; }
            set
            {
                if (value <= 0)
                    Id = ++Id;
            }
        }

        private string _Name;

        //Свойсвто имени
        public string Name
        {
            get
            { 
                //Если имя было задано некорректно
                if (_Name.Length < 1)
                    return "–––";
                return _Name;

            }
            set
            {
                //Валидация данных
                if (value.Length < 1)
                    _Name = "–––";
                else
                    _Name = value;
            }

        }
        
        private string _Zodiac;

        //Свойсвто имени
        public string Zodiac
        {
            get
            { 
                //Если имя было задано некорректно
                if (_Zodiac.Length < 1)
                    return "–––";
                return _Zodiac;

            }
            set
            {
                //Валидация данных
                if (value.Length < 1)
                    _Zodiac = "–––";
                else
                    _Zodiac = value;
            }

        }

        public DateTimeCust BirthDate
        {
            get;
            set;
        }


        //C_TOR по умолчанию 
        User():this("Карпов А.Б","Рыба",new DateTimeCust(24,03,1994))
        { }

        User(string name,string zodiac,DateTimeCust birthDate)
        {
            Id++;
            Name = name;
            Zodiac = zodiac;
            BirthDate = birthDate;
        }

        //Фабричный метод создания объекта
        static User GenerateUser()
        {
            string[] Names = 
            {
                "Карпов А.Б",
                "Васильев А.Н.",    
                "Швайко О.А.",    
                "Дёмина Д.П.",  
                "Лысюк А.В.",  
                "Якубовская Ю.В.",  
                "Пачкория Г.В.",  
                "Аникеев В.О.", 
                "Мироненко Н.Я.",
                "Решетникова Н.А.", 
                "Свиридова Т.Л.", 
                "Репеко Д.А.",  
                "Лысенко Б.П.",
            };

            return new User(Names[Utils.Random.Next(0, 14)], "---", new DateTimeCust(24, 03, 1994));
        }
        }
    }
}
