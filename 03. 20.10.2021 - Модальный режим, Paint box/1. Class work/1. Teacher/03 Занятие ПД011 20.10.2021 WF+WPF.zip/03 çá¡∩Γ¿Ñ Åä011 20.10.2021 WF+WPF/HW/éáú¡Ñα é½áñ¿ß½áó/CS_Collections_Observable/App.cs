﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualBasic;
using CS_Collections_Observable.Utilities;
namespace CS_Collections_Observable
{
    partial class App
    {
        //Минимальное количество записей в коллекции
        static public int _MinAmount = 20;
        
        public void Menu()
        {
            /* Описать класс с именем User, содержащую следующие поля:
           •	числовой идентификатор -int;
           •	фамилия, имя - string;
           •	знак Зодиака -string;
           •	дата рождения -DateTime

           Создать класс Department со списком пользователей – коллекцией типа ObservableCollection<User>.
           Проинициировать ее не менее чем 20 записями о пользователях, использовать все знаки Зодиака, 
            заполнение коллекции также выполняйте из пункта меню.
           Реализовать CRUD-операции, (операции Read и Update – реализовать индексатором), 
            обрабатывать события добавления, удаления и замещения(replace) данных в коллекции.

           Обрабатывать события при выполнении следующих запросов, включенных в меню приложения:
           •	добавление трех пользователей со знаком Рыбы(create)
           •	удаление всех пользователей старше 60 лет(delete)
           •	заменить все записи знака Овен этими же записями, но с добавлением строки "-бе-бе" к фамилии(update -replace)

           Таже в пунктах меню задать выполнение следующих действий:
           •	при помощи именованного итератора вывести в список и консоль записи с заданной фамилией
           •	при помощи именованного итератора вывести в список и консоль записи с заданным знаком Зодиака
           •	при помощи именованного итератора вывести в список и консоль записи с заданным месяцем рождения
           •	сортировка по дате рождения
           •	сортировка по названиям знаков Зодиака
           •	сортировка по фамилии, имени
           */

            #region Главное меню
            /*Console.ForegroundColor = Utils._SymbolsColor;
            Console.BackgroundColor = Utils._MainColor;*/
            Palette.MainColor.EstablishColor();
            string MainTitle = "Домашнее задание на 20.10";

            //Массивы пунктов меню 
            MenuItem[] FirstTaskMenu = new[] {
                new MenuItem {key = " Q ",Text = " - Инициализировать коллекцию"},
                new MenuItem {key = " W ",Text = " - Добавить 3-х пользователей со знаком рыбы"},
                new MenuItem {key = " E ",Text = " - Заменить все записи знака Овен"},
                new MenuItem {key = " R ",Text = " - Дополнительные действия с коллекцией"},
                new MenuItem {key = "ESC",Text = " - Выход"}
            };

            try
            {

                while (true)
                {
                    Console.Clear();
                    Utils.ShowBarMessage(MainTitle);
                    Console.CursorVisible = false;
                    Utils.ShowMenu(3, 3, "Выберете действие", FirstTaskMenu);

                    //Если задание сделано не до конца
                    /*
                    Console.ForegroundColor = Utils.colors.W;
                    Console.BackgroundColor = Utils.colors.R;
                    Console.SetCursorPosition(3, 12);
                    Console.Write("Ps.Задание в разработке. Методы не реализованы!");
                    Palette.MainColor.EstablishColor();*/
                    ConsoleKey key = Console.ReadKey().Key;

                    switch (key)
                    {
                        case ConsoleKey.Q:
                            {
                                Console.Clear();
                                Utils.ShowFrameMessage("Вывод и инициализация в разработке", "INFO", 2, 3);
                                Console.ReadKey();
                                break;
                            }
                        case ConsoleKey.W:
                            {
                                Console.Clear();
                                Utils.ShowFrameMessage("Добавление пользователей в коллекцию в разработке", "INFO", 2, 3);
                                Console.ReadKey();
                                break;
                            }
                        case ConsoleKey.E:
                            {
                                Console.Clear();
                                Utils.ShowFrameMessage("Обновление всех записей знако", "INFO", 2, 3);
                                Console.ReadKey();
                                break;
                            }
                        case ConsoleKey.R:
                            {
                                Console.Clear();
                                AdditionalActs();
                                Console.ReadKey();
                                break;
                            }

                        case ConsoleKey.Escape:
                            {
                                Console.Clear();
                                Console.ReadKey();
                                return;
                            }
                        default:
                            throw new Exception($"Клавиша {key} не поддерживается");
                    }//Switch

                }//While

            }//Try
             //Catсh блок
             //Обрабатываем общее исключение
            catch (Exception ex)
            {
                Console.Clear();
                Utils.ShowFrameMessage(ex.Message, "Exception", 3, 3, 2, ConsoleColor.White, ConsoleColor.Red);
                Console.ReadKey();
                //Console.Write($"{ ex.Message}\n {ex.StackTrace}");
                Menu();
            }//catch
            #endregion
        } //Menu()

        //Подменю
        void AdditionalActs()
        {
            //Массивы пунктов меню 
            MenuItem[] FirstTaskMenu = new[] {
                new MenuItem {key = " Q ",Text = " - Вывести список пользователей с заданной фамилией"},
                new MenuItem {key = " W ",Text = " - Вывести список пользователей с заданным знаком зодиака"},
                new MenuItem {key = " E ",Text = " - Вывести список пользователей с заданными днями рождений"},
                new MenuItem {key = " R ",Text = " - Отсортировать пользователей по дате рождения "},
                new MenuItem {key = " T ",Text = " - Отсортировать пользователей по знакам Зодиака"},
                new MenuItem {key = " Y ",Text = " - Отсортировать пользователей по Фамиии"},
                new MenuItem {key = "ESC",Text = " - Выход"}
            };

            try
            {

                while (true)
                {
                    Console.Clear();
                    Utils.ShowBarMessage("Дополнительная работа с коллекцией");
                    Console.CursorVisible = false;
                    Utils.ShowMenu(3, 3, "Что сделать с коллекцией", FirstTaskMenu);

                    //Если задание сделано не до конца
                    /*
                    Console.ForegroundColor = Utils.colors.W;
                    Console.BackgroundColor = Utils.colors.R;
                    Console.SetCursorPosition(3, 12);
                    Console.Write("Ps.Задание в разработке. Методы не реализованы!");
                    Palette.MainColor.EstablishColor();*/
                    ConsoleKey key = Console.ReadKey().Key;

                    switch (key)
                    {
                        case ConsoleKey.Q:
                            {
                                Console.Clear();
                                Utils.ShowFrameMessage("Вывод списка пользователей с заданной фамилией в разработке", "INFO", 2, 3);
                                Console.ReadKey();      
                                break;                  
                            }                           
                        case ConsoleKey.W:              
                            {                           
                                Console.Clear();
                                Utils.ShowFrameMessage("Вывод списка пользователей с заданным знаком зодиака в разработке", "INFO", 2, 3);
                                Console.ReadKey();      
                                break;                  
                            }                           
                        case ConsoleKey.E:              
                            {
                                Console.Clear();
                                Utils.ShowFrameMessage("Вывод списка пользователей с заданными днями рождений в разработке", "INFO", 2, 3);
                                Console.ReadKey();      
                                break;                  
                            }                                      
                        case ConsoleKey.R:              
                            {
                                Console.Clear();
                                Utils.ShowFrameMessage("Сортировка пользователей по дате рождения в разработке", "INFO", 2, 3);
                                Console.ReadKey();      
                                break;                  
                            }                                      
                        case ConsoleKey.T:              
                            {
                                Console.Clear();
                                Utils.ShowFrameMessage("Сортировка пользователей по знакам Зодиака в разработке", "INFO", 2, 3);
                                Console.ReadKey();      
                                break;                  
                            }                           
                        case ConsoleKey.Y:
                            {
                                Console.Clear();
                                Utils.ShowFrameMessage("Сортировка пользователей по Фамиии в разработке", "INFO", 2, 3);
                                Console.ReadKey();
                                break;
                            }

                        case ConsoleKey.Escape:
                            {
                                Console.Clear();
                                return;
                            }
                        default:
                            throw new Exception($"Клавиша {key} не поддерживается");
                    }//Switch

                }//While

            }//Try
             //Catсh блок
             //Обрабатываем общее исключение
            catch (Exception ex)
            {
                Console.Clear();
                Utils.ShowFrameMessage(ex.Message, "Exception", 3, 3, 2, ConsoleColor.White, ConsoleColor.Red);
                Console.ReadKey();
                //Console.Write($"{ ex.Message}\n {ex.StackTrace}");
                Menu();
            }//catch
        }

    } //App


}//Name space
