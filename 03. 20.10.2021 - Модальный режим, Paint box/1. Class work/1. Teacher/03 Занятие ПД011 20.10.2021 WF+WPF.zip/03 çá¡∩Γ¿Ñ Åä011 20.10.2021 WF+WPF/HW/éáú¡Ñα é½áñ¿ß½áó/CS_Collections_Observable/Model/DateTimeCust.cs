﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CS_Collections_Observable.Utilities;

namespace CS_Collections_Observable.Model
{
    public class DateTimeCust 
    {
        //Словарь кол-ва дней в каждом месяце
        private Dictionary<int, int> MonthDays = new Dictionary<int, int>()
        {
            [1] = 31,
            [3] = 31,
            [4] = 30,
            [5] = 31,
            [6] = 30,
            [7] = 31,
            [8] = 31,
            [9] = 30,
            [10] = 31,
            [11] = 30,
            [12] = 31,
        };

        //Свойство дня
        public int Day
        {
            get => Day;
            set
            {
                //Если текущий месяц не февраль
                if (Month != 2)
                {
                    int days = 0;
                    MonthDays.TryGetValue(Month, out days);

                    if (value > days || value < 1)
                        throw new Exception($"Некорректное занчение дня \"{value}\"");
                    Day = value;
                }
                //Если текущий месяц февраль
                else if (Month == 2)
                {
                    if (IsLeapYear(Year))
                        //Если год рождения - високосный, проверяем значение на корректность. 
                        //В противном случае добавляем максимальное значение месяца
                        Day = value < 30 ? value : 29;
                    else
                        //Если день некорректен - исключение бросать не буду,а переведу на максимальное значение 
                        //кол-ва дней в феврале не в високосный год. Осознаю, что редактировать входящие 
                        //данные нельзя, но в данной реализации этим можножно пренебречь
                        Day = value < 29 ? value : 28;
                }
            }
        }

        //Свойство месяца
        public int Month
        {
            get => Month;
            set
            {
                if (value < 1 || value > 12)
                    throw new Exception($"Значние месяца задано неверно \"{value}\"");
                Month = value;
            }
        }

        //Свойство года
        public int Year
        {
            get => Year;
            set
            {
                int Now = DateTime.Now.Year;
                if (value > Now)
                    throw new Exception($"Неверный год даты рождения {value} !");
                //124 - рекордный возраст +2%
                if (value > value - Now)
                    throw new Exception($"Неверный год даты рождения {value} !");

                Year = value;
            }
        }

        //C_TOR 
       public DateTimeCust() : this(1, 1, 1989)
        { }
        //C_TOR с параметрами
        public DateTimeCust(int day, int month, int year)
        {
            Year = year;
            Month = month;
            Day = day;
        }

        //Переопределение ToString
       public override string ToString ()
        {
            return $"{Day,2}.{Month,2}.{Year,4}";
        } 
        //Проверка года на високосность
        public static bool IsLeapYear(int year)
            //Возращаем значение через тернарник
        => (year % 400 == 0 || year % 4 == 0) && year % 100 > 0 ? true : false;

       

        #region Перегрузки операций
        //Перегрузка оператора <>
        public static bool operator <(DateTimeCust Dt1, DateTimeCust Dt2)
        => (Dt1.Day < Dt2.Day) && (Dt1.Month < Dt2.Month) && (Dt1.Year < Dt2.Year);
        
        public static bool operator >(DateTimeCust Dt1, DateTimeCust Dt2)
        => (Dt1.Day > Dt2.Day) && (Dt1.Month >Dt2.Month) && (Dt1.Year > Dt2.Year);
        
        //Перегрузка оператора <=>=
        public static bool operator >=(DateTimeCust Dt1, DateTimeCust Dt2)
        => (Dt1.Day >= Dt2.Day) && (Dt1.Month >= Dt2.Month) && (Dt1.Year >= Dt2.Year);
        
        public static bool operator <=(DateTimeCust Dt1, DateTimeCust Dt2)
        => (Dt1.Day <= Dt2.Day) && (Dt1.Month <= Dt2.Month) && (Dt1.Year <= Dt2.Year);

        //Перегрузка != ==
        public static bool operator !=(DateTimeCust Dt1, DateTimeCust Dt2)
        => (Dt1.Day != Dt2.Day) && (Dt1.Month != Dt2.Month) && (Dt1.Year != Dt2.Year);
        public static bool operator ==(DateTimeCust Dt1, DateTimeCust Dt2)
        => (Dt1.Day == Dt2.Day) && (Dt1.Month == Dt2.Month) && (Dt1.Year == Dt2.Year);
        #endregion
    }//DateTime
}
