﻿using System;

namespace CS_Collections_Observable.Utilities
{
    // вспомогательные методы и объекты - статический класс, т.е. класс,
    // содержащий только статические члены и методы
    public static class Utils
    {
        //Базовые цвета консоли 
        public static  ConsoleColor _MainColor = ConsoleColor.Cyan,    //Общий цвет консоли
                                   _SymbolsColor = ConsoleColor.Black,//Общий цвет символов
                                   Highlightance = ConsoleColor.White;//Цвет выделения чего-либо

        //Кортех хранящий основные цвета для тернарника
        public static(ConsoleColor R, ConsoleColor Blu, ConsoleColor Y, ConsoleColor G, ConsoleColor W, ConsoleColor C, ConsoleColor Blk) colors = (ConsoleColor.Red, ConsoleColor.Blue, ConsoleColor.Yellow, ConsoleColor.Green, ConsoleColor.White, ConsoleColor.Cyan, ConsoleColor.Black);

        // объект для получения случайных чисел
        public static Random Random = new Random();
        
        // формирование случайных вещественных чисел в диапазоне от lo до hi
        public static double GetRandom(double lo, double hi)
            => lo + (hi - lo)*Random.NextDouble();

        //Вывод плашки текста 
        static public void ShowBarMessage(string Message, ConsoleColor Back = ConsoleColor.White)
        {
            Console.Clear();
            Console.SetCursorPosition(0, 0);
            string Space = " ".PadRight(Console.WindowWidth);

            Console.BackgroundColor = Back;
            //Вычисление необходимого цвета текста в зависимости от цвета фона
            Console.ForegroundColor = Back == ConsoleColor.White ? ConsoleColor.Black : (Back == ConsoleColor.Black || Back == ConsoleColor.Gray || Back == ConsoleColor.Red) ? ConsoleColor.White : ConsoleColor.White;
            Console.WriteLine(Space);

            //Если длина сообщения больше ширины окна и нет перевода строки
            if (Message.Length > Console.WindowWidth && Message.IndexOf('\n') < 0)
            {
                Console.SetCursorPosition(0, 0);
                //Сокращаем строку до текущего размера окна. Сохраняем таким образом примерный смысл
                Message.Remove(Console.WindowWidth - 3);
                //В конец строки троеточие, для понимания, что строка продолжается
                Message += "...";
                Console.WriteLine(Message);
                return;
            }

            Console.SetCursorPosition(1, 0);
            Console.WriteLine(Message);
            //Возвращаем цвета
            Console.BackgroundColor = _MainColor;
            Console.ForegroundColor = _SymbolsColor;
        }


        //Вывод строки по позиции курсора
        static public void ShowByCoords(string Message, int X, int Y, ConsoleColor CharsColor = ConsoleColor.Black)
        {
            if (Message.Length > Console.WindowWidth || X > Console.WindowWidth)
            {
                Console.WriteLine($"Некорректные данные по длинне строки и оси X, ширна окна {Console.WindowWidth} символов");
            }

            ConsoleColor OldForeground = Console.ForegroundColor;
            Console.ForegroundColor = CharsColor;
            //Вывод строки
            Console.SetCursorPosition(X, Y);
            Console.Write(Message);

            Console.ForegroundColor = OldForeground;
        }
        
        //Вывод строки по позиции курсора. Пергрузка - изменение цвета фона
        static public void ShowByCoords(string Message, ConsoleColor BackColor, int X, int Y)
        {
            if (Message.Length > Console.WindowWidth || X > Console.WindowWidth)
            {
                Console.WriteLine($"Некорректные данные по длинне строки и оси X, ширна окна {Console.WindowWidth} символов");
            }

            //Выбор цвета символов в зависимости от цвета фона
            Console.ForegroundColor = BackColor==ConsoleColor.White|| BackColor == ConsoleColor.Gray?ConsoleColor.Black:ConsoleColor.White;
            //Вывод строки
            Console.SetCursorPosition(X, Y);
            Console.BackgroundColor = BackColor;
            Console.Write(Message);
            Console.BackgroundColor = _MainColor;

            Console.ForegroundColor = _SymbolsColor;
        }
        
        //Вывод строки по позиции курсора. Пергрузка - задание цвета через объект Color
        static public void ShowByCoords(Color OutColor,string Message, int X, int Y)
        {
            if (Message.Length > Console.WindowWidth || X > Console.WindowWidth)
            {
                Console.WriteLine($"Некорректные данные по длинне строки и оси X, ширна окна {Console.WindowWidth} символов");
            }

            OutColor.EstablishColor();
            //Вывод строки
            Console.SetCursorPosition(X, Y);
            Console.Write(Message);

            Palette.MainColor.EstablishColor();
        }


        // Вывод меню приложения
        public static void ShowMenu(int x, int y, string title, MenuItem[] menu) {
            ShowByCoords(title,ConsoleColor.White,x, y);
            int StartY = y+1;

            foreach (var menuItem in menu) 
            
            {
                StartY++;
                Console.BackgroundColor = Highlightance;
                //ShowByCoords(menuItem.key, 3, StartY, ConsoleColor.Red);

                //Тестовое использовние класса Color
                Color color = new Color { Foreground = ConsoleColor.Red, BackGround = ConsoleColor.White };
                ShowByCoords(color, menuItem.key, 3, StartY);

                //Console.BackgroundColor = _MainColor;
        
                ShowByCoords(menuItem.Text, 3+menuItem.key.Length, StartY++,Palette.MainFontColor);
            } // foreach menuItem
        } // ShowMenu 

        //Параметры: Строка сообщения,   положение на экране по оси Y,       Сообщение в квадратных скобках,       Отступы во вертикали,      Отсутпы слева,   Цвет Символов,      Цвет фона
        static public void ShowFrameMessage(string Message, string InBrackets, int indents, int fieldSymbols, int Y = 2, ConsoleColor CharsColor = ConsoleColor.White, ConsoleColor BackColor = ConsoleColor.Blue)
        {
            int lenght = Message.Length;
            //Если размер строки больше ширины консоли - выводим сообщение об этом
            if (Message.Length > Console.WindowWidth && Message.IndexOf('\n') < 0)
            {
                Console.BackgroundColor = ConsoleColor.Red;
                Console.ForegroundColor = ConsoleColor.White;
                Console.Clear();

                string Info = $"Введённая строка слишком больша.\nДлина {lenght} больше ширины консоли {Console.WindowWidth}. Уменьшите длину сообщения.", empty = new string(' ', Info.Length);

                Console.SetCursorPosition(Console.WindowWidth / 2 - Info.Length, Console.WindowHeight / 2 - 1);
                Console.WriteLine(empty);
                Console.SetCursorPosition(Console.WindowWidth / 2 - Info.Length, Console.WindowHeight / 2);
                Console.WriteLine(Info);
                Console.SetCursorPosition(Console.WindowWidth / 2 - Info.Length, Console.WindowHeight / 2 + 2);
                Console.WriteLine(empty);

                Console.ReadKey();

                /* Console.BackgroundColor = _MainColor;
                 Console.ForegroundColor = _SymbolsColor;*/

                Palette.MainColor.EstablishColor();
                return;
            }

            Console.BackgroundColor = BackColor;
            Console.ForegroundColor = CharsColor;
            // Console.Clear();

            string indent = new string(' ', lenght), //Пустая строка для формирования вертикального отсутпа
                   field = new string(' ', fieldSymbols);

            

            //Вывод пустой строки + сообщения
            for (int i = 0; i <= indents; i++)
            {

                Console.SetCursorPosition(2, Y + i);
                Console.WriteLine($"{field}{indent}{field}");
                //Вывод самого сообщения

                //Как только вывели все отсупы - выводим строку сообщения 
                if (i == indents)
                {
                    Console.SetCursorPosition(2, Y + i);
                    Console.WriteLine(field + Message + field);
                   
                    //Вывод нижних полей
                    for (int p = 1; p <= indents; p++)
                    {
                        Console.SetCursorPosition(2, Y + i + p);
                        Console.WriteLine(field + indent + field);
                    }
                }
                //Выводим сообщение в квадратных скобках на одну строку выше главного сообщения
                if (i == indents - 1)
                {
                    Console.SetCursorPosition(2, Y + i);
                    Console.Write(field + $"[{InBrackets}]");

                }
            }

            /*Console.ForegroundColor = ConsoleColor.Black;
            Console.BackgroundColor = _MainColor;*/

            //Использую палитру
            Palette.MainColor.EstablishColor();
        }
    } // class Utils
}