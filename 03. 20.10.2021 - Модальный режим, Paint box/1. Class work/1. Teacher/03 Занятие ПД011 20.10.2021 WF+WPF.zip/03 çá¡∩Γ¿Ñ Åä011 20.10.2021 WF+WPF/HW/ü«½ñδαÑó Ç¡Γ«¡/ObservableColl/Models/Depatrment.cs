﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ObservableColl.Models
{
    internal partial class Department:IEnumerable
    {
        public ObservableCollection<User> _users;


        public Department():this(new ObservableCollection<User>())
        {
           

        }

        public Department(ObservableCollection<User> users)
        {
            _users = users;
        }

        //инициилизация
        public void Initialize()
        {
            for (int i = 0; i < 20; i++)
            {
                _users.Add(User.Generate());
            }
        }

           
        //Добавление 3 персон со знаком Рыбы
        public void Create()
        {
            //подпись на событие
            _users.CollectionChanged += Users_CollectionChanged;

            for (int i = 0; i < 3; i++)
            {
                _users.Add(Add());
            }


        }

        //Генерация человека со знаком рыбы
        public User Add()
        {
            User user = new User();
            do
            {
                user = User.Generate();
                if (user.Zodiac.Contains("Рыбы")) break;
            } while (true);
            return user;

        }

        //Удаление всех пользователей страше 60 лет
        public void Delete()
        {
            _users.CollectionChanged += Users_CollectionChanged;
            DateTime  date = DateTime.Now;
            for (int i = 0; i < _users.Count; i++)
            {
                if (date.Year - _users[i].Birth.Year > 60)
                {
                    _users.RemoveAt(i);
                    
                }
            }

        }


        //заменить все записи знака Овен этими же записями, но с добавлением строки "-бе-бе" к фамилии (update - replace)
        public void Update()
       {

            _users.CollectionChanged += Users_CollectionChanged;
            User user = new User();
           
            for (int i = 0; i < _users.Count; i++)
            {
                if (_users[i].Zodiac.Contains("Овен"))
                {
                    user = _users[i];
                    user.Name = $"{user.Name}-бе-бе";
                    _users[i] = user;
                  
                 }
            }
      

        }

        public IEnumerator GetEnumerator() => _users.GetEnumerator();




        //Обработчик события
        private static void Users_CollectionChanged(object sender, NotifyCollectionChangedEventArgs e)
        {
            switch (e.Action)
            {
                case NotifyCollectionChangedAction.Add: // если добавление
                    User newUser = e.NewItems[0] as User;
                    Console.ForegroundColor = ConsoleColor.Yellow;
                    Console.WriteLine($"Добавлен новый объект:{newUser.Index} {newUser.Name} {newUser.Zodiac} {newUser.Birth}");
                    Console.ForegroundColor = ConsoleColor.White;
                    break;
                case NotifyCollectionChangedAction.Remove: // если удаление
                    User oldUser = e.OldItems[0] as User;
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine($"Удален объект: {oldUser.Index} {oldUser.Name} {oldUser.Zodiac} {oldUser.Birth}");
                    Console.ForegroundColor = ConsoleColor.White;
                    break;
                case NotifyCollectionChangedAction.Replace: // если замена
                    User replacedUser = e.OldItems[0] as User;
                    User replacingUser = e.NewItems[0] as User;
                    Console.ForegroundColor = ConsoleColor.Yellow;
                    Console.WriteLine($"Объект {replacedUser.Index} {replacedUser.Name} {replacedUser.Zodiac} {replacedUser.Birth} " +
                        $"\nзаменен объектом {replacingUser.Index} {replacingUser.Name} {replacingUser.Zodiac} {replacingUser.Birth}");
                    Console.ResetColor();
                    break;
            }
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder("");

            foreach (var user in _users)
            {  // !!! Внимание !!! для массива
                sb.Append($"{user}\n");     // !!! работает цикл foreach
            } // foreach

            return sb.ToString();
        } // ToString

      
    }



}
