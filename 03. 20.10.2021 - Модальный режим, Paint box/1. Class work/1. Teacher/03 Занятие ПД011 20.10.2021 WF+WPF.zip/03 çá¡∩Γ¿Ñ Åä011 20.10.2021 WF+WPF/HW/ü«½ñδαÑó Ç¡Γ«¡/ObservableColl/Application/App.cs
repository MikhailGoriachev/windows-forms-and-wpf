﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ObservableColl.Models;

namespace ObservableColl.Application
{
    internal class App
    {

        Department dep;

        public App():this(new Department())
        {

        }

        public App(Department d)
        {
            dep = d;
        }

        //заполнение и вывод
        public void Init()
        {
            dep.Initialize();
            dep.Show("Вывод коллекции");
        }

        //Добавление
        public void Add()
        {
            dep.Create();
            dep.Show("\nВывод коллекции");
        }

        //удаление
        public void Del()
        {
            dep.Delete();
            dep.Show("\nВывод коллекции");
        }

        //изменение
        public void Upd()
        {
            dep.Update();
            dep.Show("\nВывод коллекции");
        }

        //при помощи именованного итератора вывести в список и консоль записи с заданной фамилией
        public void ShowNames()
        {
            Console.CursorVisible = true;
            Console.Write("Введите фамилию для поиска: ");
            Console.BackgroundColor = ConsoleColor.Yellow;
            Console.ForegroundColor = ConsoleColor.Black;

            string msg = Console.ReadLine();

           Console.BackgroundColor = ConsoleColor.Black;
            Console.ForegroundColor = ConsoleColor.White;
            Console.CursorVisible = false;
            foreach (var item in dep.GetName(msg))
            {
                Console.WriteLine(item);
            }

        }

        //при помощи именованного итератора вывести в список и консоль записи с заданным знаком Зодиака

        public void ShowZodiacs()
        {
            Console.CursorVisible = true;
            Console.Write("Введите знак зодиака для поиска: ");
            Console.BackgroundColor = ConsoleColor.Yellow;
            Console.ForegroundColor = ConsoleColor.Black;

            string msg = Console.ReadLine();

            Console.BackgroundColor = ConsoleColor.Black;
            Console.ForegroundColor = ConsoleColor.White;
            Console.CursorVisible = false;

            foreach (var item in dep.GetZodiac(msg))
            {
                Console.WriteLine(item);
            }

        }

        //при помощи именованного итератора вывести в список и консоль записи с заданным месяцем рождения
        public void ShowMonth()
        {
            Console.CursorVisible = true;
            Console.Write("Введите месяц от 1 до 12 для поиска: ");
            Console.BackgroundColor = ConsoleColor.Yellow;
            Console.ForegroundColor = ConsoleColor.Black;

            string msg= Console.ReadLine();
            int.TryParse(msg, out int res);
            Console.BackgroundColor = ConsoleColor.Black;
            Console.ForegroundColor = ConsoleColor.White;
            Console.CursorVisible = false;
            foreach (var item in dep.GetMonth(res))
            {
                Console.WriteLine(item);
            }

        }


        //сортировка по дате рождения
        public void SortDate()
        {
            dep.OrderByDate();
            dep.Show("Вывод коллекции отсортированной по дате рождения");
        }

        //сортировка по зодиаку
        public void SortZodiac()
        {
            dep.OrderByZodiac();
            dep.Show("Вывод коллекции отсортированной по знаку зодиака");

            
        }

        //сортировка по имени
        public void SortName()
        {
            dep.OrderByName();
            dep.Show("Вывод коллекции отсортированной по имени");


        }
    }
}
