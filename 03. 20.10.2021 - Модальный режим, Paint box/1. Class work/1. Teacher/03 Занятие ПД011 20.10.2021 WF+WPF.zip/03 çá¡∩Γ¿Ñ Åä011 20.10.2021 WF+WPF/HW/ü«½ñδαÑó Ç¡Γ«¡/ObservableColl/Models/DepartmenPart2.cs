﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ObservableColl.Models
{
    internal partial class Department
    {

        //при помощи именованного итератора вывести в список и консоль записи с заданной фамилией
        public IEnumerable GetName(string name)
        {
            foreach (var item in _users)
            {
                if (item.Name.Contains(name))
                {
                    yield return item;
                }
                else
                {
                    Console.WriteLine($"\"{name}\" не найден в списке!");
                    break;
                }
            }

          
        }

        //при помощи именованного итератора вывести в список и консоль записи с заданным знаком Зодиака
        public IEnumerable GetZodiac(string zodiac)
        {
            foreach (var item in _users)
            {
                if (item.Zodiac.Contains(zodiac))
                {
                    yield return item;
                }
                else
                {
                    Console.WriteLine($"Знак зодиака \"{zodiac}\" не найден в списке!");
                    break;
                }
            }
        }

        //при помощи именованного итератора вывести в список и консоль записи с заданным месяцем рождения
        public IEnumerable GetMonth(int month)
        {
            foreach (var item in _users)
            {
                if (item.Birth.Month == month)
                {
                    yield return item;
                }
                else
                {
                    Console.WriteLine($"Пользователь с таким месяцом рождения не найден в списке!");
                    break;
                }
            }
        }

        //сортировка по дате рождения
        public void OrderByDate()
        {
            var SortList = new List<User>(_users);
            SortList.Sort((User p1, User p2) => p1.Birth.CompareTo(p2.Birth));

            for (int i = 0; i < SortList.Count; i++)
            {
                _users.Move(_users.IndexOf(SortList[i]), i);
            }
        }

        //Сортировка по знаку зодиака
         public void OrderByZodiac()
        {
            var SortList = new List<User>(_users);
            SortList.Sort((User p1, User p2) => p1.Zodiac.CompareTo(p2.Zodiac));

            for (int i = 0; i < SortList.Count; i++)
            {
                _users.Move(_users.IndexOf(SortList[i]), i);
            }
        }


        //Сортировка по имение
        public void OrderByName()
        {
            var SortList = new List<User>(_users);
            SortList.Sort((User p1, User p2) => p1.Name.CompareTo(p2.Name));

            for (int i = 0; i < SortList.Count; i++)
            {
                _users.Move(_users.IndexOf(SortList[i]), i);
            }
        }


        public void Show(string title)
        {
            ConsoleColor old = Console.ForegroundColor;
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine(title);
            Console.ForegroundColor = old;
            foreach (var item in _users)
            {
                Console.WriteLine(item);
            }
        }

      
        }
    }

