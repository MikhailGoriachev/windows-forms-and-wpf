﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ObservableColl.Models;
using ObservableColl.Application;
/*Задача 1. Описать класс с именем User, содержащую следующие поля:
числовой идентификатор - int;
фамилия, имя - string;
знак Зодиака - string;
дата рождения - DateTime
Создать класс Department со списком пользователей – коллекцией типа ObservableCollection<User>. Проинициировать ее не менее чем 20 записями о пользователях, использовать все знаки Зодиака, заполнение коллекции также выполняйте из пункта меню.
Реализовать CRUD-операции, (операции Read и Update – реализовать индексатором), обрабатывать события добавления, удаления и замещения (replace) данных в коллекции. 
Обрабатывать события при выполнении следующих запросов, включенных в меню приложения:
добавление трех пользователей со знаком Рыбы (create)
удаление всех пользователей старше 60 лет (delete)
заменить все записи знака Овен этими же записями, но с добавлением строки "-бе-бе" к фамилии (update - replace)
Таже в пунктах меню задать выполнение следующих действий:
при помощи именованного итератора вывести в список и консоль записи с заданной фамилией
при помощи именованного итератора вывести в список и консоль записи с заданным знаком Зодиака
при помощи именованного итератора вывести в список и консоль записи с заданным месяцем рождения
сортировка по дате рождения
сортировка по названиям знаков Зодиака
сортировка по фамилии, имени
*/
namespace ObservableColl
{
    class Program
    {
        static void Main(string[] args)
        {
            // простейшее меню приложения
            MenuItem[] menu = new[] {
                new MenuItem {HotKey = ConsoleKey.Q, Text = "Инициилизация и вывод Department"},
                new MenuItem {HotKey = ConsoleKey.W, Text = "добавление трех пользователей со знаком Рыбы (create)"},
                new MenuItem {HotKey = ConsoleKey.E, Text = "удаление всех пользователей старше 60 лет (delete)"},
                new MenuItem {HotKey = ConsoleKey.R, Text = "заменить все записи знака Овен этими же записями, но с добавлением строки \"-бе-бе\" к фамилии"},
               //_________________________________________________________________________________________________________________________________
                new MenuItem {HotKey = ConsoleKey.T, Text = "при помощи именованного итератора вывести в список и консоль записи с заданной фамилией"},
                new MenuItem {HotKey = ConsoleKey.Y, Text = "при помощи именованного итератора вывести в список и консоль записи с заданным знаком Зодиака"},
                new MenuItem {HotKey = ConsoleKey.A, Text = "при помощи именованного итератора вывести в список и консоль записи с заданным месяцем рождения"},
                //____________________________________________________________________________________________________________________________________
                new MenuItem {HotKey = ConsoleKey.S, Text = "сортировка по дате рождения"},
                new MenuItem {HotKey = ConsoleKey.D, Text = "сортировка по Зодиаку"},
                new MenuItem {HotKey = ConsoleKey.F, Text = "сортировка по Имени"},
                //----------------------------------------------------------------------------------------------
                new MenuItem {HotKey = ConsoleKey.Z, Text = "Выход"},
            };


            App app = new App();
            // главный цикл приложения
            while (true)
            {
               
                    // настройка цветового оформления
                    (Console.ForegroundColor, Console.BackgroundColor) = (ConsoleColor.White, ConsoleColor.Black);
                    Console.Clear();
                    Console.CursorVisible = false;

                    Utils.ShowNavBarTask("Интерфейс IEnumerable и его реализация");
                    Utils.ShowMenu(12, 5, "Меню приложения для демонстрации работы c ObserverCollections и IEnumerable в C#", menu);

                    // получить код нажатой клавиши, не отображать символ клавиши
                    Console.BackgroundColor = ConsoleColor.Black;
                    string msg =
                        "  Нажмите выделенную цветом клавишу для выбора пункта меню".PadRight(Console.WindowWidth - 1);
                    Utils.WriteXY(0, Console.WindowHeight - 1, msg, ConsoleColor.Black);

                    ConsoleKey key = Console.ReadKey(true).Key;
                    (Console.ForegroundColor, Console.BackgroundColor) = (ConsoleColor.White, ConsoleColor.Black);
                    Console.Clear();

                    switch (key)
                    {                       
                        case ConsoleKey.Q:
                            app.Init();
                            break;

                
                        case ConsoleKey.W:
                            app.Add();
                            break;

                        
                        case ConsoleKey.E:
                            app.Del();
                            break;

                        case ConsoleKey.R:
                            app.Upd();
                            break;
                        case ConsoleKey.T:
                            app.ShowNames();
                            break;
                        case ConsoleKey.Y:
                            app.ShowZodiacs();
                            break;
                        case ConsoleKey.A:
                            app.ShowMonth();
    
                            break;
                        case ConsoleKey.S:
                            app.SortDate();
                            break;
                        case ConsoleKey.D:
                            app.SortZodiac();
                            break;
                        case ConsoleKey.F:
                            app.SortName();
                            break;
                        // Выход из приложения назначен на клавишу F10 или клавишу M или клавишу Escape
                        case ConsoleKey.F10:
                        case ConsoleKey.Escape:
                        case ConsoleKey.Z:
                            Console.ResetColor(); // сброс цветового сочетания к исходному
                            Console.Clear();
                            Utils.WriteXY(0, Console.WindowHeight - 1, "Нажмите любую клавишу...", ConsoleColor.Gray);
                            Console.CursorVisible = true;
                            return;

                        default:
                            throw new Exception("Нет такой команды меню");
                    } // switch

                    // Ожидать нажатия любой клавиши по окончании работы пункта меню
                    Console.CursorVisible = true;
                    Console.BackgroundColor = ConsoleColor.Gray;
                    msg = "  Нажмите любую клавишу...".PadRight(Console.WindowWidth - 1);
                    Utils.WriteXY(0, Console.WindowHeight - 1, msg, ConsoleColor.Black);
                    Console.ReadKey(true);
               
            } // while
           

            
           
        }

      
    }
}
