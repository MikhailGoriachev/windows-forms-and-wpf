﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace ObservableColl.Models
{
    internal class User
    {
        //числовой идентификатор
        public int Index{ get; set; }
        
        //Имя
        public string Name { get; set; }
        //Знак зодиака
        public string Zodiac{ get; set; }
        //Дата рождения
        public DateTime Birth { get; set; }


        public override string ToString() =>
            $"[ID = {Index}; Name = {Name,-20}| Zodiac = {Zodiac,-10}| Birth = {Birth}]";


       
      
        // генерация объекта класса User
        public static User Generate()
        {
            
            string[] names =
            {
                "Ровенский Б.Ю.","Спекторенко И.Д.","Спекторенко А.Д.","Ерхов Г.П",
                "Нестерцов В.И","Кулиш Д.А.","Кузьмин В.И.","Шевцова А.К","Чепикова У.Ю.",
                "Павлова П.П.","Шеремет Е.А.","Надворный А.Д.","Чернобровкина А.В.",
                "Золотарева Е.К.","Макушкин Д.К.","Шишков А.Г.","Краснова Ю.В."
            };

            string[] zodiacs =
            {
                "Весы","Дева","Телец","Козерог","Стрелец","Скорпион","Овен","Водолей",
                "Весы","Лев","Рак","Близнецы","Змееносец","Рыбы"
            };

            DateTime[] dates = new DateTime[]
            {
                new DateTime(1999,12,21,18,22,30),new DateTime(1950,10,11,10,12,30),new DateTime(2001,3,22,20,21,0),
                new DateTime(1950,4,18,22,10,0),new DateTime(1960,11,12),new DateTime(1946,6,24,10,22,30),
                new DateTime(2004,2,23,10,30,0),new DateTime(1960,3,8,14,20,30),new DateTime(1980,1,11,12,30,12),
                new DateTime(1942,4,21,13,14,15),new DateTime(1970,3,13,20,12,30),new DateTime(1998,12,21,15,20,10),
                
            };

            return new User
            {
                Index = Utils.GetRandom(1000,2001),
                Name = names[Utils.GetRandom(0, names.Length - 1)],
                Zodiac = zodiacs[Utils.GetRandom(0,zodiacs.Length -1 )],
                Birth = dates[Utils.GetRandom(0,dates.Length -1)]
                
            };
        } // Generate
    }
}
