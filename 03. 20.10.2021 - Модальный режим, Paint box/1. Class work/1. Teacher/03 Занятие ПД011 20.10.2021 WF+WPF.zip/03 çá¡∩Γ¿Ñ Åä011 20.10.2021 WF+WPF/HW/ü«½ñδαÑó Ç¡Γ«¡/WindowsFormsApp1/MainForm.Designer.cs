﻿
namespace WindowsFormsApp1
{
    partial class MainForm
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.groupBoxInputData = new System.Windows.Forms.GroupBox();
            this.TbxThirdNum = new System.Windows.Forms.TextBox();
            this.labelThirdNum = new System.Windows.Forms.Label();
            this.TbxSeconNum = new System.Windows.Forms.TextBox();
            this.LabelSecondNum = new System.Windows.Forms.Label();
            this.TbxFirst = new System.Windows.Forms.TextBox();
            this.LabelFirstNum = new System.Windows.Forms.Label();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.groupBoxResultData = new System.Windows.Forms.GroupBox();
            this.labelResult = new System.Windows.Forms.Label();
            this.buttonSum = new System.Windows.Forms.Button();
            this.buttonSort = new System.Windows.Forms.Button();
            this.buttonExit = new System.Windows.Forms.Button();
            this.LabelInfo = new System.Windows.Forms.Label();
            this.groupBoxInputData.SuspendLayout();
            this.groupBoxResultData.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBoxInputData
            // 
            this.groupBoxInputData.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.groupBoxInputData.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.groupBoxInputData.Controls.Add(this.TbxThirdNum);
            this.groupBoxInputData.Controls.Add(this.labelThirdNum);
            this.groupBoxInputData.Controls.Add(this.TbxSeconNum);
            this.groupBoxInputData.Controls.Add(this.LabelSecondNum);
            this.groupBoxInputData.Controls.Add(this.TbxFirst);
            this.groupBoxInputData.Controls.Add(this.LabelFirstNum);
            this.groupBoxInputData.Location = new System.Drawing.Point(35, 25);
            this.groupBoxInputData.Name = "groupBoxInputData";
            this.groupBoxInputData.Size = new System.Drawing.Size(444, 316);
            this.groupBoxInputData.TabIndex = 0;
            this.groupBoxInputData.TabStop = false;
            this.groupBoxInputData.Text = " Исходные данные: ";
            this.groupBoxInputData.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // TbxThirdNum
            // 
            this.TbxThirdNum.Location = new System.Drawing.Point(21, 270);
            this.TbxThirdNum.Name = "TbxThirdNum";
            this.TbxThirdNum.Size = new System.Drawing.Size(251, 33);
            this.TbxThirdNum.TabIndex = 5;
            // 
            // labelThirdNum
            // 
            this.labelThirdNum.AutoSize = true;
            this.labelThirdNum.Location = new System.Drawing.Point(16, 242);
            this.labelThirdNum.Name = "labelThirdNum";
            this.labelThirdNum.Size = new System.Drawing.Size(156, 25);
            this.labelThirdNum.TabIndex = 4;
            this.labelThirdNum.Text = "Третье число";
            // 
            // TbxSeconNum
            // 
            this.TbxSeconNum.Location = new System.Drawing.Point(21, 181);
            this.TbxSeconNum.Name = "TbxSeconNum";
            this.TbxSeconNum.Size = new System.Drawing.Size(251, 33);
            this.TbxSeconNum.TabIndex = 3;
            // 
            // LabelSecondNum
            // 
            this.LabelSecondNum.AutoSize = true;
            this.LabelSecondNum.Location = new System.Drawing.Point(16, 153);
            this.LabelSecondNum.Name = "LabelSecondNum";
            this.LabelSecondNum.Size = new System.Drawing.Size(171, 25);
            this.LabelSecondNum.TabIndex = 2;
            this.LabelSecondNum.Text = "Воторое число";
            // 
            // TbxFirst
            // 
            this.TbxFirst.Location = new System.Drawing.Point(21, 90);
            this.TbxFirst.Name = "TbxFirst";
            this.TbxFirst.Size = new System.Drawing.Size(251, 33);
            this.TbxFirst.TabIndex = 1;
            // 
            // LabelFirstNum
            // 
            this.LabelFirstNum.AutoSize = true;
            this.LabelFirstNum.Location = new System.Drawing.Point(16, 62);
            this.LabelFirstNum.Name = "LabelFirstNum";
            this.LabelFirstNum.Size = new System.Drawing.Size(162, 25);
            this.LabelFirstNum.TabIndex = 0;
            this.LabelFirstNum.Text = "Первое число";
            this.LabelFirstNum.Click += new System.EventHandler(this.label1_Click);
            // 
            // groupBoxResultData
            // 
            this.groupBoxResultData.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.groupBoxResultData.Controls.Add(this.labelResult);
            this.groupBoxResultData.Location = new System.Drawing.Point(548, 25);
            this.groupBoxResultData.Name = "groupBoxResultData";
            this.groupBoxResultData.Size = new System.Drawing.Size(423, 316);
            this.groupBoxResultData.TabIndex = 0;
            this.groupBoxResultData.TabStop = false;
            this.groupBoxResultData.Text = " Результат: ";
            // 
            // labelResult
            // 
            this.labelResult.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelResult.Location = new System.Drawing.Point(3, 29);
            this.labelResult.Name = "labelResult";
            this.labelResult.Size = new System.Drawing.Size(417, 284);
            this.labelResult.TabIndex = 0;
            // 
            // buttonSum
            // 
            this.buttonSum.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonSum.Location = new System.Drawing.Point(35, 369);
            this.buttonSum.Name = "buttonSum";
            this.buttonSum.Size = new System.Drawing.Size(210, 51);
            this.buttonSum.TabIndex = 1;
            this.buttonSum.Text = "Сумма двух \r\nмаксимальных";
            this.buttonSum.UseVisualStyleBackColor = true;
            this.buttonSum.Click += new System.EventHandler(this.button1_Click);
            // 
            // buttonSort
            // 
            this.buttonSort.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonSort.Location = new System.Drawing.Point(35, 434);
            this.buttonSort.Name = "buttonSort";
            this.buttonSort.Size = new System.Drawing.Size(210, 51);
            this.buttonSort.TabIndex = 2;
            this.buttonSort.Text = "Сортировка";
            this.buttonSort.UseVisualStyleBackColor = true;
            this.buttonSort.Click += new System.EventHandler(this.button2_Click);
            // 
            // buttonExit
            // 
            this.buttonExit.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonExit.Image = ((System.Drawing.Image)(resources.GetObject("buttonExit.Image")));
            this.buttonExit.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonExit.Location = new System.Drawing.Point(35, 508);
            this.buttonExit.Name = "buttonExit";
            this.buttonExit.Size = new System.Drawing.Size(210, 54);
            this.buttonExit.TabIndex = 3;
            this.buttonExit.Text = "Выход";
            this.buttonExit.UseVisualStyleBackColor = true;
            this.buttonExit.Click += new System.EventHandler(this.buttonExit_Click);
            // 
            // LabelInfo
            // 
            this.LabelInfo.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.LabelInfo.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LabelInfo.ForeColor = System.Drawing.Color.Black;
            this.LabelInfo.Location = new System.Drawing.Point(339, 369);
            this.LabelInfo.Name = "LabelInfo";
            this.LabelInfo.Size = new System.Drawing.Size(632, 193);
            this.LabelInfo.TabIndex = 4;
            this.LabelInfo.Click += new System.EventHandler(this.LabelInfo_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ClientSize = new System.Drawing.Size(1016, 574);
            this.Controls.Add(this.LabelInfo);
            this.Controls.Add(this.buttonExit);
            this.Controls.Add(this.buttonSort);
            this.Controls.Add(this.buttonSum);
            this.Controls.Add(this.groupBoxInputData);
            this.Controls.Add(this.groupBoxResultData);
            this.Font = new System.Drawing.Font("Verdana", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Name = "MainForm";
            this.Text = "Элементы ввода";
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.groupBoxInputData.ResumeLayout(false);
            this.groupBoxInputData.PerformLayout();
            this.groupBoxResultData.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBoxInputData;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.GroupBox groupBoxResultData;
        private System.Windows.Forms.TextBox TbxFirst;
        private System.Windows.Forms.Label LabelFirstNum;
        private System.Windows.Forms.TextBox TbxThirdNum;
        private System.Windows.Forms.Label labelThirdNum;
        private System.Windows.Forms.TextBox TbxSeconNum;
        private System.Windows.Forms.Label LabelSecondNum;
        private System.Windows.Forms.Label labelResult;
        private System.Windows.Forms.Button buttonSum;
        private System.Windows.Forms.Button buttonSort;
        private System.Windows.Forms.Button buttonExit;
        private System.Windows.Forms.Label LabelInfo;
    }
}

