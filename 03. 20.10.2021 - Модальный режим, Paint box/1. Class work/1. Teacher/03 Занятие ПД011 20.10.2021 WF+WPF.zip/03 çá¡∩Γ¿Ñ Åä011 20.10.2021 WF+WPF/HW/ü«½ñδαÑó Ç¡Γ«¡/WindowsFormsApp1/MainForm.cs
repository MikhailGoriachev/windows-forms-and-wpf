﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
            LabelInfo.Text = $"Информация о задании" +
                $"\nЗадача1. Даны три переменные вещественного типа. Найти сумму двух наибольших из них " +
                $"(т.е. для чисел 1, 2, 3 сумма будет равна 5) " +
               $"\nЗадача2.Даны три переменные вещественного типа: A, B, C.Если их значения упорядочены по " +
              $"  возрастанию или убыванию, то удвоить их; в противном случае заменить значение каждой переменной " +
              $"  на противоположное.Вывести новые значения переменных A, B, C.";
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void MainForm_Load(object sender, EventArgs e)
        {

        }

        // решение задачи 2Даны три переменные вещественного типа: A, B, C.
        // Если их значения упорядочены по возрастанию или убыванию, то удвоить их; в противном случае з
        // аменить значение каждой переменной на противоположное. Вывести новые значения переменных A, B, C.
        private void button2_Click(object sender, EventArgs e)
        {
            double a = double.Parse(TbxFirst.Text);
            double b = double.Parse(TbxSeconNum.Text);
            double c = double.Parse(TbxThirdNum.Text);

            if (a < b && b < c || (a > b && b > c))
            {
                a *= 2;
                b *= 2;
                c *= 2;

            }
            else
            {
                a = -a;
                b = -b;
                c = -c;
            }

            labelResult.Text = $"{a} , {b} , {c} ";

        }

        //решение задачи 1 Даны три переменные вещественного типа. Найти сумму двух наибольших из них
        //(т.е. для чисел 1, 2, 3 сумма будет равна 5).

        private void button1_Click(object sender, EventArgs e)
        {
            double a = double.Parse(TbxFirst.Text);
            double b = double.Parse(TbxSeconNum.Text);
            double c = double.Parse(TbxThirdNum.Text);

            double max, sum;
            double[] arr = { a, b, c };
            max = arr.Max();
            double max2 = arr[0];
            foreach (var item in arr)
            {
                if(max2 < item && item < max)
                {
                    max2 = item;
                }
            }
            sum = max + max2;

            labelResult.Text = $"Первое максимальное {max} \nВторое максимальное {max2} \nCумма {sum}";
        }


        //закрытие главной формы
        private void buttonExit_Click(object sender, EventArgs e) => Close();

        private void LabelInfo_Click(object sender, EventArgs e)
        {

        }
    }
}
