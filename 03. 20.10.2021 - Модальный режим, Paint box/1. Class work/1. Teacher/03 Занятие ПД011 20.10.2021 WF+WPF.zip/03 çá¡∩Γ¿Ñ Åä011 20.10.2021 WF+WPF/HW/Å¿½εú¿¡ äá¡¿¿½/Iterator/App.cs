﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Iterator.Classes;

/*
Обрабатывать события при выполнении следующих запросов, включенных в меню приложения:
•	добавление трех пользователей со знаком Рыбы (create)
•	удаление всех пользователей старше 60 лет (delete)
•	заменить все записи знака Овен этими же записями, но с добавлением строки "-бе-бе" к фамилии (update - replace)
Таже в пунктах меню задать выполнение следующих действий:
•	при помощи именованного итератора вывести в список и консоль записи с заданной фамилией
	при помощи именованного итератора вывести в список и консоль записи с заданным знаком Зодиака
	при помощи именованного итератора вывести в список и консоль записи с заданным месяцем рождения
	сортировка по дате рождения
	сортировка по названиям знаков Зодиака
	сортировка по фамилии, имени
*/

namespace Iterator
{
    class App
    {
        private Department _department;
        

        public App()
        {
            _department = new Department();
        }

        //пункты меню
        private string[] _menu = {
            "Вывести список пользователей в консоль - Q",
            "Добавление трех пользователей со знаком Рыбы - W",
            "Удаление всех пользователей старше 60 лет - E",
            "Заменить все записи знака Овен этими же записями + \"бе - бе\" - R",
            "Вывести в список и консоль записи с заданной фамилией - T",
            "Вывести в список и консоль записи с заданным знаком Зодиака - A",
            "Вывести в список и консоль записи с заданным месяцем рождения - S",
            "Cортировка по дате рождения - D",
            "Cортировка по названиям знаков Зодиака - F",
            "Cортировка по фамилии, имени - G",
            "Выход - Esc",
        };

        //вывод меню
        public void ShowMenu()
        {
            Console.Clear();
            Console.CursorVisible = false;
            for (int i = 0; i < _menu.Length; i++)
            {
                Console.ForegroundColor = ConsoleColor.Cyan;
                Console.SetCursorPosition(7, i + 10);
                Console.WriteLine(_menu[i]);
                Console.ForegroundColor = ConsoleColor.White;

            }
        }
        private void StTask(string str)
        {
            Console.Clear();
            Console.SetCursorPosition(20, 1);
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine(str + "\n");
        }
        private void EndTask()
        {
            Console.ReadKey();
        }

        //вывод в консоль всех пользователей
        public void ShowDepartment()
        {
            StTask("\t\tСписок пользователей");
            _department.Show();
            EndTask();
        }
        //Добавление трех пользователей со знаком Рыбы
        public void AddTrioWithFishSign()
        {
            StTask("\tДобавлены три пользователя со знаком рыбы!");
            _department.Add(new User("Матвей", new DateTime(2000, 2, 19)));
            _department.Add(new User("Игнат", new DateTime(1999, 2, 20)));
            _department.Add(new User("Альберт", new DateTime(1998, 2, 21)));

            _department.Show();
            EndTask();
        }
        //удаление всех пользователей старше 60 лет
        public void DeleteOlderSixty()
        {
            StTask("\tУдаление пользователей старше 60 лет");
            for (int i = 0; i < _department.Group.Count; i++)
            {
                if (_department[i].DateOfBirth.AddYears(60) < DateTime.Now)
                {
                    _department.RemoveAt(i);
                    i--;
                }
            }
            _department.Show();
            EndTask();
        }
        //замена Овенов на Овен-бе-бе
        public void ChangeOvenBeBe()
        {
            StTask("\t\tШутим над Овнами");
            int n = _department.Group.Count;

            for (int i = 0; i < _department.Group.Count; i++)
                if (_department[i].ZodiacSign == "Овен"){
                    //не зажигается событие...
                    _department[i] = _department[i];
                    _department[i].ZodiacSign += "-бе-бе";
                }

            _department.Show();
            EndTask();
        }
        //вывести записи с заданной фамилией
        public void ShowByName()
        {
            string tempName = _department[Utils.rdm.Next(0, _department.Group.Count)].Name;
            StTask($"\tПоиск пользователей {tempName}");

            Console.ForegroundColor = ConsoleColor.Cyan;

            StringBuilder sb = new StringBuilder();

            sb.Append("\t┌────┬──────────────────────┬──────────────────────┬─────────────────┐\n" +
                        "\t│ id │     Пользователь     │     Знак Зодиака     │  Дата рождения  │\n" +
                        "\t├────┼──────────────────────┼──────────────────────┼─────────────────┤\n");

            foreach (var item in _department.ShowByName(tempName))
                sb.Append((item as User).ToTable() + "\n");

            sb.Append("\t└────┴──────────────────────┴──────────────────────┴─────────────────┘\n");

            Console.WriteLine(sb);

            Console.ForegroundColor = ConsoleColor.White;

            EndTask();
        }
        //вывести записи с знаком Зодиака
        public void ShowByZodiac()
        {
            string tempZodiac = _department[Utils.rdm.Next(0, _department.Group.Count)].ZodiacSign;
            StTask($"\tПоиск пользователей {tempZodiac}");

            Console.ForegroundColor = ConsoleColor.Cyan;

            StringBuilder sb = new StringBuilder();

            sb.Append("\t┌────┬──────────────────────┬──────────────────────┬─────────────────┐\n" +
                        "\t│ id │     Пользователь     │     Знак Зодиака     │  Дата рождения  │\n" +
                        "\t├────┼──────────────────────┼──────────────────────┼─────────────────┤\n");

            foreach (var item in _department.ShowByZodiac(tempZodiac))
                sb.Append((item as User).ToTable() + "\n");

            sb.Append("\t└────┴──────────────────────┴──────────────────────┴─────────────────┘\n");

            Console.WriteLine(sb);

            Console.ForegroundColor = ConsoleColor.White;

            EndTask();
        }
        //вывести записи с заданным месяцем рождения
        public void ShowByMonth()
        {
            int month = _department[Utils.rdm.Next(0, _department.Group.Count)].DateOfBirth.Month;
            StTask($"\tПоиск пользователей родившихся в {month} месяце");

            Console.ForegroundColor = ConsoleColor.Cyan;

            StringBuilder sb = new StringBuilder();

            sb.Append("\t┌────┬──────────────────────┬──────────────────────┬─────────────────┐\n" +
                        "\t│ id │     Пользователь     │     Знак Зодиака     │  Дата рождения  │\n" +
                        "\t├────┼──────────────────────┼──────────────────────┼─────────────────┤\n");

            foreach (var item in _department.ShowByMonth(month))
                sb.Append((item as User).ToTable() + "\n");

            sb.Append("\t└────┴──────────────────────┴──────────────────────┴─────────────────┘\n");

            Console.WriteLine(sb);

            Console.ForegroundColor = ConsoleColor.White;

            EndTask();
        }
        //сортировка по дате рождения
        public void SortByDate()
        {
            StTask("\t\tСортирока по дате рождения");

            var tempArr = _department.Group.ToArray();
            Array.Sort(tempArr, (x1, x2) => x1.DateOfBirth.CompareTo(x2.DateOfBirth));

            Console.ForegroundColor = ConsoleColor.Cyan;

            StringBuilder sb = new StringBuilder();

            sb.Append("\t┌────┬──────────────────────┬──────────────────────┬─────────────────┐\n" +
                        "\t│ id │     Пользователь     │     Знак Зодиака     │  Дата рождения  │\n" +
                        "\t├────┼──────────────────────┼──────────────────────┼─────────────────┤\n");

            foreach (var item in tempArr)
                sb.Append(item.ToTable() + "\n");

            sb.Append("\t└────┴──────────────────────┴──────────────────────┴─────────────────┘\n");

            Console.WriteLine(sb);


            EndTask();
        }
        //сортировка по знаку зодиака
        public void SortByZodiac()
        {
            StTask("\t\tСортирока по знаку зодиака");

            var tempArr = _department.Group.ToArray();
            Array.Sort(tempArr, (x1, x2) => x1.ZodiacSign.CompareTo(x2.ZodiacSign));

            Console.ForegroundColor = ConsoleColor.Cyan;

            StringBuilder sb = new StringBuilder();

            sb.Append("\t┌────┬──────────────────────┬──────────────────────┬─────────────────┐\n" +
                        "\t│ id │     Пользователь     │     Знак Зодиака     │  Дата рождения  │\n" +
                        "\t├────┼──────────────────────┼──────────────────────┼─────────────────┤\n");

            foreach (var item in tempArr)
                sb.Append(item.ToTable() + "\n");
            
            sb.Append("\t└────┴──────────────────────┴──────────────────────┴─────────────────┘\n");

            Console.WriteLine(sb);

            EndTask();
        }
        //сортировка по имени
        public void SortByName()
        {
            StTask("\t\tСортирока по имени");

            var tempArr = _department.Group.ToArray();
            Array.Sort(tempArr, (x1, x2) => x1.Name.CompareTo(x2.Name));

            Console.ForegroundColor = ConsoleColor.Cyan;

            StringBuilder sb = new StringBuilder();

            sb.Append("\t┌────┬──────────────────────┬──────────────────────┬─────────────────┐\n" +
                        "\t│ id │     Пользователь     │     Знак Зодиака     │  Дата рождения  │\n" +
                        "\t├────┼──────────────────────┼──────────────────────┼─────────────────┤\n");

            foreach (var item in tempArr)
                sb.Append(item.ToTable() + "\n");
            
            sb.Append("\t└────┴──────────────────────┴──────────────────────┴─────────────────┘\n");

            Console.WriteLine(sb);

            EndTask();
        }

    }
}
