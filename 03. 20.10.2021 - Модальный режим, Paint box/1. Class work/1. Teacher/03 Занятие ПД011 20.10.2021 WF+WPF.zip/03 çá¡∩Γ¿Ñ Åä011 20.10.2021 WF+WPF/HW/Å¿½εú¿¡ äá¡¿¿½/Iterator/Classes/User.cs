﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/*
Описать класс с именем User, содержащую следующие поля:
•	числовой идентификатор - int;
•	фамилия, имя - string;
•	знак Зодиака - string;
•	дата рождения - DateTime
*/

namespace Iterator.Classes 
{
    class User
    {
        private int _id;                //числовой идентификатор
        private string _name;           //фамилия, имя
        private string _zodiacSign;     //знак Зодиака
        private DateTime _dob;          //дата рождения



        //свойства
        public int Id
        {
            get { return _id; }
        }
        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }
        public string ZodiacSign
        {
            get { return _zodiacSign; }
            set { _zodiacSign = value; }
        }
        public DateTime DateOfBirth
        {
            get { return _dob; }
            set { _dob = value; }
        }

        //конструкторы
        public User()
        {
            _id = Utils.getId();
            _name = "Игорь";
            _zodiacSign = "Весы";
            _dob = DateTime.Now;
        }
        public User(string name, DateTime dt)
        {
            _id = Utils.getId();
            _name = name;
            _zodiacSign = User.GetZodiac(dt);
            _dob = dt;
        }

        //фабрика
        static public User Create()
        {
            //массив имен
            string[] names =
            {
                "Игорь",
                "Светлана",
                "Роза",
                "Владимир",
                "Ярослав",
                "Вячеслав",
                "Софья",
                "Екатерина",
                "Никита",
                "Ростислав",
                "Татьяна",
                "Алексей",
            };
            //дата рождения
            DateTime dt = new DateTime(Utils.rdm.Next(1950, 2022), Utils.rdm.Next(1, 13), Utils.rdm.Next(1, 29));

            return new User(names[Utils.rdm.Next(0, names.Length)], dt);
        }

        //определение знака Зодиака по дате рождения
        static public string GetZodiac(DateTime dt)
        {
            string result;

            if ((dt.Month == 3 && (dt.Day >= 21 && dt.Day <= 31)) || (dt.Month == 4 && (dt.Day >= 1 && dt.Day <= 19)))
                result = "Овен";
            else if ((dt.Month == 4 && (dt.Day >= 20 && dt.Day <= 30)) || (dt.Month == 5 && (dt.Day >= 1 && dt.Day <= 20)))
                result = "Телец";
            else if ((dt.Month == 5 && (dt.Day >= 21 && dt.Day <= 31)) || (dt.Month == 6 && (dt.Day >= 1 && dt.Day <= 20)))
                result = "Близнецы";
            else if ((dt.Month == 6 && (dt.Day >= 21 && dt.Day <= 30)) || (dt.Month == 7 && (dt.Day >= 1 && dt.Day <= 22)))
                result = "Рак";
            else if ((dt.Month == 7 && (dt.Day >= 23 && dt.Day <= 31)) || (dt.Month == 8 && (dt.Day >= 1 && dt.Day <= 22)))
                result = "Лев";
            else if ((dt.Month == 8 && (dt.Day >= 23 && dt.Day <= 31)) || (dt.Month == 9 && (dt.Day >= 1 && dt.Day <= 22)))
                result = "Дева";
            else if ((dt.Month == 9 && (dt.Day >= 23 && dt.Day <= 30)) || (dt.Month == 10 && (dt.Day >= 1 && dt.Day <= 22)))
                result = "Весы";
            else if ((dt.Month == 10 && (dt.Day >= 23 && dt.Day <= 31)) || (dt.Month == 11 && (dt.Day >= 1 && dt.Day <= 21)))
                result = "Скорпион";
            else if ((dt.Month == 11 && (dt.Day >= 22 && dt.Day <= 30)) || (dt.Month == 12 && (dt.Day >= 1 && dt.Day <= 21)))
                result = "Стрелец";
            else if ((dt.Month == 12 && (dt.Day >= 22 && dt.Day <= 31)) || (dt.Month == 1 && (dt.Day >= 1 && dt.Day <= 19)))
                result = "Козерог";
            else if ((dt.Month == 1 && (dt.Day >= 20 && dt.Day <= 31)) || (dt.Month == 2 && (dt.Day >= 1 && dt.Day <= 18)))
                result = "Водолей";
            else
                result = "Рыба";

            return result;
        }

        //вывод в консоль
        public string ToTable() => $"\t│ {_id,-2} │ {_name,-20} │ {_zodiacSign,-20} │    {_dob.ToShortDateString(),-10}   │";

        //табличное представление объекта
        public override string ToString() => $"{_id}, {_name,-20}, {_zodiacSign,-20}, {_dob,-10}";

    }
}
