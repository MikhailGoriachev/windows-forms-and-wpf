﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Iterator.Classes
{
    class Utils
    {
        static public Random rdm = new Random();
        //уникальный идентификационный номер
        static private int id = 0;
        //генератор уник. идент. номера
        static public int getId()
        {
            id++;
            return id;
        }
    }
}
