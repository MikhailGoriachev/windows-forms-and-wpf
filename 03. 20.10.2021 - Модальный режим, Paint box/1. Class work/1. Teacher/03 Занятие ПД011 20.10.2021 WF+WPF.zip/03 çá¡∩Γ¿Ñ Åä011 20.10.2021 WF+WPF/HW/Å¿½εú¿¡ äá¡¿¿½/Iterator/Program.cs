﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualBasic;

/*
Описать класс с именем User, содержащую следующие поля:
•	числовой идентификатор - int;
•	фамилия, имя - string;
•	знак Зодиака - string;
•	дата рождения - DateTime
Создать класс Department со списком пользователей – коллекцией типа ObservableCollection<User>. 
Проинициировать ее не менее чем 20 записями о пользователях, использовать все знаки Зодиака, заполнение коллекции 
также выполняйте из пункта меню.
Реализовать CRUD-операции, (операции Read и Update – реализовать индексатором), обрабатывать события добавления, 
удаления и замещения (replace) данных в коллекции. 
Обрабатывать события при выполнении следующих запросов, включенных в меню приложения:
•	добавление трех пользователей со знаком Рыбы (create)
•	удаление всех пользователей старше 60 лет (delete)
•	заменить все записи знака Овен этими же записями, но с добавлением строки "-бе-бе" к фамилии (update - replace)
Таже в пунктах меню задать выполнение следующих действий:
•	при помощи именованного итератора вывести в список и консоль записи с заданной фамилией
•	при помощи именованного итератора вывести в список и консоль записи с заданным знаком Зодиака
•	при помощи именованного итератора вывести в список и консоль записи с заданным месяцем рождения
•	сортировка по дате рождения
•	сортировка по названиям знаков Зодиака
•	сортировка по фамилии, имени
*/




namespace Iterator
{
    class Program
    {
        static void Main(string[] args)
        {
            App app = new App();
            bool flag = true;

            try
            {
                while (flag)
                {
                    app.ShowMenu();
                    switch (Console.ReadKey().Key)
                    {
                        case ConsoleKey.Q:
                            app.ShowDepartment();
                            break;
                        case ConsoleKey.W:
                            app.AddTrioWithFishSign();
                            break;
                        case ConsoleKey.E:
                            app.DeleteOlderSixty();
                            break;
                        case ConsoleKey.R:
                            app.ChangeOvenBeBe();
                            break;
                        case ConsoleKey.T:
                            app.ShowByName();
                            break;
                        case ConsoleKey.A:
                            app.ShowByZodiac();
                            break;
                        case ConsoleKey.S:
                            app.ShowByMonth();
                            break;
                        case ConsoleKey.D:
                            app.SortByDate();
                            break;
                        case ConsoleKey.F:
                            app.SortByZodiac();
                            break;
                        case ConsoleKey.G:
                            app.SortByName();
                            break;
                        case ConsoleKey.Escape:
                            flag = false;
                            break;
                        default:
                            continue;
                    }
                }
            }
            catch (Exception ex)
            {
                Interaction.MsgBox(ex.Message, MsgBoxStyle.Critical);
            }
        }
    }
}
