﻿using System;
using System.Collections;
using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/*
Создать класс Department со списком пользователей – коллекцией типа ObservableCollection<User>. 
Проинициировать ее не менее чем 20 записями о пользователях, использовать все знаки Зодиака, заполнение коллекции 
также выполняйте из пункта меню.
Реализовать CRUD-операции, (операции Read и Update – реализовать индексатором), обрабатывать события добавления,
удаления и замещения (replace) данных в коллекции. 
Обрабатывать события при выполнении следующих запросов, включенных в меню приложения:
•	добавление трех пользователей со знаком Рыбы (create)
•	удаление всех пользователей старше 60 лет (delete)
•	заменить все записи знака Овен этими же записями, но с добавлением строки "-бе-бе" к фамилии (update - replace)
*/

namespace Iterator.Classes
{
    class Department
    {
        private ObservableCollection<User> _group; //массив пользователей User

        //свойствo
        public ObservableCollection<User> Group { get => _group; }

        //конструктор
        public Department()
        {
            _group = new ObservableCollection<User>();
            Iniz(20);
            _group.CollectionChanged += Users_CollectionChanged;
        }

        //инициализация массива
        public void Iniz(int n)
        {
            for (int i = 0; i < n; i++)
                _group.Add(User.Create());
        }

        //добавление элемента в массив
        public void Add(User us)
        {
            _group.Add(us);
        }

        //удаление из массива по индексу
        public void RemoveAt(int n)
        {
            _group.RemoveAt(n);
        }

        //замещение в массиве (операция Update)
        public void Replace(int n, User us)
        {
            _group[n] = us;
        }

        //реализация итератора (операция Read)
        public void Show()
        {
            Console.ForegroundColor = ConsoleColor.Cyan;

            StringBuilder sb = new StringBuilder();

            sb.Append(  "\t┌────┬──────────────────────┬──────────────────────┬─────────────────┐\n" +
                        "\t│ id │     Пользователь     │     Знак Зодиака     │  Дата рождения  │\n" +
                        "\t├────┼──────────────────────┼──────────────────────┼─────────────────┤\n");

            foreach (var item in _group)
                sb.Append(item.ToTable() + "\n");

            sb.Append("\t└────┴──────────────────────┴──────────────────────┴─────────────────┘\n");

            Console.WriteLine(sb);

            Console.ForegroundColor = ConsoleColor.White;
        }

        //именованный итератор с параметром по имени
        public IEnumerable ShowByName(string name)
        {
            foreach (var item in _group)
                if (item.Name == name)
                    yield return item;
        }

        //именованный итератор с параметром по знаку зодиака
        public IEnumerable ShowByZodiac(string zs)
        {
            foreach (var item in _group)
                if (item.ZodiacSign == zs)
                    yield return item;
        }

        //именованный итератор с параметром по месяцу рождения
        public IEnumerable ShowByMonth(int month)
        {
            foreach (var item in _group)
                if (item.DateOfBirth.Month == month)
                    yield return item;
        }

        //обработчик событий
        private static void Users_CollectionChanged(object sender, NotifyCollectionChangedEventArgs e)
        {
            switch (e.Action)
            {
                case NotifyCollectionChangedAction.Add: //добавление

                    User us = e.NewItems[0] as User;
                    if (us.ZodiacSign == "Рыба")
                    {
                        StringBuilder str = new StringBuilder();
                        str.Append("\t\t┌───────────────────────────────────────────────────┐\n" +
                            $"\t\t│ Добавлен пользователь   {us.Name, -10} со знаком Рыбы │\n"
                            + "\t\t└───────────────────────────────────────────────────┘");
                        Console.WriteLine(str);
                    }

                    break;
                case NotifyCollectionChangedAction.Remove: //удаление

                        us = e.OldItems[0] as User;
                    if (us.DateOfBirth.AddYears(60) < DateTime.Now)
                    {
                        StringBuilder str = new StringBuilder();
                        str.Append("\t\t┌───────────────────────────────────────────────────┐\n" +
                            $"\t\t│    Удален пользователь   {us.Name,-10} {us.DateOfBirth.ToShortDateString(), -10}    │\n"
                            + "\t\t└───────────────────────────────────────────────────┘");
                        Console.WriteLine(str);
                    }

                    break;
                case NotifyCollectionChangedAction.Replace: //замена

                    us = e.NewItems[0] as User;
                    if (us.ZodiacSign == "Овен-бе-бе")
                    {
                        StringBuilder str = new StringBuilder();
                        str.Append("\t\t┌───────────────────────────────────────────────────┐\n" +
                            $"\t\t│    Пользователь   {us.Name,-10} теперь {us.ZodiacSign,-10}    │\n"
                            + "\t\t└───────────────────────────────────────────────────┘");
                        Console.WriteLine(str);
                    }

                    break;
            }
        }

        //индексатор
        public User this[int index]
        {
            get 
            {
                if (index >= 0 && index < _group.Count)
                    return _group[index];
                else throw new Exception("Выход за пределы массива!");
            }
            set 
            {
                if (index >= 0 && index < _group.Count)
                    _group[index] = value;
                else throw new Exception("Выход за пределы массива!");
            }
        }
        
    }

}
