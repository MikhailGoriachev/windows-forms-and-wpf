﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void BtnExit_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void TxBxInputA_Click(object sender, EventArgs e)
        {
            TxBxInputA.Text = "";
            ErrProvA.Clear();
        }
        private void TxBxInputB_Click(object sender, EventArgs e)
        {
            TxBxInputB.Text = "";
            ErrProvB.Clear();
        }
        private void TxBxInputC_Click(object sender, EventArgs e)
        {
            TxBxInputC.Text = "";
            ErrProvC.Clear();
        }

        private void BtnDoSumOf2_Click(object sender, EventArgs e)
        {
            double a, b, c, result;

            if (!double.TryParse(TxBxInputA.Text, out a))
                ErrProvA.SetError(TxBxInputA, "Некорректные данные!");
            if (!double.TryParse(TxBxInputB.Text, out b))
                ErrProvB.SetError(TxBxInputB, "Некорректные данные!");
            if (!double.TryParse(TxBxInputC.Text, out c))
                ErrProvC.SetError(TxBxInputC, "Некорректные данные!");

            if (a > c && b > c)
                result = a + b;
            else if (b > a && c > a)
                result = c + b;
            else
                result = a + c;


            LblResult.Text = $" Сумма двух наибольших = {result}\n A = {a}\n B = {b}\n C = {c}";
            TxBxInputA.Text = " A =";
            TxBxInputB.Text = " B =";
            TxBxInputC.Text = " C =";

        }

        private void BtnDoDoubleNumeric_Click(object sender, EventArgs e)
        {
            double a, b, c;
            bool flag = false;

            if (!double.TryParse(TxBxInputA.Text, out a))
                ErrProvA.SetError(TxBxInputA, "Некорректные данные!");
            if (!double.TryParse(TxBxInputB.Text, out b))
                ErrProvB.SetError(TxBxInputB, "Некорректные данные!");
            if (!double.TryParse(TxBxInputC.Text, out c))
                ErrProvC.SetError(TxBxInputC, "Некорректные данные!");

            if ((a > b && b > c) || (a < b && b < c))
            {
                flag = true;
                a *= 2;
                b *= 2;
                c *= 2;
            }
            else
            {
                a *= -1;
                b *= -1;
                c *= -1;
            }

            string str = flag ? "Числа упорядоченны по условию, удваиваем их:\n"
                : "Числа не упорядоченны по условию.\nМеняем их на противоположные:\n";
            LblResult.Text = $"{str} A = {a}\n B = {b}\n C = {c}";
            TxBxInputA.Text = " A =";
            TxBxInputB.Text = " B =";
            TxBxInputC.Text = " C =";
        }
    }
}
