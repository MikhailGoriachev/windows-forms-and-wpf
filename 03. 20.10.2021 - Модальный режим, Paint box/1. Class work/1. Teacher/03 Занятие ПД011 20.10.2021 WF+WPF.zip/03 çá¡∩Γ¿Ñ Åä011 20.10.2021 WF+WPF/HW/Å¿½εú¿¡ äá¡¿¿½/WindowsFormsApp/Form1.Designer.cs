﻿
namespace WindowsFormsApp
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.BtnExit = new System.Windows.Forms.Button();
            this.GrBxTaskButtons = new System.Windows.Forms.GroupBox();
            this.GrBxInput = new System.Windows.Forms.GroupBox();
            this.TxBxInputA = new System.Windows.Forms.TextBox();
            this.GrBxOutput = new System.Windows.Forms.GroupBox();
            this.LblResult = new System.Windows.Forms.Label();
            this.TxBxInputB = new System.Windows.Forms.TextBox();
            this.TxBxInputC = new System.Windows.Forms.TextBox();
            this.BtnDoSumOf2 = new System.Windows.Forms.Button();
            this.BtnDoDoubleNumeric = new System.Windows.Forms.Button();
            this.ErrProvA = new System.Windows.Forms.ErrorProvider(this.components);
            this.ErrProvB = new System.Windows.Forms.ErrorProvider(this.components);
            this.ErrProvC = new System.Windows.Forms.ErrorProvider(this.components);
            this.GrBxTaskButtons.SuspendLayout();
            this.GrBxInput.SuspendLayout();
            this.GrBxOutput.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ErrProvA)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ErrProvB)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ErrProvC)).BeginInit();
            this.SuspendLayout();
            // 
            // BtnExit
            // 
            this.BtnExit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BtnExit.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.BtnExit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnExit.Font = new System.Drawing.Font("Consolas", 10.11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BtnExit.ForeColor = System.Drawing.Color.White;
            this.BtnExit.Location = new System.Drawing.Point(970, 12);
            this.BtnExit.Name = "BtnExit";
            this.BtnExit.Size = new System.Drawing.Size(38, 30);
            this.BtnExit.TabIndex = 0;
            this.BtnExit.Text = "X";
            this.BtnExit.UseVisualStyleBackColor = true;
            this.BtnExit.Click += new System.EventHandler(this.BtnExit_Click);
            // 
            // GrBxTaskButtons
            // 
            this.GrBxTaskButtons.Controls.Add(this.BtnDoDoubleNumeric);
            this.GrBxTaskButtons.Controls.Add(this.BtnDoSumOf2);
            this.GrBxTaskButtons.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.GrBxTaskButtons.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.GrBxTaskButtons.ForeColor = System.Drawing.Color.White;
            this.GrBxTaskButtons.Location = new System.Drawing.Point(35, 390);
            this.GrBxTaskButtons.Name = "GrBxTaskButtons";
            this.GrBxTaskButtons.Size = new System.Drawing.Size(929, 149);
            this.GrBxTaskButtons.TabIndex = 2;
            this.GrBxTaskButtons.TabStop = false;
            this.GrBxTaskButtons.Text = " Меню ";
            // 
            // GrBxInput
            // 
            this.GrBxInput.Controls.Add(this.TxBxInputC);
            this.GrBxInput.Controls.Add(this.TxBxInputB);
            this.GrBxInput.Controls.Add(this.TxBxInputA);
            this.GrBxInput.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.GrBxInput.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.GrBxInput.ForeColor = System.Drawing.Color.White;
            this.GrBxInput.Location = new System.Drawing.Point(35, 28);
            this.GrBxInput.Name = "GrBxInput";
            this.GrBxInput.Size = new System.Drawing.Size(426, 356);
            this.GrBxInput.TabIndex = 3;
            this.GrBxInput.TabStop = false;
            this.GrBxInput.Text = " Исходные данные ";
            // 
            // TxBxInputA
            // 
            this.TxBxInputA.BackColor = System.Drawing.Color.Black;
            this.TxBxInputA.Font = new System.Drawing.Font("Century Gothic", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TxBxInputA.ForeColor = System.Drawing.Color.White;
            this.TxBxInputA.Location = new System.Drawing.Point(20, 62);
            this.TxBxInputA.Name = "TxBxInputA";
            this.TxBxInputA.Size = new System.Drawing.Size(383, 41);
            this.TxBxInputA.TabIndex = 0;
            this.TxBxInputA.Text = " A =";
            this.TxBxInputA.Click += new System.EventHandler(this.TxBxInputA_Click);
            // 
            // GrBxOutput
            // 
            this.GrBxOutput.Controls.Add(this.LblResult);
            this.GrBxOutput.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.GrBxOutput.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.GrBxOutput.ForeColor = System.Drawing.Color.White;
            this.GrBxOutput.Location = new System.Drawing.Point(479, 28);
            this.GrBxOutput.Name = "GrBxOutput";
            this.GrBxOutput.Size = new System.Drawing.Size(485, 356);
            this.GrBxOutput.TabIndex = 4;
            this.GrBxOutput.TabStop = false;
            this.GrBxOutput.Text = " Результат ";
            // 
            // LblResult
            // 
            this.LblResult.Dock = System.Windows.Forms.DockStyle.Fill;
            this.LblResult.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.LblResult.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblResult.Location = new System.Drawing.Point(3, 26);
            this.LblResult.Name = "LblResult";
            this.LblResult.Size = new System.Drawing.Size(479, 327);
            this.LblResult.TabIndex = 0;
            // 
            // TxBxInputB
            // 
            this.TxBxInputB.BackColor = System.Drawing.Color.Black;
            this.TxBxInputB.Font = new System.Drawing.Font("Century Gothic", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TxBxInputB.ForeColor = System.Drawing.Color.White;
            this.TxBxInputB.Location = new System.Drawing.Point(20, 156);
            this.TxBxInputB.Name = "TxBxInputB";
            this.TxBxInputB.Size = new System.Drawing.Size(383, 41);
            this.TxBxInputB.TabIndex = 1;
            this.TxBxInputB.Text = " B =";
            this.TxBxInputB.Click += new System.EventHandler(this.TxBxInputB_Click);
            // 
            // TxBxInputC
            // 
            this.TxBxInputC.BackColor = System.Drawing.Color.Black;
            this.TxBxInputC.Font = new System.Drawing.Font("Century Gothic", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TxBxInputC.ForeColor = System.Drawing.Color.White;
            this.TxBxInputC.Location = new System.Drawing.Point(20, 254);
            this.TxBxInputC.Name = "TxBxInputC";
            this.TxBxInputC.Size = new System.Drawing.Size(383, 41);
            this.TxBxInputC.TabIndex = 2;
            this.TxBxInputC.Text = " C =";
            this.TxBxInputC.Click += new System.EventHandler(this.TxBxInputC_Click);
            // 
            // BtnDoSumOf2
            // 
            this.BtnDoSumOf2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BtnDoSumOf2.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.BtnDoSumOf2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnDoSumOf2.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BtnDoSumOf2.ForeColor = System.Drawing.Color.White;
            this.BtnDoSumOf2.Location = new System.Drawing.Point(26, 28);
            this.BtnDoSumOf2.Name = "BtnDoSumOf2";
            this.BtnDoSumOf2.Size = new System.Drawing.Size(418, 92);
            this.BtnDoSumOf2.TabIndex = 0;
            this.BtnDoSumOf2.Text = "Cумма 2-ух наибольших";
            this.BtnDoSumOf2.UseVisualStyleBackColor = true;
            this.BtnDoSumOf2.Click += new System.EventHandler(this.BtnDoSumOf2_Click);
            // 
            // BtnDoDoubleNumeric
            // 
            this.BtnDoDoubleNumeric.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BtnDoDoubleNumeric.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.BtnDoDoubleNumeric.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnDoDoubleNumeric.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BtnDoDoubleNumeric.ForeColor = System.Drawing.Color.White;
            this.BtnDoDoubleNumeric.Location = new System.Drawing.Point(483, 28);
            this.BtnDoDoubleNumeric.Name = "BtnDoDoubleNumeric";
            this.BtnDoDoubleNumeric.Size = new System.Drawing.Size(418, 92);
            this.BtnDoDoubleNumeric.TabIndex = 1;
            this.BtnDoDoubleNumeric.Text = "Обработка трех чисел";
            this.BtnDoDoubleNumeric.UseVisualStyleBackColor = true;
            this.BtnDoDoubleNumeric.Click += new System.EventHandler(this.BtnDoDoubleNumeric_Click);
            // 
            // ErrProvA
            // 
            this.ErrProvA.BlinkStyle = System.Windows.Forms.ErrorBlinkStyle.NeverBlink;
            this.ErrProvA.ContainerControl = this;
            // 
            // ErrProvB
            // 
            this.ErrProvB.BlinkStyle = System.Windows.Forms.ErrorBlinkStyle.NeverBlink;
            this.ErrProvB.ContainerControl = this;
            // 
            // ErrProvC
            // 
            this.ErrProvC.BlinkStyle = System.Windows.Forms.ErrorBlinkStyle.NeverBlink;
            this.ErrProvC.ContainerControl = this;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.ClientSize = new System.Drawing.Size(1020, 579);
            this.Controls.Add(this.GrBxOutput);
            this.Controls.Add(this.GrBxInput);
            this.Controls.Add(this.GrBxTaskButtons);
            this.Controls.Add(this.BtnExit);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.GrBxTaskButtons.ResumeLayout(false);
            this.GrBxInput.ResumeLayout(false);
            this.GrBxInput.PerformLayout();
            this.GrBxOutput.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.ErrProvA)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ErrProvB)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ErrProvC)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button BtnExit;
        private System.Windows.Forms.GroupBox GrBxTaskButtons;
        private System.Windows.Forms.GroupBox GrBxInput;
        private System.Windows.Forms.TextBox TxBxInputA;
        private System.Windows.Forms.GroupBox GrBxOutput;
        private System.Windows.Forms.Label LblResult;
        private System.Windows.Forms.Button BtnDoSumOf2;
        private System.Windows.Forms.TextBox TxBxInputC;
        private System.Windows.Forms.TextBox TxBxInputB;
        private System.Windows.Forms.Button BtnDoDoubleNumeric;
        private System.Windows.Forms.ErrorProvider ErrProvA;
        private System.Windows.Forms.ErrorProvider ErrProvB;
        private System.Windows.Forms.ErrorProvider ErrProvC;
    }
}

