﻿using System;


namespace FirstHomework.Utilities
{
	public readonly struct Range<T>
		where T : unmanaged, IComparable<T>
	{
		public T Min { get; }
		public T Max { get; }
		public Func<T, T, T>? RandomFunc { get; init; }


		public Range(T min, T max)
		{
			Min = min;
			Max = max;
			RandomFunc = null;
		}


		public T RandomBetween => RandomFunc?.Invoke(Min, Max) ?? default;
	}
}