﻿using System;
using System.Drawing;


namespace Main.Utilities.TableFormatter
{


	public sealed class TableOptions
	{
		public Color ColorByPredicate { get; set; } = Palette.AccentDedicated;
		public Color DefaultColor { get; set; } = Palette.Default;
		public Point CursorPosition { get; set; } = new(Console.CursorLeft, Console.CursorTop);


		public void Update() => CursorPosition = new Point(Console.CursorLeft, Console.CursorTop);
	}


}
