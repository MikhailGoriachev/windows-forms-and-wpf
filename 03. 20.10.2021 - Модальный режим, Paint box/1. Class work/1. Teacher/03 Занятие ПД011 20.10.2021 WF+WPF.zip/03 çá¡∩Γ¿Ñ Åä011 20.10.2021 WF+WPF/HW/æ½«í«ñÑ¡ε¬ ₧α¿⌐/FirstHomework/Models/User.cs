﻿using System;
using Main.Utilities.Guards;
using Main.Utilities.TableFormatter;


namespace FirstHomework.Models
{
	public sealed class User
	{
		private int _id;


		[TableData("Идентификатор", "{0, -18}")]
		public int Id
		{
			get => _id;
			set => _id = Guard.Against.Negative(value, nameof(value));
		}


		public string Firstname { get; set; }


		public string Surname { get; set; }


		[TableData("Имя", "{0, -30}")]
		public string FullName => $"{Firstname} {Surname}";


		[TableData("Знак зодиака", "{0, -20}")]
		public string Zodiac { get; set; }


		[TableData("Дата рождения", "{0, -15:d}")]
		public DateTime BirthDate { get; set; }


		public int Age => DateTime.Now.Year - BirthDate.Year;
	}
}