﻿using System;
using System.Globalization;
using Main.Utilities;


namespace FirstHomework.Models
{
	public sealed class UserFactory
	{
		private static readonly GregorianCalendar Calendar = new();


		public int CreateId() => General.Rand.Next();


		public string CreateSurname() => new[]
		{
			"Холод", "Хорт", "Штефан", "Сокол", "Ежак", "Овчаренко",
			"Божко", "Фоменко", "Пиун", "Тищенко", "Рощенко", "Карпенко",
			"Полина", "Станислав", "Жувак", "Ващенко", "Величко", "Горбенко",
			"Ткач", "Иванченко", "Сорока", "Луговских", "Спасибо", "Добрый Вечер",
		}.Random();


		public string CreateFirstname() => new[]
		{
			"Мила", "Константин", "Арсений", "Нонна", "Филипп", "Павел",
			"Анна", "Арина", "Александр", "Илья", "Яна", "Эма",
			"Полина", "Станислав", "Егор", "Георгий", "Богдан", "Пётр",
			"Римма", "Катерина", "Валерия", "Екатерина", "Виталий", "Анна",
		}.Random();


		public string CreateZodiac() => new[]
		{
			"Овен", "Телец", "Близнецы", "Рак", "Лев", "Дева", "Весы",
			"Скорпион", "Стрелец", "Козерог", "Водолей", "Рыбы"
		}.Random();


		public DateTime CreateBirthDate()
		{
			int year = General.Rand.Next(1900, DateTime.Now.Year);
			int month = General.Rand.Next(1, Calendar.GetMonthsInYear(year) + 1);
			int day = General.Rand.Next(1, Calendar.GetDaysInMonth(year, month) + 1);

			return new DateTime(year, month, day);
		}


		public User CreateUser() => new()
		{
			Id = CreateId(),
			Firstname = CreateFirstname(),
			Surname = CreateSurname(),
			Zodiac = CreateZodiac(), BirthDate = CreateBirthDate()
		};
	}
}