﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.Linq;
using FirstHomework.Models;
using Main.Utilities.TableFormatter;


namespace FirstHomework
{
	public static class Controller
	{
		public static void OnCollectionChanged(object? sender, NotifyCollectionChangedEventArgs e)
		{
			Action<NotifyCollectionChangedEventArgs> react = e.Action switch
			{
				NotifyCollectionChangedAction.Add     => OnCollectionAdd,
				NotifyCollectionChangedAction.Remove  => OnCollectionRemove,
				NotifyCollectionChangedAction.Replace => OnCollectionUpdateAndReplace,
				_                                     => throw new ArgumentOutOfRangeException()
			};

			react.Invoke(e);
		}


		private static void OnCollectionAdd(NotifyCollectionChangedEventArgs e)
		{
			Console.WriteLine("Были добавлены следующие элементы:");

			new TableFormatter<User>().Show(e.NewItems.Cast<User>());
		}	


		private static void OnCollectionRemove(NotifyCollectionChangedEventArgs e)
		{
			Console.WriteLine("Были удалены следующие элементы:");

			new TableFormatter<User>().Show(e.OldItems.Cast<User>());
		} 


		private static void OnCollectionUpdateAndReplace(NotifyCollectionChangedEventArgs e)
		{
			Console.WriteLine("Были изменены следующие элементы:");

			new TableFormatter<User>().Show(e.NewItems.Cast<User>());
		}
	}
}