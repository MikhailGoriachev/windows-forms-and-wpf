﻿using System;
using System.Collections.ObjectModel;
using FirstHomework.Models;
using FirstHomework.Utilities;
using Main.Utilities;
using Main.Utilities.Menu;


namespace FirstHomework
{
	public sealed class App : MenuWrapper
	{
		private readonly Department _dep = new();


		public App() => Menu = new Menu("Главное меню приложения", new[]
		{
			new MenuItem("Начальное заполнение коллекции", Fill),
			new MenuItem("Вывод в консоль", Show),
			new MenuItem("Добавление трех рыб", AddFishes),
			new MenuItem("Удаление всех пользователей старше 60 лет", RemoveOldMans),
			new MenuItem("Добавить всем овенам в конец фамилии -бе-бе", ProcessAries),
			new MenuItem("Вывести в список и консоль записи с заданной фамилией", SelectWithSurname),
			new MenuItem("Вывести в список и консоль записи с заданным знаком Зодиака", SelectWithZodiac),
			new MenuItem("Вывести в список и консоль записи с заданным месяцем рождения", SelectWithBirthMonth),
			new MenuItem("Сортировка по дате рождения", OrderByBirthDate),
			new MenuItem("Сортировка по знаку Зодиака", OrderByZodiac),
			new MenuItem("Сортировка по фамилии, имени", OrderByFullname),
		});


		private static readonly UserFactory Factory = new();


		private void Show() => _dep.Show();


		private void Fill()
		{
			_dep.Fill(new Range<int>(20, 30)
			{
				RandomFunc = (min, max) => General.Rand.Next(min, max)
			});

			_dep.Show();
		}


		private void AddFishes()
		{
			_dep.CollectionChanged += Controller.OnCollectionChanged;

			for (int i = 0; i < 3; i++)
			{
				var user = Factory.CreateUser();
				user.Zodiac = "Рыбы";

				_dep.Add(user);
			}

			_dep.CollectionChanged -= Controller.OnCollectionChanged;
		}


		private void RemoveOldMans()
		{
			_dep.CollectionChanged += Controller.OnCollectionChanged;

			_dep.Remove(x => x.Age > 60);

			_dep.CollectionChanged -= Controller.OnCollectionChanged;
		}


		private void ProcessAries()
		{
			_dep.CollectionChanged += Controller.OnCollectionChanged;

			for (int i = 0; i < _dep.Count; i++)
			{
				var user = _dep[i];

				if (user.Zodiac != "Овен")
					continue;

				user.Surname += "-бе-бе";

				_dep[i] = user;
			}

			_dep.CollectionChanged -= Controller.OnCollectionChanged;
		}


		private void SelectWithSurname()
		{
			var surname = Factory.CreateSurname();

			var enumerable = _dep.SelectUsers(x =>
				string.Equals(x.Surname, surname, StringComparison.CurrentCulture));

			Console.WriteLine($"Фамилия для выборки: {surname}\n\n");
			_dep.Show(enumerable);
		}


		private void SelectWithZodiac()
		{
			var zodiac = Factory.CreateZodiac();

			var enumerable = _dep.SelectUsers(x =>
				string.Equals(x.Zodiac, zodiac, StringComparison.CurrentCulture));

			Console.WriteLine($"Знак зодиака для выборки: {zodiac}\n\n");
			_dep.Show(enumerable);
		}


		private void SelectWithBirthMonth()
		{
			var month = Factory.CreateBirthDate().Month;

			var enumerable = _dep.SelectUsers(x => x.BirthDate.Month == month);

			Console.WriteLine($"Месяц для выборки: {month}\n\n");
			_dep.Show(enumerable);
		}


		private void OrderAndShow<TKey>(Func<User, TKey> keySelector)
		{
			var enumerable = _dep.OrderBy(keySelector);

			_dep.Show(enumerable);
		}


		private void OrderByBirthDate() => OrderAndShow(x => x.BirthDate);

		private void OrderByZodiac() => OrderAndShow(x => x.Zodiac);

		private void OrderByFullname() => OrderAndShow(x => x.FullName);
	}
}