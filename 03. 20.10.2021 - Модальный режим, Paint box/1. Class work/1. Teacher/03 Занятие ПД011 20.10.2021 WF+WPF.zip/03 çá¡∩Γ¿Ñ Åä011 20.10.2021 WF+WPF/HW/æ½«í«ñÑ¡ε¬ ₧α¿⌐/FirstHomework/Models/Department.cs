﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.Linq;
using FirstHomework.Utilities;
using Main.Utilities;
using Main.Utilities.TableFormatter;


namespace FirstHomework.Models
{
	public sealed class Department : IEnumerable<User>
	{
		private ObservableCollection<User> _users = new();


		public User this[int index]
		{
			get => _users[index];
			set => _users[index] = value;
		}


		public event NotifyCollectionChangedEventHandler? CollectionChanged
		{
			add => _users.CollectionChanged += value;
			remove => _users.CollectionChanged -= value;
		}


		public void Show() => Show(_users);

		public void Show(IEnumerable<User> enumerable) => new TableFormatter<User>().Show(enumerable);

		public void Show(Predicate<User> match) => new TableFormatter<User>().Show(_users, match);


		public void Fill(Range<int> randomRange)
		{
			_users.Clear();

			UserFactory factory = new();

			_users.Fill(() => factory.CreateUser(), randomRange.RandomBetween);
		}


		public int Count => _users.Count;

		public void Add(User user) => _users.Add(user);


		public void Remove(int index) => _users.RemoveAt(index);


		public void Remove(Predicate<User> match)
		{
			for (int i = 0; i < _users.Count; i++)
			{
				if (match.Invoke(_users[i]))
				{
					_users.RemoveAt(i);
					i--;
				}
			}
		}


		public IEnumerable<User> SelectUsers(Predicate<User> match)
		{
			foreach (var user in _users)
			{
				if (match.Invoke(user))
					yield return user;
			}
		}


		public IEnumerable<User> OrderBy<TKey>(Func<User, TKey> keySelector) => _users.OrderBy(keySelector);


		public IEnumerator<User> GetEnumerator() => _users.GetEnumerator();

		IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
	}
}