﻿using System;
using System.ComponentModel;
using System.Windows.Forms;
using SecondHomework.Controllers;
using SecondHomework.Models;


namespace SecondHomework
{
	public sealed partial class MainForm : Form
	{
		private readonly Doubles _inputData = new();
		private readonly ITaskController _if15Controller = new If15Controller();
		private readonly ITaskController _if17Controller = new If17Controller();


		public MainForm()
		{
			InitializeComponent();

			// Привязываем свойство Text у TextBox к свойствам модели Doubles
			TextBoxForA.DataBindings.Add("Text", _inputData, "A");
			TextBoxForB.DataBindings.Add("Text", _inputData, "B");
			TextBoxForC.DataBindings.Add("Text", _inputData, "C");
		}


		// Валидация для TextBox'ов в которые вводятся данные
		private void TextBox_Validating(object sender, CancelEventArgs e)
		{
			var senderAsTextBox = sender as TextBox;

			// Если введенные данные являются double
			if (double.TryParse(senderAsTextBox.Text, out double _))
			{
				// Уберем признак ошибки (если он уже установлен)
				MainErrorProvider.SetError(senderAsTextBox, null);
				return;
			}

			// Установим ошибку для текущего TextBox
			MainErrorProvider.SetError(senderAsTextBox, "Введено не вещественное число");
			// Сигнализируем о том что валидация провалена
			e.Cancel = true;
		}


		private void SolutionForIf15_Click(object sender, EventArgs e) =>
			OutputForIf15.Text = _if15Controller.Resolve(_inputData);


		private void InfoForIf15_Click(object sender, EventArgs e) =>
			OutputForIf15.Text = _if15Controller.Description;


		private void SolutionForIf17_Click(object sender, EventArgs e) =>
			OutputForIf17.Text = _if17Controller.Resolve(_inputData);


		private void InfoForIf17_Click(object sender, EventArgs e) =>
			OutputForIf17.Text = _if17Controller.Description;
	}
}