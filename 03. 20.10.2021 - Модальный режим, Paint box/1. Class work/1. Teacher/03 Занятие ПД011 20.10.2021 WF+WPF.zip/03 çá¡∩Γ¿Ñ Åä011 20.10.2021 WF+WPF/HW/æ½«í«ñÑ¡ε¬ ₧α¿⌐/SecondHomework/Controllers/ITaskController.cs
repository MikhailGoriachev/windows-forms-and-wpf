﻿using SecondHomework.Models;


namespace SecondHomework.Controllers
{
	// Интерфейс для обработчиков заданий
	public interface ITaskController
	{
		// Описание задания
		public string Description { get; }

		// Решение задания
		string Resolve(Doubles data);
	}
}
