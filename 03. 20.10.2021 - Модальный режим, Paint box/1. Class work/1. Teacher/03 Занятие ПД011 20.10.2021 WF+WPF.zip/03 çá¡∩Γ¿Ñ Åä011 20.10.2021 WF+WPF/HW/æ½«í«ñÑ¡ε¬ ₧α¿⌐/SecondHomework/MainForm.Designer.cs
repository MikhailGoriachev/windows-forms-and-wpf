﻿
namespace SecondHomework
{
	sealed partial class MainForm
	{
		/// <summary>
		///  Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		///  Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		///  Required method for Designer support - do not modify
		///  the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
			this.InputDataGroupBox = new System.Windows.Forms.GroupBox();
			this.TextBoxForC = new System.Windows.Forms.TextBox();
			this.LabelForC = new System.Windows.Forms.Label();
			this.TextBoxForB = new System.Windows.Forms.TextBox();
			this.LabelForB = new System.Windows.Forms.Label();
			this.TextBoxForA = new System.Windows.Forms.TextBox();
			this.LabelForA = new System.Windows.Forms.Label();
			this.MainErrorProvider = new System.Windows.Forms.ErrorProvider(this.components);
			this.If15GroupBox = new System.Windows.Forms.GroupBox();
			this.OutputForIf15 = new System.Windows.Forms.TextBox();
			this.LabelForIf15 = new System.Windows.Forms.Label();
			this.SolutionForIf15 = new System.Windows.Forms.Button();
			this.InfoForIf15 = new System.Windows.Forms.Button();
			this.If17GroupBox = new System.Windows.Forms.GroupBox();
			this.OutputForIf17 = new System.Windows.Forms.TextBox();
			this.LabelForIf17 = new System.Windows.Forms.Label();
			this.SolutionForIf17 = new System.Windows.Forms.Button();
			this.InfoForIf17 = new System.Windows.Forms.Button();
			this.InputDataGroupBox.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.MainErrorProvider)).BeginInit();
			this.If15GroupBox.SuspendLayout();
			this.If17GroupBox.SuspendLayout();
			this.SuspendLayout();
			// 
			// InputDataGroupBox
			// 
			this.InputDataGroupBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
			this.InputDataGroupBox.Controls.Add(this.TextBoxForC);
			this.InputDataGroupBox.Controls.Add(this.LabelForC);
			this.InputDataGroupBox.Controls.Add(this.TextBoxForB);
			this.InputDataGroupBox.Controls.Add(this.LabelForB);
			this.InputDataGroupBox.Controls.Add(this.TextBoxForA);
			this.InputDataGroupBox.Controls.Add(this.LabelForA);
			this.InputDataGroupBox.Location = new System.Drawing.Point(24, 24);
			this.InputDataGroupBox.MinimumSize = new System.Drawing.Size(298, 192);
			this.InputDataGroupBox.Name = "InputDataGroupBox";
			this.InputDataGroupBox.Size = new System.Drawing.Size(298, 424);
			this.InputDataGroupBox.TabIndex = 0;
			this.InputDataGroupBox.TabStop = false;
			this.InputDataGroupBox.Text = "Ввод Данных";
			// 
			// TextBoxForC
			// 
			this.TextBoxForC.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.TextBoxForC.BackColor = System.Drawing.Color.White;
			this.TextBoxForC.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(33)))), ((int)(((byte)(45)))));
			this.TextBoxForC.Location = new System.Drawing.Point(56, 340);
			this.TextBoxForC.Name = "TextBoxForC";
			this.TextBoxForC.Size = new System.Drawing.Size(226, 27);
			this.TextBoxForC.TabIndex = 3;
			this.TextBoxForC.Validating += new System.ComponentModel.CancelEventHandler(this.TextBox_Validating);
			// 
			// LabelForC
			// 
			this.LabelForC.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.LabelForC.AutoSize = true;
			this.LabelForC.Location = new System.Drawing.Point(16, 343);
			this.LabelForC.Name = "LabelForC";
			this.LabelForC.Size = new System.Drawing.Size(21, 20);
			this.LabelForC.TabIndex = 4;
			this.LabelForC.Text = "C:";
			// 
			// TextBoxForB
			// 
			this.TextBoxForB.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
			this.TextBoxForB.BackColor = System.Drawing.Color.White;
			this.TextBoxForB.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(33)))), ((int)(((byte)(45)))));
			this.TextBoxForB.Location = new System.Drawing.Point(56, 197);
			this.TextBoxForB.Name = "TextBoxForB";
			this.TextBoxForB.Size = new System.Drawing.Size(226, 27);
			this.TextBoxForB.TabIndex = 2;
			this.TextBoxForB.Validating += new System.ComponentModel.CancelEventHandler(this.TextBox_Validating);
			// 
			// LabelForB
			// 
			this.LabelForB.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
			this.LabelForB.AutoSize = true;
			this.LabelForB.Location = new System.Drawing.Point(16, 200);
			this.LabelForB.Name = "LabelForB";
			this.LabelForB.Size = new System.Drawing.Size(21, 20);
			this.LabelForB.TabIndex = 2;
			this.LabelForB.Text = "B:";
			// 
			// TextBoxForA
			// 
			this.TextBoxForA.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.TextBoxForA.BackColor = System.Drawing.Color.White;
			this.TextBoxForA.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(33)))), ((int)(((byte)(45)))));
			this.TextBoxForA.Location = new System.Drawing.Point(56, 40);
			this.TextBoxForA.Name = "TextBoxForA";
			this.TextBoxForA.Size = new System.Drawing.Size(226, 27);
			this.TextBoxForA.TabIndex = 1;
			this.TextBoxForA.Validating += new System.ComponentModel.CancelEventHandler(this.TextBox_Validating);
			// 
			// LabelForA
			// 
			this.LabelForA.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.LabelForA.AutoSize = true;
			this.LabelForA.Location = new System.Drawing.Point(16, 43);
			this.LabelForA.Name = "LabelForA";
			this.LabelForA.Size = new System.Drawing.Size(22, 20);
			this.LabelForA.TabIndex = 0;
			this.LabelForA.Text = "A:";
			// 
			// MainErrorProvider
			// 
			this.MainErrorProvider.BlinkStyle = System.Windows.Forms.ErrorBlinkStyle.AlwaysBlink;
			this.MainErrorProvider.ContainerControl = this;
			this.MainErrorProvider.RightToLeft = true;
			// 
			// If15GroupBox
			// 
			this.If15GroupBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.If15GroupBox.Controls.Add(this.OutputForIf15);
			this.If15GroupBox.Controls.Add(this.LabelForIf15);
			this.If15GroupBox.Controls.Add(this.SolutionForIf15);
			this.If15GroupBox.Controls.Add(this.InfoForIf15);
			this.If15GroupBox.Location = new System.Drawing.Point(344, 32);
			this.If15GroupBox.Name = "If15GroupBox";
			this.If15GroupBox.Size = new System.Drawing.Size(472, 193);
			this.If15GroupBox.TabIndex = 1;
			this.If15GroupBox.TabStop = false;
			this.If15GroupBox.Text = "Задача. If15 ";
			// 
			// OutputForIf15
			// 
			this.OutputForIf15.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.OutputForIf15.BackColor = System.Drawing.Color.White;
			this.OutputForIf15.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(33)))), ((int)(((byte)(45)))));
			this.OutputForIf15.Location = new System.Drawing.Point(16, 88);
			this.OutputForIf15.Multiline = true;
			this.OutputForIf15.Name = "OutputForIf15";
			this.OutputForIf15.ReadOnly = true;
			this.OutputForIf15.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
			this.OutputForIf15.Size = new System.Drawing.Size(440, 88);
			this.OutputForIf15.TabIndex = 5;
			// 
			// LabelForIf15
			// 
			this.LabelForIf15.Anchor = System.Windows.Forms.AnchorStyles.Top;
			this.LabelForIf15.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
			this.LabelForIf15.Location = new System.Drawing.Point(211, 41);
			this.LabelForIf15.Name = "LabelForIf15";
			this.LabelForIf15.Size = new System.Drawing.Size(48, 30);
			this.LabelForIf15.TabIndex = 3;
			this.LabelForIf15.Text = "If15";
			this.LabelForIf15.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
			// 
			// SolutionForIf15
			// 
			this.SolutionForIf15.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.SolutionForIf15.Location = new System.Drawing.Point(368, 40);
			this.SolutionForIf15.Name = "SolutionForIf15";
			this.SolutionForIf15.Size = new System.Drawing.Size(88, 33);
			this.SolutionForIf15.TabIndex = 0;
			this.SolutionForIf15.Text = "Решить";
			this.SolutionForIf15.UseVisualStyleBackColor = true;
			this.SolutionForIf15.Click += new System.EventHandler(this.SolutionForIf15_Click);
			// 
			// InfoForIf15
			// 
			this.InfoForIf15.Location = new System.Drawing.Point(16, 40);
			this.InfoForIf15.Name = "InfoForIf15";
			this.InfoForIf15.Size = new System.Drawing.Size(88, 33);
			this.InfoForIf15.TabIndex = 1;
			this.InfoForIf15.Text = "Описание";
			this.InfoForIf15.UseVisualStyleBackColor = true;
			this.InfoForIf15.Click += new System.EventHandler(this.InfoForIf15_Click);
			// 
			// If17GroupBox
			// 
			this.If17GroupBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.If17GroupBox.Controls.Add(this.OutputForIf17);
			this.If17GroupBox.Controls.Add(this.LabelForIf17);
			this.If17GroupBox.Controls.Add(this.SolutionForIf17);
			this.If17GroupBox.Controls.Add(this.InfoForIf17);
			this.If17GroupBox.Location = new System.Drawing.Point(344, 256);
			this.If17GroupBox.Name = "If17GroupBox";
			this.If17GroupBox.Size = new System.Drawing.Size(472, 193);
			this.If17GroupBox.TabIndex = 4;
			this.If17GroupBox.TabStop = false;
			this.If17GroupBox.Text = "Задача. If17";
			// 
			// OutputForIf17
			// 
			this.OutputForIf17.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.OutputForIf17.BackColor = System.Drawing.Color.White;
			this.OutputForIf17.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(33)))), ((int)(((byte)(45)))));
			this.OutputForIf17.Location = new System.Drawing.Point(16, 88);
			this.OutputForIf17.Multiline = true;
			this.OutputForIf17.Name = "OutputForIf17";
			this.OutputForIf17.ReadOnly = true;
			this.OutputForIf17.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
			this.OutputForIf17.Size = new System.Drawing.Size(440, 88);
			this.OutputForIf17.TabIndex = 4;
			// 
			// LabelForIf17
			// 
			this.LabelForIf17.Anchor = System.Windows.Forms.AnchorStyles.Top;
			this.LabelForIf17.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
			this.LabelForIf17.Location = new System.Drawing.Point(216, 40);
			this.LabelForIf17.Name = "LabelForIf17";
			this.LabelForIf17.Size = new System.Drawing.Size(48, 32);
			this.LabelForIf17.TabIndex = 3;
			this.LabelForIf17.Text = "If17";
			this.LabelForIf17.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
			// 
			// SolutionForIf17
			// 
			this.SolutionForIf17.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.SolutionForIf17.Location = new System.Drawing.Point(368, 40);
			this.SolutionForIf17.Name = "SolutionForIf17";
			this.SolutionForIf17.Size = new System.Drawing.Size(88, 32);
			this.SolutionForIf17.TabIndex = 0;
			this.SolutionForIf17.Text = "Решить";
			this.SolutionForIf17.UseVisualStyleBackColor = true;
			this.SolutionForIf17.Click += new System.EventHandler(this.SolutionForIf17_Click);
			// 
			// InfoForIf17
			// 
			this.InfoForIf17.Location = new System.Drawing.Point(16, 40);
			this.InfoForIf17.Name = "InfoForIf17";
			this.InfoForIf17.Size = new System.Drawing.Size(88, 32);
			this.InfoForIf17.TabIndex = 1;
			this.InfoForIf17.Text = "Описание";
			this.InfoForIf17.UseVisualStyleBackColor = true;
			this.InfoForIf17.Click += new System.EventHandler(this.InfoForIf17_Click);
			// 
			// MainForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
			this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(243)))), ((int)(((byte)(224)))));
			this.ClientSize = new System.Drawing.Size(835, 475);
			this.Controls.Add(this.If17GroupBox);
			this.Controls.Add(this.If15GroupBox);
			this.Controls.Add(this.InputDataGroupBox);
			this.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
			this.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(33)))), ((int)(((byte)(45)))));
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.MinimumSize = new System.Drawing.Size(851, 514);
			this.Name = "MainForm";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Задание на 20.10.2021";
			this.InputDataGroupBox.ResumeLayout(false);
			this.InputDataGroupBox.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.MainErrorProvider)).EndInit();
			this.If15GroupBox.ResumeLayout(false);
			this.If15GroupBox.PerformLayout();
			this.If17GroupBox.ResumeLayout(false);
			this.If17GroupBox.PerformLayout();
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.GroupBox InputDataGroupBox;
		private System.Windows.Forms.TextBox TextBoxForA;
		private System.Windows.Forms.Label LabelForA;
		private System.Windows.Forms.ErrorProvider MainErrorProvider;
		private System.Windows.Forms.TextBox TextBoxForC;
		private System.Windows.Forms.Label LabelForC;
		private System.Windows.Forms.TextBox TextBoxForB;
		private System.Windows.Forms.Label LabelForB;
		private System.Windows.Forms.GroupBox If15GroupBox;
		private System.Windows.Forms.Button SolutionForIf15;
		private System.Windows.Forms.Button InfoForIf15;
		private System.Windows.Forms.Label LabelForIf15;
		private System.Windows.Forms.GroupBox If17GroupBox;
		private System.Windows.Forms.Label LabelForIf17;
		private System.Windows.Forms.Button SolutionForIf17;
		private System.Windows.Forms.Button InfoForIf17;
		private System.Windows.Forms.TextBox OutputForIf17;
		private System.Windows.Forms.TextBox OutputForIf15;
	}
}

