﻿namespace SecondHomework.Models
{
	public sealed class Doubles
	{
		public double A { get; set; }
		public double B { get; set; }
		public double C { get; set; }


		public double[] ToArray() => new[] { A, B, C };
	}
}