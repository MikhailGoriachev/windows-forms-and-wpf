﻿using System;
using System.Collections.Generic;
using System.Text;
using SecondHomework.Models;


namespace SecondHomework.Controllers
{
	public sealed class If17Controller : ITaskController
	{
		public string Description =>
			"Даны три переменные вещественного типа: A, B, C. " +
			"Если их значения упорядочены по возрастанию или убыванию, то удвоить их; " +
			"в противном случае заменить значение каждой переменной на противоположное. " +
			"Вывести новые значения переменных A, B, C.";


		public string Resolve(Doubles data)
		{
			// Получим данные в виде массива
			var array = data.ToArray();

			// Итоговая строка
			StringBuilder sb = new();

			// Выберем способ изменения массива исходя из условий
			var selectBy = ChooseSelection(array, sb);
			// Получим перечислитель новых элементов
			var selected = SelectInNewArray(array, selectBy);

			// Запишем новые элеметы в строку и вернем её
			return WriteArrayToStringBuilder(selected, sb)
				.ToString();
		}


		/// <summary>
		///		Выбор метода для изменения массива исходя из условий
		/// </summary>
		/// <param name="array">Массив для изменения</param>
		/// <param name="sb">Строка для записи соответствующего условия</param>
		/// <returns>Делегат который выбирает элементы из коллекции</returns>
		private static Func<double, double> ChooseSelection(double[] array, StringBuilder sb)
		{
			Func<double, double> select;

			// Если массив как-то отсортирован - умонажем каждый элемент на 2
			if (IsOrderedAscending(array) || IsOrderedDescending(array))
			{
				sb.AppendLine("Массив упорядочен, будет выполнено удвоение каждого элемента");
				select = x => x * 2;
			}
			// Иначе меняем знак каждому элементу
			else
			{
				sb.AppendLine("Массив не упорядочен, у каждого элемента будет изменен знак");
				select = x => -x;
			}

			return select;
		}


		/// <summary>
		///		Запись массива в строку
		/// </summary>
		/// <param name="enumerable">Перечислитель для записи</param>
		/// <param name="sb">Выходная строка</param>
		/// <returns>Тот же StringBuilder, с записанным масивом</returns>
		private static StringBuilder WriteArrayToStringBuilder(IEnumerable<double> enumerable, StringBuilder sb)
		{
			foreach (var x in enumerable)
				sb.Append($"{x,8:F}");

			return sb;
		}


		/// <summary>
		///		Выборка элементов из массива
		/// </summary>
		/// <param name="source">Массив с данными</param>
		/// <param name="select">Делегат для выбора элемента</param>
		/// <returns>Перечислитель новых элементов</returns>
		public static IEnumerable<double> SelectInNewArray(double[] source, Func<double, double> select)
		{
			for (var i = 0; i < source.Length; i++)
				yield return select.Invoke(source[i]);
		}


		/// <summary>
		///		Проверка на отсортированность массива
		/// </summary>
		/// <param name="values">Массив для проверки</param>
		/// <returns>Отсортирован ли массив по возрастанию</returns>
		private static bool IsOrderedAscending(double[] values) => IsOrdered(values, (lhs, rhs) => lhs < rhs);

		/// <summary>
		///		Проверка на отсортированность массива
		/// </summary>
		/// <param name="values">Массив для проверки</param>
		/// <returns>Отсортирован ли массив по убыванию</returns>
		private static bool IsOrderedDescending(double[] values) => IsOrdered(values, (lhs, rhs) => lhs > rhs);


		/// <summary>
		///		Проверка на отсортированность массива
		/// </summary>
		/// <param name="values">Массив для проверки</param>
		/// <param name="comparer">Компаратор для сравнения элементов</param>
		/// <returns>Отсортирован ли массив</returns>
		private static bool IsOrdered(double[] values, Func<double, double, bool> comparer)
		{
			// Элементы для сравнения
			double lhs = values[0], rhs;

			for (var i = 1; i < values.Length; i++)
			{
				// Записываем текущее число
				rhs = values[i];

				// Если элементы не отсортированы - уходим
				if (!comparer.Invoke(lhs, rhs))
					return false;

				// Меняем элементы местами (в начале цикла установим rhs)
				lhs = rhs;
			}

			// Массив отсортирован
			return true;
		}
	}
}