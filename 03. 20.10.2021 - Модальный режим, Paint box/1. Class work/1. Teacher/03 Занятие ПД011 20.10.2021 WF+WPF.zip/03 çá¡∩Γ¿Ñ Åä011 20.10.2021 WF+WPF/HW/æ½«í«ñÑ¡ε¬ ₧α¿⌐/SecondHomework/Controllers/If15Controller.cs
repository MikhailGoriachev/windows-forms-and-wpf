﻿using System;
using SecondHomework.Models;


namespace SecondHomework.Controllers
{
	public sealed class If15Controller : ITaskController
	{
		private static readonly Comparison<double> Comparer = (lhs, rhs) => rhs.CompareTo(lhs);


		public string Description =>
			"Даны три переменные вещественного типа. Найти сумму двух наибольших из них (т.е. для чисел 1, 2, 3 сумма будет равна 5)";


		public string Resolve(Doubles data)
		{
			var array = data.ToArray();

			Array.Sort(array, Comparer);

			return $"Ответ: {array[0] + array[1]}";

			// Более красивое решение, но LINQ :(
			// return $"{array.Take(2).Sum()}";
		}
	}
}