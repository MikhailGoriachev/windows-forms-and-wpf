﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
/*
 * Задача 2.
 * Разработайте приложение Windows Forms, состоящее из одной формы, используйте
 * TextBox, Button, ErrorProvider, Label, GroupBox.
 * Не советую применять еще не изученные возможности 😊
 * Приложение должно организовать ввод данных и обработку по командным кнопкам
 * Button (т.е. в событии Click кнопок, пока без модели) следующих задач.
 *
 *     If15. Даны три переменные вещественного типа. Найти сумму двух
 *           наибольших из них (т.е. для чисел 1, 2, 3 сумма будет равна 5).
 *
 *     If17. Даны три переменные вещественного типа: A, B, C. Если их значения
 *           упорядочены по возрастанию или убыванию, то удвоить их;
 *           в противном случае заменить значение каждой переменной на
 *           противоположное. Вывести новые значения переменных A, B, C.
 *
 * Предусмотрите кнопку завершения работы приложения.
 *
 */
namespace TextBoxesErrorProviders
{
    internal static class Program
    {
        /// <summary>
        /// Главная точка входа для приложения.
        /// </summary>
        [STAThread]
        static void Main() {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new MainForm());
        }
    }
}
