﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TextBoxesErrorProviders
{
    public partial class MainForm : Form
    {
        // конструктор по умолчанию, сгенерированный средой
        public MainForm() {
            InitializeComponent();
        } // MainForm

        // выход из приложения
        private void BtnQuit_Click(object sender, EventArgs e) => Close();


        // If15. Даны три переменные вещественного типа. Найти сумму двух
        // наибольших из них (т.е.для чисел 1, 2, 3 сумма будет равна 5).
        private void BtnIf15_Click(object sender, EventArgs e) {
            double sum;

            // проверка корректности ввода данных - число A 
            bool result = double.TryParse(TbxFirstNumber.Text, out double a);
            if (!result) {
                // данные не корректны - активировать ErrorProvider 
                // на элементе, в котором возникла ошибка
                ErpNumberA.SetError(TbxFirstNumber, "Недопустимый формат");
            } else {
                // данные корректны - деактивировать ErrorProvider
                // на этом элементе ввода
                ErpNumberA.SetError(TbxFirstNumber, "");
            } // if

            // аналогичный ввод и проверка для числа B
            result = double.TryParse(TbxSecndNumber.Text, out double b);
            ErpNumberB.SetError(TbxSecndNumber, !result ? "Недопустимый формат" : "");

            // аналогичный ввод и проверка для числа C
            result = double.TryParse(TbxThirdNumber.Text, out double c);
            ErpNumberC.SetError(TbxThirdNumber, !result ? "Недопустимый формат" : "");

            // обработка по заданию - ищем минимальное значение
            // для трех чисел A, B, C и суммируем два оставшихся
            if (a < b && a < c)
                sum = b + c;
            else if (b < c)
                sum = a + c;
            else
                sum = a + b;

            // вывод результата
            LblResult.Text = $"Из трех чисел {a:f3}; {b:f3}; {c:f3}\nсумма двух наибольших\n{sum:f3}";
        } // BtnIf15_Click


        // при начале ввода данных в поле ввода числа A убираем 
        // признак ошибки для ErrorProvider
        private void TbxFirstNumber_TextChanged(object sender, EventArgs e) =>
            ErpNumberA.SetError(TbxFirstNumber, "");


        // при начале ввода данных в поле ввода числа B убираем 
        // признак ошибки для ErrorProvider
        private void TbxSecndNumber_TextChanged(object sender, EventArgs e) =>
            ErpNumberB.SetError(TbxSecndNumber, "");

        // при начале ввода данных в поле ввода числа С убираем 
        // признак ошибки для ErrorProvider
        private void TbxThirdNumber_TextChanged(object sender, EventArgs e) =>
            ErpNumberC.SetError(TbxThirdNumber, "");


        // If17.
        // Даны три переменные вещественного типа: A, B, C. Если их значения
        // упорядочены по возрастанию или убыванию, то удвоить их; в противном
        // случае заменить значение каждой переменной на противоположное.
        // Вывести новые значения переменных A, B, C.
        private void BtnIf17_Click(object sender, EventArgs e) {

            // проверка корректности ввода данных - число A 
            bool result = double.TryParse(TbxFirstNumber.Text, out double a);
            ErpNumberA.SetError(TbxFirstNumber, !result ? "Недопустимый формат" : "");

            // аналогичный ввод и проверка для числа B
            result = double.TryParse(TbxSecndNumber.Text, out double b);
            ErpNumberB.SetError(TbxSecndNumber, !result ? "Недопустимый формат" : "");

            // аналогичный ввод и проверка для числа C
            result = double.TryParse(TbxThirdNumber.Text, out double c);
            ErpNumberC.SetError(TbxThirdNumber, !result ? "Недопустимый формат" : "");

            // Вывод исходных данных в StringBuilder
            StringBuilder sb = new StringBuilder("Исходные данные:\n");
            sb.Append($"{a:f3}; {b:f3}; {c:f3}\n");

            // обработка по заданию - проверка на упорядоченность и обработка
            // для трех чисел A, B, C: удвоение упорядоченных по убыванию или
            // возрастанию, замена на противопололжные значения, если числаъ
            // не упорядочены
            if (a > b && b > c || a < b && b < c) {
                a += a;
                b += b;
                c += c;
            } else {
                a = -a;
                b = -b;
                c = -c;
            } // if

            // вывод результата в StringBuilder
            sb.Append($"\nПосле обработки:\n{a:f3}; {b:f3}; {c:f3}\n");

            // вывод результата в label
            LblResult.Text = sb.ToString();
        } // BtnIf17_Click
    } // class MainForm
}
