﻿namespace TextBoxesErrorProviders
{
    partial class MainForm
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent() {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.BtnQuit = new System.Windows.Forms.Button();
            this.BtnIf17 = new System.Windows.Forms.Button();
            this.BtnIf15 = new System.Windows.Forms.Button();
            this.GrbResult = new System.Windows.Forms.GroupBox();
            this.LblResult = new System.Windows.Forms.Label();
            this.GrbInputData = new System.Windows.Forms.GroupBox();
            this.TbxThirdNumber = new System.Windows.Forms.TextBox();
            this.LblThirdNumber = new System.Windows.Forms.Label();
            this.TbxSecndNumber = new System.Windows.Forms.TextBox();
            this.LblSecndNumber = new System.Windows.Forms.Label();
            this.TbxFirstNumber = new System.Windows.Forms.TextBox();
            this.LblFirstNumber = new System.Windows.Forms.Label();
            this.ErpNumberA = new System.Windows.Forms.ErrorProvider(this.components);
            this.ErpNumberB = new System.Windows.Forms.ErrorProvider(this.components);
            this.ErpNumberC = new System.Windows.Forms.ErrorProvider(this.components);
            this.GrbResult.SuspendLayout();
            this.GrbInputData.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ErpNumberA)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ErpNumberB)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ErpNumberC)).BeginInit();
            this.SuspendLayout();
            // 
            // BtnQuit
            // 
            this.BtnQuit.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BtnQuit.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnQuit.Location = new System.Drawing.Point(710, 351);
            this.BtnQuit.Name = "BtnQuit";
            this.BtnQuit.Size = new System.Drawing.Size(75, 65);
            this.BtnQuit.TabIndex = 9;
            this.BtnQuit.UseVisualStyleBackColor = true;
            this.BtnQuit.Click += new System.EventHandler(this.BtnQuit_Click);
            // 
            // BtnIf17
            // 
            this.BtnIf17.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BtnIf17.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnIf17.Location = new System.Drawing.Point(366, 351);
            this.BtnIf17.Name = "BtnIf17";
            this.BtnIf17.Size = new System.Drawing.Size(322, 65);
            this.BtnIf17.TabIndex = 8;
            this.BtnIf17.Text = "If17. Проверка на сортировку";
            this.BtnIf17.UseVisualStyleBackColor = true;
            this.BtnIf17.Click += new System.EventHandler(this.BtnIf17_Click);
            // 
            // BtnIf15
            // 
            this.BtnIf15.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BtnIf15.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnIf15.Location = new System.Drawing.Point(15, 351);
            this.BtnIf15.Name = "BtnIf15";
            this.BtnIf15.Size = new System.Drawing.Size(322, 65);
            this.BtnIf15.TabIndex = 7;
            this.BtnIf15.Text = "If15. Сумма двух наибольших";
            this.BtnIf15.UseVisualStyleBackColor = true;
            this.BtnIf15.Click += new System.EventHandler(this.BtnIf15_Click);
            // 
            // GrbResult
            // 
            this.GrbResult.Controls.Add(this.LblResult);
            this.GrbResult.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.GrbResult.Location = new System.Drawing.Point(435, 35);
            this.GrbResult.Name = "GrbResult";
            this.GrbResult.Size = new System.Drawing.Size(350, 278);
            this.GrbResult.TabIndex = 6;
            this.GrbResult.TabStop = false;
            this.GrbResult.Text = " Результат: ";
            // 
            // LblResult
            // 
            this.LblResult.BackColor = System.Drawing.Color.Honeydew;
            this.LblResult.Dock = System.Windows.Forms.DockStyle.Fill;
            this.LblResult.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblResult.Location = new System.Drawing.Point(3, 23);
            this.LblResult.Name = "LblResult";
            this.LblResult.Size = new System.Drawing.Size(344, 252);
            this.LblResult.TabIndex = 0;
            this.LblResult.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // GrbInputData
            // 
            this.GrbInputData.Controls.Add(this.TbxThirdNumber);
            this.GrbInputData.Controls.Add(this.LblThirdNumber);
            this.GrbInputData.Controls.Add(this.TbxSecndNumber);
            this.GrbInputData.Controls.Add(this.LblSecndNumber);
            this.GrbInputData.Controls.Add(this.TbxFirstNumber);
            this.GrbInputData.Controls.Add(this.LblFirstNumber);
            this.GrbInputData.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.GrbInputData.Location = new System.Drawing.Point(15, 35);
            this.GrbInputData.Name = "GrbInputData";
            this.GrbInputData.Size = new System.Drawing.Size(401, 278);
            this.GrbInputData.TabIndex = 5;
            this.GrbInputData.TabStop = false;
            this.GrbInputData.Text = " Исходные данные: ";
            // 
            // TbxThirdNumber
            // 
            this.TbxThirdNumber.Location = new System.Drawing.Point(18, 212);
            this.TbxThirdNumber.Name = "TbxThirdNumber";
            this.TbxThirdNumber.Size = new System.Drawing.Size(364, 27);
            this.TbxThirdNumber.TabIndex = 5;
            this.TbxThirdNumber.Text = "0";
            this.TbxThirdNumber.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.TbxThirdNumber.TextChanged += new System.EventHandler(this.TbxThirdNumber_TextChanged);
            // 
            // LblThirdNumber
            // 
            this.LblThirdNumber.AutoSize = true;
            this.LblThirdNumber.Location = new System.Drawing.Point(18, 190);
            this.LblThirdNumber.Name = "LblThirdNumber";
            this.LblThirdNumber.Size = new System.Drawing.Size(126, 18);
            this.LblThirdNumber.TabIndex = 4;
            this.LblThirdNumber.Text = "Третье число:";
            // 
            // TbxSecndNumber
            // 
            this.TbxSecndNumber.Location = new System.Drawing.Point(15, 142);
            this.TbxSecndNumber.Name = "TbxSecndNumber";
            this.TbxSecndNumber.Size = new System.Drawing.Size(364, 27);
            this.TbxSecndNumber.TabIndex = 3;
            this.TbxSecndNumber.Text = "0";
            this.TbxSecndNumber.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.TbxSecndNumber.TextChanged += new System.EventHandler(this.TbxSecndNumber_TextChanged);
            // 
            // LblSecndNumber
            // 
            this.LblSecndNumber.AutoSize = true;
            this.LblSecndNumber.Location = new System.Drawing.Point(15, 120);
            this.LblSecndNumber.Name = "LblSecndNumber";
            this.LblSecndNumber.Size = new System.Drawing.Size(128, 18);
            this.LblSecndNumber.TabIndex = 2;
            this.LblSecndNumber.Text = "Второе число:";
            // 
            // TbxFirstNumber
            // 
            this.TbxFirstNumber.Location = new System.Drawing.Point(18, 69);
            this.TbxFirstNumber.Name = "TbxFirstNumber";
            this.TbxFirstNumber.Size = new System.Drawing.Size(364, 27);
            this.TbxFirstNumber.TabIndex = 1;
            this.TbxFirstNumber.Text = "0";
            this.TbxFirstNumber.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.TbxFirstNumber.TextChanged += new System.EventHandler(this.TbxFirstNumber_TextChanged);
            // 
            // LblFirstNumber
            // 
            this.LblFirstNumber.AutoSize = true;
            this.LblFirstNumber.Location = new System.Drawing.Point(18, 47);
            this.LblFirstNumber.Name = "LblFirstNumber";
            this.LblFirstNumber.Size = new System.Drawing.Size(132, 18);
            this.LblFirstNumber.TabIndex = 0;
            this.LblFirstNumber.Text = "Первое число:";
            // 
            // ErpNumberA
            // 
            this.ErpNumberA.ContainerControl = this;
            // 
            // ErpNumberB
            // 
            this.ErpNumberB.ContainerControl = this;
            // 
            // ErpNumberC
            // 
            this.ErpNumberC.ContainerControl = this;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.MintCream;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.BtnQuit);
            this.Controls.Add(this.BtnIf17);
            this.Controls.Add(this.BtnIf15);
            this.Controls.Add(this.GrbResult);
            this.Controls.Add(this.GrbInputData);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Задание на 20.10.2021 - ввод и простая обработка данных";
            this.GrbResult.ResumeLayout(false);
            this.GrbInputData.ResumeLayout(false);
            this.GrbInputData.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ErpNumberA)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ErpNumberB)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ErpNumberC)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button BtnQuit;
        private System.Windows.Forms.Button BtnIf17;
        private System.Windows.Forms.Button BtnIf15;
        private System.Windows.Forms.GroupBox GrbResult;
        private System.Windows.Forms.Label LblResult;
        private System.Windows.Forms.GroupBox GrbInputData;
        private System.Windows.Forms.TextBox TbxThirdNumber;
        private System.Windows.Forms.Label LblThirdNumber;
        private System.Windows.Forms.TextBox TbxSecndNumber;
        private System.Windows.Forms.Label LblSecndNumber;
        private System.Windows.Forms.TextBox TbxFirstNumber;
        private System.Windows.Forms.Label LblFirstNumber;
        private System.Windows.Forms.ErrorProvider ErpNumberA;
        private System.Windows.Forms.ErrorProvider ErpNumberB;
        private System.Windows.Forms.ErrorProvider ErpNumberC;
    }
}

