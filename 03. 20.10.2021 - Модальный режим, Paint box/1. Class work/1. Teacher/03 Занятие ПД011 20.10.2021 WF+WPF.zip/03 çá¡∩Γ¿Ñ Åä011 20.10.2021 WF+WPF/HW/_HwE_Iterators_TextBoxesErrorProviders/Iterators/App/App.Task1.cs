﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

using Iterators.Helpers;
using Iterators.Models;

namespace Iterators.App
{
    /*
     * Методы для решения задачи 1 
     */
    internal partial class Application
    {
        // Начальное заполнение коллекции пользователей
        public void InitializeAndShow() {
            Utils.ShowNavBarTask("  Начальное заполнение коллекции пользователей, вывод данных отделаы");

            _department.Initialize();
            _department.Show("\n\n\n\n\t    Данные сформированы. ", 12);
        } // InitializeAndShow


        // Вывод коллекции пользователей в консоль        
        public void Show() {
            Utils.ShowNavBarTask("   Вывод коллекции пользователей в консоль");

            _department.Show("\n\n\n\n\t    Данные отдела сформированы. ", 12);
        } // Show

        #region Обработка событий в ObservableCollection<>

        // "движок" для демонстрации событий по заданию
        public void EventsDemo() {
            while (true) {
                Utils.ShowNavBarTask("  Демонстрация событий в ObservableCollection<User> по заданию");

                _department.Show("\n\n\n\n\t    Данные для обработки:");

                Utils.WriteXY(12, 3, "A", ConsoleColor.Cyan);
                Utils.WriteXY(14, 3, "Добавить", ConsoleColor.Gray);
                Utils.WriteXY(24, 3, "D", ConsoleColor.Cyan);
                Utils.WriteXY(26, 3, "Удалить", ConsoleColor.Gray);
                Utils.WriteXY(36, 3, "R", ConsoleColor.Cyan);
                Utils.WriteXY(38, 3, "Заменить", ConsoleColor.Gray);
                Utils.WriteXY(48, 3, "X", ConsoleColor.Cyan);
                Utils.WriteXY(50, 3, "Выход", ConsoleColor.Gray);

                ConsoleKey key = Console.ReadKey(true).Key;
                if (key == ConsoleKey.X) break;
                Console.Clear();

                switch (key) {
                    case ConsoleKey.A:
                        AddUsers();
                        break;

                    case ConsoleKey.D:
                        DeleteUsers();
                        break;

                    case ConsoleKey.R:
                        ReplaceUsers();
                        break;
                } // while
            } // while
        } // EventsDemo


        // добавление трех пользователей со знаком Рыбы
        public void AddUsers() {
            // позиция вывода сообщения о добавлении пользователей
            int x = 70, y = 6;

            // обработчик события
            NotifyCollectionChangedEventHandler handler =  (s, e) => {
                if (e.Action != NotifyCollectionChangedAction.Add) return;

                Console.BackgroundColor = ConsoleColor.DarkGreen;
                Utils.WriteXY(x, y++, $"\t{e.Action} --> {e.NewItems[0]}", ConsoleColor.Gray);
                (Console.BackgroundColor, Console.ForegroundColor) =
                    (ConsoleColor.DarkGray, ConsoleColor.Gray);
            };

            // подписываем обработчик события
            _department.Users.CollectionChanged += handler;

            _department.Add(new User(550, "Романова", "Наталья", new DateTime(1998, 3, 12)));
            _department.Add(new User(551, "Павлов", "Николай", new DateTime(1977, 3, 11)));
            _department.Add(new User(552, "Сергеев", "Василий", new DateTime(1999, 3, 19)));

            // отписываемся от события
            _department.Users.CollectionChanged -= handler;
        } // AddUsers


        // удаление пользователей, старше 60 лет -- реализуем при помощи предиката
        public void DeleteUsers() {
            // позиция вывода сообщения об удалении пользователей
            int x = 70, y = 6;

            // подписываемся на событие удаления из коллекции
            NotifyCollectionChangedEventHandler handler = (s, e) => {
                if (e.Action != NotifyCollectionChangedAction.Remove) return;

                Console.BackgroundColor = ConsoleColor.Red;
                Utils.WriteXY(x, y++, $"{e.Action} --> {e.OldItems[0]}", ConsoleColor.Gray);
                (Console.BackgroundColor, Console.ForegroundColor) =
                    (ConsoleColor.DarkGray, ConsoleColor.Gray);
            };
            _department.Users.CollectionChanged += handler;

            // удаление пользователей старше age лет 
            int age = 60;
            _department.Remove(user => user.Age > age);

            // отписываемся от события
            _department.Users.CollectionChanged -= handler;
        } // DeleteUsers

        // заменить все записи знака Овен этими же записями, но с
        // добавлением строки "-бе-бе" к фамилии 
        public void ReplaceUsers() {
            // позиция вывода сообщения о замене зписей  пользователей
            int x = 70, y = 6;

            // подписываемся на событие замены записей в коллекции
            NotifyCollectionChangedEventHandler handler = (s, e) => {
                if (e.Action != NotifyCollectionChangedAction.Replace) return;

                Console.BackgroundColor = ConsoleColor.DarkBlue;
                Utils.WriteXY(x, y++, $"{e.Action} --> новая запись {e.NewItems[0]}", ConsoleColor.Gray);
                (Console.BackgroundColor, Console.ForegroundColor) =
                    (ConsoleColor.DarkGray, ConsoleColor.Gray);
            };
            _department.Users.CollectionChanged += handler;

            for (int i = 0; i < _department.Length; ++i) {
                // пропускаем записи, у которых знак Зодиака не Овен
                if (_department[i].Zodiac != "Овен") continue;

                // модификация записи и ее замена 
                User user = _department[i];

                // если фамилию еще не поменяли, то поменяем фамилию
                // и заменим эту фамилию
                if (!user.Surname.EndsWith("-бе-бе")) {
                    user.Surname += "-бе-бе";
                    _department[i] = user; // вот тут коллекция зажигает событие !!!
                } // if 
            } // foreach

            // отписываемся от события
            _department.Users.CollectionChanged -= handler;
        } // ReplaceUsers 

        #endregion


        // При помощи именованного итератора вывести в список и консоль
        // записи с заданной фамилией
        public void EnumerateBySurname() {
            Utils.ShowNavBarTask("  Выборка записей с заданной фамилией при помощи именованного итератора");

            // сформируем фамилию для отбора пользователей из коллекции 
            string surname = _department[Utils.GetRandom(0, _department.Length - 1)].Surname;

            // список пользователей с заданной фамилией
            List<User> list = new List<User>();
            foreach (User user in _department.GetSurname(surname))
                list.Add(user);

            // вывести список отобранных пользователей
            Show($"\n\n\tПользователи отдела с фамилией {surname}:", list);
        } // EnumerateBySurname


        // при помощи именованного итератора вывести в список и консоль
        // записи с заданным знаком Зодиака
        public void EnumerateByZodiac() {
            Utils.ShowNavBarTask("  Выборка записей с заданным знаком Зодиака при помощи именованного итератора");

            // сформируем знак Зодиака для отбора пользователей из коллекции 
            string zodiac = _department[Utils.GetRandom(0, _department.Length - 1)].Zodiac;

            // выборка данных из коллекции пользователей отдела
            List<User> list = new List<User>();
            foreach (User user in _department.GetZodiac(zodiac))
                list.Add(user);

            // показать выборку 
            Show($"\n\n\tПользователи отдела со знаком \"{zodiac}\":", list);
        } // EnumerateByZodiac


        // при помощи именованного итератора вывести в список и консоль
        // записи с заданным месяцем рождения
        public void EnumerateByMonth() {
            Utils.ShowNavBarTask("  Выборка записей с заданным месяцем рождения при помощи именованного итератора");

            // сформируем месяц для отбора пользователей из коллекции 
            int month = Utils.GetRandom(1, 12);

            List<User> list = new List<User>();
            foreach (User user in _department.GetMonthBorn(month))
                list.Add(user);

            // показать выборку 
            Show($"\n\n\tПользователи отдела с месяцем рождения \"{month}\":", list);
        } // EnumerateByMonth


        // сортировка коллекции по дате рождения - коллекцию не меняем,
        // делаем копию коллекции, сортируем копию и выводим копию
        // коллекции
        public void OrderByDateOfBorn() {
            Utils.ShowNavBarTask("  Вывод записей, упорядоченных по дате рождения");

            // копия коллекции и сортировка копии
            List<User> users = new List<User>(_department.Users);
            users.Sort((u1, u2) => u1.BornDate.CompareTo(u2.BornDate));

            Show("\n\n\n\n\t    Пользователи, упорядоченные по дате рождения", users);
        } // OrderByDateOfBorn


        // сортировка коллекции по названию знака Зодиака - коллекцию не меняем,
        // делаем копию коллекции, сортируем копию и выводим копию коллекции
        public void OrderByZodiac() {
            Utils.ShowNavBarTask("  Вывод записей, упорядоченных по названию знака Зодиака");

            List<User> users = new List<User>(_department.Users);
            users.Sort((u1, u2) => u1.Zodiac.CompareTo(u2.Zodiac));

            Show("\n\n\n\n\t    Пользователи, упорядоченные по названию знака Зодиака", users);
        } // OrderByZodiac


        // сортировка коллекции по фамилии и имени - коллекцию не меняем,
        // делаем копию коллекции, сортируем копию и выводим копию коллекции
        public void OrderBySurnameName() {
            Utils.ShowNavBarTask("  Вывод записей, упорядоченных по фамилии и имени");

            List<User> users = new List<User>(_department.Users);
            users.Sort((u1, u2) 
                => $"{u1.Surname} {u1.Name}".CompareTo($"{u2.Surname} {u2.Name}"));

            Show("\n\n\n\n\t    Пользователи, упорядоченные по фамилии и имени", users);
        } // OrderBySurnameName


        // метод для вывода сформированных итераторами списков
        private void Show(string title, IEnumerable<User> users, int indent = 12) {
            string sp = " ".PadRight(indent);
            Console.WriteLine($"{title}\n{User.Header(indent)}");

            foreach (var user in users) {
                Console.WriteLine($"{sp}{user.ToTableRow()}");
            } // foreach

            Console.WriteLine($"{User.Footer(indent)}");
        } // Show
    } // class Application
}