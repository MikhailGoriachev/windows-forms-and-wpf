﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Microsoft.VisualBasic;

using Iterators.Helpers;
using Iterators.App;

/*
 * Задача 1.
 * Описать класс с именем User, содержащую следующие поля:
 *     • числовой идентификатор - int;
 *     • фамилия, имя - string;
 *     • знак Зодиака - string;
 *     • дата рождения - DateTime
 * Создать класс Department со списком пользователей – коллекцией типа
 * ObservableCollection<User>. Проинициировать ее не менее чем 20 записями
 * о пользователях, использовать все знаки Зодиака, заполнение коллекции также
 * выполняйте из пункта меню.
 * Реализовать CRUD-операции, (операции Read и Update – реализовать
 * индексатором), обрабатывать события добавления, удаления и замещения
 * (replace) данных в коллекции. 
 * Обрабатывать события при выполнении следующих запросов, включенных в меню
 * приложения:
 *     • добавление трех пользователей со знаком Рыбы (create)
 *     • удаление всех пользователей старше 60 лет (delete)
 *     • заменить все записи знака Овен этими же записями, но с добавлением
 *       строки "-бе-бе" к фамилии (update - replace)
 * Также в пунктах меню задать выполнение следующих действий:
 *     • при помощи именованного итератора вывести в список и консоль записи
 *       с заданной фамилией
 *     • при помощи именованного итератора вывести в список и консоль записи
 *       с заданным знаком Зодиака
 *     • при помощи именованного итератора вывести в список и консоль записи
 *       с заданным месяцем рождения
 *     • сортировка по дате рождения
 *     • сортировка по названиям знаков Зодиака
 *     • сортировка по фамилии, имени
 * 
 */
namespace Iterators
{
    internal class Program
    {
        static void Main(string[] args) {
            Console.Title = "Задание на 20.10.2021 - события, итераторы в C#";

            // простейшее меню приложения
            MenuItem[] menu = new[] {
                new MenuItem {HotKey = ConsoleKey.Q, Text = "Начальное заполнение данных отдела"},
                new MenuItem {HotKey = ConsoleKey.W, Text = "Вывод данных отдела в консоль"},
                new MenuItem {HotKey = ConsoleKey.E, Text = "Обработка событий в коллекции ObservableCollection<>"},
                new MenuItem {HotKey = ConsoleKey.R, Text = "Выборка записей с заданной фамилией при помощи именованного итератора"},
                new MenuItem {HotKey = ConsoleKey.T, Text = "Выборка записей с заданным знаком Зодиака при помощи именованного итератора"},
                new MenuItem {HotKey = ConsoleKey.Y, Text = "Выборка записей с заданным месяцем рождения при помощи именованного итератора"},
                new MenuItem {HotKey = ConsoleKey.U, Text = "Вывод записей, упорядоченных по дате рождения"},
                new MenuItem {HotKey = ConsoleKey.I, Text = "Вывод записей, упорядоченных по знаку Зодиака"},
                new MenuItem {HotKey = ConsoleKey.O, Text = "Вывод записей, упорядоченных по фамилии и имени"},
                //----------------------------------------------------------------------------------------------
                new MenuItem {HotKey = ConsoleKey.Z, Text = "Выход"},
            };

            // Создание экземпляра класса приложения
            Application app = new Application();

            // главный цикл приложения
            while (true) {
                try {
                    // настройка цветового оформления
                    (Console.ForegroundColor, Console.BackgroundColor) = (ConsoleColor.Gray, ConsoleColor.DarkGray);
                    Console.Clear();
                    Console.CursorVisible = false;

                    Utils.ShowNavBarTask("  ООП C# - обобощенные коллекции, события, итераторы");
                    Utils.ShowMenu(12, 5, "Меню приложения для демонстрации работы с событиями, итераторами в C#", menu);

                    // получить код нажатой клавиши, не отображать символ клавиши
                    Console.BackgroundColor = ConsoleColor.Gray;
                    string msg =
                        "  Нажмите выделенную цветом клавишу для выбора пункта меню".PadRight(Console.WindowWidth - 1);
                    Utils.WriteXY(0, Console.WindowHeight - 1, msg, ConsoleColor.Black);

                    ConsoleKey key = Console.ReadKey(true).Key;
                    (Console.ForegroundColor, Console.BackgroundColor) = (ConsoleColor.Gray, ConsoleColor.DarkGray);
                    Console.Clear();

                    switch (key) {

                        // Начальное заполнение данных отдела
                        case ConsoleKey.Q:
                            app.InitializeAndShow();
                            break;

                        // Вывод данных отдела в консоль
                        case ConsoleKey.W:
                            app.Show();
                            break;

                        // Обработка событий в коллекции ObservableCollection<>
                        case ConsoleKey.E:
                            app.EventsDemo();
                            break;

                        // Выборка записей с заданной фамилией при помощи именованного итератора
                        case ConsoleKey.R:
                            app.EnumerateBySurname();
                            break;

                        // Выборка записей с заданным знаком Зодиака при помощи именованного итератора
                        case ConsoleKey.T:
                            app.EnumerateByZodiac();
                            break;

                        // Выборка записей с заданным месяцем рождения при помощи именованного итератора
                        case ConsoleKey.Y:
                            app.EnumerateByMonth();
                            break;

                        // Вывод записей, упорядоченных по дате рождения
                        case ConsoleKey.U:
                            app.OrderByDateOfBorn();
                            break;

                        // Вывод записей, упорядоченных по знаку Зодиака
                        case ConsoleKey.I:
                            app.OrderByZodiac();
                            break;

                        // Вывод записей, упорядоченных по фамилии и имени
                        case ConsoleKey.O:
                            app.OrderBySurnameName();
                            break;

                        // Выход из приложения назначен на клавишу F10 или клавишу M или клавишу Escape
                        case ConsoleKey.F10:
                        case ConsoleKey.Escape:
                        case ConsoleKey.Z:
                            Console.ResetColor(); // сброс цветового сочетания к исходному
                            Console.Clear();
                            Utils.WriteXY(0, Console.WindowHeight - 1, "Нажмите любую клавишу...", ConsoleColor.Gray);
                            Console.CursorVisible = true;
                            return;

                        default:
                            throw new Exception("Нет такой команды меню");
                    } // switch

                    // Ожидать нажатия любой клавиши по окончании работы пункта меню
                    Console.CursorVisible = true;
                    Console.BackgroundColor = ConsoleColor.Gray;
                    msg = "  Нажмите любую клавишу...".PadRight(Console.WindowWidth - 1);
                    Utils.WriteXY(0, Console.WindowHeight - 1, msg, ConsoleColor.Black);
                    Console.ReadKey(true);
                } // try

                // обработка исключений - просто вывести сообщение
                catch (Exception ex) {
                    Interaction.MsgBox(ex.Message, MsgBoxStyle.Critical | MsgBoxStyle.OkOnly, "Ошибка");
                } // try-catch
            } // while
        } // Main
    } // class Program
}
