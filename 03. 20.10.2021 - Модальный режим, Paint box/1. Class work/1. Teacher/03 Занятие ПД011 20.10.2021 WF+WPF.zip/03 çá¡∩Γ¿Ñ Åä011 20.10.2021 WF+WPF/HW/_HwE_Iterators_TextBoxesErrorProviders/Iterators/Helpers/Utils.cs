﻿using System;

namespace Iterators.Helpers
{
    // вспомогательные методы и объекты - статический класс, т.е. класс,
    // содержащий только статические члены и методы
    public static class Utils
    {

        // объект для получения случайных чисел
        public static readonly Random Random = new Random(Environment.TickCount);

        // Получение случайного числа
        // краткая форма записи метода - это не лямбда выражение
        public static int GetRandom(int lo, int hi) => Random.Next(lo, hi + 1);
        public static double GetRandom(double lo, double hi) => lo + (hi - lo) * Random.NextDouble();

        // формирование случайных целых чисел в заданном диапазоне (lo, hi),
        // исключая указанное параметром exclude число
        public static int GetRandomExclude(int lo, int hi, int exclude)
        {
            int number = 0;
            do
                number = Random.Next(lo, hi);
            while (number == exclude);

            return number;
        } // GetRandomExclude


        // формирует и выводит верхнюю строку для задач
        public static void ShowNavBarTask(string line) {
            // сохранить цвет фона
            (ConsoleColor oldBg, ConsoleColor oldFg) = (Console.BackgroundColor, Console.ForegroundColor);

            // при выводе немного используем методы класса string :)
            // PadRight() дополняет строку справа пробелами до заданной длины
            Console.BackgroundColor = ConsoleColor.Gray;
            WriteXY(0, 0, line.PadRight(Console.WindowWidth), ConsoleColor.Black);

            // восстановить цвет фона
            (Console.BackgroundColor, Console.ForegroundColor) = (oldBg, oldFg);
        } // ShowNavBarTask
        
        
        // Вспомогательный метод для вывода в заданных координатах окна консоли текста
        // заданным цветом
        public static void WriteXY(int x, int y, string s, ConsoleColor color) {
            // сохранить текущий цвет консоли и установить заданный
            ConsoleColor oldColor = Console.ForegroundColor;
            Console.ForegroundColor = color;

            Console.SetCursorPosition(x, y);
            Console.Write(s);

            // восстановить цвет консоли
            Console.ForegroundColor = oldColor;
        } // WriteXY

        // Вывод меню приложения
        public static void ShowMenu(int x, int y, string title, MenuItem[] menu) {
            WriteXY(x, y++, title, ConsoleColor.Gray);
            WriteXY(x, y++, new string('─', 80), ConsoleColor.Gray);

            foreach (var menuItem in menu) {
                WriteXY(x, y, menuItem.HotKey.ToString(), ConsoleColor.Cyan);
                WriteXY(x + 2, y++, menuItem.Text, ConsoleColor.Gray);
            } // foreach menuItem
        } // ShowMenu

        // Вывод сообщения "Метод в разработке" по центру экрана
        public static void ShowUnderConstruction() {
            (ConsoleColor fg, ConsoleColor bg) = (Console.ForegroundColor, Console.BackgroundColor); 
            (Console.ForegroundColor, Console.BackgroundColor) = (ConsoleColor.Black, ConsoleColor.Gray);

            string[] lines = { 
                 " ".PadRight(40),
                 " ".PadRight(40),
                 "     [К сведению]".PadRight(40),
                 " ".PadRight(40),
                 "     Метод в разработке".PadRight(40),
                 " ".PadRight(40),
                 " ".PadRight(40),
            };

            int x = (Console.WindowWidth - 40) / 2;
            int y = (Console.WindowHeight - lines.Length) / 2;
            foreach(var line in lines)
                WriteXY(x, y++, line, ConsoleColor.DarkGray);

            (Console.ForegroundColor, Console.BackgroundColor) = (fg, bg);
            Console.SetCursorPosition(0, Console.WindowHeight-1);
        } // ShowUnderConstruction


        // вернуть имя из массива имен - работает с учетом пола
        // массивы имен вынесены из методов - для ускорения работы
        // методов, не требуется инициализация массива при каждом вызове метода
        private static readonly string[] MaleNames = {
            "Ерофей", "Агафон", "Спиридон", "Тимофей", "Сергей",
            "Павел", "Федор", "Тарас", "Николай", "Валерий",
            "Юрий", "Алексей"
        };

        private static readonly string[] FemaleNames = {
            "Марфа", "Оксана", "Анна", "Лидия", "Евлампия", "Наталья", "Полина",
            "Фекла", "Тамара", "Яся", "Татьяна"
        };

        public static string GetName(bool gender) => gender
            ? MaleNames[GetRandom(0, MaleNames.Length - 1)]
            : FemaleNames[GetRandom(0, FemaleNames.Length - 1)];

        // вернуть фамилию из массива имен - очень примитивный 
        // алгоритм формирования женских фамилий
        private static readonly string[] Surnames = {
            "Огородников", "Иванов", "Семенов", "Охрименков", "Васильев", "Ларин",
            "Тяглов", "Тимофеев", "Сергеев", "Елизаветин", "Шматков", "Луков", "Федоров",
            "Туркин"
        };
        public static string GetSurname(bool gender) {
            string surname = Surnames[GetRandom(0, Surnames.Length - 1)];
            return gender ? surname : surname + "а";
        } // GetSurname


        // формирование знака зодиака по дате 
        private static readonly (string Sign, DateTime From, DateTime To)[] Zodiacs = {
            ("Козерог",  new DateTime(1999, 12, 22), new DateTime(2000,  1, 20)),
            ("Водолей",  new DateTime(2000,  1, 21), new DateTime(2000,  2, 18)),
            ("Рыбы",     new DateTime(2000,  2, 19), new DateTime(2000,  3, 20)),
            ("Овен",     new DateTime(2000,  3, 21), new DateTime(2000,  4, 20)),
            ("Телец",    new DateTime(2000,  4, 21), new DateTime(2000,  5, 21)),
            ("Близнецы", new DateTime(2000,  5, 22), new DateTime(2000,  6, 21)),
            ("Рак",      new DateTime(2000,  6, 22), new DateTime(2000,  7, 22)),
            ("Лев",      new DateTime(2000,  7, 23), new DateTime(2000,  8, 23)),
            ("Дева",     new DateTime(2000,  8, 24), new DateTime(2000,  9, 22)),
            ("Весы",     new DateTime(2000,  9, 23), new DateTime(2000, 10, 23)),
            ("Скорпион", new DateTime(2000, 10, 24), new DateTime(2000, 11, 22)),
            ("Стрелец",  new DateTime(2000, 11, 23), new DateTime(2000, 12, 21))
        };
        public static string GetZodiac(DateTime date) {
            // создать дату для сравнения с границами знаков Зодиака
            DateTime temp = new DateTime(2000, date.Month, date.Day);
            
            string result = Array.Find(Zodiacs, d => d.From <= temp && temp <= d.To).Sign;
            return string.IsNullOrEmpty(result) ? "Козерог" : result;
        } // GetZodiac
    } // class Utils
}