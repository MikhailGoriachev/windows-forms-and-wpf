﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Iterators.Models
{
    class Department: IEnumerable
    {
        // пользователи
        private ObservableCollection<User> _users;
        public ObservableCollection<User> Users => _users;

        // название отдела
        private string _name;
        public string Name {
            get => _name; 
            set => _name = value;
        } // Name

        // размер коллекции
        public int Length => _users.Count;

        // индексатор для доступа к коллекции
        public User this[int index] {
            get => _users[index];
            set => _users[index] = value;
        } // this

        #region Конструкторы

        public Department() : this(new ObservableCollection<User>(), "Прачечная") {
            Initialize();
        } // Department

        public Department(ObservableCollection<User> users, string name) {
            _users = users;
            _name = name;
        } // Department
        #endregion

        // Инициализатор для коллекции, 20 - по заданию
        public void Initialize(int size = 20) {
            if (size <= 0)
                throw new ArgumentException("Количество генерируемых персон не может быть <= 0");
           
            _users.Clear();
            for(int i = 0; i < size; ++i)
                _users.Add(User.Generate());
        } // Initialize

        // Вывод коллекции сотрудников в консоль
        public void Show(string title, int indent = 12) {
            string sp = " ".PadRight(indent);
            Console.WriteLine($"{title}\n{User.Header(indent)}");

            foreach (var user in _users) {
                Console.WriteLine($"{sp}{user.ToTableRow()}");    
            } // foreach

            Console.WriteLine($"{User.Footer(indent)}");
        } // Show


        // именованный итератор для фильтрации коллекции
        // сотрудников по фамилии
        public IEnumerable GetSurname(string surname) {
            foreach (var user in _users) {
                if (user.Surname == surname) yield return user;
            } // foreach
        } // GetSurname


        // именованный итератор для фильтрации коллекции
        // сотрудников по названию знаку Зодиака
        public IEnumerable GetZodiac(string zodiac) {
            foreach (var user in _users) {
                if (user.Zodiac == zodiac) yield return user;
            } // foreach
        } // GetZodiac


        // именованный итератор для фильтрации коллекции
        // сотрудников по месяцу рождения
        public IEnumerable GetMonthBorn(int month) {
            foreach (var user in _users) {
                if (user.BornDate.Month == month) yield return user;
            } // foreach
        } // GetMonthBorn


        // метод для добавления пользователя в коллекцию
        public void Add(User user) => _users.Add(user);


        // удаление пользователя по индексу
        public void RemoveAt(int index) => _users.RemoveAt(index);


        // удаление пользователей по предикату
        public void Remove(Predicate<User> predicate) {
            // просмотр коллекции пользователей и удаление тех, для
            // кого предикат вернет true
            int n = _users.Count;
            for (int i = 0; i < n; ++i) {
                if (predicate(_users[i])) {
                    _users.RemoveAt(i);
                    --i; // остаться на той же позиции после удаления
                    n = _users.Count;  // перечитать размер коллекции
                } // if
            } // for i
        } // Remove


        // реализация итератора для коллекции
        public IEnumerator GetEnumerator() => _users.GetEnumerator();
    } // class Department
}
