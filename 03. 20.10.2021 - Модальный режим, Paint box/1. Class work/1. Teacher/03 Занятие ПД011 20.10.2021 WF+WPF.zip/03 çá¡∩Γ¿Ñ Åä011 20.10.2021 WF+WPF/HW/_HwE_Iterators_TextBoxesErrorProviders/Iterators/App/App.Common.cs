﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

using Iterators.Helpers;
using Iterators.Models;

namespace Iterators.App
{
    // Общая часть приложения, создание объекта для выполнения задания
    internal partial class Application
    {
        // коллекция для обработки
        private Department _department;

        // конструкторы - по умолчанию, с внедрением параметров 
        public Application():this(new Department()) { } // Application

        public Application(Department department) {
            _department = department;
        } // Application
    } // class Application
}
