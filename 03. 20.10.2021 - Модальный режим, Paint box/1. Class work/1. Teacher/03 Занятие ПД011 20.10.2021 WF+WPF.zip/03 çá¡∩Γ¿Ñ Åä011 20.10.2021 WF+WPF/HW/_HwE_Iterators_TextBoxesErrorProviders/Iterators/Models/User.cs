﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Iterators.Helpers;

namespace Iterators.Models
{
    // Класс User, содержащую следующие поля:
    //     • числовой идентификатор
    //     • фамилия, имя
    //     • знак Зодиака
    //     • дата рождения
    internal class User
    {
        // числовой идентификатор - int;
        private int _id;
        public int Id {
            get => _id;
            set {
                if (value <= 0)
                    throw new ArgumentException($"User. Недопустимое значение идентфикатора: {value}");

                _id = value;
            } // set
        } // Id


        // фамилия - string;
        private string _surname;
        public string Surname {
            get => _surname;
            set {
                if (string.IsNullOrWhiteSpace(value))
                    throw new ArgumentException("User. Фамилия не задана или задана пустой строкой");

                _surname = value;
            } // set
        } // Surname

        // имя - string;
        private string _name;
        public string Name {
            get => _name;
            set {
                if (string.IsNullOrWhiteSpace(value))
                    throw new ArgumentException("User. Имя не задано или задано пустой строкой");

                _name = value;
            } // set
        } // Name


        // знак Зодиака - string, вычисляется по дате рождения
        public string Zodiac => Utils.GetZodiac(_bornDate);

        // дата рождения - DateTime
        private DateTime _bornDate;
        public DateTime BornDate {
            get => _bornDate;
            set => _bornDate = value;
        } // BornDate 

        #region конструкторы

        // конструктор по умолчанию
        private User() : this(1000, "Пупкин", "Василий",
            new DateTime(DateTime.Now.Year - 65, 1, 1)) { } // User

        // конструктор с параметрами
        public User(int id, string surname, string name, DateTime bornDate) {
            Id = id;
            Surname = surname;
            Name = name;
            BornDate = bornDate;
        } // User       

        #endregion


        // Фабричный метод для создания объекта класса User
        public static User Generate() {
            // объект-заготовка
            User user = new User { Id = Utils.GetRandom(1, 1000) };

            // блок генерации имен и фамилии
            bool gender = Utils.GetRandom(0, 1) == 1;  // получить пол объекта User
            user.Name = Utils.GetName(gender);               // генерация имени в зависимости от пола
            user.Surname = Utils.GetSurname(gender);

            // дата рождения
            user.BornDate = new DateTime(
                Utils.GetRandom(1941, DateTime.Today.Year - 18),
                Utils.GetRandom(1, 12),
                Utils.GetRandom(1, 28)
            );

            return user;
        } // User

        // вывод данных в формате строки таблицы
        public string ToTableRow() =>
            $"│ {_id,5} │ {_surname,-18} │ {_name,-15} │ {Zodiac,-12} │    {_bornDate:d} │ {Age,7} │";

        // статический метод для вывода шапки таблицы
        public static string Header(int indent) {
            string sp = " ".PadRight(indent);
            return 
                $"{sp}┌───────┬────────────────────┬─────────────────┬──────────────┬───────────────┬─────────┐\n" +
                $"{sp}│  Id.  │ Фамилия            │ Имя             │ Знак Зодиака │ Дата рождения │ Возраст │\n" +
                $"{sp}├───────┼────────────────────┼─────────────────┼──────────────┼───────────────┼─────────┤";
        } // Header

        // статический метод для вывода подвала таблицы
        public static string Footer(int indent) {
            string sp = " ".PadRight(indent);
            return $"{sp}└───────┴────────────────────┴─────────────────┴──────────────┴───────────────┴─────────┘";
        } // Footer


        // для вывода данных о пользователе в строковом формате
        public override string ToString() =>
            $"Ид: {_id}. {_surname} {_name}. {Zodiac}. {_bornDate:d}";

        // возраст пользователя - для бОльшего удобства
        public int Age => DateTime.Now.Year - _bornDate.Year;
    } // class User
}
