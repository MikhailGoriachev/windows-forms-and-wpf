﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _002_TextInputOutptut
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }
        
        // выход из приложения
        private void BtnQuit_Click(object sender, EventArgs e) => Close();

        // If15.Даны три переменные вещественного типа.Найти сумму двух
        // наибольших из них(т.е.для чисел 1, 2, 3 сумма будет равна 5).
        private void BtnIf15_Click(object sender, EventArgs e) {
            double max1, max2;
            string txt;
            (double a, double b, double c) = ParseNumbers(out bool res);

            // Все числа были введены корректно
            if (res) {
                // посик двух наибольших чисел
                (max1, max2) = a < b && a < c ? (b, c) : (b < c) ? (a, c) : (b, a);

                LblResult.TextAlign = ContentAlignment.MiddleLeft;
                txt = $"  Из чисел {a,5:f2}; {b,5:f2}; {c,5:f2}\n\n  Наибольшие {max1,5:f2} и {max2,5:f2}\n\n  Их сумма: {max1 + max2,5:f2}\n";
            } 
            else {
                LblResult.TextAlign = ContentAlignment.MiddleCenter;
                txt = "Некорректный ввод!";
            } // if

            LblResult.Text = txt;
        } // BtnIf15_Click


        // If17. Даны три переменные вещественного типа: A, B, C.
        // Если их значения упорядочены по возрастанию или убыванию,
        // то удвоить их; в противном случае заменить значение каждой
        // переменной на противоположное. Вывести новые значения
        // переменных A, B, C.
        private void BtnIf17_Click(object sender, EventArgs e) {
            
            string txt;
            (double a, double b, double c) = ParseNumbers(out bool res);

            // Все числа были введены корректно
            if (res) {
                txt = $"  Числа до обработки     : {a,6:f2}; {b,6:f2}; {c,6:f2}";

                (a, b, c) = a < b && b < c || c < b && b < a
                    ?
                // Eсли их значения упорядочены по возрастанию или убыванию, то удвоить их
                    (2d * a, 2d * b, 2d * c)
                    :
                // В противном случае заменить значение каждой переменной на противоположное
                    (-a, -b, -c);

                txt += $"\n\n  Числа после обработки: {a,6:f2}; {b,6:f2}; {c,6:f2}";
                LblResult.TextAlign = ContentAlignment.MiddleLeft;
            }
            else {
                LblResult.TextAlign = ContentAlignment.MiddleCenter;
                txt = "Некорректный ввод!";
            } // if

            LblResult.Text = txt;
        } // BtnIf17_Click

        private (double, double, double) ParseNumbers(out bool res) {
            string error = "Недопустимый формат";
            res = true; // Все числа введены корректно - true

            // проверка корректности ввода данных - число A 
            bool result = double.TryParse(TxbFirstNumber.Text, out double a);
            ErpFirstNumber.SetError(TxbFirstNumber, !result ? error : "");
            if (!result) res = false;

            // аналогичный ввод и проверка для числа B
            result = double.TryParse(TxbSecondNumber.Text, out double b);
            ErpSecondNumber.SetError(TxbSecondNumber, !result ? error : "");
            if (!result) res = false;

            // аналогичный ввод и проверка для числа C
            result = double.TryParse(TxbThirdNumber.Text, out double c);
            ErpThirdNumber.SetError(TxbThirdNumber, !result ? error : "");
            if (!result) res = false;

            return (a, b, c);
        } // ParseNumbers

        private void TxbFirstNumber_TextChanged(object sender, EventArgs e) =>
            ErpFirstNumber.SetError(TxbFirstNumber, "");

        private void TxbSecondNumber_TextChanged(object sender, EventArgs e) =>
            ErpSecondNumber.SetError(TxbSecondNumber, "");

        private void TxbThirdNumber_TextChanged(object sender, EventArgs e) =>
            ErpThirdNumber.SetError(TxbThirdNumber, "");
    }
}
