﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualBasic;   // для доступа к возможностям класса Interaction
using Задание.Helpers;
using Задание.Application;

/*
 * Задача 1. Описать класс с именем User, содержащую следующие поля:
 *      •	числовой идентификатор - int;
 *      •	фамилия, имя - string;
 *      •	знак Зодиака - string;
 *      •	дата рождения - DateTime
 *      
 * Создать класс Department со списком пользователей – коллекцией типа 
 * ObservableCollection<User>. Проинициировать ее не менее чем 20 записями
 * о пользователях, использовать все знаки Зодиака, заполнение коллекции
 * также выполняйте из пункта меню.
 * 
 * Реализовать CRUD-операции, (операции Read и Update – реализовать индексатором),
 * обрабатывать события добавления, удаления и замещения (replace) данных в коллекции. 
 * 
 * Обрабатывать события при выполнении следующих запросов, включенных в меню приложения:
 *       •	добавление трех пользователей со знаком Рыбы (create)
 *       •	удаление всех пользователей старше 60 лет (delete)
 *       •	заменить все записи знака Овен этими же записями, но с добавлением строки "-бе-бе"
 *          к фамилии (update - replace)
 *          
 * Таже в пунктах меню задать выполнение следующих действий:
 *       •	при помощи именованного итератора вывести в список и консоль записи с заданной фамилией
 *       •	при помощи именованного итератора вывести в список и консоль записи с заданным знаком Зодиака
 *       •	при помощи именованного итератора вывести в список и консоль записи с заданным месяцем рождения
 *       •	сортировка по дате рождения
 *       •	сортировка по названиям знаков Зодиака
 *       •	сортировка по фамилии, имени
 */

namespace Задание
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Задание на 20.10.2021";

            // простейшее меню приложения
            MenuItem[] menu = new[] {
                new MenuItem { HotKey = ConsoleKey.Q, Text = "Начальное формирование коллекции пользователей" },
                new MenuItem { HotKey = ConsoleKey.W, Text = "Вывод коллекции пользователей" },
                new MenuItem { HotKey = ConsoleKey.E, Text = "Добавление трех пользователей со знаком Рыбы" },
                new MenuItem { HotKey = ConsoleKey.R, Text = "Удаление всех пользователей старше 60 лет" },
                new MenuItem { HotKey = ConsoleKey.T, Text = "Заменить все записи знака Овен" },
                new MenuItem { HotKey = ConsoleKey.Y, Text = "Вывести список записей с заданной фамилией" },
                new MenuItem { HotKey = ConsoleKey.A, Text = "Вывести список записей с заданным знаком Зодиака" },
                new MenuItem { HotKey = ConsoleKey.S, Text = "Вывести список записей с заданным месяцем рождения" },
                new MenuItem { HotKey = ConsoleKey.D, Text = "Cортировка по дате рождения" },
                new MenuItem { HotKey = ConsoleKey.F, Text = "Cортировка по названиям знаков Зодиака" },
                new MenuItem { HotKey = ConsoleKey.G, Text = "Cортировка по фамилии, имени" },
                //--------------------------------------------------------------------------------------------------------------------------
                new MenuItem { HotKey = ConsoleKey.Z, Text = "Выход" },
            };

            // Создание экземпляра класса приложения
            App app = new App();

            // главный цикл приложения
            while (true) {
                try {

                    // настройка цветового оформления
                    Console.ForegroundColor = ConsoleColor.Gray;
                    Console.BackgroundColor = ConsoleColor.DarkGray;
                    Console.Clear();
                    Console.CursorVisible = false;

                    Utils.ShowNavBarTask("  Задание на 20.10.2021");
                    Utils.ShowMenu(12, 5, "Главное меню приложения", menu);

                    // получить код нажатой клавиши, не отображать символ клавиши
                    ConsoleKey key = Console.ReadKey(true).Key;
                    Console.Clear();

                    switch (key) {
                        // Начальное формирование коллекции пользователей
                        case ConsoleKey.Q:
                            app.DepartmentInitialize();
                            break;

                        // Вывод коллекции пользователей
                        case ConsoleKey.W:
                            app.DepartmentShow();
                            break;

                        // Добавление трех пользователей со знаком Рыбы
                        case ConsoleKey.E:
                            app.DemoAddUsers();
                            break;

                        // Удаление всех пользователей старше 60 лет
                        case ConsoleKey.R:
                            app.DemoRemoveAllOlderThan();
                            break;

                        // Заменить все записи знака Овен
                        case ConsoleKey.T:
                            app.DemoReplaceUsers();
                            break;

                        // Вывести список записей с заданной фамилией
                        case ConsoleKey.Y:
                            app.ShowSurname();
                            break;

                        // Вывести список записей с заданным знаком Зодиака
                        case ConsoleKey.A:
                            app.ShowByZodiacSign();
                            break;

                        // Вывести список записей с заданным месяцем рождения
                        case ConsoleKey.S:
                            app.ShowByMonth();
                            break;

                        // Cортировка по дате рождения
                        case ConsoleKey.D:
                            app.DemoOrderByDateOfBirth();
                            break;

                        // Cортировка по названиям знаков Зодиака
                        case ConsoleKey.F:
                            app.DemoOrderByZodiacSign();
                            break;

                        // Cортировка по фамилии, имени
                        case ConsoleKey.G:
                            app.DemoOrderByName();
                            break;

                        // выход из приложения назначен на клавишу F10 или кавишу Z
                        case ConsoleKey.F10:
                        case ConsoleKey.Z:
                            Console.ResetColor();   // сброс цветового сочетания к исходному
                            Console.Clear();
                            Utils.WriteXY(0, Console.WindowHeight - 1, "", ConsoleColor.Gray);
                            Console.CursorVisible = true;
                            return;

                        default:
                            throw new Exception("Такого пункта нет в меню!");
                    } // switch

                }
                catch (Exception ex) {
                    Interaction.MsgBox(ex.Message, MsgBoxStyle.Critical | MsgBoxStyle.OkOnly, "Ошибка");
                }
                finally { 
                    // Ожидать нажатия любой клавиши по окончании работы пункта меню
                    Console.CursorVisible = true;
                    Utils.WriteXY(0, Console.WindowHeight - 1, "Нажмите любую клавишу...", ConsoleColor.Gray);
                    Console.ReadKey(true);
                }
            } // while
        } // Main
    }
}
