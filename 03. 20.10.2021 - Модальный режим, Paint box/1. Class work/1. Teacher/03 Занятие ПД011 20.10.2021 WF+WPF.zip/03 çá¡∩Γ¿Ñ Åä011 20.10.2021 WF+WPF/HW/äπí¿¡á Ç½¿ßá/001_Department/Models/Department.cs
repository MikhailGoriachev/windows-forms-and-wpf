﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel; // для ObservableCollection<T>
using System.Collections.Specialized;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Задание.Helpers;

namespace Задание.Models
{

    internal class Department: IEnumerable {
        private ObservableCollection<User> _users; //контейнер

        public Department() {
            Initialize();
        } // Department

        public Department(ObservableCollection<User> users) {
            _users = users;
            _users.CollectionChanged += CollectionChangedEventHandler;
        } // Department

        public int UsersCount { get => _users.Count; }

        // Заполнение коллекции пользователей
        public void Initialize() {
            int i = 1;
            _users = new ObservableCollection<User>(
                new[]{
                    new User{Id = i, Name = "Семенов Иван",       DateOfBirth = new DateTime(Utils.GetRand(1930, 2016), i++, Utils.GetRand(1, 20))},
                    new User{Id = i, Name = "Воликов Геннадий",   DateOfBirth = new DateTime(Utils.GetRand(1930, 2016), i++, Utils.GetRand(1, 21))},
                    new User{Id = i, Name = "Жукова Елена",       DateOfBirth = new DateTime(Utils.GetRand(1930, 2016), i++, Utils.GetRand(1, 21))},
                    new User{Id = i, Name = "Янковский Олег",     DateOfBirth = new DateTime(Utils.GetRand(1930, 2016), i++, Utils.GetRand(1, 22))},
                    new User{Id = i, Name = "Абалкин Семён",      DateOfBirth = new DateTime(Utils.GetRand(1930, 2016), i++, Utils.GetRand(1, 21))},
                    new User{Id = i, Name = "Харламова Ольга",    DateOfBirth = new DateTime(Utils.GetRand(1930, 2016), i++, Utils.GetRand(1, 23))},
                    new User{Id = i, Name = "Романова Мария",     DateOfBirth = new DateTime(Utils.GetRand(1930, 2016), i++, Utils.GetRand(1, 23))},
                    new User{Id = i, Name = "Жеребцов Александр", DateOfBirth = new DateTime(Utils.GetRand(1930, 2016), i++, Utils.GetRand(1, 22))},
                    new User{Id = i, Name = "Куликов Дмитрий",    DateOfBirth = new DateTime(Utils.GetRand(1930, 2016), i++, Utils.GetRand(1, 20))},
                    new User{Id = i, Name = "Крутых Анна",        DateOfBirth = new DateTime(Utils.GetRand(1930, 2016), i++, Utils.GetRand(1, 20))},
                    new User{Id = i, Name = "Петренко Денис",     DateOfBirth = new DateTime(Utils.GetRand(1930, 2016), i++, Utils.GetRand(1, 19))},
                    new User{Id = i, Name = "Рожкова София",      DateOfBirth = new DateTime(Utils.GetRand(1930, 2016), i++, Utils.GetRand(1, 21))},
                    User.Generate(i++),
                    User.Generate(i++),
                    User.Generate(i++),
                    User.Generate(i++),
                    User.Generate(i++),
                    User.Generate(i++),
                    User.Generate(i++),
                    User.Generate(i++),
                });
            _users.CollectionChanged += CollectionChangedEventHandler;
        } // Initialize


        // Обработчик события CollectionChanged 
        private static void CollectionChangedEventHandler(object sender, NotifyCollectionChangedEventArgs e) {
            ConsoleColor old = Console.ForegroundColor;
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.Write("\nВ обработчике! ");

            switch (e.Action) {
                case NotifyCollectionChangedAction.Add:
                    Console.WriteLine($"Операция добавления. Добавлен {(User)e.NewItems[0]}");
                    break;
                case NotifyCollectionChangedAction.Remove:
                    Console.WriteLine($"Операция удаления. Удален {(User)e.OldItems[0]}");
                    break;
                case NotifyCollectionChangedAction.Replace:
                    Console.WriteLine($"Операция замены: {(User)e.OldItems[0]} на {(User)e.NewItems[0]}");
                    break;
                case NotifyCollectionChangedAction.Move:
                    Console.WriteLine($"Операция перемещения/обмена: {e.OldStartingIndex} и {e.NewStartingIndex}");
                    break;
                case NotifyCollectionChangedAction.Reset:
                    Console.WriteLine("Операция очистки");
                    break;
                default:
                    Console.WriteLine("Операция не распознана");
                    break;
            } // switch

            Console.ForegroundColor = old;
        } // CollectionChangedEventHandler


        // Вывести данные коллекции в консоль - для вывода 
        public void Show(string caption, int indent) {
            // вывод заголовка таблицы данных 
            string space = " ".PadRight(indent);
            Console.Write($"\n\n{space}{caption}\n{User.Header(indent)}");

            // вывод всех элементов коллекции объектов данных
            foreach (User item in _users)
                Console.WriteLine($"{space}{item.ToTableRow()}");

            // вывод подвала таблицы
            Console.WriteLine($"{User.Footer(indent)}\n");
        } // Show


        public void Show<T>(string caption, int indent, Func<T, IEnumerable> func, T value) {
            // вывод заголовка таблицы данных 
            string space = " ".PadRight(indent);
            Console.Write($"\n\n{space}{caption}\n{User.Header(indent)}");

            // вывод всех элементов коллекции объектов данных
            foreach (User item in func(value))
                Console.WriteLine($"{space}{item.ToTableRow()}");

            // вывод подвала таблицы
            Console.WriteLine($"{User.Footer(indent)}\n");
        } // Show


        // Cортировка по дате рождения
        public void OrderByDateOfBirth() {
            List<User> temp = new List<User>(_users);
            temp.Sort((x, y) => x.DateOfBirth.CompareTo(y.DateOfBirth));
            _users = new ObservableCollection<User>(temp);
        } // OrderByDateOfBirth


        // Cортировка по названиям знаков Зодиака
        public void OrderByZodiacSign() {
            List<User> temp = new List<User>(_users);
            temp.Sort((x, y) => x.ZodiacSign.CompareTo(y.ZodiacSign));
            _users = new ObservableCollection<User>(temp);
            _users.CollectionChanged += CollectionChangedEventHandler;
        } // OrderByZodiacSign


        // Cортировка по фамилии, имени
        public void OrderByName() {
            List<User> temp = new List<User>(_users);
            temp.Sort((x, y) => x.Name.CompareTo(y.Name));
            _users = new ObservableCollection<User>(temp);
            _users.CollectionChanged += CollectionChangedEventHandler;
        } // OrderByName


        // Добавление пользователя
        public void AddUser(User u) => _users.Add(u);


        // Удвление всех пользователей старше заданного значения 
        public void RemoveAllOlderThan(int age) {
            for (int i = UsersCount - 1; i >= 0; i--) {
                if ((DateTime.Now.Year - _users[i].DateOfBirth.Year) > age)
                    _users.RemoveAt(i);
            } // for i
        } // RemoveAllOlderThan


        // Заменить все записи заданного знака этими же записями, но с добавлением строки "-бе-бе" к фамилии 
        public void ReplaceAllByZodiacSign(string zodiacSign) {
            for (int i = 0; i < _users.Count; i++){
                if (_users[i].ZodiacSign == zodiacSign) {
                    User temp = new User { DateOfBirth = _users[i].DateOfBirth, Id = _users[i].Id };
                    string[] strs = _users[i].Name.Split(" ".ToCharArray(), StringSplitOptions.RemoveEmptyEntries);
                    temp.Name = strs[0] + "-бе-бе " + strs[1];
                    _users[i] = temp;
                } // if
            } // for i
        } // ReplaceAllByZodiacSign


        public IEnumerator GetEnumerator() => _users.GetEnumerator();


        // Именованный итератор, возвращает только записи с заданной фамилией
        public IEnumerable GetBySurname(string surname) {
            foreach (var user in _users){
                if (user.Name.Contains(surname)) yield return user;
            } // foreach
        } // GetBySurname


        // Именованный итератор, возвращает только записи с заданным знаком Зодиака
        public IEnumerable GetByZodiacSign(string zodiacSign) {
            foreach (var user in _users) {
                if (user.ZodiacSign == zodiacSign) yield return user;
            } // foreach
        } // GetByZodiacSign


        // Именованный итератор, возвращает только записи с заданным месяцем рождения
        public IEnumerable GetByMonth(int month) {
            foreach (var user in _users) {
                if (user.DateOfBirth.Month == month) yield return user;
            } // foreach
        } // GetByMonth

    } // Department
}
