﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WPF_Figures_Materials.Views
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void MenuButton_Click(object sender, RoutedEventArgs e)
        {
            Button button = e.OriginalSource as Button;

            switch (button.Name)
            {
                case "Btn_Conoid":
                    Conoid_Window conoid_Window = new Conoid_Window();
                    conoid_Window.ShowDialog();
                    break;
                case "Btn_Sphere":

                    break;
                case "Btn_Cylinder":

                    break;
                case "Btn_Parallelepiped":

                    break;
                case "Btn_About":

                    break;
                default:
                    break;
            }
        }
    }
}
