﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace WPF_Figures_Materials.Utilities
{
    // вспомогательные методы и объекты - статический класс, т.е. класс,
    // содержащий только статические члены и методы
    public static class Utils
    {

        static public string EmptyResult = "----";
        
        // объект для получения случайных чисел
        public static Random Random = new Random();
        
        // формирование случайных вещественных чисел в диапазоне от lo до hi
        public static double GetRandom(double lo, double hi)
            => lo + (hi - lo)*Random.NextDouble();
        //Генерация случайных значений int
        public static int GetRandom(int lo, int hi)
            => Random.Next(lo, hi);

        //Создание URI для записи в Imgage source
        public static ImageSource BuiltSourceMaterial(string fName)
        {
            BitmapImage bti = new BitmapImage();
            bti.BeginInit();

            bti.UriSource = new Uri($"pack://application:,,,/Images/Materials/{fName}");

            bti.EndInit();

            return bti;
        }

    } // class Utils
}