﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WPF_Figures_Materials.Models
{
    internal class Materials
    {
        //Ассоциативный массив плотностей
        static public Dictionary<string, double> _density = new Dictionary<string, double> {
            {"Медь",8940d},
            {"Нержавейка",7900d},
            {"Водяной лед",920d},
            {"Гранит",2600d},
        };

        //Ассоциативный массив изображений материала
        static public Dictionary<string, string> _FileName = new Dictionary<string, string>
        {
            {"Медь","copper.png"},
            {"Нержавейка","steel.png"},
            {"Водяной лед","water_ice.png"},
            {"Гранит","granite"},

        };


    }
}
