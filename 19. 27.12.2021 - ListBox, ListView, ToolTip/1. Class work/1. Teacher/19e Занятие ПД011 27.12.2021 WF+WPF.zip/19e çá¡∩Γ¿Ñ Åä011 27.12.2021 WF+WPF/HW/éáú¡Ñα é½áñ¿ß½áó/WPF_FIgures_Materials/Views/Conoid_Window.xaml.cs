﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using WPF_Figures_Materials.Models;
using WPF_Figures_Materials.Utilities;

namespace WPF_Figures_Materials.Views
{
    /// <summary>
    /// Interaction logic for Conoid.xaml
    /// </summary>
    public partial class Conoid_Window : Window
    {
        //Конус
        private Conoid _conoid;
        public Conoid conoid
        {
            get => _conoid;
            set => _conoid = value;
        }

        //Все ли элементны проинициализированы
        bool Initialized = false;

        public Conoid_Window():this(new Conoid())
        {
            InitializeComponent();

            TxbTop.Text =   _conoid.RadiusUp.ToString();
            TbxDown.Text =  _conoid.RadiusDown.ToString();
            TbxHight.Text = _conoid.Height.ToString();

            Initialized = true;

            //Расчёт всего 
            CountConoid();
        }

        public Conoid_Window(Conoid cone)
        {
            conoid = cone;
        }

        //Расчёт величин
        private void CountConoid()
        {
            if (_conoid == null)
                return;

            //Вывод результатов 
            TbxOutSquare.Text = Cbk_Square.IsChecked == true ? $"{_conoid.Area:f2} M^2" : "Не расчитывается";
            TbxOutVolume.Text = Cbk_Volume.IsChecked == true ? $"{_conoid.Volume:f2} M^3" : "Не расчитывается";
            TbxOutMass.Text = Cbk_Wegiht.IsChecked == true ? $"{_conoid.Mass:f2} КГ" : "Не расчитывается";

        }

        //Изменение состояния радио-кнопки
        private void Rbt_Material_Checked(object sender, RoutedEventArgs e)
        {
            RadioButton rbtn = e.OriginalSource as RadioButton;
            if (rbtn == null)
                return;

            //Задаём значения из ассоциативных массивов 
            string MaterialName = rbtn.Content.ToString();

            //Img_Material.Source = Utils.BuiltSourceMaterial(Materials._FileName[MaterialName]);
            _conoid.Density = Materials._density[MaterialName];

            TbxDensityRead.Text = $"Плотность \"{MaterialName.ToLower()}\":";
            TbxDensity.Text = _conoid.Density.ToString();

            if (Initialized) 
                CountConoid();
        }

        private void TbxFigure_TextChanged(object sender, TextChangedEventArgs e)
        {
            TextBox tbx = e.OriginalSource as TextBox;

            if (tbx == null || !Initialized)
                return;

            double value = 0d;

            if (!double.TryParse(tbx.Text, out value))
            {
                CleanFields();
                return;
            }
            //Если верхний радиус
            if (tbx.Name.Contains("Top"))
            {
                _conoid.RadiusUp = value;
                CountConoid();
            }
            //Если нижний радиус
            else if (tbx.Name.Contains("Down"))
            {
                _conoid.RadiusDown = value;
                CountConoid();
            }
            //Если высота
            else if (tbx.Name.Contains("Hight"))
            {
                _conoid.RadiusDown = value;
                CountConoid();
            }

        }

        //Очистка полей
        private void CleanFields()
        {
            TbxOutMass.Text = TbxOutSquare.Text = TbxOutVolume.Text = Utils.EmptyResult;
        }
    }
}
