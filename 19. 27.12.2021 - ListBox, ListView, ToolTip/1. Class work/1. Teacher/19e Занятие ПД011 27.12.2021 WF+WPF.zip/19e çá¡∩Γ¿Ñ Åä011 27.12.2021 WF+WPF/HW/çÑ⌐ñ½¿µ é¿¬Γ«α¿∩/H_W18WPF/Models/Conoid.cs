﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace H_W18WPF.Models {
    // Усеченный конус
    public class Conoid {
         // радиус нижнего основания
        private double _radius1;
        public double Radius1 {
            get => _radius1;
            set {
                if (value <= 0)
                    throw new ArgumentException("Conoid. Отрицательное или нулевое нижнее основание");
                _radius1 = value;
            } // set
        } // Radius1


        // радиус верхнего основания
        private double _radius2;
        public double Radius2 {
            get => _radius2;
            set {
                if (value <= 0)
                    throw new ArgumentException("Conoid. Отрицательное или нулевое верхнее основание");
                _radius2 = value;
            } // set
        } // Radius2


        // высота
        private double _height;
        public double Height {
            get => _height;
            set {
                if (value <= 0)
                    throw new ArgumentException("Conoid. Отрицательная или нулевая высота");
                _height = value;
            } // set
        } // Height



        // образующая
        public double L {
            get => Math.Sqrt(_height * _height + (_radius1 - _radius2) * (_radius1 - _radius2));
        } // L


        // плотность материала
        private double _density;
        public double Density {
            get => _density;
            set {
                if (value <= 0)
                    throw new ArgumentException("Conoid. Отрицательная или нулевая плотность материала");
                _density = value;
            } // set
        } // Density

        // конструкторы объекта класса
        public Conoid() : this(1d, 1d, 1d, 1d) { }
        public Conoid(double r1, double r2, double h, double d)
        {
            Radius1 = r1;
            Radius2 = r2;
            Height = h;
            Density = d;
        } // Conoid


        // Вычисление площади  конуса
        public double CalcArea() => 
            Math.PI * (_radius1 * _radius1 + (_radius1 * _radius2) * L + _radius2 * _radius2);


        // Вычисление объема конуса
        public double CalcVolume() => 
            1d / 3d * Math.PI * _height * (_radius1 * _radius1 + _radius1 * _radius2 + _radius2 * _radius2);


        // Вычисление массы конуса
        public double CalcMassa() =>
            CalcVolume() * Density;

        // строковое представление конуса (метод ToString(), выводить только
        // радиусы, высоту и плотность) 
        public override string ToString() =>
            $"радиус основания: {_radius1:f3}; верхний радиус: {_radius2:f3}; " +
            $"высота: {_height:f3}; плотность: {_density:f3}";

    } // class Conoid
}
