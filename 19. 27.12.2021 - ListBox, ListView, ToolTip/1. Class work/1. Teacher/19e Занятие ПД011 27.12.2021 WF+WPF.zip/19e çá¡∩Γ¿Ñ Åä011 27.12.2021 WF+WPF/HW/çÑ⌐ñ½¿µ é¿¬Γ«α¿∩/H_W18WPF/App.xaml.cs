﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;

namespace H_W18WPF
{
    /// <summary>
    /// Логика взаимодействия для App.xaml
    /// </summary>
    public partial class App : Application
    {
        public const double steelDensity = 7950d, // плотность стали (нержавеющей)
                   copperDensity = 8900d, // плотность меди
                      iceDensity = 920d,  // плотность водяного льда
                  graniteDensity = 2700d; // плотность гранита
    }
}
