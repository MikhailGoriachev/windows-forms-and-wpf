﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using H_W18WPF.Models;

namespace H_W18WPF.Views
{
    /// <summary>
    /// Логика взаимодействия для CylinderWindow.xaml
    /// </summary>
    public partial class CylinderWindow : Window
    {
        // Модель - цилиндр
        private Cylinder _cylinder;

        public CylinderWindow() : this(new Cylinder()) { }

        public CylinderWindow(Cylinder cylinder)
        {
            InitializeComponent();
            _cylinder = cylinder;

            // Записать значения модели в элементы интерфейса, поля ввода
            TxbTop.Text = $"{_cylinder.Radius:n3}";
            TxbHeight.Text = $"{_cylinder.Height:n3}";
            TxbDensity.Text = $"{_cylinder.Density:n3}";
        } // CylinderWindow

        // закрытие окна
        private void Close_Click(object sender, RoutedEventArgs e) => Close();

        // Изменение цвета надписи на кнопке при перемещении курсора мыши на кнопку
        private void Button_MouseEnter(object sender, MouseEventArgs e)
        {
            Button btn = e.OriginalSource as Button;
            btn.Foreground = new SolidColorBrush(Color.FromArgb(255, 0, 0, 0));
        } // Button_MouseEnter

        private void Button_MouseLeave(object sender, MouseEventArgs e)
        {
            Button btn = e.OriginalSource as Button;
            btn.Foreground = new SolidColorBrush(Colors.White);
        } // Button_MouseLeave

        // Обработичк клика по радиокнопке Rb1: загрузка stal.jpg в Image
        private void Rb1_Checked(object sender, RoutedEventArgs e)
        {
            _cylinder.Density = App.steelDensity;

            ImgMaterial.Source = BuildImageSource("stal.jpg");
        }//Rb1_Checked 

        private void Rb2_Checked(object sender, RoutedEventArgs e)
        {
            _cylinder.Density = App.copperDensity;

            ImgMaterial.Source = BuildImageSource("copper.jpg");
        }// Rb2_Checked

        private void Rb3_Checked(object sender, RoutedEventArgs e)
        {
            _cylinder.Density = App.iceDensity;

            ImgMaterial.Source = BuildImageSource("ice.jpg");
        }// Rb3_Checked


        private void Rb4_Checked(object sender, RoutedEventArgs e)
        {
            _cylinder.Density = App.graniteDensity;

            ImgMaterial.Source = BuildImageSource("granite1.jpg");
        }// Rb4_Checked


        private ImageSource BuildImageSource(string fileName)
        {
            BitmapImage image = new BitmapImage();
            image.BeginInit();
            image.UriSource = new Uri($"/Images/{fileName}", UriKind.Relative);
            image.EndInit();

            return image;
        } // BuildImageSource


        // вычисление цилиндра
        private void Calculate_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // Получить данные от элементов управления
                _cylinder.Radius = double.Parse(TxbTop.Text);
                _cylinder.Height = double.Parse(TxbHeight.Text);
                //_cylinder.Density = double.Parse(TxbDensity.Text);

                // Вычислить параметры тела в зависимости от установленных чек-боксов
                TblArea.Text = CbxArea.IsChecked == true
                    ? $"{_cylinder.CalcArea():n3}"
                    : "Расчет не задан";

                TblVolume.Text = CbxVolume.IsChecked == true
                    ? $"{_cylinder.CalcVolume():n3}"
                    : "Расчет не задан";

                TblMass.Text = CbxMass.IsChecked == true
                    ? $"{_cylinder.CalcMassa():n3}"
                    : "Расчет не задан";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            } // try-catch
        } // Calculate_Click

    }// class CylinderWindow
}
