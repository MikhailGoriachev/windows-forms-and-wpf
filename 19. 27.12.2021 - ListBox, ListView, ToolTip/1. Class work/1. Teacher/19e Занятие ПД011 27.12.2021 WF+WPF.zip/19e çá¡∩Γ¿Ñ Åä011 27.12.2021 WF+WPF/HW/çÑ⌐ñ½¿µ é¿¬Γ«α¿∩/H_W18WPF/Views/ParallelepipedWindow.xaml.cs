﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using H_W18WPF.Models;

namespace H_W18WPF.Views
{
    /// <summary>
    /// Логика взаимодействия для ParallelepipedWindow.xaml
    /// </summary>
    public partial class ParallelepipedWindow : Window
    {

        private Parallelepiped _parallelepiped;
        public ParallelepipedWindow() : this(new Parallelepiped()) { }

        public ParallelepipedWindow(Parallelepiped parallelepiped)
        {
            InitializeComponent();
            _parallelepiped = parallelepiped;

            // Записать значения модели в элементы интерфейса, поля ввода
            TxbBottom.Text = $"{_parallelepiped.A:n3}";
            TxbTop.Text = $"{_parallelepiped.B:n3}";
            TxbHeight.Text = $"{_parallelepiped.C:n3}";
            TxbDensity.Text = $"{_parallelepiped.Density:n3}";
        } // ConoidWindow

        // закрытие окна
        private void Close_Click(object sender, RoutedEventArgs e) => Close();

        // Изменение цвета надписи на кнопке при перемещении курсора мыши на кнопку
        private void Button_MouseEnter(object sender, MouseEventArgs e)
        {
            Button btn = e.OriginalSource as Button;
            btn.Foreground = new SolidColorBrush(Color.FromArgb(255, 0, 0, 0));
        } // Button_MouseEnter

        private void Button_MouseLeave(object sender, MouseEventArgs e)
        {
            Button btn = e.OriginalSource as Button;
            btn.Foreground = new SolidColorBrush(Colors.White);
        } // Button_MouseLeave

        // Обработчик клика по радиокнопке Rb1: загрузка stal.jpg в Image
        private void Rb1_Checked(object sender, RoutedEventArgs e)
        {
            _parallelepiped.Density = App.steelDensity;

            ImgMaterial.Source = BuildImageSource("stal.jpg");
        }//Rb1_Checked 

        private void Rb2_Checked(object sender, RoutedEventArgs e)
        {
            _parallelepiped.Density = App.copperDensity;

            ImgMaterial.Source = BuildImageSource("copper.jpg");
        }// Rb2_Checked

        private void Rb3_Checked(object sender, RoutedEventArgs e)
        {
            _parallelepiped.Density = App.iceDensity;

            ImgMaterial.Source = BuildImageSource("ice.jpg");
        }// Rb3_Checked


        private void Rb4_Checked(object sender, RoutedEventArgs e)
        {
            _parallelepiped.Density = App.graniteDensity;

            ImgMaterial.Source = BuildImageSource("granite1.jpg");
        }// Rb4_Checked


        private ImageSource BuildImageSource(string fileName)
        {
            BitmapImage image = new BitmapImage();
            image.BeginInit();
            image.UriSource = new Uri($"/Images/{fileName}", UriKind.Relative);
            image.EndInit();

            return image;
        } // BuildImageSource

        // вычисление прямоугольного параллелепипеда
        private void Calculate_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // Получить данные от элементов управления
                _parallelepiped.A = double.Parse(TxbTop.Text);
                _parallelepiped.B = double.Parse(TxbBottom.Text);
                _parallelepiped.C = double.Parse(TxbHeight.Text);
                //_parallelepiped.Density = double.Parse(TxbDensity.Text);

                // Вычислить параметры тела в зависимости от установленных чек-боксов
                TblArea.Text = CbxArea.IsChecked == true
                    ? $"{_parallelepiped.CalcArea():n3}"
                    : "Расчет не задан";

                TblVolume.Text = CbxVolume.IsChecked == true
                    ? $"{_parallelepiped.CalcVolume():n3}"
                    : "Расчет не задан";

                TblMass.Text = CbxMass.IsChecked == true
                    ? $"{_parallelepiped.CalcMassa():n3}"
                    : "Расчет не задан";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            } // try-catch
        } // Calculate_Click

    }// class ParallelepipedWindow
}
