﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using H_W18WPF.Views;

namespace H_W18WPF
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        // Завершить работу приложения
        private void Exit_Click(object sender, RoutedEventArgs e) => Close();


        // Открыть окно со сведениями о приложении и разработчике
        private void About_Click(object sender, RoutedEventArgs e)
        {
            AboutWindow aboutWindow = new AboutWindow();
            aboutWindow.ShowDialog();
        } // About_Click


        // Изменение цвета надписи на кнопке при перемещении курсора мыши на кнопку
        private void Button_MouseEnter(object sender, MouseEventArgs e)
        {
            Button btn = e.OriginalSource as Button;
            btn.Foreground = new SolidColorBrush(Color.FromArgb(255, 0, 0, 0));
        } // Button_MouseEnter

        private void Button_MouseLeave(object sender, MouseEventArgs e)
        {
            Button btn = e.OriginalSource as Button;
            btn.Foreground = new SolidColorBrush(Colors.White);
        } // Button_MouseLeave


        // Расчет усеченного конуса
        private void ConoidCalc_Click(object sender, RoutedEventArgs e)
        {
            ConoidWindow conoidWindow = new ConoidWindow();
            conoidWindow.ShowDialog();
        } // ConoidCalc_Click


        // Расчет сферы
        private void SphereCalc_Click(object sender, RoutedEventArgs e)
        {
            SphereWindow sphere = new SphereWindow();
            sphere.ShowDialog();
        } // SphereCalc_Click

        // Расчет цилиндра
        private void CylinderCalc_Click(object sender, RoutedEventArgs e)
        {
            CylinderWindow cylinder = new CylinderWindow();
            cylinder.ShowDialog();
        } // CylinderCalc_Click


        // Расчет прямоугольного параллелепипеда
        private void ParallelepipedCalc_Click(object sender, RoutedEventArgs e)
        {
            ParallelepipedWindow parallelepiped = new ParallelepipedWindow();
            parallelepiped.ShowDialog();
        } // ParallelepipedCalc_Click

    }// class MainWindow
}
