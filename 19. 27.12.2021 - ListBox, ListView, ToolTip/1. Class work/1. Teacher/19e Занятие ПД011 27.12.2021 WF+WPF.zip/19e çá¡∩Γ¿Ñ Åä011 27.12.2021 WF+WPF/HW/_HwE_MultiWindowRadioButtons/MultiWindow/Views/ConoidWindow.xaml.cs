﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using MultiWindow.Helpers;
using MultiWindow.Models;

namespace MultiWindow.Views
{
    /// <summary>
    /// Логика взаимодействия для ConoidWindow.xaml
    /// </summary>
    public partial class ConoidWindow : Window
    {
        // Модель - усеченный конус
        private Conoid _conoid;

        public ConoidWindow() : this(new Conoid()) { }

        public ConoidWindow(Conoid conoid) {
            InitializeComponent();
            _conoid = conoid;

            // Записать значения модели в элементы интерфейса, поля ввода
            TxbBottom.Text = $"{_conoid.RadiusDown:n3}";
            TxbTop.Text = $"{_conoid.RadiusUp:n3}";
            TxbHeight.Text = $"{_conoid.Height:n3}";
            TxbDensity.Text = $"{_conoid.Density:n3}";

            // хардкодим :( 
            // установить соответствующую радиокнопку и изображение по плотности
            // по умолчанию плотность - плотность стали
            RbtSteel.IsChecked = true;
            ImgMaterial.Source = Utils.BuildImageSource( Materials.Data["steel"].ImageFile);
        } // ConoidWindow


        #region Изменение цвета надписи на кнопке при перемещении курсора мыши на кнопку
        private void Button_MouseEnter(object sender, MouseEventArgs e) {
            Button btn = e.OriginalSource as Button;
            btn.Foreground = new SolidColorBrush(Color.FromArgb(255, 0, 0, 0));
        } // Button_MouseEnter

        private void Button_MouseLeave(object sender, MouseEventArgs e) {
            Button btn = e.OriginalSource as Button;
            btn.Foreground = new SolidColorBrush(Colors.White);
        } // Button_MouseLeave
        #endregion

        
        // обработчик установки радиокнопок выбора материала, из которого создано тело
        private void RbtMaterial_Checked(object sender, EventArgs e) {
            RadioButton rbt = sender as RadioButton;
            MaterialViewModel viewModel = Materials.Data[(string) rbt.Tag];
            
            // задать картинку материала
            ImgMaterial.Source = Utils.BuildImageSource(viewModel?.ImageFile);

            // задать плотность материала
            _conoid.Density = viewModel.Density;

            // отобразить плотность материала в TextBox
            TxbDensity.Text = $"{_conoid.Density:f3}";

            // т.к. данные для расчета изменились, очищаем поле вывода результата
            TblArea.Text = TblVolume.Text = TblMass.Text = Utils.EmptyResult;
        } // RbtMaterial_Click


        // вычичсление для объемного тела по заданию
        private void Calculate_Click(object sender, RoutedEventArgs e) {
            try {
                // Получить данные от элементов управления
                _conoid.RadiusUp = double.Parse(TxbTop.Text);
                _conoid.RadiusDown = double.Parse(TxbBottom.Text);
                _conoid.Height = double.Parse(TxbHeight.Text);
                _conoid.Density = double.Parse(TxbDensity.Text);

                // Вычислить параметры тела в зависимости от установленных чек-боксов
                TblArea.Text = CbxArea.IsChecked == true
                    ? $"{_conoid.Area:n3}"
                    : Utils.CalcDontNeed;

                TblVolume.Text = CbxVolume.IsChecked == true
                    ? $"{_conoid.Volume:n3}"
                    : Utils.CalcDontNeed;

                TblMass.Text = CbxMass.IsChecked == true
                    ? $"{_conoid.Mass:n3}"
                    : Utils.CalcDontNeed;
            } catch (Exception ex) {
                MessageBox.Show(ex.Message, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            } // try-catch
        } // Calculate_Click
    } // class ConoidWindow
}
