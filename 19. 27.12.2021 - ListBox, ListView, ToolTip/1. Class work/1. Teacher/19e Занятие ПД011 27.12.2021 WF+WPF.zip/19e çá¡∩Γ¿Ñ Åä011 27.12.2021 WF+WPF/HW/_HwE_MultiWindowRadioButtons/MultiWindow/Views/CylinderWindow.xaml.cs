﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using MultiWindow.Helpers;
using MultiWindow.Models;

namespace MultiWindow.Views
{
    /// <summary>
    /// Логика взаимодействия для CylinderWindow.xaml
    /// </summary>
    public partial class CylinderWindow : Window
    {
        // Модель - цилиндр
        private Cylinder _cylinder;

        public CylinderWindow() : this(new Cylinder()) { }

        public CylinderWindow(Cylinder cylinder) {
            InitializeComponent();
            _cylinder = cylinder;

            // Записать значения модели в элементы интерфейса, поля ввода
            TxbRadius.Text  = $"{_cylinder.Radius:n3}";
            TxbHeight.Text  = $"{_cylinder.Height:n3}";
            TxbDensity.Text = $"{_cylinder.Density:n3}";

            // хардкодим :( 
            // установить соответствующую радиокнопку и изображение по плотности
            // по умолчанию плотность - плотность стали
            RbtSteel.IsChecked = true;
            ImgMaterial.Source = Utils.BuildImageSource(Materials.Data["steel"].ImageFile);
        } // CylinderWindow


        #region Изменение цвета надписи на кнопке при перемещении курсора мыши на кнопку
        private void Button_MouseEnter(object sender, MouseEventArgs e) {
            Button btn = e.OriginalSource as Button;
            btn.Foreground = new SolidColorBrush(Color.FromArgb(255, 0, 0, 0));
        } // Button_MouseEnter

        private void Button_MouseLeave(object sender, MouseEventArgs e) {
            Button btn = e.OriginalSource as Button;
            btn.Foreground = new SolidColorBrush(Colors.White);
        } // Button_MouseLeave
        #endregion


        // обработчик установки радиокнопок выбора материала, из которого создано тело
        private void RbtMaterial_Checked(object sender, EventArgs e) {
            RadioButton rbt = sender as RadioButton;
            MaterialViewModel viewModel = Materials.Data[(string) rbt.Tag];
            
            // задать картинку материала
            ImgMaterial.Source = Utils.BuildImageSource(viewModel?.ImageFile);

            // задать плотность материала
            _cylinder.Density = viewModel.Density;

            // отобразить плотность материала в TextBox
            TxbDensity.Text = $"{_cylinder.Density:f3}";

            // т.к. данные для расчета изменились, очищаем поле вывода результата
            TblArea.Text = TblVolume.Text = TblMass.Text = Utils.EmptyResult;
        } // RbtMaterial_Click


        // вычисление для объемного тела по заданию
        private void Calculate_Click(object sender, RoutedEventArgs e) {
            try {
                // Получить данные от элементов управления
                _cylinder.Radius = double.Parse(TxbRadius.Text);
                _cylinder.Height = double.Parse(TxbHeight.Text);
                _cylinder.Density = double.Parse(TxbDensity.Text);

                // Вычислить параметры тела в зависимости от установленных чек-боксов
                TblArea.Text = CbxArea.IsChecked == true
                    ? $"{_cylinder.Area:n3}"
                    : Utils.CalcDontNeed;

                TblVolume.Text = CbxVolume.IsChecked == true
                    ? $"{_cylinder.Volume:n3}"
                    : "Расчет не задан";

                TblMass.Text = CbxMass.IsChecked == true
                    ? $"{_cylinder.Mass:n3}"
                    : "Расчет не задан";
            } catch (Exception ex) {
                MessageBox.Show(ex.Message, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            } // try-catch
        } // Calculate_Click

    } // class CylinderWindow
}
