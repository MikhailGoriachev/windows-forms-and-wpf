﻿namespace Main.Common
{
	internal static class Routes
	{
		public const string DefaultRouteToResources = "pack://application:,,,/Resources";

		public static readonly string FiguresImages = $"{DefaultRouteToResources}/Figures Images";

		public static readonly string MaterialsImages = $"{DefaultRouteToResources}/Materials Images";
	}
}