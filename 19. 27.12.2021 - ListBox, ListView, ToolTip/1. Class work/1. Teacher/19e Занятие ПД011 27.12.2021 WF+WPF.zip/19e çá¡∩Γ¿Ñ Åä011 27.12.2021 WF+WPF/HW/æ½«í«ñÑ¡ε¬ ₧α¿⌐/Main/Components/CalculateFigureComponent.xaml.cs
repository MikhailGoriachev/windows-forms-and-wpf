﻿using System.Windows;
using System.Windows.Controls;
using Main.Models;


namespace Main.Components
{
	public sealed partial class CalculateFigureComponent : UserControl
	{
		public static readonly DependencyProperty FigureProperty = DependencyProperty.Register(
			"Figure", typeof(IFigure), typeof(CalculateFigureComponent), new PropertyMetadata(default(IFigure)));

		public IFigure Figure { get { return (IFigure)GetValue(FigureProperty); } set { SetValue(FigureProperty, value); } }


		public CalculateFigureComponent() =>
			InitializeComponent();


		private void CalculateButton_OnClick(object sender, RoutedEventArgs e)
		{
			if (AreaCheckBox.IsChecked == true)
				AreaOutput.Value = $"{(Figure?.Area() ?? 0):F2}";

			if (VolumeCheckBox.IsChecked == true)
				VolumeOutput.Value = $"{(Figure?.Volume() ?? 0):F2}";

			if (MassCheckBox.IsChecked == true)
				MassOutput.Value = $"{(Figure?.Mass() ?? 0):F2}";
		}
	}
}