﻿using System;
using Main.Common;


namespace Main.Models
{
	public sealed class Sphere : IFigure
	{
		public Uri ImageUri { get; } = new($"{Routes.FiguresImages}/{nameof(Sphere)}.png");

		public double Radius { get; set; }

		public double Density { get; set; }


		public double Area() => 4d * Math.PI * (Radius * Radius);


		public double Volume() => 4d / 3d * Math.PI * Math.Pow(Radius, 3);
	}
}