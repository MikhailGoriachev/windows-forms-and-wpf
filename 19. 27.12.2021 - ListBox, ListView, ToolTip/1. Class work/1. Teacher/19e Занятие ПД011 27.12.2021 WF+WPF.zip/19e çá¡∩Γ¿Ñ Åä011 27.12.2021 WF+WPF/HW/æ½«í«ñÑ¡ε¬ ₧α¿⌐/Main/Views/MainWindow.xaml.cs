﻿using System.Windows;


namespace Main.Views
{
	public sealed partial class MainWindow : Window
	{
		public MainWindow() => InitializeComponent();
	}
}