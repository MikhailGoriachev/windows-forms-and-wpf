﻿using System;
using System.Globalization;
using System.Windows.Data;


namespace Main.Common
{
	[ValueConversion(typeof(double), typeof(string))]
	internal sealed class StringDoubleConverter : IValueConverter
	{
		public object Convert(object value, Type targetType, object parameter, CultureInfo culture) =>
			((double)value).ToString();
			


		public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture) =>
			double.TryParse((string)value, out var d) ? d : default;
	}
}