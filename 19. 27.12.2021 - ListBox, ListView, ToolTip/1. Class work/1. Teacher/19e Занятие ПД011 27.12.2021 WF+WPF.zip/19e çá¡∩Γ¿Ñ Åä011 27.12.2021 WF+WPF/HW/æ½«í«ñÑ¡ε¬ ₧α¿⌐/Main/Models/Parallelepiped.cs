﻿using System;
using Main.Common;


namespace Main.Models
{
	public sealed class Parallelepiped : IFigure
	{
		public Uri ImageUri { get; } = new($"{Routes.FiguresImages}/{nameof(Parallelepiped)}.png");

		public double A { get; set; }

		public double B { get; set; }

		public double C { get; set; }

		public double Density { get; set; }


		public double Area() => 2d * (A * B + B * C + A * C);

		public double Volume() => A * B * C;
	}
}