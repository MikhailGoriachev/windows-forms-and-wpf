﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Figures.Views { 
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow() {
            InitializeComponent();
        }

        #region Изменение цвета надписи на кнопке при перемещении курсора мыши на кнопку
        private void Button_MouseEnter(object sender, MouseEventArgs e) {
            Button btn = e.OriginalSource as Button;
            btn.Foreground = new SolidColorBrush(Color.FromArgb(255, 0, 0, 0));
        } // Button_MouseEnter

        private void Button_MouseLeave(object sender, MouseEventArgs e) {
            Button btn = e.OriginalSource as Button;
            btn.Foreground = new SolidColorBrush(Colors.White);
        } // Button_MouseLeave
        #endregion
        private void Exit_Click(object sender, RoutedEventArgs e) => Close();

        // Открыть окно со сведениями о приложении и разработчике
        private void About_Click(object sender, RoutedEventArgs e) {
            AboutWindow aboutWindow = new AboutWindow();
            aboutWindow.ShowDialog();
        } // About_Click

        // Расчет учеченного конуса
        private void ConoidCalc_Click(object sender, RoutedEventArgs e) {
            ConoidWindow conoidWindow = new ConoidWindow();
            conoidWindow.ShowDialog();
        } // ConoidCalc_Click

        // Расчет сферы
        private void SphereCalc_Click(object sender, RoutedEventArgs e) {
            SphereWindow sphereWindow = new SphereWindow();
            sphereWindow.ShowDialog();
        } // SphereCalc_Click

        // Расчет цилиндра
        private void CylinderCalc_Click(object sender, RoutedEventArgs e) {
            CylinderWindow cylinderWindow = new CylinderWindow();
            cylinderWindow.ShowDialog();
        } // CylinderCalc_Click

        // Расчет параллелепипеда
        private void ParallelepipedCalc_Click(object sender, RoutedEventArgs e) {
            ParallelepipedWindow parallelepipedWindow = new ParallelepipedWindow();
            parallelepipedWindow.ShowDialog();
        } // ParallelepipedCalc_Click
    }
}
