﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Figures.Models;

namespace Figures.Views
{
    /// <summary>
    /// Логика взаимодействия для SphereWindow.xaml
    /// </summary>
    public partial class SphereWindow : Window
    {
        // Модель
        private Sphere _sphere;

        // представление для пустой строки результата
        private const string EmptyResult = "---''---";

        public SphereWindow() : this(new Sphere()) { }

        public SphereWindow(Sphere sphere) {
            InitializeComponent();
            _sphere = sphere;

            // Записать значения модели в элементы интерфейса, поля ввода
            TxbRadius.Text = $"{_sphere.Radius:n3}";
            TxbDensity.Text = $"{Materials.Data["steel"].Density:n3}";

            RbtCopper.Tag   = "copper";
            RbtGranite.Tag  = "granite";
            RbtSteel.Tag    = "steel";
            RbtWaterIce.Tag = "water_ice";
            RbtSteel.IsChecked = true;

            TxbRadius.TextChanged += TextBox_TextChanged;
        } // ParallelepipedWindow


        #region Изменение цвета надписи на кнопке при перемещении курсора мыши на кнопку
        private void Button_MouseEnter(object sender, MouseEventArgs e) {
            Button btn = e.OriginalSource as Button;
            btn.Foreground = new SolidColorBrush(Color.FromArgb(255, 0, 0, 0));
        } // Button_MouseEnter

        private void Button_MouseLeave(object sender, MouseEventArgs e) {
            Button btn = e.OriginalSource as Button;
            btn.Foreground = new SolidColorBrush(Colors.White);
        } // Button_MouseLeave
        #endregion

        // закрытие окна
        private void Close_Click(object sender, RoutedEventArgs e) => Close();

        // вычисление параметров по заданию
        private void Calculate_Click(object sender, RoutedEventArgs e) {
            try {
                // Получить данные от элементов управления
                _sphere.Radius = double.Parse(TxbRadius.Text);

                // Вычислить параметры тела в зависимости от установленных чек-боксов
                TblArea.Text = CbxArea.IsChecked == true
                    ? $"{_sphere.Area:n3}"
                    : "Расчет не задан";

                TblVolume.Text = CbxVolume.IsChecked == true
                    ? $"{_sphere.Volume:n3}"
                    : "Расчет не задан";

                TblMass.Text = CbxMass.IsChecked == true
                    ? $"{_sphere.Mass:n3}"
                    : "Расчет не задан";
            }
            catch (Exception ex) {
                MessageBox.Show(ex.Message, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            } // try-catch
        } // Calculate_Click

        // обработчик кликов по радиокнопкам выбора материала, из которого создано тело
        private void RadioButton_Checked(object sender, RoutedEventArgs e) {
            RadioButton rbt = e.OriginalSource as RadioButton;
            MaterialViewModel viewModel = Materials.Data[(string)rbt.Tag];

            _sphere.Density = viewModel.Density;

            TxbDensity.Text = $"{_sphere.Density:n3}";
            ImgMaterial.Source = new BitmapImage(new Uri($"../Images/Materials/{viewModel.ImageFile}", UriKind.Relative));
            // очищаем поле вывода результата
            TblArea.Text = TblMass.Text = TblVolume.Text = EmptyResult;
        } // RadioButton_Checked

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e) {
            // очищаем поле вывода результата
            TblArea.Text = TblMass.Text = TblVolume.Text = EmptyResult;
        } // TextBox_TextChanged
    }
}
