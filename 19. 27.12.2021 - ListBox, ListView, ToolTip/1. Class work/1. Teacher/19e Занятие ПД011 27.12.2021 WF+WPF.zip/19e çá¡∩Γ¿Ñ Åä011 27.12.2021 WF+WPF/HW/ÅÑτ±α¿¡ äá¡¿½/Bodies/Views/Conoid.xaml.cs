﻿using Figures;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;


namespace Bodies.Views
{
    /// <summary>
    /// Interaction logic for Conoid.xaml
    /// </summary>
    public partial class Conoid : Window
    {
        //Модель - усеченный конус
        private Cone _conoid;

        
        public Conoid(Cone conoid)
        {
            InitializeComponent();
            _conoid = conoid;

            //Записать значения модели в элементы интерфейса
            TxtbxBottom.Text = $"{_conoid.Radius}";
            TxbTop.Text = $"{_conoid.Radius2}";
            TxtDensity.Text = $"{_conoid.Density}";
            TxtHeight.Text = $"{_conoid.Height}";


        }



        private void Button_MouseEnter(object sender, MouseEventArgs e)
        {

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {

        }

        private void Calculate_Click(object sender, RoutedEventArgs e)
        {
            Cone conoid = new Cone();
            conoid.Radius = Convert.ToDouble(TxtbxBottom.Text);
            conoid.Radius2 = Convert.ToDouble(TxbTop.Text);
            conoid.Height = Convert.ToDouble(TxtHeight.Text);
            if(CbxArea.IsChecked== true)
            {
                TblArea.Text = conoid.CalcArea().ToString();

            }
            if(CbxMass.IsChecked == true)
            {
                TblMass.Text =  conoid.CalcMass().ToString();
            }
            if(CbxVolume.IsChecked == true)
            {
                TblVolume.Text = conoid.CalcVoulume().ToString();
            }
        }

        private void Button_MouseLeave(object sender, MouseEventArgs e)
        {

        }

        private void Clock_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
