﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HomeWorkWPFFiguresMaterials.Models
{
    // усеченный конус
    public class Conoid
    {
        // радиус нижнего основания
        private double _r1;
        public double R1
        {
            get { return _r1; }
            set
            {
                if (value <= 0)
                    throw new Exception("Conoid: ошибка радиуса нижнего основания");
                _r1 = value;
            }
        }

        // радиус верхнего основания
        private double _r2;
        public double R2
        {
            get { return _r2; }
            set
            {
                if (value <= 0)
                    throw new Exception("Conoid: ошибка радиуса верхнего основания");
                _r2 = value;
            }
        }

        // высота
        private double _h;
        public double H
        {
            get { return _h; }
            set
            {
                if (value <= 0)
                    throw new Exception("Conoid: ошибка высоты");
                _h = value;
            }
        }

        // плотность
        private double _p;
        public double P
        {
            get { return _p; }
            set
            {
                if (value <= 0)
                    throw new Exception("Conoid: ошибка плотности");
                _p = value;
            }
        }

        // образующая
        public double L { get; private set; }

        // конструкторы
        public Conoid() : this(1d, 1d, 1d, 1d) { }
        public Conoid(double r1, double r2, double h, double p)
        {
            R1 = r1;
            R2 = r2;
            H = h;
            P = p;
            GetL();
        }

        // вычисление образующей
        private void GetL()
        {
            L = Math.Sqrt(_h * _h + Math.Pow((_r1 - _r2), 2));
        }

        // вычисление объема        
        public double GetV()
        {
            return (1d / 3d) * Math.PI * _h * (_r1 * _r1 + _r1 * _r2 + _r2 * _r2);
        }

        // вычисление полной площади поверхности
        public double GetS()
        {
            GetL();
            return Math.PI * (_r1 * _r1 + ((_r1 + _r2) * L) + _r2 * _r2);
        }

        // вычисление массы
        public double GetMass()
        {
            return GetV() * _p;
        }



    }
}
