﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HomeWorkWPFFiguresMaterials.Models
{
    public class Rectangular
    {
        // сторона а
        private double _a;

        public double A
        {
            get { return _a; }
            set
            {
                if (value <= 0)
                    throw new Exception("Rectangular: ошибка стороны а ");
                _a = value;
            }
        }

        // сторона б
        private double _b;

        public double B
        {
            get { return _b; }
            set
            {
                if (value <= 0)
                    throw new Exception("Rectangular: ошибка стороны b ");
                _b = value;
            }
        }

        // высота
        private double _h;

        public double H
        {
            get { return _h; }
            set
            {
                if (value <= 0)
                    throw new Exception("Rectangular: ошибка высоты ");
                _h = value;
            }
        }

        private double _p;

        public double P
        {
            get => _p;
            set
            {
                if (value <= 0)
                    throw new Exception("Rectangular: ошибка плотности");
                _p = value;
            }
        }

        public Rectangular() : this(1d, 1d, 1d, 1d) { }

        public Rectangular(double a, double b, double h, double p)
        {
            A = a;
            B = b;
            H = h;
            P = p;
        }

        // площадь
        public double GetS() => 2 * (_a * _b + _a * _h + _b * _h);

        // объем 
        public double GetV() => _a * _b * _h;

        // масса 
        public double GetMass() => _p * GetV();


    }
}