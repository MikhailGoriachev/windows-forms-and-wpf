﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HomeWorkWPFFiguresMaterials.Models
{
    // цилиндр
    public class Cylinder
    {
        // радиус
        private double _r;

        public double R
        {
            get => _r;
            set
            {
                if (value <= 0)
                    throw new Exception("Cylinder: ошибка радиуса ");
                _r = value;
            }
        }

        // высота
        private double _h;

        public double H
        {
            get => _h;
            set
            {
                if (value <= 0)
                    throw new Exception("Cylinder: ошибка высоты ");
                _h = value;
            }
        }

        // плотность
        private double _p;

        public double P
        {
            get => _p;
            set
            {
                if (value <= 0)
                    throw new Exception("Cylinder: ошибка плотности");
                _p = value;
            }
        }

        public Cylinder() : this(1d, 1d, 1d) { }

        public Cylinder(double r, double h, double d)
        {
            R = r;
            H = h;
            P = d;
        }

        // методы для расчета параметров цилиндра 

        // площадь
        public double GetS() => 2 * Math.PI * _r * _h;

        // объем 
        public double GetV() => Math.PI * _r * _r * _h;

        // масса 
        public double GetMass() => _p * GetV();
    }
}
