﻿using HomeWorkWPFFiguresMaterials.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace HomeWorkWPFFiguresMaterials
{
    /// <summary>
    /// Логика взаимодействия для ConoidWindow.xaml
    /// </summary>
    public partial class ConoidWindow : Window
    {
        // поле с фигурой
        private Conoid _conoid;

        // конструктор с зависимостями
        public ConoidWindow() : this(new Conoid()) { }

        // конструктор по умолчанию
        public ConoidWindow(Conoid conoid)
        {
            InitializeComponent();

            _conoid = conoid;

            Txb_r1.Text = $"{_conoid.R1}";
            Txb_r2.Text = $"{_conoid.R2}";
            Txb_h.Text = $"{_conoid.H}";
            Txb_p.Text = $"{_conoid.P}";

            Rbt_WaterIce.IsChecked = true;



            // очистка поля вывода результата
            Lbl_res_S.Content = "";
            Lbl_res_V.Content = "";
            Lbl_res_M.Content = "";

            // фокус на первом поле ввода
            Txb_r1.Focus();

        }

        // Calculate
        private void Calculate_Command(object sender, RoutedEventArgs e)
        {
            try
            {
                _conoid.R1 = double.Parse(Txb_r1.Text);
                _conoid.R2 = double.Parse(Txb_r2.Text);
                _conoid.H = double.Parse(Txb_h.Text);
                _conoid.P = double.Parse(Txb_p.Text);



                if (Cbx_S.IsChecked == true)
                    Lbl_res_S.Content = $"{_conoid.GetS():f3}";
                else
                    Lbl_res_S.Content = $"{"--//--"}";

                if (Cbx_V.IsChecked == true)
                    Lbl_res_V.Content = $"{_conoid.GetV():f3}";
                else
                    Lbl_res_V.Content = $"{"--//--"}";

                if (Cbx_M.IsChecked == true)
                    Lbl_res_M.Content = $"{_conoid.GetMass():f3}";
                else
                    Lbl_res_M.Content = $"{"--//--"}";


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            } // try-catch
        } // Geometric_Command


        // Очистка поля вывода результата при изменении значений в полях ввода
        private void TextChanged_Handler(object sender, TextChangedEventArgs e)
        {

            // очистка поля вывода результата
            Lbl_res_S.Content = "";
            Lbl_res_V.Content = "";
            Lbl_res_M.Content = "";
        } // TextChanged_Handler

        // радиокнопка для водяного льда
        private void Rbt_WaterIce_Checked(object sender, RoutedEventArgs e)
        {
            _conoid.P = 916.7;
            Txb_p.Text = $"{_conoid.P}";
            Img_material.Source = BuildImageSource("WaterIce.png");

        }

        // радиокнопка для гранита
        private void Rbt_Granite_Checked(object sender, RoutedEventArgs e)
        {
            _conoid.P = 2600;
            Txb_p.Text = $"{_conoid.P}";
            Img_material.Source = BuildImageSource("Granite.png");
        }

        // радиокнопка для меди
        private void Rbt_Copper_Checked(object sender, RoutedEventArgs e)
        {
            _conoid.P = 8940;
            Txb_p.Text = $"{_conoid.P}";
            Img_material.Source = BuildImageSource("Copper.png");
        }

        // радиокнока для нержавющей стали
        private void StainlessSteel_Checked(object sender, RoutedEventArgs e)
        {
            _conoid.P = 7701;
            Txb_p.Text = $"{_conoid.P}";
            Img_material.Source = BuildImageSource("StainlessSteel.png");

        }



        // формирование Uri из имени файла, файлы изображений в папке проекта
        // Images, действие при построении для каждого файла изображения - Resource
        // формат Uri для имени файла в ресурсах проекта
        // pack://application:,,,/Папка/файл.ext, так, для нашего проекта это будет
        // pack://application:,,,/Images/Cat0.jpg
        private ImageSource BuildImageSource(string fileName)
        {
            BitmapImage image = new BitmapImage();
            image.BeginInit();
            image.UriSource = new Uri($"E:/WindowsForms/18e Занятие ПД011 22.12.2021 WF+WPF/Поддубный Алексей/HomeWorkWPFFiguresMaterials/HomeWorkWPFFiguresMaterials/Images/Materials/{fileName}");
            image.EndInit();

            return image;
        } // BuildImageSource

        private void Button_Exit_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }


    }
}
