﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

using NET_Framework_WPF__2__ManyForms_.Models;

namespace NET_Framework_WPF__2__ManyForms_.Views
{
    /// <summary>
    /// Логика взаимодействия для ConoidWindow.xaml
    /// </summary>
    public partial class ConoidWindow : Window
    {

        // Модель - усчеченный конус
        private Conoid _conoid;
        
        // представление для пустой строки результата
        private const string EmptyResult = "--''--";

        public ConoidWindow() : this(new Conoid()) { }
        public ConoidWindow(Conoid conoid)
        {
            InitializeComponent();
            _conoid = conoid;


            RbtSteel.IsChecked = true;
            ImageSourceConverter imgs = new ImageSourceConverter();
            ImgMaterial.SetValue(Image.SourceProperty, imgs.ConvertFromString(@"..\..\Images\Materials\" + Materials.Data["steel"].ImageFile));

            // Записать значения модели в элементы интерфейса, поля ввода
            TxbBottom.Text = $"{_conoid.RadiusDown:n3}";
            TxbTop.Text = $"{_conoid.RadiusUp:n3}";
            TxbHeight.Text = $"{_conoid.Height:n3}";
            TxbDensity.Text = $"{_conoid.Density:n3}";
        } // ParallelepipedWindow


        private void Calculate_Click(object sender, RoutedEventArgs e)  {
            try
            {
                // Получить данные от элементов управления
                _conoid.RadiusUp = double.Parse(TxbTop.Text);
                _conoid.RadiusDown = double.Parse(TxbBottom.Text);
                _conoid.Height = double.Parse(TxbHeight.Text);

                // проверка на уровне модели
                if (_conoid.RadiusDown <= _conoid.RadiusUp)
                    throw new Exception($"Нижнее основание конуса меньше или равно верхнему");

                // Вычислить параметры тела в зависимости от установленных чек-боксов
                TblArea.Text = CbxArea.IsChecked == true
                    ? $"{_conoid.Area:n3}"
                    : "Расчет не задан";

                TblVolume.Text = CbxVolume.IsChecked == true
                    ? $"{_conoid.Volume:n3}"
                    : "Расчет не задан";

                TblMass.Text = CbxMass.IsChecked == true
                    ? $"{_conoid.Mass:n3}"
                    : "Расчет не задан";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            } // try-catch
        }

        private void RadioButton_Click(object sender, RoutedEventArgs e) {
            RadioButton rbt = e.OriginalSource as RadioButton;
            // TODO: Здесь проблема, как решается и в чем дело пока что не понял
            MaterialViewModel viewModel = Materials.Data[(string)rbt.Tag];
            
            // задать картинку материала
            ImageSourceConverter imgs = new ImageSourceConverter();
            ImgMaterial.SetValue(Image.SourceProperty, imgs.ConvertFromString(@"..\..\Images\Materials\" + viewModel?.ImageFile));

            // задать плотность материала
            _conoid.Density = viewModel.Density;

            // отобразить плотность материала в TextBox
            TxbDensity.Text = $"{_conoid.Density:f3}";
            TxbDensity.SelectionLength = 0;

            // т.к. данные для расчета изменились, очищаем поле вывода результата
            TblArea.Text = TblVolume.Text = TblMass.Text = EmptyResult;
        }

        #region Изменение цвета шрифта кнопки, при перемещение курсора на кнопку
        private void Button_MouseEnter(object sender, MouseEventArgs e) {
            Button btn = e.OriginalSource as Button;
            string tag = (string)btn.Tag;
            // проверка кнопка "Выход" или нет
            btn.Foreground = (tag == "BtnExit")
                ? Brushes.DimGray
                : Brushes.DarkGoldenrod;
        } // Button_MouseEnter

        private void Button_MouseLeave(object sender, MouseEventArgs e) {
            Button btn = (Button)sender;
            string tag = (string)btn.Tag;
            // проверка кнопка "Выход" или нет
            btn.Foreground = (tag == "BtnExit")
                ? Brushes.Black
                : Brushes.Gold;
        } // Button_MouseLeave
        #endregion

        // В разработке
        private void Txb_Changed(object sender, TextChangedEventArgs e) {
            // т.к. данные для расчета изменились, очищаем поле вывода результата
            // TblArea.Text = TblVolume.Text = TblMass.Text = EmptyResult;
        }
    }
}
