﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace NET_Framework_WPF__2__ManyForms_.Views
{
    /// <summary>
    /// Логика взаимодействия для AboutWindow.xaml
    /// </summary>
    public partial class AboutWindow : Window
    {
        public AboutWindow()
        {
            InitializeComponent();
        }

        #region Изменение цвета шрифта кнопки, при перемещение курсора на кнопку
        private void Button_MouseEnter(object sender, MouseEventArgs e)
        {
            Button btn = e.OriginalSource as Button;
            string tag = (string)btn.Tag;
            // проверка кнопка "Выход" или нет
            btn.Foreground = (tag == "BtnExit")
                ? Brushes.DimGray
                : Brushes.DarkGoldenrod;
        } // Button_MouseEnter

        private void Button_MouseLeave(object sender, MouseEventArgs e)
        {
            Button btn = (Button)sender;
            string tag = (string)btn.Tag;
            // проверка кнопка "Выход" или нет
            btn.Foreground = (tag == "BtnExit")
                ? Brushes.Black
                : Brushes.Gold;
        } // Button_MouseLeave 
        #endregion
    }
}
