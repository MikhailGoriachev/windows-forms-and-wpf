﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace PracticalWork.Models
{
    // Класс Пользователь
    public class User : DependencyObject
    {
        // минимальное значение возраста
        public static int MaxAge => 170;

        // максимальное значение возраста
        public static int MinAge => 0;

        // полное имя
        public string FullName
        {
            get => (string)GetValue(FullNameProperty);
            set => SetValue(FullNameProperty, value);
        }


        public static readonly DependencyProperty FullNameProperty;



        // возраст
        public int Age
        {
            get => (int)GetValue(AgeProperty);
            set => SetValue(AgeProperty, value);
        }

        public static readonly DependencyProperty AgeProperty;



        // оклад
        public int Salary
        {
            get => (int)GetValue(SalaryProperty);
            set => SetValue(SalaryProperty, value);
        }

        public static readonly DependencyProperty SalaryProperty;



        // город проживания
        public string City
        {
            get => (string)GetValue(CityProperty);
            set => SetValue(CityProperty, value);
        }

        public static readonly DependencyProperty CityProperty;


        static User()
        {
            // инициализация
            FullNameProperty = DependencyProperty.Register("FullName", typeof(string), typeof(User), 
                new PropertyMetadata { CoerceValueCallback = CorrectAge });
            AgeProperty      = DependencyProperty.Register("Age", typeof(int), typeof(User), new PropertyMetadata(0));
            SalaryProperty   = DependencyProperty.Register("Salary", typeof(int), typeof(User), new PropertyMetadata(0));
            CityProperty     = DependencyProperty.Register("City", typeof(string), typeof(User), new PropertyMetadata(0));



        }


        // корректировщик поля FullName
        // private static object CorrectFullName(DependencyObject d, object baseValue)
        // {
        //     // новое значение 
        //     string value = (string)baseValue;
        // 
        //     // если количество слов в строке меньше трёх
        //     //if (value.Split(' ').Length < 3)
        //     //    return
        // 
        // }


        // корректировщик поля Age
        private static object CorrectAge(DependencyObject d, object baseValue)
        {
            // новое значение 
            int value = (int)baseValue;

            return value < MinAge ? MinAge : value > MaxAge ? MaxAge : value;
        }
    }
}
