﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Json;
using System.Text;
using System.Threading.Tasks;
using Animals.Models;

namespace Animals.Controllers
{
    public class AnimalsController {
        // условное название коллекции 
        private string _name;
        public string Name {
            get => _name;
            set {
                if (string.IsNullOrEmpty(value))
                    throw new Exception("Пустая строка в названии коллекции");

                _name = value;
            } // set
        } // Name

        // коллекция объектов для обработки
        private List<Animal> _animals;
        public List<Animal> Animals {
            get => _animals;
            private set => _animals = value;
        } // Appliances

        // имя файла для сериализация в формате JSON
        private string _fileName;

        public string FileName {
            get => _fileName;
            set => _fileName = value;
        } // FileName

        // количестово объектов в коллекции
        public int Count => _animals.Count;

        // конструкторы
        public AnimalsController() : this("Ветеринарная клиника", new List<Animal>(), @"App_Data\Animals.json") {
            Generate(20);
        } // AnimalsController

        public AnimalsController(string name, List<Animal> animals, string fileName) {
            _name = name;
            _animals = animals;
            _fileName = fileName;
        } // FlatController


        // формирование заданного количества объектов в коллекции
        public void Generate(int n) {
            _animals.Clear();

            for (int i = 0; i < n; i++)
                _animals.Add(Animal.Generate());
        } // Generate

        // Удаление объекта
        public void RemoveAnimal(int index) => _animals.RemoveAt(index);

        // Добавление объекта в коллекцию
        public void AddAnimal(Animal animal) => _animals.Insert(0, animal);

        // Редактирование объекта 
        public void EditAnimal(int index, Animal animal) => _animals[index] = animal;

        // индексатор 
        public Animal this[int index] {
            get => _animals[index];
            set => _animals[index] = value;
        } // indexer

        // Упорядочивание копии коллекции
        public List<Animal> OrderBy(Comparison<Animal> comparison) {
            List<Animal> temp = _animals;
            temp.Sort(comparison);
            return temp;
        } // OrderBy

        // Выборка 
        public List<Animal> SelectAnimals(Predicate<Animal> predicate) =>
            _animals.FindAll(predicate);

        // максимальный вес животного
        public double MaxWeight() {
            double max = _animals[0].Weight;
            _animals.ForEach(x => max = x.Weight > max ? x.Weight : max);
            return max;
        } // MaxWeight

        // минимальный вес животного
        public double MinWeight() {
            double min = _animals[0].Weight;
            _animals.ForEach(x => min = x.Weight < min ? x.Weight : min);
            return min;
        } // MaxWeight

        // выборка коллекции животных с максимальным весом
        public List<Animal> SelectAnimalsWhereMaxWeight() {
            double max = MaxWeight();
            return SelectAnimals(x => x.Weight == max);
        } // SelectAnimalsWhereMaxWeight

        // выборка коллекции животных, фамилия владельцев которых
        // содержит заданную подстроку(подстроку вводить в этой же вкладке)
        public List<Animal> SelectAnimalsWhereOwner(string str) =>
            SelectAnimals(x => x.Owner.Contains(str));


        // отсортированную по возрасту копию коллекции животных
        public List<Animal> OrderByAge() => OrderBy((x, y) => x.Age.CompareTo(y.Age));

        // отсортированную по виду копии коллекции животных
        public List<Animal> OrderByType() => OrderBy((x, y) => x.Type.CompareTo(y.Type));

        // отсортированную по фамилиям владельцев копию коллекции животных
        public List<Animal> OrderByOwner() => OrderBy((x, y) => x.Owner.CompareTo(y.Owner));

        // список видов животных из коллекции
        public List<string> GetTypes() {
            Dictionary<string, int> types = new Dictionary<string, int>();
            
            _animals.ForEach(t => types[t.Type] = 0);

            return types.Keys.ToList();
        } // GetRooms

        // сериализация в формате JSON
        public void Serialization(string fileName) {
            DataContractJsonSerializer jsonFormatter = new DataContractJsonSerializer(typeof(List<Animal>));

            using (FileStream fs = new FileStream(fileName, FileMode.Create))
                jsonFormatter.WriteObject(fs, _animals);
        } // Serialization

        // десериализация формате JSON
        public void Deserialization(string fileName) {
            DataContractJsonSerializer jsonFormatter = new DataContractJsonSerializer(typeof(List<Animal>));

            using (FileStream fs = new FileStream(fileName, FileMode.OpenOrCreate)) {
                _animals = (List<Animal>)jsonFormatter.ReadObject(fs);
            }
        } // Deserialization

    } // AnimalsController
}
