﻿using Animals.Controllers;
using Animals.Helpers;
using Animals.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Animals.Views
{
    public partial class MainForm : Form
    {

        private AnimalsController _animalsController;

        public MainForm() : this(new AnimalsController()) { } // MainForm

        public MainForm(AnimalsController animalsController) {
            InitializeComponent();

            _animalsController = animalsController;

            // Если папки и/или файл нет, то создать папку
            if (!File.Exists(@"App_data\" + _animalsController.FileName)) { 
                Directory.CreateDirectory(@"App_Data");
                _animalsController.Serialization(_animalsController.FileName);
            } 
            else {
                _animalsController.Deserialization(@"App_Data\" + _animalsController.FileName);
                WriteToListView(LsvAnimals, _animalsController.Animals);
            } // if


            // запись коллекции объектов в ListView для табличного отображения
            WriteToListView(LsvAnimals, _animalsController.Animals);
            WriteToTreeView(TrvAnimals, _animalsController);
            StlMain.Text = $"Коллекция сформирована. Текущее количество электроприборов: {_animalsController.Count}";
        } // MainForm


        private void Exit_Command(object sender, EventArgs e) => Application.Exit();

        private void About_Command(object sender, EventArgs e) {
            FormAbout formAbout = new FormAbout();
            formAbout.ShowDialog();
        } // About_Command

        // Сохранение данных 
        private void Save_Command(object sender, EventArgs e) =>
            _animalsController.Serialization(_animalsController.FileName);


        // Загрузка данных из выбранного файла
        private void Open_Command(object sender, EventArgs e) {
            OfdMain.Title = "Открыть файл";
            OfdMain.Filter = "Файлы JSON (*.json)|*.json";
            OfdMain.FilterIndex = 1;
            if (OfdMain.ShowDialog() == DialogResult.OK) {
                _animalsController.Deserialization(OfdMain.FileName);
                WriteToListView(LsvAnimals, _animalsController.Animals);
                WriteToTreeView(TrvAnimals, _animalsController);
                TrvAnimals.ExpandAll();
                MainForm_Load(sender, e);
            } // if
            _animalsController.FileName = OfdMain.FileName;
            MainForm_Load(sender, e);
        } // Open_Command


        // Сохранение данных в выбранном файле 
        private void SaveAs_Command(object sender, EventArgs e) {
            SfdMain.Title = "Сохранить файл как";
            SfdMain.InitialDirectory = Path.GetDirectoryName(_animalsController.FileName);
            SfdMain.Filter = "Файлы JSON (*.json)|*.json";
            //SfdMain.FilterIndex = 1;
            if (SfdMain.ShowDialog() == DialogResult.OK) {
                _animalsController.Serialization(SfdMain.FileName);
            } // if
            _animalsController.FileName = SfdMain.FileName;
            MainForm_Load(sender, e);
        } // SaveAs_Command


        // запись коллекции объектов в ListView для табличного отображения
        private void WriteToListView(ListView listView, List<Animal> animals) {

            listView.Items.Clear();

            foreach (var animal in animals) {
                listView.Items.Add(animal.ToListViewItem());
            } // foreach animal
        } // WriteToListView

        private void WriteToTreeView(TreeView treeView, AnimalsController animalsController) {
            treeView.Nodes.Clear();

            treeView.Nodes.Add(animalsController.Name);

            int i = 0;
            foreach (var animal in animalsController.Animals){
                // добавление узла животного
                treeView.Nodes[0].Nodes.Add($"{animal.Type} {animal.PetName}");
                // смена картинки
                treeView.Nodes[0].Nodes[i].ImageIndex =
                    treeView.Nodes[0].Nodes[i].SelectedImageIndex = animal.ImageId + 2;

                // добавление листа - имя владельца
                treeView.Nodes[0].Nodes[i].Nodes.Add(animal.Owner);
                // смена картинки
                treeView.Nodes[0].Nodes[i].Nodes[0].ImageIndex =
                    treeView.Nodes[0].Nodes[i].Nodes[0].SelectedImageIndex = 19;

                // добавление листа - вес животного
                treeView.Nodes[0].Nodes[i].Nodes.Add($"{animal.Weight:f3} кг");
                // смена картинки
                treeView.Nodes[0].Nodes[i].Nodes[1].ImageIndex =
                    treeView.Nodes[0].Nodes[i].Nodes[1].SelectedImageIndex = 18;
                i++;
            } // foreach animal
            TrvAnimals.Nodes[0].ExpandAll();
            for(int j = 0; j < TrvAnimals.Nodes[0].Nodes.Count; j++)
                TrvAnimals.Nodes[0].Nodes[j].Collapse();
            TrvAnimals.SelectedNode = TrvAnimals.Nodes[0];
        } // WriteToListView

        // Начальное формирование данных
        private void Generate_Command(object sender, EventArgs e) {
            _animalsController.Generate(Utils.GetRandom(20, 25));

            StlMain.Text = $"Коллекция сформирована. Текущее количество записей: {_animalsController.Count}";
            WriteToListView(LsvAnimals, _animalsController.Animals);
            WriteToTreeView(TrvAnimals, _animalsController);

            // сериализация данных
            Save_Command(sender, e);
            MainForm_Load(sender, e);
            // делаем главную страницу текущей
            TbcMain.SelectedTab = TbpGeneral;
        } // Generate_Command


        // свернуть в трей
        private void ToTray_Command(object sender, EventArgs e) {
            this.Hide();
            NtiMain.Visible = true;
        } // ToTray_Command


        // восстановить из трея
        private void FromTray_Command(object sender, EventArgs e){
            this.Show();
            WindowState = FormWindowState.Normal;
            NtiMain.Visible = false;
        } // FromTray_Command


        // удаление данных о животном
        private void RemoveAt_Command(object sender, EventArgs e) {
            // если нет выбранных элементов - молча уходим
            int index = LsvAnimals.SelectedIndices[0];

            if (LsvAnimals.SelectedIndices.Count == 0) return;
            // удаление записей и из коллекции
            _animalsController.RemoveAnimal(index);

            WriteToListView(LsvAnimals, _animalsController.Animals);
            WriteToTreeView(TrvAnimals, _animalsController);


            StlMain.Text = $"Запись удалёна. Текущее количество записей: {_animalsController.Count}";

            if(LsvAnimals.Items.Count > 0)
                LsvAnimals.Items[index -= LsvAnimals.Items.Count == index ? 1 : 0].Selected = true;
            MainForm_Load(sender, e);

            // сериализация данных
            Save_Command(sender, e);
        } // RemoveAt_Command


        // сортировка коллекции по возрасту
        private void OrderByAge_Command(object sender, EventArgs e) {
            WriteToListView(LsvOrderedAnimals, _animalsController.OrderByAge());

            // делаем страницу отсортированных данных текущей
            TbcMain.SelectedTab = TbpOrdered;

            // формирование заголовка поля вывода данных
            LblHeaderOrdered.Text = "Коллекция животных упорядочена по возрасту:"; ;
        } // OrderByAge_Command


        // сортировка коллекции по виду 
        private void OrderByType_Command(object sender, EventArgs e) {
            WriteToListView(LsvOrderedAnimals, _animalsController.OrderByType());

            // делаем страницу отсортированных данных текущей
            TbcMain.SelectedTab = TbpOrdered;

            // формирование заголовка поля вывода данных
            LblHeaderOrdered.Text = "Коллекция животных упорядочена по виду:"; ;
        } // OrderByType_Command


        // сортировка коллекции по фамилиям владельцев 
        private void OrderByOwner_Command(object sender, EventArgs e) {
            WriteToListView(LsvOrderedAnimals, _animalsController.OrderByOwner());

            // делаем страницу отсортированных данных текущей
            TbcMain.SelectedTab = TbpOrdered;

            // формирование заголовка поля вывода данных
            LblHeaderOrdered.Text = "Коллекция животных упорядочена по фамилиям владельцев :"; ;
        } // OrderByOwner_Command


        // Выборка и вывод в отдельной вкладке коллекции животных с максимальным весом
        private void SelectWhereMaxWeight_Command(object sender, EventArgs e) {
            TbxOwner.Visible = LblOwner.Visible = false;

            LblHeaderSelected.Text = $"Выборка коллекции животных с максимальным весом\n\rМаксимальным вес: {_animalsController.MaxWeight():f3} кг";
            WriteToListView(LsvSelectedAnimals, _animalsController.SelectAnimalsWhereMaxWeight());

            TbcMain.SelectedTab = TbpSelected; ;
        } // SelectByName_Command

        // Выборка и вывод в отдельной вкладке коллекции животных, фамилия владельцев
        // которых содержит заданную подстроку (подстроку вводить в этой же вкладке)
        private void SelectWhereOwner_Command(object sender, EventArgs e) {
            LblHeaderSelected.Text = $"Выборка коллекции животных, фамилия владельцев которых содержит заданную подстроку";
            WriteToListView(LsvSelectedAnimals, _animalsController.SelectAnimalsWhereOwner(""));
            TbxOwner.Visible = LblOwner.Visible = true;
            TbxOwner.Text = "";
            TbcMain.SelectedTab = TbpSelected; ;
        } // SelectByState_Command


        private void TbxOwner_TextChanged(object sender, EventArgs e) {
            WriteToListView(LsvSelectedAnimals, _animalsController.SelectAnimalsWhereOwner(TbxOwner.Text));
        } // TbxOwner_TextChanged

        // Разрешаем работу кнопок правки данных только на главной вкладке формы  
        private void TbcMain_SelectedIndexChanged(object sender, EventArgs e) {
            TsbAddAppliance.Enabled = TsbEditAppliance.Enabled =
                TsbRemoveAppliance.Enabled  = 
                MniAnimals.Enabled =
                TbcMain.SelectedTab == TbpGeneral;
        } // TbcMain_SelectedIndexChanged

        // Добавление записи в коллекцию 
        private void AddAnimal_Command(object sender, EventArgs e) {
            AnimalForm animalForm = new AnimalForm();

            // если окно закрыто не по кнопке BtnOk - молча уходим
            if (animalForm.ShowDialog() != DialogResult.OK) return;

            // получить данные из свойства формы
            _animalsController.AddAnimal(animalForm.Animal);

            WriteToListView(LsvAnimals, _animalsController.Animals);
            WriteToTreeView(TrvAnimals, _animalsController);

            StlMain.Text = $"Запись добавлена. Текущее количество: {_animalsController.Count}";
            MainForm_Load(sender, e);
            // сериализация данных
            Save_Command(sender, e);
        } // AddAppliance_Command

        // Редактирование выбранного электроприбора
        private void EditAnimal_Command(object sender, EventArgs e) {
            // если нет выбранных элементов - молча уходим
            if (LsvAnimals.SelectedIndices.Count == 0) return;

            AnimalForm animalForm = new AnimalForm("Редактирование данных о животном", "Сохранить");

            int index = LsvAnimals.SelectedIndices[0];
            animalForm.Animal = _animalsController.Animals[index];
            // если окно закрыто не по кнопке BtnOk - молча уходим
            if (animalForm.ShowDialog() != DialogResult.OK) return;

            // получить данные из свойства формы
            _animalsController[index] = animalForm.Animal;

            WriteToListView(LsvAnimals, _animalsController.Animals);
            WriteToTreeView(TrvAnimals, _animalsController);

            StlMain.Text = $"Данные о животном изменены. Текущее количество записей: {_animalsController.Count}";
            LsvAnimals.Items[index].Selected = true;
            MainForm_Load(sender, e);
            // сериализация данных
            Save_Command(sender, e);
        } // AddAppliance_Command


        private void LsvAnimals_DragDrop(object sender, DragEventArgs e) {
            string[] fileNames = (string[])e.Data.GetData(DataFormats.FileDrop);
            _animalsController.Deserialization(fileNames[0]);
            WriteToListView(LsvAnimals, _animalsController.Animals);
            WriteToTreeView(TrvAnimals, _animalsController);
            MainForm_Load(sender, e);
            } // LsvAppliances_DragDrop

        private void LsvAnimals_DragEnter(object sender, DragEventArgs e)  {
            e.Effect = DragDropEffects.Copy;
        } // LsvAppliances_DragEnter

        private void TbcMain_KeyDown(object sender, KeyEventArgs e) {
            if (e.KeyData != Keys.Delete || TbcMain.SelectedTab != TbpGeneral) return;

            RemoveAt_Command(sender, EventArgs.Empty);
        } // TbcMain_KeyDown

        private void MainForm_Load(object sender, EventArgs e) {
            OrderByAge_Command(sender, e);
            SelectWhereMaxWeight_Command(sender, e);
            TbcMain.SelectedTab = TbpGeneral;
            StlFilePath.Text = Path.GetFileName(_animalsController.FileName);
        } // MainForm_Load
    }
}
