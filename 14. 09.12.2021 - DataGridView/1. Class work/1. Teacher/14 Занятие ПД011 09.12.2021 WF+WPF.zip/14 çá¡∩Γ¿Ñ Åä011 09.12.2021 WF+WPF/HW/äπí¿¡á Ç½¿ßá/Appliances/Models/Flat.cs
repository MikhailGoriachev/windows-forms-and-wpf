﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Appliances.Helpers;
using System.Runtime.Serialization.Json;
using System.Runtime.Serialization;
using System.IO;

namespace Appliances.Models
{
    // класс, описывающий электрооборудование квартиры: адрес квартиры, коллекция электроприборов
    [DataContract]
    public class Flat {
        // условное название квартиры 
        private string _name;
        [DataMember]
        public string Name {
            get => _name;
            set {
                if (string.IsNullOrEmpty(value))
                    throw new Exception("Пустая строка в названии квартиры");

                _name = value;
            } // set
        } // Name

        // адрес квартиры
        private string _address;
        [DataMember]
        public string Address {
            get => _address;
            set {
                if (string.IsNullOrEmpty(value))
                    throw new Exception("Пустая строка в адресе квартиры");

                _address = value;
            } // set
        } // Address

        // коллекция электроприборов
        private List<Appliance> _appliances;
        [DataMember]
        public List<Appliance> Appliances {
            get => _appliances;
            private set => _appliances = value;
        } // Appliances

        // конструкторы для получения коллекции электроприборов
        public Flat() : this("Васин дом", "Ленинский проспект, 4а", new List<Appliance>()) {
            // создание коллекции электроприборов, количество по заданию 
            Generate(Utils.GetRandom(6, 8));
        } // Flat

        public Flat(string name, string address, List<Appliance> appliances) {
            Appliances = appliances;
            Address = address;
            Name = name;
        } // Flat

        // количестово электроприборов в коллекции
        public int Count => _appliances.Count;

        // формирование заданного количества электроприборов в коллекции
        public void Generate(int n) {
            _appliances.Clear();

            for (int i = 0; i < n; i++)
                _appliances.Add(Appliance.Generate());
        } // Generate

        // Удаление электроприбора
        public void RemoveAppliance(int index) => _appliances.RemoveAt(index);

        // Добавление электроприбора в коллекцию
        public void AddAppliance(Appliance appliance) => _appliances.Insert(0, appliance);

        // Редактирование электроприбора 
        public void EditAppliance(int index, Appliance appliance) => _appliances[index] = appliance;

        // Включение/выключение электроприбора
        public void ChangeState(int index) => _appliances[index].State = !_appliances[index].State;

        // Включение/выключение всех электроприборов комнаты
        public void TurnOnOff(bool state) => _appliances.ForEach(x => x.State = state);

        // Включение/выключение всех электроприборов квартиры
        public void TurnOnOffInRoom(bool state, string room) => _appliances.ForEach(x => x.State = x.Room == room ? state : x.State);

        // Упорядочивание копии коллекции электроприборов
        public List<Appliance> OrderBy(Comparison<Appliance> comparison) {
            List<Appliance> temp =_appliances;
            temp.Sort(comparison);
            return temp;
        } // OrderBy

        // Выборка электроприборов 
        public List<Appliance> SelectAppliances(Predicate<Appliance> predicate) =>
            _appliances.FindAll(predicate);

        // сериализация в формате JSON
        public void Serialization(string fileName) {
            DataContractJsonSerializer jsonFormatter = new DataContractJsonSerializer(typeof(Flat));

            using (FileStream fs = new FileStream(fileName, FileMode.Create))
                jsonFormatter.WriteObject(fs, this);
        } // Serialization

        // десериализация формате JSON
        public void Deserialization(string fileName) {
            DataContractJsonSerializer jsonFormatter = new DataContractJsonSerializer(typeof(Flat));

            using (FileStream fs = new FileStream(fileName, FileMode.OpenOrCreate)){
                Flat temp = (Flat)jsonFormatter.ReadObject(fs);
                Address = temp.Address;
                Name = temp.Name;
                Appliances = temp.Appliances;
            }
        } // Deserialization

    } // Flat
}
