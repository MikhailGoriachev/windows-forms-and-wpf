﻿
namespace AnimalsAtPetShop.Views
{
    partial class MainForm
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.ImlAnimals = new System.Windows.Forms.ImageList(this.components);
            this.NtfMain = new System.Windows.Forms.NotifyIcon(this.components);
            this.CmnNotify = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.CmiRestore = new System.Windows.Forms.ToolStripMenuItem();
            this.CmiNotifySeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.CmiAbout = new System.Windows.Forms.ToolStripMenuItem();
            this.CmiNotifySeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.CmiExit = new System.Windows.Forms.ToolStripMenuItem();
            this.SfdMain = new System.Windows.Forms.SaveFileDialog();
            this.OfdMain = new System.Windows.Forms.OpenFileDialog();
            this.MnsMain = new System.Windows.Forms.MenuStrip();
            this.MniFile = new System.Windows.Forms.ToolStripMenuItem();
            this.MniFileOpen = new System.Windows.Forms.ToolStripMenuItem();
            this.MniFileSave = new System.Windows.Forms.ToolStripMenuItem();
            this.MniFileSaveAs = new System.Windows.Forms.ToolStripMenuItem();
            this.MniFileSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.MniFileExit = new System.Windows.Forms.ToolStripMenuItem();
            this.MniPetShop = new System.Windows.Forms.ToolStripMenuItem();
            this.MniPetShopNew = new System.Windows.Forms.ToolStripMenuItem();
            this.MniPetShopEdit = new System.Windows.Forms.ToolStripMenuItem();
            this.MniPetShopSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.MniPetShopToTray = new System.Windows.Forms.ToolStripMenuItem();
            this.MniReport = new System.Windows.Forms.ToolStripMenuItem();
            this.MniReportOrder = new System.Windows.Forms.ToolStripMenuItem();
            this.MniReportOrderByName = new System.Windows.Forms.ToolStripMenuItem();
            this.MniReportOrderByState = new System.Windows.Forms.ToolStripMenuItem();
            this.MniReportOrderByPower = new System.Windows.Forms.ToolStripMenuItem();
            this.MniReportOrderByPrice = new System.Windows.Forms.ToolStripMenuItem();
            this.MniReportSelect = new System.Windows.Forms.ToolStripMenuItem();
            this.MniReportSelectByName = new System.Windows.Forms.ToolStripMenuItem();
            this.MniReportSelectByState = new System.Windows.Forms.ToolStripMenuItem();
            this.MniHelp = new System.Windows.Forms.ToolStripMenuItem();
            this.MniHelpAbout = new System.Windows.Forms.ToolStripMenuItem();
            this.StsMain = new System.Windows.Forms.StatusStrip();
            this.TslStatus = new System.Windows.Forms.ToolStripStatusLabel();
            this.TstMain = new System.Windows.Forms.ToolStrip();
            this.TsbNewApartment = new System.Windows.Forms.ToolStripButton();
            this.TsbOpen = new System.Windows.Forms.ToolStripButton();
            this.TsbSave = new System.Windows.Forms.ToolStripButton();
            this.TstSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.TsbEditApartment = new System.Windows.Forms.ToolStripButton();
            this.TsbToTray = new System.Windows.Forms.ToolStripButton();
            this.TstSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.TsbTurnOnAll = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.TsbTurnOffAll = new System.Windows.Forms.ToolStripButton();
            this.TsbExit = new System.Windows.Forms.ToolStripButton();
            this.LblPetShopInfo = new System.Windows.Forms.Label();
            this.TbcMain = new System.Windows.Forms.TabControl();
            this.TbpAppliances = new System.Windows.Forms.TabPage();
            this.LsvAnimals = new System.Windows.Forms.ListView();
            this.ClhImage = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.ClhBreed = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.ClhName = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.ClhColor = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.ClhWeight = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.ClhAge = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.ClhOwner = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.TbpSorted = new System.Windows.Forms.TabPage();
            this.TbpSelected = new System.Windows.Forms.TabPage();
            this.LsvOrdered = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader5 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader11 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader12 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.LsvFiltered = new System.Windows.Forms.ListView();
            this.columnHeader6 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader7 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader8 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader9 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader10 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader13 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader14 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.CmnNotify.SuspendLayout();
            this.MnsMain.SuspendLayout();
            this.StsMain.SuspendLayout();
            this.TstMain.SuspendLayout();
            this.TbcMain.SuspendLayout();
            this.TbpAppliances.SuspendLayout();
            this.TbpSorted.SuspendLayout();
            this.TbpSelected.SuspendLayout();
            this.SuspendLayout();
            // 
            // ImlAnimals
            // 
            this.ImlAnimals.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("ImlAnimals.ImageStream")));
            this.ImlAnimals.TransparentColor = System.Drawing.Color.Transparent;
            this.ImlAnimals.Images.SetKeyName(0, "bird.png");
            this.ImlAnimals.Images.SetKeyName(1, "bull.png");
            this.ImlAnimals.Images.SetKeyName(2, "cat.png");
            this.ImlAnimals.Images.SetKeyName(3, "cow.png");
            this.ImlAnimals.Images.SetKeyName(4, "dog.png");
            this.ImlAnimals.Images.SetKeyName(5, "duck.png");
            this.ImlAnimals.Images.SetKeyName(6, "elephant.png");
            this.ImlAnimals.Images.SetKeyName(7, "fish.png");
            this.ImlAnimals.Images.SetKeyName(8, "horse.png");
            this.ImlAnimals.Images.SetKeyName(9, "ladybug.png");
            this.ImlAnimals.Images.SetKeyName(10, "leopard.png");
            this.ImlAnimals.Images.SetKeyName(11, "lion.png");
            this.ImlAnimals.Images.SetKeyName(12, "lobster.png");
            this.ImlAnimals.Images.SetKeyName(13, "rabbit.png");
            this.ImlAnimals.Images.SetKeyName(14, "snail.png");
            this.ImlAnimals.Images.SetKeyName(15, "turtle.png");
            // 
            // NtfMain
            // 
            this.NtfMain.ContextMenuStrip = this.CmnNotify;
            this.NtfMain.Visible = true;
            // 
            // CmnNotify
            // 
            this.CmnNotify.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.CmnNotify.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.CmiRestore,
            this.CmiNotifySeparator1,
            this.CmiAbout,
            this.CmiNotifySeparator2,
            this.CmiExit});
            this.CmnNotify.Name = "contextMenuStrip1";
            this.CmnNotify.Size = new System.Drawing.Size(183, 88);
            // 
            // CmiRestore
            // 
            this.CmiRestore.Name = "CmiRestore";
            this.CmiRestore.Size = new System.Drawing.Size(182, 24);
            this.CmiRestore.Text = "Восстановить";
            this.CmiRestore.Click += new System.EventHandler(this.FromTray_Command);
            // 
            // CmiNotifySeparator1
            // 
            this.CmiNotifySeparator1.Name = "CmiNotifySeparator1";
            this.CmiNotifySeparator1.Size = new System.Drawing.Size(179, 6);
            // 
            // CmiAbout
            // 
            this.CmiAbout.Name = "CmiAbout";
            this.CmiAbout.Size = new System.Drawing.Size(182, 24);
            this.CmiAbout.Text = "О программе...";
            this.CmiAbout.Click += new System.EventHandler(this.About_Command);
            // 
            // CmiNotifySeparator2
            // 
            this.CmiNotifySeparator2.Name = "CmiNotifySeparator2";
            this.CmiNotifySeparator2.Size = new System.Drawing.Size(179, 6);
            // 
            // CmiExit
            // 
            this.CmiExit.Name = "CmiExit";
            this.CmiExit.Size = new System.Drawing.Size(182, 24);
            this.CmiExit.Text = "Выход";
            this.CmiExit.Click += new System.EventHandler(this.Exit_Command);
            // 
            // OfdMain
            // 
            this.OfdMain.FileName = "openFileDialog1";
            // 
            // MnsMain
            // 
            this.MnsMain.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.MnsMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniFile,
            this.MniPetShop,
            this.MniReport,
            this.MniHelp});
            this.MnsMain.Location = new System.Drawing.Point(0, 0);
            this.MnsMain.Name = "MnsMain";
            this.MnsMain.Size = new System.Drawing.Size(1031, 28);
            this.MnsMain.TabIndex = 7;
            this.MnsMain.Text = "menuStrip1";
            // 
            // MniFile
            // 
            this.MniFile.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniFileOpen,
            this.MniFileSave,
            this.MniFileSaveAs,
            this.MniFileSeparator1,
            this.MniFileExit});
            this.MniFile.Name = "MniFile";
            this.MniFile.Size = new System.Drawing.Size(57, 24);
            this.MniFile.Text = "Файл";
            // 
            // MniFileOpen
            // 
            this.MniFileOpen.Name = "MniFileOpen";
            this.MniFileOpen.Size = new System.Drawing.Size(187, 24);
            this.MniFileOpen.Text = "Открыть...";
            // 
            // MniFileSave
            // 
            this.MniFileSave.Name = "MniFileSave";
            this.MniFileSave.Size = new System.Drawing.Size(187, 24);
            this.MniFileSave.Text = "Сохранить";
            this.MniFileSave.Click += new System.EventHandler(this.Save_Command);
            // 
            // MniFileSaveAs
            // 
            this.MniFileSaveAs.Name = "MniFileSaveAs";
            this.MniFileSaveAs.Size = new System.Drawing.Size(187, 24);
            this.MniFileSaveAs.Text = "Сохранить как...";
            // 
            // MniFileSeparator1
            // 
            this.MniFileSeparator1.Name = "MniFileSeparator1";
            this.MniFileSeparator1.Size = new System.Drawing.Size(184, 6);
            // 
            // MniFileExit
            // 
            this.MniFileExit.Name = "MniFileExit";
            this.MniFileExit.Size = new System.Drawing.Size(187, 24);
            this.MniFileExit.Text = "Выход";
            this.MniFileExit.Click += new System.EventHandler(this.Exit_Command);
            // 
            // MniPetShop
            // 
            this.MniPetShop.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniPetShopNew,
            this.MniPetShopEdit,
            this.MniPetShopSeparator1,
            this.MniPetShopToTray});
            this.MniPetShop.Name = "MniPetShop";
            this.MniPetShop.Size = new System.Drawing.Size(105, 24);
            this.MniPetShop.Text = "Зоомагазин";
            // 
            // MniPetShopNew
            // 
            this.MniPetShopNew.Name = "MniPetShopNew";
            this.MniPetShopNew.Size = new System.Drawing.Size(190, 24);
            this.MniPetShopNew.Text = "Новый...";
            this.MniPetShopNew.Click += new System.EventHandler(this.New_Command);
            // 
            // MniPetShopEdit
            // 
            this.MniPetShopEdit.Name = "MniPetShopEdit";
            this.MniPetShopEdit.Size = new System.Drawing.Size(190, 24);
            this.MniPetShopEdit.Text = "Редактировать...";
            // 
            // MniPetShopSeparator1
            // 
            this.MniPetShopSeparator1.Name = "MniPetShopSeparator1";
            this.MniPetShopSeparator1.Size = new System.Drawing.Size(187, 6);
            // 
            // MniPetShopToTray
            // 
            this.MniPetShopToTray.Name = "MniPetShopToTray";
            this.MniPetShopToTray.Size = new System.Drawing.Size(190, 24);
            this.MniPetShopToTray.Text = "Свернуть в трей";
            this.MniPetShopToTray.Click += new System.EventHandler(this.ToTray_Command);
            // 
            // MniReport
            // 
            this.MniReport.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniReportOrder,
            this.MniReportSelect});
            this.MniReport.Name = "MniReport";
            this.MniReport.Size = new System.Drawing.Size(71, 24);
            this.MniReport.Text = "Отчеты";
            // 
            // MniReportOrder
            // 
            this.MniReportOrder.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniReportOrderByName,
            this.MniReportOrderByState,
            this.MniReportOrderByPower,
            this.MniReportOrderByPrice});
            this.MniReportOrder.Name = "MniReportOrder";
            this.MniReportOrder.Size = new System.Drawing.Size(170, 24);
            this.MniReportOrder.Text = "Упорядочить";
            // 
            // MniReportOrderByName
            // 
            this.MniReportOrderByName.Name = "MniReportOrderByName";
            this.MniReportOrderByName.Size = new System.Drawing.Size(216, 24);
            this.MniReportOrderByName.Text = "По названию";
            // 
            // MniReportOrderByState
            // 
            this.MniReportOrderByState.Name = "MniReportOrderByState";
            this.MniReportOrderByState.Size = new System.Drawing.Size(216, 24);
            this.MniReportOrderByState.Text = "По состоянию";
            // 
            // MniReportOrderByPower
            // 
            this.MniReportOrderByPower.Name = "MniReportOrderByPower";
            this.MniReportOrderByPower.Size = new System.Drawing.Size(216, 24);
            this.MniReportOrderByPower.Text = "По мощности";
            // 
            // MniReportOrderByPrice
            // 
            this.MniReportOrderByPrice.Name = "MniReportOrderByPrice";
            this.MniReportOrderByPrice.Size = new System.Drawing.Size(216, 24);
            this.MniReportOrderByPrice.Text = "По убыванию цены";
            // 
            // MniReportSelect
            // 
            this.MniReportSelect.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniReportSelectByName,
            this.MniReportSelectByState});
            this.MniReportSelect.Name = "MniReportSelect";
            this.MniReportSelect.Size = new System.Drawing.Size(170, 24);
            this.MniReportSelect.Text = "Выбрать";
            // 
            // MniReportSelectByName
            // 
            this.MniReportSelectByName.Name = "MniReportSelectByName";
            this.MniReportSelectByName.Size = new System.Drawing.Size(178, 24);
            this.MniReportSelectByName.Text = "По названию";
            // 
            // MniReportSelectByState
            // 
            this.MniReportSelectByState.Name = "MniReportSelectByState";
            this.MniReportSelectByState.Size = new System.Drawing.Size(178, 24);
            this.MniReportSelectByState.Text = "По состоянию";
            // 
            // MniHelp
            // 
            this.MniHelp.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniHelpAbout});
            this.MniHelp.Name = "MniHelp";
            this.MniHelp.Size = new System.Drawing.Size(79, 24);
            this.MniHelp.Text = "Справка";
            // 
            // MniHelpAbout
            // 
            this.MniHelpAbout.Name = "MniHelpAbout";
            this.MniHelpAbout.Size = new System.Drawing.Size(182, 24);
            this.MniHelpAbout.Text = "О программе...";
            // 
            // StsMain
            // 
            this.StsMain.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.StsMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.TslStatus});
            this.StsMain.Location = new System.Drawing.Point(0, 525);
            this.StsMain.Name = "StsMain";
            this.StsMain.Size = new System.Drawing.Size(1031, 25);
            this.StsMain.TabIndex = 9;
            this.StsMain.Text = "statusStrip1";
            // 
            // TslStatus
            // 
            this.TslStatus.AutoSize = false;
            this.TslStatus.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenInner;
            this.TslStatus.Name = "TslStatus";
            this.TslStatus.Padding = new System.Windows.Forms.Padding(6, 0, 0, 0);
            this.TslStatus.Size = new System.Drawing.Size(280, 20);
            this.TslStatus.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // TstMain
            // 
            this.TstMain.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TstMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.TsbNewApartment,
            this.TsbOpen,
            this.TsbSave,
            this.TstSeparator1,
            this.TsbEditApartment,
            this.TsbToTray,
            this.TstSeparator2,
            this.TsbTurnOnAll,
            this.toolStripButton1,
            this.TsbTurnOffAll,
            this.TsbExit});
            this.TstMain.Location = new System.Drawing.Point(0, 28);
            this.TstMain.Name = "TstMain";
            this.TstMain.Size = new System.Drawing.Size(1031, 25);
            this.TstMain.TabIndex = 12;
            this.TstMain.Text = "toolStrip1";
            // 
            // TsbNewApartment
            // 
            this.TsbNewApartment.AutoSize = false;
            this.TsbNewApartment.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbNewApartment.Image = ((System.Drawing.Image)(resources.GetObject("TsbNewApartment.Image")));
            this.TsbNewApartment.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbNewApartment.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbNewApartment.Name = "TsbNewApartment";
            this.TsbNewApartment.Size = new System.Drawing.Size(23, 22);
            this.TsbNewApartment.Text = "toolStripButton4";
            // 
            // TsbOpen
            // 
            this.TsbOpen.AutoSize = false;
            this.TsbOpen.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbOpen.Image = ((System.Drawing.Image)(resources.GetObject("TsbOpen.Image")));
            this.TsbOpen.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbOpen.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbOpen.Name = "TsbOpen";
            this.TsbOpen.Size = new System.Drawing.Size(23, 22);
            this.TsbOpen.Text = "toolStripButton2";
            // 
            // TsbSave
            // 
            this.TsbSave.AutoSize = false;
            this.TsbSave.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbSave.Image = ((System.Drawing.Image)(resources.GetObject("TsbSave.Image")));
            this.TsbSave.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbSave.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbSave.Name = "TsbSave";
            this.TsbSave.Size = new System.Drawing.Size(23, 22);
            this.TsbSave.Text = "toolStripButton3";
            // 
            // TstSeparator1
            // 
            this.TstSeparator1.AutoSize = false;
            this.TstSeparator1.Name = "TstSeparator1";
            this.TstSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // TsbEditApartment
            // 
            this.TsbEditApartment.AutoSize = false;
            this.TsbEditApartment.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbEditApartment.Image = ((System.Drawing.Image)(resources.GetObject("TsbEditApartment.Image")));
            this.TsbEditApartment.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbEditApartment.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbEditApartment.Name = "TsbEditApartment";
            this.TsbEditApartment.Size = new System.Drawing.Size(23, 22);
            this.TsbEditApartment.Text = "toolStripButton5";
            // 
            // TsbToTray
            // 
            this.TsbToTray.AutoSize = false;
            this.TsbToTray.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbToTray.Image = ((System.Drawing.Image)(resources.GetObject("TsbToTray.Image")));
            this.TsbToTray.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbToTray.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbToTray.Name = "TsbToTray";
            this.TsbToTray.Size = new System.Drawing.Size(23, 22);
            this.TsbToTray.Text = "toolStripButton6";
            // 
            // TstSeparator2
            // 
            this.TstSeparator2.AutoSize = false;
            this.TstSeparator2.Name = "TstSeparator2";
            this.TstSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // TsbTurnOnAll
            // 
            this.TsbTurnOnAll.AutoSize = false;
            this.TsbTurnOnAll.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbTurnOnAll.Image = ((System.Drawing.Image)(resources.GetObject("TsbTurnOnAll.Image")));
            this.TsbTurnOnAll.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbTurnOnAll.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbTurnOnAll.Name = "TsbTurnOnAll";
            this.TsbTurnOnAll.Size = new System.Drawing.Size(23, 22);
            this.TsbTurnOnAll.Text = "toolStripButton7";
            // 
            // toolStripButton1
            // 
            this.toolStripButton1.AutoSize = false;
            this.toolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton1.Image")));
            this.toolStripButton1.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton1.Text = "toolStripButton7";
            // 
            // TsbTurnOffAll
            // 
            this.TsbTurnOffAll.AutoSize = false;
            this.TsbTurnOffAll.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbTurnOffAll.Image = ((System.Drawing.Image)(resources.GetObject("TsbTurnOffAll.Image")));
            this.TsbTurnOffAll.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbTurnOffAll.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbTurnOffAll.Name = "TsbTurnOffAll";
            this.TsbTurnOffAll.Size = new System.Drawing.Size(23, 22);
            this.TsbTurnOffAll.Text = "toolStripButton7";
            // 
            // TsbExit
            // 
            this.TsbExit.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.TsbExit.AutoSize = false;
            this.TsbExit.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbExit.Image = ((System.Drawing.Image)(resources.GetObject("TsbExit.Image")));
            this.TsbExit.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbExit.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbExit.Name = "TsbExit";
            this.TsbExit.Size = new System.Drawing.Size(23, 22);
            this.TsbExit.Text = "toolStripButton7";
            this.TsbExit.Click += new System.EventHandler(this.Exit_Command);
            // 
            // LblPetShopInfo
            // 
            this.LblPetShopInfo.Dock = System.Windows.Forms.DockStyle.Top;
            this.LblPetShopInfo.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblPetShopInfo.Location = new System.Drawing.Point(0, 53);
            this.LblPetShopInfo.Name = "LblPetShopInfo";
            this.LblPetShopInfo.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.LblPetShopInfo.Size = new System.Drawing.Size(1031, 27);
            this.LblPetShopInfo.TabIndex = 13;
            this.LblPetShopInfo.Text = "Место для вывода данных магазина";
            this.LblPetShopInfo.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // TbcMain
            // 
            this.TbcMain.Controls.Add(this.TbpAppliances);
            this.TbcMain.Controls.Add(this.TbpSorted);
            this.TbcMain.Controls.Add(this.TbpSelected);
            this.TbcMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TbcMain.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TbcMain.Location = new System.Drawing.Point(0, 80);
            this.TbcMain.Name = "TbcMain";
            this.TbcMain.SelectedIndex = 0;
            this.TbcMain.Size = new System.Drawing.Size(1031, 445);
            this.TbcMain.TabIndex = 14;
            // 
            // TbpAppliances
            // 
            this.TbpAppliances.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.TbpAppliances.Controls.Add(this.LsvAnimals);
            this.TbpAppliances.Location = new System.Drawing.Point(4, 27);
            this.TbpAppliances.Name = "TbpAppliances";
            this.TbpAppliances.Padding = new System.Windows.Forms.Padding(3);
            this.TbpAppliances.Size = new System.Drawing.Size(1023, 414);
            this.TbpAppliances.TabIndex = 0;
            this.TbpAppliances.Text = "Животные коллекции";
            this.TbpAppliances.ToolTipText = "Коллекция животных магазина";
            this.TbpAppliances.UseVisualStyleBackColor = true;
            // 
            // LsvAnimals
            // 
            this.LsvAnimals.AllowDrop = true;
            this.LsvAnimals.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.ClhImage,
            this.ClhBreed,
            this.ClhName,
            this.ClhColor,
            this.ClhWeight,
            this.ClhAge,
            this.ClhOwner});
            this.LsvAnimals.Dock = System.Windows.Forms.DockStyle.Fill;
            this.LsvAnimals.FullRowSelect = true;
            this.LsvAnimals.GridLines = true;
            this.LsvAnimals.HideSelection = false;
            this.LsvAnimals.LabelEdit = true;
            this.LsvAnimals.Location = new System.Drawing.Point(3, 3);
            this.LsvAnimals.MultiSelect = false;
            this.LsvAnimals.Name = "LsvAnimals";
            this.LsvAnimals.Size = new System.Drawing.Size(1013, 404);
            this.LsvAnimals.SmallImageList = this.ImlAnimals;
            this.LsvAnimals.TabIndex = 0;
            this.LsvAnimals.UseCompatibleStateImageBehavior = false;
            this.LsvAnimals.View = System.Windows.Forms.View.Details;
            this.LsvAnimals.DragDrop += new System.Windows.Forms.DragEventHandler(this.LsvAnimals_DragDrop);
            this.LsvAnimals.DragEnter += new System.Windows.Forms.DragEventHandler(this.LsvAnimals_DragEnter);
            // 
            // ClhImage
            // 
            this.ClhImage.Text = "Состояние";
            this.ClhImage.Width = 120;
            // 
            // ClhBreed
            // 
            this.ClhBreed.Text = "Вид животного";
            this.ClhBreed.Width = 123;
            // 
            // ClhName
            // 
            this.ClhName.Text = "Кличка";
            this.ClhName.Width = 222;
            // 
            // ClhColor
            // 
            this.ClhColor.Text = "Масть";
            this.ClhColor.Width = 117;
            // 
            // ClhWeight
            // 
            this.ClhWeight.Text = "Вес, кг";
            this.ClhWeight.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.ClhWeight.Width = 98;
            // 
            // ClhAge
            // 
            this.ClhAge.Text = "Возраст, лет";
            this.ClhAge.Width = 108;
            // 
            // ClhOwner
            // 
            this.ClhOwner.Text = "Владелец";
            this.ClhOwner.Width = 196;
            // 
            // TbpSorted
            // 
            this.TbpSorted.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.TbpSorted.Controls.Add(this.LsvOrdered);
            this.TbpSorted.Location = new System.Drawing.Point(4, 27);
            this.TbpSorted.Name = "TbpSorted";
            this.TbpSorted.Padding = new System.Windows.Forms.Padding(3);
            this.TbpSorted.Size = new System.Drawing.Size(1023, 414);
            this.TbpSorted.TabIndex = 1;
            this.TbpSorted.Text = "Упорядоченная коллекция";
            this.TbpSorted.UseVisualStyleBackColor = true;
            // 
            // TbpSelected
            // 
            this.TbpSelected.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.TbpSelected.Controls.Add(this.LsvFiltered);
            this.TbpSelected.Location = new System.Drawing.Point(4, 27);
            this.TbpSelected.Name = "TbpSelected";
            this.TbpSelected.Padding = new System.Windows.Forms.Padding(3);
            this.TbpSelected.Size = new System.Drawing.Size(1023, 414);
            this.TbpSelected.TabIndex = 2;
            this.TbpSelected.Text = "Выборка животных";
            this.TbpSelected.UseVisualStyleBackColor = true;
            // 
            // LsvOrdered
            // 
            this.LsvOrdered.AllowDrop = true;
            this.LsvOrdered.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3,
            this.columnHeader4,
            this.columnHeader5,
            this.columnHeader11,
            this.columnHeader12});
            this.LsvOrdered.Dock = System.Windows.Forms.DockStyle.Fill;
            this.LsvOrdered.FullRowSelect = true;
            this.LsvOrdered.GridLines = true;
            this.LsvOrdered.HideSelection = false;
            this.LsvOrdered.LabelEdit = true;
            this.LsvOrdered.Location = new System.Drawing.Point(3, 3);
            this.LsvOrdered.MultiSelect = false;
            this.LsvOrdered.Name = "LsvOrdered";
            this.LsvOrdered.Size = new System.Drawing.Size(1013, 404);
            this.LsvOrdered.SmallImageList = this.ImlAnimals;
            this.LsvOrdered.TabIndex = 1;
            this.LsvOrdered.UseCompatibleStateImageBehavior = false;
            this.LsvOrdered.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Состояние";
            this.columnHeader1.Width = 120;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Вид животного";
            this.columnHeader2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.columnHeader2.Width = 123;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Кличка";
            this.columnHeader3.Width = 222;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "Масть";
            this.columnHeader4.Width = 117;
            // 
            // columnHeader5
            // 
            this.columnHeader5.Text = "Вес, кг";
            this.columnHeader5.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.columnHeader5.Width = 98;
            // 
            // columnHeader11
            // 
            this.columnHeader11.Text = "Возраст, лет";
            this.columnHeader11.Width = 108;
            // 
            // columnHeader12
            // 
            this.columnHeader12.Text = "Владелец";
            this.columnHeader12.Width = 196;
            // 
            // LsvFiltered
            // 
            this.LsvFiltered.AllowDrop = true;
            this.LsvFiltered.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader6,
            this.columnHeader7,
            this.columnHeader8,
            this.columnHeader9,
            this.columnHeader10,
            this.columnHeader13,
            this.columnHeader14});
            this.LsvFiltered.Dock = System.Windows.Forms.DockStyle.Fill;
            this.LsvFiltered.FullRowSelect = true;
            this.LsvFiltered.GridLines = true;
            this.LsvFiltered.HideSelection = false;
            this.LsvFiltered.LabelEdit = true;
            this.LsvFiltered.Location = new System.Drawing.Point(3, 3);
            this.LsvFiltered.MultiSelect = false;
            this.LsvFiltered.Name = "LsvFiltered";
            this.LsvFiltered.Size = new System.Drawing.Size(1013, 404);
            this.LsvFiltered.SmallImageList = this.ImlAnimals;
            this.LsvFiltered.TabIndex = 1;
            this.LsvFiltered.UseCompatibleStateImageBehavior = false;
            this.LsvFiltered.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader6
            // 
            this.columnHeader6.Text = "Состояние";
            this.columnHeader6.Width = 120;
            // 
            // columnHeader7
            // 
            this.columnHeader7.Text = "Вид животного";
            this.columnHeader7.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.columnHeader7.Width = 123;
            // 
            // columnHeader8
            // 
            this.columnHeader8.Text = "Кличка";
            this.columnHeader8.Width = 222;
            // 
            // columnHeader9
            // 
            this.columnHeader9.Text = "Масть";
            this.columnHeader9.Width = 117;
            // 
            // columnHeader10
            // 
            this.columnHeader10.Text = "Вес, кг";
            this.columnHeader10.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.columnHeader10.Width = 98;
            // 
            // columnHeader13
            // 
            this.columnHeader13.Text = "Возраст, лет";
            this.columnHeader13.Width = 108;
            // 
            // columnHeader14
            // 
            this.columnHeader14.Text = "Владелец";
            this.columnHeader14.Width = 196;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1031, 550);
            this.Controls.Add(this.TbcMain);
            this.Controls.Add(this.LblPetShopInfo);
            this.Controls.Add(this.TstMain);
            this.Controls.Add(this.MnsMain);
            this.Controls.Add(this.StsMain);
            this.Name = "MainForm";
            this.Text = "Задание на 06.12.2021 - работа с ListView, Drag\'n\'Drop";
            this.CmnNotify.ResumeLayout(false);
            this.MnsMain.ResumeLayout(false);
            this.MnsMain.PerformLayout();
            this.StsMain.ResumeLayout(false);
            this.StsMain.PerformLayout();
            this.TstMain.ResumeLayout(false);
            this.TstMain.PerformLayout();
            this.TbcMain.ResumeLayout(false);
            this.TbpAppliances.ResumeLayout(false);
            this.TbpSorted.ResumeLayout(false);
            this.TbpSelected.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ImageList ImlAnimals;
        private System.Windows.Forms.NotifyIcon NtfMain;
        private System.Windows.Forms.SaveFileDialog SfdMain;
        private System.Windows.Forms.OpenFileDialog OfdMain;
        private System.Windows.Forms.ContextMenuStrip CmnNotify;
        private System.Windows.Forms.ToolStripMenuItem CmiRestore;
        private System.Windows.Forms.ToolStripSeparator CmiNotifySeparator1;
        private System.Windows.Forms.ToolStripMenuItem CmiAbout;
        private System.Windows.Forms.ToolStripSeparator CmiNotifySeparator2;
        private System.Windows.Forms.ToolStripMenuItem CmiExit;
        private System.Windows.Forms.MenuStrip MnsMain;
        private System.Windows.Forms.ToolStripMenuItem MniFile;
        private System.Windows.Forms.ToolStripMenuItem MniFileOpen;
        private System.Windows.Forms.ToolStripMenuItem MniFileSave;
        private System.Windows.Forms.ToolStripMenuItem MniFileSaveAs;
        private System.Windows.Forms.ToolStripSeparator MniFileSeparator1;
        private System.Windows.Forms.ToolStripMenuItem MniFileExit;
        private System.Windows.Forms.ToolStripMenuItem MniPetShop;
        private System.Windows.Forms.ToolStripMenuItem MniPetShopNew;
        private System.Windows.Forms.ToolStripMenuItem MniPetShopEdit;
        private System.Windows.Forms.ToolStripMenuItem MniReport;
        private System.Windows.Forms.ToolStripMenuItem MniReportOrder;
        private System.Windows.Forms.ToolStripMenuItem MniReportOrderByName;
        private System.Windows.Forms.ToolStripMenuItem MniReportOrderByState;
        private System.Windows.Forms.ToolStripMenuItem MniReportOrderByPower;
        private System.Windows.Forms.ToolStripMenuItem MniReportOrderByPrice;
        private System.Windows.Forms.ToolStripMenuItem MniReportSelect;
        private System.Windows.Forms.ToolStripMenuItem MniReportSelectByName;
        private System.Windows.Forms.ToolStripMenuItem MniReportSelectByState;
        private System.Windows.Forms.ToolStripMenuItem MniHelp;
        private System.Windows.Forms.ToolStripMenuItem MniHelpAbout;
        private System.Windows.Forms.StatusStrip StsMain;
        private System.Windows.Forms.ToolStripStatusLabel TslStatus;
        private System.Windows.Forms.ToolStrip TstMain;
        private System.Windows.Forms.ToolStripButton TsbOpen;
        private System.Windows.Forms.ToolStripButton TsbSave;
        private System.Windows.Forms.ToolStripSeparator TstSeparator1;
        private System.Windows.Forms.ToolStripButton TsbNewApartment;
        private System.Windows.Forms.ToolStripButton TsbEditApartment;
        private System.Windows.Forms.ToolStripSeparator TstSeparator2;
        private System.Windows.Forms.ToolStripButton TsbToTray;
        private System.Windows.Forms.ToolStripButton TsbTurnOnAll;
        private System.Windows.Forms.ToolStripButton TsbTurnOffAll;
        private System.Windows.Forms.Label LblPetShopInfo;
        private System.Windows.Forms.TabControl TbcMain;
        private System.Windows.Forms.TabPage TbpAppliances;
        private System.Windows.Forms.ListView LsvAnimals;
        private System.Windows.Forms.ColumnHeader ClhImage;
        private System.Windows.Forms.ColumnHeader ClhBreed;
        private System.Windows.Forms.ColumnHeader ClhName;
        private System.Windows.Forms.ColumnHeader ClhColor;
        private System.Windows.Forms.ColumnHeader ClhWeight;
        private System.Windows.Forms.TabPage TbpSorted;
        private System.Windows.Forms.TabPage TbpSelected;
        private System.Windows.Forms.ToolStripSeparator MniPetShopSeparator1;
        private System.Windows.Forms.ToolStripMenuItem MniPetShopToTray;
        private System.Windows.Forms.ToolStripButton toolStripButton1;
        private System.Windows.Forms.ToolStripButton TsbExit;
        private System.Windows.Forms.ColumnHeader ClhAge;
        private System.Windows.Forms.ColumnHeader ClhOwner;
        private System.Windows.Forms.ListView LsvOrdered;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.ColumnHeader columnHeader5;
        private System.Windows.Forms.ColumnHeader columnHeader11;
        private System.Windows.Forms.ColumnHeader columnHeader12;
        private System.Windows.Forms.ListView LsvFiltered;
        private System.Windows.Forms.ColumnHeader columnHeader6;
        private System.Windows.Forms.ColumnHeader columnHeader7;
        private System.Windows.Forms.ColumnHeader columnHeader8;
        private System.Windows.Forms.ColumnHeader columnHeader9;
        private System.Windows.Forms.ColumnHeader columnHeader10;
        private System.Windows.Forms.ColumnHeader columnHeader13;
        private System.Windows.Forms.ColumnHeader columnHeader14;
    }
}

