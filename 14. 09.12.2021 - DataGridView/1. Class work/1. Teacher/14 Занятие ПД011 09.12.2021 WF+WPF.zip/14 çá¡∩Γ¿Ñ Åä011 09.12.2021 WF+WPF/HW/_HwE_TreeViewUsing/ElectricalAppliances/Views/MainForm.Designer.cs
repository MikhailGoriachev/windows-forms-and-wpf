﻿
namespace ElectricalAppliances.Views
{
    partial class MainForm
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            System.Windows.Forms.TreeNode treeNode1 = new System.Windows.Forms.TreeNode("Квартира");
            this.MnsMain = new System.Windows.Forms.MenuStrip();
            this.MniFile = new System.Windows.Forms.ToolStripMenuItem();
            this.MniFileOpen = new System.Windows.Forms.ToolStripMenuItem();
            this.MniFileSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.MniFileSave = new System.Windows.Forms.ToolStripMenuItem();
            this.MniFileSaveAs = new System.Windows.Forms.ToolStripMenuItem();
            this.MniFileSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.MniFileExit = new System.Windows.Forms.ToolStripMenuItem();
            this.MniApartment = new System.Windows.Forms.ToolStripMenuItem();
            this.новаяКвартираToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.редактироватьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.MniControl = new System.Windows.Forms.ToolStripMenuItem();
            this.MniControlToTray = new System.Windows.Forms.ToolStripMenuItem();
            this.MniControlSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.MniControlTurnApplianceOn = new System.Windows.Forms.ToolStripMenuItem();
            this.MniControlTurnApplianceOff = new System.Windows.Forms.ToolStripMenuItem();
            this.MniControlSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.MniControlTurnOnAll = new System.Windows.Forms.ToolStripMenuItem();
            this.MniControlTurnOffAll = new System.Windows.Forms.ToolStripMenuItem();
            this.MniReport = new System.Windows.Forms.ToolStripMenuItem();
            this.MniReportOrder = new System.Windows.Forms.ToolStripMenuItem();
            this.MniReportOrderByName = new System.Windows.Forms.ToolStripMenuItem();
            this.MniReportOrderByState = new System.Windows.Forms.ToolStripMenuItem();
            this.MniReportOrderByPower = new System.Windows.Forms.ToolStripMenuItem();
            this.MniReportOrderByPrice = new System.Windows.Forms.ToolStripMenuItem();
            this.MniReportSelect = new System.Windows.Forms.ToolStripMenuItem();
            this.MniReportSelectByName = new System.Windows.Forms.ToolStripMenuItem();
            this.MniReportSelectByState = new System.Windows.Forms.ToolStripMenuItem();
            this.MniHelp = new System.Windows.Forms.ToolStripMenuItem();
            this.MniHelpAbout = new System.Windows.Forms.ToolStripMenuItem();
            this.TstMain = new System.Windows.Forms.ToolStrip();
            this.TsbNew = new System.Windows.Forms.ToolStripButton();
            this.TsbOpen = new System.Windows.Forms.ToolStripButton();
            this.TsbSave = new System.Windows.Forms.ToolStripButton();
            this.TstSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.TsbEditApartment = new System.Windows.Forms.ToolStripButton();
            this.TsbToTray = new System.Windows.Forms.ToolStripButton();
            this.TstSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.TsbTurnOnAll = new System.Windows.Forms.ToolStripButton();
            this.TsbTurnOffAll = new System.Windows.Forms.ToolStripButton();
            this.TstSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.TsbAbout = new System.Windows.Forms.ToolStripButton();
            this.TsbExit = new System.Windows.Forms.ToolStripButton();
            this.StsMain = new System.Windows.Forms.StatusStrip();
            this.TslStatus = new System.Windows.Forms.ToolStripStatusLabel();
            this.TslOn = new System.Windows.Forms.ToolStripStatusLabel();
            this.TslOff = new System.Windows.Forms.ToolStripStatusLabel();
            this.TslFileName = new System.Windows.Forms.ToolStripStatusLabel();
            this.CmnNotify = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.CmiRestore = new System.Windows.Forms.ToolStripMenuItem();
            this.CmiNotifySeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.CmiAbout = new System.Windows.Forms.ToolStripMenuItem();
            this.CmiNotifySeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.CmiExit = new System.Windows.Forms.ToolStripMenuItem();
            this.CmnListView = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.CmiListViewTurnOn = new System.Windows.Forms.ToolStripMenuItem();
            this.CmiListViewTurnOff = new System.Windows.Forms.ToolStripMenuItem();
            this.CmiListViewSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.CmiListViewTurnOnAll = new System.Windows.Forms.ToolStripMenuItem();
            this.CmiListViewTurnOffAll = new System.Windows.Forms.ToolStripMenuItem();
            this.CmiListViewSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.CmiListViewToTray = new System.Windows.Forms.ToolStripMenuItem();
            this.ImlSmall = new System.Windows.Forms.ImageList(this.components);
            this.OfdMain = new System.Windows.Forms.OpenFileDialog();
            this.SfdMain = new System.Windows.Forms.SaveFileDialog();
            this.NtfMain = new System.Windows.Forms.NotifyIcon(this.components);
            this.LblApartmentInfo = new System.Windows.Forms.Label();
            this.TbcMain = new System.Windows.Forms.TabControl();
            this.TbpAppliances = new System.Windows.Forms.TabPage();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.TrvApartment = new System.Windows.Forms.TreeView();
            this.LsvAppliances = new System.Windows.Forms.ListView();
            this.ClhState = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.ClhId = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.ClhRoom = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.ClhName = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.ClhPower = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.ClhPrice = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.TbpSorted = new System.Windows.Forms.TabPage();
            this.LsvOrdered = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader5 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.TbpSelected = new System.Windows.Forms.TabPage();
            this.LsvFiltered = new System.Windows.Forms.ListView();
            this.columnHeader6 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader7 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader8 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader9 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader10 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.CmnTreeAppliance = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.MnsMain.SuspendLayout();
            this.TstMain.SuspendLayout();
            this.StsMain.SuspendLayout();
            this.CmnNotify.SuspendLayout();
            this.CmnListView.SuspendLayout();
            this.TbcMain.SuspendLayout();
            this.TbpAppliances.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.TbpSorted.SuspendLayout();
            this.TbpSelected.SuspendLayout();
            this.CmnTreeAppliance.SuspendLayout();
            this.SuspendLayout();
            // 
            // MnsMain
            // 
            this.MnsMain.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.MnsMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniFile,
            this.MniApartment,
            this.MniControl,
            this.MniReport,
            this.MniHelp});
            this.MnsMain.Location = new System.Drawing.Point(0, 0);
            this.MnsMain.Name = "MnsMain";
            this.MnsMain.Size = new System.Drawing.Size(1184, 28);
            this.MnsMain.TabIndex = 0;
            this.MnsMain.Text = "menuStrip1";
            // 
            // MniFile
            // 
            this.MniFile.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniFileOpen,
            this.MniFileSeparator1,
            this.MniFileSave,
            this.MniFileSaveAs,
            this.MniFileSeparator2,
            this.MniFileExit});
            this.MniFile.Name = "MniFile";
            this.MniFile.Size = new System.Drawing.Size(57, 24);
            this.MniFile.Text = "Файл";
            // 
            // MniFileOpen
            // 
            this.MniFileOpen.Image = global::ElectricalAppliances.Properties.Resources.folder;
            this.MniFileOpen.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MniFileOpen.Name = "MniFileOpen";
            this.MniFileOpen.Size = new System.Drawing.Size(203, 38);
            this.MniFileOpen.Text = "Открыть...";
            this.MniFileOpen.Click += new System.EventHandler(this.OpenFile_Command);
            // 
            // MniFileSeparator1
            // 
            this.MniFileSeparator1.Name = "MniFileSeparator1";
            this.MniFileSeparator1.Size = new System.Drawing.Size(200, 6);
            // 
            // MniFileSave
            // 
            this.MniFileSave.Enabled = false;
            this.MniFileSave.Image = global::ElectricalAppliances.Properties.Resources.disk;
            this.MniFileSave.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MniFileSave.Name = "MniFileSave";
            this.MniFileSave.Size = new System.Drawing.Size(203, 38);
            this.MniFileSave.Text = "Сохранить";
            this.MniFileSave.Click += new System.EventHandler(this.Save_Command);
            // 
            // MniFileSaveAs
            // 
            this.MniFileSaveAs.Image = global::ElectricalAppliances.Properties.Resources.save_as;
            this.MniFileSaveAs.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MniFileSaveAs.Name = "MniFileSaveAs";
            this.MniFileSaveAs.Size = new System.Drawing.Size(203, 38);
            this.MniFileSaveAs.Text = "Сохранить как...";
            this.MniFileSaveAs.Click += new System.EventHandler(this.SaveAs_Command);
            // 
            // MniFileSeparator2
            // 
            this.MniFileSeparator2.Name = "MniFileSeparator2";
            this.MniFileSeparator2.Size = new System.Drawing.Size(200, 6);
            // 
            // MniFileExit
            // 
            this.MniFileExit.Image = global::ElectricalAppliances.Properties.Resources.door_out;
            this.MniFileExit.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MniFileExit.Name = "MniFileExit";
            this.MniFileExit.Size = new System.Drawing.Size(203, 38);
            this.MniFileExit.Text = "Выход";
            this.MniFileExit.Click += new System.EventHandler(this.Exit_Command);
            // 
            // MniApartment
            // 
            this.MniApartment.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.новаяКвартираToolStripMenuItem,
            this.редактироватьToolStripMenuItem});
            this.MniApartment.Name = "MniApartment";
            this.MniApartment.Size = new System.Drawing.Size(87, 24);
            this.MniApartment.Text = "Квартира";
            // 
            // новаяКвартираToolStripMenuItem
            // 
            this.новаяКвартираToolStripMenuItem.Name = "новаяКвартираToolStripMenuItem";
            this.новаяКвартираToolStripMenuItem.Size = new System.Drawing.Size(199, 24);
            this.новаяКвартираToolStripMenuItem.Text = "Новая квартира...";
            // 
            // редактироватьToolStripMenuItem
            // 
            this.редактироватьToolStripMenuItem.Name = "редактироватьToolStripMenuItem";
            this.редактироватьToolStripMenuItem.Size = new System.Drawing.Size(199, 24);
            this.редактироватьToolStripMenuItem.Text = "Редактировать...";
            // 
            // MniControl
            // 
            this.MniControl.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniControlToTray,
            this.MniControlSeparator1,
            this.MniControlTurnApplianceOn,
            this.MniControlTurnApplianceOff,
            this.MniControlSeparator2,
            this.MniControlTurnOnAll,
            this.MniControlTurnOffAll});
            this.MniControl.Name = "MniControl";
            this.MniControl.Size = new System.Drawing.Size(106, 24);
            this.MniControl.Text = "Управление";
            // 
            // MniControlToTray
            // 
            this.MniControlToTray.Image = global::ElectricalAppliances.Properties.Resources.arrow_in;
            this.MniControlToTray.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MniControlToTray.Name = "MniControlToTray";
            this.MniControlToTray.Size = new System.Drawing.Size(268, 38);
            this.MniControlToTray.Text = "Свернуть в трей";
            this.MniControlToTray.Click += new System.EventHandler(this.ToTray_Command);
            // 
            // MniControlSeparator1
            // 
            this.MniControlSeparator1.Name = "MniControlSeparator1";
            this.MniControlSeparator1.Size = new System.Drawing.Size(265, 6);
            // 
            // MniControlTurnApplianceOn
            // 
            this.MniControlTurnApplianceOn.Image = global::ElectricalAppliances.Properties.Resources.ledon1;
            this.MniControlTurnApplianceOn.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MniControlTurnApplianceOn.Name = "MniControlTurnApplianceOn";
            this.MniControlTurnApplianceOn.Size = new System.Drawing.Size(268, 38);
            this.MniControlTurnApplianceOn.Text = "Включить прибор...";
            this.MniControlTurnApplianceOn.Click += new System.EventHandler(this.TurnOnSelected_Command);
            // 
            // MniControlTurnApplianceOff
            // 
            this.MniControlTurnApplianceOff.Image = global::ElectricalAppliances.Properties.Resources.ledoff1;
            this.MniControlTurnApplianceOff.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MniControlTurnApplianceOff.Name = "MniControlTurnApplianceOff";
            this.MniControlTurnApplianceOff.Size = new System.Drawing.Size(268, 38);
            this.MniControlTurnApplianceOff.Text = "Выключить прибор...";
            this.MniControlTurnApplianceOff.Click += new System.EventHandler(this.TurnOffSelected_Command);
            // 
            // MniControlSeparator2
            // 
            this.MniControlSeparator2.Name = "MniControlSeparator2";
            this.MniControlSeparator2.Size = new System.Drawing.Size(265, 6);
            // 
            // MniControlTurnOnAll
            // 
            this.MniControlTurnOnAll.Image = global::ElectricalAppliances.Properties.Resources.lightbulb;
            this.MniControlTurnOnAll.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MniControlTurnOnAll.Name = "MniControlTurnOnAll";
            this.MniControlTurnOnAll.Size = new System.Drawing.Size(268, 38);
            this.MniControlTurnOnAll.Text = "Включить все приборы";
            this.MniControlTurnOnAll.Click += new System.EventHandler(this.TurnOnAll_Commad);
            // 
            // MniControlTurnOffAll
            // 
            this.MniControlTurnOffAll.Image = global::ElectricalAppliances.Properties.Resources.lightbulb_off;
            this.MniControlTurnOffAll.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MniControlTurnOffAll.Name = "MniControlTurnOffAll";
            this.MniControlTurnOffAll.Size = new System.Drawing.Size(268, 38);
            this.MniControlTurnOffAll.Text = "Выключить все приборы";
            this.MniControlTurnOffAll.Click += new System.EventHandler(this.TurnOffAll_Commad);
            // 
            // MniReport
            // 
            this.MniReport.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniReportOrder,
            this.MniReportSelect});
            this.MniReport.Name = "MniReport";
            this.MniReport.Size = new System.Drawing.Size(71, 24);
            this.MniReport.Text = "Отчеты";
            // 
            // MniReportOrder
            // 
            this.MniReportOrder.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniReportOrderByName,
            this.MniReportOrderByState,
            this.MniReportOrderByPower,
            this.MniReportOrderByPrice});
            this.MniReportOrder.Name = "MniReportOrder";
            this.MniReportOrder.Size = new System.Drawing.Size(170, 24);
            this.MniReportOrder.Text = "Упорядочить";
            // 
            // MniReportOrderByName
            // 
            this.MniReportOrderByName.Name = "MniReportOrderByName";
            this.MniReportOrderByName.Size = new System.Drawing.Size(216, 24);
            this.MniReportOrderByName.Text = "По названию";
            this.MniReportOrderByName.Click += new System.EventHandler(this.OrderByName_Command);
            // 
            // MniReportOrderByState
            // 
            this.MniReportOrderByState.Name = "MniReportOrderByState";
            this.MniReportOrderByState.Size = new System.Drawing.Size(216, 24);
            this.MniReportOrderByState.Text = "По состоянию";
            this.MniReportOrderByState.Click += new System.EventHandler(this.OrderByState_Command);
            // 
            // MniReportOrderByPower
            // 
            this.MniReportOrderByPower.Name = "MniReportOrderByPower";
            this.MniReportOrderByPower.Size = new System.Drawing.Size(216, 24);
            this.MniReportOrderByPower.Text = "По мощности";
            this.MniReportOrderByPower.Click += new System.EventHandler(this.OrderByPower_Command);
            // 
            // MniReportOrderByPrice
            // 
            this.MniReportOrderByPrice.Name = "MniReportOrderByPrice";
            this.MniReportOrderByPrice.Size = new System.Drawing.Size(216, 24);
            this.MniReportOrderByPrice.Text = "По убыванию цены";
            this.MniReportOrderByPrice.Click += new System.EventHandler(this.OrderByPriceDesc_Command);
            // 
            // MniReportSelect
            // 
            this.MniReportSelect.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniReportSelectByName,
            this.MniReportSelectByState});
            this.MniReportSelect.Name = "MniReportSelect";
            this.MniReportSelect.Size = new System.Drawing.Size(170, 24);
            this.MniReportSelect.Text = "Выбрать";
            // 
            // MniReportSelectByName
            // 
            this.MniReportSelectByName.Name = "MniReportSelectByName";
            this.MniReportSelectByName.Size = new System.Drawing.Size(178, 24);
            this.MniReportSelectByName.Text = "По названию";
            // 
            // MniReportSelectByState
            // 
            this.MniReportSelectByState.Name = "MniReportSelectByState";
            this.MniReportSelectByState.Size = new System.Drawing.Size(178, 24);
            this.MniReportSelectByState.Text = "По состоянию";
            // 
            // MniHelp
            // 
            this.MniHelp.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniHelpAbout});
            this.MniHelp.Name = "MniHelp";
            this.MniHelp.Size = new System.Drawing.Size(79, 24);
            this.MniHelp.Text = "Справка";
            // 
            // MniHelpAbout
            // 
            this.MniHelpAbout.Image = global::ElectricalAppliances.Properties.Resources.help;
            this.MniHelpAbout.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MniHelpAbout.Name = "MniHelpAbout";
            this.MniHelpAbout.Size = new System.Drawing.Size(198, 38);
            this.MniHelpAbout.Text = "О программе...";
            this.MniHelpAbout.Click += new System.EventHandler(this.About_Command);
            // 
            // TstMain
            // 
            this.TstMain.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TstMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.TsbNew,
            this.TsbOpen,
            this.TsbSave,
            this.TstSeparator1,
            this.TsbEditApartment,
            this.TsbToTray,
            this.TstSeparator2,
            this.TsbTurnOnAll,
            this.TsbTurnOffAll,
            this.TstSeparator3,
            this.TsbAbout,
            this.TsbExit});
            this.TstMain.Location = new System.Drawing.Point(0, 28);
            this.TstMain.Name = "TstMain";
            this.TstMain.Size = new System.Drawing.Size(1184, 39);
            this.TstMain.TabIndex = 1;
            this.TstMain.Text = "toolStrip1";
            // 
            // TsbNew
            // 
            this.TsbNew.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbNew.Image = global::ElectricalAppliances.Properties.Resources._new;
            this.TsbNew.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbNew.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbNew.Name = "TsbNew";
            this.TsbNew.Size = new System.Drawing.Size(36, 36);
            this.TsbNew.Text = "toolStripButton1";
            this.TsbNew.ToolTipText = "Новая квартира...";
            // 
            // TsbOpen
            // 
            this.TsbOpen.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbOpen.Image = global::ElectricalAppliances.Properties.Resources.folder;
            this.TsbOpen.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbOpen.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbOpen.Name = "TsbOpen";
            this.TsbOpen.Size = new System.Drawing.Size(36, 36);
            this.TsbOpen.Text = "toolStripButton2";
            this.TsbOpen.ToolTipText = "Открыть файл данных...";
            this.TsbOpen.Click += new System.EventHandler(this.OpenFile_Command);
            // 
            // TsbSave
            // 
            this.TsbSave.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbSave.Enabled = false;
            this.TsbSave.Image = global::ElectricalAppliances.Properties.Resources.disk;
            this.TsbSave.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbSave.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbSave.Name = "TsbSave";
            this.TsbSave.Size = new System.Drawing.Size(36, 36);
            this.TsbSave.Text = "toolStripButton3";
            this.TsbSave.ToolTipText = "Сохранить данные квартиры";
            this.TsbSave.Click += new System.EventHandler(this.Save_Command);
            // 
            // TstSeparator1
            // 
            this.TstSeparator1.Name = "TstSeparator1";
            this.TstSeparator1.Size = new System.Drawing.Size(6, 39);
            // 
            // TsbEditApartment
            // 
            this.TsbEditApartment.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbEditApartment.Image = global::ElectricalAppliances.Properties.Resources.pencil;
            this.TsbEditApartment.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbEditApartment.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbEditApartment.Name = "TsbEditApartment";
            this.TsbEditApartment.Size = new System.Drawing.Size(36, 36);
            this.TsbEditApartment.Text = "toolStripButton5";
            // 
            // TsbToTray
            // 
            this.TsbToTray.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbToTray.Image = global::ElectricalAppliances.Properties.Resources.arrow_in;
            this.TsbToTray.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbToTray.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbToTray.Name = "TsbToTray";
            this.TsbToTray.Size = new System.Drawing.Size(36, 36);
            this.TsbToTray.Text = "toolStripButton6";
            // 
            // TstSeparator2
            // 
            this.TstSeparator2.Name = "TstSeparator2";
            this.TstSeparator2.Size = new System.Drawing.Size(6, 39);
            // 
            // TsbTurnOnAll
            // 
            this.TsbTurnOnAll.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbTurnOnAll.Image = global::ElectricalAppliances.Properties.Resources.lightbulb;
            this.TsbTurnOnAll.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbTurnOnAll.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbTurnOnAll.Name = "TsbTurnOnAll";
            this.TsbTurnOnAll.Size = new System.Drawing.Size(36, 36);
            this.TsbTurnOnAll.ToolTipText = "Включить все приборы квартиры";
            this.TsbTurnOnAll.Click += new System.EventHandler(this.TurnOnAll_Commad);
            // 
            // TsbTurnOffAll
            // 
            this.TsbTurnOffAll.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbTurnOffAll.Image = global::ElectricalAppliances.Properties.Resources.lightbulb_off;
            this.TsbTurnOffAll.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbTurnOffAll.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbTurnOffAll.Name = "TsbTurnOffAll";
            this.TsbTurnOffAll.Size = new System.Drawing.Size(36, 36);
            this.TsbTurnOffAll.ToolTipText = "Выключить все приборы квартиры";
            this.TsbTurnOffAll.Click += new System.EventHandler(this.TurnOffAll_Commad);
            // 
            // TstSeparator3
            // 
            this.TstSeparator3.Name = "TstSeparator3";
            this.TstSeparator3.Size = new System.Drawing.Size(6, 39);
            // 
            // TsbAbout
            // 
            this.TsbAbout.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbAbout.Image = global::ElectricalAppliances.Properties.Resources.help;
            this.TsbAbout.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbAbout.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbAbout.Name = "TsbAbout";
            this.TsbAbout.Size = new System.Drawing.Size(36, 36);
            this.TsbAbout.ToolTipText = "Сведения о приложении и разработчике";
            this.TsbAbout.Click += new System.EventHandler(this.About_Command);
            // 
            // TsbExit
            // 
            this.TsbExit.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.TsbExit.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbExit.Image = global::ElectricalAppliances.Properties.Resources.door_out;
            this.TsbExit.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbExit.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbExit.Name = "TsbExit";
            this.TsbExit.Size = new System.Drawing.Size(36, 36);
            this.TsbExit.ToolTipText = "Завершение приложение";
            this.TsbExit.Click += new System.EventHandler(this.Exit_Command);
            // 
            // StsMain
            // 
            this.StsMain.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.StsMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.TslStatus,
            this.TslOn,
            this.TslOff,
            this.TslFileName});
            this.StsMain.Location = new System.Drawing.Point(0, 616);
            this.StsMain.Name = "StsMain";
            this.StsMain.Size = new System.Drawing.Size(1184, 25);
            this.StsMain.TabIndex = 2;
            this.StsMain.Text = "statusStrip1";
            // 
            // TslStatus
            // 
            this.TslStatus.AutoSize = false;
            this.TslStatus.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenInner;
            this.TslStatus.Name = "TslStatus";
            this.TslStatus.Padding = new System.Windows.Forms.Padding(6, 0, 0, 0);
            this.TslStatus.Size = new System.Drawing.Size(280, 20);
            this.TslStatus.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // TslOn
            // 
            this.TslOn.AutoSize = false;
            this.TslOn.BackColor = System.Drawing.Color.Aquamarine;
            this.TslOn.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenInner;
            this.TslOn.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.TslOn.Name = "TslOn";
            this.TslOn.Padding = new System.Windows.Forms.Padding(6, 0, 0, 0);
            this.TslOn.Size = new System.Drawing.Size(140, 20);
            this.TslOn.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // TslOff
            // 
            this.TslOff.AutoSize = false;
            this.TslOff.BackColor = System.Drawing.Color.Thistle;
            this.TslOff.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenInner;
            this.TslOff.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.TslOff.Name = "TslOff";
            this.TslOff.Padding = new System.Windows.Forms.Padding(6, 0, 0, 0);
            this.TslOff.Size = new System.Drawing.Size(140, 20);
            this.TslOff.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // TslFileName
            // 
            this.TslFileName.Name = "TslFileName";
            this.TslFileName.Size = new System.Drawing.Size(609, 20);
            this.TslFileName.Spring = true;
            this.TslFileName.Text = "Имя файла данных";
            this.TslFileName.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // CmnNotify
            // 
            this.CmnNotify.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.CmnNotify.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.CmiRestore,
            this.CmiNotifySeparator1,
            this.CmiAbout,
            this.CmiNotifySeparator2,
            this.CmiExit});
            this.CmnNotify.Name = "contextMenuStrip1";
            this.CmnNotify.Size = new System.Drawing.Size(199, 130);
            // 
            // CmiRestore
            // 
            this.CmiRestore.Image = global::ElectricalAppliances.Properties.Resources.arrow_out;
            this.CmiRestore.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.CmiRestore.Name = "CmiRestore";
            this.CmiRestore.Size = new System.Drawing.Size(198, 38);
            this.CmiRestore.Text = "Восстановить";
            this.CmiRestore.Click += new System.EventHandler(this.FromTray_Command);
            // 
            // CmiNotifySeparator1
            // 
            this.CmiNotifySeparator1.Name = "CmiNotifySeparator1";
            this.CmiNotifySeparator1.Size = new System.Drawing.Size(195, 6);
            // 
            // CmiAbout
            // 
            this.CmiAbout.Name = "CmiAbout";
            this.CmiAbout.Size = new System.Drawing.Size(198, 38);
            this.CmiAbout.Text = "О программе...";
            this.CmiAbout.Click += new System.EventHandler(this.About_Command);
            // 
            // CmiNotifySeparator2
            // 
            this.CmiNotifySeparator2.Name = "CmiNotifySeparator2";
            this.CmiNotifySeparator2.Size = new System.Drawing.Size(195, 6);
            // 
            // CmiExit
            // 
            this.CmiExit.Name = "CmiExit";
            this.CmiExit.Size = new System.Drawing.Size(198, 38);
            this.CmiExit.Text = "Выход";
            this.CmiExit.Click += new System.EventHandler(this.Exit_Command);
            // 
            // CmnListView
            // 
            this.CmnListView.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.CmnListView.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.CmiListViewTurnOn,
            this.CmiListViewTurnOff,
            this.CmiListViewSeparator1,
            this.CmiListViewTurnOnAll,
            this.CmiListViewTurnOffAll,
            this.CmiListViewSeparator2,
            this.CmiListViewToTray});
            this.CmnListView.Name = "contextMenuStrip2";
            this.CmnListView.Size = new System.Drawing.Size(253, 136);
            // 
            // CmiListViewTurnOn
            // 
            this.CmiListViewTurnOn.Name = "CmiListViewTurnOn";
            this.CmiListViewTurnOn.Size = new System.Drawing.Size(252, 24);
            this.CmiListViewTurnOn.Text = "Включить прибор";
            this.CmiListViewTurnOn.Click += new System.EventHandler(this.TurnOnSelected_Command);
            // 
            // CmiListViewTurnOff
            // 
            this.CmiListViewTurnOff.Name = "CmiListViewTurnOff";
            this.CmiListViewTurnOff.Size = new System.Drawing.Size(252, 24);
            this.CmiListViewTurnOff.Text = "Выключить прибор";
            this.CmiListViewTurnOff.Click += new System.EventHandler(this.TurnOffSelected_Command);
            // 
            // CmiListViewSeparator1
            // 
            this.CmiListViewSeparator1.Name = "CmiListViewSeparator1";
            this.CmiListViewSeparator1.Size = new System.Drawing.Size(249, 6);
            // 
            // CmiListViewTurnOnAll
            // 
            this.CmiListViewTurnOnAll.Name = "CmiListViewTurnOnAll";
            this.CmiListViewTurnOnAll.Size = new System.Drawing.Size(252, 24);
            this.CmiListViewTurnOnAll.Text = "Включить все приборы";
            this.CmiListViewTurnOnAll.Click += new System.EventHandler(this.TurnOnAll_Commad);
            // 
            // CmiListViewTurnOffAll
            // 
            this.CmiListViewTurnOffAll.Name = "CmiListViewTurnOffAll";
            this.CmiListViewTurnOffAll.Size = new System.Drawing.Size(252, 24);
            this.CmiListViewTurnOffAll.Text = "Выключить все приборы";
            this.CmiListViewTurnOffAll.Click += new System.EventHandler(this.TurnOffAll_Commad);
            // 
            // CmiListViewSeparator2
            // 
            this.CmiListViewSeparator2.Name = "CmiListViewSeparator2";
            this.CmiListViewSeparator2.Size = new System.Drawing.Size(249, 6);
            // 
            // CmiListViewToTray
            // 
            this.CmiListViewToTray.Name = "CmiListViewToTray";
            this.CmiListViewToTray.Size = new System.Drawing.Size(252, 24);
            this.CmiListViewToTray.Text = "Свернуть в трей";
            this.CmiListViewToTray.Click += new System.EventHandler(this.ToTray_Command);
            // 
            // ImlSmall
            // 
            this.ImlSmall.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("ImlSmall.ImageStream")));
            this.ImlSmall.TransparentColor = System.Drawing.Color.Transparent;
            this.ImlSmall.Images.SetKeyName(0, "ledoff.png");
            this.ImlSmall.Images.SetKeyName(1, "ledon.png");
            this.ImlSmall.Images.SetKeyName(2, "house.png");
            this.ImlSmall.Images.SetKeyName(3, "control_panel.png");
            // 
            // OfdMain
            // 
            this.OfdMain.Filter = "Данные квартиры (*.json)|*.json|Все файлы (*.*)|*.*";
            this.OfdMain.Title = "Открыть файл данных квартиры";
            // 
            // SfdMain
            // 
            this.SfdMain.DefaultExt = "json";
            this.SfdMain.Filter = "Данные квартиры (*.json)|*.json|Все файлы (*.*)|*.*";
            this.SfdMain.Title = "Сохранить данные квартиры";
            // 
            // NtfMain
            // 
            this.NtfMain.ContextMenuStrip = this.CmnNotify;
            this.NtfMain.Icon = ((System.Drawing.Icon)(resources.GetObject("NtfMain.Icon")));
            this.NtfMain.Text = "Управление электроприборами\r\nквартиры";
            // 
            // LblApartmentInfo
            // 
            this.LblApartmentInfo.Dock = System.Windows.Forms.DockStyle.Top;
            this.LblApartmentInfo.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblApartmentInfo.Location = new System.Drawing.Point(0, 67);
            this.LblApartmentInfo.Name = "LblApartmentInfo";
            this.LblApartmentInfo.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.LblApartmentInfo.Size = new System.Drawing.Size(1184, 27);
            this.LblApartmentInfo.TabIndex = 3;
            this.LblApartmentInfo.Text = "Место для вывода адреса квартиры";
            this.LblApartmentInfo.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // TbcMain
            // 
            this.TbcMain.Controls.Add(this.TbpAppliances);
            this.TbcMain.Controls.Add(this.TbpSorted);
            this.TbcMain.Controls.Add(this.TbpSelected);
            this.TbcMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TbcMain.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TbcMain.Location = new System.Drawing.Point(0, 94);
            this.TbcMain.Name = "TbcMain";
            this.TbcMain.SelectedIndex = 0;
            this.TbcMain.Size = new System.Drawing.Size(1184, 522);
            this.TbcMain.TabIndex = 6;
            // 
            // TbpAppliances
            // 
            this.TbpAppliances.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.TbpAppliances.Controls.Add(this.splitContainer1);
            this.TbpAppliances.Location = new System.Drawing.Point(4, 27);
            this.TbpAppliances.Name = "TbpAppliances";
            this.TbpAppliances.Padding = new System.Windows.Forms.Padding(3);
            this.TbpAppliances.Size = new System.Drawing.Size(1176, 491);
            this.TbpAppliances.TabIndex = 0;
            this.TbpAppliances.Text = "Приборы квартиры";
            this.TbpAppliances.ToolTipText = "Коллекция приборов квартиры";
            this.TbpAppliances.UseVisualStyleBackColor = true;
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(3, 3);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.TrvApartment);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.LsvAppliances);
            this.splitContainer1.Size = new System.Drawing.Size(1166, 481);
            this.splitContainer1.SplitterDistance = 270;
            this.splitContainer1.TabIndex = 0;
            // 
            // TrvApartment
            // 
            this.TrvApartment.AllowDrop = true;
            this.TrvApartment.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TrvApartment.ImageIndex = 2;
            this.TrvApartment.ImageList = this.ImlSmall;
            this.TrvApartment.Location = new System.Drawing.Point(0, 0);
            this.TrvApartment.Name = "TrvApartment";
            treeNode1.Name = "ApartmentNode";
            treeNode1.Text = "Квартира";
            treeNode1.ToolTipText = "Это адрес квартиры";
            this.TrvApartment.Nodes.AddRange(new System.Windows.Forms.TreeNode[] {
            treeNode1});
            this.TrvApartment.SelectedImageIndex = 0;
            this.TrvApartment.Size = new System.Drawing.Size(270, 481);
            this.TrvApartment.TabIndex = 0;
            this.TrvApartment.NodeMouseClick += new System.Windows.Forms.TreeNodeMouseClickEventHandler(this.CorrectBehavor_NodeMouseClick);
            this.TrvApartment.DragDrop += new System.Windows.Forms.DragEventHandler(this.Handler_DragDrop);
            this.TrvApartment.DragEnter += new System.Windows.Forms.DragEventHandler(this.Object_DragEnter);
            this.TrvApartment.MouseUp += new System.Windows.Forms.MouseEventHandler(this.CorrectBehavor_MouseUp);
            // 
            // LsvAppliances
            // 
            this.LsvAppliances.AllowDrop = true;
            this.LsvAppliances.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.ClhState,
            this.ClhId,
            this.ClhRoom,
            this.ClhName,
            this.ClhPower,
            this.ClhPrice});
            this.LsvAppliances.ContextMenuStrip = this.CmnListView;
            this.LsvAppliances.Dock = System.Windows.Forms.DockStyle.Fill;
            this.LsvAppliances.FullRowSelect = true;
            this.LsvAppliances.GridLines = true;
            this.LsvAppliances.HideSelection = false;
            this.LsvAppliances.LabelEdit = true;
            this.LsvAppliances.Location = new System.Drawing.Point(0, 0);
            this.LsvAppliances.MultiSelect = false;
            this.LsvAppliances.Name = "LsvAppliances";
            this.LsvAppliances.Size = new System.Drawing.Size(892, 481);
            this.LsvAppliances.SmallImageList = this.ImlSmall;
            this.LsvAppliances.TabIndex = 1;
            this.LsvAppliances.UseCompatibleStateImageBehavior = false;
            this.LsvAppliances.View = System.Windows.Forms.View.Details;
            this.LsvAppliances.DragDrop += new System.Windows.Forms.DragEventHandler(this.Handler_DragDrop);
            this.LsvAppliances.DragEnter += new System.Windows.Forms.DragEventHandler(this.Object_DragEnter);
            // 
            // ClhState
            // 
            this.ClhState.Text = "Состояние";
            this.ClhState.Width = 120;
            // 
            // ClhId
            // 
            this.ClhId.Text = "Идентификатор";
            this.ClhId.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.ClhId.Width = 140;
            // 
            // ClhRoom
            // 
            this.ClhRoom.Text = "Комната";
            this.ClhRoom.Width = 120;
            // 
            // ClhName
            // 
            this.ClhName.Text = "Название";
            this.ClhName.Width = 260;
            // 
            // ClhPower
            // 
            this.ClhPower.Text = "Мощность, Вт";
            this.ClhPower.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.ClhPower.Width = 160;
            // 
            // ClhPrice
            // 
            this.ClhPrice.Text = "Цена, руб.";
            this.ClhPrice.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.ClhPrice.Width = 160;
            // 
            // TbpSorted
            // 
            this.TbpSorted.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.TbpSorted.Controls.Add(this.LsvOrdered);
            this.TbpSorted.Location = new System.Drawing.Point(4, 27);
            this.TbpSorted.Name = "TbpSorted";
            this.TbpSorted.Padding = new System.Windows.Forms.Padding(3);
            this.TbpSorted.Size = new System.Drawing.Size(1176, 491);
            this.TbpSorted.TabIndex = 1;
            this.TbpSorted.Text = "Упорядоченная коллекция";
            this.TbpSorted.UseVisualStyleBackColor = true;
            // 
            // LsvOrdered
            // 
            this.LsvOrdered.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3,
            this.columnHeader4,
            this.columnHeader5});
            this.LsvOrdered.Dock = System.Windows.Forms.DockStyle.Fill;
            this.LsvOrdered.FullRowSelect = true;
            this.LsvOrdered.GridLines = true;
            this.LsvOrdered.HideSelection = false;
            this.LsvOrdered.LabelEdit = true;
            this.LsvOrdered.Location = new System.Drawing.Point(3, 3);
            this.LsvOrdered.MultiSelect = false;
            this.LsvOrdered.Name = "LsvOrdered";
            this.LsvOrdered.Size = new System.Drawing.Size(1166, 481);
            this.LsvOrdered.SmallImageList = this.ImlSmall;
            this.LsvOrdered.TabIndex = 1;
            this.LsvOrdered.UseCompatibleStateImageBehavior = false;
            this.LsvOrdered.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Состояние";
            this.columnHeader1.Width = 120;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Идентификатор";
            this.columnHeader2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.columnHeader2.Width = 180;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Название";
            this.columnHeader3.Width = 260;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "Мощность, Вт";
            this.columnHeader4.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.columnHeader4.Width = 160;
            // 
            // columnHeader5
            // 
            this.columnHeader5.Text = "Цена, руб.";
            this.columnHeader5.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.columnHeader5.Width = 160;
            // 
            // TbpSelected
            // 
            this.TbpSelected.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.TbpSelected.Controls.Add(this.LsvFiltered);
            this.TbpSelected.Location = new System.Drawing.Point(4, 27);
            this.TbpSelected.Name = "TbpSelected";
            this.TbpSelected.Padding = new System.Windows.Forms.Padding(3);
            this.TbpSelected.Size = new System.Drawing.Size(1176, 491);
            this.TbpSelected.TabIndex = 2;
            this.TbpSelected.Text = "Выборка приборов";
            this.TbpSelected.UseVisualStyleBackColor = true;
            // 
            // LsvFiltered
            // 
            this.LsvFiltered.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader6,
            this.columnHeader7,
            this.columnHeader8,
            this.columnHeader9,
            this.columnHeader10});
            this.LsvFiltered.Dock = System.Windows.Forms.DockStyle.Fill;
            this.LsvFiltered.FullRowSelect = true;
            this.LsvFiltered.GridLines = true;
            this.LsvFiltered.HideSelection = false;
            this.LsvFiltered.LabelEdit = true;
            this.LsvFiltered.Location = new System.Drawing.Point(3, 3);
            this.LsvFiltered.MultiSelect = false;
            this.LsvFiltered.Name = "LsvFiltered";
            this.LsvFiltered.Size = new System.Drawing.Size(1166, 481);
            this.LsvFiltered.SmallImageList = this.ImlSmall;
            this.LsvFiltered.TabIndex = 1;
            this.LsvFiltered.UseCompatibleStateImageBehavior = false;
            this.LsvFiltered.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader6
            // 
            this.columnHeader6.Text = "Состояние";
            this.columnHeader6.Width = 120;
            // 
            // columnHeader7
            // 
            this.columnHeader7.Text = "Идентификатор";
            this.columnHeader7.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.columnHeader7.Width = 180;
            // 
            // columnHeader8
            // 
            this.columnHeader8.Text = "Название";
            this.columnHeader8.Width = 260;
            // 
            // columnHeader9
            // 
            this.columnHeader9.Text = "Мощность, Вт";
            this.columnHeader9.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.columnHeader9.Width = 160;
            // 
            // columnHeader10
            // 
            this.columnHeader10.Text = "Цена, руб.";
            this.columnHeader10.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.columnHeader10.Width = 160;
            // 
            // CmnTreeAppliance
            // 
            this.CmnTreeAppliance.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.CmnTreeAppliance.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem1,
            this.toolStripMenuItem2});
            this.CmnTreeAppliance.Name = "contextMenuStrip2";
            this.CmnTreeAppliance.Size = new System.Drawing.Size(231, 80);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Image = global::ElectricalAppliances.Properties.Resources.ledon1;
            this.toolStripMenuItem1.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(230, 38);
            this.toolStripMenuItem1.Text = "Включить прибор";
            this.toolStripMenuItem1.Click += new System.EventHandler(this.TurnOnApplianceCmnTree_Command);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Image = global::ElectricalAppliances.Properties.Resources.ledoff1;
            this.toolStripMenuItem2.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(230, 38);
            this.toolStripMenuItem2.Text = "Выключить прибор";
            this.toolStripMenuItem2.Click += new System.EventHandler(this.TurnOffApplianceCmnTree_Command);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1184, 641);
            this.Controls.Add(this.TbcMain);
            this.Controls.Add(this.LblApartmentInfo);
            this.Controls.Add(this.TstMain);
            this.Controls.Add(this.StsMain);
            this.Controls.Add(this.MnsMain);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.MnsMain;
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Задание на 01.12.2021 - изучение ListView";
            this.MnsMain.ResumeLayout(false);
            this.MnsMain.PerformLayout();
            this.TstMain.ResumeLayout(false);
            this.TstMain.PerformLayout();
            this.StsMain.ResumeLayout(false);
            this.StsMain.PerformLayout();
            this.CmnNotify.ResumeLayout(false);
            this.CmnListView.ResumeLayout(false);
            this.TbcMain.ResumeLayout(false);
            this.TbpAppliances.ResumeLayout(false);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.TbpSorted.ResumeLayout(false);
            this.TbpSelected.ResumeLayout(false);
            this.CmnTreeAppliance.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip MnsMain;
        private System.Windows.Forms.ToolStrip TstMain;
        private System.Windows.Forms.StatusStrip StsMain;
        private System.Windows.Forms.ContextMenuStrip CmnNotify;
        private System.Windows.Forms.ContextMenuStrip CmnListView;
        private System.Windows.Forms.ToolStripMenuItem MniFile;
        private System.Windows.Forms.ToolStripMenuItem MniFileOpen;
        private System.Windows.Forms.ToolStripMenuItem MniFileSave;
        private System.Windows.Forms.ToolStripMenuItem MniFileSaveAs;
        private System.Windows.Forms.ToolStripSeparator MniFileSeparator1;
        private System.Windows.Forms.ToolStripMenuItem MniFileExit;
        private System.Windows.Forms.ToolStripMenuItem MniApartment;
        private System.Windows.Forms.ToolStripMenuItem новаяКвартираToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem редактироватьToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem MniControl;
        private System.Windows.Forms.ToolStripMenuItem MniControlToTray;
        private System.Windows.Forms.ToolStripMenuItem MniReport;
        private System.Windows.Forms.ToolStripMenuItem MniHelp;
        private System.Windows.Forms.ToolStripMenuItem MniHelpAbout;
        private System.Windows.Forms.OpenFileDialog OfdMain;
        private System.Windows.Forms.SaveFileDialog SfdMain;
        private System.Windows.Forms.NotifyIcon NtfMain;
        private System.Windows.Forms.ToolStripButton TsbNew;
        private System.Windows.Forms.ToolStripButton TsbOpen;
        private System.Windows.Forms.ToolStripButton TsbSave;
        private System.Windows.Forms.ToolStripSeparator TstSeparator1;
        private System.Windows.Forms.ToolStripButton TsbEditApartment;
        private System.Windows.Forms.ToolStripSeparator TstSeparator2;
        private System.Windows.Forms.ToolStripButton TsbToTray;
        private System.Windows.Forms.ToolStripButton TsbTurnOnAll;
        private System.Windows.Forms.ToolStripStatusLabel TslStatus;
        private System.Windows.Forms.ToolStripSeparator MniControlSeparator1;
        private System.Windows.Forms.ToolStripMenuItem MniControlTurnApplianceOn;
        private System.Windows.Forms.ToolStripMenuItem MniControlTurnApplianceOff;
        private System.Windows.Forms.ToolStripSeparator MniControlSeparator2;
        private System.Windows.Forms.ToolStripMenuItem MniControlTurnOnAll;
        private System.Windows.Forms.ToolStripMenuItem MniControlTurnOffAll;
        private System.Windows.Forms.ToolStripMenuItem MniReportOrder;
        private System.Windows.Forms.ToolStripMenuItem MniReportSelect;
        private System.Windows.Forms.ToolStripButton TsbTurnOffAll;
        private System.Windows.Forms.ToolStripMenuItem CmiRestore;
        private System.Windows.Forms.ToolStripSeparator CmiNotifySeparator1;
        private System.Windows.Forms.ToolStripMenuItem CmiAbout;
        private System.Windows.Forms.ToolStripSeparator CmiNotifySeparator2;
        private System.Windows.Forms.ToolStripMenuItem CmiExit;
        private System.Windows.Forms.ToolStripMenuItem MniReportOrderByName;
        private System.Windows.Forms.ToolStripMenuItem MniReportOrderByState;
        private System.Windows.Forms.ToolStripMenuItem MniReportOrderByPower;
        private System.Windows.Forms.ToolStripMenuItem MniReportOrderByPrice;
        private System.Windows.Forms.ToolStripMenuItem MniReportSelectByName;
        private System.Windows.Forms.ToolStripMenuItem MniReportSelectByState;
        private System.Windows.Forms.ImageList ImlSmall;
        private System.Windows.Forms.Label LblApartmentInfo;
        private System.Windows.Forms.TabControl TbcMain;
        private System.Windows.Forms.TabPage TbpAppliances;
        private System.Windows.Forms.TabPage TbpSorted;
        private System.Windows.Forms.ListView LsvOrdered;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.ColumnHeader columnHeader5;
        private System.Windows.Forms.TabPage TbpSelected;
        private System.Windows.Forms.ListView LsvFiltered;
        private System.Windows.Forms.ColumnHeader columnHeader6;
        private System.Windows.Forms.ColumnHeader columnHeader7;
        private System.Windows.Forms.ColumnHeader columnHeader8;
        private System.Windows.Forms.ColumnHeader columnHeader9;
        private System.Windows.Forms.ColumnHeader columnHeader10;
        private System.Windows.Forms.ToolStripStatusLabel TslOn;
        private System.Windows.Forms.ToolStripStatusLabel TslOff;
        private System.Windows.Forms.ToolStripMenuItem CmiListViewTurnOn;
        private System.Windows.Forms.ToolStripMenuItem CmiListViewTurnOff;
        private System.Windows.Forms.ToolStripSeparator CmiListViewSeparator1;
        private System.Windows.Forms.ToolStripMenuItem CmiListViewTurnOnAll;
        private System.Windows.Forms.ToolStripMenuItem CmiListViewTurnOffAll;
        private System.Windows.Forms.ToolStripSeparator CmiListViewSeparator2;
        private System.Windows.Forms.ToolStripMenuItem CmiListViewToTray;
        private System.Windows.Forms.ToolStripSeparator TstSeparator3;
        private System.Windows.Forms.ToolStripButton TsbAbout;
        private System.Windows.Forms.ToolStripButton TsbExit;
        private System.Windows.Forms.ToolStripSeparator MniFileSeparator2;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.TreeView TrvApartment;
        private System.Windows.Forms.ListView LsvAppliances;
        private System.Windows.Forms.ColumnHeader ClhState;
        private System.Windows.Forms.ColumnHeader ClhId;
        private System.Windows.Forms.ColumnHeader ClhName;
        private System.Windows.Forms.ColumnHeader ClhPower;
        private System.Windows.Forms.ColumnHeader ClhPrice;
        private System.Windows.Forms.ToolStripStatusLabel TslFileName;
        private System.Windows.Forms.ColumnHeader ClhRoom;
        private System.Windows.Forms.ContextMenuStrip CmnTreeAppliance;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
    }
}

