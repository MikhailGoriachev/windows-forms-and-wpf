﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using ElectricalAppliances.Controllers;
using ElectricalAppliances.Models;

namespace ElectricalAppliances.Views
{
    public partial class MainForm : Form
    {
        // контроллер для обработки данных по заданию
        private ApartmentController _apartmentController;

        public MainForm():this(new ApartmentController()) {} // MainForm

        public MainForm(ApartmentController apartmentController) {
            InitializeComponent();

            // получить данные по контроллеру 
            _apartmentController = apartmentController;

            // Вывести адрес квартиры
            LblApartmentInfo.Text = _apartmentController.Apartment.Address;

            // сформировать данные в ListView: приборы, отсортированные приборы, выборка по наименованию
            FillListView(_apartmentController.GetAll(), LsvAppliances);
            FillListView(_apartmentController.OrderByBrand(), LsvOrdered);
            FillListView(_apartmentController.SelectWhereName(_apartmentController.GetAll()[0].Name), LsvFiltered);

            // сформировать данные в TreeView
            FillTreeView(_apartmentController.GetAll(), TrvApartment);

            // Сформировать заголовок вкладки отсортированной коллекции
            TbpSorted.Text += ": по названию";
            
            // вывести количество приборов квартире
            TslStatus.Text = $"Количество приборов в квартире: {_apartmentController.Count}";
            TslOn.Text = $"Включено: {_apartmentController.SelectWhereState(true).Count}";
            TslOff.Text = $"Выключено: {_apartmentController.SelectWhereState(false).Count}";
        } // MainForm


        // вывод коллекции электроприборов в ListView в табличном формате,
        // состояние прибора отображать картинкой
        public void FillListView(List<Appliance> appliances, ListView listView) {
            listView.Items.Clear();

            appliances.ForEach(a => listView.Items.Add(a.ToListViewItem()));
        } // FillListView


        // заполнение элемента TreeView
        private void FillTreeView(List<Appliance> appliances, TreeView treeView) {
            treeView.Nodes.Clear();

            // заполнение словаря для формирования узлов дерева
            //         комната приборы
            Dictionary<string, List<Appliance>> nodes = new Dictionary<string, List<Appliance>>();
            foreach (var appliance in appliances) {
                // новый узел для добавления в дерево
                if (!nodes.ContainsKey(appliance.Room))
                    nodes[appliance.Room] = new List<Appliance>();
                
                // добавить прибор комнаты
                nodes[appliance.Room].Add(appliance);
            } // foreach appliance

            // формирование дерева
            treeView.Nodes.Add("", _apartmentController.Apartment.Address, 2, 2);
            foreach (var node in nodes) {
                // ссылка на очередной добавляемый узел дерева
                // указываем дважды индекс картинки, чтобы выбранный и невыбранный узлы 
                // выглядели одинаково
                var treeNode = treeView.Nodes[0].Nodes.Add("", node.Key, 3, 3);

                // добавить все приборы комнаты, соответствующей узлу дерева
                foreach (var appliance in node.Value) {
                    // индекс картинки для включенного и выключенного состояний приборов
                    int imageIndex = appliance.State ? 1 : 0;

                    TreeNode aplianceNode = treeNode.Nodes.Add("", appliance.Name, imageIndex, imageIndex);
               
                    // запомнить ссылку на прибор в теге узла
                    aplianceNode.Tag = appliance;

                    // назначить контекстное меню для прибора
                    aplianceNode.ContextMenuStrip = CmnTreeAppliance;
                }
            } // foreach node

            treeView.ExpandAll();
        } // FillTreeView


        // завершение приложения
        private void Exit_Command(object sender, EventArgs e) => Application.Exit();


        // свернуть в трей
        private void ToTray_Command(object sender, EventArgs e) {
            this.Hide();
            NtfMain.Visible = true;
        } // ToTray_Command


        // восстановить из трея
        private void FromTray_Command(object sender, EventArgs e) {
            this.Show();
            WindowState = FormWindowState.Normal;
            NtfMain.Visible = false;
        } // FromTray_Command


        // вывод формы со сведениями о приложении и разработчике
        private void About_Command(object sender, EventArgs e) {
            AboutForm aboutForm = new AboutForm();
            aboutForm.ShowDialog();
        } // About_Command


        // включить все приборы
        private void TurnOnAll_Commad(object sender, EventArgs e) {
            TbcMain.SelectedTab = TbpAppliances;

            _apartmentController.TurnAll(true);
            FillListView(_apartmentController.Apartment.Appliances, LsvAppliances);

            TslOn.Text = $"Включено: {_apartmentController.SelectWhereState(true).Count}";
            TslOff.Text = $"Выключено: {_apartmentController.SelectWhereState(false).Count}";
        } // TurnOnAll_Commad


        // выключить все приборы
        private void TurnOffAll_Commad(object sender, EventArgs e) {
            TbcMain.SelectedTab = TbpAppliances;

            _apartmentController.TurnAll(false);
            FillListView(_apartmentController.Apartment.Appliances, LsvAppliances);

            TslOn.Text = $"Включено: {_apartmentController.SelectWhereState(true).Count}";
            TslOff.Text = $"Выключено: {_apartmentController.SelectWhereState(false).Count}";
        } // TurnOnAll_Commad


        // включение выбранного прибора
        private void TurnOnSelected_Command(object sender, EventArgs e) {
            // выход, если нет выбранного прибора
            if (LsvAppliances.SelectedIndices.Count == 0) return;

            int index = LsvAppliances.SelectedIndices[0];
            _apartmentController.TurnAt(index, true);
            LsvAppliances.Items[index] = _apartmentController.Apartment[index].ToListViewItem();
            LsvAppliances.Items[index].Selected = true;

            TslOn.Text = $"Включено: {_apartmentController.SelectWhereState(true).Count}";
            TslOff.Text = $"Выключено: {_apartmentController.SelectWhereState(false).Count}";

            // перерисовать дерево
            FillTreeView(_apartmentController.GetAll(), TrvApartment);
        } // TurnOnSelected_Command


        // выключение выбранного в ListView прибора
        private void TurnOffSelected_Command(object sender, EventArgs e) {
            // выход, если нет выбранного прибора
            if (LsvAppliances.SelectedIndices.Count == 0) return;

            int index = LsvAppliances.SelectedIndices[0];
            _apartmentController.TurnAt(index, false);
            LsvAppliances.Items[index] = _apartmentController.Apartment[index].ToListViewItem();
            LsvAppliances.Items[index].Selected = true;

            TslOn.Text = $"Включено: {_apartmentController.SelectWhereState(true).Count}";
            TslOff.Text = $"Выключено: {_apartmentController.SelectWhereState(false).Count}";

            // перерисовать дерево
            FillTreeView(_apartmentController.GetAll(), TrvApartment);
        } // TurnOffSelected_Command


        // сортировка коллекции по названию прибора
        private void OrderByName_Command(object sender, EventArgs e) {
            TbcMain.SelectedTab = TbpSorted;

            FillListView(_apartmentController.OrderByBrand(), LsvOrdered);

            // скорректировать название вкладки
            TbpSorted.Text = TbpSorted.Text.Remove(TbpSorted.Text.IndexOf(":")+1) + " по названию";
        } // OrderByName_Command


        // сортировка коллекции по состоянию прибора
        private void OrderByState_Command(object sender, EventArgs e) {
            TbcMain.SelectedTab = TbpSorted;

            FillListView(_apartmentController.OrderByState(), LsvOrdered);

            // скорректировать название вкладки
            TbpSorted.Text = TbpSorted.Text.Remove(TbpSorted.Text.IndexOf(":")+1) + " по состоянию";
        } // OrderByState_Command


        // сортировка коллекции по мощности прибора
        private void OrderByPower_Command(object sender, EventArgs e) {
            TbcMain.SelectedTab = TbpSorted;

            FillListView(_apartmentController.OrderByPower(), LsvOrdered);

            // скорректировать название вкладки
            TbpSorted.Text = TbpSorted.Text.Remove(TbpSorted.Text.IndexOf(":") + 1) + " по мощности";
        } // OrderByPower_Command


        // сортировка коллекции по убыванию цены прибора
        private void OrderByPriceDesc_Command(object sender, EventArgs e) {
            TbcMain.SelectedTab = TbpSorted;

            FillListView(_apartmentController.OrderByPriceDesc(), LsvOrdered);

            // скорректировать название вкладки
            TbpSorted.Text = TbpSorted.Text.Remove(TbpSorted.Text.IndexOf(":") + 1) + " по убыванию цены";
        } // OrderByPriceDesc_Command


        // выбор и загрузка файла данных о квартире и коллекции приборов квартиры
        private void OpenFile_Command(object sender, EventArgs e) {
            // показать диалог выбора файла, если файл не выбран - молча уходим 
            if (OfdMain.ShowDialog() != DialogResult.OK) return;

            // загрузка выбранного файла
            _apartmentController.DataFileName = OfdMain.FileName;
            _apartmentController.DeserializeData();

            // отображение данных файла, обновление данных
            // сформировать данные в ListView: приборы, отсортированные приборы, выборка по наименованию
            FillListView(_apartmentController.GetAll(), LsvAppliances);
            FillListView(_apartmentController.OrderByBrand(), LsvOrdered);
            FillListView(_apartmentController.SelectWhereName(_apartmentController.GetAll()[0].Name), LsvFiltered);

            // вывести количество приборов квартире
            TslStatus.Text = $"Количество приборов в квартире: {_apartmentController.Count}";
            TslOn.Text = $"Включено: {_apartmentController.SelectWhereState(true).Count}";
            TslOff.Text = $"Выключено: {_apartmentController.SelectWhereState(false).Count}";

            // сделать первую (главную) вклдаку текущей
            TbcMain.SelectedTab = TbpAppliances;
        } // OpenFile_Command


        // задать имя файла и папку для сохранения данных при помощи стандартного диалога,
        // затем сохранить данные в выбранном файле
        private void SaveAs_Command(object sender, EventArgs e) {
            // Если файл для сохраненения не задан, то молча уходим 
            if (SfdMain.ShowDialog() != DialogResult.OK) return;

            // задать имя файла данных и собственно, сохранить данные
            _apartmentController.DataFileName = SfdMain.FileName;
            _apartmentController.SerializeData();

            // разрешим кнопку и пункт меню сохранения
            TsbSave.Enabled = true;
        } // SaveAs_Command


        // сохранить данные в заданном командой SaveAs имени файла
        private void Save_Command(object sender, EventArgs e) => _apartmentController.SerializeData();

        #region Перетаскивавние на ListView, TreeView

        // перетаскивание на ListView
        private void Handler_DragDrop(object sender, DragEventArgs e) {
            if (!e.Data.GetDataPresent(DataFormats.FileDrop)) return;
            
            // Прием файла, data[] - массив имен файлов
            _apartmentController.DataFileName = ((string[])e.Data.GetData(DataFormats.FileDrop))[0];
            _apartmentController.DeserializeData();

            // обновление отобржаемых данных
            FillListView(_apartmentController.GetAll(), LsvAppliances);
            FillListView(_apartmentController.OrderByBrand(), LsvOrdered);
            FillListView(_apartmentController.SelectWhereName(_apartmentController.GetAll()[0].Name), LsvFiltered);
            FillTreeView(_apartmentController.GetAll(), TrvApartment);

            // вывести количество приборов квартире
            TslStatus.Text = $"Количество приборов в квартире: {_apartmentController.Count}";
            TslOn.Text = $"Включено: {_apartmentController.SelectWhereState(true).Count}";
            TslOff.Text = $"Выключено: {_apartmentController.SelectWhereState(false).Count}";
        } // Handler_DragDrop


        // Подтверждение операции необходимо, оно задает операцию при
        // завершении буксировки, один обработчик для ListView, TreeView
        private void Object_DragEnter(object sender, DragEventArgs e) =>
            e.Effect = DragDropEffects.Copy;

        #endregion


        // событие клика в контекстном меню CmnTreeAppliance
        private void TurnOnApplianceCmnTree_Command(object sender, EventArgs e) {
            // если узел не соответствует уровню прибора - уходим
            // 0 -- квартира
            // 1 -- комната
            // 2 -- прибор
            if (TrvApartment.SelectedNode.Level != 2) return;

            (TrvApartment.SelectedNode.Tag as Appliance).State = true;
            TrvApartment.SelectedNode.ImageIndex = TrvApartment.SelectedNode.SelectedImageIndex = 1;

            // перерисовать ListView
            FillListView(_apartmentController.GetAll(), LsvAppliances);

            // обновить статистику по состоянию приборов квартиры
            TslOn.Text = $"Включено: {_apartmentController.SelectWhereState(true).Count}";
            TslOff.Text = $"Выключено: {_apartmentController.SelectWhereState(false).Count}";
        } // TurnOnApplianceCmnTree_Command

        // событие клика в контекстном меню CmnTreeAppliance
        private void TurnOffApplianceCmnTree_Command(object sender, EventArgs e) {
            // если узел не соответствует уровню прибора - уходим
            // 0 -- квартира
            // 1 -- комната
            // 2 -- прибор
            if (TrvApartment.SelectedNode.Level != 2) return;

            // изменения состояния в коллекции и изменение картинки в дереве
            (TrvApartment.SelectedNode.Tag as Appliance).State = false;
            TrvApartment.SelectedNode.ImageIndex = TrvApartment.SelectedNode.SelectedImageIndex = 0;

            // перерисовать ListView
            FillListView(_apartmentController.GetAll(), LsvAppliances);

            // обновить статистику по состоянию приборов квартиры
            TslOn.Text = $"Включено: {_apartmentController.SelectWhereState(true).Count}";
            TslOff.Text = $"Выключено: {_apartmentController.SelectWhereState(false).Count}";
        } // TurnOnApplianceCmnTree_Command

        // коррекция поведения TreeView - при отпускании любой кнопки мыши
        // сделать узел, на котором был клик, текущим 
        private void CorrectBehavor_MouseUp(object sender, MouseEventArgs e) {
            // закомментировано для исключения конфликтов с NodeMouseClick
            // TrvApartment.SelectedNode = TrvApartment.GetNodeAt(e.Location);
        } // CorrectBehavor_MouseUp

        // альтернативная коррекция поведения TreeView - по клику на узле (любой кнопкой мыши)
        // сделать узел, на котором был клик, текущим 
        private void CorrectBehavor_NodeMouseClick(object sender, TreeNodeMouseClickEventArgs e) {
            TrvApartment.SelectedNode = e.Node;
        } // CorrectBehavor_NodeMouseClick
    } // class MainForm
}
