﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.Serialization.Json;
using ElectricalAppliances.Helpers; // для JSON, добавить сборку System.Runtime.Serialization.dll

using ElectricalAppliances.Models;

namespace ElectricalAppliances.Controllers
{
    /*
     * Контроллер для выполнения обработок по командам из представления, из форм:
     *     • При запуске приложения проверять наличие в папке исполняемого
     *       файла папки App_Data и файла appliances.json с данными о квартире.
     *       Если папки и/или файл нет, то создать папку, заполнить начальными
     *       данными объект, описывающий электрооборудование квартиры,
     *       сериализовать данные в формате JSON
     *     • Переформирование коллекции электроприборов и сведений о квартире
     *       с сериализацией 
     *     • Сохранение данных в выбранном файле – сериализация в формате JSON
     *     • Загрузка данных из файла, десериализация в формате JSON. 
     *     • Добавление электроприбора в коллекцию, сериализация данных
     *     • Удаление электроприбора из коллекции, сериализация данных
     *     • Упорядочивание копии коллекции электроприборов
     *         o По названию
     *         o По состоянию
     *         o По мощности
     *         o По убыванию цены
     *     • Включение/выключение выбранного электроприбора
     *     • Включение/выключение всех электроприборов квартиры
     *     • Выборка коллекции электроприборов, с заданным названием
     *     • Выборка коллекции электроприборов заданного состояния
     *
     */
    public class ApartmentController
    {
        // данные по квартире, которой мы управляем 
        private Apartment _apartment;

        // имя файла для хранения данных квартиры
        public string DataFileName { get; set; }


        #region Ансамбль конструкторов

        public ApartmentController() : this(new Apartment()) {
            _apartment.OrderBy((a1, a2) => a1.Room.CompareTo(a2.Room));
        } // ApartmentController

        public ApartmentController(Apartment apartment) {
            _apartment = apartment;
        } // ApartmentController
        #endregion

        // Переформирование коллекции электроприборов и сведений о квартире
        // с сериализацией
        public void Generate() {
            _apartment.Generate(Utils.GetRandom(10, 20));
            _apartment.OrderBy((a1, a2) => a1.Room.CompareTo(a2.Room));
            SerializeData();
        } // Generate


        // -----------------------------------------------------------------------------------
        public List<Appliance> GetAll() => _apartment.Appliances;
        public Apartment Apartment => _apartment;

        public int Count => _apartment.Appliances.Count;

        // -----------------------------------------------------------------------------------

        // сериализация данных в формате JSON
        public void SerializeData() {
            DataContractJsonSerializer jsonFormatter = new DataContractJsonSerializer(typeof(Apartment));

            // Запись объекта в JSON-файл
            using (FileStream fs = new FileStream(DataFileName, FileMode.Create)) {
                jsonFormatter.WriteObject(fs, _apartment);
            } // using
        } // SerializeData

        // десериализация данных из формата JSON
        public void DeserializeData() {
            DataContractJsonSerializer jsonFormatter = new DataContractJsonSerializer(typeof(Apartment));

            // Читаем коллекцию из JSON-файла
            using (FileStream fs = new FileStream(DataFileName, FileMode.OpenOrCreate)) {
                _apartment = (Apartment)jsonFormatter.ReadObject(fs);
            } // using
        } // DeserializeData

        // -----------------------------------------------------------------------------------
        
        // Добавление электроприбора в коллекцию, сериализация данных
        public void AddAppliance(Appliance appliance) {
            _apartment.Add(appliance);
            SerializeData();
        } // AddAppliance

        // Удаление электроприбора из коллекции, сериализация данных
        public void RemoveApplianceAt(int index) {
            _apartment.RemoveAt(index);
            SerializeData();
        } // RemoveApplianceAt

        // -----------------------------------------------------------------------------------


        // Запрос на упорядочивание копии коллекции электроприборов по названию
        public List<Appliance> OrderByBrand() =>
            _apartment.OrderCopyBy((t1, t2) => t1.Name.CompareTo(t2.Name));


        // Запрос на упорядочивание коллекции электроприборов по состоянию
        public List<Appliance> OrderByState() =>
            _apartment.OrderCopyBy((t1, t2) => t1.State.CompareTo(t2.State));


        // Запрос на упорядочивание коллекции электроприборов по мощности
        public List<Appliance> OrderByPower() =>
            _apartment.OrderCopyBy((t1, t2) => t1.Power.CompareTo(t2.Power));


        // Запрос на  упорядочивание коллекции электроприборов по убыванию цены
        public List<Appliance> OrderByPriceDesc() =>
            _apartment.OrderCopyBy((t1, t2) => t2.Price.CompareTo(t1.Price));


        // -----------------------------------------------------------------------------------


        // Включение/выключение выбранного электроприбора
        public void TurnAt(int index, bool state) => _apartment.TurnAt(index, state);
        
        // Включение/выключение всех электроприборов квартиры
        public void TurnAll(bool state) => _apartment.TurnAll(state);


        // -----------------------------------------------------------------------------------


        // Запрос на выборку в коллекцию электроприборов с заданным названием
        public List<Appliance> SelectWhereName(string name) =>
            _apartment.Filter(t => t.Name == name);       
        
        
        // Запрос на выборку в коллекцию электроприборов с заданным состоянием
        public List<Appliance> SelectWhereState(bool state) =>
            _apartment.Filter(t => t.State == state);
    } // class ApartmentController
}
