﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WF_Appliance.Controller;
using WF_Appliance.Models;
using WF_Appliance.Utilities;

namespace WF_Appliance.Forms
{
    public partial class Appliance_form : Form
    {

        //Свойство объекта 
        private Appliance _appliance = new Appliance();

        public Appliance appliance
        {
            get => _appliance;
        }

       
        public Appliance_form()
        {
            InitializeComponent();

            #region Связывание данных
            //Привязываем данные в comboboxes
            List<object> tempList = new List<object>(Utils.GetUniqueNames());
            BindData(tempList, Cbx_Name);
            

            //Добавляем мощности
            tempList.Clear();
            foreach (int item in Utils.Powers)
            {
                tempList.Add(item);
            }
            BindData(tempList, Cbx_Power);

            //Добавляем значение
            NudPrice.Value = Utils.Prices[Utils.Random.Next(0, Utils.Prices.Length)];

            //Задаём состояние 
            _appliance.State = Utils.Random.Next(1, 100) % 3 == 0 ? true : false;
            #endregion

            //Выводим готовый объект в TextBox 
            Tbx_EndedObj.Text = $"Итоговый обект:\r\n{_appliance}";
        }

        //C_TOR с параметрами для редактирования телевизора
        public Appliance_form(Appliance appliance)
        {
            InitializeComponent();

            //Привязываем данные в comboboxes
            List<object> tempList = new List<object>(Utils.GetUniqueNames());
            BindData(tempList, Cbx_Name);


            //Добавляем мощности
            tempList.Clear();
            foreach (int item in Utils.Powers)
            {
                tempList.Add(item);
            }
            BindData(tempList, Cbx_Power);


            
            this.Text = "Редактирование обекта";

            _appliance.Name = appliance.Name;
            _appliance.Power = appliance.Power;
            _appliance.Price = appliance.Price;
            _appliance.State = appliance.State;

            //Задаём значения в CBX
            Cbx_Name.SelectedIndex = Cbx_Name.Items.IndexOf(_appliance.Name);

            Cbx_Power.Items.IndexOf(_appliance.Power);

            Cbx_Power.SelectedIndex = Cbx_Power.Items.IndexOf(_appliance.Power);


            BtnAdd.Text = "Сохранить";
            //Изменяем состояние обекта
            if (_appliance.State)
                RbtnOn.Checked = true;
            else
                RbtnOff.Checked = true;

            //Задаём существующее значение в NudPrice
            NudPrice.Value = (decimal)_appliance.Price;

            //Выводим готовый объект в TextBox 
            Tbx_EndedObj.Text = $"Итоговый обект:\r\n{_appliance}";
        }

        //Привязка данных к конкретному комбобоксу
        void BindData(List<object> list,ComboBox cbx)
        {
            cbx.DataSource = null;
            cbx.DataSource = list;

        }

        //При повторном вводе меняем цвет
        private void Tbx_Changed(object sender, EventArgs e)
        {
            TextBox textBox = sender as TextBox;
            textBox.BackColor = Color.White;
        }

        private void Cbx_IndexChanged(object sender, EventArgs e)
        {
            ComboBox TempCbx = (ComboBox)sender;

            //Выбор получающего поля
            if (TempCbx.Equals(Cbx_Name))
                _appliance.Name = TempCbx.SelectedItem.ToString();
            else if (TempCbx.Equals(Cbx_Power))
                _appliance.Power = int.Parse(TempCbx.SelectedItem.ToString());


            //Выводим готовый объект в TextBox 
            Tbx_EndedObj.Text = $"Итоговый обект:\r\n{_appliance}";

        }

        private void Nud_ValueChanged(object sender, EventArgs e)
        {
            _appliance.Price = (int)NudPrice.Value;

            //Выводим готовый объект в TextBox 
            Tbx_EndedObj.Text = $"Итоговый обект:\r\n{_appliance}";
        }

        // Запрет на ввод знака '-'
        private void Restrict_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.OemMinus || e.KeyData == Keys.Subtract)
                //SendKeys.Flush();
                e.SuppressKeyPress = true;
        }

        private void TurnOn_Command(object sender, EventArgs e)
        {
            _appliance.State = true;

            //Выводим готовый объект в TextBox 
            Tbx_EndedObj.Text = $"Итоговый обект:\r\n{_appliance}";
        }

        private void TurnOff_Command(object sender, EventArgs e)
        {

            _appliance.State = false;

            //Выводим готовый объект в TextBox 
            Tbx_EndedObj.Text = $"Итоговый обект:\r\n{_appliance}";
        }
    }
}
