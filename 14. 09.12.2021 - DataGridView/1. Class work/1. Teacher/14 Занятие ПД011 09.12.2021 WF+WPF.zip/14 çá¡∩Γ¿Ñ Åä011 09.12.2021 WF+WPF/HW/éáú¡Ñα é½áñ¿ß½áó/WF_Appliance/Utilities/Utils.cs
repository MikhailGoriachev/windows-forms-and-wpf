﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;

namespace WF_Appliance.Utilities
{
    // вспомогательные методы и объекты - статический класс, т.е. класс,
    // содержащий только статические члены и методы
    public static class Utils
    {
        
        // объект для получения случайных чисел
        public static Random Random = new Random();
        
        // формирование случайных вещественных чисел в диапазоне от lo до hi
        public static double GetRandom(double lo, double hi)
            => lo + (hi - lo)*Random.NextDouble();


        //Массив названий приборов 
        public static (string Name, string Room)[] NamesRooms = {
        ("Чайник", "Кухня"),
        ("Блендер", "Кухня"),
        ("Утюг","Гардеробная"),
        ("Миксер","Кухня"),
        ("Хлебопечка","Кухня"),
        ("Стиральная машина","Ванная"),
        ("Микроволновка","Кухня"),
        ("Светильник напольный","Спальня"),
        ("Светильник напольный","Гостинная"),
        ("Кондиционер","Спальня"),
        ("Кондиционер","Гостинная"),
        ("Посудомоечная машина","Кухня"),
        ("Телевизор","Кухня"),
        ("Телевизор","Гостинная"),
        ("Пылесос","Кладовка")
        }; 

        //Коллекция названий отдельно 
        public static string[] GetUniqueNames()
        {
            Dictionary<string, int> names = new Dictionary<string, int>();

            //Проходим по массиву строк 
            for (int i = 0; i < NamesRooms.Length; i++)
                names[NamesRooms[i].Name] = 0;

            List<string> tempList = new List<string>(names.Keys);
            return tempList.ToArray(); ;
        }
        
        //Коллекция комнат отдельно 
        public static string[] GetUniqueRooms()
        {
            Dictionary<string, int> rooms = new Dictionary<string, int>();

            //Проходим по массиву строк 
            for (int i = 0; i < NamesRooms.Length; i++)
                rooms[NamesRooms[i].Room] = 0;

            List<string> tempList = new List<string>(rooms.Keys);
            return tempList.ToArray(); ;
        }

        //Массив мощностей В приборов ВТ 
        public static int[] Powers =
        {
            6000,
            1000,
            2000,
            3500,
            1950,
            3300,
            1200,
            720,
            1500,
            850,
            1300,
            1400,
            2100,
            200,
            250,
            1150,
            1250
        };

        //Массив цена на приборы RUB
        public static int[] Prices =
        {
            7100, 
            8200,
            7250, 
            9100,
            9500,
            7950,
            11400,
            14700,
            18500,
            19350,
            12200,
            13100,
            14300,
            10700,
            12350
        };


    } // class Utils
}