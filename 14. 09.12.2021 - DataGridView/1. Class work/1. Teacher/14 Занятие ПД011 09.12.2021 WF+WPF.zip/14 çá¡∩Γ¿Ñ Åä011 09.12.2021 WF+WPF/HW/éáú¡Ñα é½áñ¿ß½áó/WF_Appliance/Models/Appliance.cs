﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WF_Appliance.Utilities;
using System.Runtime.Serialization;
using System.Windows.Forms;

namespace WF_Appliance.Models
{
    [DataContract]
    public class Appliance
    {
        [DataMember]
        // название электроприбора
        private string _name;
        public string Name
        {
            get => _name;
            set
            {
                if (string.IsNullOrEmpty(value))
                    throw new Exception("Строка названия не может быть пустой");

                _name = value;
            } // set
        } // Name

        [DataMember]
        // мощность электроприбора
        private int _power;
        public int Power
        {
            get => _power;
            set
            {
                if (value <= 0)
                    throw new Exception($"Мощность прибора некорректна: {value}");

                _power = value;
            } // set
        } // Power

        [DataMember]
        // цена электроприбора
        private int _price;
        public int Price
        {
            get => _price;
            set
            {
                if (value <= 0)
                    throw new Exception($"Цена прибора некорректна: {value}");

                _price = value;
            } // set
        } // Price

        [DataMember]
        // состояние электроприбора: включен/выключен
        private bool _state;
        public bool State
        {
            get => _state;
            set => _state = value;
        } // State

        [DataMember]
        //Комната нахождения прибора 
        private string _room;
        public string Room
        {
            get => _room;

            set{
                if (string.IsNullOrWhiteSpace(value))
                    throw new Exception("Комната нахождения прибора пута!");
                _room = value;

            }
        }


        //Внедрение зависимости Utils.Random.Next(0,Utils.)
        public Appliance(): this(Utils.NamesRooms[0].Name,Utils.NamesRooms[0].Room,Utils.Powers[1],Utils.Prices[0],false)
        {}
         
        //Свойства: 
        public Appliance(string name,string room,int power,int price, bool state)
        {
            Name = name;
            Room = room;
            Price = price;
            Power = power;
            //По умолчанию прибор выключен
            _state = state;
        }

        //Генерация прибора
        static public Appliance Generate()
        {
            int indNameRoom = Utils.Random.Next(0, Utils.NamesRooms.Length),
                indPower = Utils.Random.Next(0, Utils.Powers.Length),
                indPrice = Utils.Random.Next(0, Utils.Prices.Length);

            //Определяем случайное состояние прибора от остатка деления на 3
            bool State = Utils.Random.Next(1, 100) % 3 == 0 ? true : false;

            return 
                new Appliance
                (Utils.NamesRooms[indNameRoom].Name,Utils.NamesRooms[indNameRoom].Room, Utils.Powers[indPower], Utils.Prices[indPrice],State);

        } //Generate

        //Запись прибора в обект ListViewItem
        public ListViewItem ToListView()
        {
            // создание элемента (строки)
            ListViewItem listViewItem = new ListViewItem();

            // установка значения первого столбца
            listViewItem.ImageIndex = State ? 1 : 0;

            //Установка под-элементов 
            listViewItem.SubItems.Add(Name);
            listViewItem.SubItems.Add(Power.ToString());
            listViewItem.SubItems.Add(Price.ToString());
            listViewItem.SubItems.Add(Room);


            // добавление остальных элементов
            //listViewItem.SubItems.AddRange(new[] { $"{Name}", $"{Power}", $"{Price}" });

            return listViewItem;
        }

        //Вывод в строку таблицы
        override public string ToString() =>
           $"Название: {_name} \r\nМощность: {_power} Вт \r\nСтоимость: {_price} руб. \r\nСостояние: {(_state ? "Включен" : "Выключен")} \r\nРасположение: {Room}";


        // Вывод в строку таблицы
        public string ToTableRow =>
            $" {_name,-22} │ {_power,12:n2} │ {_price,10:n2} │ " +
            $"{(_state ? "Включен" : "Выключен"),-10}";

        // Шапка таблицы, статическое свойство
        public static string Header =>
            $"┌────────────────────────┬──────────────┬────────────┬────────────┐\r\n" +
            $"│ Название прибора       │ Мощность, Вт │ Цена, руб. │ Состояние  │\r\n" +
            $"├────────────────────────┼──────────────┼────────────┼────────────┤\r\n";


    }
}
