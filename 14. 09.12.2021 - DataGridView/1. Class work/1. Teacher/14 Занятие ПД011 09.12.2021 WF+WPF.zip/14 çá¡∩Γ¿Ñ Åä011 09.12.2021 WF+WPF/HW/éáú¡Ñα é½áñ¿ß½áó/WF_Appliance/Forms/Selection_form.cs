﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WF_Appliance.Models;

namespace WF_Appliance.Forms
{
    public partial class Selection_form : Form
    {
        //Мастреская 
        private Flat _repairShop = new Flat();

        public Selection_form():this("Выборка по умолчанию",new Appliance[10])
        {
            InitializeComponent();
            //Коллекция по умолчанию 
         /*   _repairShop.Televisions.Clear();
            _repairShop.Generate(defaultCount);

            TbxOutPut.Text = _repairShop.ShowCollection();*/
        }

        public Selection_form(string title,Appliance[] tvs)
        {

            InitializeComponent();

            //Добавление выборки в мастерскую
            _repairShop.Appliances.Clear();
            _repairShop.Appliances.AddRange(tvs);

            //Устанавливаем label 
            LblTitle.Text = title;

            //Меняем значение в статусной строке
            SStatusLbl_total.Text = $"Выбрано телевизоров: {_repairShop.Appliances.Count} ";

            //Связываем 
            BindTelevision();
        }

        //Связывание полученной коллекции с ListBox
        void BindTelevision()
        {
            //Обнуляем связь
            LbxOutPut.DataSource = null;

            //Возобновляем связь
            LbxOutPut.DataSource = _repairShop.Appliances;

            LbxOutPut.DisplayMember = "ToTableRow";
        }
       
    }
}
