﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WF_Appliance.Models;
using System.Runtime.Serialization;
using System.IO;
using System.Runtime.Serialization.Json;

namespace WF_Appliance.Controller
{

    /*
    •При запуске приложения проверять наличие в папке исполняемого файла папки App_Data и файла appliances.json с данными о квартире. 
       Если папки и/или файл нет, то создать папку, заполнить начальными данными объект, описывающий электрооборудование квартиры, сериализовать данные в формате JSON
    
    •Выводить коллекцию электроприборов в Lisappiew в табличном формате, 
       состояние прибора отображать картинкой   
    •Переформирование коллекции электроприборов и сведений о квартире с сериализацией 
    •Сохранение данных в выбранном файле – сериализация в формате JSON. Файл для сохранения выбирать стандартным диалогом 
    •Загрузка данных из выбранного стандартным диалогом файла, десериализация в формате JSON. 

    •	Упорядочивание коллекции электроприборов, вывод упорядоченной копии коллекции в отдельной вкладке. При выборе команды переходить на вкладку
o	По названию
o	По состоянию
o	По мощности
o	По убыванию цены
•	Включение/выключение выбранного электроприбора
•	Включение/выключение всех электроприборов квартиры
•	Выборка и вывод в отдельной вкладке главной формы коллекции электроприборов, с заданным названием. При выборе команды переходить на вкладку
•	Выборка и вывод в отдельной вкладке главной формы коллекции электроприборов заданного состояния. При выборе команды переходить на вкладку


    */

    public class FlatController
    {
        //Мастерская
        private Flat _flat;

        //Имя файла для записи 
        public string FName;

        //Перечесление компонентов television 
        public enum SubCollection
        {
            //Мощность
            Power,
            //Цена 
            Price
        }

        public Flat Flat
        {
            get => _flat;
            set => _flat = value;
        } // Flat

        //Количество включенных приборов 
        public int TurnedOnCount
        {
            get;
            private set;
        }

        //Свойство проверки коллекции на пустоту 23.11
        public bool IsEmpty
        {
            get
                => _flat.Appliances.Count <= 0;
        }

        //Получения кол-ва элементов в коллекции 
        public int Count
            => _flat.Count;

        //Получение коллекции приборов 
        public List<Appliance> GetAppliances
            => _flat.Appliances;

        private List<Appliance> CopyList;

        //C_TOR с внедрением зависимости 
        public FlatController():this(new Flat(),"\\App_Data\\appliances.json", 2)
        { }

        public FlatController(Flat flat,string FileName = "\\App_Data\\appliances.json", int dirsCount = 2)
        {
            _flat = flat;
            //Создаём копию списка
            CopyList = new List<Appliance>(_flat.Appliances);
            string currDir = Directory.GetCurrentDirectory();

            int subDirsCount = CountDirs(currDir);
            
            //Проверка корректности кол-ва каталогов
            dirsCount = dirsCount > subDirsCount ? subDirsCount : dirsCount;

            for (int i = 0; i < dirsCount; i++)
            {
                int length = currDir.LastIndexOf(@"\");
                currDir = currDir.Substring(0,length);
            }

            FName = currDir + FileName;

            //Создание/провекра на существование файла и каталога app_data
            CreateDirAndFile();
            
        }//FlatController

        //Подсчёт кол-ва ключенных приборов 
        public int CountTurnedOn()
        {
            int count = 0;

            foreach (var item in _flat.Appliances)
            {
                if (item.State)
                    count++;
            }

            return count;
        }

        //Получение уникализированных комнат
        public string[] GetRooms()
        {
            Dictionary<string, int> Rooms = new Dictionary<string, int>();
            //Добавляем комнаты в словарь 
            foreach (Appliance item in GetAppliances)
                Rooms[item.Room] = 0;

            List<string> tempList = new List<string>(Rooms.Keys);

            return tempList.ToArray();

        }

        //Подсчёт кол-ва каталогов местонахождения программы
        int CountDirs(string currDirectory)
        {
            //Если в пути текущего каталога нет разделителей - уходим
            if (currDirectory.IndexOf('\\') < 0)
                return -1;

            //При помощи цыкла считаем кол-во каталогов
            int count = 0;
            foreach (char item in currDirectory)
            {
                if (item == '\\')
                    count++;
                    
            }

            return count;
        }

        //Изменение состояния приборов по массиву индексов 
        public void TurnAppByInds(int[]indecies, bool state)
        {
            if (indecies.Length <= 0)
                return;

            for (int i = 0; i < indecies.Length; i++)
                Flat.TurnOnOff(indecies[i],state);
        }

        //ИЗменение состояния всех приборов 
        public void TurnAllApp(bool state)
        {
            Flat.TurnAll(state);
        }

        //Изменение состояния конкретного прибора
        public void TurnApp(int index, bool state)
        {
            Flat.TurnOnOff(index,state);
        }

        //Изменение состояния конкретного прибора
        public void TurnApp(Appliance item, bool state)
        {
            Flat.TurnOnOff(item,state);
        }


        #region Сортировки 

        //Сортировка по названию копию коллекции

        
        public List<Appliance> SortByName()
        {
            //Если коллекция не пуста - копируем список, в противном случае будем работать с последней копией 
            if (!IsEmpty)
            {
                CopyList.Clear();
                CopyList.AddRange(GetAppliances);
            }
            
            CopyList.Sort((app1, app2) => app1.Name.CompareTo(app2.Name));
            return CopyList;
        }

        //Сортирвока по состоянию

        public List<Appliance> SortByState()
        {
            //Если коллекция не пуста - копируем список, в противном случае будем работать с последней копией 
            if (!IsEmpty)
            {
                CopyList.Clear();
                CopyList.AddRange(GetAppliances);
            }
            CopyList.Sort((app1, app2) => app2.State.CompareTo(app1.State));
            return CopyList;
        }

        //Сортировка по мощности
        
        public List<Appliance> SortByPower()
        {
            //Если коллекция не пуста - копируем список, в противном случае будем работать с последней копией 
            if (!IsEmpty)
            {
                CopyList.Clear();
                CopyList.AddRange(GetAppliances);
            }
            CopyList.Sort((app1, app2) => app1.Power.CompareTo(app2.Power));
            return CopyList;
        }

        //Сортировка по убыванию цены
        public List<Appliance> SortDescByPrice()
        {
            //Если коллекция не пуста - копируем список, в противном случае будем работать с последней копией 
            if (!IsEmpty)
            {
                CopyList.Clear();
                CopyList.AddRange(GetAppliances);
            }
            CopyList.Sort((app1, app2) => app2.Price.CompareTo(app1.Price));
            return CopyList;
        }
        #endregion

        #region Выборки 
        //Выборка приборов, с заданным названием
        public List<Appliance> SelectByName(string name)
        {
            return _flat.SelectBy((app) => app.Name == name);
        }
        //Выборка приборов заданного состояния.
        public List<Appliance> SelectByState(bool state)
        {
            return _flat.SelectBy((app) => app.State == state );
        }
        #endregion

        #region Коллекции составных частей обекта
        //Получения коллекции названий
        public List<string> GetNamesCollection()
        {
            Dictionary<string, int> set = new Dictionary<string, int>();

            //Заносим в словарь значения, которые после будут уникализированы
            foreach (Appliance item in _flat.Appliances)
            { set[item.Name] = 0; }

            //Обращаем словарь в список ключей из 
            List<string> temp = new List<string>(set.Keys);
            return temp;
        }//GetNamesCollection

        
        //Метод получения коллекции с типом int
        public List<int> GetIntsCollection(SubCollection code)
        {
            Dictionary<int, int> set = new Dictionary<int, int>();

            //Выбор цыкла для конкретного поля на Appliances
            switch (code)
            {
                //Создаём коллекцию мощностей
                case SubCollection.Power:
                    foreach (Appliance item in _flat.Appliances)
                    { set[item.Power] = 0; }
                    break;

                //Создаём коллекцию цен
                case SubCollection.Price:
                    foreach (Appliance item in _flat.Appliances)
                    { set[item.Price] = 0; }
                    break;

                //По умолчанию будет отрабатывать цыкл получения цен
                default:
                    foreach (Appliance item in _flat.Appliances)
                    { set[item.Price] = 0; }
                    break;
            }

            //Обращаем словарь в список
            List<int> temp = new List<int>(set.Keys);
            return temp;
        }//GetIntsCollection
        #endregion

        #region Сериализация 
        //Проверка файла и каталога на существование 
        public void CreateDirAndFile()
        {
            //Проверяем файл на существование 
            if (File.Exists(FName))
                return;

            //из общего пути сохранение получаем название каталога 
            string dir = Path.GetDirectoryName(FName);
            //string dir = Directory.GetDirectories(FName)[0];

            //Получаем путь к каталогу 
            int length = FName.LastIndexOf(@"\");
            string DirPath = FName.Substring(0, length);

            //Если каталог по выделенному пути не существует - создаём его
            if (!Directory.Exists(dir))
                Directory.CreateDirectory(DirPath);

            //Создаём файл и сразу же освобождаем ресурсы посредством использования блока using
            using (File.Create(FName)) { };

            //Записываем коллекцию в файл 
            Serialize();
        }

        public void Serialize()
        {
            if (!File.Exists(FName))
                return;

            //Создаём форматтер 
            DataContractJsonSerializer jsonFormatter = new DataContractJsonSerializer(typeof(Flat));

            using (FileStream fs = new FileStream(FName, FileMode.Create))
            {
                jsonFormatter.WriteObject(fs,_flat);
            }
            

        }

        public void Deserialize()
        {

            if (!File.Exists(FName))
                return;

            DataContractJsonSerializer jsonFormatter = new DataContractJsonSerializer(typeof(Flat));
            using (FileStream fs = new FileStream(FName,FileMode.OpenOrCreate))
            {
                /*_flat =  JsonSerializer.DeserializeAsync<RepairShop>(fs);*/
                _flat = (Flat)jsonFormatter.ReadObject(fs);

            }
        }
        #endregion

    }
}
