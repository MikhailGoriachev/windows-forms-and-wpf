﻿namespace WF_Appliance.Forms
{
    partial class Del_Certain_Appliance_Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.BtnDelete = new System.Windows.Forms.Button();
            this.CbxField = new System.Windows.Forms.ComboBox();
            this.LblField = new System.Windows.Forms.Label();
            this.BtnClose = new System.Windows.Forms.Button();
            this.GbxByWhat = new System.Windows.Forms.GroupBox();
            this.RbtnPrice = new System.Windows.Forms.RadioButton();
            this.RbtnPower = new System.Windows.Forms.RadioButton();
            this.RbtnName = new System.Windows.Forms.RadioButton();
            this.GbxByWhat.SuspendLayout();
            this.SuspendLayout();
            // 
            // BtnDelete
            // 
            this.BtnDelete.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.BtnDelete.Enabled = false;
            this.BtnDelete.Font = new System.Drawing.Font("Consolas", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BtnDelete.Location = new System.Drawing.Point(32, 202);
            this.BtnDelete.Name = "BtnDelete";
            this.BtnDelete.Size = new System.Drawing.Size(159, 53);
            this.BtnDelete.TabIndex = 0;
            this.BtnDelete.Text = "Удалить";
            this.BtnDelete.UseVisualStyleBackColor = true;
            this.BtnDelete.Click += new System.EventHandler(this.BtnDelete_Click);
            // 
            // CbxField
            // 
            this.CbxField.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CbxField.Enabled = false;
            this.CbxField.FormattingEnabled = true;
            this.CbxField.Location = new System.Drawing.Point(141, 124);
            this.CbxField.Name = "CbxField";
            this.CbxField.Size = new System.Drawing.Size(218, 23);
            this.CbxField.TabIndex = 1;
            this.CbxField.SelectedIndexChanged += new System.EventHandler(this.CbxField_SelectedIndexChanged);
            // 
            // LblField
            // 
            this.LblField.AutoSize = true;
            this.LblField.Enabled = false;
            this.LblField.Font = new System.Drawing.Font("Consolas", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblField.Location = new System.Drawing.Point(146, 103);
            this.LblField.Name = "LblField";
            this.LblField.Size = new System.Drawing.Size(104, 18);
            this.LblField.TabIndex = 2;
            this.LblField.Text = "Поле выборки";
            // 
            // BtnClose
            // 
            this.BtnClose.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.BtnClose.Font = new System.Drawing.Font("Consolas", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BtnClose.Location = new System.Drawing.Point(312, 202);
            this.BtnClose.Name = "BtnClose";
            this.BtnClose.Size = new System.Drawing.Size(169, 53);
            this.BtnClose.TabIndex = 3;
            this.BtnClose.Text = "Закрыть";
            this.BtnClose.UseVisualStyleBackColor = true;
            // 
            // GbxByWhat
            // 
            this.GbxByWhat.Controls.Add(this.RbtnPrice);
            this.GbxByWhat.Controls.Add(this.RbtnPower);
            this.GbxByWhat.Controls.Add(this.RbtnName);
            this.GbxByWhat.Location = new System.Drawing.Point(36, 22);
            this.GbxByWhat.Name = "GbxByWhat";
            this.GbxByWhat.Size = new System.Drawing.Size(430, 78);
            this.GbxByWhat.TabIndex = 12;
            this.GbxByWhat.TabStop = false;
            this.GbxByWhat.Text = "Критерии удаления";
            // 
            // RbtnPrice
            // 
            this.RbtnPrice.AutoSize = true;
            this.RbtnPrice.Location = new System.Drawing.Point(305, 34);
            this.RbtnPrice.Name = "RbtnPrice";
            this.RbtnPrice.Size = new System.Drawing.Size(88, 19);
            this.RbtnPrice.TabIndex = 17;
            this.RbtnPrice.TabStop = true;
            this.RbtnPrice.Text = "Стоимость";
            this.RbtnPrice.UseVisualStyleBackColor = true;
            this.RbtnPrice.CheckedChanged += new System.EventHandler(this.RbtnPrice_CheckedChanged);
            // 
            // RbtnPower
            // 
            this.RbtnPower.AutoSize = true;
            this.RbtnPower.BackColor = System.Drawing.SystemColors.Control;
            this.RbtnPower.Location = new System.Drawing.Point(166, 34);
            this.RbtnPower.Name = "RbtnPower";
            this.RbtnPower.Size = new System.Drawing.Size(81, 19);
            this.RbtnPower.TabIndex = 15;
            this.RbtnPower.TabStop = true;
            this.RbtnPower.Text = "Мощность";
            this.RbtnPower.UseVisualStyleBackColor = false;
            this.RbtnPower.CheckedChanged += new System.EventHandler(this.RbtnPower_CheckedChanged);
            // 
            // RbtnName
            // 
            this.RbtnName.AutoSize = true;
            this.RbtnName.BackColor = System.Drawing.SystemColors.Control;
            this.RbtnName.Location = new System.Drawing.Point(18, 33);
            this.RbtnName.Name = "RbtnName";
            this.RbtnName.Size = new System.Drawing.Size(81, 19);
            this.RbtnName.TabIndex = 13;
            this.RbtnName.TabStop = true;
            this.RbtnName.Text = "Название";
            this.RbtnName.UseVisualStyleBackColor = false;
            this.RbtnName.CheckedChanged += new System.EventHandler(this.RbtnName_CheckedChanged);
            // 
            // Del_Certain_Appliance_Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(515, 273);
            this.Controls.Add(this.GbxByWhat);
            this.Controls.Add(this.BtnClose);
            this.Controls.Add(this.LblField);
            this.Controls.Add(this.CbxField);
            this.Controls.Add(this.BtnDelete);
            this.Font = new System.Drawing.Font("Consolas", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Del_Certain_Appliance_Form";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Удаление нескольких приборов";
            this.GbxByWhat.ResumeLayout(false);
            this.GbxByWhat.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button BtnDelete;
        private System.Windows.Forms.ComboBox CbxField;
        private System.Windows.Forms.Label LblField;
        private System.Windows.Forms.Button BtnClose;
        private System.Windows.Forms.GroupBox GbxByWhat;
        private System.Windows.Forms.RadioButton RbtnPrice;
        private System.Windows.Forms.RadioButton RbtnPower;
        private System.Windows.Forms.RadioButton RbtnName;
    }
}