﻿namespace WF_Appliance.Forms
{
    partial class Selection_form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.LblTitle = new System.Windows.Forms.Label();
            this.BtnComeBack = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.LbxOutPut = new System.Windows.Forms.ListBox();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.SStatusLbl_total = new System.Windows.Forms.ToolStripStatusLabel();
            this.statusStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // LblTitle
            // 
            this.LblTitle.AutoSize = true;
            this.LblTitle.Font = new System.Drawing.Font("Consolas", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblTitle.Location = new System.Drawing.Point(14, 27);
            this.LblTitle.Name = "LblTitle";
            this.LblTitle.Size = new System.Drawing.Size(232, 18);
            this.LblTitle.TabIndex = 0;
            this.LblTitle.Text = "                            ";
            // 
            // BtnComeBack
            // 
            this.BtnComeBack.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.BtnComeBack.Font = new System.Drawing.Font("Consolas", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BtnComeBack.Location = new System.Drawing.Point(225, 477);
            this.BtnComeBack.Name = "BtnComeBack";
            this.BtnComeBack.Size = new System.Drawing.Size(310, 47);
            this.BtnComeBack.TabIndex = 1;
            this.BtnComeBack.Text = "Вернуться в главную форму";
            this.BtnComeBack.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Consolas", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(14, 61);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(733, 36);
            this.label2.TabIndex = 3;
            this.label2.Text = "Производитель    Тип    Диагональ         Дефект            Владелец            М" +
    "астер           Цена   ";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // LbxOutPut
            // 
            this.LbxOutPut.Font = new System.Drawing.Font("Consolas", 12F);
            this.LbxOutPut.FormattingEnabled = true;
            this.LbxOutPut.ItemHeight = 19;
            this.LbxOutPut.Location = new System.Drawing.Point(17, 100);
            this.LbxOutPut.Name = "LbxOutPut";
            this.LbxOutPut.SelectionMode = System.Windows.Forms.SelectionMode.None;
            this.LbxOutPut.Size = new System.Drawing.Size(738, 346);
            this.LbxOutPut.TabIndex = 4;
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.SStatusLbl_total});
            this.statusStrip1.Location = new System.Drawing.Point(0, 530);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(767, 22);
            this.statusStrip1.TabIndex = 5;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // SStatusLbl_total
            // 
            this.SStatusLbl_total.Name = "SStatusLbl_total";
            this.SStatusLbl_total.Size = new System.Drawing.Size(0, 17);
            // 
            // Selection_form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(767, 552);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.LbxOutPut);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.BtnComeBack);
            this.Controls.Add(this.LblTitle);
            this.Font = new System.Drawing.Font("Consolas", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.MaximizeBox = false;
            this.Name = "Selection_form";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label LblTitle;
        private System.Windows.Forms.Button BtnComeBack;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ListBox LbxOutPut;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel SStatusLbl_total;
    }
}