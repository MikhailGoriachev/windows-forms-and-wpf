﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WF_Appliance.Models;
using WF_Appliance.Utilities;


namespace WF_Appliance.Forms
{
    //Редактирование квартиры
    public partial class EditFlat_Form : Form
    {
       
        
        //Адрес мастерской 
        private string _Adress;
        public string Adress_
        {
            get => _Adress;
        }
        //Статус изменения 
        private bool Changed = false;

        public EditFlat_Form():this("Будённовский просп.,19")
        {}

        //C_TOR с параметрами 
        public EditFlat_Form(string adress)
        {
            InitializeComponent();
            _Adress = adress;


            Tbx_Adress.Clear();
            Tbx_Adress.Text = _Adress;
        }

        //Проверка введенных данных
        private void Tbx_Validating(object sender, CancelEventArgs e)
        {
            //Определяем текстовое поле 
            TextBox tbxTemp = sender as TextBox;


            //Если строка осталась пустой, тогда просто отключаем возможность сохранения и оставляем только выход из формы
            if (string.IsNullOrWhiteSpace(tbxTemp.Text))
            {
                BtnAccept.Enabled = false;
            }   
            else
            {
                Changed = true;

                _Adress = tbxTemp.Text;

                BtnAccept.Enabled = true;
            }
        }

        private void Cancel_Command(object sender, EventArgs e)
        {
            if (Changed)
            {
                DialogResult dialogResult = MessageBox.Show("Квартира была изменена.Сохранить?","Предупреждение" ,MessageBoxButtons.YesNo, MessageBoxIcon.Information);

                //Если пользователь сохраняет данные - симулируем клик по кнопке "сохранить"
                if (dialogResult == DialogResult.Yes)
                    BtnAccept.PerformClick();

            }
        }


        //Загрузка формы
        private void EditFlat_Form_Load(object sender, EventArgs e)
        {
            Tbx_Adress.Clear();
            Tbx_Adress.Text = _Adress;
        }
    }
}
