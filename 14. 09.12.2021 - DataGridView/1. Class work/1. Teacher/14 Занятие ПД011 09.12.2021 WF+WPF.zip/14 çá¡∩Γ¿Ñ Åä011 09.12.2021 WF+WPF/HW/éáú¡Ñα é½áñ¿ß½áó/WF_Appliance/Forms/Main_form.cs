﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WF_Appliance.Models;
using WF_Appliance.Forms;
using WF_Appliance.Utilities;
using WF_Appliance.Controller;

namespace WF_Appliance
{
    public partial class Main_form : Form
    {
        //Телемастерская
        //private Flat _flat;

        //Котроллер 
        private FlatController _flatController;

        public Main_form() : this(new FlatController())
        { }

        //C_TOR с параметрами
        public Main_form(FlatController FlatController)
        {
            //Создание всех элементов формы
            InitializeComponent();

            _flatController = FlatController;

            //Связывание данных 
            FillListView(_flatController.GetAppliances, Lsv_Main);

            //Добавление данных в дерево
            FillTreeView();

            //Сохранение 
            _flatController.Serialize();

        }

        //Связываение данных
        private void FillListView(List<Appliance> appliances, ListView listView)
        {
            //Очищаем ListView
            listView.Items.Clear();

            //Заносим список в listView
            appliances.ForEach(item => listView.Items.Add(item.ToListView()));
        }

        //Заполнение дерева 
        private void FillTreeView()
        {
            Trv_Main.Nodes.Clear();
            if (_flatController.IsEmpty)
            {
                return;
            }

            //Добавление главного узла - квартира 
            Trv_Main.Nodes.Add($"Квартира: {_flatController.Flat.Adress}");
  

            //Заполнение комнатами
            Dictionary<string, List<Appliance>> RoomApps = new Dictionary<string, List<Appliance>>();

            int i = 0, appNum = 1;

            List<Appliance> temList = new List<Appliance>();

            foreach (string Room in _flatController.GetRooms())
            {
                temList.Clear();
                //Заносим данные в словарь
                RoomApps.Add(Room, _flatController.GetAppliances.FindAll(item => item.Room == Room));


                Trv_Main.Nodes[0].Nodes.Add(Room);

                temList = RoomApps[Room];
                appNum = 1;
                foreach (Appliance item in temList)
                {
                    Trv_Main.Nodes[0].Nodes[i].Nodes.Add($"{appNum++}. {item.Name}; {item.Power}Вт");
                }

                i++;
               // Trv_Main.Nodes[0].Nodes[]
            }

            Trv_Main.ExpandAll();
        }

        //Перезапись конкретного прибора для сохранения выделения 
        void ChangeOne(Appliance appliance, ListView listView, int index)
        {
            //Получаем выбранную строку таблицы
            ListViewItem Row = listView.Items[index];

            //listView.Items.Insert(index, appliance.ToListView());

            //Row.SubItems.Clear();

            //Перезаписываем изменённый прибор в ListView 
            Row.ImageIndex = appliance.State ? 1 : 0;
        }
        
        //Перезапись конкретного прибора для сохранения выделения 
        void ChangeOne(List<Appliance> applianceData, ListView listView, int index)
        {
            //Получаем выбранную строку таблицы
            ListViewItem Row = listView.Items[index];

            Appliance appliance = applianceData[index];

            //Перезаписываем изменённый прибор в ListView 
            Row = appliance.ToListView();

        }

        //Выбор элемента в списке
        private void LbxFlat_SelectedIndexChanged(object sender, EventArgs e)
        {
            int ind = Lsv_Main.SelectedIndices.Count == 0?-1: Lsv_Main.SelectedIndices[0];
            if (ind < 0 || ind >= _flatController.Flat.Count)
            {
                TbxAppliance.Clear();
                return;
            }

            //Проверяем состояние прибора и отключаем ненужные кнопки
            if (_flatController.Flat[ind].State)
            {
                BtnTurnOnOneStrip.Enabled = false;
                BtnTurnOFFOneStrip.Enabled = true;
            }
            else
            {
                BtnTurnOFFOneStrip.Enabled = false;
                BtnTurnOnOneStrip.Enabled = true;
            }


            //Выводим информацию в правый text box
            TbxAppliance.Text = $"{DateTime.Now:HH:mm:ss}\r\n{_flatController.Flat[ind]}";


        }

        //Загрузка всей формы
        private void Main_form_Load(object sender, EventArgs e)
        {
            //Вывод количества созданных объектов в строку состояния
            
            //Проверка на пустоту 
            IsColletionEmpty();

            int turnedOn = _flatController.CountTurnedOn(), amount = _flatController.Count;
            //Изменение статусной строки 
            TSl_Footer.Text = $"Приборов в квартире: {amount} | Включено: {turnedOn} | Выключено: {amount-turnedOn}";

            //Выводим кол-ва приборов в каждой комнате 
            CountInRooms();
        }

        // завершение работы приложения
        private void Exit_Command(object sender, EventArgs e) =>
            Application.Exit();

        //Изменение статусной строки 
        private void ChangeStatusString()
        {
            int turnedOn = _flatController.CountTurnedOn(), amount = _flatController.Count;
            TSl_Footer.Text = $"Приборов в квартире: {amount} | Включено: {turnedOn} | Выключено: {amount - turnedOn}";
        }

        //Вывод кол-ва приборов в комнате через TextBox
        private void CountInRooms()
        {
            //Создаём словарь для комнат
            Dictionary<string, int> Rooms = new Dictionary<string, int>();

            //Счётчик
            int count = 0,i = 0;

            TbxRooms.Clear();

            //Временный список 
            List<Appliance> tempList = new List<Appliance>();

            //Добавляем комнаты в словарь 
            foreach (Appliance item in _flatController.GetAppliances)
                Rooms[item.Room] = count;

            //Подсчёт кол-ва приборов в комнате 
            foreach (string key in Rooms.Keys)
            {
                //Находим необходимые приборы через FindAll
                count = _flatController.GetAppliances.FindAll(elem => elem.Room == key).Count;

                //Вывод в Tbx

                TbxRooms.Text += $"{++i}. {key}: {count} приборов\r\n";

            }
        }

        private void AddAppliance_Command(object sender, EventArgs e)
        {
            Appliance_form addForm = new Appliance_form();
            DialogResult showResult = addForm.ShowDialog();

            //Если заверешение работы формы произошло не через кнопку добавить/сохранить
            //со свойством DialogResult.Yes, тогда объект не добавляем 
            if (showResult != DialogResult.OK)
                return;


            //Если же завершение работы формы было корректным, тогда добавляем объект в список приборов
            _flatController.Flat.Appliances.Add(addForm.appliance);
            
            //Последний добавленный прибор заносим в ListView
            Lsv_Main.Items.Add(_flatController.GetAppliances[_flatController.Count - 1].ToListView());

            //Изменяем дерево
            FillTreeView();

            //Проверка на пустоту 
            IsColletionEmpty();

            //Выводи кол-ва приборов в каждой комнате 
            CountInRooms();

            //Изменение статусной строки 
            int turnedOn = _flatController.CountTurnedOn(), amount = _flatController.Count;
            TSl_Footer.Text = $"Приборов в квартире: {amount} | Включено: {turnedOn} | Выключено: {amount - turnedOn}";

            //Сохранение 
            _flatController.Serialize();
        }

        //Добавление коллекции приборов в фомру
        private void AddCollection_Command(object sender, EventArgs e)
        {
            _flatController.Flat.AddCollectionToList();

            //Проводим повторную связку с List box
            FillListView(_flatController.GetAppliances,Lsv_Main);

            //Изменяем дерево
            FillTreeView();

            //Проверка на пустоту 
            IsColletionEmpty();

            //Выводи кол-ва приборов в каждой комнате 
            CountInRooms();

            //Изменение статусной строки 
            int turnedOn = _flatController.CountTurnedOn(), amount = _flatController.Count;
            TSl_Footer.Text = $"Приборов в квартире: {amount} | Включено: {turnedOn} | Выключено: {amount - turnedOn}";

            //Сохранение 
            if (_flatController.Count < 1000)
                _flatController.Serialize();
        }

        //Удаление прибора
        private void DelAppliance_Command(object sender, EventArgs e)
        {
            int ind = Lsv_Main.SelectedIndices.Count == 0 ? -1 : Lsv_Main.SelectedIndices[0];

            //Проверка на корректность выбранного элемента 
            if (ind < 0 || ind >= _flatController.Flat.Count)
                return;
            //Удаление элемента
            _flatController.GetAppliances.RemoveAt(ind);
            //Повторное связывание 
            FillListView(_flatController.GetAppliances,Lsv_Main);

            //Изменяем дерево
            FillTreeView();

            //Проверка на пустоту 
            IsColletionEmpty();

            //Выводи кол-ва приборов в каждой комнате 
            CountInRooms();

            //Изменение статусной строки 
            int turnedOn = _flatController.CountTurnedOn(), amount = _flatController.Count;
            TSl_Footer.Text = $"Приборов в квартире: {amount} | Включено: {turnedOn} | Выключено: {amount - turnedOn}";

            //Сохранение 
            if (_flatController.Count >= 5)
                _flatController.Serialize();
        }

        //Удаление всей коллекции [23.11]
        private void DelAll_Command(object sender, EventArgs e) 
        {
            _flatController.Flat.Appliances.RemoveRange(0,_flatController.Count);

            //Перепривязка данных 
            FillListView(_flatController.GetAppliances, Lsv_Main);

            //Изменяем дерево
            FillTreeView();

            //Проверка на пустоту 
            IsColletionEmpty();

            //Изменение статусной строки 
            int turnedOn = _flatController.CountTurnedOn(), amount = _flatController.Count;
            TSl_Footer.Text = $"Приборов в квартире: {amount} | Включено: {turnedOn} | Выключено: {amount - turnedOn}";

        }

        //Отключение элементов управления коллекцией в случае её пустоты [23.11.21]
        private void IsColletionEmpty()
        {
            //Если коллекция не пуста
            if (!_flatController.IsEmpty)
            {
                
                //Изменение состояний кнопок
                EditAppToolStripMenuItem.Enabled = true;
                DeleteAppMNI.Enabled = true;
                AddCollectionAppMni.Enabled = true;
                SortsToolStripMenuItem.Enabled = true;
                SelectionTSMItem.Enabled = true;
                //DelAppsMni.Enabled = true;
                TurnOnAllTopMni.Enabled  = true;
                TurnOffAllTopMni.Enabled = true;

                //Включаем кнопку выборки 
                SelectionTSMItem.Enabled = true;

                //Включаем кнопки контекстного меню 
                DelAppCM.Enabled = true;
                DelWhole_CM.Enabled = _flatController.Count > 1;
                EditAppCM.Enabled = true;
                SelecetionsSetCM.Enabled = true;
                SortsSetCM.Enabled = true;

                //Кнопки управления приборами
                BtnTurnOnOneStrip.Enabled = 
                BtnTurnOFFOneStrip.Enabled = 
                TurnOnAppliance_CM.Enabled = 
                TurnOffAppliance_CM.Enabled =  true;

                //Отключаем возможность загрузки из файла 
                OpenFile_CM.Visible = false;

                //включаем кнопки menu strip
                BtnSortsToolStrip.Enabled =      true;
                BtnSelectionsToolStrip.Enabled = true;
                BtnEditToolStrip.Enabled =       true;
                BtnDelAppToolStrip.Enabled =     true;
                BtnManyAppsStrip.Enabled =       true;

                //Включение текстового поля
                GbxRooms.Visible = GbxAppliance.Visible = true;

                //Отключение уведомления 
                Lbl_Main_Empty.Visible = false;

                return;

            }

            //Если коллекция пуста, оставляем включенными только возможности добавления 
            //Изменение состояний кнопок 
            
            EditAppToolStripMenuItem.Enabled = false;

            //Отключаем кнопку выборки 
            SelectionTSMItem.Enabled = false;
            SortsToolStripMenuItem.Enabled = false;
            DeleteAppMNI.Enabled = false;

            //DelAppsMni.Enabled = false;
            DelWhole_CM.Enabled = false;
            TurnOnAllTopMni.Enabled = false;
            TurnOffAllTopMni.Enabled = false;
            //Отключаем кнопки контекстного меню 

            DelAppCM.Enabled = false;
            EditAppCM.Enabled = false;
            SelecetionsSetCM.Enabled = false;
            SortsSetCM.Enabled = false;

            //Кнопки управления приборами
            BtnTurnOnOneStrip.Enabled =
            BtnTurnOFFOneStrip.Enabled =
            TurnOnAppliance_CM.Enabled =
            TurnOffAppliance_CM.Enabled = false;

            //Включаем возможность загрузки из файла 
            OpenFile_CM.Visible = true;

            //Отключаем кнопки menu strip
            BtnSortsToolStrip.Enabled = false;
            BtnSelectionsToolStrip.Enabled = false;
            BtnEditToolStrip.Enabled = false;
            BtnDelAppToolStrip.Enabled = false;
            BtnManyAppsStrip.Enabled = false;

            //Включение текстовых полей
            GbxRooms.Visible = GbxAppliance.Visible = false;

            //Отключение уведомления 
            Lbl_Main_Empty.Visible = true;
            Lbl_Main_Empty.Text = "Коллекция приборов пуста!";

        }

        #region Сортировки 

        //Блокируем выбор элемента
        private void Lbx_Sorted_SelectedIndexChanged(object sender, EventArgs e)
        {
            TurnOff_Buttons_Tab(Sorts_Tab);
        }

        //Загрузка вкладки
        private void SortsTab_Fill(List<Appliance> collection, string Type)
        {
            //Переключаем текущую вкладку 
            Tab_Control_Main.SelectedTab = Sorts_Tab;

            FillListView(collection, Lsv_Sorts);

            //Задание текста на Label
            switch (Type)
            {
                case "по имени":
                    Lbl_SortsTab.Text = "Сортировка приборов по названию";
                    break;

                case "по состоянию":
                    Lbl_SortsTab.Text = "Сортировка приборов по состоянию";
                    break;

                case "по мощности":
                    Lbl_SortsTab.Text = "Сортировка приборов по мощности";
                    break;

                case "по стоимости":
                    Lbl_SortsTab.Text = "Сортировка приборов по стоимости";
                    break;
                default:
                    break;
            }

            //Изменение статусной строки 
            int turnedOn = _flatController.CountTurnedOn(), amount = _flatController.Count;
            TSl_Footer.Text = $"Отсортировано приборов {Type}: {collection.Count} | Включено: {turnedOn} | Выключено: {amount - turnedOn}";

        }
        private void SortByNameTSMItem_Command(object sender, EventArgs e)
        {
            //Сортировка коллекции. Метод контроллера возвращает отсортированную копию коллекции
            SortsTab_Fill(_flatController.SortByName(),"по имени");
 
        }

        private void SortByStatelTSMItem_Command(object sender, EventArgs e)
        {

            //Сортировка коллекции. Метод контроллера возвращает отсортированную копию коллекции
            SortsTab_Fill(_flatController.SortByState(),"по состоянию");

        }
        private void SortByPowerTSMItem_Command(object sender, EventArgs e)
        {

            //Сортировка коллекции. Метод контроллера возвращает отсортированную копию коллекции
            SortsTab_Fill(_flatController.SortByPower(),"по мощности");

        }

        private void SortByPriceTSMItem_Command(object sender, EventArgs e)
        {

            //Сортировка коллекции. Метод контроллера возвращает отсортированную копию коллекции
            SortsTab_Fill(_flatController.SortDescByPrice(),"по стоимости");
        }
        #endregion

        private void ReformCollection_Command(object sender, EventArgs e)
        {
            _flatController.Flat.Generate(Utils.Random.Next(12, 15));

            //Перепривязка данных 
            FillListView(_flatController.GetAppliances, Lsv_Main);

            //Изменяем дерево
            FillTreeView();

            //Проверка на пустоту 
            IsColletionEmpty();

            //Выводи кол-ва приборов в каждой комнате 
            CountInRooms();

            //Изменение статусной строки 
            int turnedOn = _flatController.CountTurnedOn(), amount = _flatController.Count;
            TSl_Footer.Text = $"Приборов в квартире: {amount} | Включено: {turnedOn} | Выключено: {amount - turnedOn}";

            //Сохранение 
            _flatController.Serialize();

        }

        #region Обработчики события на вкладках
        //Закрыть вкладку при выходе
        private void Tab_Leave(object sender, EventArgs e)
        {
            //Включаем кнопки управления
            TurnOn_Buttons_Tab();

        }

        //Закрыть вкладку по кнопке
        private void Close_Current_Tab_Command(object sender, EventArgs e)
        {
            TabPage currPage = Tab_Control_Main.SelectedTab;

            //Если вкладки нет в коллекции или произошла попытка закрытия главной вкладки - выходим
            if (currPage == null || currPage == Main_tab)
                return;

            TurnOn_Buttons_Tab();
        }

        //Переход во динамическую вкладку
        private void Enter_Dyn_Tab(object sender, EventArgs e)
        {

            TabPage tempPage = sender as TabPage;
            //Отключаем кнопки управления коллекцией 
            TurnOff_Buttons_Tab(tempPage);


            if (tempPage == Sorts_Tab)
                SortByNameTSMItem_Command(sender, e);
            else if (tempPage == Selection_Tab)
            {
                Lsv_Selection.Enabled = true;
                //Проверка коллекции на пустоту
                if (_flatController.IsEmpty)
                 {
                    Lsv_Selection.Enabled = false;

                    Lsv_Selection.Items.Clear();

                    IsColletionEmpty();

                    Lbl_SelectionTab.Text = "Исходная коллекция пуста!\r\nЗаполните данными!";

                    TSl_Footer.Text = "";
                    return;
                 }

                if (Lsv_Selection.Items.Count <= 0)
                    //Выводим сообщение
                    Lbl_SelectionTab.Text = "Необходимо выбрать способ выборки в меню сверху!";
                TSl_Footer.Text = "";

            }
            //Если возращаемя на главную вкладку
            else if (tempPage == Main_tab)
            {
                IsColletionEmpty();
                //Изменение статусной строки 
                int turnedOn = _flatController.CountTurnedOn(), amount = _flatController.Count;
                TSl_Footer.Text = $"Приборов в квартире: {amount} | Включено: {turnedOn} | Выключено: {amount - turnedOn}";

            }

        
        }

        #endregion

        #region Выборки


        //Загрузка вкладки
        private void SelectionTab_Fill( List<Appliance> collection)
        {
            //Переключаем текущую вкладку 
            Tab_Control_Main.SelectedTab = Selection_Tab;

            FillListView(collection, Lsv_Selection);
            

        }


        //Выборка по  
        private void SelectByName_Command(object sender, EventArgs e)
        {
            //Список для хранения возвращаемого списка 
            List<Appliance> Appliances = new List<Appliance>();

            //Создаём окно выбора подколлекции 
            Select_Certain select_Certain = new Select_Certain(_flatController, Select_Certain.SubObject.name);

            if (select_Certain.ShowDialog() != DialogResult.OK)
                return;

            //Получаем выбранного мастера
            string ChosenName = (string)select_Certain.ChosenItem;

            Appliances = _flatController.SelectByName(ChosenName);

            //Открываем вкладку
             SelectionTab_Fill(Appliances);

            //Выводим сообщение
            Lbl_SelectionTab.Text = $"Выборка по названию прибора \"{ChosenName}\"";
        }

        //Выборка по 
        private void SelectByState_Command(object sender, EventArgs e)
        {

            //Список для хранения возвращаемого списка 
            List<Appliance> Appliances = new List<Appliance>();

            //Создаём окно выбора подколлекции 
            Select_Certain select_Certain = new Select_Certain(_flatController, Select_Certain.SubObject.state);

            if (select_Certain.ShowDialog() != DialogResult.OK)
                return;

            //Получаем выбранную
            string ChosenState = (string)select_Certain.ChosenItem;
            bool state = ChosenState == "Включен" ? true : false;

            Appliances = _flatController.SelectByState(state);

            //Выводим сообщение
            Lbl_SelectionTab.Text = $"Выборка по состоянию прибора \"{ChosenState}\"";

            //Открываем вкладку
            SelectionTab_Fill(Appliances);


        }

        #endregion

        //Удаление множества приборов
        private void BtnDelCertain_Click(object sender, EventArgs e)
        {
            //Вызываем форму удаления 
            Del_Certain_Appliance_Form del_Form = new Del_Certain_Appliance_Form(_flatController);

            if (del_Form.ShowDialog() != DialogResult.OK)
                return;
            //Получаем измененный контроллер
            _flatController = del_Form.rsController;

            //Перепривязка данных 
            FillListView(_flatController.GetAppliances, Lsv_Main);

            //Сохранение если в коллекции осталось мие 5 элементов
            if (_flatController.Count >= 5)
                _flatController.Serialize();

            //Проверка на пустоту 
            IsColletionEmpty();

        }

        //Редактирование прибора
        private void EditAppliance_Command(object sender, EventArgs e)
        {
            int ind = Lsv_Main.SelectedIndices.Count == 0 ? -1 : Lsv_Main.SelectedIndices[0];
            string oldRoom = _flatController.GetAppliances[ind].Room;

            //Проверка на наличие выбранного элемента 
            if (ind < 0 || ind >= _flatController.Flat.Count)
            {
                MessageBox.Show("Не выбран прибор", "Ошибка", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
                return;
            }

            //Создаём форму в режиме редактирования
            Appliance_form appliance_Form = new Appliance_form(_flatController.GetAppliances[ind]);
            DialogResult showResult = appliance_Form.ShowDialog();

            //Если заверешение работы формы произошло не через кнопку добавить/сохранить
            //со свойством DialogResult.Yes, тогда объект не добавляем

            if (showResult != DialogResult.OK)
                return;

            //Если же завершение работы формы было корректным, тогда изменяем выбранный обект в списке

            _flatController.Flat.Appliances.Insert(ind, appliance_Form.appliance);

            //Перепривязка данных 
            FillListView(_flatController.GetAppliances, Lsv_Main);

            //Если комната изменилась
            if (_flatController.GetAppliances[ind].Room != oldRoom)
                //Выводим кол-ва приборов в каждой комнате 
                CountInRooms();

            //Сохранение 
            _flatController.Serialize();
        }

        //Запус формы о программе
        private void About_Command(object sender, EventArgs e)
        {
            Form fromAbout = new AboutForm();
            fromAbout.ShowDialog();
        }

        private void OpenFile_Command(object sender, EventArgs e)
        {
            DialogResult showResult = OFD.ShowDialog();
            if (showResult != DialogResult.OK)
                return;
            _flatController.FName = OFD.FileName;

            _flatController.Deserialize();

            //Привязка данных 
            FillListView(_flatController.GetAppliances, Lsv_Main);

            //Проверка на пустоту 
            IsColletionEmpty();

            //Выводим кол-ва приборов в каждой комнате 
            CountInRooms();

        }

        //Редактирование днанных телемастерской 
        private void EditFlat_Command(object sender, EventArgs e)
        {
            
            EditFlat_Form editFlat = new EditFlat_Form(_flatController.Flat.Adress);

            //Если форма была завершена не по кнопке "Сохранить"
            if (editFlat.ShowDialog() != DialogResult.OK)
                return;

            //Перезаписываем 
            _flatController.Flat.Adress = editFlat.Adress_;

           
        }

        //Изменение шрифта
        private void ChangeFont_Command(object sender, EventArgs e)
        {
            if (FND_ListView.ShowDialog() != DialogResult.OK)
                return;
            Lsv_Main.Font = FND_ListView.Font;
            Lsv_Sorts.Font = FND_ListView.Font;
            Lsv_Selection.Font = FND_ListView.Font;

        }

        //Изменение цвета
        private void ChangeColor_Command(object sender, EventArgs e)
        {
            if (CLD_ListView.ShowDialog() != DialogResult.OK)
                return;

            ToolStripMenuItem button = sender as ToolStripMenuItem;
            if (button == ChangeBackColor_CM)
            {
                Lsv_Main.BackColor = CLD_ListView.Color;
                Lsv_Selection.BackColor = CLD_ListView.Color;
                Lsv_Sorts.BackColor = CLD_ListView.Color;

            }
            else if (button == ChangeForeColor_CM)
            {
                Lsv_Main.ForeColor = CLD_ListView.Color;
                Lsv_Selection.ForeColor = CLD_ListView.Color;
                Lsv_Sorts.ForeColor = CLD_ListView.Color;
            }
            
        }

        //Отключение кнопок управления коллекцией при открытии вкладок Выборка и Сортировки 
        private void TurnOff_Buttons_Tab(TabPage tabPage)
        {
            //Если вкладка - выборка
            if (tabPage == Selection_Tab) {
                //Изменение состояний кнопок верхнего меню

                EditAppToolStripMenuItem.Enabled =
                SortsToolStripMenuItem.Enabled =
                DeleteAppMNI.Enabled = 
                DelWhole_CM.Enabled = 
                AddAppToolStripMenuItem.Enabled =
                ReformTSMItem.Enabled = 
                AddCollectionAppMni.Enabled =
                TurnOnAllTopMni.Enabled = 
                TurnOffAllTopMni.Enabled = false;

                //Отключаем кнопки menu strip
                BtnAddToolStrip.Enabled =
                BtnSortsToolStrip.Enabled =
                BtnEditToolStrip.Enabled =
                BtnDelAppToolStrip.Enabled =
                BtnManyAppsStrip.Enabled =
                BtnTurnOnOneStrip.Enabled =
                BtnTurnOFFOneStrip.Enabled = false;
                //BtnSelectionsToolStrip.Enabled = false;

            }
            //Оператор else if для полного контроля
            else if (tabPage == Sorts_Tab)
            {
                //Изменение состояний кнопок 
                EditAppToolStripMenuItem.Enabled = 
                SelectionTSMItem.Enabled =
                DeleteAppMNI.Enabled =
                DelWhole_CM.Enabled =
                AddAppToolStripMenuItem.Enabled =
                ReformTSMItem.Enabled =
                AddCollectionAppMni.Enabled =
                TurnOnAllTopMni.Enabled =
                TurnOffAllTopMni.Enabled = false;

                SortsToolStripMenuItem.Enabled =
                BtnSortsToolStrip.Enabled = true;

                //Включаем кнопки menu strip
                BtnAddToolStrip.Enabled =
                BtnSelectionsToolStrip.Enabled =
                BtnEditToolStrip.Enabled =
                BtnDelAppToolStrip.Enabled =
                BtnManyAppsStrip.Enabled =
                BtnTurnOnOneStrip.Enabled =
                BtnTurnOFFOneStrip.Enabled = false;

            }
        }
        
        //Отключение кнопок управления коллекцией при открытии вкладок Выборка и Сортировки 
        private void TurnOn_Buttons_Tab()
        {
            //Изменение состояний кнопок 
            EditAppToolStripMenuItem.Enabled = 
            SortsToolStripMenuItem.Enabled = 
            SelectionTSMItem.Enabled = 
            DeleteAppMNI.Enabled =
            //DelAppsMni.Enabled = 
            DelWhole_CM.Enabled = 
            AddAppToolStripMenuItem.Enabled = 
            ReformTSMItem.Enabled = 
            AddCollectionAppMni.Enabled = 
            TurnOnAllTopMni.Enabled = 
            TurnOffAllTopMni.Enabled = true;

            //Включаем кнопки menu strip
            BtnAddToolStrip.Enabled = 
            BtnSortsToolStrip.Enabled =  
            BtnSelectionsToolStrip.Enabled = 
            BtnEditToolStrip.Enabled = 
            BtnDelAppToolStrip.Enabled = 
            BtnManyAppsStrip.Enabled = 
            BtnTurnOnOneStrip.Enabled = 
            BtnTurnOFFOneStrip.Enabled = true;


        }

        private void OpenFromTray_Command(object sender, EventArgs e)
        {
            this.Show();
            WindowState = FormWindowState.Normal;

            //Отключаем иконку 
            NTI.Visible = false;
        }

        private void HideForm_Command(object sender, EventArgs e)
        {
            this.Hide();
            NTI.Visible = true;
        }

        //Выключение одного прибора
        private void TurnOnOne_Command(object sender, EventArgs e)
        {
            int index = Lsv_Main.SelectedIndices.Count == 0 ? -1 : Lsv_Main.SelectedIndices[0];

            //Если выбор элемента некорректен
            if (index < 0 || index >= _flatController.Count)
                return;

            //Включаем прибор по индексу 
            _flatController.TurnApp(index, true);

            //Перепривязка данных 
            //FllListView(_flatController.GetAppliances, Lsv_Main);
            ChangeOne(_flatController.GetAppliances[index],Lsv_Main,index);

            //Отклчение нажатой кнопки
            BtnTurnOnOneStrip.Enabled = false;
            BtnTurnOFFOneStrip.Enabled = true;

            ChangeStatusString();
        }

        //Выключение одного прибора
        private void TurnOffOne_Command(object sender, EventArgs e)
        {

            int index = Lsv_Main.SelectedIndices.Count == 0 ? -1 : Lsv_Main.SelectedIndices[0];

            //Если выбор элемента некорректен
            if (index < 0 || index >= _flatController.Count)
                return;

            //Включаем прибор по индексу 
            _flatController.TurnApp(index, false);

            //Перепривязка данных 
            //FllListView(_flatController.GetAppliances, Lsv_Main);

            ChangeOne(_flatController.GetAppliances[index], Lsv_Main, index);

            BtnTurnOnOneStrip.Enabled = true;
            BtnTurnOFFOneStrip.Enabled = false;

            ChangeStatusString();
        }

        //Включение всех приборов
        private void TurnOnAll_Command(object sender, EventArgs e)
        {
            _flatController.TurnAllApp(true);

            //Перепривязка данных 
            FillListView(_flatController.GetAppliances, Lsv_Main);

            ChangeStatusString();
        }

        //Выключение всех приборов
        private void TurnOffAll_Command(object sender, EventArgs e)
        {
            _flatController.TurnAllApp(false);

            //Перепривязка данных 
            FillListView(_flatController.GetAppliances, Lsv_Main);

            ChangeStatusString();
        }


        #region Drag&Drop

        //Сброс на форму
        private void Main_form_DragDrop(object sender, DragEventArgs e)
        {
            Lsv_Main.BackColor = Color.White;
        }
        private void Main_form_DragEnter(object sender, DragEventArgs e)
        {

            // проверка на содержимое
            if (e.Data.GetDataPresent(DataFormats.FileDrop))
            {
                // переход на главную вкладку
                Tab_Control_Main.SelectedTab = Main_tab;

                // изменение цвета ListView
                Lsv_Main.BackColor = Color.CornflowerBlue;

                // установка эффекта
                e.Effect = DragDropEffects.Copy;
            }
            else
                // установка эффекта
                e.Effect = DragDropEffects.None;
        }
        private void Main_form_DragLeave(object sender, EventArgs e)
        {
            //Меняем цвет listveiw 
            Lsv_Main.BackColor = Color.White;
        }

        //
        private void Lsv_Main_DragEnter(object sender, DragEventArgs e)
        {
            // проверка на содержимое
            if (e.Data.GetDataPresent(DataFormats.FileDrop))
            {

                // изменение цвета ListView
                Lsv_Main.BackColor = Color.CornflowerBlue;

                // установка эффекта
                e.Effect = DragDropEffects.Copy;
            }
            else
                // установка эффекта
                e.Effect = DragDropEffects.None;
        }
       
        private void Lsv_Main_DragDrop(object sender, DragEventArgs e)
        {
            Lsv_Main.BackColor = Color.White;

            string fileName = ((string[])e.Data.GetData(DataFormats.FileDrop))[0];
            _flatController.FName = fileName;
            _flatController.Deserialize();

            FillListView(_flatController.GetAppliances, Lsv_Main);


            //Выводим кол-ва приборов в каждой комнате 
            CountInRooms();

            IsColletionEmpty();

            ChangeStatusString();

        } 
        private void Lsv_Main_DragLeave(object sender, EventArgs e)
        {
            //Меняем цвет listveiw 
            Lsv_Main.BackColor = Color.White;
        }
        #endregion

        //Для отключения выделения ListView
        private void Main_form_MouseDown(object sender, MouseEventArgs e)
        {
            //Меняем цвет listveiw 
            Lsv_Main.BackColor = Color.White;
        }
    }

}
