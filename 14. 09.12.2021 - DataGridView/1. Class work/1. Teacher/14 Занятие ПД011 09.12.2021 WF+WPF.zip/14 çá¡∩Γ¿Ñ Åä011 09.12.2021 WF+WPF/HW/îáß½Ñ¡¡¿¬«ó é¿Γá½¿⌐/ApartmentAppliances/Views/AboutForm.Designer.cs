﻿
namespace ApartmentAppliances.Views
{
	partial class AboutForm
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AboutForm));
			this.LblAbout = new System.Windows.Forms.Label();
			this.BtnOk = new System.Windows.Forms.Button();
			this.TxbAbout = new System.Windows.Forms.TextBox();
			this.SuspendLayout();
			// 
			// LblAbout
			// 
			this.LblAbout.Font = new System.Drawing.Font("Verdana", 11.25F);
			this.LblAbout.Location = new System.Drawing.Point(12, 417);
			this.LblAbout.Name = "LblAbout";
			this.LblAbout.Size = new System.Drawing.Size(600, 23);
			this.LblAbout.TabIndex = 5;
			this.LblAbout.Text = "Студент Масленников В., группа ПД011, Донецк, 2021";
			this.LblAbout.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// BtnOk
			// 
			this.BtnOk.BackColor = System.Drawing.SystemColors.Control;
			this.BtnOk.DialogResult = System.Windows.Forms.DialogResult.OK;
			this.BtnOk.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.BtnOk.Location = new System.Drawing.Point(816, 408);
			this.BtnOk.Name = "BtnOk";
			this.BtnOk.Size = new System.Drawing.Size(160, 32);
			this.BtnOk.TabIndex = 4;
			this.BtnOk.Text = "OK";
			this.BtnOk.UseVisualStyleBackColor = false;
			// 
			// TxbAbout
			// 
			this.TxbAbout.AutoCompleteCustomSource.AddRange(new string[] {
            "\tЗадача 1. Разработайте приложение Windows Forms с использованием изученных элеме" +
                "нтов",
            "интерфейса (строковое меню, контекстное меню, панель инструментов, лист-бокс, ком" +
                "бо-бокс, ",
            "строка состояния, строки ввода, чек-боксы и радиокнопки, вкладки, ListView). ",
            "\t",
            "\tРазработайте класс, описывающий электроприбор: название; мощность; цена; состоян" +
                "ие",
            "прибора: включен/выключен; название комнаты, в которой размещен прибор (кухня, пр" +
                "ихожая, …). ",
            "\t",
            "\tРазработайте класс, описывающий электрооборудование квартиры: адрес квартиры, ",
            "условное название квартиры (Васин дом, Орлиная слободка, …) коллекция электроприб" +
                "оров.",
            "Отдельно хранить названия комнат не надо.",
            "\t",
            "\tПриложение должно использовать вкладки. Сведения о квартире и список электроприб" +
                "оров ",
            "выводить в первой вкладке главной формы.  ",
            "\t",
            "\tСведения о квартире разместить в виде дерева в TreeView в левой части вкладки, в" +
                " правой",
            "части – вывод этих же сведений в ListView в табличном формате.",
            "\t",
            "\tПри построении дерева используйте следующие соответствия: корень дерева – условн" +
                "ое",
            "название квартиры, узлы – названия комнат, листья – электроприборы в комнате. Изо" +
                "бражение",
            "узла дерева – условное обозначение электроприбора.",
            "\t",
            "\tПриложение должно иметь следующий функционал (при помощи пунктов меню, контекстн" +
                "ого меню,",
            "кнопок панели инструментов):",
            "\t•\tСворачивать приложение в трей, восстанавливать форму приложения из контекстног" +
                "о меню ",
            "иконки в трее. В этом же контекстом меню разместите команды для завершения прилож" +
                "ения, вызова ",
            "формы со сведениями о приложении и разработчике",
            "\t•\tПри запуске приложения проверять наличие в папке исполняемого файла папки App_" +
                "Data ",
            "и файла appliances.json с данными о квартире. Если папки и/или файл нет, то созда" +
                "ть папку, ",
            "заполнить начальными данными объект, описывающий электрооборудование квартиры, се" +
                "риализовать",
            "данные в формате JSON",
            "\t•\tВыводить коллекцию электроприборов в ListView в табличном формате, состояние п" +
                "рибора ",
            "отображать картинкой   ",
            "\t•\tПереформирование коллекции электроприборов и сведений о квартире с сериализаци" +
                "ей ",
            "\t•\tСохранение данных в выбранном файле – сериализация в формате JSON. Файл для со" +
                "хранения ",
            "выбирать стандартным диалогом ",
            "\t•\tЗагрузка данных из выбранного стандартным диалогом файла, перетаскиванием файл" +
                "а на ",
            "ListView главной вкладки, на TreeView главной вкладки, десериализация в формате J" +
                "SON. ",
            "\t•\tДобавление электроприбора в коллекцию (ввод данных в отдельной форме), сериали" +
                "зация данных",
            "\t•\tУдаление электроприбора из коллекции, сериализация данных",
            "\t•\tРедактирование выбранного электроприбора в отдельной форме, сериализация данны" +
                "х",
            "\t•\tРедактирование названия квартиры, комнаты, электроприбора непосредственно в уз" +
                "лах",
            "дерева – редактирование меток узлов дерева",
            "\t•\tРедактирование данных квартиры – адрес и название, сериализация данных",
            "\t•\tУпорядочивание копии коллекции электроприборов, вывод упорядоченной копии колл" +
                "екции",
            "в отдельной вкладке. При выборе команды переходить на вкладку",
            "\t\to\tПо названию",
            "\t\to\tПо состоянию",
            "\t\to\tПо мощности",
            "\t\to\tПо убыванию цены",
            "\t•\tВключение/выключение выбранного электроприбора",
            "\t•\tВключение/выключение всех электроприборов квартиры",
            "\t•\tВключение и выключение всех электроприборов комнаты",
            "\t•\tВыборка и вывод в отдельной вкладке главной формы коллекции электроприборов, с" +
                " ",
            "заданным названием. При выборе команды переходить на вкладку",
            "\t•\tВыборка и вывод в отдельной вкладке главной формы коллекции электроприборов за" +
                "данного ",
            "состояния. При выборе команды переходить на вкладку",
            "\tВ меню и контекстных меню (ListView, MainForm, NotifyIcon) включите команды выхо" +
                "да, вывода ",
            "окна со сведениями о программе и ее разработчике."});
			this.TxbAbout.BackColor = System.Drawing.SystemColors.ControlLightLight;
			this.TxbAbout.Font = new System.Drawing.Font("Verdana", 11F);
			this.TxbAbout.Location = new System.Drawing.Point(12, 9);
			this.TxbAbout.Multiline = true;
			this.TxbAbout.Name = "TxbAbout";
			this.TxbAbout.ReadOnly = true;
			this.TxbAbout.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
			this.TxbAbout.Size = new System.Drawing.Size(964, 384);
			this.TxbAbout.TabIndex = 3;
			this.TxbAbout.Text = resources.GetString("TxbAbout.Text");
			// 
			// AboutForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(987, 450);
			this.Controls.Add(this.LblAbout);
			this.Controls.Add(this.BtnOk);
			this.Controls.Add(this.TxbAbout);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.MaximizeBox = false;
			this.Name = "AboutForm";
			this.ShowInTaskbar = false;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "О программе";
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Label LblAbout;
		private System.Windows.Forms.Button BtnOk;
		private System.Windows.Forms.TextBox TxbAbout;
	}
}