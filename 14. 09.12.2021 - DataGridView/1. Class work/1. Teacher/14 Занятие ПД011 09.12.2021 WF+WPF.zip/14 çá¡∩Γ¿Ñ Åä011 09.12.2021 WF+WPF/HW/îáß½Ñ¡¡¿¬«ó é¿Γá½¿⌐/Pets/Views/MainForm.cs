﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Pets.Controllers;
using Pets.Models;

namespace Pets.Views
{
	public partial class MainForm : Form
	{
		// Коды изображений в ImageList
		enum ImgCodes
		{
			Root = 32,
			Weight = 33,
			Age = 34,
			Paint = 35,
			Owner = 36
		}

		// Объект контроллера для работы с коллекцией
		private PetsClubController _petsClubController;

		public MainForm() : this(new PetsClubController())
		{}

		public MainForm(PetsClubController petsClubController)
		{
			InitializeComponent();
			_petsClubController = petsClubController;
		}

		// Обработка при загрузке формы
		private void MainForm_Load(object sender, EventArgs e)
		{
			// Обновить содержимое ListView
			UpdateMainListView();

			// Обновить заголовок окна и статусную строку 
			UpdateMainTitle();

			GrbMain.Text = _petsClubController.PetsClub.Name ;

			OrderBySpecies_Command(sender, e);

			UpdateListView(LsvSelected, _petsClubController.Animals);

			InitializeTreeView();

			TbcMain.SelectedTab = TbpMain;
			UpdateStatusLine();
		}

		

		// Обновление заголовка главной формы
		private void UpdateMainTitle()
		{
			// формировка заголовка с проверкой на наличией изменений с последнего сохранения
			StringBuilder sb = new StringBuilder();
			sb.Append(_petsClubController.PetsClub.Name);
			sb.Append(" - " + Path.GetFileName(_petsClubController.FileName));

			// установка заголовка в форму
			Text = sb.ToString();
		}

		// Обеовление информации в статусной линии
		private void UpdateStatusLine(string msg = "")
		{
			StlLblMessage.Text = msg;
			StlLblStatus.Text =
				$"Питомцев: {_petsClubController.Animals.Count}  |  Файл: {Path.GetFileName(_petsClubController.FileName)}";
		}

		// о программе
		private void About_Command(object sender, EventArgs e) => new AboutForm().ShowDialog();
			

		// выход из приложения
		private void Exit_Command(object sender, EventArgs e) => Application.Exit();


		// Команда отображения формы изменения данных о клубе питомцев
		private void PetsClubSettings_Command(object sender, EventArgs e)
		{
			PetsClubSettinfsForm settingsForm =
				new PetsClubSettinfsForm(_petsClubController.PetsClub.Name);

			if (settingsForm.ShowDialog() != DialogResult.OK) return;

			_petsClubController.PetsClub.Name = settingsForm.Title;

			GrbMain.Text = _petsClubController.PetsClub.Name;

			UpdateMainTitle();
			UpdateStatusLine("Название клуба изменено.");
			InitializeTreeView();
			SaveData();
		}

		#region Обработка TreeView

		// Метод заполнения TreeView коллекцией приборов
		private void InitializeTreeView()
		{
			TrvMain.Nodes.Clear();

			// создание корня - клуб
			TrvMain.Nodes.Add(_petsClubController.PetsClub.Name, _petsClubController.PetsClub.Name,
				(int)ImgCodes.Root, (int)ImgCodes.Root);

			// создание узлов - животные
			_petsClubController.PetsClub.Animals.ForEach(pet =>
			{
				var added = TrvMain.Nodes[0].Nodes.Add(pet.Name, pet.Species + " " + pet.Name, pet.IdImage, pet.IdImage + 16);
				
				// получение веса в строковом представлении с нужным количеством знаков
				double weight = pet.Weight;
				string w = weight < 0.1 ? (weight < 0.01 ? $"{weight:F3}" : $"{weight:F2}") : $"{weight:F1}";

				// добавление листьев узла - параметры животного
				added.Nodes.Add(w,w, (int)ImgCodes.Weight, (int)ImgCodes.Root);
				added.Nodes.Add($"{pet.Age:F1}", $"{pet.Age:F1}", (int)ImgCodes.Age, (int)ImgCodes.Age);
				added.Nodes.Add(pet.Paint, pet.Paint, (int)ImgCodes.Paint, (int)ImgCodes.Paint);
				added.Nodes.Add(pet.Owner, pet.Owner, (int)ImgCodes.Owner, (int)ImgCodes.Owner);
			});


			// развернуть сформированные узлы дерева 
			TrvMain.ExpandAll();

			TrvMain.SelectedNode = TrvMain.Nodes[0];
		}
		
		// Развернуть все элементы дерева
		private void ExpandAll_Command(object sender, EventArgs e)
		{
			TrvMain.ExpandAll();
			TrvMain.Select();
			TrvMain.SelectedNode = TrvMain.Nodes[0];
		}

		// Свернуть все элементы дерева
		private void CollapseAll_Command(object sender, EventArgs e) => TrvMain.CollapseAll();

		#endregion


		#region Обработка ListView

		// Обновить содержимого ListView главной вкладки
		private void UpdateMainListView() =>
			UpdateListView(LsvAnimals, _petsClubController.Animals);

		// Метод обновления ListView по параметрам
		private static void UpdateListView(ListView listView, List<Animal> animals)
		{
			listView.Items.Clear();

			if (animals.Count == 0) return;

			animals.ForEach(ap =>
			{
				double weight = ap.Weight;
				listView.Items.Add(
					new ListViewItem(new[]
					{
						"",
						$"{ap.Species}",
						$"{ap.Name}",
						$"{ap.Age:F1}",
						weight < 0.1 ? (weight < 0.01 ? $"{weight:F3}" : $"{weight:F2}") : $"{weight:F1}",
						$"{ap.Paint}",
						$"{ap.Owner}"
					}, ap.IdImage));
			});
		}

		// установить выделение в ListView
		private void SetLsvSelectedIndex(int index)
		{
			if (index == -1) return;
			LsvAnimals.Items[index].Selected = true;
			LsvAnimals.Select();
			LsvAnimals.EnsureVisible(index);
		}

		// Обработка нажатий клавиш при фокусе ListView
		private void LsvAppliances_KeyDown(object sender, KeyEventArgs e)
		{
			if (e.KeyCode == Keys.Delete) Delete_Command(sender, e);
			if (e.KeyCode == Keys.Enter) Edit_Command(sender, e);
		}

		private void LsvAnimals_MouseDoubleClick(object sender, MouseEventArgs e) =>
			Edit_Command(sender, e);

		private void TbcMain_SelectedIndexChanged(object sender, EventArgs e)
		{
			TsbEdit.Enabled = TsbDelete.Enabled = MnuEditEdit.Enabled = MnuEditDelete.Enabled =
				TbcMain.SelectedTab == TbpMain;

			if (TbcMain.SelectedTab == TbpSelect)
			{
				TxbOwnerInput.AutoCompleteMode = AutoCompleteMode.Suggest;
				TxbOwnerInput.AutoCompleteSource = AutoCompleteSource.CustomSource;
				TxbOwnerInput.AutoCompleteCustomSource.AddRange(_petsClubController.PetsClub.GetAnimalsOwners().ToArray());
			}
		}

		#endregion



		#region Изменение коллекции животных
		// сформировать коллекцию
		private void GenerateCollection_Command(object sender, EventArgs e)
		{
			_petsClubController.PetsClub.Initialize();
			UpdateMainListView();

			SaveData();

			OrderBySpecies_Command(sender, e);

			UpdateListView(LsvSelected, _petsClubController.Animals);
			InitializeTreeView();

			TbcMain.SelectedTab = TbpMain;

			// обновить строку состояния
			UpdateStatusLine("Коллекция питомцев переформирована.");
		}

		// добавить животное
		private void Add_Command(object sender, EventArgs e)
		{
			TbcMain.SelectedTab = TbpMain;

			AnimalForm animalForm = new AnimalForm();

			// отмена добавления
			if (animalForm.ShowDialog() != DialogResult.OK)
				return;

			// добавление животного в текущую коллекцию
			_petsClubController.AddAnimal(animalForm.Animal);

			// обновить главный listView
			UpdateMainListView();
			InitializeTreeView();

			// установка выделения в конец списка на новый элемент
			SetLsvSelectedIndex(LsvAnimals.Items.Count - 1);

			// обновить строку состояния
			UpdateStatusLine($"Добавлен питомец {animalForm.Animal.Name}.");

			// сохранение изменений в файл
			SaveData();
		}

		// удалить животное
		private void Delete_Command(object sender, EventArgs e)
		{
			if (LsvAnimals.SelectedIndices.Count == 0) return;

			// получить индекс выбранного элемента в ListView
			int index = LsvAnimals.SelectedIndices[0];

			string name = _petsClubController.PetsClub[index].Name;
			// удаление записи из коллекции и ListView
			_petsClubController.RemoveAt(index);
			LsvAnimals.Items.RemoveAt(index);

			UpdateStatusLine($"Удален питомец {name}.");

			// Возврат выделения элемента на место удаленного, если возможно
			int count = LsvAnimals.Items.Count;
			SetLsvSelectedIndex(count != 0 ? (index < count ? index : count - 1) : -1);

			InitializeTreeView();
			// сохранение изменений в файл
			SaveData();
		}

		// удалить всех животных
		private void DeleteAll_Command(object sender, EventArgs e)
		{
			TbcMain.SelectedTab = TbpMain;

			// очистка коллекции и listView
			_petsClubController.RemoveAll();
			LsvAnimals.Items.Clear();
			LsvOrdered.Items.Clear();
			LsvSelected.Items.Clear();
			

			UpdateStatusLine("Все питомцы удалены.");

			InitializeTreeView();

			// сохранение изменений в файл
			SaveData();
		}

		private void Edit_Command(object sender, EventArgs e)
		{
			if (LsvAnimals.SelectedIndices.Count == 0) return;

			// получить индекс выбранного элемента в ListView
			int index = LsvAnimals.SelectedIndices[0];

			// передача данных в форму
			AnimalForm animalForm = new AnimalForm("Редактировать информацию о питомце", "Сохранить")
			{
				Animal = _petsClubController.PetsClub[index]
			};

			// проверка на подтверджение изменения данных
			if (animalForm.ShowDialog() != DialogResult.OK)
				return;

			_petsClubController.PetsClub[index] = animalForm.Animal;

			UpdateMainListView();
			InitializeTreeView();

			SetLsvSelectedIndex(index);

			UpdateStatusLine($"Данные о питомце {animalForm.Animal.Name} изменены.");

			SaveData();
		}

		#endregion



		#region Сортировки

		// сортировка по возрасту
		private void OrderByAge_Command(object sender, EventArgs e) =>
			Order(_petsClubController.CopyOrderedByAge, "Питомцы отсортированы по возрасту:");

		// сотировка по виду
		private void OrderBySpecies_Command(object sender, EventArgs e) =>
			Order(_petsClubController.CopyOrderedBySpecies, "Питомцы отсортированы по виду:");

		// сотировка по фамилии владельца
		private void OrderByOwner_Command(object sender, EventArgs e) =>
			Order(_petsClubController.CopyOrderedByOwnersAnimals, "Питомцы отсортированы по фамилиям владельцев:");
		
		// метод сортировки копии и вывода в соответствующий listView
		private void Order(Func<List<Animal>> ordering, string prompt)
		{
			// отобразить отсортированные элементы в соответствующем listView
			UpdateListView(LsvOrdered, ordering());
			// изменение информации о сортировке
			LblOrdered.Text = prompt;
			// установка фокуса на вкладку с отсортированной коллекции
			TbcMain.SelectedTab = TbpOrder;

			UpdateStatusLine(prompt.TrimEnd(':') + ".");
		}

		#endregion



		#region Выборки

		// Выборка по максимальному весу животного
		private void SelectWhereMaxWeight_Command(object sender, EventArgs e)
		{
			List<Animal> selected = _petsClubController.SelectWhereMaxWeight();

			UpdateListView(LsvSelected, selected);

			LblSelected.Text = $"Питомцы отобраны по максимальному весу:";

			TxbOwnerInput.Visible = false;

			TbcMain.SelectedTab = TbpSelect;

			UpdateStatusLine("Питомцы отобраны по максимальному весу.");
		}

		// Выборка по максимальному весу животного
		private void SelectWhereOwnerName_Command(object sender, EventArgs e)
		{
			TxbOwnerInput.Visible = true;

			TbcMain.SelectedTab = TbpSelect;

			UpdateListView(LsvSelected, _petsClubController.Animals);

			LblSelected.Text = $"Введите часть фамилии для фильтра:";

			TxbOwnerInput.Select();
		}


		private void TxbOwnerInput_TextChanged(object sender, EventArgs e) =>
			UpdateListView(LsvSelected, _petsClubController.SelectWhereOwnerSurnameContains(TxbOwnerInput.Text));
		
		#endregion

		
		#region Сохранение\загрузка
			private void SaveData() => _petsClubController.SaveJsonToFile(_petsClubController.FileName);

		// Обработка команды "сохранить"
		private void Save_Command(object sender, EventArgs e)
		{
			SaveData();
			UpdateStatusLine("Данные сохранены в файл.");
		}

		// Обработка команды "сохранить как"
		private void SaveAs_Command(object sender, EventArgs e)
		{
			// установка директории для выбора файла 
			SfdMain.InitialDirectory = Path.GetDirectoryName(_petsClubController.FileName);

			if (SfdMain.ShowDialog() != DialogResult.OK) return;

			_petsClubController.FileName = SfdMain.FileName;

			_petsClubController.SaveJsonToFile(_petsClubController.FileName);

			UpdateStatusLine($"Данные сохранены в файл {_petsClubController.FileName}");
		}


		// Команда открытия файла
		private void FileOpen_Command(object sender, EventArgs e)
		{
			// установка директории для выбора файла 
			OfdMain.InitialDirectory = Path.GetDirectoryName(_petsClubController.FileName);

			// запуск диалогового окна открытия и проверка на результат
			if (OfdMain.ShowDialog() != DialogResult.OK) return;


			_petsClubController.FileName = OfdMain.FileName;

			_petsClubController.ReadJsonFromFile(_petsClubController.FileName);

			UpdateMainListView();
			InitializeTreeView();

			UpdateStatusLine($"Данные загружены из файла {_petsClubController.FileName}");

			GrbMain.Text = _petsClubController.PetsClub.Name;

			UpdateMainTitle();
		}

		// Команда создания нового файла коллекции
		private void FileNew_Command(object sender, EventArgs e)
		{
			SaveAs_Command(sender, e);

			_petsClubController.PetsClub.Name = "Новый клуб";

			// Переформировать данные и обновить листвью
			_petsClubController.PetsClub.Initialize();
			UpdateMainListView();
			InitializeTreeView();

			UpdateStatusLine($"Создан клуб {_petsClubController.PetsClub.Name}.");
		}


		#endregion

		
		#region Команды для трея
		// Команда сворачивания в трей
		private void ToTray_Command(object sender, EventArgs e)
		{
			this.Hide();
			NtiMain.BalloonTipText = _petsClubController.PetsClub.Name;
			NtiMain.Visible = true;
		}

		// Команда востановления из трея
		private void Restore_Command(object sender, EventArgs e)
		{
			this.Show();
			WindowState = FormWindowState.Normal;
			NtiMain.Visible = false;
		}


		// Восстановление из трея по дабл-клику
		private void CmnTray_MouseDoubleClick(object sender, MouseEventArgs e) =>
			Restore_Command(sender, e);

		#endregion


		#region Смена шрифта и фона

		// Команда смены шрифта
		private void Font_Command(object sender, EventArgs e)
		{
			if (FdlTextFont.ShowDialog() == DialogResult.OK)
				SetFont();
		}

		// Обработка кнопки применить в диалоге смены шрифта
		private void FdlTextFont_Apply(object sender, EventArgs e) => SetFont();

		// Непосредственно установка значения фона
		public void SetFont() => LsvAnimals.Font = FdlTextFont.Font;

		// Команда смены цвета фона
		private void BackColor_Command(object sender, EventArgs e)
		{
			if (CdlBackColor.ShowDialog() == DialogResult.OK)
				LsvAnimals.BackColor = CdlBackColor.Color;
		}

		// Команда смены цвета текста
		private void ForeColor_Command(object sender, EventArgs e)
		{
			if (CdlBackColor.ShowDialog() == DialogResult.OK)
				LsvAnimals.ForeColor = CdlBackColor.Color;
		}

		#endregion


		#region Drag'n'Drop

		private void DragEnter_Command(object sender, DragEventArgs e) =>
			e.Effect = e.Data.GetDataPresent(DataFormats.FileDrop) ? DragDropEffects.Move : DragDropEffects.None;

		private void DragDrop_Command(object sender, DragEventArgs e)
		{
			if (!e.Data.GetDataPresent(DataFormats.FileDrop))
				return;

			_petsClubController.ReadJsonFromFile(((string[])e.Data.GetData(DataFormats.FileDrop))[0]);

			UpdateMainTitle();
			UpdateMainListView();
			InitializeTreeView();

			GrbMain.Text = _petsClubController.PetsClub.Name;

			UpdateStatusLine($"Данные загружены из файла {_petsClubController.FileName}");
		}


		#endregion
		
	}
	
}
