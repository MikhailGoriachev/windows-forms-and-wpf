﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Appliances.Models;

namespace Appliances
{
    public partial class MainForm : Form
    {
        private List<Appliance> _appliances;
        public MainForm()
        {
            
            InitializeComponent();

            //коллекция для отображения 
            _appliances = new List<Appliance>
            {
                new Appliance{ Name = "Миксер", Power = 280, Price = 5000, OnOff = false},
                new Appliance {Name = "Пылесос", Power = 800, Price = 12000, OnOff = false}, 
                new Appliance {Name = "Утюг", Power = 300, Price = 2300, OnOff = false}, 
                new Appliance {Name = "Чайник", Power = 370, Price = 400, OnOff = false}, 
                new Appliance {Name = "Тостер", Power = 560, Price = 3450, OnOff = false}, 
                new Appliance {Name = "Соковыжималка", Power = 670, Price = 7800, OnOff = false}, 
                new Appliance {Name = "Дрель", Power = 750, Price = 8000, OnOff = false}, 
                new Appliance {Name = "Смартфон", Power = 50, Price =  10000, OnOff = false}, 
                new Appliance {Name = "Бритва", Power = 187, Price = 11203, OnOff = false}, 
                new Appliance {Name = "Фен", Power = 290, Price = 5400, OnOff = false}, 
                new Appliance {Name = "Компьютер", Power = 380, Price = 25000, OnOff = false}, 
                new Appliance {Name = "Обогреватель", Power = 430, Price = 3200, OnOff = false}

            };
            LbxAppliaces.DataSource = _appliances;

            LbxAppliaces.DisplayMember = "TableRow";

            // !!! укзано несуществующее свойство !!!
            // LbxAppliaces.ValueMember = "Id";

        }

        private void Appliance_Command(object sender, EventArgs e)
        {
            ListBoxAppliaces _appliaceForm = new ListBoxAppliaces();
            _appliaceForm.ShowDialog();
        }
    }
}
