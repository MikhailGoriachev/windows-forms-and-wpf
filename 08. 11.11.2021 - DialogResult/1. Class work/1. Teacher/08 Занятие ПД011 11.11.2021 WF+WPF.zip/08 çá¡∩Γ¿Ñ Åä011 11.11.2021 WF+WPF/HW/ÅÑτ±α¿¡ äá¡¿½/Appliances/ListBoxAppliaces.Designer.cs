﻿
namespace Appliances
{
    partial class ListBoxAppliaces
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ListBoxAppliaces));
            this.LbxAppliaces = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // LbxAppliaces
            // 
            this.LbxAppliaces.FormattingEnabled = true;
            this.LbxAppliaces.ItemHeight = 25;
            this.LbxAppliaces.Location = new System.Drawing.Point(103, 208);
            this.LbxAppliaces.Name = "LbxAppliaces";
            this.LbxAppliaces.Size = new System.Drawing.Size(589, 429);
            this.LbxAppliaces.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(103, 167);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(602, 38);
            this.label1.TabIndex = 1;
            this.label1.Text = "Назание            Мощность             Цена               Состояние";
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label2.Location = new System.Drawing.Point(103, 126);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(589, 38);
            this.label2.TabIndex = 2;
            this.label2.Text = "Перечень приборов\r\n\r\n";
            // 
            // ListBoxAppliaces
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1349, 673);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.LbxAppliaces);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "ListBoxAppliaces";
            this.Text = "Список приборов";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListBox LbxAppliaces;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
    }
}