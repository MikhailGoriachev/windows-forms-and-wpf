﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Appliances.Models
{
    /*
     Класс, описывающий электроприбор (название, мощность, цена, включен/выключен). 
     */
    public class Appliance
    {
        public string Name { get; set; }  // название прибора

        public double Power { get; set; }    // мощность 

        public int Price { get; set; }  // цена

        public bool OnOff { get; set; } // состояние включен/выключен

        public override string ToString() => $" Название прибора: {Name}; \r\nМощность: {Power}; \r\nЦена : {Price}; \r\nСостояние: {OnOff}";

        public string TableRow => $"{Name,10} | {Power,4} |  {Price,5} | {OnOff,3}";
    }// class Appliance
}
