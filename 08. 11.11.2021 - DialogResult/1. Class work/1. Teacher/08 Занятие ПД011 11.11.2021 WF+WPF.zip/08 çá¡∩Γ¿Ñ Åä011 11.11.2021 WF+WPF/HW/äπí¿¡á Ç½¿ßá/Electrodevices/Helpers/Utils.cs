﻿using System;

namespace Electrodevices.Helpers
{
    // вспомогательные методы и объекты - статический класс, т.е. класс,
    // содержащий только статические члены и методы
    public static class Utils
    {
        // объект для получения случайных чисел
        public static Random Random = new Random();
        
        // формирование случайных вещественных чисел в диапазоне от lo до hi
        public static double GetRandom(double lo, double hi)
            => lo + (hi - lo)*Random.NextDouble();
    } // class Utils
}