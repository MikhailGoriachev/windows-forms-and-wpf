﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Electrodevices.Helpers;
using Electrodevices.Models;

namespace Electrodevices.Views
{
    public partial class MainForm : Form
    {
        // коллекция данных
        private List<Electrodevice> _electrodevices;
        public MainForm() {
            InitializeComponent();

            _electrodevices = new List<Electrodevice>();
            InitializeElectrodevices();

            ElectrodevicesBind();
        } // MainForm
        private void Exit_Command(object sender, EventArgs e) => Application.Exit();

        // формирование коллекции приборов
        private void InitializeElectrodevices(int n = 11){
            _electrodevices.Clear();
            for (int i = 0; i < n; i++)
                _electrodevices.Add(Electrodevice.Generate());
        } // CreateElectrodevices

        // Выполнение привязки к данным для Листбокса
        private void ElectrodevicesBind(){
            LbxElectrodevices.DataSource = null;              // остановить текущую привязку
            LbxElectrodevices.DataSource = _electrodevices;   // источник данных - связанная со списком коллекция
            LbxElectrodevices.DisplayMember = "TableRow";     // отображаемое в списке свойство/атрибут
            LbxElectrodevices.ValueMember = "Name";           // поле, значение которого возвращет метод SelectedValue
        } // PersonsBind

        // удаление всех приборов
        private void Delete_Command(object sender, EventArgs e){
            _electrodevices.Clear();
            ElectrodevicesBind();
        } // Delete_Command

        // формирование коллекции приборов
        private void Initialize_Command(object sender, EventArgs e) {
            InitializeElectrodevices();
            ElectrodevicesBind();
        }// Initialize_Command

        // перемешивание элементов коллекции
        private void Shuffle_Command(object sender, EventArgs e){
            for (int i = _electrodevices.Count - 1; i >= 1; i--){
                int temp = Utils.Random.Next(i + 1);
                (_electrodevices[i], _electrodevices[temp]) = (_electrodevices[temp], _electrodevices[i]);
            } // for i

            ElectrodevicesBind();
        } // Shuffle_Command

        private void TurnOnAllDevices_Command(object sender, EventArgs e) {
            TurnOnOffAllDevices(true);
            ElectrodevicesBind();
        } // TurnOnAllDevices_Command


        private void TurnOffAllDevices_Command(object sender, EventArgs e) {
            TurnOnOffAllDevices(false);
            ElectrodevicesBind();
        } // TurnOffAllDevices_Command

        private void TurnOnOffAllDevices(bool state){
            foreach (var item in _electrodevices)
                item.State = state;
        } // TurnOnOffAllDevices

        private void TurnOnOffDevice_Command(object sender, EventArgs e) {
            int index = LbxElectrodevices.SelectedIndex;
            if (index < 0) return;
            _electrodevices[index].State = !_electrodevices[index].State;

            ElectrodevicesBind();
        } // TurnOnOffDevice_Command

        // удаление выбранного прибора
        private void RemoveSelectedDevice_Command(object sender, EventArgs e) {
            int index = LbxElectrodevices.SelectedIndex;

            if (index < 0) return;

            _electrodevices.RemoveAt(index);

            ElectrodevicesBind();

            if (index == _electrodevices.Count)
                LbxElectrodevices.SelectedIndex = _electrodevices.Count - 1;
        } // RemoveSelectedDevice_Command


        // сортировка по названию прибора
        private void OrderByName_Command(object sender, EventArgs e) {
            _electrodevices.Sort((x, y) => x.Name.CompareTo(y.Name));
            ElectrodevicesBind();
        } // OrderByName_Command

        private void OrderByPower_Command(object sender, EventArgs e) {
            _electrodevices.Sort((x, y) => x.Power.CompareTo(y.Power));
            ElectrodevicesBind();
        } // OrderByPower_Command

        // добавление прибора в коллекцию
        private void AddDevice_Command(object sender, EventArgs e) {

            string name = TbxName.Text;
            if (string.IsNullOrWhiteSpace(name)){
                ErpName.SetError(TbxName, "Некорректный ввод!");
                return;
            } // if

            _electrodevices.Insert(0, new Electrodevice { Name = name, Power = (int)NudPower.Value, Price = (int)NudPrice.Value, State = RbtON.Checked});
            ElectrodevicesBind();
        } // AddDevice_Command

        private void TbxName_TextChanged(object sender, EventArgs e) => ErpName.SetError(TbxName, "");

        // фильтрация нажатия клавиш "минус" - на основной и доп. цифровой клавиатуре 
        // если e.SuppressKeyPress установлен в true, то клавиша не доходит до элемента интерфейса 
        private void NudPower_KeyDown(object sender, KeyEventArgs e) =>
            e.SuppressKeyPress = e.KeyData == Keys.OemMinus || e.KeyData == Keys.Subtract;

        private void About_Command(object sender, EventArgs e) {
            FormAbout formAbout = new FormAbout();
            formAbout.ShowDialog();
        } // About_Command

        // удаление прибора из коллекции - по клавише Delete
        private void LbxElectrodevices_KeyDown(object sender, KeyEventArgs e) {
            if (e.KeyData != Keys.Delete) return;

            RemoveSelectedDevice_Command(sender, EventArgs.Empty);
        } // LbxElectrodevices_KeyDown
    }
}
