﻿
namespace Electrodevices.Views
{
    partial class MainForm
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.MainMenu = new System.Windows.Forms.MenuStrip();
            this.MniFile = new System.Windows.Forms.ToolStripMenuItem();
            this.MniExit = new System.Windows.Forms.ToolStripMenuItem();
            this.MniHelp = new System.Windows.Forms.ToolStripMenuItem();
            this.оПрограммеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.коллекцияПриборовToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.MniCreate = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem6 = new System.Windows.Forms.ToolStripSeparator();
            this.MniShuffle = new System.Windows.Forms.ToolStripMenuItem();
            this.MniOrderBy = new System.Windows.Forms.ToolStripMenuItem();
            this.MniByName = new System.Windows.Forms.ToolStripMenuItem();
            this.MniByPower = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem7 = new System.Windows.Forms.ToolStripSeparator();
            this.MniTurnOn = new System.Windows.Forms.ToolStripMenuItem();
            this.MniTurnOff = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem8 = new System.Windows.Forms.ToolStripSeparator();
            this.MniTurnOnOff = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem9 = new System.Windows.Forms.ToolStripSeparator();
            this.MniRemove = new System.Windows.Forms.ToolStripMenuItem();
            this.MniDelete = new System.Windows.Forms.ToolStripMenuItem();
            this.TsMain = new System.Windows.Forms.ToolStrip();
            this.TsbCreate = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.TsbShuffle = new System.Windows.Forms.ToolStripButton();
            this.TsmOrderBy = new System.Windows.Forms.ToolStripSplitButton();
            this.TsmName = new System.Windows.Forms.ToolStripMenuItem();
            this.TsmPower = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.TsbTurnOn = new System.Windows.Forms.ToolStripButton();
            this.TsbTurnOff = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.TsbTurnOnOff = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.TsbRemove = new System.Windows.Forms.ToolStripButton();
            this.TsmDelete = new System.Windows.Forms.ToolStripButton();
            this.LbxElectrodevices = new System.Windows.Forms.ListBox();
            this.CmsElectrodevices = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.CmiCreate = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripSeparator();
            this.CmiShuffle = new System.Windows.Forms.ToolStripMenuItem();
            this.CmiOrderBy = new System.Windows.Forms.ToolStripMenuItem();
            this.CmiByName = new System.Windows.Forms.ToolStripMenuItem();
            this.CmiByPower = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripSeparator();
            this.CmiTurnOn = new System.Windows.Forms.ToolStripMenuItem();
            this.CmiTurnOff = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem4 = new System.Windows.Forms.ToolStripSeparator();
            this.включитьвыключитьВыбранныйПриборToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem5 = new System.Windows.Forms.ToolStripSeparator();
            this.удалитьВыбранныйПриборToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.CmiDelete = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripSeparator();
            this.CmiExit = new System.Windows.Forms.ToolStripMenuItem();
            this.LblElectrodevices = new System.Windows.Forms.Label();
            this.GrbAddElectrodevice = new System.Windows.Forms.GroupBox();
            this.BntAdd = new System.Windows.Forms.Button();
            this.LblState = new System.Windows.Forms.Label();
            this.PnlState = new System.Windows.Forms.Panel();
            this.RbtON = new System.Windows.Forms.RadioButton();
            this.RbtOFF = new System.Windows.Forms.RadioButton();
            this.LblPrice = new System.Windows.Forms.Label();
            this.LblPower = new System.Windows.Forms.Label();
            this.LblName = new System.Windows.Forms.Label();
            this.NudPrice = new System.Windows.Forms.NumericUpDown();
            this.NudPower = new System.Windows.Forms.NumericUpDown();
            this.TbxName = new System.Windows.Forms.TextBox();
            this.ErpName = new System.Windows.Forms.ErrorProvider(this.components);
            this.CmsMain = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.оПрограммеToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem20 = new System.Windows.Forms.ToolStripMenuItem();
            this.CmiAbout = new System.Windows.Forms.ToolStripMenuItem();
            this.MainMenu.SuspendLayout();
            this.TsMain.SuspendLayout();
            this.CmsElectrodevices.SuspendLayout();
            this.GrbAddElectrodevice.SuspendLayout();
            this.PnlState.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.NudPrice)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NudPower)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ErpName)).BeginInit();
            this.CmsMain.SuspendLayout();
            this.SuspendLayout();
            // 
            // MainMenu
            // 
            this.MainMenu.BackColor = System.Drawing.SystemColors.MenuBar;
            this.MainMenu.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.MainMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniFile,
            this.MniHelp,
            this.коллекцияПриборовToolStripMenuItem});
            this.MainMenu.Location = new System.Drawing.Point(0, 0);
            this.MainMenu.Name = "MainMenu";
            this.MainMenu.Size = new System.Drawing.Size(883, 26);
            this.MainMenu.TabIndex = 0;
            this.MainMenu.Text = "menuStrip1";
            // 
            // MniFile
            // 
            this.MniFile.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniExit});
            this.MniFile.Name = "MniFile";
            this.MniFile.Size = new System.Drawing.Size(54, 22);
            this.MniFile.Text = "&Файл";
            // 
            // MniExit
            // 
            this.MniExit.Image = global::Electrodevices.Properties.Resources.exit;
            this.MniExit.Name = "MniExit";
            this.MniExit.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.F4)));
            this.MniExit.Size = new System.Drawing.Size(170, 22);
            this.MniExit.Text = "&Выход";
            this.MniExit.Click += new System.EventHandler(this.Exit_Command);
            // 
            // MniHelp
            // 
            this.MniHelp.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.MniHelp.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.оПрограммеToolStripMenuItem});
            this.MniHelp.Name = "MniHelp";
            this.MniHelp.Size = new System.Drawing.Size(76, 22);
            this.MniHelp.Text = "&Справка";
            // 
            // оПрограммеToolStripMenuItem
            // 
            this.оПрограммеToolStripMenuItem.Name = "оПрограммеToolStripMenuItem";
            this.оПрограммеToolStripMenuItem.Size = new System.Drawing.Size(181, 22);
            this.оПрограммеToolStripMenuItem.Text = "О п&рограмме...";
            this.оПрограммеToolStripMenuItem.Click += new System.EventHandler(this.About_Command);
            // 
            // коллекцияПриборовToolStripMenuItem
            // 
            this.коллекцияПриборовToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniCreate,
            this.toolStripMenuItem6,
            this.MniShuffle,
            this.MniOrderBy,
            this.toolStripMenuItem7,
            this.MniTurnOn,
            this.MniTurnOff,
            this.toolStripMenuItem8,
            this.MniTurnOnOff,
            this.toolStripMenuItem9,
            this.MniRemove,
            this.MniDelete});
            this.коллекцияПриборовToolStripMenuItem.Name = "коллекцияПриборовToolStripMenuItem";
            this.коллекцияПриборовToolStripMenuItem.Size = new System.Drawing.Size(162, 22);
            this.коллекцияПриборовToolStripMenuItem.Text = "&Коллекция приборов";
            // 
            // MniCreate
            // 
            this.MniCreate.Image = global::Electrodevices.Properties.Resources.Create;
            this.MniCreate.Name = "MniCreate";
            this.MniCreate.Size = new System.Drawing.Size(359, 22);
            this.MniCreate.Text = "&Сформировать коллекцию приборов";
            this.MniCreate.Click += new System.EventHandler(this.Initialize_Command);
            // 
            // toolStripMenuItem6
            // 
            this.toolStripMenuItem6.Name = "toolStripMenuItem6";
            this.toolStripMenuItem6.Size = new System.Drawing.Size(356, 6);
            // 
            // MniShuffle
            // 
            this.MniShuffle.Image = global::Electrodevices.Properties.Resources.shuffle;
            this.MniShuffle.Name = "MniShuffle";
            this.MniShuffle.Size = new System.Drawing.Size(359, 22);
            this.MniShuffle.Text = "&Перемешать элементы коллекции";
            this.MniShuffle.Click += new System.EventHandler(this.Shuffle_Command);
            // 
            // MniOrderBy
            // 
            this.MniOrderBy.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniByName,
            this.MniByPower});
            this.MniOrderBy.Image = global::Electrodevices.Properties.Resources.OrderBy;
            this.MniOrderBy.Name = "MniOrderBy";
            this.MniOrderBy.Size = new System.Drawing.Size(359, 22);
            this.MniOrderBy.Text = "&Отсортировать";
            // 
            // MniByName
            // 
            this.MniByName.Image = global::Electrodevices.Properties.Resources.name;
            this.MniByName.Name = "MniByName";
            this.MniByName.Size = new System.Drawing.Size(167, 22);
            this.MniByName.Text = "по &названию";
            this.MniByName.Click += new System.EventHandler(this.OrderByName_Command);
            // 
            // MniByPower
            // 
            this.MniByPower.Image = global::Electrodevices.Properties.Resources.power;
            this.MniByPower.Name = "MniByPower";
            this.MniByPower.Size = new System.Drawing.Size(167, 22);
            this.MniByPower.Text = "по мощности";
            this.MniByPower.Click += new System.EventHandler(this.OrderByPower_Command);
            // 
            // toolStripMenuItem7
            // 
            this.toolStripMenuItem7.Name = "toolStripMenuItem7";
            this.toolStripMenuItem7.Size = new System.Drawing.Size(356, 6);
            // 
            // MniTurnOn
            // 
            this.MniTurnOn.Image = global::Electrodevices.Properties.Resources.TurnON;
            this.MniTurnOn.Name = "MniTurnOn";
            this.MniTurnOn.Size = new System.Drawing.Size(359, 22);
            this.MniTurnOn.Text = "Включить все приборы";
            this.MniTurnOn.Click += new System.EventHandler(this.TurnOnAllDevices_Command);
            // 
            // MniTurnOff
            // 
            this.MniTurnOff.Image = global::Electrodevices.Properties.Resources.TurnOFF;
            this.MniTurnOff.Name = "MniTurnOff";
            this.MniTurnOff.Size = new System.Drawing.Size(359, 22);
            this.MniTurnOff.Text = "Выключить все приборы";
            this.MniTurnOff.Click += new System.EventHandler(this.TurnOffAllDevices_Command);
            // 
            // toolStripMenuItem8
            // 
            this.toolStripMenuItem8.Name = "toolStripMenuItem8";
            this.toolStripMenuItem8.Size = new System.Drawing.Size(356, 6);
            // 
            // MniTurnOnOff
            // 
            this.MniTurnOnOff.Image = global::Electrodevices.Properties.Resources.TurnOnOff;
            this.MniTurnOnOff.Name = "MniTurnOnOff";
            this.MniTurnOnOff.Size = new System.Drawing.Size(359, 22);
            this.MniTurnOnOff.Text = "Включить/выключить выбранный прибор";
            this.MniTurnOnOff.Click += new System.EventHandler(this.TurnOnOffDevice_Command);
            // 
            // toolStripMenuItem9
            // 
            this.toolStripMenuItem9.Name = "toolStripMenuItem9";
            this.toolStripMenuItem9.Size = new System.Drawing.Size(356, 6);
            // 
            // MniRemove
            // 
            this.MniRemove.Image = global::Electrodevices.Properties.Resources.remove;
            this.MniRemove.Name = "MniRemove";
            this.MniRemove.Size = new System.Drawing.Size(359, 22);
            this.MniRemove.Text = "Удалить выбранный прибор";
            this.MniRemove.Click += new System.EventHandler(this.RemoveSelectedDevice_Command);
            // 
            // MniDelete
            // 
            this.MniDelete.Image = global::Electrodevices.Properties.Resources.Delete;
            this.MniDelete.Name = "MniDelete";
            this.MniDelete.Size = new System.Drawing.Size(359, 22);
            this.MniDelete.Text = "Удалить все приборы";
            this.MniDelete.Click += new System.EventHandler(this.Delete_Command);
            // 
            // TsMain
            // 
            this.TsMain.BackColor = System.Drawing.SystemColors.ControlLight;
            this.TsMain.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TsMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.TsbCreate,
            this.toolStripSeparator1,
            this.TsbShuffle,
            this.TsmOrderBy,
            this.toolStripSeparator2,
            this.TsbTurnOn,
            this.TsbTurnOff,
            this.toolStripSeparator3,
            this.TsbTurnOnOff,
            this.toolStripSeparator4,
            this.TsbRemove,
            this.TsmDelete});
            this.TsMain.Location = new System.Drawing.Point(0, 26);
            this.TsMain.Name = "TsMain";
            this.TsMain.Size = new System.Drawing.Size(883, 37);
            this.TsMain.TabIndex = 1;
            this.TsMain.Text = "toolStrip1";
            // 
            // TsbCreate
            // 
            this.TsbCreate.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbCreate.Image = global::Electrodevices.Properties.Resources.Create;
            this.TsbCreate.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbCreate.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbCreate.Name = "TsbCreate";
            this.TsbCreate.Size = new System.Drawing.Size(34, 34);
            this.TsbCreate.Text = "toolStripButton1";
            this.TsbCreate.ToolTipText = "Сформировать коллекцию приборов";
            this.TsbCreate.Click += new System.EventHandler(this.Initialize_Command);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 37);
            // 
            // TsbShuffle
            // 
            this.TsbShuffle.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbShuffle.Image = global::Electrodevices.Properties.Resources.shuffle;
            this.TsbShuffle.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbShuffle.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbShuffle.Name = "TsbShuffle";
            this.TsbShuffle.Size = new System.Drawing.Size(34, 34);
            this.TsbShuffle.Text = "toolStripButton1";
            this.TsbShuffle.ToolTipText = "Перемешать элементы коллекции";
            this.TsbShuffle.Click += new System.EventHandler(this.Shuffle_Command);
            // 
            // TsmOrderBy
            // 
            this.TsmOrderBy.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsmOrderBy.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.TsmName,
            this.TsmPower});
            this.TsmOrderBy.Image = global::Electrodevices.Properties.Resources.OrderBy;
            this.TsmOrderBy.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsmOrderBy.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsmOrderBy.Name = "TsmOrderBy";
            this.TsmOrderBy.Size = new System.Drawing.Size(46, 34);
            this.TsmOrderBy.Text = "toolStripSplitButton1";
            this.TsmOrderBy.ToolTipText = "Отсортировать";
            this.TsmOrderBy.ButtonClick += new System.EventHandler(this.OrderByName_Command);
            // 
            // TsmName
            // 
            this.TsmName.Image = global::Electrodevices.Properties.Resources.name;
            this.TsmName.Name = "TsmName";
            this.TsmName.Size = new System.Drawing.Size(167, 22);
            this.TsmName.Text = "по названию";
            this.TsmName.Click += new System.EventHandler(this.OrderByName_Command);
            // 
            // TsmPower
            // 
            this.TsmPower.Image = global::Electrodevices.Properties.Resources.power;
            this.TsmPower.Name = "TsmPower";
            this.TsmPower.Size = new System.Drawing.Size(167, 22);
            this.TsmPower.Text = "по мощности";
            this.TsmPower.Click += new System.EventHandler(this.OrderByPower_Command);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 37);
            // 
            // TsbTurnOn
            // 
            this.TsbTurnOn.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbTurnOn.Image = global::Electrodevices.Properties.Resources.TurnON;
            this.TsbTurnOn.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbTurnOn.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbTurnOn.Name = "TsbTurnOn";
            this.TsbTurnOn.Size = new System.Drawing.Size(34, 34);
            this.TsbTurnOn.Text = "toolStripButton1";
            this.TsbTurnOn.ToolTipText = "Включить все приборы";
            this.TsbTurnOn.Click += new System.EventHandler(this.TurnOnAllDevices_Command);
            // 
            // TsbTurnOff
            // 
            this.TsbTurnOff.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbTurnOff.Image = global::Electrodevices.Properties.Resources.TurnOFF;
            this.TsbTurnOff.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbTurnOff.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbTurnOff.Name = "TsbTurnOff";
            this.TsbTurnOff.Size = new System.Drawing.Size(34, 34);
            this.TsbTurnOff.Text = "toolStripButton1";
            this.TsbTurnOff.ToolTipText = "Выключить все приборы";
            this.TsbTurnOff.Click += new System.EventHandler(this.TurnOffAllDevices_Command);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(6, 37);
            // 
            // TsbTurnOnOff
            // 
            this.TsbTurnOnOff.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbTurnOnOff.Image = global::Electrodevices.Properties.Resources.TurnOnOff;
            this.TsbTurnOnOff.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbTurnOnOff.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbTurnOnOff.Name = "TsbTurnOnOff";
            this.TsbTurnOnOff.Size = new System.Drawing.Size(34, 34);
            this.TsbTurnOnOff.Text = "toolStripButton1";
            this.TsbTurnOnOff.ToolTipText = "Включить/выключить выбранный прибор";
            this.TsbTurnOnOff.Click += new System.EventHandler(this.TurnOnOffDevice_Command);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(6, 37);
            // 
            // TsbRemove
            // 
            this.TsbRemove.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbRemove.Image = global::Electrodevices.Properties.Resources.remove;
            this.TsbRemove.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbRemove.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbRemove.Name = "TsbRemove";
            this.TsbRemove.Size = new System.Drawing.Size(34, 34);
            this.TsbRemove.Text = "toolStripButton1";
            this.TsbRemove.ToolTipText = "удалить выбранный прибор\r\n";
            this.TsbRemove.Click += new System.EventHandler(this.RemoveSelectedDevice_Command);
            // 
            // TsmDelete
            // 
            this.TsmDelete.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.TsmDelete.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsmDelete.Image = global::Electrodevices.Properties.Resources.Delete;
            this.TsmDelete.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsmDelete.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsmDelete.Name = "TsmDelete";
            this.TsmDelete.Size = new System.Drawing.Size(34, 34);
            this.TsmDelete.Text = "toolStripButton1";
            this.TsmDelete.ToolTipText = "удалить все приборы";
            this.TsmDelete.Click += new System.EventHandler(this.Delete_Command);
            // 
            // LbxElectrodevices
            // 
            this.LbxElectrodevices.ContextMenuStrip = this.CmsElectrodevices;
            this.LbxElectrodevices.Font = new System.Drawing.Font("Consolas", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LbxElectrodevices.FormattingEnabled = true;
            this.LbxElectrodevices.ItemHeight = 18;
            this.LbxElectrodevices.Location = new System.Drawing.Point(31, 105);
            this.LbxElectrodevices.Name = "LbxElectrodevices";
            this.LbxElectrodevices.Size = new System.Drawing.Size(469, 310);
            this.LbxElectrodevices.TabIndex = 2;
            this.LbxElectrodevices.KeyDown += new System.Windows.Forms.KeyEventHandler(this.LbxElectrodevices_KeyDown);
            // 
            // CmsElectrodevices
            // 
            this.CmsElectrodevices.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.CmiCreate,
            this.toolStripMenuItem2,
            this.CmiShuffle,
            this.CmiOrderBy,
            this.toolStripMenuItem3,
            this.CmiTurnOn,
            this.CmiTurnOff,
            this.toolStripMenuItem4,
            this.включитьвыключитьВыбранныйПриборToolStripMenuItem,
            this.toolStripMenuItem5,
            this.удалитьВыбранныйПриборToolStripMenuItem,
            this.CmiDelete,
            this.toolStripMenuItem1,
            this.CmiAbout,
            this.CmiExit});
            this.CmsElectrodevices.Name = "CmsElectrodevices";
            this.CmsElectrodevices.Size = new System.Drawing.Size(311, 254);
            // 
            // CmiCreate
            // 
            this.CmiCreate.Image = global::Electrodevices.Properties.Resources.Create;
            this.CmiCreate.Name = "CmiCreate";
            this.CmiCreate.Size = new System.Drawing.Size(310, 22);
            this.CmiCreate.Text = "Сформировать коллекцию приборов";
            this.CmiCreate.Click += new System.EventHandler(this.Initialize_Command);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(307, 6);
            // 
            // CmiShuffle
            // 
            this.CmiShuffle.Image = global::Electrodevices.Properties.Resources.shuffle;
            this.CmiShuffle.Name = "CmiShuffle";
            this.CmiShuffle.Size = new System.Drawing.Size(310, 22);
            this.CmiShuffle.Text = "Перемешать элементы коллекции";
            this.CmiShuffle.Click += new System.EventHandler(this.Shuffle_Command);
            // 
            // CmiOrderBy
            // 
            this.CmiOrderBy.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.CmiByName,
            this.CmiByPower});
            this.CmiOrderBy.Image = global::Electrodevices.Properties.Resources.OrderBy;
            this.CmiOrderBy.Name = "CmiOrderBy";
            this.CmiOrderBy.Size = new System.Drawing.Size(310, 22);
            this.CmiOrderBy.Text = "Отсортировать";
            // 
            // CmiByName
            // 
            this.CmiByName.Image = global::Electrodevices.Properties.Resources.name;
            this.CmiByName.Name = "CmiByName";
            this.CmiByName.Size = new System.Drawing.Size(150, 22);
            this.CmiByName.Text = "по названию";
            this.CmiByName.Click += new System.EventHandler(this.OrderByName_Command);
            // 
            // CmiByPower
            // 
            this.CmiByPower.Image = global::Electrodevices.Properties.Resources.power;
            this.CmiByPower.Name = "CmiByPower";
            this.CmiByPower.Size = new System.Drawing.Size(150, 22);
            this.CmiByPower.Text = "по мощности";
            this.CmiByPower.Click += new System.EventHandler(this.OrderByPower_Command);
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(307, 6);
            // 
            // CmiTurnOn
            // 
            this.CmiTurnOn.Image = global::Electrodevices.Properties.Resources.TurnON;
            this.CmiTurnOn.Name = "CmiTurnOn";
            this.CmiTurnOn.Size = new System.Drawing.Size(310, 22);
            this.CmiTurnOn.Text = "Включить все приборы";
            this.CmiTurnOn.Click += new System.EventHandler(this.TurnOnAllDevices_Command);
            // 
            // CmiTurnOff
            // 
            this.CmiTurnOff.Image = global::Electrodevices.Properties.Resources.TurnOFF;
            this.CmiTurnOff.Name = "CmiTurnOff";
            this.CmiTurnOff.Size = new System.Drawing.Size(310, 22);
            this.CmiTurnOff.Text = "Выключить все приборы";
            this.CmiTurnOff.Click += new System.EventHandler(this.TurnOffAllDevices_Command);
            // 
            // toolStripMenuItem4
            // 
            this.toolStripMenuItem4.Name = "toolStripMenuItem4";
            this.toolStripMenuItem4.Size = new System.Drawing.Size(307, 6);
            // 
            // включитьвыключитьВыбранныйПриборToolStripMenuItem
            // 
            this.включитьвыключитьВыбранныйПриборToolStripMenuItem.Image = global::Electrodevices.Properties.Resources.TurnOnOff;
            this.включитьвыключитьВыбранныйПриборToolStripMenuItem.Name = "включитьвыключитьВыбранныйПриборToolStripMenuItem";
            this.включитьвыключитьВыбранныйПриборToolStripMenuItem.Size = new System.Drawing.Size(310, 22);
            this.включитьвыключитьВыбранныйПриборToolStripMenuItem.Text = "Включить/выключить выбранный прибор";
            this.включитьвыключитьВыбранныйПриборToolStripMenuItem.Click += new System.EventHandler(this.TurnOnOffDevice_Command);
            // 
            // toolStripMenuItem5
            // 
            this.toolStripMenuItem5.Name = "toolStripMenuItem5";
            this.toolStripMenuItem5.Size = new System.Drawing.Size(307, 6);
            // 
            // удалитьВыбранныйПриборToolStripMenuItem
            // 
            this.удалитьВыбранныйПриборToolStripMenuItem.Image = global::Electrodevices.Properties.Resources.remove;
            this.удалитьВыбранныйПриборToolStripMenuItem.Name = "удалитьВыбранныйПриборToolStripMenuItem";
            this.удалитьВыбранныйПриборToolStripMenuItem.Size = new System.Drawing.Size(310, 22);
            this.удалитьВыбранныйПриборToolStripMenuItem.Text = "удалить выбранный прибор";
            this.удалитьВыбранныйПриборToolStripMenuItem.Click += new System.EventHandler(this.RemoveSelectedDevice_Command);
            // 
            // CmiDelete
            // 
            this.CmiDelete.Image = global::Electrodevices.Properties.Resources.Delete;
            this.CmiDelete.Name = "CmiDelete";
            this.CmiDelete.Size = new System.Drawing.Size(310, 22);
            this.CmiDelete.Text = "удалить все приборы";
            this.CmiDelete.Click += new System.EventHandler(this.Delete_Command);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(307, 6);
            // 
            // CmiExit
            // 
            this.CmiExit.Image = global::Electrodevices.Properties.Resources.exit;
            this.CmiExit.Name = "CmiExit";
            this.CmiExit.Size = new System.Drawing.Size(310, 22);
            this.CmiExit.Text = "Выход";
            this.CmiExit.Click += new System.EventHandler(this.Exit_Command);
            // 
            // LblElectrodevices
            // 
            this.LblElectrodevices.BackColor = System.Drawing.SystemColors.Control;
            this.LblElectrodevices.Font = new System.Drawing.Font("Consolas", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblElectrodevices.Location = new System.Drawing.Point(31, 68);
            this.LblElectrodevices.Name = "LblElectrodevices";
            this.LblElectrodevices.Size = new System.Drawing.Size(482, 42);
            this.LblElectrodevices.TabIndex = 3;
            this.LblElectrodevices.Text = "Коллекция приборов:\r\n│       Название       │ Мощность │   Цена   │ Состояние │";
            // 
            // GrbAddElectrodevice
            // 
            this.GrbAddElectrodevice.Controls.Add(this.BntAdd);
            this.GrbAddElectrodevice.Controls.Add(this.LblState);
            this.GrbAddElectrodevice.Controls.Add(this.PnlState);
            this.GrbAddElectrodevice.Controls.Add(this.LblPrice);
            this.GrbAddElectrodevice.Controls.Add(this.LblPower);
            this.GrbAddElectrodevice.Controls.Add(this.LblName);
            this.GrbAddElectrodevice.Controls.Add(this.NudPrice);
            this.GrbAddElectrodevice.Controls.Add(this.NudPower);
            this.GrbAddElectrodevice.Controls.Add(this.TbxName);
            this.GrbAddElectrodevice.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.GrbAddElectrodevice.Location = new System.Drawing.Point(574, 96);
            this.GrbAddElectrodevice.Name = "GrbAddElectrodevice";
            this.GrbAddElectrodevice.Size = new System.Drawing.Size(267, 319);
            this.GrbAddElectrodevice.TabIndex = 4;
            this.GrbAddElectrodevice.TabStop = false;
            this.GrbAddElectrodevice.Text = " Добавление прибора: ";
            // 
            // BntAdd
            // 
            this.BntAdd.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.BntAdd.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.BntAdd.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BntAdd.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.BntAdd.Location = new System.Drawing.Point(45, 255);
            this.BntAdd.Name = "BntAdd";
            this.BntAdd.Size = new System.Drawing.Size(182, 39);
            this.BntAdd.TabIndex = 8;
            this.BntAdd.Text = "Добавить прибор";
            this.BntAdd.UseVisualStyleBackColor = false;
            this.BntAdd.Click += new System.EventHandler(this.AddDevice_Command);
            // 
            // LblState
            // 
            this.LblState.AutoSize = true;
            this.LblState.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblState.Location = new System.Drawing.Point(17, 210);
            this.LblState.Name = "LblState";
            this.LblState.Size = new System.Drawing.Size(93, 18);
            this.LblState.TabIndex = 7;
            this.LblState.Text = "Сосотояние:";
            // 
            // PnlState
            // 
            this.PnlState.Controls.Add(this.RbtON);
            this.PnlState.Controls.Add(this.RbtOFF);
            this.PnlState.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.PnlState.Location = new System.Drawing.Point(115, 203);
            this.PnlState.Name = "PnlState";
            this.PnlState.Size = new System.Drawing.Size(135, 31);
            this.PnlState.TabIndex = 6;
            // 
            // RbtON
            // 
            this.RbtON.AutoSize = true;
            this.RbtON.Checked = true;
            this.RbtON.Location = new System.Drawing.Point(13, 5);
            this.RbtON.Name = "RbtON";
            this.RbtON.Size = new System.Drawing.Size(47, 22);
            this.RbtON.TabIndex = 0;
            this.RbtON.TabStop = true;
            this.RbtON.Text = "ON";
            this.RbtON.UseVisualStyleBackColor = true;
            // 
            // RbtOFF
            // 
            this.RbtOFF.AutoSize = true;
            this.RbtOFF.Location = new System.Drawing.Point(79, 5);
            this.RbtOFF.Name = "RbtOFF";
            this.RbtOFF.Size = new System.Drawing.Size(53, 22);
            this.RbtOFF.TabIndex = 1;
            this.RbtOFF.TabStop = true;
            this.RbtOFF.Text = "OFF";
            this.RbtOFF.UseVisualStyleBackColor = true;
            // 
            // LblPrice
            // 
            this.LblPrice.AutoSize = true;
            this.LblPrice.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblPrice.Location = new System.Drawing.Point(17, 158);
            this.LblPrice.Name = "LblPrice";
            this.LblPrice.Size = new System.Drawing.Size(47, 18);
            this.LblPrice.TabIndex = 5;
            this.LblPrice.Text = "Цена:";
            // 
            // LblPower
            // 
            this.LblPower.AutoSize = true;
            this.LblPower.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblPower.Location = new System.Drawing.Point(17, 106);
            this.LblPower.Name = "LblPower";
            this.LblPower.Size = new System.Drawing.Size(85, 18);
            this.LblPower.TabIndex = 4;
            this.LblPower.Text = "Мощность:";
            // 
            // LblName
            // 
            this.LblName.AutoSize = true;
            this.LblName.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblName.Location = new System.Drawing.Point(17, 54);
            this.LblName.Name = "LblName";
            this.LblName.Size = new System.Drawing.Size(78, 18);
            this.LblName.TabIndex = 3;
            this.LblName.Text = "Название:";
            // 
            // NudPrice
            // 
            this.NudPrice.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.NudPrice.Location = new System.Drawing.Point(124, 154);
            this.NudPrice.Maximum = new decimal(new int[] {
            1874919424,
            2328306,
            0,
            0});
            this.NudPrice.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.NudPrice.Name = "NudPrice";
            this.NudPrice.Size = new System.Drawing.Size(120, 26);
            this.NudPrice.TabIndex = 2;
            this.NudPrice.ThousandsSeparator = true;
            this.NudPrice.Value = new decimal(new int[] {
            2100,
            0,
            0,
            0});
            this.NudPrice.KeyDown += new System.Windows.Forms.KeyEventHandler(this.NudPower_KeyDown);
            // 
            // NudPower
            // 
            this.NudPower.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.NudPower.Location = new System.Drawing.Point(124, 102);
            this.NudPower.Maximum = new decimal(new int[] {
            1874919424,
            2328306,
            0,
            0});
            this.NudPower.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.NudPower.Name = "NudPower";
            this.NudPower.Size = new System.Drawing.Size(120, 26);
            this.NudPower.TabIndex = 1;
            this.NudPower.ThousandsSeparator = true;
            this.NudPower.Value = new decimal(new int[] {
            1200,
            0,
            0,
            0});
            this.NudPower.KeyDown += new System.Windows.Forms.KeyEventHandler(this.NudPower_KeyDown);
            // 
            // TbxName
            // 
            this.TbxName.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TbxName.Location = new System.Drawing.Point(124, 50);
            this.TbxName.Name = "TbxName";
            this.TbxName.Size = new System.Drawing.Size(120, 26);
            this.TbxName.TabIndex = 0;
            this.TbxName.Text = "чайник";
            this.TbxName.TextChanged += new System.EventHandler(this.TbxName_TextChanged);
            // 
            // ErpName
            // 
            this.ErpName.ContainerControl = this;
            // 
            // CmsMain
            // 
            this.CmsMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.оПрограммеToolStripMenuItem1,
            this.toolStripMenuItem20});
            this.CmsMain.Name = "CmsElectrodevices";
            this.CmsMain.Size = new System.Drawing.Size(159, 48);
            // 
            // оПрограммеToolStripMenuItem1
            // 
            this.оПрограммеToolStripMenuItem1.Name = "оПрограммеToolStripMenuItem1";
            this.оПрограммеToolStripMenuItem1.Size = new System.Drawing.Size(180, 22);
            this.оПрограммеToolStripMenuItem1.Text = "О программе...";
            this.оПрограммеToolStripMenuItem1.Click += new System.EventHandler(this.About_Command);
            // 
            // toolStripMenuItem20
            // 
            this.toolStripMenuItem20.Image = global::Electrodevices.Properties.Resources.exit;
            this.toolStripMenuItem20.Name = "toolStripMenuItem20";
            this.toolStripMenuItem20.Size = new System.Drawing.Size(158, 22);
            this.toolStripMenuItem20.Text = "Выход";
            this.toolStripMenuItem20.Click += new System.EventHandler(this.Exit_Command);
            // 
            // CmiAbout
            // 
            this.CmiAbout.Name = "CmiAbout";
            this.CmiAbout.Size = new System.Drawing.Size(310, 22);
            this.CmiAbout.Text = "О программе...";
            this.CmiAbout.Click += new System.EventHandler(this.About_Command);
            // 
            // MainForm
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.SystemColors.Menu;
            this.ClientSize = new System.Drawing.Size(883, 457);
            this.ContextMenuStrip = this.CmsMain;
            this.Controls.Add(this.GrbAddElectrodevice);
            this.Controls.Add(this.LbxElectrodevices);
            this.Controls.Add(this.LblElectrodevices);
            this.Controls.Add(this.TsMain);
            this.Controls.Add(this.MainMenu);
            this.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.KeyPreview = true;
            this.MainMenuStrip = this.MainMenu;
            this.MaximizeBox = false;
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Задание на 10.11.2021";
            this.MainMenu.ResumeLayout(false);
            this.MainMenu.PerformLayout();
            this.TsMain.ResumeLayout(false);
            this.TsMain.PerformLayout();
            this.CmsElectrodevices.ResumeLayout(false);
            this.GrbAddElectrodevice.ResumeLayout(false);
            this.GrbAddElectrodevice.PerformLayout();
            this.PnlState.ResumeLayout(false);
            this.PnlState.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.NudPrice)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NudPower)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ErpName)).EndInit();
            this.CmsMain.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip MainMenu;
        private System.Windows.Forms.ToolStripMenuItem MniFile;
        private System.Windows.Forms.ToolStripMenuItem MniExit;
        private System.Windows.Forms.ToolStrip TsMain;
        private System.Windows.Forms.ToolStripButton TsbCreate;
        private System.Windows.Forms.ToolStripButton TsbShuffle;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripSplitButton TsmOrderBy;
        private System.Windows.Forms.ToolStripMenuItem TsmName;
        private System.Windows.Forms.ToolStripMenuItem TsmPower;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripButton TsbTurnOn;
        private System.Windows.Forms.ToolStripButton TsbTurnOff;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripButton TsbTurnOnOff;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripButton TsbRemove;
        private System.Windows.Forms.ToolStripButton TsmDelete;
        private System.Windows.Forms.ToolStripMenuItem MniHelp;
        private System.Windows.Forms.ToolStripMenuItem оПрограммеToolStripMenuItem;
        private System.Windows.Forms.ListBox LbxElectrodevices;
        private System.Windows.Forms.Label LblElectrodevices;
        private System.Windows.Forms.GroupBox GrbAddElectrodevice;
        private System.Windows.Forms.NumericUpDown NudPrice;
        private System.Windows.Forms.NumericUpDown NudPower;
        private System.Windows.Forms.TextBox TbxName;
        private System.Windows.Forms.Label LblName;
        private System.Windows.Forms.Button BntAdd;
        private System.Windows.Forms.Label LblState;
        private System.Windows.Forms.Panel PnlState;
        private System.Windows.Forms.RadioButton RbtON;
        private System.Windows.Forms.RadioButton RbtOFF;
        private System.Windows.Forms.Label LblPrice;
        private System.Windows.Forms.Label LblPower;
        private System.Windows.Forms.ContextMenuStrip CmsElectrodevices;
        private System.Windows.Forms.ToolStripMenuItem CmiCreate;
        private System.Windows.Forms.ToolStripMenuItem CmiShuffle;
        private System.Windows.Forms.ToolStripMenuItem CmiOrderBy;
        private System.Windows.Forms.ToolStripMenuItem CmiByName;
        private System.Windows.Forms.ToolStripMenuItem CmiByPower;
        private System.Windows.Forms.ToolStripMenuItem CmiTurnOn;
        private System.Windows.Forms.ToolStripMenuItem CmiTurnOff;
        private System.Windows.Forms.ToolStripMenuItem включитьвыключитьВыбранныйПриборToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem2;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem3;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem4;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem5;
        private System.Windows.Forms.ToolStripMenuItem удалитьВыбранныйПриборToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem CmiExit;
        private System.Windows.Forms.ToolStripMenuItem CmiDelete;
        private System.Windows.Forms.ToolStripMenuItem коллекцияПриборовToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem MniCreate;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem6;
        private System.Windows.Forms.ToolStripMenuItem MniShuffle;
        private System.Windows.Forms.ToolStripMenuItem MniOrderBy;
        private System.Windows.Forms.ToolStripMenuItem MniByName;
        private System.Windows.Forms.ToolStripMenuItem MniByPower;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem7;
        private System.Windows.Forms.ToolStripMenuItem MniTurnOn;
        private System.Windows.Forms.ToolStripMenuItem MniTurnOff;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem8;
        private System.Windows.Forms.ToolStripMenuItem MniTurnOnOff;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem9;
        private System.Windows.Forms.ToolStripMenuItem MniRemove;
        private System.Windows.Forms.ToolStripMenuItem MniDelete;
        private System.Windows.Forms.ErrorProvider ErpName;
        private System.Windows.Forms.ContextMenuStrip CmsMain;
        private System.Windows.Forms.ToolStripMenuItem оПрограммеToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem20;
        private System.Windows.Forms.ToolStripMenuItem CmiAbout;
    }
}

