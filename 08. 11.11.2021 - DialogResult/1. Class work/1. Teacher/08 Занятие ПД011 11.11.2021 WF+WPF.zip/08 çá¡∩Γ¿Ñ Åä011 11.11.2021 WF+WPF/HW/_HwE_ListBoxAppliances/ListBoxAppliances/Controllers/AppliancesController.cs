﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ListBoxAppliances.Helpers;
using ListBoxAppliances.Models;

namespace ListBoxAppliances.Controllers
{
    // Обработка коллекции приборов по заданию
    // Обработки:
    //     • Формирование коллекции приборов
    //     • перемешивание элементов коллекции
    //     • сортировка по названию прибора
    //     • сортировка по мощности прибора
    //     • включение всех приборов, всем приборам установить состояние
    //       «включено»
    //     • выключение всех приборов, всем приборам установить состояние
    //       «выключено»
    //     • включение выбранного прибора
    //     • выключение выбранного прибора
    //     • удаление выбранного прибора
    //     • удаление всех приборов
    public class AppliancesController
    {
        // ссылка на коллекцию приборов
        private List<Appliance> _appliances;
        public List<Appliance> Appliances => _appliances;

        // конструкторы для получения коллекции приборов
        public AppliancesController() : this(new List<Appliance>()) {
            // создание коллекции приборов, количество по заданию 
            Generate(Utils.GetRandom(10, 12));
        } // AppliancesController

        public AppliancesController(List<Appliance> appliances) {
            _appliances = appliances;
        } // AppliancesController

        // количестово приборов в коллекции
        public int Count => _appliances.Count;


        // формирование заданного количества приборов в коллекции
        public void Generate(int n) {
            _appliances.Clear();

            for (int i = 0; i < n; i++)
                _appliances.Add(Appliance.Generate());
        } // Generate


        // перемешивание элементов коллекции
        public void Shuffle() {
            for (int i = _appliances.Count - 1; i >= 0; i--) {
                int j = Utils.GetRandom(0, i);
                (_appliances[i], _appliances[j]) = (_appliances[j], _appliances[i]);
            } // for i
        } // Shuffle


        // сортировка по названию прибора
        public void OrderbyName() => 
            _appliances.Sort((a1, a2) => a1.Name.CompareTo(a2.Name));


        // сортировка по мощности прибора
        public void OrderbyPower() =>
            _appliances.Sort((a1, a2) => a1.Power.CompareTo(a2.Power));


        // включение всех приборов, всем приборам установить состояние
        // «включено»
        public void TurnOnAll() =>
            _appliances.ForEach(a => a.State = true);


        // выключение всех приборов, всем приборам установить состояние
        // «выключено»
        public void TurnOffAll() =>
            _appliances.ForEach(a => a.State = false);


        // включение выбранного прибора
        public void TurnOnAt(int index) => _appliances[index].State = true;


        // выключение выбранного прибора
        public void TurnOffAt(int index) => _appliances[index].State = false; 
        

        // удаление выбранного прибора
        public void RemoveAt(int index) => _appliances.RemoveAt(index);
        

        // удаление всех приборов
        public void RemoveAll() => _appliances.Clear();

        // добавление прибора в коллекцию
        public void AddAppliance(Appliance appliance)  => _appliances.Add(appliance);
    } // class AppliancesController
}
