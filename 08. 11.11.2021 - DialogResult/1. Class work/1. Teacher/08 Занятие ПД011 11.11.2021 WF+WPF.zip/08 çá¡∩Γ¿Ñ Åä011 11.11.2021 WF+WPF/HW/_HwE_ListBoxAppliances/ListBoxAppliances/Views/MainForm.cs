﻿using System;
using System.Windows.Forms;
using ListBoxAppliances.Controllers;
using ListBoxAppliances.Helpers;
using ListBoxAppliances.Models;

namespace ListBoxAppliances.Views
{
    public partial class MainForm : Form
    {
        // контроллер для работы с коллекцией приборов
        private AppliancesController _appliancesController;

        /// <summary>
        /// Конструкторы формы, с возможностью внедрения зависимостей
        /// </summary>
        public MainForm():this(new AppliancesController()) { } // MainForm

        public MainForm(AppliancesController appliancesController) {
            InitializeComponent();

            _appliancesController = appliancesController;

            // привязка ListBox к коллекции
            BindCollection();
        } // MainForm


        // выполнение привязки коллекции
        private void BindCollection() {
            // остановить привязку
            LbxAppliances.DataSource = null;

            // задать привязку
            LbxAppliances.DataSource = _appliancesController.Appliances;
            
            LbxAppliances.DisplayMember = "TableRow";
        } // BindCollection


        // выполняется после конструктора формы
        private void MainForm_Load(object sender, EventArgs e) {
            // вывод в строку состояния
            StlMain.Text = $"Сформировано приборов: {_appliancesController.Appliances.Count}";

            // начальлный выбор в комбо-боксах
            CbxApplianceNames.SelectedIndex = 0;
            CbxApplianceState.SelectedIndex = 0;
        } // MainForm_Load


        // команда заверешния работы приложения
        private void Exit_Command(object sender, EventArgs e) => Application.Exit();


        // команда отображения окна сведений о программе
        private void About_Command(object sender, EventArgs e) {
            AboutForm aboutForm = new AboutForm();
            aboutForm.ShowDialog();
        } // About_Command


        // формирование новой коллекции
        private void NewCollection_Command(object sender, EventArgs e) {
            _appliancesController.Generate(Utils.GetRandom(10, 12));

            BindCollection();

            // обновить строку состояния
            StlMain.Text = $"Коллекция приборов сформирована. Текущее количество приборов: {_appliancesController.Count}";
        } // NewCollection_Command


        // перемешивание приборов в коллекции 
        private void Shuffle_Command(object sender, EventArgs e) {
            _appliancesController.Shuffle();
            
            BindCollection();

            // обновить строку состояния
            StlMain.Text = $"Коллекция приборов перемешана. Текущее количество приборов: {_appliancesController.Count}";
        } // Shuffle_Command


        // сортировка коллекции приборов по наименованию
        private void OrderByName_Command(object sender, EventArgs e) {
            _appliancesController.OrderbyName();

            BindCollection();

            // обновить строку состояния
            StlMain.Text = $"Коллекция приборов упорядочена по наименованию. Текущее количество приборов: {_appliancesController.Count}";
        } // OrderByName_Command


        // сортировка коллекции приборов по мощности
        private void OrderByPower_Command(object sender, EventArgs e)
        {
            _appliancesController.OrderbyPower();

            BindCollection();

            // обновить строку состояния
            StlMain.Text = $"Коллекция приборов упорядочена по мощности. Текущее количество приборов: {_appliancesController.Count}";
        } // OrderByPower_Command


        // Включить выбранный прибор
        private void TurnOnAt_Command(object sender, EventArgs e)
        {
            // если нет выбранного прибора, то ничего не делать
            if (LbxAppliances.SelectedIndex == -1) return;

            // включить выбранный прибор
            _appliancesController.TurnOnAt(LbxAppliances.SelectedIndex);

            BindCollection();

            // обновить строку состояния
            StlMain.Text = $"Прибор включен. Текущее количество приборов: {_appliancesController.Count}";
        } // TurnOnAt_Command


        // Включить все приборы
        private void TurnOnAll_Command(object sender, EventArgs e) {
            _appliancesController.TurnOnAll();

            BindCollection();

            // обновить строку состояния
            StlMain.Text = $"Все приборы включены. Текущее количество приборов: {_appliancesController.Count}";
        } // TurnOnAll_Command


        // Выключить выбранный прибор
        private void TurnOffAt_Command(object sender, EventArgs e) {
            // если нет выбранного прибора, то ничего не делать
            if (LbxAppliances.SelectedIndex == -1) return;
            
            // выключить выбранный прибор
            _appliancesController.TurnOffAt(LbxAppliances.SelectedIndex);

            BindCollection();

            // обновить строку состояния
            StlMain.Text = $"Прибор выключен. Текущее количество приборов: {_appliancesController.Count}";
        } // TurnOffAt_Command


        // Выключить все приборы
        private void TurnOffAll_Command(object sender, EventArgs e) {
            _appliancesController.TurnOffAll();

            BindCollection();

            // обновить строку состояния
            StlMain.Text = $"Все приборы выключены. Текущее количество приборов: {_appliancesController.Count}";
        } // TurnOffAll_Command


        // Добавить прибор в коллекцию по клику на кнопке формы "Добавить прибор"
        private void AddAppliance_Command(object sender, EventArgs e)
        {
            try {
                // собрать прибор из данных формы
                Appliance appliance = new Appliance {
                    Name = CbxApplianceNames.Text,
                    Power = (int) NudPower.Value,
                    Price = (int) NudPrice.Value,
                    State = CbxApplianceState.Text == CbxApplianceState.Items[0].ToString()
                };

                // добавить прибор в коллекцию
                _appliancesController.AddAppliance(appliance);

                // обновить привязку
                BindCollection();

                // обновить строку состояния
                StlMain.Text = $"Прибор добавлен. Текущее количество приборов: {_appliancesController.Count}";
            } catch (Exception ex) {
                MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            } // try-catch
        } // AddAppliance_Command


        // удаление выбранного прибора из коллекции
        private void RemoveAt_Command(object sender, EventArgs e) {
            // если нет выбранного прибора, то ничего не делать
            if (LbxAppliances.SelectedIndex == -1) return;

            // удалить выбранный прибор
            _appliancesController.RemoveAt(LbxAppliances.SelectedIndex);

            // обновить привязку
            BindCollection();

            // обновить строку состояния
            StlMain.Text = $"Прибор удален. Текущее количество приборов: {_appliancesController.Count}";
        } // RemoveAt_Command

        // удаление всех приборов из коллекции
        private void RemoveAll_Command(object sender, EventArgs e) {
            // удалить все приборы
            _appliancesController.RemoveAll();

            // обновить привязку
            BindCollection();

            // обновить строку состояния
            StlMain.Text = $"Все приборы удалены. Текущее количество приборов: {_appliancesController.Count}";
        } // RemoveAt_Command
    } // class MainForm
}
