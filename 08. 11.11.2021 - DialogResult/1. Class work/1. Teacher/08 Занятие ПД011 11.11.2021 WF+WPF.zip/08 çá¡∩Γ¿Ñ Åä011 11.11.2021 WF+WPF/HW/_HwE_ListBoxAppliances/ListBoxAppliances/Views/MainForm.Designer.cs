﻿namespace ListBoxAppliances.Views
{
    partial class MainForm
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.MnuMain = new System.Windows.Forms.MenuStrip();
            this.файлToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.MniFileExit = new System.Windows.Forms.ToolStripMenuItem();
            this.MniEdit = new System.Windows.Forms.ToolStripMenuItem();
            this.MniEditNewCollection = new System.Windows.Forms.ToolStripMenuItem();
            this.MniEditShuffle = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripSeparator();
            this.MniRemoveAt = new System.Windows.Forms.ToolStripMenuItem();
            this.MniRemoveAll = new System.Windows.Forms.ToolStripMenuItem();
            this.MniOrder = new System.Windows.Forms.ToolStripMenuItem();
            this.MniOrderByName = new System.Windows.Forms.ToolStripMenuItem();
            this.MniOrderByPower = new System.Windows.Forms.ToolStripMenuItem();
            this.MniTurnOn = new System.Windows.Forms.ToolStripMenuItem();
            this.MniTurnOnAt = new System.Windows.Forms.ToolStripMenuItem();
            this.MniTurnOnAll = new System.Windows.Forms.ToolStripMenuItem();
            this.MniTurnOff = new System.Windows.Forms.ToolStripMenuItem();
            this.MniTurnOffAt = new System.Windows.Forms.ToolStripMenuItem();
            this.MniTurnOffAll = new System.Windows.Forms.ToolStripMenuItem();
            this.MniHelp = new System.Windows.Forms.ToolStripMenuItem();
            this.MniHelpAbout = new System.Windows.Forms.ToolStripMenuItem();
            this.TsbMain = new System.Windows.Forms.ToolStrip();
            this.toolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton2 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton11 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton10 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton3 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton4 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton5 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton7 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton6 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton8 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton9 = new System.Windows.Forms.ToolStripButton();
            this.TsbExit = new System.Windows.Forms.ToolStripButton();
            this.StsMain = new System.Windows.Forms.StatusStrip();
            this.StlMain = new System.Windows.Forms.ToolStripStatusLabel();
            this.LblAppliances = new System.Windows.Forms.Label();
            this.LbxAppliances = new System.Windows.Forms.ListBox();
            this.CmnAppliances = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.правкаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.новаяКоллекцияToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.перемешатьКоллекциюToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.сортировкаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.поНаименованиюToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.поМощностиToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripSeparator();
            this.оПрограммеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripSeparator();
            this.выходToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.GbxAppliance = new System.Windows.Forms.GroupBox();
            this.BtnOk = new System.Windows.Forms.Button();
            this.CbxApplianceState = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.NudPrice = new System.Windows.Forms.NumericUpDown();
            this.label2 = new System.Windows.Forms.Label();
            this.NudPower = new System.Windows.Forms.NumericUpDown();
            this.LblPower = new System.Windows.Forms.Label();
            this.CbxApplianceNames = new System.Windows.Forms.ComboBox();
            this.LblApplianceName = new System.Windows.Forms.Label();
            this.CmnForm = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.toolStripMenuItem9 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator6 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripMenuItem10 = new System.Windows.Forms.ToolStripMenuItem();
            this.включениеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.выключениеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem4 = new System.Windows.Forms.ToolStripSeparator();
            this.удалитьПриборToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.удалитьВсеПриборыToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.включитьВыбранныйToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.включитьВсеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.выключитьВыбранныйToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.выключитьВсеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.MnuMain.SuspendLayout();
            this.TsbMain.SuspendLayout();
            this.StsMain.SuspendLayout();
            this.CmnAppliances.SuspendLayout();
            this.GbxAppliance.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.NudPrice)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NudPower)).BeginInit();
            this.CmnForm.SuspendLayout();
            this.SuspendLayout();
            // 
            // MnuMain
            // 
            this.MnuMain.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.MnuMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.файлToolStripMenuItem,
            this.MniEdit,
            this.MniOrder,
            this.MniTurnOn,
            this.MniTurnOff,
            this.MniHelp});
            this.MnuMain.Location = new System.Drawing.Point(0, 0);
            this.MnuMain.Margin = new System.Windows.Forms.Padding(5, 0, 0, 5);
            this.MnuMain.Name = "MnuMain";
            this.MnuMain.Size = new System.Drawing.Size(1084, 28);
            this.MnuMain.TabIndex = 0;
            this.MnuMain.Text = "menuStrip1";
            // 
            // файлToolStripMenuItem
            // 
            this.файлToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniFileExit});
            this.файлToolStripMenuItem.Name = "файлToolStripMenuItem";
            this.файлToolStripMenuItem.Size = new System.Drawing.Size(57, 24);
            this.файлToolStripMenuItem.Text = "Файл";
            // 
            // MniFileExit
            // 
            this.MniFileExit.Image = global::ListBoxAppliances.Properties.Resources.door_out;
            this.MniFileExit.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MniFileExit.Name = "MniFileExit";
            this.MniFileExit.Size = new System.Drawing.Size(138, 38);
            this.MniFileExit.Text = "Выход";
            this.MniFileExit.Click += new System.EventHandler(this.Exit_Command);
            // 
            // MniEdit
            // 
            this.MniEdit.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniEditNewCollection,
            this.MniEditShuffle,
            this.toolStripMenuItem3,
            this.MniRemoveAt,
            this.MniRemoveAll});
            this.MniEdit.Name = "MniEdit";
            this.MniEdit.Size = new System.Drawing.Size(72, 24);
            this.MniEdit.Text = "Правка";
            // 
            // MniEditNewCollection
            // 
            this.MniEditNewCollection.Image = global::ListBoxAppliances.Properties.Resources._new;
            this.MniEditNewCollection.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MniEditNewCollection.Name = "MniEditNewCollection";
            this.MniEditNewCollection.Size = new System.Drawing.Size(246, 38);
            this.MniEditNewCollection.Text = "Новая коллекция";
            this.MniEditNewCollection.Click += new System.EventHandler(this.NewCollection_Command);
            // 
            // MniEditShuffle
            // 
            this.MniEditShuffle.Image = global::ListBoxAppliances.Properties.Resources.mixx;
            this.MniEditShuffle.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MniEditShuffle.Name = "MniEditShuffle";
            this.MniEditShuffle.Size = new System.Drawing.Size(246, 38);
            this.MniEditShuffle.Text = "Перемешать";
            this.MniEditShuffle.Click += new System.EventHandler(this.Shuffle_Command);
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(243, 6);
            // 
            // MniRemoveAt
            // 
            this.MniRemoveAt.Image = global::ListBoxAppliances.Properties.Resources.delete;
            this.MniRemoveAt.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MniRemoveAt.Name = "MniRemoveAt";
            this.MniRemoveAt.Size = new System.Drawing.Size(246, 38);
            this.MniRemoveAt.Text = "Удалить прибор";
            this.MniRemoveAt.Click += new System.EventHandler(this.RemoveAt_Command);
            // 
            // MniRemoveAll
            // 
            this.MniRemoveAll.Image = global::ListBoxAppliances.Properties.Resources.delete_package;
            this.MniRemoveAll.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MniRemoveAll.Name = "MniRemoveAll";
            this.MniRemoveAll.Size = new System.Drawing.Size(246, 38);
            this.MniRemoveAll.Text = "Удалить все приборы";
            this.MniRemoveAll.Click += new System.EventHandler(this.RemoveAll_Command);
            // 
            // MniOrder
            // 
            this.MniOrder.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniOrderByName,
            this.MniOrderByPower});
            this.MniOrder.Name = "MniOrder";
            this.MniOrder.Size = new System.Drawing.Size(104, 24);
            this.MniOrder.Text = "Сортировка";
            // 
            // MniOrderByName
            // 
            this.MniOrderByName.Image = global::ListBoxAppliances.Properties.Resources.sort_alphabel;
            this.MniOrderByName.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MniOrderByName.Name = "MniOrderByName";
            this.MniOrderByName.Size = new System.Drawing.Size(227, 38);
            this.MniOrderByName.Text = "По наименованию";
            this.MniOrderByName.Click += new System.EventHandler(this.OrderByName_Command);
            // 
            // MniOrderByPower
            // 
            this.MniOrderByPower.Image = global::ListBoxAppliances.Properties.Resources.sort_date;
            this.MniOrderByPower.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MniOrderByPower.Name = "MniOrderByPower";
            this.MniOrderByPower.Size = new System.Drawing.Size(227, 38);
            this.MniOrderByPower.Text = "По мощности";
            this.MniOrderByPower.Click += new System.EventHandler(this.OrderByPower_Command);
            // 
            // MniTurnOn
            // 
            this.MniTurnOn.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniTurnOnAt,
            this.MniTurnOnAll});
            this.MniTurnOn.Name = "MniTurnOn";
            this.MniTurnOn.Size = new System.Drawing.Size(99, 24);
            this.MniTurnOn.Text = "Включение";
            // 
            // MniTurnOnAt
            // 
            this.MniTurnOnAt.Image = global::ListBoxAppliances.Properties.Resources.lightbulb;
            this.MniTurnOnAt.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MniTurnOnAt.Name = "MniTurnOnAt";
            this.MniTurnOnAt.Size = new System.Drawing.Size(248, 38);
            this.MniTurnOnAt.Text = "Включить выбранный";
            this.MniTurnOnAt.Click += new System.EventHandler(this.TurnOnAt_Command);
            // 
            // MniTurnOnAll
            // 
            this.MniTurnOnAll.Image = global::ListBoxAppliances.Properties.Resources.lightning_add;
            this.MniTurnOnAll.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MniTurnOnAll.Name = "MniTurnOnAll";
            this.MniTurnOnAll.Size = new System.Drawing.Size(248, 38);
            this.MniTurnOnAll.Text = "Включить все";
            this.MniTurnOnAll.Click += new System.EventHandler(this.TurnOnAll_Command);
            // 
            // MniTurnOff
            // 
            this.MniTurnOff.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniTurnOffAt,
            this.MniTurnOffAll});
            this.MniTurnOff.Name = "MniTurnOff";
            this.MniTurnOff.Size = new System.Drawing.Size(110, 24);
            this.MniTurnOff.Text = "Выключение";
            // 
            // MniTurnOffAt
            // 
            this.MniTurnOffAt.Image = global::ListBoxAppliances.Properties.Resources.lightbulb_off;
            this.MniTurnOffAt.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MniTurnOffAt.Name = "MniTurnOffAt";
            this.MniTurnOffAt.Size = new System.Drawing.Size(259, 38);
            this.MniTurnOffAt.Text = "Выключить выбранный";
            this.MniTurnOffAt.Click += new System.EventHandler(this.TurnOffAt_Command);
            // 
            // MniTurnOffAll
            // 
            this.MniTurnOffAll.Image = global::ListBoxAppliances.Properties.Resources.lightning_delete;
            this.MniTurnOffAll.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MniTurnOffAll.Name = "MniTurnOffAll";
            this.MniTurnOffAll.Size = new System.Drawing.Size(259, 38);
            this.MniTurnOffAll.Text = "Выключить все";
            this.MniTurnOffAll.Click += new System.EventHandler(this.TurnOffAll_Command);
            // 
            // MniHelp
            // 
            this.MniHelp.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.MniHelp.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniHelpAbout});
            this.MniHelp.Name = "MniHelp";
            this.MniHelp.Size = new System.Drawing.Size(79, 24);
            this.MniHelp.Text = "Справка";
            // 
            // MniHelpAbout
            // 
            this.MniHelpAbout.Image = global::ListBoxAppliances.Properties.Resources.help;
            this.MniHelpAbout.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MniHelpAbout.Name = "MniHelpAbout";
            this.MniHelpAbout.Size = new System.Drawing.Size(198, 38);
            this.MniHelpAbout.Text = "О программе...";
            this.MniHelpAbout.Click += new System.EventHandler(this.About_Command);
            // 
            // TsbMain
            // 
            this.TsbMain.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TsbMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButton1,
            this.toolStripButton2,
            this.toolStripSeparator1,
            this.toolStripButton11,
            this.toolStripButton10,
            this.toolStripSeparator5,
            this.toolStripButton3,
            this.toolStripButton4,
            this.toolStripSeparator2,
            this.toolStripButton5,
            this.toolStripButton7,
            this.toolStripSeparator3,
            this.toolStripButton6,
            this.toolStripButton8,
            this.toolStripSeparator4,
            this.toolStripButton9,
            this.TsbExit});
            this.TsbMain.Location = new System.Drawing.Point(0, 28);
            this.TsbMain.Name = "TsbMain";
            this.TsbMain.Padding = new System.Windows.Forms.Padding(5, 1, 15, 1);
            this.TsbMain.Size = new System.Drawing.Size(1084, 41);
            this.TsbMain.TabIndex = 1;
            this.TsbMain.Text = "toolStrip1";
            // 
            // toolStripButton1
            // 
            this.toolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton1.Image = global::ListBoxAppliances.Properties.Resources._new;
            this.toolStripButton1.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.Size = new System.Drawing.Size(36, 36);
            this.toolStripButton1.Text = "Новая коллекция";
            this.toolStripButton1.ToolTipText = "Сформировать новую коллекцию";
            this.toolStripButton1.Click += new System.EventHandler(this.NewCollection_Command);
            // 
            // toolStripButton2
            // 
            this.toolStripButton2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton2.Image = global::ListBoxAppliances.Properties.Resources.mixx;
            this.toolStripButton2.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripButton2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton2.Name = "toolStripButton2";
            this.toolStripButton2.Size = new System.Drawing.Size(36, 36);
            this.toolStripButton2.Text = "toolStripButton2";
            this.toolStripButton2.ToolTipText = "Перемешать данные в коллекции";
            this.toolStripButton2.Click += new System.EventHandler(this.Shuffle_Command);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 39);
            // 
            // toolStripButton11
            // 
            this.toolStripButton11.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton11.Image = global::ListBoxAppliances.Properties.Resources.delete;
            this.toolStripButton11.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripButton11.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton11.Name = "toolStripButton11";
            this.toolStripButton11.Size = new System.Drawing.Size(36, 36);
            this.toolStripButton11.Text = "toolStripButton11";
            this.toolStripButton11.ToolTipText = "Удаление выбранного прибора";
            this.toolStripButton11.Click += new System.EventHandler(this.RemoveAt_Command);
            // 
            // toolStripButton10
            // 
            this.toolStripButton10.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton10.Image = global::ListBoxAppliances.Properties.Resources.delete_package;
            this.toolStripButton10.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripButton10.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton10.Name = "toolStripButton10";
            this.toolStripButton10.Size = new System.Drawing.Size(36, 36);
            this.toolStripButton10.Text = "toolStripButton10";
            this.toolStripButton10.ToolTipText = "Удаление всех приборов коллекции";
            this.toolStripButton10.Click += new System.EventHandler(this.RemoveAll_Command);
            // 
            // toolStripSeparator5
            // 
            this.toolStripSeparator5.Name = "toolStripSeparator5";
            this.toolStripSeparator5.Size = new System.Drawing.Size(6, 39);
            // 
            // toolStripButton3
            // 
            this.toolStripButton3.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton3.Image = global::ListBoxAppliances.Properties.Resources.sort_alphabel;
            this.toolStripButton3.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripButton3.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton3.Name = "toolStripButton3";
            this.toolStripButton3.Size = new System.Drawing.Size(36, 36);
            this.toolStripButton3.Text = "toolStripButton3";
            this.toolStripButton3.ToolTipText = "Сортировка коллекции приборов\r\nпо наименованию";
            this.toolStripButton3.Click += new System.EventHandler(this.OrderByName_Command);
            // 
            // toolStripButton4
            // 
            this.toolStripButton4.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton4.Image = global::ListBoxAppliances.Properties.Resources.sort_date;
            this.toolStripButton4.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripButton4.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton4.Name = "toolStripButton4";
            this.toolStripButton4.Size = new System.Drawing.Size(36, 36);
            this.toolStripButton4.Text = "toolStripButton4";
            this.toolStripButton4.ToolTipText = "Сортировка коллекции приборов\r\nпо мощности\r\n";
            this.toolStripButton4.Click += new System.EventHandler(this.OrderByPower_Command);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 39);
            // 
            // toolStripButton5
            // 
            this.toolStripButton5.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton5.Image = global::ListBoxAppliances.Properties.Resources.lightbulb;
            this.toolStripButton5.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripButton5.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton5.Name = "toolStripButton5";
            this.toolStripButton5.Size = new System.Drawing.Size(36, 36);
            this.toolStripButton5.Text = "toolStripButton5";
            this.toolStripButton5.ToolTipText = "Включить выбранный прибор";
            this.toolStripButton5.Click += new System.EventHandler(this.TurnOnAt_Command);
            // 
            // toolStripButton7
            // 
            this.toolStripButton7.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton7.Image = global::ListBoxAppliances.Properties.Resources.lightbulb_off;
            this.toolStripButton7.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripButton7.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton7.Name = "toolStripButton7";
            this.toolStripButton7.Size = new System.Drawing.Size(36, 36);
            this.toolStripButton7.Text = "toolStripButton7";
            this.toolStripButton7.ToolTipText = "Выключить выбранный прибор";
            this.toolStripButton7.Click += new System.EventHandler(this.TurnOffAt_Command);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(6, 39);
            // 
            // toolStripButton6
            // 
            this.toolStripButton6.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton6.Image = global::ListBoxAppliances.Properties.Resources.lightning_add;
            this.toolStripButton6.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripButton6.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton6.Name = "toolStripButton6";
            this.toolStripButton6.Size = new System.Drawing.Size(36, 36);
            this.toolStripButton6.Text = "toolStripButton6";
            this.toolStripButton6.ToolTipText = "Включить все приборы";
            this.toolStripButton6.Click += new System.EventHandler(this.TurnOnAll_Command);
            // 
            // toolStripButton8
            // 
            this.toolStripButton8.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton8.Image = global::ListBoxAppliances.Properties.Resources.lightning_delete;
            this.toolStripButton8.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripButton8.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton8.Name = "toolStripButton8";
            this.toolStripButton8.Size = new System.Drawing.Size(36, 36);
            this.toolStripButton8.Text = "toolStripButton8";
            this.toolStripButton8.ToolTipText = "Выключить все приборы";
            this.toolStripButton8.Click += new System.EventHandler(this.TurnOffAll_Command);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(6, 39);
            // 
            // toolStripButton9
            // 
            this.toolStripButton9.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton9.Image = global::ListBoxAppliances.Properties.Resources.help;
            this.toolStripButton9.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripButton9.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton9.Name = "toolStripButton9";
            this.toolStripButton9.Size = new System.Drawing.Size(36, 36);
            this.toolStripButton9.Text = "toolStripButton9";
            this.toolStripButton9.ToolTipText = "Вывод свежедений о приложении \r\nи разработчике";
            this.toolStripButton9.Click += new System.EventHandler(this.About_Command);
            // 
            // TsbExit
            // 
            this.TsbExit.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.TsbExit.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbExit.Image = global::ListBoxAppliances.Properties.Resources.door_out;
            this.TsbExit.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbExit.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbExit.Name = "TsbExit";
            this.TsbExit.Size = new System.Drawing.Size(36, 36);
            this.TsbExit.Text = "toolStripButton10";
            this.TsbExit.ToolTipText = "Завершение работы приложения";
            this.TsbExit.Click += new System.EventHandler(this.Exit_Command);
            // 
            // StsMain
            // 
            this.StsMain.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.StsMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.StlMain});
            this.StsMain.Location = new System.Drawing.Point(0, 536);
            this.StsMain.Name = "StsMain";
            this.StsMain.Size = new System.Drawing.Size(1084, 25);
            this.StsMain.TabIndex = 2;
            this.StsMain.Text = "statusStrip1";
            // 
            // StlMain
            // 
            this.StlMain.AutoSize = false;
            this.StlMain.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.StlMain.Name = "StlMain";
            this.StlMain.Size = new System.Drawing.Size(1069, 20);
            this.StlMain.Spring = true;
            this.StlMain.Text = "toolStripStatusLabel1";
            this.StlMain.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // LblAppliances
            // 
            this.LblAppliances.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblAppliances.Location = new System.Drawing.Point(16, 72);
            this.LblAppliances.Name = "LblAppliances";
            this.LblAppliances.Size = new System.Drawing.Size(608, 23);
            this.LblAppliances.TabIndex = 3;
            this.LblAppliances.Text = "Заголовок коллекции приборов";
            // 
            // LbxAppliances
            // 
            this.LbxAppliances.ContextMenuStrip = this.CmnAppliances;
            this.LbxAppliances.Font = new System.Drawing.Font("Consolas", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LbxAppliances.FormattingEnabled = true;
            this.LbxAppliances.ItemHeight = 19;
            this.LbxAppliances.Location = new System.Drawing.Point(8, 96);
            this.LbxAppliances.Name = "LbxAppliances";
            this.LbxAppliances.ScrollAlwaysVisible = true;
            this.LbxAppliances.Size = new System.Drawing.Size(616, 422);
            this.LbxAppliances.TabIndex = 4;
            // 
            // CmnAppliances
            // 
            this.CmnAppliances.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.CmnAppliances.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.правкаToolStripMenuItem,
            this.сортировкаToolStripMenuItem,
            this.включениеToolStripMenuItem,
            this.выключениеToolStripMenuItem,
            this.toolStripMenuItem1,
            this.оПрограммеToolStripMenuItem,
            this.toolStripMenuItem2,
            this.выходToolStripMenuItem});
            this.CmnAppliances.Name = "CmnAppliances";
            this.CmnAppliances.Size = new System.Drawing.Size(202, 244);
            // 
            // правкаToolStripMenuItem
            // 
            this.правкаToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.новаяКоллекцияToolStripMenuItem,
            this.перемешатьКоллекциюToolStripMenuItem,
            this.toolStripMenuItem4,
            this.удалитьПриборToolStripMenuItem,
            this.удалитьВсеПриборыToolStripMenuItem});
            this.правкаToolStripMenuItem.Name = "правкаToolStripMenuItem";
            this.правкаToolStripMenuItem.Size = new System.Drawing.Size(201, 38);
            this.правкаToolStripMenuItem.Text = "Правка";
            // 
            // новаяКоллекцияToolStripMenuItem
            // 
            this.новаяКоллекцияToolStripMenuItem.Image = global::ListBoxAppliances.Properties.Resources._new;
            this.новаяКоллекцияToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.новаяКоллекцияToolStripMenuItem.Name = "новаяКоллекцияToolStripMenuItem";
            this.новаяКоллекцияToolStripMenuItem.Size = new System.Drawing.Size(250, 38);
            this.новаяКоллекцияToolStripMenuItem.Text = "Новая коллекция";
            this.новаяКоллекцияToolStripMenuItem.Click += new System.EventHandler(this.NewCollection_Command);
            // 
            // перемешатьКоллекциюToolStripMenuItem
            // 
            this.перемешатьКоллекциюToolStripMenuItem.Image = global::ListBoxAppliances.Properties.Resources.mixx;
            this.перемешатьКоллекциюToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.перемешатьКоллекциюToolStripMenuItem.Name = "перемешатьКоллекциюToolStripMenuItem";
            this.перемешатьКоллекциюToolStripMenuItem.Size = new System.Drawing.Size(250, 38);
            this.перемешатьКоллекциюToolStripMenuItem.Text = "Перемешать";
            this.перемешатьКоллекциюToolStripMenuItem.Click += new System.EventHandler(this.Shuffle_Command);
            // 
            // сортировкаToolStripMenuItem
            // 
            this.сортировкаToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.поНаименованиюToolStripMenuItem,
            this.поМощностиToolStripMenuItem});
            this.сортировкаToolStripMenuItem.Name = "сортировкаToolStripMenuItem";
            this.сортировкаToolStripMenuItem.Size = new System.Drawing.Size(201, 38);
            this.сортировкаToolStripMenuItem.Text = "Сортировка";
            // 
            // поНаименованиюToolStripMenuItem
            // 
            this.поНаименованиюToolStripMenuItem.Image = global::ListBoxAppliances.Properties.Resources.sort_alphabel;
            this.поНаименованиюToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.поНаименованиюToolStripMenuItem.Name = "поНаименованиюToolStripMenuItem";
            this.поНаименованиюToolStripMenuItem.Size = new System.Drawing.Size(230, 38);
            this.поНаименованиюToolStripMenuItem.Text = "По наименованию";
            this.поНаименованиюToolStripMenuItem.Click += new System.EventHandler(this.OrderByName_Command);
            // 
            // поМощностиToolStripMenuItem
            // 
            this.поМощностиToolStripMenuItem.Image = global::ListBoxAppliances.Properties.Resources.sort_date;
            this.поМощностиToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.поМощностиToolStripMenuItem.Name = "поМощностиToolStripMenuItem";
            this.поМощностиToolStripMenuItem.Size = new System.Drawing.Size(230, 38);
            this.поМощностиToolStripMenuItem.Text = "По мощности";
            this.поМощностиToolStripMenuItem.Click += new System.EventHandler(this.OrderByPower_Command);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(198, 6);
            // 
            // оПрограммеToolStripMenuItem
            // 
            this.оПрограммеToolStripMenuItem.Image = global::ListBoxAppliances.Properties.Resources.help;
            this.оПрограммеToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.оПрограммеToolStripMenuItem.Name = "оПрограммеToolStripMenuItem";
            this.оПрограммеToolStripMenuItem.Size = new System.Drawing.Size(201, 38);
            this.оПрограммеToolStripMenuItem.Text = "О программе...";
            this.оПрограммеToolStripMenuItem.Click += new System.EventHandler(this.About_Command);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(198, 6);
            // 
            // выходToolStripMenuItem
            // 
            this.выходToolStripMenuItem.Image = global::ListBoxAppliances.Properties.Resources.door_out;
            this.выходToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.выходToolStripMenuItem.Name = "выходToolStripMenuItem";
            this.выходToolStripMenuItem.Size = new System.Drawing.Size(201, 38);
            this.выходToolStripMenuItem.Text = "Выход";
            this.выходToolStripMenuItem.Click += new System.EventHandler(this.Exit_Command);
            // 
            // GbxAppliance
            // 
            this.GbxAppliance.BackColor = System.Drawing.Color.Lavender;
            this.GbxAppliance.Controls.Add(this.BtnOk);
            this.GbxAppliance.Controls.Add(this.CbxApplianceState);
            this.GbxAppliance.Controls.Add(this.label3);
            this.GbxAppliance.Controls.Add(this.NudPrice);
            this.GbxAppliance.Controls.Add(this.label2);
            this.GbxAppliance.Controls.Add(this.NudPower);
            this.GbxAppliance.Controls.Add(this.LblPower);
            this.GbxAppliance.Controls.Add(this.CbxApplianceNames);
            this.GbxAppliance.Controls.Add(this.LblApplianceName);
            this.GbxAppliance.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.GbxAppliance.Location = new System.Drawing.Point(640, 128);
            this.GbxAppliance.Name = "GbxAppliance";
            this.GbxAppliance.Size = new System.Drawing.Size(416, 352);
            this.GbxAppliance.TabIndex = 5;
            this.GbxAppliance.TabStop = false;
            this.GbxAppliance.Text = "Данные нового прибора:";
            // 
            // BtnOk
            // 
            this.BtnOk.BackColor = System.Drawing.Color.LightCyan;
            this.BtnOk.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BtnOk.Location = new System.Drawing.Point(184, 296);
            this.BtnOk.Name = "BtnOk";
            this.BtnOk.Size = new System.Drawing.Size(216, 32);
            this.BtnOk.TabIndex = 8;
            this.BtnOk.Text = "Добавить прибор";
            this.BtnOk.UseVisualStyleBackColor = false;
            this.BtnOk.Click += new System.EventHandler(this.AddAppliance_Command);
            // 
            // CbxApplianceState
            // 
            this.CbxApplianceState.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CbxApplianceState.FormattingEnabled = true;
            this.CbxApplianceState.Items.AddRange(new object[] {
            "включен",
            "выключен"});
            this.CbxApplianceState.Location = new System.Drawing.Point(184, 211);
            this.CbxApplianceState.Name = "CbxApplianceState";
            this.CbxApplianceState.Size = new System.Drawing.Size(216, 26);
            this.CbxApplianceState.TabIndex = 7;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(16, 215);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(166, 18);
            this.label3.TabIndex = 6;
            this.label3.Text = "Состояние прибора:";
            // 
            // NudPrice
            // 
            this.NudPrice.DecimalPlaces = 2;
            this.NudPrice.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.NudPrice.Location = new System.Drawing.Point(184, 158);
            this.NudPrice.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.NudPrice.Name = "NudPrice";
            this.NudPrice.Size = new System.Drawing.Size(216, 26);
            this.NudPrice.TabIndex = 5;
            this.NudPrice.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.NudPrice.ThousandsSeparator = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(16, 162);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(122, 18);
            this.label2.TabIndex = 4;
            this.label2.Text = "Цена прибора:";
            // 
            // NudPower
            // 
            this.NudPower.DecimalPlaces = 2;
            this.NudPower.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.NudPower.Location = new System.Drawing.Point(184, 105);
            this.NudPower.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.NudPower.Name = "NudPower";
            this.NudPower.Size = new System.Drawing.Size(216, 26);
            this.NudPower.TabIndex = 3;
            this.NudPower.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.NudPower.ThousandsSeparator = true;
            // 
            // LblPower
            // 
            this.LblPower.AutoSize = true;
            this.LblPower.Location = new System.Drawing.Point(16, 109);
            this.LblPower.Name = "LblPower";
            this.LblPower.Size = new System.Drawing.Size(164, 18);
            this.LblPower.TabIndex = 2;
            this.LblPower.Text = "Мощность прибора:";
            // 
            // CbxApplianceNames
            // 
            this.CbxApplianceNames.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CbxApplianceNames.FormattingEnabled = true;
            this.CbxApplianceNames.Items.AddRange(new object[] {
            "блендер",
            "вертикальный пылесос",
            "микроволновка",
            "миксер",
            "панель управления",
            "посудомоечная машина",
            "светильник",
            "стиральная машина",
            "утюг",
            "хлебопечка",
            "чайник"});
            this.CbxApplianceNames.Location = new System.Drawing.Point(184, 52);
            this.CbxApplianceNames.Name = "CbxApplianceNames";
            this.CbxApplianceNames.Size = new System.Drawing.Size(216, 26);
            this.CbxApplianceNames.Sorted = true;
            this.CbxApplianceNames.TabIndex = 1;
            // 
            // LblApplianceName
            // 
            this.LblApplianceName.AutoSize = true;
            this.LblApplianceName.Location = new System.Drawing.Point(16, 56);
            this.LblApplianceName.Name = "LblApplianceName";
            this.LblApplianceName.Size = new System.Drawing.Size(157, 18);
            this.LblApplianceName.TabIndex = 0;
            this.LblApplianceName.Text = "Название прибора:";
            // 
            // CmnForm
            // 
            this.CmnForm.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.CmnForm.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem9,
            this.toolStripSeparator6,
            this.toolStripMenuItem10});
            this.CmnForm.Name = "CmnAppliances";
            this.CmnForm.Size = new System.Drawing.Size(202, 86);
            // 
            // toolStripMenuItem9
            // 
            this.toolStripMenuItem9.Image = global::ListBoxAppliances.Properties.Resources.help;
            this.toolStripMenuItem9.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripMenuItem9.Name = "toolStripMenuItem9";
            this.toolStripMenuItem9.Size = new System.Drawing.Size(201, 38);
            this.toolStripMenuItem9.Text = "О программе...";
            this.toolStripMenuItem9.Click += new System.EventHandler(this.About_Command);
            // 
            // toolStripSeparator6
            // 
            this.toolStripSeparator6.Name = "toolStripSeparator6";
            this.toolStripSeparator6.Size = new System.Drawing.Size(198, 6);
            // 
            // toolStripMenuItem10
            // 
            this.toolStripMenuItem10.Image = global::ListBoxAppliances.Properties.Resources.door_out;
            this.toolStripMenuItem10.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripMenuItem10.Name = "toolStripMenuItem10";
            this.toolStripMenuItem10.Size = new System.Drawing.Size(201, 38);
            this.toolStripMenuItem10.Text = "Выход";
            this.toolStripMenuItem10.Click += new System.EventHandler(this.Exit_Command);
            // 
            // включениеToolStripMenuItem
            // 
            this.включениеToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.включитьВыбранныйToolStripMenuItem,
            this.включитьВсеToolStripMenuItem});
            this.включениеToolStripMenuItem.Name = "включениеToolStripMenuItem";
            this.включениеToolStripMenuItem.Size = new System.Drawing.Size(201, 38);
            this.включениеToolStripMenuItem.Text = "Включение";
            // 
            // выключениеToolStripMenuItem
            // 
            this.выключениеToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.выключитьВыбранныйToolStripMenuItem,
            this.выключитьВсеToolStripMenuItem});
            this.выключениеToolStripMenuItem.Name = "выключениеToolStripMenuItem";
            this.выключениеToolStripMenuItem.Size = new System.Drawing.Size(201, 38);
            this.выключениеToolStripMenuItem.Text = "Выключение";
            // 
            // toolStripMenuItem4
            // 
            this.toolStripMenuItem4.Name = "toolStripMenuItem4";
            this.toolStripMenuItem4.Size = new System.Drawing.Size(247, 6);
            // 
            // удалитьПриборToolStripMenuItem
            // 
            this.удалитьПриборToolStripMenuItem.Image = global::ListBoxAppliances.Properties.Resources.delete;
            this.удалитьПриборToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.удалитьПриборToolStripMenuItem.Name = "удалитьПриборToolStripMenuItem";
            this.удалитьПриборToolStripMenuItem.Size = new System.Drawing.Size(250, 38);
            this.удалитьПриборToolStripMenuItem.Text = "Удалить прибор";
            this.удалитьПриборToolStripMenuItem.Click += new System.EventHandler(this.RemoveAt_Command);
            // 
            // удалитьВсеПриборыToolStripMenuItem
            // 
            this.удалитьВсеПриборыToolStripMenuItem.Image = global::ListBoxAppliances.Properties.Resources.delete_package;
            this.удалитьВсеПриборыToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.удалитьВсеПриборыToolStripMenuItem.Name = "удалитьВсеПриборыToolStripMenuItem";
            this.удалитьВсеПриборыToolStripMenuItem.Size = new System.Drawing.Size(250, 38);
            this.удалитьВсеПриборыToolStripMenuItem.Text = "Удалить все приборы";
            this.удалитьВсеПриборыToolStripMenuItem.Click += new System.EventHandler(this.RemoveAll_Command);
            // 
            // включитьВыбранныйToolStripMenuItem
            // 
            this.включитьВыбранныйToolStripMenuItem.Image = global::ListBoxAppliances.Properties.Resources.lightbulb;
            this.включитьВыбранныйToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.включитьВыбранныйToolStripMenuItem.Name = "включитьВыбранныйToolStripMenuItem";
            this.включитьВыбранныйToolStripMenuItem.Size = new System.Drawing.Size(254, 38);
            this.включитьВыбранныйToolStripMenuItem.Text = "Включить выбранный";
            this.включитьВыбранныйToolStripMenuItem.Click += new System.EventHandler(this.TurnOnAt_Command);
            // 
            // включитьВсеToolStripMenuItem
            // 
            this.включитьВсеToolStripMenuItem.Image = global::ListBoxAppliances.Properties.Resources.lightning_add;
            this.включитьВсеToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.включитьВсеToolStripMenuItem.Name = "включитьВсеToolStripMenuItem";
            this.включитьВсеToolStripMenuItem.Size = new System.Drawing.Size(254, 38);
            this.включитьВсеToolStripMenuItem.Text = "Включить все";
            this.включитьВсеToolStripMenuItem.Click += new System.EventHandler(this.TurnOnAll_Command);
            // 
            // выключитьВыбранныйToolStripMenuItem
            // 
            this.выключитьВыбранныйToolStripMenuItem.Image = global::ListBoxAppliances.Properties.Resources.lightbulb_off;
            this.выключитьВыбранныйToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.выключитьВыбранныйToolStripMenuItem.Name = "выключитьВыбранныйToolStripMenuItem";
            this.выключитьВыбранныйToolStripMenuItem.Size = new System.Drawing.Size(265, 38);
            this.выключитьВыбранныйToolStripMenuItem.Text = "Выключить выбранный";
            this.выключитьВыбранныйToolStripMenuItem.Click += new System.EventHandler(this.TurnOffAt_Command);
            // 
            // выключитьВсеToolStripMenuItem
            // 
            this.выключитьВсеToolStripMenuItem.Image = global::ListBoxAppliances.Properties.Resources.lightning_delete;
            this.выключитьВсеToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.выключитьВсеToolStripMenuItem.Name = "выключитьВсеToolStripMenuItem";
            this.выключитьВсеToolStripMenuItem.Size = new System.Drawing.Size(265, 38);
            this.выключитьВсеToolStripMenuItem.Text = "Выключить все";
            this.выключитьВсеToolStripMenuItem.Click += new System.EventHandler(this.TurnOffAll_Command);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1084, 561);
            this.ContextMenuStrip = this.CmnForm;
            this.Controls.Add(this.GbxAppliance);
            this.Controls.Add(this.LbxAppliances);
            this.Controls.Add(this.LblAppliances);
            this.Controls.Add(this.StsMain);
            this.Controls.Add(this.TsbMain);
            this.Controls.Add(this.MnuMain);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.MnuMain;
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(1100, 600);
            this.MinimumSize = new System.Drawing.Size(1100, 566);
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Задание на 11.11.2021 - привязка данных к ListBox, ComboBox";
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.MnuMain.ResumeLayout(false);
            this.MnuMain.PerformLayout();
            this.TsbMain.ResumeLayout(false);
            this.TsbMain.PerformLayout();
            this.StsMain.ResumeLayout(false);
            this.StsMain.PerformLayout();
            this.CmnAppliances.ResumeLayout(false);
            this.GbxAppliance.ResumeLayout(false);
            this.GbxAppliance.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.NudPrice)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NudPower)).EndInit();
            this.CmnForm.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip MnuMain;
        private System.Windows.Forms.ToolStripMenuItem файлToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem MniFileExit;
        private System.Windows.Forms.ToolStripMenuItem MniEdit;
        private System.Windows.Forms.ToolStripMenuItem MniEditNewCollection;
        private System.Windows.Forms.ToolStripMenuItem MniEditShuffle;
        private System.Windows.Forms.ToolStripMenuItem MniOrder;
        private System.Windows.Forms.ToolStripMenuItem MniOrderByName;
        private System.Windows.Forms.ToolStripMenuItem MniOrderByPower;
        private System.Windows.Forms.ToolStripMenuItem MniTurnOn;
        private System.Windows.Forms.ToolStripMenuItem MniTurnOnAt;
        private System.Windows.Forms.ToolStripMenuItem MniTurnOnAll;
        private System.Windows.Forms.ToolStripMenuItem MniTurnOff;
        private System.Windows.Forms.ToolStripMenuItem MniTurnOffAt;
        private System.Windows.Forms.ToolStripMenuItem MniTurnOffAll;
        private System.Windows.Forms.ToolStripMenuItem MniHelp;
        private System.Windows.Forms.ToolStripMenuItem MniHelpAbout;
        private System.Windows.Forms.ToolStrip TsbMain;
        private System.Windows.Forms.ToolStripButton toolStripButton1;
        private System.Windows.Forms.ToolStripButton toolStripButton2;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripButton toolStripButton3;
        private System.Windows.Forms.ToolStripButton toolStripButton4;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripButton toolStripButton5;
        private System.Windows.Forms.ToolStripButton toolStripButton6;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripButton toolStripButton7;
        private System.Windows.Forms.ToolStripButton toolStripButton8;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripButton toolStripButton9;
        private System.Windows.Forms.ToolStripButton TsbExit;
        private System.Windows.Forms.StatusStrip StsMain;
        private System.Windows.Forms.Label LblAppliances;
        private System.Windows.Forms.ListBox LbxAppliances;
        private System.Windows.Forms.GroupBox GbxAppliance;
        private System.Windows.Forms.ToolStripStatusLabel StlMain;
        private System.Windows.Forms.ComboBox CbxApplianceState;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.NumericUpDown NudPrice;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.NumericUpDown NudPower;
        private System.Windows.Forms.Label LblPower;
        private System.Windows.Forms.ComboBox CbxApplianceNames;
        private System.Windows.Forms.Label LblApplianceName;
        private System.Windows.Forms.Button BtnOk;
        private System.Windows.Forms.ContextMenuStrip CmnAppliances;
        private System.Windows.Forms.ToolStripMenuItem правкаToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem новаяКоллекцияToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem перемешатьКоллекциюToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem сортировкаToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem поНаименованиюToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem поМощностиToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem оПрограммеToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem выходToolStripMenuItem;
        private System.Windows.Forms.ContextMenuStrip CmnForm;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem9;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator6;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem10;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem MniRemoveAt;
        private System.Windows.Forms.ToolStripMenuItem MniRemoveAll;
        private System.Windows.Forms.ToolStripButton toolStripButton11;
        private System.Windows.Forms.ToolStripButton toolStripButton10;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator5;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem4;
        private System.Windows.Forms.ToolStripMenuItem удалитьПриборToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem удалитьВсеПриборыToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem включениеToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem включитьВыбранныйToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem включитьВсеToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem выключениеToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem выключитьВыбранныйToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem выключитьВсеToolStripMenuItem;
    }
}

