﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WF_HW7_
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }


        CollectionAppliance _collection;

        private void ApplianceBind()
        {
            Lbx_Appliance.DataSource = null;                            // остановить текущую привязку
            Lbx_Appliance.DataSource = _collection.Appliances;          // источник данных - связанная со списком коллекция
            Lbx_Appliance.DisplayMember = "TableRow";                   // отображаемое в списке свойство/атрибут
        } // PersonsBind


        // включить все приборы
        private void TStrMenu_AllApliances_On_Click(object sender, EventArgs e) => _collection.AllOn();

        // выключить все приборы
        private void TStrMenu_AllApliances_Off_Click(object sender, EventArgs e) => _collection.AllOff();

        // удалить все приборы
        private void TStrMenu_AllApliances_Remove_Click(object sender, EventArgs e) => _collection.RemoveAllAppliance();

        // отсортировать по названию
        private void TStrMenu_Sort_byTitle_Click(object sender, EventArgs e) => _collection.SortByTitle();

        // отсортировать по мощности
        private void TStrMenu_Sort_byPower_Click(object sender, EventArgs e) => _collection.SortByPower();

        // включить конкретный прибор
        private void TStrLbl_On_Click(object sender, EventArgs e) => _collection.OnAppliance(Lbx_Appliance.SelectedIndex);

        // выключить конкретный прибор
        private void TStrLbl_Off_Click(object sender, EventArgs e) => _collection.OffAppliance(Lbx_Appliance.SelectedIndex);

        // удалить конкретный прибор
        private void TStrLbl_Delete_Click(object sender, EventArgs e) => _collection.RemoveAppliance(Lbx_Appliance.SelectedIndex);

        // генерация приборов
        private void Btn_Generate_Click(object sender, EventArgs e) 
        { 
            _collection = new CollectionAppliance();
            _collection.Refresh += ApplianceBind;
            ApplianceBind();

            TStrMenu_AllApliances_On.Enabled = true;
            TStrMenu_AllApliances_Off.Enabled = true;
            TStrMenu_AllApliances_Remove.Enabled = true;
            TStrMenu_Sort_byTitle.Enabled = true;
            TStrMenu_Sort_byPower.Enabled = true;
            TStrLbl_On.Enabled = true;
            TStrLbl_Off.Enabled = true;
            TStrLbl_Delete.Enabled = true;
            Btn_Mix.Enabled = true;
        }

        // перемешать приборы
        private void Btn_Mix_Click(object sender, EventArgs e) => _collection.Mix();

        // выход из приложения
        private void Btn_Exit_Click(object sender, EventArgs e) => Application.Exit();

    }
}
