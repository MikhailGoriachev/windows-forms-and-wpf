﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WF_HW7_
{
    class ElectricAppliance
    {
        public string _title{ get; set; }       // название
        public double _power { get; set; }      // мощность
        public double _price { get; set; }      // цена
        public bool _condition { get; set; }    // состояние (включен/выключен)


        public ElectricAppliance(string titile, double power, double price, bool condition ) 
        {
            _title = titile;
            _power = power;
            _price = price;
            _condition = condition;
        }

        public string TableRow =>
            $"| {_title,-30} | {_power,10} | {_price,10} | {_condition,5} |";

    }
}
