﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WF_HW7_
{
    class CollectionAppliance
    {
        List<ElectricAppliance> _electricAppliances; // коллекция приборов


        //формирование коллекции
        public CollectionAppliance()
        {
            _electricAppliances = new List<ElectricAppliance>()
            {
               new ElectricAppliance("Прибор1",   500, 1000, false),
               new ElectricAppliance("Прибор2",   600, 2000, true),
               new ElectricAppliance("Прибор3",   700, 3000, false),
               new ElectricAppliance("Прибор4",   800, 4000, true),
               new ElectricAppliance("Прибор5",   900, 5000, false),
               new ElectricAppliance("Прибор6",  1000, 6000, true),
               new ElectricAppliance("Прибор7",  1100, 7000, false),
               new ElectricAppliance("Прибор8",  1200, 8000, true),
               new ElectricAppliance("Прибор9",  1300, 9000, false),
               new ElectricAppliance("Прибор10", 1400, 1000, true),
               new ElectricAppliance("Прибор11", 1500, 1100, false),
            };
        }

        public event Action Refresh;


        public List<ElectricAppliance> Appliances => _electricAppliances;

        //Перемешивание элементов
        public void Mix() 
        {
            Random rand = new Random();


            for (int i = 0; i < _electricAppliances.Count; i++)
            {
                int first = rand.Next(_electricAppliances.Count);
                int sec = rand.Next(_electricAppliances.Count);


                (_electricAppliances[first], _electricAppliances[sec]) = (_electricAppliances[sec], _electricAppliances[first]);
            }

            Refresh();
        }

        //Сортировка по названию прибора
        public void SortByTitle() 
        { 
            _electricAppliances.Sort((x, y) => x._title.CompareTo(y._title));

            Refresh();
        }

        //Сортировка по мощности
        public void SortByPower()
        {
            _electricAppliances.Sort((x, y) => x._title.CompareTo(y._title));

            Refresh();
        }

        //Включение всех приборов
        public void AllOn() 
        {
            foreach (var item in _electricAppliances)
                item._condition = true;

            Refresh();
        }

        //Выключение всех приборов
        public void AllOff()
        {
            foreach (var item in _electricAppliances)
                item._condition = false;

            Refresh();
        }

        //Включение выбранного прибора
        public void OnAppliance(int index)
        {
            if (index < 0 || index >= _electricAppliances.Count)
                return;
            _electricAppliances[index]._condition = true;

            Refresh();
        }

        //Выключение выбранного прибора
        public void OffAppliance(int index) 
        {
            if (index < 0 || index >= _electricAppliances.Count)
                return;
            _electricAppliances[index]._condition = false;

            Refresh();
        }

        //Удаление выбранного прибора
        public void RemoveAppliance(int index) 
        {
            if (index < 0 || index >= _electricAppliances.Count)
                return;
            _electricAppliances.RemoveAt(index);

            Refresh();
        }

        //Удаление всех приборов
        public void RemoveAllAppliance()
        {
            _electricAppliances.Clear();

            Refresh();
        }
    }
}
