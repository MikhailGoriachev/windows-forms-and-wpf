﻿
namespace WF_HW7_
{
    partial class MainForm
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.TStrMenu_AllApliances = new System.Windows.Forms.ToolStripMenuItem();
            this.TStrMenu_AllApliances_On = new System.Windows.Forms.ToolStripMenuItem();
            this.TStrMenu_AllApliances_Off = new System.Windows.Forms.ToolStripMenuItem();
            this.TStrMenu_AllApliances_Remove = new System.Windows.Forms.ToolStripMenuItem();
            this.TStrMenu_Sort = new System.Windows.Forms.ToolStripMenuItem();
            this.TStrMenu_Sort_byTitle = new System.Windows.Forms.ToolStripMenuItem();
            this.TStrMenu_Sort_byPower = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripBtn_Mix = new System.Windows.Forms.ToolStripButton();
            this.TStrLbl_On = new System.Windows.Forms.ToolStripLabel();
            this.TStrLbl_Off = new System.Windows.Forms.ToolStripLabel();
            this.TStrLbl_Delete = new System.Windows.Forms.ToolStripLabel();
            this.Btn_Generate = new System.Windows.Forms.Button();
            this.Btn_Mix = new System.Windows.Forms.Button();
            this.Btn_Exit = new System.Windows.Forms.Button();
            this.Lbx_Appliance = new System.Windows.Forms.ListBox();
            this.menuStrip1.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.TStrMenu_AllApliances,
            this.TStrMenu_Sort});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(834, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // TStrMenu_AllApliances
            // 
            this.TStrMenu_AllApliances.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.TStrMenu_AllApliances_On,
            this.TStrMenu_AllApliances_Off,
            this.TStrMenu_AllApliances_Remove});
            this.TStrMenu_AllApliances.Name = "TStrMenu_AllApliances";
            this.TStrMenu_AllApliances.Size = new System.Drawing.Size(175, 20);
            this.TStrMenu_AllApliances.Text = "Функции для всех приборов";
            // 
            // TStrMenu_AllApliances_On
            // 
            this.TStrMenu_AllApliances_On.Enabled = false;
            this.TStrMenu_AllApliances_On.Name = "TStrMenu_AllApliances_On";
            this.TStrMenu_AllApliances_On.Size = new System.Drawing.Size(213, 22);
            this.TStrMenu_AllApliances_On.Text = "Включить все приборы";
            this.TStrMenu_AllApliances_On.Click += new System.EventHandler(this.TStrMenu_AllApliances_On_Click);
            // 
            // TStrMenu_AllApliances_Off
            // 
            this.TStrMenu_AllApliances_Off.Enabled = false;
            this.TStrMenu_AllApliances_Off.Name = "TStrMenu_AllApliances_Off";
            this.TStrMenu_AllApliances_Off.Size = new System.Drawing.Size(213, 22);
            this.TStrMenu_AllApliances_Off.Text = "Выключить все приборы";
            this.TStrMenu_AllApliances_Off.Click += new System.EventHandler(this.TStrMenu_AllApliances_Off_Click);
            // 
            // TStrMenu_AllApliances_Remove
            // 
            this.TStrMenu_AllApliances_Remove.Enabled = false;
            this.TStrMenu_AllApliances_Remove.Name = "TStrMenu_AllApliances_Remove";
            this.TStrMenu_AllApliances_Remove.Size = new System.Drawing.Size(213, 22);
            this.TStrMenu_AllApliances_Remove.Text = "Удалить все приборы";
            this.TStrMenu_AllApliances_Remove.Click += new System.EventHandler(this.TStrMenu_AllApliances_Remove_Click);
            // 
            // TStrMenu_Sort
            // 
            this.TStrMenu_Sort.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.TStrMenu_Sort_byTitle,
            this.TStrMenu_Sort_byPower});
            this.TStrMenu_Sort.Name = "TStrMenu_Sort";
            this.TStrMenu_Sort.Size = new System.Drawing.Size(85, 20);
            this.TStrMenu_Sort.Text = "Сортировка";
            // 
            // TStrMenu_Sort_byTitle
            // 
            this.TStrMenu_Sort_byTitle.Enabled = false;
            this.TStrMenu_Sort_byTitle.Name = "TStrMenu_Sort_byTitle";
            this.TStrMenu_Sort_byTitle.Size = new System.Drawing.Size(152, 22);
            this.TStrMenu_Sort_byTitle.Text = "По названию";
            this.TStrMenu_Sort_byTitle.Click += new System.EventHandler(this.TStrMenu_Sort_byTitle_Click);
            // 
            // TStrMenu_Sort_byPower
            // 
            this.TStrMenu_Sort_byPower.Enabled = false;
            this.TStrMenu_Sort_byPower.Name = "TStrMenu_Sort_byPower";
            this.TStrMenu_Sort_byPower.Size = new System.Drawing.Size(152, 22);
            this.TStrMenu_Sort_byPower.Text = "По мощности";
            this.TStrMenu_Sort_byPower.Click += new System.EventHandler(this.TStrMenu_Sort_byPower_Click);
            // 
            // toolStrip1
            // 
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripBtn_Mix,
            this.TStrLbl_On,
            this.TStrLbl_Off,
            this.TStrLbl_Delete});
            this.toolStrip1.Location = new System.Drawing.Point(0, 24);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(834, 25);
            this.toolStrip1.TabIndex = 1;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // toolStripBtn_Mix
            // 
            this.toolStripBtn_Mix.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripBtn_Mix.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripBtn_Mix.Name = "toolStripBtn_Mix";
            this.toolStripBtn_Mix.Size = new System.Drawing.Size(23, 22);
            this.toolStripBtn_Mix.Text = "Перемешать все элементы";
            // 
            // TStrLbl_On
            // 
            this.TStrLbl_On.Enabled = false;
            this.TStrLbl_On.Name = "TStrLbl_On";
            this.TStrLbl_On.Size = new System.Drawing.Size(74, 22);
            this.TStrLbl_On.Text = "  Включить  ";
            this.TStrLbl_On.Click += new System.EventHandler(this.TStrLbl_On_Click);
            // 
            // TStrLbl_Off
            // 
            this.TStrLbl_Off.Enabled = false;
            this.TStrLbl_Off.Name = "TStrLbl_Off";
            this.TStrLbl_Off.Size = new System.Drawing.Size(83, 22);
            this.TStrLbl_Off.Text = "  Выключить  ";
            this.TStrLbl_Off.Click += new System.EventHandler(this.TStrLbl_Off_Click);
            // 
            // TStrLbl_Delete
            // 
            this.TStrLbl_Delete.Enabled = false;
            this.TStrLbl_Delete.Name = "TStrLbl_Delete";
            this.TStrLbl_Delete.Size = new System.Drawing.Size(63, 22);
            this.TStrLbl_Delete.Text = "  Удалить  ";
            this.TStrLbl_Delete.Click += new System.EventHandler(this.TStrLbl_Delete_Click);
            // 
            // Btn_Generate
            // 
            this.Btn_Generate.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.Btn_Generate.Font = new System.Drawing.Font("Consolas", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Btn_Generate.Location = new System.Drawing.Point(12, 90);
            this.Btn_Generate.Name = "Btn_Generate";
            this.Btn_Generate.Size = new System.Drawing.Size(206, 51);
            this.Btn_Generate.TabIndex = 2;
            this.Btn_Generate.Text = "Сгенерировать данные";
            this.Btn_Generate.UseVisualStyleBackColor = false;
            this.Btn_Generate.Click += new System.EventHandler(this.Btn_Generate_Click);
            // 
            // Btn_Mix
            // 
            this.Btn_Mix.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.Btn_Mix.Enabled = false;
            this.Btn_Mix.Font = new System.Drawing.Font("Consolas", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Btn_Mix.Location = new System.Drawing.Point(12, 242);
            this.Btn_Mix.Name = "Btn_Mix";
            this.Btn_Mix.Size = new System.Drawing.Size(206, 58);
            this.Btn_Mix.TabIndex = 3;
            this.Btn_Mix.Text = "Перемешать данные";
            this.Btn_Mix.UseVisualStyleBackColor = false;
            this.Btn_Mix.Click += new System.EventHandler(this.Btn_Mix_Click);
            // 
            // Btn_Exit
            // 
            this.Btn_Exit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.Btn_Exit.Font = new System.Drawing.Font("Consolas", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Btn_Exit.Location = new System.Drawing.Point(12, 409);
            this.Btn_Exit.Name = "Btn_Exit";
            this.Btn_Exit.Size = new System.Drawing.Size(206, 49);
            this.Btn_Exit.TabIndex = 4;
            this.Btn_Exit.Text = "Выход";
            this.Btn_Exit.UseVisualStyleBackColor = false;
            this.Btn_Exit.Click += new System.EventHandler(this.Btn_Exit_Click);
            // 
            // Lbx_Appliance
            // 
            this.Lbx_Appliance.FormattingEnabled = true;
            this.Lbx_Appliance.Location = new System.Drawing.Point(269, 90);
            this.Lbx_Appliance.Name = "Lbx_Appliance";
            this.Lbx_Appliance.Size = new System.Drawing.Size(553, 368);
            this.Lbx_Appliance.TabIndex = 5;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(834, 537);
            this.Controls.Add(this.Lbx_Appliance);
            this.Controls.Add(this.Btn_Exit);
            this.Controls.Add(this.Btn_Mix);
            this.Controls.Add(this.Btn_Generate);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "MainForm";
            this.Text = "Электроприборы";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem TStrMenu_AllApliances;
        private System.Windows.Forms.ToolStripMenuItem TStrMenu_AllApliances_On;
        private System.Windows.Forms.ToolStripMenuItem TStrMenu_AllApliances_Off;
        private System.Windows.Forms.ToolStripMenuItem TStrMenu_AllApliances_Remove;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton toolStripBtn_Mix;
        private System.Windows.Forms.ToolStripMenuItem TStrMenu_Sort;
        private System.Windows.Forms.ToolStripMenuItem TStrMenu_Sort_byTitle;
        private System.Windows.Forms.ToolStripMenuItem TStrMenu_Sort_byPower;
        private System.Windows.Forms.ToolStripLabel TStrLbl_On;
        private System.Windows.Forms.Button Btn_Generate;
        private System.Windows.Forms.Button Btn_Mix;
        private System.Windows.Forms.Button Btn_Exit;
        private System.Windows.Forms.ToolStripLabel TStrLbl_Off;
        private System.Windows.Forms.ToolStripLabel TStrLbl_Delete;
        private System.Windows.Forms.ListBox Lbx_Appliance;
    }
}

