﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Main.ApplicationControl;


namespace Main.Models
{
	internal sealed class AppliancesFactory
	{
		private readonly Random _random = new();
		private readonly int _min;
		private readonly int _max;


		public AppliancesFactory(int min, int max)
		{
			_min = min;
			_max = max;
		}


		public Appliance Make() =>
			new()
			{
				Title = $"Title {_random.Next(_min, _max)}",
				Power = _random.Next(_min, _max),
				Price = (decimal)_random.RealNextDouble(_min, _max)
			};
	}
}
