﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Windows.Forms;
using Main.ApplicationControl;
using Main.Common;
using Main.Models;
using Main.Views;


namespace Main.Presenters
{
	internal sealed class MainPresenter : BasePresenter<IMainFormView>
	{
		private readonly ApplianceValidator _validator = new();
		private BindingList<Appliance> _appliances = new();
		private BindingSource _source;


		public MainPresenter(IMainFormView view, IApplicationController controller)
			: base(view, controller)
		{
			ViewOnFillRequired();

			_source = new(_appliances, null);
			View.SetBindingAppliances(_source);

			View.ValidateRequired     += ViewOnValidateRequired;
			View.FillRequired         += ViewOnFillRequired;
			View.ShuffleRequired      += ViewOnShuffleRequired;

			View.OrderByTitleRequired += () => ViewOnOrderBy(a => a.Title);
			View.OrderByPowerRequired += () => ViewOnOrderBy(a => a.Power);

			View.EnableAllRequired    += () => ViewOnChangeStateForAll(true);
			View.DisableAllRequired    += () => ViewOnChangeStateForAll(false);

			View.ClearRequired += () => _appliances.Clear();
		}


		private void ViewOnChangeStateForAll(bool newState)
		{
			foreach (var appliance in _appliances)
				appliance.State = newState;

			_appliances.ResetBindings();
		}


		private void ViewOnOrderBy<TProperty>(Func<Appliance, TProperty> selector)
		{
			var newList = new BindingList<Appliance>
				(_appliances.OrderBy(a => a.Title).ToList());

			_source.DataSource = _appliances = newList;
		}


		private void ViewOnShuffleRequired()
		{
			Random rand = new();

			for (int i = 0; i < _appliances.Count; i++)
			{
				int lhs = rand.Next(_appliances.Count);
				int rhs = rand.Next(_appliances.Count);

				(_appliances[lhs], _appliances[rhs]) =
					(_appliances[rhs], _appliances[lhs]);
			}
		}


		private void ViewOnFillRequired()
		{
			_appliances.Clear();

			var factory = new AppliancesFactory(100, 800);
			int size = new Random().Next(7, 23);

			for (int i = 0; i < size; i++)
				_appliances.Add(factory.Make());
		}


		private void ViewOnValidateRequired(DataGridView grid, DataGridViewCellCancelEventArgs e)
		{
			var appliance = _appliances[e.RowIndex];

			var validationResults = _validator.Validate(appliance);

			if (!validationResults.IsValid)
			{
				grid.Rows[e.RowIndex].ErrorText = validationResults.ToString();

				e.Cancel = true;
				return;
			}

			grid.Rows[e.RowIndex].ErrorText = null;
		}
	}
}