﻿namespace Main.Models
{
	public sealed class Appliance
	{
		public int Power { get; set; }
		public decimal Price { get; set; }
		public bool State { get; set; }
		public string? Title { get; set; }


		public Appliance() { }


		public Appliance(string title, int power, decimal price, bool state)
		{
			Title = title;
			Power = power;
			Price = price;
			State = state;
		}
	}
}