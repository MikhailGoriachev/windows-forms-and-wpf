﻿using System;
using System.Windows.Forms;
using Main.Common;


namespace Main.ApplicationControl
{
	internal interface IApplicationController
	{
		TPresenter Run<TPresenter>() where TPresenter : IPresenter;


		TPresenter Run<TPresenter>(Action<Form> onStartup) where TPresenter : IPresenter;
	}
}