﻿namespace Main.Views
{
	partial class MainForm
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
			this.ApplianceBindingSource = new System.Windows.Forms.BindingSource(this.components);
			this.MainGridView = new System.Windows.Forms.DataGridView();
			this.titleDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.priceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.powerDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.stateDataGridViewCheckBoxColumn = new System.Windows.Forms.DataGridViewCheckBoxColumn();
			this.MainGridContextMenu = new System.Windows.Forms.ContextMenuStrip(this.components);
			this.FillContextMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.ShuffleContextMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.OrderByTitleContextMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.OrderByPowerContextMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.EnableAllContextMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.DisableAllContextMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.ClearContextMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			((System.ComponentModel.ISupportInitialize)(this.ApplianceBindingSource)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.MainGridView)).BeginInit();
			this.MainGridContextMenu.SuspendLayout();
			this.SuspendLayout();
			// 
			// ApplianceBindingSource
			// 
			this.ApplianceBindingSource.DataSource = typeof(Main.Models.Appliance);
			// 
			// MainGridView
			// 
			this.MainGridView.AutoGenerateColumns = false;
			this.MainGridView.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
			dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
			dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
			dataGridViewCellStyle1.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
			dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
			dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
			dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
			dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
			this.MainGridView.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
			this.MainGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.MainGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.titleDataGridViewTextBoxColumn,
            this.priceDataGridViewTextBoxColumn,
            this.powerDataGridViewTextBoxColumn,
            this.stateDataGridViewCheckBoxColumn});
			this.MainGridView.ContextMenuStrip = this.MainGridContextMenu;
			this.MainGridView.DataSource = this.ApplianceBindingSource;
			dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
			dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Window;
			dataGridViewCellStyle4.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
			dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.ControlText;
			dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
			dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
			dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
			this.MainGridView.DefaultCellStyle = dataGridViewCellStyle4;
			this.MainGridView.Dock = System.Windows.Forms.DockStyle.Fill;
			this.MainGridView.Location = new System.Drawing.Point(0, 0);
			this.MainGridView.Name = "MainGridView";
			dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
			dataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Control;
			dataGridViewCellStyle5.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
			dataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.WindowText;
			dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
			dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
			dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
			this.MainGridView.RowHeadersDefaultCellStyle = dataGridViewCellStyle5;
			this.MainGridView.Size = new System.Drawing.Size(800, 450);
			this.MainGridView.TabIndex = 1;
			this.MainGridView.RowValidating += new System.Windows.Forms.DataGridViewCellCancelEventHandler(this.MainGridView_RowValidating);
			// 
			// titleDataGridViewTextBoxColumn
			// 
			this.titleDataGridViewTextBoxColumn.DataPropertyName = "Title";
			this.titleDataGridViewTextBoxColumn.HeaderText = "Title";
			this.titleDataGridViewTextBoxColumn.Name = "titleDataGridViewTextBoxColumn";
			this.titleDataGridViewTextBoxColumn.Width = 350;
			// 
			// priceDataGridViewTextBoxColumn
			// 
			this.priceDataGridViewTextBoxColumn.DataPropertyName = "Price";
			dataGridViewCellStyle2.Format = "C2";
			dataGridViewCellStyle2.NullValue = null;
			this.priceDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle2;
			this.priceDataGridViewTextBoxColumn.HeaderText = "Price";
			this.priceDataGridViewTextBoxColumn.Name = "priceDataGridViewTextBoxColumn";
			this.priceDataGridViewTextBoxColumn.Width = 150;
			// 
			// powerDataGridViewTextBoxColumn
			// 
			this.powerDataGridViewTextBoxColumn.DataPropertyName = "Power";
			dataGridViewCellStyle3.Format = "N0";
			this.powerDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle3;
			this.powerDataGridViewTextBoxColumn.HeaderText = "Power";
			this.powerDataGridViewTextBoxColumn.Name = "powerDataGridViewTextBoxColumn";
			this.powerDataGridViewTextBoxColumn.Width = 150;
			// 
			// stateDataGridViewCheckBoxColumn
			// 
			this.stateDataGridViewCheckBoxColumn.DataPropertyName = "State";
			this.stateDataGridViewCheckBoxColumn.HeaderText = "State";
			this.stateDataGridViewCheckBoxColumn.Name = "stateDataGridViewCheckBoxColumn";
			this.stateDataGridViewCheckBoxColumn.Width = 65;
			// 
			// MainGridContextMenu
			// 
			this.MainGridContextMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.FillContextMenuItem,
            this.ShuffleContextMenuItem,
            this.OrderByTitleContextMenuItem,
            this.OrderByPowerContextMenuItem,
            this.EnableAllContextMenuItem,
            this.DisableAllContextMenuItem,
            this.ClearContextMenuItem});
			this.MainGridContextMenu.Name = "contextMenuStrip1";
			this.MainGridContextMenu.Size = new System.Drawing.Size(232, 180);
			// 
			// FillContextMenuItem
			// 
			this.FillContextMenuItem.Name = "FillContextMenuItem";
			this.FillContextMenuItem.Size = new System.Drawing.Size(231, 22);
			this.FillContextMenuItem.Text = "Формирование коллекции";
			this.FillContextMenuItem.Click += new System.EventHandler(this.FillContextMenuItem_Click);
			// 
			// ShuffleContextMenuItem
			// 
			this.ShuffleContextMenuItem.Name = "ShuffleContextMenuItem";
			this.ShuffleContextMenuItem.Size = new System.Drawing.Size(231, 22);
			this.ShuffleContextMenuItem.Text = "Перемешивание элементов";
			this.ShuffleContextMenuItem.Click += new System.EventHandler(this.ShuffleContextMenuItem_Click);
			// 
			// OrderByTitleContextMenuItem
			// 
			this.OrderByTitleContextMenuItem.Name = "OrderByTitleContextMenuItem";
			this.OrderByTitleContextMenuItem.Size = new System.Drawing.Size(231, 22);
			this.OrderByTitleContextMenuItem.Text = "Сортировка по названию";
			this.OrderByTitleContextMenuItem.Click += new System.EventHandler(this.OrderByTitleContextMenuItem_Click);
			// 
			// OrderByPowerContextMenuItem
			// 
			this.OrderByPowerContextMenuItem.Name = "OrderByPowerContextMenuItem";
			this.OrderByPowerContextMenuItem.Size = new System.Drawing.Size(231, 22);
			this.OrderByPowerContextMenuItem.Text = "Сортировка по мощности";
			this.OrderByPowerContextMenuItem.Click += new System.EventHandler(this.OrderByPowerContextMenuItem_Click);
			// 
			// EnableAllContextMenuItem
			// 
			this.EnableAllContextMenuItem.Name = "EnableAllContextMenuItem";
			this.EnableAllContextMenuItem.Size = new System.Drawing.Size(231, 22);
			this.EnableAllContextMenuItem.Text = "Включение всех приборов";
			this.EnableAllContextMenuItem.Click += new System.EventHandler(this.EnableAllContextMenuItem_Click);
			// 
			// DisableAllContextMenuItem
			// 
			this.DisableAllContextMenuItem.Name = "DisableAllContextMenuItem";
			this.DisableAllContextMenuItem.Size = new System.Drawing.Size(231, 22);
			this.DisableAllContextMenuItem.Text = "Выключение всех приборов";
			this.DisableAllContextMenuItem.Click += new System.EventHandler(this.DisableAllContextMenuItem_Click);
			// 
			// ClearContextMenuItem
			// 
			this.ClearContextMenuItem.Name = "ClearContextMenuItem";
			this.ClearContextMenuItem.Size = new System.Drawing.Size(231, 22);
			this.ClearContextMenuItem.Text = "Удаление всех";
			this.ClearContextMenuItem.Click += new System.EventHandler(this.ClearContextMenuItem_Click);
			// 
			// MainForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(800, 450);
			this.Controls.Add(this.MainGridView);
			this.Name = "MainForm";
			this.Text = "MainForm";
			((System.ComponentModel.ISupportInitialize)(this.ApplianceBindingSource)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.MainGridView)).EndInit();
			this.MainGridContextMenu.ResumeLayout(false);
			this.ResumeLayout(false);

		}

		#endregion
		private System.Windows.Forms.BindingSource ApplianceBindingSource;
		private System.Windows.Forms.DataGridView MainGridView;
		private System.Windows.Forms.DataGridViewTextBoxColumn titleDataGridViewTextBoxColumn;
		private System.Windows.Forms.DataGridViewTextBoxColumn priceDataGridViewTextBoxColumn;
		private System.Windows.Forms.DataGridViewTextBoxColumn powerDataGridViewTextBoxColumn;
		private System.Windows.Forms.DataGridViewCheckBoxColumn stateDataGridViewCheckBoxColumn;
		private System.Windows.Forms.ContextMenuStrip MainGridContextMenu;
		private System.Windows.Forms.ToolStripMenuItem FillContextMenuItem;
		private System.Windows.Forms.ToolStripMenuItem ShuffleContextMenuItem;
		private System.Windows.Forms.ToolStripMenuItem OrderByTitleContextMenuItem;
		private System.Windows.Forms.ToolStripMenuItem OrderByPowerContextMenuItem;
		private System.Windows.Forms.ToolStripMenuItem EnableAllContextMenuItem;
		private System.Windows.Forms.ToolStripMenuItem DisableAllContextMenuItem;
		private System.Windows.Forms.ToolStripMenuItem ClearContextMenuItem;
	}
}