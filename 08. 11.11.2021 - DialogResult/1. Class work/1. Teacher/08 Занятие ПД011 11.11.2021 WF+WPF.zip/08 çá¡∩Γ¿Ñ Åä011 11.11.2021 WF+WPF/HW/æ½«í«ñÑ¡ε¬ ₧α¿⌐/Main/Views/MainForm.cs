﻿using System;
using System.Windows.Forms;
using Main.Common;


namespace Main.Views
{
	internal interface IMainFormView : IView
	{
		event Action ClearRequired;
		event Action DisableAllRequired;
		event Action EnableAllRequired;
		event Action FillRequired;
		event Action OrderByPowerRequired;
		event Action OrderByTitleRequired;

		void SetBindingAppliances(BindingSource source);

		event Action ShuffleRequired;

		event Action<DataGridView, DataGridViewCellCancelEventArgs> ValidateRequired;
	}


	public sealed partial class MainForm : BaseForm, IMainFormView
	{
		private readonly ApplicationContext _context;


		public MainForm(ApplicationContext context)
		{
			InitializeComponent();
			_context = context;
		}


		public event Action? ClearRequired;
		public event Action? DisableAllRequired;
		public event Action? EnableAllRequired;
		public event Action? FillRequired;
		public event Action? OrderByPowerRequired;
		public event Action? OrderByTitleRequired;


		public void SetBindingAppliances(BindingSource source) =>
			MainGridView.DataSource = source;


		public event Action? ShuffleRequired;


		public event Action<DataGridView, DataGridViewCellCancelEventArgs>? ValidateRequired;


		public new void Show()
		{
			_context.MainForm = this;
			Application.Run(_context);
		}


		private void ClearContextMenuItem_Click(object sender, EventArgs e) =>
			ClearRequired?.Invoke();


		private void DisableAllContextMenuItem_Click(object sender, EventArgs e) =>
			DisableAllRequired?.Invoke();


		private void EnableAllContextMenuItem_Click(object sender, EventArgs e) =>
			EnableAllRequired?.Invoke();


		private void FillContextMenuItem_Click(object sender, EventArgs e) =>
			FillRequired?.Invoke();


		private void MainGridView_RowValidating(object sender, DataGridViewCellCancelEventArgs e) =>
			ValidateRequired?.Invoke((DataGridView)sender, e);


		private void OrderByPowerContextMenuItem_Click(object sender, EventArgs e) =>
			OrderByPowerRequired?.Invoke();


		private void OrderByTitleContextMenuItem_Click(object sender, EventArgs e) =>
			OrderByTitleRequired?.Invoke();


		private void ShuffleContextMenuItem_Click(object sender, EventArgs e) =>
			ShuffleRequired?.Invoke();
	}
}