﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using FluentValidation;


namespace Main.Models
{
	internal class ApplianceValidator : AbstractValidator<Appliance>
	{
		public ApplianceValidator()
		{
			RuleFor(a => a.Title)
				.Must(s => !string.IsNullOrWhiteSpace(s))
				.WithMessage("Название должно быть");

			RuleFor(a => a.Price)
				.GreaterThan(0)
				.WithMessage("Цена не может быть отрицательной");

			RuleFor(a => a.Power)
				.GreaterThan(0)
				.WithMessage("Мощность не может быть отрицательной");
		}
	}
}