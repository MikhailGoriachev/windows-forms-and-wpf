﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;

namespace MultiWindow.Views
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow() {
            InitializeComponent();
        } // MainWindow

        // Открыть окно со сведениями о приложении и разработчике
        private void About_Click(object sender, RoutedEventArgs e) {
            AboutWindow aboutWindow = new AboutWindow();
            aboutWindow.ShowDialog();
        } // About_Click

        // Завершить работу приложения
        private void Exit_Click(object sender, RoutedEventArgs e) {
            Close();
        } // Exit_Click

        // вычисление параметров прямоугольного паоаллелепипеда
        private void ParallelepipedCalc_Click(object sender, RoutedEventArgs e) {
            ParallelepipedWindow parallelepipedWindow = new ParallelepipedWindow();
            parallelepipedWindow.ShowDialog();
        } // ParallelepipedCalc_Click

        #region Изменение цвета надписи на кнопке при перемещении курсора мыши на кнопку
        private void Button_MouseEnter(object sender, MouseEventArgs e){
            Button btn = e.OriginalSource as Button;
            btn.Foreground = new SolidColorBrush(Color.FromArgb(255, 0, 0, 0));
        } // Button_MouseEnter

        private void Button_MouseLeave(object sender, MouseEventArgs e) {
            Button btn = e.OriginalSource as Button;
            btn.Foreground = new SolidColorBrush(Colors.White);
        } // Button_MouseLeave
        #endregion

        // Расчет учеченного конуса
        private void ConoidCalc_Click(object sender, RoutedEventArgs e) {
            ConoidWindow conoidWindow = new ConoidWindow();
            conoidWindow.ShowDialog();
        } // ConoidCalc_Click
    } // class MainWindow
}
