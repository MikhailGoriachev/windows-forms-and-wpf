﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using MultiWindow.Models;

namespace MultiWindow.Views
{
    /// <summary>
    /// Логика взаимодействия для ParallelepipedWindow.xaml
    /// </summary>
    public partial class ParallelepipedWindow : Window
    {
        // Модель - прямоугольный параллелепипед
        private Parallelepiped _parallelepiped;

        public ParallelepipedWindow():this(new Parallelepiped()) { }

        public ParallelepipedWindow(Parallelepiped parallelepiped) {
            InitializeComponent();
            _parallelepiped = parallelepiped;

            // Записать значения модели в элементы интерфейса, поля ввода
            TxbSideA.Text = $"{_parallelepiped.A:n3}";
            TxbSideB.Text = $"{_parallelepiped.B:n3}";
            TxbSideC.Text = $"{_parallelepiped.C:n3}";
            TxbDensity.Text = $"{_parallelepiped.Density:n3}";
        } // ParallelepipedWindow
        

        #region Изменение цвета надписи на кнопке при перемещении курсора мыши на кнопку
        private void Button_MouseEnter(object sender, MouseEventArgs e) {
            Button btn = sender as Button;
            btn.Foreground = new SolidColorBrush(Color.FromArgb(255, 0, 0, 0));
        } // Button_MouseEnter


        private void Button_MouseLeave(object sender, MouseEventArgs e) {
            Button btn = sender as Button;
            btn.Foreground = new SolidColorBrush(Color.FromArgb(255, 255, 255, 255));
        } // Button_MouseLeave
        #endregion


        // Вычисление параметров фигуры по заданию
        private void Calculate_Click(object sender, RoutedEventArgs e) {
            try {
                // Получить данные от элементов управления
                _parallelepiped.A = double.Parse(TxbSideA.Text);
                _parallelepiped.B = double.Parse(TxbSideB.Text);
                _parallelepiped.C = double.Parse(TxbSideC.Text);
                _parallelepiped.Density = double.Parse(TxbDensity.Text);

                // Вычислить параметры тела в зависимости от установленных чек-боксов
                TblArea.Text = CbxArea.IsChecked == true
                    ? $"{_parallelepiped.Area:n3}"
                    : "Расчет не задан";

                TblVolume.Text = CbxVolume.IsChecked == true
                    ? $"{_parallelepiped.Volume:n3}"
                    : "Расчет не задан";

                TblMass.Text = CbxMass.IsChecked == true
                    ? $"{_parallelepiped.Mass:n3}"
                    : "Расчет не задан";
            } catch (Exception ex) {
                MessageBox.Show(ex.Message, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            } // try-catch
        } // Calculate_Click

        private void Close_Click(object sender, RoutedEventArgs e) => Close();
    } // class ParallelepipedWindow
}
