﻿
namespace TrainTickets.Views
{
    partial class MainForm
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.MnuMain = new System.Windows.Forms.MenuStrip();
            this.MniFile = new System.Windows.Forms.ToolStripMenuItem();
            this.MniFileNew = new System.Windows.Forms.ToolStripMenuItem();
            this.MniFileSep1 = new System.Windows.Forms.ToolStripSeparator();
            this.MniFileOpen = new System.Windows.Forms.ToolStripMenuItem();
            this.MniFileSave = new System.Windows.Forms.ToolStripMenuItem();
            this.MniFileSaveAs = new System.Windows.Forms.ToolStripMenuItem();
            this.MniFileSep2 = new System.Windows.Forms.ToolStripSeparator();
            this.MniFileExit = new System.Windows.Forms.ToolStripMenuItem();
            this.MniTrain = new System.Windows.Forms.ToolStripMenuItem();
            this.MniTrainCarriageAdd = new System.Windows.Forms.ToolStripMenuItem();
            this.MniTrainCarriageRemove = new System.Windows.Forms.ToolStripMenuItem();
            this.MniTicket = new System.Windows.Forms.ToolStripMenuItem();
            this.MniTicketSold = new System.Windows.Forms.ToolStripMenuItem();
            this.MniTicketBack = new System.Windows.Forms.ToolStripMenuItem();
            this.MniHelp = new System.Windows.Forms.ToolStripMenuItem();
            this.MniHelpAbout = new System.Windows.Forms.ToolStripMenuItem();
            this.TstMain = new System.Windows.Forms.ToolStrip();
            this.TsbNewTrain = new System.Windows.Forms.ToolStripButton();
            this.TsbOpen = new System.Windows.Forms.ToolStripButton();
            this.TsbSave = new System.Windows.Forms.ToolStripButton();
            this.TstMainSep1 = new System.Windows.Forms.ToolStripSeparator();
            this.TsbCarriageAdd = new System.Windows.Forms.ToolStripButton();
            this.TsbCarriageRemove = new System.Windows.Forms.ToolStripButton();
            this.TstMainSep2 = new System.Windows.Forms.ToolStripSeparator();
            this.TsbTicketSold = new System.Windows.Forms.ToolStripButton();
            this.TsbTicketBack = new System.Windows.Forms.ToolStripButton();
            this.TstMainSep3 = new System.Windows.Forms.ToolStripSeparator();
            this.TsbAbout = new System.Windows.Forms.ToolStripButton();
            this.TsbExit = new System.Windows.Forms.ToolStripButton();
            this.StsMain = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel2 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel3 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel4 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel5 = new System.Windows.Forms.ToolStripStatusLabel();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.TrvTrain = new System.Windows.Forms.TreeView();
            this.DgvCarriageView = new System.Windows.Forms.DataGridView();
            this.OfdMain = new System.Windows.Forms.OpenFileDialog();
            this.SfdMain = new System.Windows.Forms.SaveFileDialog();
            this.numberDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.carriageTypeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.compartmentNumberDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.seatNumberDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.soldDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.BnsCarriageView = new System.Windows.Forms.BindingSource(this.components);
            this.MnuMain.SuspendLayout();
            this.TstMain.SuspendLayout();
            this.StsMain.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DgvCarriageView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BnsCarriageView)).BeginInit();
            this.SuspendLayout();
            // 
            // MnuMain
            // 
            this.MnuMain.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.MnuMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniFile,
            this.MniTrain,
            this.MniTicket,
            this.MniHelp});
            this.MnuMain.Location = new System.Drawing.Point(0, 0);
            this.MnuMain.Name = "MnuMain";
            this.MnuMain.Size = new System.Drawing.Size(1179, 28);
            this.MnuMain.TabIndex = 0;
            this.MnuMain.Text = "menuStrip1";
            // 
            // MniFile
            // 
            this.MniFile.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniFileNew,
            this.MniFileSep1,
            this.MniFileOpen,
            this.MniFileSave,
            this.MniFileSaveAs,
            this.MniFileSep2,
            this.MniFileExit});
            this.MniFile.Name = "MniFile";
            this.MniFile.Size = new System.Drawing.Size(57, 24);
            this.MniFile.Text = "Файл";
            // 
            // MniFileNew
            // 
            this.MniFileNew.Image = global::TrainTickets.Properties.Resources._new;
            this.MniFileNew.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MniFileNew.Name = "MniFileNew";
            this.MniFileNew.Size = new System.Drawing.Size(203, 38);
            this.MniFileNew.Text = "Новый";
            // 
            // MniFileSep1
            // 
            this.MniFileSep1.Name = "MniFileSep1";
            this.MniFileSep1.Size = new System.Drawing.Size(200, 6);
            // 
            // MniFileOpen
            // 
            this.MniFileOpen.Image = global::TrainTickets.Properties.Resources.open;
            this.MniFileOpen.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MniFileOpen.Name = "MniFileOpen";
            this.MniFileOpen.Size = new System.Drawing.Size(203, 38);
            this.MniFileOpen.Text = "Открыть..";
            this.MniFileOpen.Click += new System.EventHandler(this.OpenFile_Command);
            // 
            // MniFileSave
            // 
            this.MniFileSave.Enabled = false;
            this.MniFileSave.Image = global::TrainTickets.Properties.Resources.save;
            this.MniFileSave.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MniFileSave.Name = "MniFileSave";
            this.MniFileSave.Size = new System.Drawing.Size(203, 38);
            this.MniFileSave.Text = "Сохранить";
            this.MniFileSave.Click += new System.EventHandler(this.Save_Command);
            // 
            // MniFileSaveAs
            // 
            this.MniFileSaveAs.Image = global::TrainTickets.Properties.Resources.save_as;
            this.MniFileSaveAs.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MniFileSaveAs.Name = "MniFileSaveAs";
            this.MniFileSaveAs.Size = new System.Drawing.Size(203, 38);
            this.MniFileSaveAs.Text = "Сохранить как...";
            this.MniFileSaveAs.Click += new System.EventHandler(this.SaveAs_Command);
            // 
            // MniFileSep2
            // 
            this.MniFileSep2.Name = "MniFileSep2";
            this.MniFileSep2.Size = new System.Drawing.Size(200, 6);
            // 
            // MniFileExit
            // 
            this.MniFileExit.Image = global::TrainTickets.Properties.Resources.exit;
            this.MniFileExit.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MniFileExit.Name = "MniFileExit";
            this.MniFileExit.Size = new System.Drawing.Size(203, 38);
            this.MniFileExit.Text = "Выход";
            this.MniFileExit.Click += new System.EventHandler(this.Exit_Command);
            // 
            // MniTrain
            // 
            this.MniTrain.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniTrainCarriageAdd,
            this.MniTrainCarriageRemove});
            this.MniTrain.Name = "MniTrain";
            this.MniTrain.Size = new System.Drawing.Size(64, 24);
            this.MniTrain.Text = "Поезд";
            // 
            // MniTrainCarriageAdd
            // 
            this.MniTrainCarriageAdd.Image = global::TrainTickets.Properties.Resources.carriage_add;
            this.MniTrainCarriageAdd.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MniTrainCarriageAdd.Name = "MniTrainCarriageAdd";
            this.MniTrainCarriageAdd.Size = new System.Drawing.Size(214, 38);
            this.MniTrainCarriageAdd.Text = "Добавить вагон...";
            // 
            // MniTrainCarriageRemove
            // 
            this.MniTrainCarriageRemove.Image = global::TrainTickets.Properties.Resources.carriage_delete;
            this.MniTrainCarriageRemove.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MniTrainCarriageRemove.Name = "MniTrainCarriageRemove";
            this.MniTrainCarriageRemove.Size = new System.Drawing.Size(214, 38);
            this.MniTrainCarriageRemove.Text = "Удалить вагон... ";
            // 
            // MniTicket
            // 
            this.MniTicket.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniTicketSold,
            this.MniTicketBack});
            this.MniTicket.Name = "MniTicket";
            this.MniTicket.Size = new System.Drawing.Size(72, 24);
            this.MniTicket.Text = "Билеты";
            // 
            // MniTicketSold
            // 
            this.MniTicketSold.Image = global::TrainTickets.Properties.Resources.sold_ticket;
            this.MniTicketSold.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MniTicketSold.Name = "MniTicketSold";
            this.MniTicketSold.Size = new System.Drawing.Size(162, 38);
            this.MniTicketSold.Text = "Продать...";
            // 
            // MniTicketBack
            // 
            this.MniTicketBack.Image = global::TrainTickets.Properties.Resources.back_ticket;
            this.MniTicketBack.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MniTicketBack.Name = "MniTicketBack";
            this.MniTicketBack.Size = new System.Drawing.Size(162, 38);
            this.MniTicketBack.Text = "Вернуть...";
            // 
            // MniHelp
            // 
            this.MniHelp.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniHelpAbout});
            this.MniHelp.Name = "MniHelp";
            this.MniHelp.Size = new System.Drawing.Size(79, 24);
            this.MniHelp.Text = "Справка";
            // 
            // MniHelpAbout
            // 
            this.MniHelpAbout.Image = global::TrainTickets.Properties.Resources.help;
            this.MniHelpAbout.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MniHelpAbout.Name = "MniHelpAbout";
            this.MniHelpAbout.Size = new System.Drawing.Size(198, 38);
            this.MniHelpAbout.Text = "О программе...";
            this.MniHelpAbout.Click += new System.EventHandler(this.About_Command);
            // 
            // TstMain
            // 
            this.TstMain.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TstMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.TsbNewTrain,
            this.TsbOpen,
            this.TsbSave,
            this.TstMainSep1,
            this.TsbCarriageAdd,
            this.TsbCarriageRemove,
            this.TstMainSep2,
            this.TsbTicketSold,
            this.TsbTicketBack,
            this.TstMainSep3,
            this.TsbAbout,
            this.TsbExit});
            this.TstMain.Location = new System.Drawing.Point(0, 28);
            this.TstMain.Name = "TstMain";
            this.TstMain.Size = new System.Drawing.Size(1179, 39);
            this.TstMain.TabIndex = 1;
            this.TstMain.Text = "toolStrip1";
            // 
            // TsbNewTrain
            // 
            this.TsbNewTrain.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbNewTrain.Image = global::TrainTickets.Properties.Resources._new;
            this.TsbNewTrain.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbNewTrain.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbNewTrain.Name = "TsbNewTrain";
            this.TsbNewTrain.Size = new System.Drawing.Size(36, 36);
            this.TsbNewTrain.ToolTipText = "Новый поезд";
            // 
            // TsbOpen
            // 
            this.TsbOpen.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbOpen.Image = global::TrainTickets.Properties.Resources.open;
            this.TsbOpen.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbOpen.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbOpen.Name = "TsbOpen";
            this.TsbOpen.Size = new System.Drawing.Size(36, 36);
            this.TsbOpen.ToolTipText = "Открыть файл данных";
            this.TsbOpen.Click += new System.EventHandler(this.OpenFile_Command);
            // 
            // TsbSave
            // 
            this.TsbSave.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbSave.Enabled = false;
            this.TsbSave.Image = global::TrainTickets.Properties.Resources.save;
            this.TsbSave.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbSave.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbSave.Name = "TsbSave";
            this.TsbSave.Size = new System.Drawing.Size(36, 36);
            this.TsbSave.ToolTipText = "Сохранить файл данных";
            this.TsbSave.Click += new System.EventHandler(this.Save_Command);
            // 
            // TstMainSep1
            // 
            this.TstMainSep1.Name = "TstMainSep1";
            this.TstMainSep1.Size = new System.Drawing.Size(6, 39);
            // 
            // TsbCarriageAdd
            // 
            this.TsbCarriageAdd.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbCarriageAdd.Image = global::TrainTickets.Properties.Resources.carriage_add;
            this.TsbCarriageAdd.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbCarriageAdd.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbCarriageAdd.Name = "TsbCarriageAdd";
            this.TsbCarriageAdd.Size = new System.Drawing.Size(36, 36);
            this.TsbCarriageAdd.ToolTipText = "Добавить вагон";
            // 
            // TsbCarriageRemove
            // 
            this.TsbCarriageRemove.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbCarriageRemove.Image = global::TrainTickets.Properties.Resources.carriage_delete;
            this.TsbCarriageRemove.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbCarriageRemove.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbCarriageRemove.Name = "TsbCarriageRemove";
            this.TsbCarriageRemove.Size = new System.Drawing.Size(36, 36);
            this.TsbCarriageRemove.ToolTipText = "Удалить вагон";
            // 
            // TstMainSep2
            // 
            this.TstMainSep2.Name = "TstMainSep2";
            this.TstMainSep2.Size = new System.Drawing.Size(6, 39);
            // 
            // TsbTicketSold
            // 
            this.TsbTicketSold.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbTicketSold.Image = global::TrainTickets.Properties.Resources.sold_ticket;
            this.TsbTicketSold.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbTicketSold.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbTicketSold.Name = "TsbTicketSold";
            this.TsbTicketSold.Size = new System.Drawing.Size(36, 36);
            this.TsbTicketSold.ToolTipText = "Продать билет";
            // 
            // TsbTicketBack
            // 
            this.TsbTicketBack.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbTicketBack.Image = global::TrainTickets.Properties.Resources.back_ticket;
            this.TsbTicketBack.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbTicketBack.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbTicketBack.Name = "TsbTicketBack";
            this.TsbTicketBack.Size = new System.Drawing.Size(36, 36);
            this.TsbTicketBack.ToolTipText = "Сдать билет";
            // 
            // TstMainSep3
            // 
            this.TstMainSep3.Name = "TstMainSep3";
            this.TstMainSep3.Size = new System.Drawing.Size(6, 39);
            // 
            // TsbAbout
            // 
            this.TsbAbout.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbAbout.Image = global::TrainTickets.Properties.Resources.help;
            this.TsbAbout.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbAbout.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbAbout.Name = "TsbAbout";
            this.TsbAbout.Size = new System.Drawing.Size(36, 36);
            this.TsbAbout.ToolTipText = "Сведения о приложении \r\nи разработчике";
            this.TsbAbout.Click += new System.EventHandler(this.About_Command);
            // 
            // TsbExit
            // 
            this.TsbExit.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.TsbExit.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbExit.Image = global::TrainTickets.Properties.Resources.exit;
            this.TsbExit.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbExit.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbExit.Name = "TsbExit";
            this.TsbExit.Size = new System.Drawing.Size(36, 36);
            this.TsbExit.ToolTipText = "Выход из приложения";
            this.TsbExit.Click += new System.EventHandler(this.Exit_Command);
            // 
            // StsMain
            // 
            this.StsMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1,
            this.toolStripStatusLabel2,
            this.toolStripStatusLabel3,
            this.toolStripStatusLabel4,
            this.toolStripStatusLabel5});
            this.StsMain.Location = new System.Drawing.Point(0, 632);
            this.StsMain.Name = "StsMain";
            this.StsMain.Size = new System.Drawing.Size(1179, 22);
            this.StsMain.TabIndex = 2;
            this.StsMain.Text = "statusStrip1";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(131, 17);
            this.toolStripStatusLabel1.Text = "toolStripStatusLabel1";
            // 
            // toolStripStatusLabel2
            // 
            this.toolStripStatusLabel2.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.toolStripStatusLabel2.Name = "toolStripStatusLabel2";
            this.toolStripStatusLabel2.Size = new System.Drawing.Size(131, 17);
            this.toolStripStatusLabel2.Text = "toolStripStatusLabel2";
            // 
            // toolStripStatusLabel3
            // 
            this.toolStripStatusLabel3.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.toolStripStatusLabel3.Name = "toolStripStatusLabel3";
            this.toolStripStatusLabel3.Size = new System.Drawing.Size(131, 17);
            this.toolStripStatusLabel3.Text = "toolStripStatusLabel3";
            // 
            // toolStripStatusLabel4
            // 
            this.toolStripStatusLabel4.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.toolStripStatusLabel4.Name = "toolStripStatusLabel4";
            this.toolStripStatusLabel4.Size = new System.Drawing.Size(131, 17);
            this.toolStripStatusLabel4.Text = "toolStripStatusLabel4";
            // 
            // toolStripStatusLabel5
            // 
            this.toolStripStatusLabel5.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.toolStripStatusLabel5.Name = "toolStripStatusLabel5";
            this.toolStripStatusLabel5.Size = new System.Drawing.Size(131, 17);
            this.toolStripStatusLabel5.Text = "toolStripStatusLabel5";
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 67);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.TrvTrain);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.DgvCarriageView);
            this.splitContainer1.Size = new System.Drawing.Size(1179, 565);
            this.splitContainer1.SplitterDistance = 393;
            this.splitContainer1.TabIndex = 3;
            // 
            // TrvTrain
            // 
            this.TrvTrain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TrvTrain.Location = new System.Drawing.Point(0, 0);
            this.TrvTrain.Name = "TrvTrain";
            this.TrvTrain.Size = new System.Drawing.Size(393, 565);
            this.TrvTrain.TabIndex = 0;
            // 
            // DgvCarriageView
            // 
            this.DgvCarriageView.AllowDrop = true;
            this.DgvCarriageView.AllowUserToAddRows = false;
            this.DgvCarriageView.AllowUserToDeleteRows = false;
            this.DgvCarriageView.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.DgvCarriageView.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.DgvCarriageView.AutoGenerateColumns = false;
            this.DgvCarriageView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.DgvCarriageView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DgvCarriageView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.numberDataGridViewTextBoxColumn,
            this.carriageTypeDataGridViewTextBoxColumn,
            this.compartmentNumberDataGridViewTextBoxColumn,
            this.seatNumberDataGridViewTextBoxColumn,
            this.soldDataGridViewTextBoxColumn});
            this.DgvCarriageView.DataSource = this.BnsCarriageView;
            this.DgvCarriageView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.DgvCarriageView.Location = new System.Drawing.Point(0, 0);
            this.DgvCarriageView.MultiSelect = false;
            this.DgvCarriageView.Name = "DgvCarriageView";
            this.DgvCarriageView.ReadOnly = true;
            this.DgvCarriageView.RowHeadersVisible = false;
            this.DgvCarriageView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DgvCarriageView.Size = new System.Drawing.Size(782, 565);
            this.DgvCarriageView.TabIndex = 0;
            this.DgvCarriageView.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.DgvCarriageView_CellFormatting);
            // 
            // OfdMain
            // 
            this.OfdMain.DefaultExt = "train";
            this.OfdMain.Filter = "Данные поезда (*.train)|*.train|Файлы формата JSON|*.json|Все файлы|*.*";
            this.OfdMain.Title = "Открыть файл данных поезда";
            // 
            // SfdMain
            // 
            this.SfdMain.CheckFileExists = true;
            this.SfdMain.DefaultExt = "train";
            this.SfdMain.Filter = "Данные поезда (*.train)|*.train|Файлы формата JSON|*.json|Все файлы|*.*";
            this.SfdMain.Title = "Задайте имя файла для сохранения";
            // 
            // numberDataGridViewTextBoxColumn
            // 
            this.numberDataGridViewTextBoxColumn.DataPropertyName = "Number";
            this.numberDataGridViewTextBoxColumn.HeaderText = "№ вагона";
            this.numberDataGridViewTextBoxColumn.Name = "numberDataGridViewTextBoxColumn";
            this.numberDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // carriageTypeDataGridViewTextBoxColumn
            // 
            this.carriageTypeDataGridViewTextBoxColumn.DataPropertyName = "CarriageType";
            this.carriageTypeDataGridViewTextBoxColumn.HeaderText = "Тип вагона";
            this.carriageTypeDataGridViewTextBoxColumn.Name = "carriageTypeDataGridViewTextBoxColumn";
            this.carriageTypeDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // compartmentNumberDataGridViewTextBoxColumn
            // 
            this.compartmentNumberDataGridViewTextBoxColumn.DataPropertyName = "CompartmentNumber";
            this.compartmentNumberDataGridViewTextBoxColumn.HeaderText = "Номер купе";
            this.compartmentNumberDataGridViewTextBoxColumn.Name = "compartmentNumberDataGridViewTextBoxColumn";
            this.compartmentNumberDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // seatNumberDataGridViewTextBoxColumn
            // 
            this.seatNumberDataGridViewTextBoxColumn.DataPropertyName = "SeatNumber";
            this.seatNumberDataGridViewTextBoxColumn.HeaderText = "Номер места";
            this.seatNumberDataGridViewTextBoxColumn.Name = "seatNumberDataGridViewTextBoxColumn";
            this.seatNumberDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // soldDataGridViewTextBoxColumn
            // 
            this.soldDataGridViewTextBoxColumn.DataPropertyName = "Sold";
            this.soldDataGridViewTextBoxColumn.HeaderText = "Состояние";
            this.soldDataGridViewTextBoxColumn.Name = "soldDataGridViewTextBoxColumn";
            this.soldDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // BnsCarriageView
            // 
            this.BnsCarriageView.DataSource = typeof(TrainTickets.ViewModels.CarriageView);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1179, 654);
            this.Controls.Add(this.splitContainer1);
            this.Controls.Add(this.StsMain);
            this.Controls.Add(this.TstMain);
            this.Controls.Add(this.MnuMain);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.MnuMain;
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Задание на 16.12.2021 - макет приложения по продаже билетов на поезд";
            this.MnuMain.ResumeLayout(false);
            this.MnuMain.PerformLayout();
            this.TstMain.ResumeLayout(false);
            this.TstMain.PerformLayout();
            this.StsMain.ResumeLayout(false);
            this.StsMain.PerformLayout();
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DgvCarriageView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BnsCarriageView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip MnuMain;
        private System.Windows.Forms.ToolStrip TstMain;
        private System.Windows.Forms.StatusStrip StsMain;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel2;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel3;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel4;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel5;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.TreeView TrvTrain;
        private System.Windows.Forms.DataGridView DgvCarriageView;
        private System.Windows.Forms.ToolStripMenuItem MniFile;
        private System.Windows.Forms.ToolStripMenuItem MniFileNew;
        private System.Windows.Forms.ToolStripSeparator MniFileSep1;
        private System.Windows.Forms.ToolStripMenuItem MniFileOpen;
        private System.Windows.Forms.ToolStripMenuItem MniFileSave;
        private System.Windows.Forms.ToolStripMenuItem MniFileSaveAs;
        private System.Windows.Forms.ToolStripSeparator MniFileSep2;
        private System.Windows.Forms.ToolStripMenuItem MniFileExit;
        private System.Windows.Forms.ToolStripMenuItem MniTrain;
        private System.Windows.Forms.ToolStripMenuItem MniTrainCarriageAdd;
        private System.Windows.Forms.ToolStripMenuItem MniTrainCarriageRemove;
        private System.Windows.Forms.ToolStripMenuItem MniTicket;
        private System.Windows.Forms.ToolStripMenuItem MniTicketSold;
        private System.Windows.Forms.ToolStripMenuItem MniTicketBack;
        private System.Windows.Forms.ToolStripMenuItem MniHelp;
        private System.Windows.Forms.ToolStripMenuItem MniHelpAbout;
        private System.Windows.Forms.ToolStripButton TsbNewTrain;
        private System.Windows.Forms.ToolStripButton TsbOpen;
        private System.Windows.Forms.ToolStripButton TsbSave;
        private System.Windows.Forms.ToolStripSeparator TstMainSep1;
        private System.Windows.Forms.ToolStripButton TsbCarriageAdd;
        private System.Windows.Forms.ToolStripButton TsbCarriageRemove;
        private System.Windows.Forms.ToolStripSeparator TstMainSep2;
        private System.Windows.Forms.ToolStripButton TsbTicketSold;
        private System.Windows.Forms.ToolStripButton TsbTicketBack;
        private System.Windows.Forms.ToolStripSeparator TstMainSep3;
        private System.Windows.Forms.ToolStripButton TsbAbout;
        private System.Windows.Forms.ToolStripButton TsbExit;
        private System.Windows.Forms.OpenFileDialog OfdMain;
        private System.Windows.Forms.SaveFileDialog SfdMain;
        private System.Windows.Forms.BindingSource BnsCarriageView;
        private System.Windows.Forms.DataGridViewTextBoxColumn numberDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn carriageTypeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn compartmentNumberDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn seatNumberDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn soldDataGridViewTextBoxColumn;
    }
}

