﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace TrainTickets.Models
{
    // Класс Вагон характеризуется номером вагона, количеством купе, массивом
    // купе, максимальной вместимостью купе (типом купе).
    [DataContract]
    public class Carriage
    {
        // количество купе - всегда 9
        public const int NumberCompartmens = 9;

        // вместимость купе - количество мест - однозначно определяеся типом вагона
        [DataMember]
        public readonly int Capacity;

        // номер вагона
        [DataMember]
        private int _number;
        public int Number {
            get => _number;
            set {
                if (value < 1 || value > 50)
                    throw new InvalidDataException($"Carriage: {value} - некорректный номер вагона");
                _number = value;
            } // set
        } // Number

        // массив купе
        [DataMember]
        private readonly Compartment[] _compartments;

        // индексатор для доступа к массиву купе
        public Compartment this[int index] {
            get => _compartments[index];
            set => _compartments[index] = value;
        } // Compartment
        

        #region Ансамбль конструкторов
        public Carriage():this("плацкарт") {} // Carriage

        public Carriage(string carriageType) {
            // получить емкость купе в зависимости от типа купе
            switch (carriageType) {
                case "СВ": Capacity = 2;
                    break;
                case "купе":
                    Capacity = 4;
                    break;
                case "плацкарт":
                default:
                    Capacity = 6;
                    break;
            } // switch

            // создание массива купе
            _compartments = new Compartment[NumberCompartmens];

            // начальный номер места
            int seatNumber = 1;
            for (int i = 0; i < NumberCompartmens; i++) {
                _compartments[i] = new Compartment(Capacity, ref seatNumber);
            } // for i
        } // Carriage

        #endregion

        // получить тип вагона по вместимости купе
        public string GetCarriageType() {
            switch (Capacity) {
                case 2: return "СВ";
                case 4: return "купе";
                default:
                case 6: return "плацкарт";
            }
        } // GetCarriageType
    } // class Carriage
}
