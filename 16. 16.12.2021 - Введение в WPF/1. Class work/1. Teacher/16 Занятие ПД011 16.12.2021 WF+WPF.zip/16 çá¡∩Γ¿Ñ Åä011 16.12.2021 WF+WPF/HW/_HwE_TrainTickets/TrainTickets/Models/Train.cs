﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using TrainTickets.Helpers;
using TrainTickets.ViewModels;

namespace TrainTickets.Models
{
    // Класс Поезд, хранящий коллекцию объектов класса Вагон. Максимальное
    // количество вагонов в поезде 20. Поезд характеризуется номером
    // (цифры и буквы), пунктом отправления и пунктом назначения. 
    [DataContract]
    public class Train
    {
        // номер поезда
        [DataMember]
        private string _number;
        public string Number {
            get => _number;
            set {
                if (string.IsNullOrWhiteSpace(value))
                    throw new InvalidDataException("Train: номер поезда не указан");
                _number = value;
            } // set
        } // Number

        // пункт отправления
        [DataMember]
        private string _departure;
        public string Departure {
            get => _departure;
            set {
                if (string.IsNullOrWhiteSpace(value))
                    throw new InvalidDataException("Train: пункт отправления не указан");
                _departure = value;
            } // set
        } // Departure

        // пункт назначения
        [DataMember]
        private string _destination;
        public string Destination {
            get => _destination;
            set {
                if (string.IsNullOrWhiteSpace(value))
                    throw new InvalidDataException("Train: пункт назначения не указан");
                _destination = value;
            } // set
        } // Destination

        // максимальное количество вагонов в поезде 
        public const int MaxCarriages = 20;

        // коллекция вагонов поезда
        [DataMember]
        private List<Carriage> _carriages;

        // количество вагонов поезда
        public int Count => _carriages.Count;


        #region Ансамбль конструкторов

        public Train():this("001М", "Ясиноватая", "Луганск", new List<Carriage>()) { }

        public Train(string number, string departure, string destination, List<Carriage> carriages) {
            Number = number;
            Departure = departure;
            Destination = destination;
            _carriages = carriages;
        } // Train

        #endregion

        // добавить вагон к поезду
        public Train Add(Carriage carriage) {
            if (_carriages.Count == MaxCarriages) return this;

            _carriages.Add(carriage);
            return this;
        } // Add


        // получить вагон по номеру
        public Carriage CarriageAt(int number) => _carriages[number - 1];

        // получить все вагоны
        public List<Carriage> GetAllCarriages() => _carriages;


        // сгенерировать данные поезда, коллекцию вагонов
        public void Generate() {
            // чистим старую коллекцию вагонов поезда
            _carriages.Clear();

            // типы вагонов, купе
            string[] carriageTypes = { "СВ", "купе", "плацкарт"};
            
            // данные поезда
            (string Departure, string Destination, string Number)[] points = {
                ("Ясиноватая", "Луганск", "001М"),
                ("Ясиноватая", "Горловка", "506П"),
                ("Донецк-2", "Макеевка", "504П"),
                ("Донецк-2", "Иловайск", "505П"),
                ("Ясиноватая", "Ростоа-на-Дону", "002М")
            };

            // генерация количества вагонов
            int n = Utils.GetRandom(3, MaxCarriages);
            
            // генерация данных пользователя
            int index = Utils.GetRandom(0,points.Length-1);
            (_departure, _destination, _number) = 
                (points[index].Departure, points[index].Destination, _number = points[index].Number);

            // генерация вагонов поезда
            for (int i = 0; i < n; i++) {
                _carriages.Add(new Carriage(carriageTypes[Utils.GetRandom(0, carriageTypes.Length-1)]));
            } // for i
        } // Generate0

        // удалить вагон по индексу
        public void RemoveCarriageAt(int index) {
            _carriages.RemoveAt(index);
        }


        // отбор данных из коллекции вагонов по номеру вагона в формате для отображения
        // в DataGridView
        public List<CarriageView> MapToCarriageView(int carriageNumber) {
            // итоговая коллекция
            List<CarriageView> carriageViews = new List<CarriageView>();

            // получили ссылку на вагон с номером carriageNumber
            Carriage carriage = CarriageAt(carriageNumber);

            // перебираем все купе вагона
            for (int i = 0; i < Carriage.NumberCompartmens; i++) {
                for (int j = 0; j < carriage.Capacity; j++) {
                    carriageViews.Add(new CarriageView {
                        CarriageType = carriage.GetCarriageType(),
                        Number = carriageNumber,
                        CompartmentNumber = i + 1,
                        SeatNumber = carriage[i].Seats[j].Number,
                        Sold = carriage[i].Seats[j].Sold?"продано":"свободно"
                    });
                } // for j
            } // for i

            return carriageViews;
        } // MapToCarriageView
    } // class Train
}
