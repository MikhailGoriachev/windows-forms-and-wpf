﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace TrainTickets.Models
{
    // Класс Место характеризуется номером и состоянием – продано или свободно
    // (не продано)
    [DataContract]
    public class Seat
    {
        // номер места пассажира - принимаем решение, что номер всегда
        // должен быть указан
        [DataMember]
        private string _number;
        public string Number {
            get => _number;
            set {
                if (string.IsNullOrWhiteSpace(value))
                    throw new InvalidDataException("Seat: Номер места не указан");

                _number = value;
            } // set
        } // Number

        // состояние места
        // true - продано, false - не продано
        [DataMember]
        public bool Sold { get; set; }

        #region Ансамбль конструкторов
        public Seat():this("1", false) { }

        public Seat(string number, bool sold) {
            Number = number;
            Sold = sold;
        } // Seat

        #endregion
    } // class Seat
}
