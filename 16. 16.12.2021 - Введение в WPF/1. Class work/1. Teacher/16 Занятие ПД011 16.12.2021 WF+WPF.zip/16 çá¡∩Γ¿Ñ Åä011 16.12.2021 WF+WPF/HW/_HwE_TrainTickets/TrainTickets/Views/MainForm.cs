﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using TrainTickets.Controllers;
using TrainTickets.Helpers;
using TrainTickets.ViewModels;

namespace TrainTickets.Views
{
    public partial class MainForm : Form
    {
        private TrainController _trainController;

        public MainForm():this(new TrainController()) { } // MainForm

        public MainForm(TrainController trainController) {
            InitializeComponent();

            _trainController = trainController;

            // загрузить данные вагона № 1 в DataGrid
            BnsCarriageView.DataSource = _trainController.SelectWhereNumber(1);
            DgvCarriageView.DataSource = BnsCarriageView;
        } // MainForm

        #region Команды общего назначения

        // завершение приложения
        private void Exit_Command(object sender, EventArgs e) => Application.Exit();


        // вывод формы со сведениями о приложении и разработчике
        private void About_Command(object sender, EventArgs e) {
            AboutForm aboutForm = new AboutForm();
            aboutForm.ShowDialog();
        } // About_Command

        #endregion

        #region Загрузка и сохранение данных, перетаскивание

        // выбор и загрузка файла данных о квартире и коллекции приборов квартиры
        private void OpenFile_Command(object sender, EventArgs e) {
            // показать диалог выбора файла, если файл не выбран - молча уходим 
            if (OfdMain.ShowDialog() != DialogResult.OK) return;

            // загрузка выбранного файла
            _trainController.FileName = OfdMain.FileName;
            _trainController.DeserializeData();

            // отображение данных файла, обновление данных
            BnsCarriageView.ResetBindings(false);

            // сформировать дерево для поезда

            // вывести статистику в строку состояния
        } // OpenFile_Command


        // задать имя файла и папку для сохранения данных при помощи стандартного диалога,
        // затем сохранить данные в выбранном файле
        private void SaveAs_Command(object sender, EventArgs e) {
            // Если файл для сохраненения не задан, то молча уходим 
            if (SfdMain.ShowDialog() != DialogResult.OK) return;

            // задать имя файла данных и собственно, сохранить данные
            _trainController.FileName = SfdMain.FileName;

            // разрешим кнопку и пункт меню сохранения
            TsbSave.Enabled = true;
        } // SaveAs_Command


        // сохранить данные в заданном командой SaveAs имени файла
        private void Save_Command(object sender, EventArgs e) => _trainController.SerializeData();

        #endregion

        #region Перетаскивавние на ListView, TreeView
        /*
        // перетаскивание на ListView, TreeView
        private void Handler_DragDrop(object sender, DragEventArgs e)
        {
            if (!e.Data.GetDataPresent(DataFormats.FileDrop)) return;

            // Прием файла, data[] - массив имен файлов
            _apartmentController.FileName = ((string[])e.Data.GetData(DataFormats.FileDrop))[0];
            _apartmentController.DeserializeData();

            // обновление отобржаемых данных
            FillDataGridView(_apartmentController.GetAll(), DgvAppliances);
            FillDataGridView(_apartmentController.OrderByBrand(), DgvOrdered);
            FillDataGridView(_apartmentController.SelectWhereName(_apartmentController.GetAll()[0].Name), DgvFiltered);
            FillTreeView(_apartmentController.GetAll(), TrvApartment);

            // вывести количество приборов квартире
            TslStatus.Text = $"Количество приборов в квартире: {_apartmentController.Count}";
            TslOn.Text = $"Включено: {_apartmentController.SelectWhereState(true).Count}";
            TslOff.Text = $"Выключено: {_apartmentController.SelectWhereState(false).Count}";
        } // Handler_DragDrop


        // Подтверждение операции необходимо, оно задает операцию при
        // завершении буксировки, один обработчик для ListView, TreeView
        private void Object_DragEnter(object sender, DragEventArgs e) =>
            e.Effect = DragDropEffects.Copy;

        */
        #endregion

        // форматирование ячеек строки
        private void DgvCarriageView_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            // получить ссылку на коллекцию данных в блоке привязки
            List<CarriageView> carriageViews = BnsCarriageView.DataSource as List<CarriageView>;

            switch (e.ColumnIndex) {
                // форматирвоание ячеек с номером вагона, номером места
                case 0:
                case 3:
                    e.CellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                    break;

                // форматирование ячейки с номером купе 
                case 2:
                    e.Value = Utils.ToRoman(carriageViews[e.RowIndex].CompartmentNumber);
                    e.CellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                    break;

                // форматирование ячейки состояния места с учетом чередования строк
                case 4:
                    if (e.RowIndex % 2 == 0) {
                        e.CellStyle.BackColor =
                            carriageViews[e.ColumnIndex].Sold == "продано"
                                ? Color.Bisque
                                : Color.LightGreen;
                    } else {
                        e.CellStyle.BackColor =
                            carriageViews[e.ColumnIndex].Sold == "продано"
                                ? Color.BurlyWood
                                : Color.LightSeaGreen;
                    } // if
                    e.CellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
                    break;
            } // switch
        } // DgvCarriageView_CellFormatting
    } // class MainForm
}
