﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace TrainTickets.Models
{
    // Класс Купе характеризуется типом (СВ, купе, плацкарт), количеством мест,
    // списком мест.
    [DataContract]
    public class Compartment
    {
        // количество мест в купе, тип купе 

        // коллекция мест в купе
        [DataMember]
        private Seat[] _seats;
        public Seat[] Seats {
            get => _seats;
            set {
                if (value.Length != 2 && value.Length != 4 && value.Length != 6)
                    throw new InvalidDataException("Compartment: некорректное количество мест в купе");
                _seats = value;
            } // set
        } // Seat

        // тип купе
        public string Type {
            get {
                switch (_seats.Length) {
                    case 2: return "СВ";
                    case 4: return "купе";
                    case 6: return "плацкарт";
                } // switch

                return "неизвестно";
            } // get
        } // Type

        #region Ансамбль конструкторов

        public Compartment():this(new Seat[6]) {}

        public Compartment(Seat[] seats) {
            Seats = seats;
        } // Compartment

        public Compartment(int capacity, ref int startNumber) {
            // создать массив мест 
            Seats = new Seat[capacity];

            // заполнение массива мест в купе, номер места формируем счетчиком
            for (int i = 0; i < capacity; i++) {
                Seats[i] = new Seat($"{startNumber}", false);
                ++startNumber;
            } // for i
        } // Compartment

        #endregion
    } // class Compartment
}
