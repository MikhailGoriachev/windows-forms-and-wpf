﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Json;
using System.Text;
using System.Threading.Tasks;
using TrainTickets.Helpers;
using TrainTickets.Models;
using TrainTickets.ViewModels;

namespace TrainTickets.Controllers
{
    public class TrainController
    {
        // данные по поезду, билеты на который мы продаем 
        private Train _train;

        // имя папки для хранения файла данных поезда
        public string InitialFolderName { get; set; } = "App_Data";

        // имя файла для хранения данных поезда
        public string FileName { get; set; } = "train001.train";


        #region Ансамбль конструкторов

        public TrainController() : this(new Train()) { } // TrainController

        public TrainController(Train train) {
            _train = train;

            // если поезд не содержит коллекцию вагонов - сформировать эту коллекцию
            // и сохранить данные в файле
            if (_train.Count == 0) {
                _train.Generate();

                // сохранить данные в файле, при необходимости - создать папку
                FileName = InitialFolderName + "\\" + FileName;
                SerializeData();
            } // if
        } // TrainController
        #endregion

        // Переформирование коллекции вагонов и сведений о поезде
        // с сериализацией
        public void Generate() {
            _train.Generate();
            SerializeData();
        } // Generate


        // -----------------------------------------------------------------------------------


        // -----------------------------------------------------------------------------------

        // сериализация данных в формате JSON
        // для общего развития: ссылка на Newtonsoft https://www.newtonsoft.com/json 
        public void SerializeData() {
            // если нет папки для хранения данных - создать папку
            if (!Directory.Exists(InitialFolderName)) {
                Directory.CreateDirectory(InitialFolderName);
            } // if

            DataContractJsonSerializer jsonFormatter = new DataContractJsonSerializer(typeof(Train));

            // Запись объекта в JSON-файл
            using (FileStream fs = new FileStream(FileName, FileMode.Create)) {
                jsonFormatter.WriteObject(fs, _train);
            } // using
        } // SerializeData


        // десериализация данных из формата JSON
        // для общего развития: ссылка на Newtonsoft https://www.newtonsoft.com/json 
        public void DeserializeData()
        {
            DataContractJsonSerializer jsonFormatter = new DataContractJsonSerializer(typeof(Train));

            // Читаем коллекцию из JSON-файла
            using (FileStream fs = new FileStream(FileName, FileMode.OpenOrCreate)) {
                _train = (Train)jsonFormatter.ReadObject(fs);
            } // using
        } // DeserializeData

        // -----------------------------------------------------------------------------------

        // Добавление вагона в коллекцию, сериализация данных
        public void AddCarriage(Carriage carriage) {
            _train.Add(carriage);
            SerializeData();
        } // AddCarriage

        // Удаление вагона из коллекции, сериализация данных
        public void RemoveCarriageAt(int index)
        {
            _train.RemoveCarriageAt(index);
            SerializeData();
        } // RemoveCarriageAt

        // -----------------------------------------------------------------------------------

        // Запрос на выборку в коллекцию информации о вагоне для отображения в DataGridView
        public List<CarriageView> SelectWhereNumber(int carriageNumber) => 
            _train.MapToCarriageView(carriageNumber);

    } // class TrainController
}
