﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TrainTickets.Models;

namespace TrainTickets.Models
{
    //Класс Купе 
    class Compartment
    {
        
        private string _type;       //тип купе
        private int _amntSeats;     //количество мест
        private List<Place> _seats; //список мест в купе

        //конструкторы
        public Compartment()
        {
            _type = "СВ";
            _amntSeats = 2;
            _seats = Place.CreatePlaces(2);
        }
        private Compartment(string type, int amount, List<Place> places)
        {
            _type = type;
            _amntSeats = amount;
            _seats = places;
        }
        //свойства
        public List<Place> Seats
        {
            get { return _seats; }
        }
        public string Type
        {
            get { return _type; }
        }
        public int AmountSeats
        {
            get { return _amntSeats; }
        }

        //Фабрика массива купе для класса вагонов Wagon
        static public List<Compartment> CreateCompartment(string typeName)
        {
            //Вагоны всегда состоят из 9 купе
            int length = 9;
            //кортеж из элементов купе
            (string type, int amntSeats, List<Place> seats) temp;
            //возвращаемый список купе
            List<Compartment> compartments = new List<Compartment>();

            //подбираем нужный тип купе
            switch (typeName)
            {
                case "СВ":
                    temp = ("СВ", 2, Place.CreatePlaces(2));
                    break;
                case "Купейный":
                    temp = ("Купейный", 4, Place.CreatePlaces(4));
                    break;
                case "Плацкартный":
                    temp = ("Плацкартный", 6, Place.CreatePlaces(6));
                    break;
                default:
                    throw new Exception("Такого вида купе нет!");
            }

            /*
            temp = (typeName == "СВ") ?
                    ("СВ", 2, Place.CreatePlaces(2)) :
                (typeName == "Купейный") ?
                    ("Купейный", 4, Place.CreatePlaces(4)) :
                (typeName == "Плацкартный") ?
                    ("Плацкартный", 6, Place.CreatePlaces(6)) :
                throw new Exception("Такого вида купе нет!");
            */


            for (int i = 0; i < length; i++)
                compartments.Add(new Compartment(temp.type, temp.amntSeats, temp.seats));

            return compartments;
        }

    }
}
