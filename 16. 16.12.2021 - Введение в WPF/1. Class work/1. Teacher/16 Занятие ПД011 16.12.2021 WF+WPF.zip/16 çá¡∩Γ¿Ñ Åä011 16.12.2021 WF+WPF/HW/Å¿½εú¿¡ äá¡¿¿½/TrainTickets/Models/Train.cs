﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TrainTickets.Models
{
    //класс поезд
    class Train
    {
        //Максимальное количество вагонов в поезде 20
        public const int MaxNumWagons = 20; 

        private string _numOfTrain;         //номер поезда
        private List<Wagon> _wagons;        //массив вагонов
        private string _departure;          //пункт отправления
        private string _direction;          //пункт назначения

        //конструкторы
        public Train()
        {
            _numOfTrain = "111AA";
            _wagons = Wagon.CreateCompartment("СВ");
            _departure = "Донецк";
            _direction = "Ростов";
        }
        public Train(string numOfTrain, List<Wagon> wagons, string departure,string direction)
        {
            Wagons = wagons;
            NumberOfTrain = numOfTrain;
            Departure = departure;
            Direction = direction;
        }
     
        //свойства
        public List<Wagon> Wagons
        {
            get { return  _wagons; }
            set {  
                if(value.Count > MaxNumWagons || value.Count < 1)
                    throw new Exception("Wagons: Некорректное присваивания массива вагонов!");
                _wagons = value;
            }
        }
        public string NumberOfTrain
        {
            get { return _numOfTrain; }
            set { _numOfTrain = value; }
        }
        public string Departure { get => _departure; set { _departure = value; } }
        public string Direction { get => _direction; set { _direction = value; } }
    }
}
