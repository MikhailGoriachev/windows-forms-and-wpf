﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TrainTickets.Models
{
    //Класс Вагон характеризуется номером вагона, количеством купе,
    //массивом купе, максимальной вместимостью купе (типом купе).
    class Wagon
    {
        private string _type;                    //максимальная вместимость купе (тип купе)
        private const int _amntComps = 9;        //количество купе
        private int _numOfCarriage;              //номер вагона
        private List<Compartment> _compartments; //массив купе

        //конструкторы
        public Wagon()
        {
            _type = "СВ";
            _numOfCarriage = 1;
            _compartments = Compartment.CreateCompartment("СВ");
        }
        public Wagon(string type, int numOfCarriage, List<Compartment> compartments)
        {
            Type = type;
            NumOfCarriage = numOfCarriage;
            Compartments = compartments;
        }
        //свойства
        public List<Compartment> Compartments
        {
            get { return _compartments; }
            private set { 
                if(value.Count > 9)
                    throw new Exception("Compartments: Некорректное присваивания массива купе!");
                _compartments = value; 
            }
        }
        public int NumOfCarriage
        {
            get { return _numOfCarriage; }
            private set { _numOfCarriage = !(value > 20 || value < 1) ? value
                    :throw new Exception("NumOfCarriage: Неверный номер вагона!"); }
        }
        public string Type
        {
            get { return _type; }
            private set 
            {
                if (value != "СВ" && value != "Купейный" && value != "Плацкартный")
                    throw new Exception("Type: Неверный тип вагона!");
                _type = value;
            }
        }

        //Фабрика массива вагонов для класса поезда Train
        static public List<Wagon> CreateCompartment(string typeName)
        {
            //Максимальное количество вагонов в поезде 20
            int length = 20;
            //кортеж из элементов вагона
            (string type, List<Compartment> comps) temp;

            //возвращаемый методом массив вагонов
            List<Wagon> wagons = new List<Wagon>();
            
            //подбираем нужный тип
            temp = (typeName == "СВ") ?
                    ("СВ", Compartment.CreateCompartment("СВ")) :
                (typeName == "Купейный") ?
                    ("Купейный", Compartment.CreateCompartment("Купейный")) :
                (typeName == "Плацкартный") ?
                    ("Плацкартный", Compartment.CreateCompartment("Плацкартный")) :
                throw new Exception("Такого вида купе нет!");

            //собираем массив вагонов
            for (int i = 0; i < length; i++)
                wagons.Add(new Wagon(temp.type, i+1, temp.comps));

            return wagons;
        }

    }
}
