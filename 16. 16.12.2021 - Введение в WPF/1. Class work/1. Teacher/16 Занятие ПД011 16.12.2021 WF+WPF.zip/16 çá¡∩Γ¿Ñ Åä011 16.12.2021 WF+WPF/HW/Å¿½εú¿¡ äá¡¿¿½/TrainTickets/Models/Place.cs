﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TrainTickets.Properties;

namespace TrainTickets.Models
{
    //класс место
    class Place
    {
        private int _numOfSeat; // номер места
        private bool _state;    // занятость места

        //конструкторы
        public Place()
        {
            _numOfSeat = 0;
            _state = false;
        }
        private Place(int num, bool st)
        {
            NumOfSeat = num;
            State = st;
        }

        //свойства
        public int NumOfSeat
        {
            get { return _numOfSeat; }
            private set { _numOfSeat = value; }
        }
        public bool State
        {
            get { return _state; }
            set { _state = value; }
        }

        //фабрика массива мест для класса купе Compartment
        static public List<Place> CreatePlaces(int amount)
        {
            //если количество мест некорректно выходим
            if (amount < 1 || amount > 54)
                throw new Exception("CreatePlaces: Неверное количество мест!");

            //создаем коллекцию мест
            List<Place> places = new List<Place>();

            for (int i = 0; i < amount; i++)
                //заполняем коллекцию местами
                places.Add(new Place(i + 1, false));

            return places;
        }
    }
}
