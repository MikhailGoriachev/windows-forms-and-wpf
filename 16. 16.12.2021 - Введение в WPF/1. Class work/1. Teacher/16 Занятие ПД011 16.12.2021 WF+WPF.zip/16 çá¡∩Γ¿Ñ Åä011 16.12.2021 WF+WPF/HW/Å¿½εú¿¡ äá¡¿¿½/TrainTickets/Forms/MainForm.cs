﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TrainTickets.Models;

namespace TrainTickets
{
    public partial class MainForm : Form
    {
        private Train train = new Train();
        public MainForm()
        {
            InitializeComponent();

            BindingSource.DataSource = train.Wagons;
        }
    }
}
