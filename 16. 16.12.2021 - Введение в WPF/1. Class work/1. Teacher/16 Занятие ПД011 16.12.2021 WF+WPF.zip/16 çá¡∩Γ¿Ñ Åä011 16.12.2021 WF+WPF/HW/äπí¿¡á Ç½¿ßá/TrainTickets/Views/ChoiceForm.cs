﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TrainTickets.Views
{
    public partial class ChoiceForm : Form
    {
        public ChoiceForm(): this("Выбор", ":", new List<string>()){ }

        public ChoiceForm(string formTitle, string title, List<string> options) {
            InitializeComponent();
            Text = formTitle;
            LblPrompt.Text = title;

            // привязка к коллекции, выбор первого в списке 
            CbxOptions.DataSource = options;
            CbxOptions.SelectedItem = 0;
        } // ChoiceForm
           
        public string Option => CbxOptions.Text;
    }
}
