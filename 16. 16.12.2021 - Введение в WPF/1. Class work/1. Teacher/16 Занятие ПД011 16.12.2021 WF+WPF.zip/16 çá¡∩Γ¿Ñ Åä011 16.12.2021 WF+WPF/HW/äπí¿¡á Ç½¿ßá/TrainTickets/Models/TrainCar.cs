﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TrainTickets.Helpers;

namespace TrainTickets.Models
{
    public class TrainCar {
        // кол-во купе в вагоне
        public const int CountCompartment = 9;

        private Utils.TrainCarType _type;
        public Utils.TrainCarType Type {
            get => _type;
            set => _type = value; 
        } // Type


        private int _number;
        public int Number { 
            get => _number;
            set {
                if (value <= 0)
                    throw new Exception("TrainCar: Некорректный номер вагона!");
                _number = value;
            } // set 
        } // Number

        public int LastNum { get; private set; }

        private Compartment[] _compartments;
        public Compartment[] Compartments {
            get => _compartments;
            private set => _compartments = value;
        } // Compartments

        public TrainCar(Utils.TrainCarType type, int number, int lastPlaceNum) {
            _type = type;
            _number = number;
            Initialize(lastPlaceNum);
        } // Compartment

        public void Initialize(int lastPlaceNum) {
            _compartments = new Compartment[(int)_type];
            for (int i = 0; i < _compartments.Length; i++) {
                _compartments[i] = new Compartment(_type, lastPlaceNum);
                lastPlaceNum = _compartments[i].Places[(int)_type - 1].Number + 1;
            } // for i
            LastNum = _compartments[_compartments.Length - 1].LastNum;
        } // Initialize

        // кол-во проданных билетов
        public int CountSales() {
            int count = 0;
            for (int i = 0; i < _compartments.Length; i++)
                count += _compartments[i].CountSales();
            return count;
        } // CountSales

        // кол-во билетов
        public int Count() {
            int count = 0;
            for (int i = 0; i < _compartments.Length; i++)
                count += _compartments[i].Count();
            return count;
        } // Count

        // кол-во проданных билетов
        public int CountSales(Utils.TrainCarType type) {
            if (_type != type) return 0;
            int count = 0;
            for (int i = 0; i < _compartments.Length; i++)
                count += _compartments[i].CountSales(type);
            return count;
        } // CountSales

        // кол-во билетов
        public int Count(Utils.TrainCarType type) {
            if (_type != type) return 0;
            int count = 0;
            for (int i = 0; i < _compartments.Length; i++)
                count += _compartments[i].Count(type);
            return count;
        } // Count

    } // TrainCar
}
