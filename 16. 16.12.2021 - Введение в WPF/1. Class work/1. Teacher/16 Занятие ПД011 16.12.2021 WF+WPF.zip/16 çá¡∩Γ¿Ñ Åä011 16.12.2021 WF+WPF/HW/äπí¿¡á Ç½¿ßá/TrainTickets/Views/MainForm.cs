﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TrainTickets.Controllers;
using TrainTickets.Helpers;
using TrainTickets.Models;

namespace TrainTickets.Views
{
    public partial class MainForm : Form
    {
        // контроллер для обработки данных по заданию
        private TrainController _trainController;

        public MainForm() {
            InitializeComponent();
            _trainController = new TrainController();

            FillTreeView(_trainController.Train, TrvTrain);
            FillDataGridView(_trainController.Train, DgvTrain);
        }

        // завершение приложения
        private void Exit_Command(object sender, EventArgs e) => Application.Exit();

        // заполнение элемента TreeView
        private void FillTreeView(Train train, TreeView treeView) {
            treeView.Nodes.Clear();

            treeView.Nodes.Add($"Поезд {train.Number}");
            for (int i = 0; i < train.TrainCars.Count; i++) {
                var temp = treeView.Nodes[0].Nodes.Add($"Вагон №{train.TrainCars[i].Number}");
                temp.Tag = train.TrainCars[i];
                temp.ContextMenuStrip = CmnTrainCar;
                for (int j = 0; j < train.TrainCars[i].Compartments.Length; j++) {
                    treeView.Nodes[0].Nodes[i].Nodes.Add($"Купе №{j + 1}");
                    for (int k = 0; k < train.TrainCars[i].Compartments[j].Places.Length; k++) {
                        treeView.Nodes[0].Nodes[i].Nodes[j].Nodes.Add($"Место №{train.TrainCars[i].Compartments[j].Places[k].Number}");
                    } // for k
                } // for j
            } // for i

            treeView.ExpandAll();
        } // FillTreeView

        public void FillDataGridView(Train train, DataGridView dataGridView) {
            dataGridView.Rows.Clear();
            dataGridView.Rows.AddRange(train.ToDataGridViewRow().ToArray());
        } // FillDataGridView

        // свернуть в трей
        private void ToTray_Command(object sender, EventArgs e) {
            this.Hide();
            NtfMain.Visible = true;
        } // ToTray_Command

        // выбор и загрузка файла данных о квартире и коллекции приборов квартиры
        private void OpenFile_Command(object sender, EventArgs e)
        {
            // показать диалог выбора файла, если файл не выбран - молча уходим 
            if (OfdMain.ShowDialog() != DialogResult.OK) return;

            // загрузка выбранного файла
            _trainController.FileName = OfdMain.FileName;
            _trainController.DeserializeData();

            // отображение данных файла, обновление данных
            FillDataGridView(_trainController.Train, DgvTrain);

            // сформировать дерево 
            FillTreeView(_trainController.Train, TrvTrain);

            MainForm_Load(sender, e);
        } // OpenFile_Command


        // задать имя файла и папку для сохранения данных при помощи стандартного диалога,
        // затем сохранить данные в выбранном файле
        private void SaveAs_Command(object sender, EventArgs e) {
            // Если файл для сохраненения не задан, то молча уходим 
            if (SfdMain.ShowDialog() != DialogResult.OK) return;

            // задать имя файла данных и собственно, сохранить данные
            _trainController.FileName = SfdMain.FileName;
            _trainController.SerializeData();

            // разрешим кнопку и пункт меню сохранения
            MniFileSave.Enabled = true;
        } // SaveAs_Command

        // сохранить данные в заданном командой SaveAs имени файла
        private void Save_Command(object sender, EventArgs e) => _trainController.SerializeData();

        // восстановить из трея
        private void FromTray_Command(object sender, EventArgs e) {
            this.Show();
            WindowState = FormWindowState.Normal;
            NtfMain.Visible = false;
        } // FromTray_Command

        // Генерация новых данных
        private void Generate_Command(object sender, EventArgs e) {
            _trainController.Train.Initialize(4);
            FillTreeView(_trainController.Train, TrvTrain);
            FillDataGridView(_trainController.Train, DgvTrain);
            MainForm_Load(sender, e);
            Save_Command(sender, e);
        } // Generate_Command

        // по правой кнопке мыши делаем строку DataGridView текущей
        private void DgvTrain_MouseDown(object sender, MouseEventArgs e) {
            if (e.Button == MouseButtons.Right) {
                DataGridView.HitTestInfo hit = DgvTrain.HitTest(e.X, e.Y);
                DgvTrain.Rows[hit.RowIndex].Selected = true;
            } // if
        } // DgvDgvTrain_MouseDown

        // коррекция поведения TreeView - по клику на узле (любой кнопкой мыши)
        // сделать узел, на котором был клик, текущим 
        private void CorrectBehavor_NodeMouseClick(object sender, TreeNodeMouseClickEventArgs e) {
            TrvTrain.SelectedNode = e.Node;
        } // CorrectBehavor_NodeMouseClick

        private void ReturnTicket_Command(object sender, EventArgs e) {
            // выход, если нет выбранного элемента
            if (DgvTrain.SelectedRows.Count == 0) return;

            int index = DgvTrain.SelectedRows[0].Index;
            ((Place)DgvTrain.Rows[index].Tag).State = true;

            // визуализация изменения
            DgvTrain[4, index].Value = "Cвободно";
            DgvTrain[4, index].Style.BackColor = Color.Green;
            DgvTrain.Rows[index].Selected = true;

            MainForm_Load(sender, e);

            Save_Command(sender, e);
        } // ReturnTicket_Command

        private void SellTicket_Command(object sender, EventArgs e) {
            // выход, если нет выбранного элемента
            if (DgvTrain.SelectedRows.Count == 0) return;

            int index = DgvTrain.SelectedRows[0].Index;
            ((Place)DgvTrain.Rows[index].Tag).State = false;

            // визуализация изменения
            DgvTrain[4, index].Value = "Продано";
            DgvTrain[4, index].Style.BackColor = Color.Yellow;
            DgvTrain.Rows[index].Selected = true;

            MainForm_Load(sender, e);
            Save_Command(sender, e);
        } // SellTicket_Command

        private void MainForm_Load(object sender, EventArgs e) {
            TslTrainCarsCount.Text = $"Кол-во вагонов: {_trainController.Train.TrainCars.Count()}";
            TslSales.Text = $"Места: {_trainController.Train.Count()}/{_trainController.Train.CountSales()}";
            TslSleepping.Text = $"СВ: {_trainController.Train.CountTrainCarsByType(Utils.TrainCarType.Sleepping)}/{_trainController.Train.Count(Utils.TrainCarType.Sleepping)}/{_trainController.Train.CountSales(Utils.TrainCarType.Sleepping)}";
            TslCompartment.Text = $"Купейный: {_trainController.Train.CountTrainCarsByType(Utils.TrainCarType.Compartment)}/{_trainController.Train.Count(Utils.TrainCarType.Compartment)}/{_trainController.Train.CountSales(Utils.TrainCarType.Compartment)}";
            TslReserved.Text = $"Плацкарт: {_trainController.Train.CountTrainCarsByType(Utils.TrainCarType.Reserved)}/{_trainController.Train.Count(Utils.TrainCarType.Reserved)}/{_trainController.Train.CountSales(Utils.TrainCarType.Reserved)}";
        } // MainForm_Load

        private void RemoveTrainCar_Command(object sender, EventArgs e) {
            if (TrvTrain.SelectedNode.Level != 1) return;


            _trainController.Train.TrainCars.Remove(TrvTrain.SelectedNode.Tag as TrainCar);

            FillTreeView(_trainController.Train, TrvTrain);
            FillDataGridView(_trainController.Train, DgvTrain);

            MainForm_Load(sender, e);
            Save_Command(sender, e);
        } // RemoveTrainCar_Command

        private void DragDrop_Command(object sender, DragEventArgs e) {
            string[] fileNames = (string[])e.Data.GetData(DataFormats.FileDrop);
            _trainController.FileName = fileNames[0];
            _trainController.DeserializeData();

            FillTreeView(_trainController.Train, TrvTrain);
            FillDataGridView(_trainController.Train, DgvTrain);

            MainForm_Load(sender, e);

            MainForm_Load(sender, e);
        } // DragDrop_Command

        private void DragEnter_Command(object sender, DragEventArgs e) {
            e.Effect = DragDropEffects.Copy;
        } // DragEnter_Command

        private void About_Command(object sender, EventArgs e) {
            FormAbout formAbout = new FormAbout();
            formAbout.ShowDialog();
        } // About_Command

        // Выборка и вывод в отдельной вкладке коллекции электроприборов, с заданным состоянием
        private void AddTrainCarCommand_Command(object sender, EventArgs e) {
            // получить список названий из коллекции
            List<string> types = new List<string>(new string[] { "СП", "Купейный", "Плацкартный"});

            // создание формы выбора состояния, передача в окно списка состояний
            ChoiceForm choiceForm = new ChoiceForm("Выбор типа вагона", "Тип вагона:", types);

            if (choiceForm.ShowDialog() != DialogResult.OK) return;

            Utils.TrainCarType type = choiceForm.Option == "СП"
                ? Utils.TrainCarType.Sleepping
                : choiceForm.Option == "Купейный"
                    ? Utils.TrainCarType.Compartment
                    : Utils.TrainCarType.Reserved;

            _trainController.Train.TrainCars.Add(new TrainCar(type, _trainController.Train.TrainCars.Count + 1, _trainController.Train.TrainCars[_trainController.Train.TrainCars.Count - 1].LastNum));

            FillTreeView(_trainController.Train, TrvTrain);
            FillDataGridView(_trainController.Train, DgvTrain);

            MainForm_Load(sender, e);

            MainForm_Load(sender, e);
        } // SelectByState_Command
    }
}
