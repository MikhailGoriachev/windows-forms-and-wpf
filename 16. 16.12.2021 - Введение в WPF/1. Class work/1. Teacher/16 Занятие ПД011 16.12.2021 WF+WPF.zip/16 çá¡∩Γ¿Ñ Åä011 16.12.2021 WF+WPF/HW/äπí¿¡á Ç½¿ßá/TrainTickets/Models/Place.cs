﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TrainTickets.Models
{
    // Класс места: номер, состояние(занято, свободно).
    public class Place {
        private int _number;
        public int Number { 
            get => _number;
            set {
                if (value <= 0)
                    throw new Exception("Place: Некорректный номер места!");
                _number = value;
            } // set 
        } // Number

        private bool _state;
        public bool State { 
            get => _state;
            set => _state = value;
        } // State

        public Place(int number, bool state) {
            _number = number;
            _state = state;
        } // Train
    } // Place
}
