﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TrainTickets.Helpers;

namespace TrainTickets.Models
{
    // Класс купе - свойства: тип, количество мест, список мест
    public class Compartment {
        private Utils.TrainCarType _type;
        public Utils.TrainCarType Type {
            get => _type;
            set => _type = value;
        } // Type


        private Place[] _places;
        public Place[] Places { 
            get => _places;
            private set => _places = value;
        } // Places

        public int LastNum { get; private set; }

        public Compartment(Utils.TrainCarType type, int lastPlaceNum) {
            _type = type;
            Initialize(lastPlaceNum);
        } // Compartment

        public void Initialize(int lastPlaceNum) {
            _places = new Place[(int)_type];
            for (int i = 0; i < _places.Length; i++) {
                _places[i] = new Place(lastPlaceNum, Utils.GetRandom(0, 1) == 0);
                lastPlaceNum++;
            } // for i
            LastNum = _places[_places.Length - 1].Number + 1;
        } // Initialize

        // кол-во проданных билетов
        public int CountSales(Utils.TrainCarType type) {
            if (_type != type) return 0;
            int count = 0;
            for (int i = 0; i < _places.Length; i++)
                count += _places[i].State ? 0 : 1;
            return count;
        } // CountSales

        // кол-во билетов
        public int Count(Utils.TrainCarType type) {
            if (_type != type) return 0;
            return _places.Length;
        } // Count

        // кол-во проданных билетов
        public int CountSales(){
            int count = 0;
            for (int i = 0; i < _places.Length; i++)
                count += _places[i].State ? 0 : 1;
            return count;
        } // CountSales

        // кол-во билетов
        public int Count() => _places.Length;
    } // Compartment
}
