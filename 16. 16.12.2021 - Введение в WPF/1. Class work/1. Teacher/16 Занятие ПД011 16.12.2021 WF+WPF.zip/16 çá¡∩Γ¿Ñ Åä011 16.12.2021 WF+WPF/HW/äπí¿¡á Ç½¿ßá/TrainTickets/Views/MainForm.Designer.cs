﻿
namespace TrainTickets.Views
{
    partial class MainForm
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            System.Windows.Forms.TreeNode treeNode2 = new System.Windows.Forms.TreeNode("Поезд");
            this.TstMain = new System.Windows.Forms.ToolStrip();
            this.TstSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.TstSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.TstSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.TsbExit = new System.Windows.Forms.ToolStripButton();
            this.MnsMain = new System.Windows.Forms.MenuStrip();
            this.MniFile = new System.Windows.Forms.ToolStripMenuItem();
            this.MniFileOpen = new System.Windows.Forms.ToolStripMenuItem();
            this.MniFileSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.MniFileSave = new System.Windows.Forms.ToolStripMenuItem();
            this.MniFileSaveAs = new System.Windows.Forms.ToolStripMenuItem();
            this.MniFileSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.MniFileExit = new System.Windows.Forms.ToolStripMenuItem();
            this.MniTrain = new System.Windows.Forms.ToolStripMenuItem();
            this.новыеДанныеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.MniControl = new System.Windows.Forms.ToolStripMenuItem();
            this.MniControlToTray = new System.Windows.Forms.ToolStripMenuItem();
            this.MniControlSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.MniControlAddTrainCar = new System.Windows.Forms.ToolStripMenuItem();
            this.MniControlSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.MniControlReturnTicket = new System.Windows.Forms.ToolStripMenuItem();
            this.MniControlSellTicket = new System.Windows.Forms.ToolStripMenuItem();
            this.MniHelp = new System.Windows.Forms.ToolStripMenuItem();
            this.MniHelpAbout = new System.Windows.Forms.ToolStripMenuItem();
            this.NtfMain = new System.Windows.Forms.NotifyIcon(this.components);
            this.CmnNotify = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.CmiRestore = new System.Windows.Forms.ToolStripMenuItem();
            this.CmiNotifySeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.CmiAbout = new System.Windows.Forms.ToolStripMenuItem();
            this.CmiNotifySeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.CmiExit = new System.Windows.Forms.ToolStripMenuItem();
            this.StsMain = new System.Windows.Forms.StatusStrip();
            this.TslTrainCarsCount = new System.Windows.Forms.ToolStripStatusLabel();
            this.TslSales = new System.Windows.Forms.ToolStripStatusLabel();
            this.TslSleepping = new System.Windows.Forms.ToolStripStatusLabel();
            this.TslCompartment = new System.Windows.Forms.ToolStripStatusLabel();
            this.TslReserved = new System.Windows.Forms.ToolStripStatusLabel();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.TrvTrain = new System.Windows.Forms.TreeView();
            this.DgvTrain = new System.Windows.Forms.DataGridView();
            this.ColTrainCarNum = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColTrainCarType = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColComNum = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColPlaceNum = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColState = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SfdMain = new System.Windows.Forms.SaveFileDialog();
            this.OfdMain = new System.Windows.Forms.OpenFileDialog();
            this.CmnTrainCar = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.TsbNew = new System.Windows.Forms.ToolStripButton();
            this.TsbOpen = new System.Windows.Forms.ToolStripButton();
            this.TsbSave = new System.Windows.Forms.ToolStripButton();
            this.TsbToTray = new System.Windows.Forms.ToolStripButton();
            this.TsbReturnTicket = new System.Windows.Forms.ToolStripButton();
            this.TsbSellTicket = new System.Windows.Forms.ToolStripButton();
            this.TsbAbout = new System.Windows.Forms.ToolStripButton();
            this.TstMain.SuspendLayout();
            this.MnsMain.SuspendLayout();
            this.CmnNotify.SuspendLayout();
            this.StsMain.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DgvTrain)).BeginInit();
            this.CmnTrainCar.SuspendLayout();
            this.SuspendLayout();
            // 
            // TstMain
            // 
            this.TstMain.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TstMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.TsbNew,
            this.TsbOpen,
            this.TsbSave,
            this.TstSeparator1,
            this.TsbToTray,
            this.TstSeparator2,
            this.TsbReturnTicket,
            this.TsbSellTicket,
            this.TstSeparator3,
            this.TsbAbout,
            this.TsbExit});
            this.TstMain.Location = new System.Drawing.Point(0, 28);
            this.TstMain.Name = "TstMain";
            this.TstMain.Size = new System.Drawing.Size(874, 39);
            this.TstMain.TabIndex = 3;
            this.TstMain.Text = "toolStrip1";
            // 
            // TstSeparator1
            // 
            this.TstSeparator1.Name = "TstSeparator1";
            this.TstSeparator1.Size = new System.Drawing.Size(6, 39);
            // 
            // TstSeparator2
            // 
            this.TstSeparator2.Name = "TstSeparator2";
            this.TstSeparator2.Size = new System.Drawing.Size(6, 39);
            // 
            // TstSeparator3
            // 
            this.TstSeparator3.Name = "TstSeparator3";
            this.TstSeparator3.Size = new System.Drawing.Size(6, 39);
            // 
            // TsbExit
            // 
            this.TsbExit.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.TsbExit.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbExit.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbExit.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbExit.Name = "TsbExit";
            this.TsbExit.Size = new System.Drawing.Size(23, 36);
            this.TsbExit.ToolTipText = "Завершение приложение";
            // 
            // MnsMain
            // 
            this.MnsMain.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.MnsMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniFile,
            this.MniTrain,
            this.MniControl,
            this.MniHelp});
            this.MnsMain.Location = new System.Drawing.Point(0, 0);
            this.MnsMain.Name = "MnsMain";
            this.MnsMain.Size = new System.Drawing.Size(874, 28);
            this.MnsMain.TabIndex = 2;
            this.MnsMain.Text = "menuStrip1";
            // 
            // MniFile
            // 
            this.MniFile.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniFileOpen,
            this.MniFileSeparator1,
            this.MniFileSave,
            this.MniFileSaveAs,
            this.MniFileSeparator2,
            this.MniFileExit});
            this.MniFile.Name = "MniFile";
            this.MniFile.Size = new System.Drawing.Size(57, 24);
            this.MniFile.Text = "Файл";
            // 
            // MniFileOpen
            // 
            this.MniFileOpen.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MniFileOpen.Name = "MniFileOpen";
            this.MniFileOpen.Size = new System.Drawing.Size(187, 24);
            this.MniFileOpen.Text = "Открыть...";
            this.MniFileOpen.Click += new System.EventHandler(this.OpenFile_Command);
            // 
            // MniFileSeparator1
            // 
            this.MniFileSeparator1.Name = "MniFileSeparator1";
            this.MniFileSeparator1.Size = new System.Drawing.Size(184, 6);
            // 
            // MniFileSave
            // 
            this.MniFileSave.Enabled = false;
            this.MniFileSave.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MniFileSave.Name = "MniFileSave";
            this.MniFileSave.Size = new System.Drawing.Size(187, 24);
            this.MniFileSave.Text = "Сохранить";
            // 
            // MniFileSaveAs
            // 
            this.MniFileSaveAs.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MniFileSaveAs.Name = "MniFileSaveAs";
            this.MniFileSaveAs.Size = new System.Drawing.Size(187, 24);
            this.MniFileSaveAs.Text = "Сохранить как...";
            this.MniFileSaveAs.Click += new System.EventHandler(this.SaveAs_Command);
            // 
            // MniFileSeparator2
            // 
            this.MniFileSeparator2.Name = "MniFileSeparator2";
            this.MniFileSeparator2.Size = new System.Drawing.Size(184, 6);
            // 
            // MniFileExit
            // 
            this.MniFileExit.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MniFileExit.Name = "MniFileExit";
            this.MniFileExit.Size = new System.Drawing.Size(187, 24);
            this.MniFileExit.Text = "Выход";
            this.MniFileExit.Click += new System.EventHandler(this.Exit_Command);
            // 
            // MniTrain
            // 
            this.MniTrain.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.новыеДанныеToolStripMenuItem});
            this.MniTrain.Name = "MniTrain";
            this.MniTrain.Size = new System.Drawing.Size(64, 24);
            this.MniTrain.Text = "Поезд";
            // 
            // новыеДанныеToolStripMenuItem
            // 
            this.новыеДанныеToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.новыеДанныеToolStripMenuItem.Name = "новыеДанныеToolStripMenuItem";
            this.новыеДанныеToolStripMenuItem.Size = new System.Drawing.Size(190, 24);
            this.новыеДанныеToolStripMenuItem.Text = "Новаые данные";
            this.новыеДанныеToolStripMenuItem.Click += new System.EventHandler(this.Generate_Command);
            // 
            // MniControl
            // 
            this.MniControl.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniControlToTray,
            this.MniControlSeparator1,
            this.MniControlAddTrainCar,
            this.MniControlSeparator2,
            this.MniControlReturnTicket,
            this.MniControlSellTicket});
            this.MniControl.Name = "MniControl";
            this.MniControl.Size = new System.Drawing.Size(106, 24);
            this.MniControl.Text = "Управление";
            // 
            // MniControlToTray
            // 
            this.MniControlToTray.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MniControlToTray.Name = "MniControlToTray";
            this.MniControlToTray.Size = new System.Drawing.Size(198, 24);
            this.MniControlToTray.Text = "Свернуть в трей";
            this.MniControlToTray.Click += new System.EventHandler(this.ToTray_Command);
            // 
            // MniControlSeparator1
            // 
            this.MniControlSeparator1.Name = "MniControlSeparator1";
            this.MniControlSeparator1.Size = new System.Drawing.Size(195, 6);
            // 
            // MniControlAddTrainCar
            // 
            this.MniControlAddTrainCar.Name = "MniControlAddTrainCar";
            this.MniControlAddTrainCar.Size = new System.Drawing.Size(198, 24);
            this.MniControlAddTrainCar.Text = "Добавить вагон...";
            this.MniControlAddTrainCar.Click += new System.EventHandler(this.AddTrainCarCommand_Command);
            // 
            // MniControlSeparator2
            // 
            this.MniControlSeparator2.Name = "MniControlSeparator2";
            this.MniControlSeparator2.Size = new System.Drawing.Size(195, 6);
            // 
            // MniControlReturnTicket
            // 
            this.MniControlReturnTicket.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MniControlReturnTicket.Name = "MniControlReturnTicket";
            this.MniControlReturnTicket.Size = new System.Drawing.Size(198, 24);
            this.MniControlReturnTicket.Text = "Возврат билета";
            this.MniControlReturnTicket.Click += new System.EventHandler(this.ReturnTicket_Command);
            // 
            // MniControlSellTicket
            // 
            this.MniControlSellTicket.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MniControlSellTicket.Name = "MniControlSellTicket";
            this.MniControlSellTicket.Size = new System.Drawing.Size(198, 24);
            this.MniControlSellTicket.Text = "Продажа билета";
            this.MniControlSellTicket.Click += new System.EventHandler(this.SellTicket_Command);
            // 
            // MniHelp
            // 
            this.MniHelp.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniHelpAbout});
            this.MniHelp.Name = "MniHelp";
            this.MniHelp.Size = new System.Drawing.Size(79, 24);
            this.MniHelp.Text = "Справка";
            // 
            // MniHelpAbout
            // 
            this.MniHelpAbout.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MniHelpAbout.Name = "MniHelpAbout";
            this.MniHelpAbout.Size = new System.Drawing.Size(182, 24);
            this.MniHelpAbout.Text = "О программе...";
            this.MniHelpAbout.Click += new System.EventHandler(this.About_Command);
            // 
            // NtfMain
            // 
            this.NtfMain.ContextMenuStrip = this.CmnNotify;
            this.NtfMain.Icon = ((System.Drawing.Icon)(resources.GetObject("NtfMain.Icon")));
            this.NtfMain.Text = "Управление электроприборами\r\nквартиры";
            // 
            // CmnNotify
            // 
            this.CmnNotify.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.CmnNotify.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.CmiRestore,
            this.CmiNotifySeparator1,
            this.CmiAbout,
            this.CmiNotifySeparator2,
            this.CmiExit});
            this.CmnNotify.Name = "contextMenuStrip1";
            this.CmnNotify.Size = new System.Drawing.Size(183, 88);
            // 
            // CmiRestore
            // 
            this.CmiRestore.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.CmiRestore.Name = "CmiRestore";
            this.CmiRestore.Size = new System.Drawing.Size(182, 24);
            this.CmiRestore.Text = "Восстановить";
            this.CmiRestore.Click += new System.EventHandler(this.FromTray_Command);
            // 
            // CmiNotifySeparator1
            // 
            this.CmiNotifySeparator1.Name = "CmiNotifySeparator1";
            this.CmiNotifySeparator1.Size = new System.Drawing.Size(179, 6);
            // 
            // CmiAbout
            // 
            this.CmiAbout.Name = "CmiAbout";
            this.CmiAbout.Size = new System.Drawing.Size(182, 24);
            this.CmiAbout.Text = "О программе...";
            this.CmiAbout.Click += new System.EventHandler(this.About_Command);
            // 
            // CmiNotifySeparator2
            // 
            this.CmiNotifySeparator2.Name = "CmiNotifySeparator2";
            this.CmiNotifySeparator2.Size = new System.Drawing.Size(179, 6);
            // 
            // CmiExit
            // 
            this.CmiExit.Name = "CmiExit";
            this.CmiExit.Size = new System.Drawing.Size(182, 24);
            this.CmiExit.Text = "Выход";
            this.CmiExit.Click += new System.EventHandler(this.Exit_Command);
            // 
            // StsMain
            // 
            this.StsMain.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.StsMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.TslTrainCarsCount,
            this.TslSales,
            this.TslSleepping,
            this.TslCompartment,
            this.TslReserved});
            this.StsMain.Location = new System.Drawing.Point(0, 493);
            this.StsMain.Name = "StsMain";
            this.StsMain.Size = new System.Drawing.Size(874, 25);
            this.StsMain.TabIndex = 5;
            this.StsMain.Text = "statusStrip1";
            // 
            // TslTrainCarsCount
            // 
            this.TslTrainCarsCount.AutoSize = false;
            this.TslTrainCarsCount.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenInner;
            this.TslTrainCarsCount.Name = "TslTrainCarsCount";
            this.TslTrainCarsCount.Padding = new System.Windows.Forms.Padding(6, 0, 0, 0);
            this.TslTrainCarsCount.Size = new System.Drawing.Size(200, 20);
            this.TslTrainCarsCount.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // TslSales
            // 
            this.TslSales.AutoSize = false;
            this.TslSales.BackColor = System.Drawing.Color.LightGreen;
            this.TslSales.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenInner;
            this.TslSales.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.TslSales.Name = "TslSales";
            this.TslSales.Padding = new System.Windows.Forms.Padding(6, 0, 0, 0);
            this.TslSales.Size = new System.Drawing.Size(140, 20);
            this.TslSales.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // TslSleepping
            // 
            this.TslSleepping.AutoSize = false;
            this.TslSleepping.BackColor = System.Drawing.Color.LightPink;
            this.TslSleepping.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenInner;
            this.TslSleepping.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.TslSleepping.Name = "TslSleepping";
            this.TslSleepping.Padding = new System.Windows.Forms.Padding(6, 0, 0, 0);
            this.TslSleepping.Size = new System.Drawing.Size(161, 20);
            this.TslSleepping.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // TslCompartment
            // 
            this.TslCompartment.BackColor = System.Drawing.Color.LightBlue;
            this.TslCompartment.Name = "TslCompartment";
            this.TslCompartment.Size = new System.Drawing.Size(179, 20);
            this.TslCompartment.Spring = true;
            this.TslCompartment.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // TslReserved
            // 
            this.TslReserved.BackColor = System.Drawing.Color.LightSteelBlue;
            this.TslReserved.Name = "TslReserved";
            this.TslReserved.Size = new System.Drawing.Size(179, 20);
            this.TslReserved.Spring = true;
            this.TslReserved.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 67);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.TrvTrain);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.DgvTrain);
            this.splitContainer1.Size = new System.Drawing.Size(874, 426);
            this.splitContainer1.SplitterDistance = 202;
            this.splitContainer1.TabIndex = 6;
            // 
            // TrvTrain
            // 
            this.TrvTrain.AllowDrop = true;
            this.TrvTrain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TrvTrain.Location = new System.Drawing.Point(0, 0);
            this.TrvTrain.Name = "TrvTrain";
            treeNode2.Name = "ApartmentNode";
            treeNode2.Text = "Поезд";
            this.TrvTrain.Nodes.AddRange(new System.Windows.Forms.TreeNode[] {
            treeNode2});
            this.TrvTrain.Size = new System.Drawing.Size(202, 426);
            this.TrvTrain.TabIndex = 0;
            this.TrvTrain.NodeMouseClick += new System.Windows.Forms.TreeNodeMouseClickEventHandler(this.CorrectBehavor_NodeMouseClick);
            this.TrvTrain.DragDrop += new System.Windows.Forms.DragEventHandler(this.DragDrop_Command);
            this.TrvTrain.DragEnter += new System.Windows.Forms.DragEventHandler(this.DragEnter_Command);
            // 
            // DgvTrain
            // 
            this.DgvTrain.AllowDrop = true;
            this.DgvTrain.AllowUserToAddRows = false;
            this.DgvTrain.AllowUserToDeleteRows = false;
            this.DgvTrain.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.DgvTrain.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DgvTrain.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ColTrainCarNum,
            this.ColTrainCarType,
            this.ColComNum,
            this.ColPlaceNum,
            this.ColState});
            this.DgvTrain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.DgvTrain.Location = new System.Drawing.Point(0, 0);
            this.DgvTrain.MultiSelect = false;
            this.DgvTrain.Name = "DgvTrain";
            this.DgvTrain.ReadOnly = true;
            this.DgvTrain.RowHeadersVisible = false;
            this.DgvTrain.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DgvTrain.Size = new System.Drawing.Size(668, 426);
            this.DgvTrain.TabIndex = 0;
            this.DgvTrain.DragDrop += new System.Windows.Forms.DragEventHandler(this.DragDrop_Command);
            this.DgvTrain.DragEnter += new System.Windows.Forms.DragEventHandler(this.DragEnter_Command);
            // 
            // ColTrainCarNum
            // 
            this.ColTrainCarNum.FillWeight = 10F;
            this.ColTrainCarNum.HeaderText = "Номер вагона";
            this.ColTrainCarNum.Name = "ColTrainCarNum";
            this.ColTrainCarNum.ReadOnly = true;
            // 
            // ColTrainCarType
            // 
            this.ColTrainCarType.FillWeight = 15F;
            this.ColTrainCarType.HeaderText = "Тип вагона";
            this.ColTrainCarType.Name = "ColTrainCarType";
            this.ColTrainCarType.ReadOnly = true;
            // 
            // ColComNum
            // 
            this.ColComNum.FillWeight = 20F;
            this.ColComNum.HeaderText = "Номер купе";
            this.ColComNum.Name = "ColComNum";
            this.ColComNum.ReadOnly = true;
            // 
            // ColPlaceNum
            // 
            this.ColPlaceNum.FillWeight = 25F;
            this.ColPlaceNum.HeaderText = "Номер места";
            this.ColPlaceNum.Name = "ColPlaceNum";
            this.ColPlaceNum.ReadOnly = true;
            // 
            // ColState
            // 
            this.ColState.FillWeight = 20F;
            this.ColState.HeaderText = "Состояние места";
            this.ColState.Name = "ColState";
            this.ColState.ReadOnly = true;
            // 
            // SfdMain
            // 
            this.SfdMain.DefaultExt = "json";
            this.SfdMain.Filter = "Данные квартиры (*.json)|*.json|Все файлы (*.*)|*.*";
            this.SfdMain.Title = "Сохранить данные квартиры";
            // 
            // OfdMain
            // 
            this.OfdMain.Filter = "Данные квартиры (*.json)|*.json|Все файлы (*.*)|*.*";
            this.OfdMain.Title = "Открыть файл данных квартиры";
            // 
            // CmnTrainCar
            // 
            this.CmnTrainCar.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem3,
            this.toolStripMenuItem2});
            this.CmnTrainCar.Name = "CmnTrainCar";
            this.CmnTrainCar.Size = new System.Drawing.Size(181, 70);
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(180, 22);
            this.toolStripMenuItem3.Text = "Добавить вагон...";
            this.toolStripMenuItem3.Click += new System.EventHandler(this.AddTrainCarCommand_Command);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(169, 22);
            this.toolStripMenuItem2.Text = "Удалить вагон";
            this.toolStripMenuItem2.Click += new System.EventHandler(this.RemoveTrainCar_Command);
            // 
            // TsbNew
            // 
            this.TsbNew.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbNew.Image = global::TrainTickets.Properties.Resources.Create;
            this.TsbNew.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbNew.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbNew.Name = "TsbNew";
            this.TsbNew.Size = new System.Drawing.Size(34, 36);
            this.TsbNew.Text = "toolStripButton1";
            this.TsbNew.ToolTipText = "Новые данные...";
            this.TsbNew.Click += new System.EventHandler(this.Generate_Command);
            // 
            // TsbOpen
            // 
            this.TsbOpen.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbOpen.Image = global::TrainTickets.Properties.Resources.folder_blue;
            this.TsbOpen.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbOpen.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbOpen.Name = "TsbOpen";
            this.TsbOpen.Size = new System.Drawing.Size(36, 36);
            this.TsbOpen.Text = "toolStripButton2";
            this.TsbOpen.ToolTipText = "Открыть файл данных...";
            this.TsbOpen.Click += new System.EventHandler(this.OpenFile_Command);
            // 
            // TsbSave
            // 
            this.TsbSave.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbSave.Image = global::TrainTickets.Properties.Resources.save_as;
            this.TsbSave.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbSave.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbSave.Name = "TsbSave";
            this.TsbSave.Size = new System.Drawing.Size(36, 36);
            this.TsbSave.Text = "toolStripButton3";
            this.TsbSave.ToolTipText = "Сохранить данные \r\n";
            this.TsbSave.Click += new System.EventHandler(this.SaveAs_Command);
            // 
            // TsbToTray
            // 
            this.TsbToTray.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbToTray.Image = global::TrainTickets.Properties.Resources.ToTray;
            this.TsbToTray.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbToTray.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbToTray.Name = "TsbToTray";
            this.TsbToTray.Size = new System.Drawing.Size(34, 36);
            this.TsbToTray.Text = "toolStripButton6";
            this.TsbToTray.ToolTipText = "в трей";
            this.TsbToTray.Click += new System.EventHandler(this.ToTray_Command);
            // 
            // TsbReturnTicket
            // 
            this.TsbReturnTicket.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbReturnTicket.Image = global::TrainTickets.Properties.Resources.shuffle;
            this.TsbReturnTicket.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbReturnTicket.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbReturnTicket.Name = "TsbReturnTicket";
            this.TsbReturnTicket.Size = new System.Drawing.Size(34, 36);
            this.TsbReturnTicket.ToolTipText = "Возврат билета";
            this.TsbReturnTicket.Click += new System.EventHandler(this.ReturnTicket_Command);
            // 
            // TsbSellTicket
            // 
            this.TsbSellTicket.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbSellTicket.Image = global::TrainTickets.Properties.Resources.Cost;
            this.TsbSellTicket.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbSellTicket.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbSellTicket.Name = "TsbSellTicket";
            this.TsbSellTicket.Size = new System.Drawing.Size(34, 36);
            this.TsbSellTicket.ToolTipText = "Продажа билета";
            this.TsbSellTicket.Click += new System.EventHandler(this.SellTicket_Command);
            // 
            // TsbAbout
            // 
            this.TsbAbout.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbAbout.Image = global::TrainTickets.Properties.Resources.help;
            this.TsbAbout.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbAbout.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbAbout.Name = "TsbAbout";
            this.TsbAbout.Size = new System.Drawing.Size(36, 36);
            this.TsbAbout.ToolTipText = "Сведения о приложении и разработчике";
            this.TsbAbout.Click += new System.EventHandler(this.About_Command);
            // 
            // MainForm
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.ClientSize = new System.Drawing.Size(874, 518);
            this.Controls.Add(this.splitContainer1);
            this.Controls.Add(this.StsMain);
            this.Controls.Add(this.TstMain);
            this.Controls.Add(this.MnsMain);
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Задание на 16.12.2021";
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.TstMain.ResumeLayout(false);
            this.TstMain.PerformLayout();
            this.MnsMain.ResumeLayout(false);
            this.MnsMain.PerformLayout();
            this.CmnNotify.ResumeLayout(false);
            this.StsMain.ResumeLayout(false);
            this.StsMain.PerformLayout();
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DgvTrain)).EndInit();
            this.CmnTrainCar.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStrip TstMain;
        private System.Windows.Forms.ToolStripButton TsbNew;
        private System.Windows.Forms.ToolStripButton TsbOpen;
        private System.Windows.Forms.ToolStripButton TsbSave;
        private System.Windows.Forms.ToolStripSeparator TstSeparator1;
        private System.Windows.Forms.ToolStripButton TsbToTray;
        private System.Windows.Forms.ToolStripSeparator TstSeparator2;
        private System.Windows.Forms.ToolStripButton TsbReturnTicket;
        private System.Windows.Forms.ToolStripButton TsbSellTicket;
        private System.Windows.Forms.ToolStripSeparator TstSeparator3;
        private System.Windows.Forms.ToolStripButton TsbAbout;
        private System.Windows.Forms.ToolStripButton TsbExit;
        private System.Windows.Forms.MenuStrip MnsMain;
        private System.Windows.Forms.ToolStripMenuItem MniFile;
        private System.Windows.Forms.ToolStripMenuItem MniFileOpen;
        private System.Windows.Forms.ToolStripSeparator MniFileSeparator1;
        private System.Windows.Forms.ToolStripMenuItem MniFileSaveAs;
        private System.Windows.Forms.ToolStripSeparator MniFileSeparator2;
        private System.Windows.Forms.ToolStripMenuItem MniFileExit;
        private System.Windows.Forms.ToolStripMenuItem MniTrain;
        private System.Windows.Forms.ToolStripMenuItem новыеДанныеToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem MniControl;
        private System.Windows.Forms.ToolStripMenuItem MniControlToTray;
        private System.Windows.Forms.ToolStripSeparator MniControlSeparator1;
        private System.Windows.Forms.ToolStripMenuItem MniControlSellTicket;
        private System.Windows.Forms.ToolStripMenuItem MniControlReturnTicket;
        private System.Windows.Forms.ToolStripSeparator MniControlSeparator2;
        private System.Windows.Forms.ToolStripMenuItem MniHelp;
        private System.Windows.Forms.ToolStripMenuItem MniHelpAbout;
        private System.Windows.Forms.NotifyIcon NtfMain;
        private System.Windows.Forms.StatusStrip StsMain;
        private System.Windows.Forms.ToolStripStatusLabel TslTrainCarsCount;
        private System.Windows.Forms.ToolStripStatusLabel TslSales;
        private System.Windows.Forms.ToolStripStatusLabel TslSleepping;
        private System.Windows.Forms.ToolStripStatusLabel TslReserved;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.TreeView TrvTrain;
        private System.Windows.Forms.DataGridView DgvTrain;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColTrainCarNum;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColTrainCarType;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColComNum;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColPlaceNum;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColState;
        private System.Windows.Forms.ToolStripStatusLabel TslCompartment;
        private System.Windows.Forms.SaveFileDialog SfdMain;
        private System.Windows.Forms.OpenFileDialog OfdMain;
        private System.Windows.Forms.ToolStripMenuItem MniFileSave;
        private System.Windows.Forms.ToolStripMenuItem MniControlAddTrainCar;
        private System.Windows.Forms.ContextMenuStrip CmnTrainCar;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem3;
        private System.Windows.Forms.ContextMenuStrip CmnNotify;
        private System.Windows.Forms.ToolStripMenuItem CmiRestore;
        private System.Windows.Forms.ToolStripSeparator CmiNotifySeparator1;
        private System.Windows.Forms.ToolStripMenuItem CmiAbout;
        private System.Windows.Forms.ToolStripSeparator CmiNotifySeparator2;
        private System.Windows.Forms.ToolStripMenuItem CmiExit;
    }
}

