﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TrainTickets.Helpers;

namespace TrainTickets.Models
{
    public class Train {
        // кол-во купе в вагоне
        const int CountTrainCars = 20;

        private string _number;
        public string Number {
            get => _number;
            set {
                if (String.IsNullOrWhiteSpace(value))
                    throw new Exception("Train: Некорректный номер пезда!");
                _number = value;
            } // set 
        } // Number

        private List<TrainCar> _trainCars;
        public List<TrainCar> TrainCars {
            get => _trainCars;
            private set => _trainCars = value;
        } // TrainCars

        // конструкторы
        public Train() : this("126 4A", new List<TrainCar>()) {
        } // Flat

        public Train(string number, List<TrainCar> trainCars) {
            _number = number;
            _trainCars = trainCars;
            Initialize(4);
            // Initialize(Utils.GetRandom(2, 4));
            //Initialize(1);
        } // Train

        public void Initialize(int n) {
            _trainCars.Clear();
            int lastPlaceNum = 1;
            Utils.TrainCarType type;
            type = Utils.RandomEnum<Utils.TrainCarType>();
            for (int i = 0; i < n; i++) {
                // генерация случайного типа вагона
                type = Utils.RandomEnum<Utils.TrainCarType>();
                // добавление вагона
                _trainCars.Add(new TrainCar(type, i + 1, lastPlaceNum));
                // запомнить номер последнего места в вагоне 
                lastPlaceNum += _trainCars[i].LastNum;
            } // for i
        } // Initialize

        // заполнение строк DataGridView
        public List<DataGridViewRow> ToDataGridViewRow() {
            List<DataGridViewRow> rows = new List<DataGridViewRow>();

            for (int i = 0; i < _trainCars.Count; i++) {
                for (int j = 0; j < _trainCars[i].Compartments.Length; j++) {
                    for (int k = 0; k < _trainCars[i].Compartments[j].Places.Length; k++) {
                        DataGridViewRow row = new DataGridViewRow();

                        // номер вагона
                        DataGridViewCell cell = new DataGridViewTextBoxCell();
                        cell.Value = $"{_trainCars[i].Number}";
                        cell.Style.Alignment = DataGridViewContentAlignment.MiddleRight;
                        row.Cells.Add(cell);

                        // тип вагона
                        cell = new DataGridViewTextBoxCell();
                        (cell.Value, cell.Style.BackColor) = (int)_trainCars[i].Type == 2
                         ? ("СП", Color.LightPink)
                         : (int)_trainCars[i].Type == 4
                             ? ("Купейный", Color.LightBlue)
                             : ("Плацкартный ", Color.LightSteelBlue);
                        cell.Style.Alignment = DataGridViewContentAlignment.MiddleLeft;
                        row.Cells.Add(cell);

                        // номер купе
                        cell = new DataGridViewTextBoxCell();
                        cell.Value = $"{j + 1}";
                        cell.Style.Alignment = DataGridViewContentAlignment.MiddleRight;
                        row.Cells.Add(cell);


                        // номер места
                        cell = new DataGridViewTextBoxCell();
                        cell.Value = $"{_trainCars[i].Compartments[j].Places[k].Number}";
                        cell.Style.Alignment = DataGridViewContentAlignment.MiddleRight;
                        row.Cells.Add(cell);

                        // номер места
                        cell = new DataGridViewTextBoxCell();
                        (cell.Value, cell.Style.BackColor) = _trainCars[i].Compartments[j].Places[k].State
                            ? ("Cвободно", Color.Green)
                            : ("Продано", Color.Yellow);
                        cell.Style.Alignment = DataGridViewContentAlignment.MiddleRight;
                        row.Cells.Add(cell);
                        row.Tag = _trainCars[i].Compartments[j].Places[k];
                        rows.Add(row);
                    } // for j
                } // for j
            } // for i
            
            return rows;
        } // ToDataGridViewRow

        // кол-во проданных билетов
        public int CountSales() {
            int count = 0;
            for (int i = 0; i < _trainCars.Count; i++)
                count += _trainCars[i].CountSales();
            return count;
        } // CountSales

        // кол-во билетов
        public int Count() {
            int count = 0;
            for (int i = 0; i < _trainCars.Count; i++)
                count += _trainCars[i].Count();
            return count;
        } // Count

        // кол-во проданных билетов
        public int CountSales(Utils.TrainCarType type) {
            int count = 0;
            for (int i = 0; i < _trainCars.Count; i++)
                count += _trainCars[i].CountSales(type);
            return count;
        } // CountSales

        // кол-во билетов
        public int Count(Utils.TrainCarType type) {
            int count = 0;
            for (int i = 0; i < _trainCars.Count; i++)
                count += _trainCars[i].Count(type);
            return count;
        } // Count

        // кол-во вагонов
        public int CountTrainCarsByType(Utils.TrainCarType type) {
            int count = 0;
            for (int i = 0; i < _trainCars.Count; i++)
                count += _trainCars[i].Type == type? 1: 0;
            return count;
        } // Count
    } // Train
}
