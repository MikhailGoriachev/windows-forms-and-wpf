﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Railway.Controllers;
using Railway.Models;


namespace Railway.Views
{
	public partial class MainForm : Form
	{
		// Коды изображений из ImageList
		enum ImgCodes
		{
			NotAvailable, Available, Train, Car, Cmp
		}


		// Объект контроллера для работы с коллекцией
		private TrainController _trainController;

		public MainForm():this(new TrainController())
		{}

		public MainForm(TrainController trainController)
		{
			InitializeComponent();
			_trainController = trainController;
		}

		private void MainForm_Load(object sender, EventArgs e)
		{
			InitializeTreeView();

			// Отключение генерации столбцов для привязанных данных
			DgvMain.AutoGenerateColumns = false;
			
			// Заполнение таблицы данными первого вагона
			DgvMain.DataSource = _trainController.GetTableModel(_trainController.Train[0]);

			// Настройка созданных столбцов на свойства при привязке данных
			ClnNum.DataPropertyName = "CarNumber";
			ClnType.DataPropertyName = "CarType";
			ClnPlaceNum.DataPropertyName = "PlaceNumber";
			ClnCmpNumber.DataPropertyName = "CompartmentNumber";
			ClnState.DataPropertyName = "PlaceState";
		}

		// выход из приложения
		private void Exit_Command(object sender, EventArgs e) => Close();


		#region Обработка TreeView

		// Метод заполнения TreeView коллекцией приборов
		private void InitializeTreeView()
		{
			TrvMain.Nodes.Clear();

			// создание корня - поезд
			var nodeTrain = TrvMain.Nodes.Add("",$"Поезд №{_trainController.Train.Number}",
				(int)ImgCodes.Train, (int)ImgCodes.Train);

			nodeTrain.ContextMenuStrip = CmnTrvTrain;

			// цикл по вагонам
			_trainController.Train.Cars.ForEach(car =>
			{
				// добавить узел вагона
				var nodeCar = nodeTrain.Nodes.Add("",$"Вагон: {car.Number}",
					(int)ImgCodes.Car, (int)ImgCodes.Car);
				
				nodeCar.Tag = car;
				nodeCar.ContextMenuStrip = CmnTrvCar;

				// цикл по купе вагона
				car.Compartments.ForEach(cmp =>
				{
					// добавить узел купе
					var nodeCmp = nodeCar.Nodes.Add("",$"{cmp.Type}: {cmp.Number}", (int)ImgCodes.Cmp, (int)ImgCodes.Cmp);
					nodeCmp.Tag = cmp;
					//цикл по местам купе
					cmp.Places.ForEach(place =>
					{
						int img = place.State ? (int)ImgCodes.Available : (int)ImgCodes.NotAvailable;
						// добавить лист "место" к купе
						var nodePlace = nodeCmp.Nodes.Add("", $"место: {place.Number}", img, img);
						nodePlace.Tag = place;
						nodePlace.ContextMenuStrip = CmnTrvPlace;
					});
				});

			});

			TrvMain.Nodes[0].Expand();
		}

		// Обработка действий по клику кнопками мыши на TreeView
		private void TrvMain_NodeMouseClick(object sender, TreeNodeMouseClickEventArgs e) {
			
			// Установить выделение на выбранный элемент дерева
			TrvMain.SelectedNode = e.Node;

			// Если не корень - установить выделение в DataGridView на место\вагон
			if (e.Node.Level > 0)
				if (e.Node.Level == 3)
				{
					DgvSelectPlace(e.Node);
					// для контекстного меню блокировка соответствующих пунктов
					if (e.Button == MouseButtons.Right)
					{
						bool state = ((Place) e.Node.Tag).State;
						CmnTrvBuy.Enabled = state;
						CmnTrvRefund.Enabled = !state;
					}
				}
				else
					DgvBindCurrentNodeCar(e.Node);

		}
		
		#region Контекстное меню TreeView

		// покупка билета из контекстного меню TreeView
		private void BuyTicketTrv_Click(object sender, EventArgs e)
		{
			var selected = TrvMain.SelectedNode;
			((Place) selected.Tag).State = false;
			selected.ImageIndex = selected.SelectedImageIndex = (int) ImgCodes.NotAvailable;
			DgvBindCurrentNodeCar(selected);
			DgvSelectPlace(selected);
		}

		// возврат билета из контекстного меню TreeView
		private void RefundTicketTrv_Click(object sender, EventArgs e)
		{
			var selected = TrvMain.SelectedNode;
			((Place)selected.Tag).State = true;
			selected.ImageIndex = selected.SelectedImageIndex = (int)ImgCodes.Available;
			DgvBindCurrentNodeCar(selected);
			DgvSelectPlace(selected);
		}


		// добавить вагон СВ
		private void CmnTrvAddSv_Click(object sender, EventArgs e)
		{
			_trainController.AddCar("св");
			InitializeTreeView();
			TrvMain.SelectedNode = TrvMain.Nodes[0].LastNode;
		}

		// добавить вагон купе
		private void CmnTrvAddCoupe_Click(object sender, EventArgs e)
		{
			_trainController.AddCar("купе");
			InitializeTreeView();
			TrvMain.SelectedNode = TrvMain.Nodes[0].LastNode;
		}

		// добавить вагон плацкарт
		private void CmnTrvAddEconomy_Click(object sender, EventArgs e)
		{
			_trainController.AddCar("плацкарт");
			InitializeTreeView();
			TrvMain.SelectedNode = TrvMain.Nodes[0].LastNode;
		}

		// удалить вагон
		private void CmnTrvRemove_Click(object sender, EventArgs e)
		{
			_trainController.RemoveCar((Car)TrvMain.SelectedNode.Tag);
			InitializeTreeView();

			// обновление DataGridView, если остались объекты вагонов
			DgvMain.DataSource = TrvMain.Nodes[0].FirstNode != null ? _trainController.GetTableModel((Car) TrvMain.Nodes[0].FirstNode.Tag) : null;
		}
		#endregion


		#endregion

		#region Обработка DataGridView

		// Привязать к DataGridView данные вагона по выбранному узлу дерева
		public void DgvBindCurrentNodeCar(TreeNode carNode)
		{
			// оставить сам узел, если выбран вагон, либо добраться до него
			int level = carNode.Level;
			for (int i = 1; i < level; i++)
				carNode = carNode.Parent;

			// привязка в DataGridView по табличному представлению выбранного вагона
			DgvMain.DataSource = _trainController.GetTableModel((Car)carNode.Tag);
		}

		// громоздкая реализация выделения в DataGridView нужного места по выбранному в ListTreeView
		public void DgvSelectPlace(TreeNode node)
		{
			var cmp = node.Parent; // текущее купе 
			var cmpTmp = cmp.Parent.FirstNode; // первое купе в вагоне
			int offset = ((Place)node.Tag).Number - 1; // смешение для DataGridView

			while (cmpTmp != cmp)
			{
				offset += ((Compartment)cmpTmp.Tag).Places.Count;
				cmpTmp = cmpTmp.NextNode;
			}

			DgvMain.CurrentCell = DgvMain.Rows[offset].Cells[0];
		}

		#endregion



		#region Drag'n'Drop
		private void Command_DragEnter(object sender, DragEventArgs e) =>
			e.Effect = e.Data.GetDataPresent(DataFormats.FileDrop) ? DragDropEffects.Move : DragDropEffects.None;

		private void Command_DragDrop(object sender, DragEventArgs e)
		{
			if (!e.Data.GetDataPresent(DataFormats.FileDrop))
				return;

			_trainController.ReadJsonFromFile(((string[])e.Data.GetData(DataFormats.FileDrop))[0]);

			// обновление элементов интерфейса
			InitializeTreeView();
			DgvMain.DataSource = _trainController.GetTableModel(_trainController.Train[0]);
			
		}

		#endregion
	}
}
