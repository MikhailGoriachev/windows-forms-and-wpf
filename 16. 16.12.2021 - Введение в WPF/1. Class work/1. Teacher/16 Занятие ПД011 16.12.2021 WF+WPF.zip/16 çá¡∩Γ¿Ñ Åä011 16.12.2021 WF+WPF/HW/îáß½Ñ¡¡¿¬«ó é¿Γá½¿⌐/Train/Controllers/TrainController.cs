﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Railway.Helpers;
using Railway.Models;

namespace Railway.Controllers
{
	// контроллер для класса Train
	public class TrainController
	{
		// объект модели данных
		private Train _train;
		public Train Train
		{
			get => _train;
			set
			{
				_train = value;
			}
		}

		// коллекция для представления в таблице
		private List<CarTableModel> _trainTable;

		public List<CarTableModel> TrainTable
		{
			get => _trainTable;
			set
			{
				_trainTable = value;
			}
		}

		// вернуть коллекцию вагонов поезда
		public List<Car> Cars => _train.Cars;


		// директория и имя файля для сохранения
		public string FileName { get; set; }

		// директория и имя файля для сохранения по-умолчанию
		public static readonly string FileNameDefault = Environment.CurrentDirectory + @"\App_Data\train.json";

		// конструкторы
		public TrainController() : this(FileNameDefault, new Train())
		{
			string dir = Path.GetDirectoryName(FileNameDefault);
			if (!Directory.Exists(dir))
				Directory.CreateDirectory(dir);
			
			if (File.Exists(FileNameDefault))
				ReadJsonFromFile(FileNameDefault);
			else
			{
				Initialize();
				SaveJsonToFile(FileNameDefault);
			}
		}

		public TrainController(string fileName, Train train)
		{
			_train = Train;
			_trainTable = new List<CarTableModel>();
			FileName = fileName;
		}

		private void Initialize()
		{
			string[] departures =
			{
				"Отправка1", "Отправка2", "Отправка3", "Отправка4", "Отправка5", "Отправка6", "Отправка7", "Отправка8",
				"Отправка9", "Отправка10", "Отправка11", "Отправка12", "Отправка13","Отправка14", "Отправка15","Отправка16"
			};
			
			string[] destinations =
			{
				"Назначение1", "Назначение2", "Назначение3", "Назначение4", "Назначение5", "Назначение6", "Назначение7",
				"Назначение8", "Назначение9", "Назначение10", "Назначение11", "Назначение12", "Назначение13", "Назначение14",
				"Назначение15", "Назначение16"
			};
			
			string number = Utils.GetRandom(100, 400).ToString();
			string departure = departures[Utils.GetRandom(0, departures.Length - 1)];
			string destination = destinations[Utils.GetRandom(0, destinations.Length - 1)];

			Train = Train.Generate(number, departure, destination);
		}


		public List<CarTableModel> GetTableModel(Car car)
		{
			List<CarTableModel> carTable = new List<CarTableModel>();

			foreach (var cmp in car.Compartments)
				foreach (var place in cmp.Places)
					carTable.Add(new CarTableModel()
					{
						CarNumber = car.Number,
						CarType = car.Type,
						CompartmentNumber = cmp.Number,
						PlaceNumber = place.Number,
						PlaceState = place.StateToString,
					});

			return carTable;
		}


		public void InitTableModel()
		{
			_trainTable.Clear();

			foreach (var car in _train.Cars)
				foreach (var cmp in car.Compartments)
					foreach (var place in cmp.Places)
						_trainTable.Add(new CarTableModel()
						{
							CarNumber = car.Number,
							CarType = car.Type,
							CompartmentNumber = cmp.Number,
							PlaceNumber = place.Number,
							PlaceState = place.StateToString,
						});
		}

		public void AddCar(string type) => _train.AddCar(type);

		public void RemoveCar(Car car) => _train.RemoveCar(car);

		#region Сериализация
		// Сохранение в файл JSON форматом
		public void SaveJsonToFile(string fileName)
		{
			using (StreamWriter file = File.CreateText(fileName))
			{
				new JsonSerializer { Formatting = Formatting.Indented }.Serialize(file, _train);
			}
		}

		// Чтение из файла JSON форматом
		public void ReadJsonFromFile(string fileName)
		{

			using (StreamReader file = File.OpenText(fileName))
			{
				JsonSerializer serializer = new JsonSerializer();
				_train = (Train)serializer.Deserialize(file, typeof(Train));
				FileName = fileName;
			}
		}
		#endregion

	}
}
