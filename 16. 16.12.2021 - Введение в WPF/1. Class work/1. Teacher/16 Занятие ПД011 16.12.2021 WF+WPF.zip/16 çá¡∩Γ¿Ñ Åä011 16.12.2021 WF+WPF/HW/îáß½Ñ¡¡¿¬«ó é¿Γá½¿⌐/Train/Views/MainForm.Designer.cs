﻿
namespace Railway.Views
{
	partial class MainForm
	{
		/// <summary>
		/// Обязательная переменная конструктора.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Освободить все используемые ресурсы.
		/// </summary>
		/// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Код, автоматически созданный конструктором форм Windows

		/// <summary>
		/// Требуемый метод для поддержки конструктора — не изменяйте 
		/// содержимое этого метода с помощью редактора кода.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
			this.TsbMain = new System.Windows.Forms.ToolStrip();
			this.TsbAdd = new System.Windows.Forms.ToolStripButton();
			this.StlMain = new System.Windows.Forms.StatusStrip();
			this.SpcMain = new System.Windows.Forms.SplitContainer();
			this.TrvMain = new System.Windows.Forms.TreeView();
			this.ImlTree = new System.Windows.Forms.ImageList(this.components);
			this.DgvMain = new System.Windows.Forms.DataGridView();
			this.ClnNum = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.ClnType = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.ClnCmpNumber = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.ClnPlaceNum = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.ClnState = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.MniMain = new System.Windows.Forms.MenuStrip();
			this.MniFile = new System.Windows.Forms.ToolStripMenuItem();
			this.MniFileExit = new System.Windows.Forms.ToolStripMenuItem();
			this.CmnTrvTrain = new System.Windows.Forms.ContextMenuStrip(this.components);
			this.CmnTrvAdd = new System.Windows.Forms.ToolStripMenuItem();
			this.CmnTrvAddSv = new System.Windows.Forms.ToolStripMenuItem();
			this.CmnTrvAddCoupe = new System.Windows.Forms.ToolStripMenuItem();
			this.CmnTrvAddEconomy = new System.Windows.Forms.ToolStripMenuItem();
			this.CmnTrvCar = new System.Windows.Forms.ContextMenuStrip(this.components);
			this.CmnTrvRemove = new System.Windows.Forms.ToolStripMenuItem();
			this.CmnTrvPlace = new System.Windows.Forms.ContextMenuStrip(this.components);
			this.CmnTrvBuy = new System.Windows.Forms.ToolStripMenuItem();
			this.CmnTrvRefund = new System.Windows.Forms.ToolStripMenuItem();
			this.BnsTrain = new System.Windows.Forms.BindingSource(this.components);
			this.поездToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.билетыToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.справкаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.TsbRemove = new System.Windows.Forms.ToolStripButton();
			this.TsbBuy = new System.Windows.Forms.ToolStripButton();
			this.TsbRefund = new System.Windows.Forms.ToolStripButton();
			this.оПрограммеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
			this.TsbNew = new System.Windows.Forms.ToolStripButton();
			this.TsbOpen = new System.Windows.Forms.ToolStripButton();
			this.TsbSave = new System.Windows.Forms.ToolStripButton();
			this.TsbSaveAs = new System.Windows.Forms.ToolStripButton();
			this.TsbRemoveAll = new System.Windows.Forms.ToolStripButton();
			this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
			this.создатьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.открытьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.сохранитьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.сохранитьКакToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
			this.добавитьВагонToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.удалитьВагонToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
			this.удалитьВсеВагоныToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.купитьБилетToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.возвратБилетаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.TsbMain.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.SpcMain)).BeginInit();
			this.SpcMain.Panel1.SuspendLayout();
			this.SpcMain.Panel2.SuspendLayout();
			this.SpcMain.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.DgvMain)).BeginInit();
			this.MniMain.SuspendLayout();
			this.CmnTrvTrain.SuspendLayout();
			this.CmnTrvCar.SuspendLayout();
			this.CmnTrvPlace.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.BnsTrain)).BeginInit();
			this.SuspendLayout();
			// 
			// TsbMain
			// 
			this.TsbMain.ImageScalingSize = new System.Drawing.Size(30, 30);
			this.TsbMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.TsbNew,
            this.TsbOpen,
            this.TsbSave,
            this.TsbSaveAs,
            this.toolStripSeparator1,
            this.TsbAdd,
            this.TsbRemove,
            this.TsbRemoveAll,
            this.toolStripSeparator2,
            this.TsbBuy,
            this.TsbRefund});
			this.TsbMain.Location = new System.Drawing.Point(0, 24);
			this.TsbMain.Name = "TsbMain";
			this.TsbMain.Padding = new System.Windows.Forms.Padding(6, 1, 17, 1);
			this.TsbMain.Size = new System.Drawing.Size(954, 39);
			this.TsbMain.TabIndex = 0;
			this.TsbMain.Text = "toolStrip1";
			// 
			// TsbAdd
			// 
			this.TsbAdd.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.TsbAdd.Image = ((System.Drawing.Image)(resources.GetObject("TsbAdd.Image")));
			this.TsbAdd.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.TsbAdd.Name = "TsbAdd";
			this.TsbAdd.Size = new System.Drawing.Size(34, 34);
			this.TsbAdd.Text = "Добавить вагон";
			// 
			// StlMain
			// 
			this.StlMain.Location = new System.Drawing.Point(0, 400);
			this.StlMain.Name = "StlMain";
			this.StlMain.Size = new System.Drawing.Size(954, 22);
			this.StlMain.TabIndex = 1;
			// 
			// SpcMain
			// 
			this.SpcMain.BackColor = System.Drawing.Color.Transparent;
			this.SpcMain.Dock = System.Windows.Forms.DockStyle.Fill;
			this.SpcMain.Location = new System.Drawing.Point(0, 63);
			this.SpcMain.Name = "SpcMain";
			// 
			// SpcMain.Panel1
			// 
			this.SpcMain.Panel1.Controls.Add(this.TrvMain);
			// 
			// SpcMain.Panel2
			// 
			this.SpcMain.Panel2.Controls.Add(this.DgvMain);
			this.SpcMain.Size = new System.Drawing.Size(954, 337);
			this.SpcMain.SplitterDistance = 287;
			this.SpcMain.TabIndex = 2;
			// 
			// TrvMain
			// 
			this.TrvMain.Dock = System.Windows.Forms.DockStyle.Fill;
			this.TrvMain.ImageIndex = 0;
			this.TrvMain.ImageList = this.ImlTree;
			this.TrvMain.Location = new System.Drawing.Point(0, 0);
			this.TrvMain.Name = "TrvMain";
			this.TrvMain.SelectedImageIndex = 0;
			this.TrvMain.Size = new System.Drawing.Size(287, 337);
			this.TrvMain.TabIndex = 0;
			this.TrvMain.NodeMouseClick += new System.Windows.Forms.TreeNodeMouseClickEventHandler(this.TrvMain_NodeMouseClick);
			this.TrvMain.DragDrop += new System.Windows.Forms.DragEventHandler(this.Command_DragDrop);
			this.TrvMain.DragEnter += new System.Windows.Forms.DragEventHandler(this.Command_DragEnter);
			// 
			// ImlTree
			// 
			this.ImlTree.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("ImlTree.ImageStream")));
			this.ImlTree.TransparentColor = System.Drawing.Color.Transparent;
			this.ImlTree.Images.SetKeyName(0, "seat_sold.png");
			this.ImlTree.Images.SetKeyName(1, "seat_available.png");
			this.ImlTree.Images.SetKeyName(2, "train.png");
			this.ImlTree.Images.SetKeyName(3, "car.png");
			this.ImlTree.Images.SetKeyName(4, "cmp.png");
			// 
			// DgvMain
			// 
			this.DgvMain.AllowDrop = true;
			this.DgvMain.AllowUserToAddRows = false;
			this.DgvMain.AllowUserToDeleteRows = false;
			this.DgvMain.AllowUserToResizeColumns = false;
			this.DgvMain.AllowUserToResizeRows = false;
			this.DgvMain.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
			this.DgvMain.BackgroundColor = System.Drawing.SystemColors.Control;
			this.DgvMain.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.DgvMain.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
			this.DgvMain.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
			this.DgvMain.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ClnNum,
            this.ClnType,
            this.ClnCmpNumber,
            this.ClnPlaceNum,
            this.ClnState});
			this.DgvMain.Dock = System.Windows.Forms.DockStyle.Fill;
			this.DgvMain.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
			this.DgvMain.Location = new System.Drawing.Point(0, 0);
			this.DgvMain.MultiSelect = false;
			this.DgvMain.Name = "DgvMain";
			this.DgvMain.ReadOnly = true;
			this.DgvMain.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToDisplayedHeaders;
			this.DgvMain.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
			this.DgvMain.Size = new System.Drawing.Size(663, 337);
			this.DgvMain.TabIndex = 0;
			this.DgvMain.DragDrop += new System.Windows.Forms.DragEventHandler(this.Command_DragDrop);
			this.DgvMain.DragEnter += new System.Windows.Forms.DragEventHandler(this.Command_DragEnter);
			// 
			// ClnNum
			// 
			this.ClnNum.HeaderText = "Номер вагона";
			this.ClnNum.Name = "ClnNum";
			this.ClnNum.ReadOnly = true;
			this.ClnNum.Width = 140;
			// 
			// ClnType
			// 
			this.ClnType.HeaderText = "Тип вагона";
			this.ClnType.Name = "ClnType";
			this.ClnType.ReadOnly = true;
			this.ClnType.Width = 117;
			// 
			// ClnCmpNumber
			// 
			this.ClnCmpNumber.HeaderText = "Номер купе";
			this.ClnCmpNumber.Name = "ClnCmpNumber";
			this.ClnCmpNumber.ReadOnly = true;
			this.ClnCmpNumber.Width = 121;
			// 
			// ClnPlaceNum
			// 
			this.ClnPlaceNum.HeaderText = "Номер места";
			this.ClnPlaceNum.Name = "ClnPlaceNum";
			this.ClnPlaceNum.ReadOnly = true;
			this.ClnPlaceNum.Width = 134;
			// 
			// ClnState
			// 
			this.ClnState.HeaderText = "Статус";
			this.ClnState.Name = "ClnState";
			this.ClnState.ReadOnly = true;
			this.ClnState.Width = 87;
			// 
			// MniMain
			// 
			this.MniMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniFile,
            this.поездToolStripMenuItem,
            this.билетыToolStripMenuItem,
            this.справкаToolStripMenuItem});
			this.MniMain.Location = new System.Drawing.Point(0, 0);
			this.MniMain.Name = "MniMain";
			this.MniMain.Size = new System.Drawing.Size(954, 24);
			this.MniMain.TabIndex = 3;
			this.MniMain.Text = "menuStrip1";
			// 
			// MniFile
			// 
			this.MniFile.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.создатьToolStripMenuItem,
            this.открытьToolStripMenuItem,
            this.сохранитьToolStripMenuItem,
            this.сохранитьКакToolStripMenuItem,
            this.toolStripSeparator3,
            this.MniFileExit});
			this.MniFile.Name = "MniFile";
			this.MniFile.Size = new System.Drawing.Size(48, 20);
			this.MniFile.Text = "Файл";
			// 
			// MniFileExit
			// 
			this.MniFileExit.Name = "MniFileExit";
			this.MniFileExit.Size = new System.Drawing.Size(180, 22);
			this.MniFileExit.Text = "Выход";
			this.MniFileExit.Click += new System.EventHandler(this.Exit_Command);
			// 
			// CmnTrvTrain
			// 
			this.CmnTrvTrain.Font = new System.Drawing.Font("Segoe UI", 10F);
			this.CmnTrvTrain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.CmnTrvAdd});
			this.CmnTrvTrain.Name = "CmnTrvTrain";
			this.CmnTrvTrain.Size = new System.Drawing.Size(179, 28);
			// 
			// CmnTrvAdd
			// 
			this.CmnTrvAdd.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.CmnTrvAddSv,
            this.CmnTrvAddCoupe,
            this.CmnTrvAddEconomy});
			this.CmnTrvAdd.Name = "CmnTrvAdd";
			this.CmnTrvAdd.Size = new System.Drawing.Size(178, 24);
			this.CmnTrvAdd.Text = "Добавить вагон";
			// 
			// CmnTrvAddSv
			// 
			this.CmnTrvAddSv.Name = "CmnTrvAddSv";
			this.CmnTrvAddSv.Size = new System.Drawing.Size(138, 24);
			this.CmnTrvAddSv.Text = "СВ";
			this.CmnTrvAddSv.Click += new System.EventHandler(this.CmnTrvAddSv_Click);
			// 
			// CmnTrvAddCoupe
			// 
			this.CmnTrvAddCoupe.Name = "CmnTrvAddCoupe";
			this.CmnTrvAddCoupe.Size = new System.Drawing.Size(138, 24);
			this.CmnTrvAddCoupe.Text = "Купе";
			this.CmnTrvAddCoupe.Click += new System.EventHandler(this.CmnTrvAddCoupe_Click);
			// 
			// CmnTrvAddEconomy
			// 
			this.CmnTrvAddEconomy.Name = "CmnTrvAddEconomy";
			this.CmnTrvAddEconomy.Size = new System.Drawing.Size(138, 24);
			this.CmnTrvAddEconomy.Text = "Плацкарт";
			this.CmnTrvAddEconomy.Click += new System.EventHandler(this.CmnTrvAddEconomy_Click);
			// 
			// CmnTrvCar
			// 
			this.CmnTrvCar.Font = new System.Drawing.Font("Segoe UI", 10F);
			this.CmnTrvCar.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.CmnTrvRemove});
			this.CmnTrvCar.Name = "CmnTrvCar";
			this.CmnTrvCar.Size = new System.Drawing.Size(169, 28);
			// 
			// CmnTrvRemove
			// 
			this.CmnTrvRemove.Name = "CmnTrvRemove";
			this.CmnTrvRemove.Size = new System.Drawing.Size(168, 24);
			this.CmnTrvRemove.Text = "Удалить вагон";
			this.CmnTrvRemove.Click += new System.EventHandler(this.CmnTrvRemove_Click);
			// 
			// CmnTrvPlace
			// 
			this.CmnTrvPlace.Font = new System.Drawing.Font("Segoe UI", 10F);
			this.CmnTrvPlace.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.CmnTrvBuy,
            this.CmnTrvRefund});
			this.CmnTrvPlace.Name = "CmnTrvPlace";
			this.CmnTrvPlace.Size = new System.Drawing.Size(180, 52);
			// 
			// CmnTrvBuy
			// 
			this.CmnTrvBuy.Name = "CmnTrvBuy";
			this.CmnTrvBuy.Size = new System.Drawing.Size(179, 24);
			this.CmnTrvBuy.Text = "Покупка билета";
			this.CmnTrvBuy.Click += new System.EventHandler(this.BuyTicketTrv_Click);
			// 
			// CmnTrvRefund
			// 
			this.CmnTrvRefund.Name = "CmnTrvRefund";
			this.CmnTrvRefund.Size = new System.Drawing.Size(179, 24);
			this.CmnTrvRefund.Text = "Возврат билета";
			this.CmnTrvRefund.Click += new System.EventHandler(this.RefundTicketTrv_Click);
			// 
			// поездToolStripMenuItem
			// 
			this.поездToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.добавитьВагонToolStripMenuItem,
            this.удалитьВагонToolStripMenuItem,
            this.toolStripSeparator4,
            this.удалитьВсеВагоныToolStripMenuItem});
			this.поездToolStripMenuItem.Name = "поездToolStripMenuItem";
			this.поездToolStripMenuItem.Size = new System.Drawing.Size(52, 20);
			this.поездToolStripMenuItem.Text = "Поезд";
			// 
			// билетыToolStripMenuItem
			// 
			this.билетыToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.купитьБилетToolStripMenuItem,
            this.возвратБилетаToolStripMenuItem});
			this.билетыToolStripMenuItem.Name = "билетыToolStripMenuItem";
			this.билетыToolStripMenuItem.Size = new System.Drawing.Size(60, 20);
			this.билетыToolStripMenuItem.Text = "Билеты";
			// 
			// справкаToolStripMenuItem
			// 
			this.справкаToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.оПрограммеToolStripMenuItem});
			this.справкаToolStripMenuItem.Name = "справкаToolStripMenuItem";
			this.справкаToolStripMenuItem.Size = new System.Drawing.Size(65, 20);
			this.справкаToolStripMenuItem.Text = "Справка";
			// 
			// TsbRemove
			// 
			this.TsbRemove.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.TsbRemove.Image = ((System.Drawing.Image)(resources.GetObject("TsbRemove.Image")));
			this.TsbRemove.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.TsbRemove.Name = "TsbRemove";
			this.TsbRemove.Size = new System.Drawing.Size(34, 34);
			this.TsbRemove.Text = "Удалить вагон";
			// 
			// TsbBuy
			// 
			this.TsbBuy.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.TsbBuy.Image = ((System.Drawing.Image)(resources.GetObject("TsbBuy.Image")));
			this.TsbBuy.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.TsbBuy.Name = "TsbBuy";
			this.TsbBuy.Size = new System.Drawing.Size(34, 34);
			this.TsbBuy.Text = "Купить билет";
			// 
			// TsbRefund
			// 
			this.TsbRefund.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.TsbRefund.Image = ((System.Drawing.Image)(resources.GetObject("TsbRefund.Image")));
			this.TsbRefund.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.TsbRefund.Name = "TsbRefund";
			this.TsbRefund.Size = new System.Drawing.Size(34, 34);
			this.TsbRefund.Text = "Вернуть билет";
			// 
			// оПрограммеToolStripMenuItem
			// 
			this.оПрограммеToolStripMenuItem.Name = "оПрограммеToolStripMenuItem";
			this.оПрограммеToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
			this.оПрограммеToolStripMenuItem.Text = "О программе";
			// 
			// toolStripSeparator1
			// 
			this.toolStripSeparator1.Name = "toolStripSeparator1";
			this.toolStripSeparator1.Size = new System.Drawing.Size(6, 37);
			// 
			// TsbNew
			// 
			this.TsbNew.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.TsbNew.Image = ((System.Drawing.Image)(resources.GetObject("TsbNew.Image")));
			this.TsbNew.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.TsbNew.Name = "TsbNew";
			this.TsbNew.Size = new System.Drawing.Size(34, 34);
			this.TsbNew.Text = "Создать";
			// 
			// TsbOpen
			// 
			this.TsbOpen.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.TsbOpen.Image = ((System.Drawing.Image)(resources.GetObject("TsbOpen.Image")));
			this.TsbOpen.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.TsbOpen.Name = "TsbOpen";
			this.TsbOpen.Size = new System.Drawing.Size(34, 34);
			this.TsbOpen.Text = "Открыть";
			// 
			// TsbSave
			// 
			this.TsbSave.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.TsbSave.Image = ((System.Drawing.Image)(resources.GetObject("TsbSave.Image")));
			this.TsbSave.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.TsbSave.Name = "TsbSave";
			this.TsbSave.Size = new System.Drawing.Size(34, 34);
			this.TsbSave.Text = "Сохранить";
			// 
			// TsbSaveAs
			// 
			this.TsbSaveAs.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.TsbSaveAs.Image = ((System.Drawing.Image)(resources.GetObject("TsbSaveAs.Image")));
			this.TsbSaveAs.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.TsbSaveAs.Name = "TsbSaveAs";
			this.TsbSaveAs.Size = new System.Drawing.Size(34, 34);
			this.TsbSaveAs.Text = "Сохранить как...";
			// 
			// TsbRemoveAll
			// 
			this.TsbRemoveAll.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.TsbRemoveAll.Image = ((System.Drawing.Image)(resources.GetObject("TsbRemoveAll.Image")));
			this.TsbRemoveAll.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.TsbRemoveAll.Name = "TsbRemoveAll";
			this.TsbRemoveAll.Size = new System.Drawing.Size(34, 34);
			this.TsbRemoveAll.Text = "Удалить все вагоны";
			// 
			// toolStripSeparator2
			// 
			this.toolStripSeparator2.Name = "toolStripSeparator2";
			this.toolStripSeparator2.Size = new System.Drawing.Size(6, 37);
			// 
			// создатьToolStripMenuItem
			// 
			this.создатьToolStripMenuItem.Name = "создатьToolStripMenuItem";
			this.создатьToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
			this.создатьToolStripMenuItem.Text = "Создать";
			// 
			// открытьToolStripMenuItem
			// 
			this.открытьToolStripMenuItem.Name = "открытьToolStripMenuItem";
			this.открытьToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
			this.открытьToolStripMenuItem.Text = "Открыть...";
			// 
			// сохранитьToolStripMenuItem
			// 
			this.сохранитьToolStripMenuItem.Name = "сохранитьToolStripMenuItem";
			this.сохранитьToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
			this.сохранитьToolStripMenuItem.Text = "Сохранить";
			// 
			// сохранитьКакToolStripMenuItem
			// 
			this.сохранитьКакToolStripMenuItem.Name = "сохранитьКакToolStripMenuItem";
			this.сохранитьКакToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
			this.сохранитьКакToolStripMenuItem.Text = "Сохранить как...";
			// 
			// toolStripSeparator3
			// 
			this.toolStripSeparator3.Name = "toolStripSeparator3";
			this.toolStripSeparator3.Size = new System.Drawing.Size(177, 6);
			// 
			// добавитьВагонToolStripMenuItem
			// 
			this.добавитьВагонToolStripMenuItem.Name = "добавитьВагонToolStripMenuItem";
			this.добавитьВагонToolStripMenuItem.Size = new System.Drawing.Size(182, 22);
			this.добавитьВагонToolStripMenuItem.Text = "Добавить вагон";
			// 
			// удалитьВагонToolStripMenuItem
			// 
			this.удалитьВагонToolStripMenuItem.Name = "удалитьВагонToolStripMenuItem";
			this.удалитьВагонToolStripMenuItem.Size = new System.Drawing.Size(182, 22);
			this.удалитьВагонToolStripMenuItem.Text = "Удалить вагон";
			// 
			// toolStripSeparator4
			// 
			this.toolStripSeparator4.Name = "toolStripSeparator4";
			this.toolStripSeparator4.Size = new System.Drawing.Size(179, 6);
			// 
			// удалитьВсеВагоныToolStripMenuItem
			// 
			this.удалитьВсеВагоныToolStripMenuItem.Name = "удалитьВсеВагоныToolStripMenuItem";
			this.удалитьВсеВагоныToolStripMenuItem.Size = new System.Drawing.Size(182, 22);
			this.удалитьВсеВагоныToolStripMenuItem.Text = "Удалить все вагоны";
			// 
			// купитьБилетToolStripMenuItem
			// 
			this.купитьБилетToolStripMenuItem.Name = "купитьБилетToolStripMenuItem";
			this.купитьБилетToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
			this.купитьБилетToolStripMenuItem.Text = "Покупка билета";
			// 
			// возвратБилетаToolStripMenuItem
			// 
			this.возвратБилетаToolStripMenuItem.Name = "возвратБилетаToolStripMenuItem";
			this.возвратБилетаToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
			this.возвратБилетаToolStripMenuItem.Text = "Возврат билета";
			// 
			// MainForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(954, 422);
			this.Controls.Add(this.SpcMain);
			this.Controls.Add(this.StlMain);
			this.Controls.Add(this.TsbMain);
			this.Controls.Add(this.MniMain);
			this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.MainMenuStrip = this.MniMain;
			this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
			this.MaximizeBox = false;
			this.Name = "MainForm";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "RailWay";
			this.Load += new System.EventHandler(this.MainForm_Load);
			this.TsbMain.ResumeLayout(false);
			this.TsbMain.PerformLayout();
			this.SpcMain.Panel1.ResumeLayout(false);
			this.SpcMain.Panel2.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.SpcMain)).EndInit();
			this.SpcMain.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.DgvMain)).EndInit();
			this.MniMain.ResumeLayout(false);
			this.MniMain.PerformLayout();
			this.CmnTrvTrain.ResumeLayout(false);
			this.CmnTrvCar.ResumeLayout(false);
			this.CmnTrvPlace.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.BnsTrain)).EndInit();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.ToolStrip TsbMain;
		private System.Windows.Forms.StatusStrip StlMain;
		private System.Windows.Forms.SplitContainer SpcMain;
		private System.Windows.Forms.TreeView TrvMain;
		private System.Windows.Forms.DataGridView DgvMain;
		private System.Windows.Forms.ToolStripButton TsbAdd;
		private System.Windows.Forms.MenuStrip MniMain;
		private System.Windows.Forms.ToolStripMenuItem MniFile;
		private System.Windows.Forms.BindingSource BnsTrain;
		private System.Windows.Forms.ImageList ImlTree;
		private System.Windows.Forms.DataGridViewTextBoxColumn ClnNum;
		private System.Windows.Forms.DataGridViewTextBoxColumn ClnType;
		private System.Windows.Forms.DataGridViewTextBoxColumn ClnCmpNumber;
		private System.Windows.Forms.DataGridViewTextBoxColumn ClnPlaceNum;
		private System.Windows.Forms.DataGridViewTextBoxColumn ClnState;
		private System.Windows.Forms.ContextMenuStrip CmnTrvTrain;
		private System.Windows.Forms.ToolStripMenuItem CmnTrvAdd;
		private System.Windows.Forms.ContextMenuStrip CmnTrvCar;
		private System.Windows.Forms.ToolStripMenuItem CmnTrvRemove;
		private System.Windows.Forms.ContextMenuStrip CmnTrvPlace;
		private System.Windows.Forms.ToolStripMenuItem CmnTrvBuy;
		private System.Windows.Forms.ToolStripMenuItem CmnTrvRefund;
		private System.Windows.Forms.ToolStripMenuItem CmnTrvAddSv;
		private System.Windows.Forms.ToolStripMenuItem CmnTrvAddCoupe;
		private System.Windows.Forms.ToolStripMenuItem CmnTrvAddEconomy;
		private System.Windows.Forms.ToolStripMenuItem MniFileExit;
		private System.Windows.Forms.ToolStripButton TsbRemove;
		private System.Windows.Forms.ToolStripButton TsbBuy;
		private System.Windows.Forms.ToolStripButton TsbRefund;
		private System.Windows.Forms.ToolStripMenuItem поездToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem билетыToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem справкаToolStripMenuItem;
		private System.Windows.Forms.ToolStripButton TsbNew;
		private System.Windows.Forms.ToolStripButton TsbOpen;
		private System.Windows.Forms.ToolStripButton TsbSave;
		private System.Windows.Forms.ToolStripButton TsbSaveAs;
		private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
		private System.Windows.Forms.ToolStripButton TsbRemoveAll;
		private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
		private System.Windows.Forms.ToolStripMenuItem создатьToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem открытьToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem сохранитьToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem сохранитьКакToolStripMenuItem;
		private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
		private System.Windows.Forms.ToolStripMenuItem добавитьВагонToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem удалитьВагонToolStripMenuItem;
		private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
		private System.Windows.Forms.ToolStripMenuItem удалитьВсеВагоныToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem купитьБилетToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem возвратБилетаToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem оПрограммеToolStripMenuItem;
	}
}

