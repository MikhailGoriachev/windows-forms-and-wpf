﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Railway.Helpers;

namespace Railway.Models
{
	// Класс, описывающий купе вагона
	public class Compartment
	{
		// Тип купе
		private string _type;

		public string Type
		{
			get => _type;
			set { 
				_type = value; 
			}
		}

		// Номер купе
		private int _number;

		public int Number
		{
			get => _number;
			set
			{
				_number = value;
			}
		}


		// Количество мест
		private int _capacity;

		public int Capacity
		{
			get => _capacity; 
			private set { _capacity = value; }
		}


		// Места
		private List<Place> _places;

		public List<Place> Places
		{
			get => _places; 
			set { 
				_places = value;
			}
		}


		// Конструкторы

		public Compartment():this("СВ", 1, 2, new List<Place>())
		{
		}

		public Compartment(string type, int number, int capacity, List<Place> places)
		{
			Type = type;
			Number = number;
			Capacity = capacity;
			Places = places;
		}

		// индексатор
		public Place this[int index]
		{
			get => _places[index];
			set => _places[index] = value;
		}

		// генерация купе по типу
		public static Compartment Generate(string type, int number)
		{
			var compartment = (type) switch
			{
				"св" => new Compartment(type, number, 2, new List<Place>()),
				"купе" => new Compartment(type, number, 4, new List<Place>()),
				"плацкарт" => new Compartment(type, number, 6, new List<Place>()),
				_ => throw new ArgumentOutOfRangeException(nameof(type), type, "Тип купе не определён")
			};

			for (int i = 0; i < compartment.Capacity; i++)
				compartment.Places.Add(new Place(i + 1, Utils.GetRandomBool()));

			return compartment;
		}

	}
}
