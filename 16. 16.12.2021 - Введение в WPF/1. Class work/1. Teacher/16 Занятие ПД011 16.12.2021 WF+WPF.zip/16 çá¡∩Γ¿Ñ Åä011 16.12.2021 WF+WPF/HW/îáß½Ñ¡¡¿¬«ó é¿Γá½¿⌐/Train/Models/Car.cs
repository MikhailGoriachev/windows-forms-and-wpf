﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Railway.Helpers;

namespace Railway.Models
{
	// класс, описывающий вагон
	public class Car
	{
		// тип вагона
		private string _type;
		public string Type
		{
			get => _type; 
			set { 
				_type = value; 
			}
		}

		// номер вагона
		private int _number;

		public int Number
		{
			get => _number; 
			set { 
				_number = value; 
			}
		}

		// количество купе в вагоне
		private readonly int _compartmentsCount;

		public int CompartmentsCount => _compartmentsCount;

		// коллекция купе вагона
		private List<Compartment> _compartments;
		
		public List<Compartment> Compartments
		{
			get => _compartments; 
			set {
				_compartments = value; 
			}
		}

		// конструкторы
		public Car() { }


		public Car(string type, int number, List<Compartment> compartments)
		{
			Type = type;
			Number = number;
			Compartments = compartments;

			_compartmentsCount = 9;
		}

		// индексатор
		public Compartment this[int index]
		{
			get => _compartments[index];
			set => _compartments[index] = value;
		}


		// генерация вагона
		public static Car Generate(string type, int number)
		{
			Car car = new Car(type, number, new List<Compartment>());

			for (int i = 0; i < car.CompartmentsCount; i++)
				car.Compartments.Add(Compartment.Generate(type, i + 1));

			return car;
		}

	}
}
