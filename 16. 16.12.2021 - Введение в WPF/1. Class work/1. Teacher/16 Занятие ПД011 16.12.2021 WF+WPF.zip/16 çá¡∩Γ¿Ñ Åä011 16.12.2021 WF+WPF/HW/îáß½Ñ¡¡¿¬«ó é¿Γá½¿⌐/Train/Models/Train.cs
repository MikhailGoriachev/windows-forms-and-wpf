﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Railway.Helpers;

namespace Railway.Models
{
	// класс, описывающий поезд
	public class Train
	{
		// номер поезда
		private string _number;

		public string Number
		{
			get => _number; 
			set { 
				_number = value; 
			}
		}

		// пункт отправления
		private string _departure;

		public string Departure
		{
			get => _departure;
			set
			{
				_departure = value;
			}
		}

		// пункт назначения
		private string _destination;

		public string Destination
		{
			get => _destination;
			set
			{
				_destination = value;
			}
		}

		private string[] _text;

		public string[] Text { get; set; }

		// коллекция вагонов поезда
		private List<Car> _cars;

		public List<Car> Cars
		{
			get => _cars; 
			set {
				_cars = value; 
			}
		}

		// конструкторы
		public Train()
		{}
		
		public Train(string number, string departure, string destination, List<Car> cars)
		{
			Number = number;
			Departure = departure;
			Destination = destination;
			Cars = cars;
			_text = new[] {"sfa", "dsff", "fsdfsd", "fsfef"};
		}


		// индексатор
		public Car this[int index]
		{
			get => _cars[index];
			set => _cars[index] = value;
		}


		// добавление вагона
		public void AddCar(string type) =>
			_cars.Add(Car.Generate(type, _cars.Count + 1));

		// удаление вагона
		public void RemoveCar(Car car) => _cars.RemoveAt(_cars.FindIndex(c => c == car));

		// генерация поезда
		public static Train Generate(string number, string departure, string destination)
		{
			
			Train train = new Train(number, departure, destination, new List<Car>());

			int nCars = Utils.GetRandom(5, 20);

			for (int i = 0; i < nCars; i++)
			{
				var type = Utils.GetRandom(1, 3) switch
				{
					1 => "св",
					2 => "купе",
					3 => "плацкарт"
				};

				train.Cars.Add(Car.Generate(type, i + 1));
			}

			return train;
		}
	}
}
