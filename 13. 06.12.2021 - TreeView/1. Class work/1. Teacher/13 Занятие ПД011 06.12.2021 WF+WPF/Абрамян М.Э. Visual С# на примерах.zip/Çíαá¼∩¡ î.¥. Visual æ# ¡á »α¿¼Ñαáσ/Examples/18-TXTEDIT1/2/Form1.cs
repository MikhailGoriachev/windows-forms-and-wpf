/***************************/
/*                         */
/*  �.�.�������            */
/*  C# �� ��������         */
/*                         */
/*  ������ TXTEDIT1        */
/*  ����� 18, ������ 18.2  */
/*                         */
/***************************/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace TXTEDIT1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent(); 
            saveFileDialog1.InitialDirectory = Directory.GetCurrentDirectory();
        }

        private void exit1_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void SaveToFile(string path)
        {
            StreamWriter sw = new StreamWriter(path, false, Encoding.Default);
            sw.WriteLine(textBox1.Text);
            sw.Close();
        }

        private void saveAs1_Click(object sender, EventArgs e)
        {
            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                string path = saveFileDialog1.FileName;
                SaveToFile(path);
                Text = "Text Editor - " + Path.GetFileName(path);
            }
        }

        private void save1_Click(object sender, EventArgs e)
        {
            string path = saveFileDialog1.FileName;
            if (path == "")
                saveAs1_Click(saveAs1, null);
            else
                SaveToFile(path);
        }
    }
}
