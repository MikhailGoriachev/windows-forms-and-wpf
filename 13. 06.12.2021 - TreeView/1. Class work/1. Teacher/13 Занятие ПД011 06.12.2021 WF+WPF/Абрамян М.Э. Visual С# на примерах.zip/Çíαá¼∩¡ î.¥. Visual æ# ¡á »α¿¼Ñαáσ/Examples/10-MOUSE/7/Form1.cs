/***************************/
/*                         */
/*  �.�.�������            */
/*  C# �� ��������         */
/*                         */
/*  ������ MOUSE           */
/*  ����� 10, ������ 10.7  */
/*                         */
/***************************/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace MOUSE
{
    public partial class Form1 : Form
    {
        private Point p;
        private Size s;

        public Form1()
        {
            InitializeComponent();
        }

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            p = e.Location;
            Control a = sender as Control;
            a.BringToFront();
            s = a.Size;
            if (Control.MouseButtons != MouseButtons.Left
              && Control.MouseButtons != MouseButtons.Right)
                a.Cursor = null;
            else
                if (e.Button == MouseButtons.Left)
                    a.Cursor = Cursors.Hand;
                else
                    if (e.Button == MouseButtons.Right)
                        a.Cursor = Cursors.SizeNWSE;
        }

        private void panel1_MouseMove(object sender, MouseEventArgs e)
        {
            Control a = sender as Control;
            Text = string.Format("Mouse - {0} {1}", a.Name, e.Location);
            Size s0 = new Size(e.X - p.X, e.Y - p.Y);
            if (e.Button == MouseButtons.Left)
            {
                Point p0 = a.Location + s0;
                a.Location = new Point(Math.Max(0, p0.X), Math.Max(0, p0.Y));
            }
            else
                if (e.Button == MouseButtons.Right)
                {
                    s0 += s;
                    a.Size = new Size(Math.Max(50, s0.Width), Math.Max(20, s0.Height));
                }
        }

        private void Form1_MouseMove(object sender, MouseEventArgs e)
        {
            Text = "Mouse";
        }

        private void panel1_MouseUp(object sender, MouseEventArgs e)
        {
            Control a = sender as Control;
            if (Control.MouseButtons != MouseButtons.None
                && !a.ClientRectangle.Contains(e.Location))
            {
                a.Cursor = null;
                Capture = true;
                return;
            }
            if (Control.MouseButtons == MouseButtons.Left)
                panel1_MouseDown(sender, new MouseEventArgs(MouseButtons.Left,
                    0, e.X, e.Y, 0));
            else
                if (Control.MouseButtons == MouseButtons.Right)
                    panel1_MouseDown(sender, new MouseEventArgs(MouseButtons.Right,
                        0, e.X, e.Y, 0));
                else
                    a.Cursor = null;
        }
    }
}
