/***************************/
/*                         */
/*  �.�.�������            */
/*  C# �� ��������         */
/*                         */
/*  ������ MOUSE           */
/*  ����� 10, ������ 10.1  */
/*                         */
/***************************/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace MOUSE
{
    public partial class Form1 : Form
    {
        private Point p;

        public Form1()
        {
            InitializeComponent();
        }

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            p = e.Location;
            Panel a = sender as Panel;
            a.BringToFront();
        }

        private void panel1_MouseMove(object sender, MouseEventArgs e)
        {
            Panel a = sender as Panel;
            Text = string.Format("Mouse - {0} {1}", a.Name, e.Location);
            Size s0 = new Size(e.X - p.X, e.Y - p.Y);
            if (e.Button == MouseButtons.Left)
                a.Location += s0;
        }

        private void Form1_MouseMove(object sender, MouseEventArgs e)
        {
            Text = "Mouse";
        }
    }
}
