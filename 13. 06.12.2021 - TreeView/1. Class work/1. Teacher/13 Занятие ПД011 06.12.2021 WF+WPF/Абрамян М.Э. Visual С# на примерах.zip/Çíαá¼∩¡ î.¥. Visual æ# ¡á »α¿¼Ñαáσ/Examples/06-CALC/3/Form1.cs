/***************************/
/*                         */
/*  �.�.�������            */
/*  C# �� ��������         */
/*                         */
/*  ������ CALC            */
/*  ����� 6, ������ 6.3    */
/*                         */
/***************************/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace CALC
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            label1.Text = (sender as Button).Text[1].ToString();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            double x = 0, x1, x2;
            if (!double.TryParse(textBox1.Text, out x1) ||
                !double.TryParse(textBox2.Text, out x2))
            {
                label2.Text = "= ERROR";
                return;
            }
            switch (label1.Text[0])
            {
                case '+':
                    x = x1 + x2; break;
                case '-':
                    x = x1 - x2; break;
                case 'x':
                    x = x1 * x2; break;
                case '/':
                    x = x1 / x2; break;
            }
            label2.Text = "= " + x;
        }
    }
}
