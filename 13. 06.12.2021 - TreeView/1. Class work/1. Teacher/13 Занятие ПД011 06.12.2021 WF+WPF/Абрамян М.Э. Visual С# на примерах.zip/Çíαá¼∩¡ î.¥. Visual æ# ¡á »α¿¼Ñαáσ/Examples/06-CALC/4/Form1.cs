/***************************/
/*                         */
/*  �.�.�������            */
/*  C# �� ��������         */
/*                         */
/*  ������ CALC            */
/*  ����� 6, ������ 6.4    */
/*                         */
/***************************/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace CALC
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            label1.Text = (sender as Button).Text[1].ToString();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            double x = 0, x1, x2;
            if (!double.TryParse(textBox1.Text, out x1) ||
                !double.TryParse(textBox2.Text, out x2))
            {
                label2.Text = "= ERROR";
                return;
            }
            switch (label1.Text[0])
            {
                case '+':
                    x = x1 + x2; break;
                case '-':
                    x = x1 - x2; break;
                case 'x':
                    x = x1 * x2; break;
                case '/':
                    x = x1 / x2; break;
            }
            label2.Text = "= " + x;
        }

        private void Form1_KeyPress(object sender, KeyPressEventArgs e)
        {
            char c = e.KeyChar;
            switch (c)
            {
                case '+':
                    button1_Click(button1, null); break;
                case '_':
                    button1_Click(button2, null); break;
                case 'x':
                case '*':
                    button1_Click(button3, null); break;
                case '/':
                    button1_Click(button4, null); break;
                case '=':
                    button5_Click(button5, null); break;
            }
            e.Handled = !(char.IsDigit(c) || 
                c == Application.CurrentCulture.NumberFormat.NumberDecimalSeparator[0] || 
                c == '-' || c == '\b');
        }
    }
}
