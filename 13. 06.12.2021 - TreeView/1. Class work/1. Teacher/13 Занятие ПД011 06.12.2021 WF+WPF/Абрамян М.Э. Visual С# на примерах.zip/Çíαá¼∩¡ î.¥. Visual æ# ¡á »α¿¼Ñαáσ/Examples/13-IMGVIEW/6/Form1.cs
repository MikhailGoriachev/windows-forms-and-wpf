/***************************/
/*                         */
/*  �.�.�������            */
/*  C# �� ��������         */
/*                         */
/*  ������ IMGVIEW         */
/*  ����� 13, ������ 13.6  */
/*                         */
/***************************/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Microsoft.Win32;

namespace IMGVIEW
{
    public partial class Form1 : Form
    {
        private string regKeyName = "Software\\CSExamples\\IMGVIEW";
        
        public Form1()
        {
            InitializeComponent();
            dirListBox1_Change(this, null);
        }

        private void dirListBox1_Change(object sender, EventArgs e)
        {
            fileListBox1.Path = dirListBox1.Path;
            if (fileListBox1.Items.Count > 0)
                fileListBox1.SelectedIndex = 0;
            else
                pictureBox1.Image = null;
        }

        private void fileListBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                pictureBox1.Image = new Bitmap(fileListBox1.Path +
                    "\\" + fileListBox1.FileName);
            }
            catch
            {
                pictureBox1.Image = null;
            }
        }

        private void dirListBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\r')
                dirListBox1.Path = 
                    dirListBox1.get_DirList(dirListBox1.DirListIndex);
        }

        private void driveListBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            while (!new System.IO.DriveInfo(driveListBox1.Drive).IsReady)
                if (MessageBox.Show("Drive " + driveListBox1.Drive +
                    " is not ready.", "Warning", MessageBoxButtons.RetryCancel,
                    MessageBoxIcon.Warning) != DialogResult.Retry)
                {
                    driveListBox1.SelectedIndexChanged -=
                        driveListBox1_SelectedIndexChanged;
                    driveListBox1.Drive = dirListBox1.Path[0] + ":";
                    driveListBox1.SelectedIndexChanged +=
                        driveListBox1_SelectedIndexChanged;
                    return;
                }
            dirListBox1.Path = driveListBox1.Drive[0] + ":\\";
        }

        private void checkBox1_CheckStateChanged(object sender, EventArgs e)
        {
            switch (checkBox1.CheckState)
            {
                case CheckState.Checked:
                    pictureBox1.SizeMode = PictureBoxSizeMode.Zoom; break;
                case CheckState.Indeterminate:
                    pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage; break;
                case CheckState.Unchecked:
                    pictureBox1.SizeMode = PictureBoxSizeMode.CenterImage; break;
            }
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            RegistryKey rk = null;
            try
            {
                rk = Registry.CurrentUser.CreateSubKey(regKeyName);
                if (rk == null)
                    return;
                rk.SetValue("FormWidth", Width);
                rk.SetValue("FormHeight", Height);
                rk.SetValue("Split1", splitContainer1.SplitterDistance);
                rk.SetValue("Split2", splitContainer2.SplitterDistance);
                rk.SetValue("Zoom", (int)checkBox1.CheckState);
                rk.SetValue("Path", dirListBox1.Path);
                rk.SetValue("File", fileListBox1.FileName);
            }
            finally
            {
                if (rk != null)
                    rk.Close();
            }
        }
    }
}
