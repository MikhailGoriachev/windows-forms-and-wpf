/***************************/
/*                         */
/*  �.�.�������            */
/*  C# �� ��������         */
/*                         */
/*  ������ IMGVIEW         */
/*  ����� 13, ������ 13.3  */
/*                         */
/***************************/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace IMGVIEW
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            dirListBox1_Change(this, null);
        }

        private void dirListBox1_Change(object sender, EventArgs e)
        {
            fileListBox1.Path = dirListBox1.Path;
            if (fileListBox1.Items.Count > 0)
                fileListBox1.SelectedIndex = 0;
            else
                pictureBox1.Image = null;
        }

        private void fileListBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                pictureBox1.Image = new Bitmap(fileListBox1.Path +
                    "\\" + fileListBox1.FileName);
            }
            catch
            {
                pictureBox1.Image = null;
            }
        }

        private void dirListBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\r')
                dirListBox1.Path = 
                    dirListBox1.get_DirList(dirListBox1.DirListIndex);
        }
    }
}
