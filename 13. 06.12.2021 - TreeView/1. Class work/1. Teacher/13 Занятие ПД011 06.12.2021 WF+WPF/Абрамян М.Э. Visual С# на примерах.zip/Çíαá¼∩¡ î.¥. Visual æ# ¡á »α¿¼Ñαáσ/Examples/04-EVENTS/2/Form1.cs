/***************************/
/*                         */
/*  �.�.�������            */
/*  C# �� ��������         */
/*                         */
/*  ������ EVENTS          */
/*  ����� 4, ������ 4.2    */
/*                         */
/***************************/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace EVENTS
{
    public partial class Form1 : Form
    {
        private Random r = new Random(); 
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void Form1_MouseDown(object sender, MouseEventArgs e)
        {
            button1.Location = new Point(e.X - button1.Width / 2,
                e.Y - button1.Height / 2);
        }

        private void button2_MouseMove(object sender, MouseEventArgs e)
        {
            if (Control.ModifierKeys == Keys.Control)
                return;
            button2.Location = new Point(r.Next(ClientRectangle.Width - 5),
                r.Next(ClientRectangle.Height - 5));
        }

        private void button2_Click(object sender, EventArgs e)
        {
            button2.Text = "��������";
            button2.MouseMove -= button2_MouseMove;
        }

    }
}
