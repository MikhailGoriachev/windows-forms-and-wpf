/***************************/
/*                         */
/*  �.�.�������            */
/*  C# �� ��������         */
/*                         */
/*  ������ EXCEP           */
/*  ����� 3, ������ 3.2    */
/*                         */
/***************************/

using System;
using System.Collections.Generic;
using System.Text;

namespace EXCEP
{
    class Program
    {
        static void M1(int x, int y, int z)
        {
            try
            {
                int a = checked((int)Math.Pow(x, y));
                Console.WriteLine("x ^ y / z = {0}", a / z);
            }
            catch (DivideByZeroException)
            {
                Console.WriteLine("DivideByZero Exception");
            }
            Console.WriteLine("M1 finished");
        }
        static void M2(int x, int y, int z)
        {
            try
            {
                M1(x, y, z);
            }
            catch (ArithmeticException)
            {
                Console.WriteLine("Arithmetic Exception");
            }
            Console.WriteLine("M2 finished");
        }

        static void Main(string[] args)
        {
            try
            {

                Console.Write("x = ");
                int x = int.Parse(Console.ReadLine());
                Console.Write("y = ");
                int y = int.Parse(Console.ReadLine());
                Console.Write("z = ");
                int z = int.Parse(Console.ReadLine());
                M2(x, y, z);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.GetType().Name + ":\n  " + ex.Message);
            }
            Console.ReadLine();
        }
    }
}
