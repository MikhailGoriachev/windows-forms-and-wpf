/***************************/
/*                         */
/*  �.�.�������            */
/*  C# �� ��������         */
/*                         */
/*  ������ CURSORS         */
/*  ����� 7, ������ 7.4    */
/*                         */
/***************************/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace CURSORS
{
    public partial class Form1 : Form
    {
        private List<string> str = new List<string>(30);
        private List<Cursor> cur = new List<Cursor>(30);
        Icon[] ico = new Icon[3];

        public Form1()
        {
            InitializeComponent();
            foreach (System.Reflection.PropertyInfo pi in
              typeof(Cursors).GetProperties())
            {
                str.Add(pi.Name);
                cur.Add((Cursor)pi.GetValue(null, null));
            }
            button1.Tag = str.IndexOf("Default");
            for (int i = 1; i <= 2; i++)
            {
                str.Add("C" + i);
                cur.Add(new Cursor(GetType(), "C" + i + ".cur"));
            }
            button5.Tag = 0;
            ico[1] = new Icon(GetType(), "Computer.ico");
            ico[2] = new Icon(GetType(), "Folder.ico");
            ico[0] = Icon;
        }

        private void button1_MouseDown(object sender, MouseEventArgs e)
        {
            int k = (int)button1.Tag,
                c = str.Count;
            switch (e.Button)
            {
                case MouseButtons.Left:
                    k = (k + 1) % c; break;
                case MouseButtons.Right:
                    k = (k - 1 + c) % c; break;
            }
            button1.Text = str[k];
            button1.Cursor = cur[k];
            button1.Tag = k;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Cursor = button1.Cursor;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            UseWaitCursor = true;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            UseWaitCursor = false;
            Cursor = Cursors.Default;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            int k = ((int)button5.Tag + 1) % 3;
            button5.Text = "Icon " + k;
            button5.Tag = k;
            Icon = ico[k];
        }
    }
}
