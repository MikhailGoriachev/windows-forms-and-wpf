/***************************/
/*                         */
/*  �.�.�������            */
/*  C# �� ��������         */
/*                         */
/*  ������ ZOO             */
/*  ����� 11, ������ 11.8  */
/*                         */
/***************************/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace ZOO
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                Label src = sender as Label;
                src.ForeColor = Color.Blue;
                if (DoDragDrop(sender, DragDropEffects.Move) == DragDropEffects.None)
                    src.Visible = false;
                src.ForeColor = SystemColors.ControlText;
            }
            string s = "";
            for (int i = 1; i <= 4; i++)
            {
                if (Controls["label" + i].Visible)
                    return;
                s = s + (Controls["textBox" + i].Text);
            }
            if (s == "")
                return;
            button1.Text = "������� ������";
            button1.ForeColor = Color.Green;
            button1.ImageKey = "OK.bmp";
        }

        private void Form1_DragEnter(object sender, DragEventArgs e)
        {
            e.Effect = DragDropEffects.Move;
        }

        private void Form1_DragDrop(object sender, DragEventArgs e)
        {
            Label src = e.Data.GetData(typeof(Label)) as Label;
            src.Location = PointToClient(new Point(e.X, e.Y));
        }

        private void label1_DragEnter(object sender, DragEventArgs e)
        {
            e.Effect = DragDropEffects.Move;
            (sender as Control).BackColor = Color.Yellow;
        }

        private void textBox1_DragDrop(object sender, DragEventArgs e)
        {
            Label src = e.Data.GetData(typeof(Label)) as Label;
            TextBox trg = sender as TextBox;
            if ((int)src.Tag >= (int)trg.Tag)
            {
                trg.Text = src.Text;
                trg.Tag = src.Tag;
            }
            src.Visible = false;
            trg.BackColor = SystemColors.Control;
        }

        private void label1_DragDrop(object sender, DragEventArgs e)
        {
            Label src = e.Data.GetData(typeof(Label)) as Label;
            Label trg = sender as Label;
            trg.BackColor = SystemColors.Control;
            if (src == trg) return;
            if ((int)src.Tag > (int)trg.Tag)
            {
                src.Location = trg.Location;
                trg.Visible = false;
            }
            else
                src.Visible = false;
        }

        private void label1_DragLeave(object sender, EventArgs e)
        {
            (sender as Control).BackColor = SystemColors.Control;
        }

        private void Form1_GiveFeedback(object sender, GiveFeedbackEventArgs e)
        {
            e.UseDefaultCursors = false;
            Cursor.Current = e.Effect == DragDropEffects.Move ?
              Cursors.Hand : Cursors.No;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            for (int i = 1; i <= 4; i++)
                Controls["label" + i].Location =
                  Controls["textBox" + i].Location - new Size(0, textBox1.Top / 2);
            ActiveControl = button1;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form1_Load(this, null);
            for (int i = 1; i <= 4; i++)
            {
                Controls["label" + i].Visible = true;
                Control c = Controls["textBox" + i];
                c.Text = "";
                c.Tag = 0;
            }
            button1.Text = "������� ������";
            button1.ForeColor = Color.Red;
            button1.ImageKey = "Critical.bmp";
        }
    }
}
