/***************************/
/*                         */
/*  �.�.�������            */
/*  C# �� ��������         */
/*                         */
/*  ������ ZOO             */
/*  ����� 11, ������ 11.2  */
/*                         */
/***************************/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace ZOO
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
                DoDragDrop(sender, DragDropEffects.Move);
        }

        private void Form1_DragEnter(object sender, DragEventArgs e)
        {
            e.Effect = DragDropEffects.Move;
        }

        private void Form1_DragDrop(object sender, DragEventArgs e)
        {
            Label src = e.Data.GetData(typeof(Label)) as Label;
            src.Location = PointToClient(new Point(e.X, e.Y));
        }

        private void label1_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetData(typeof(Label)) == sender)
                e.Effect = DragDropEffects.Move;
            else
                e.Effect = DragDropEffects.None;
        }

        private void textBox1_DragEnter(object sender, DragEventArgs e)
        {
            if ((sender as TextBox).Text == "")
                e.Effect = DragDropEffects.Move;
            else
                e.Effect = DragDropEffects.None;
        }

        private void textBox1_DragDrop(object sender, DragEventArgs e)
        {
            Label src = e.Data.GetData(typeof(Label)) as Label;
            (sender as TextBox).Text = src.Text;
            src.Visible = false;
        }
    }
}
