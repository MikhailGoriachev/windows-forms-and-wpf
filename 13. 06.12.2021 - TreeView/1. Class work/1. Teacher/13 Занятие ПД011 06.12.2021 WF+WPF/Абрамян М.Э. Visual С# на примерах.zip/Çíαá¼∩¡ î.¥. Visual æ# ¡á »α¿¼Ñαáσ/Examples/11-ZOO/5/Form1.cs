/***************************/
/*                         */
/*  �.�.�������            */
/*  C# �� ��������         */
/*                         */
/*  ������ ZOO             */
/*  ����� 11, ������ 11.5  */
/*                         */
/***************************/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace ZOO
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                Label src = sender as Label;
                src.ForeColor = Color.Blue;
                if (DoDragDrop(sender, DragDropEffects.Move) == DragDropEffects.None)
                    src.Visible = false;
                src.ForeColor = SystemColors.ControlText;
            }
        }

        private void Form1_DragEnter(object sender, DragEventArgs e)
        {
            e.Effect = DragDropEffects.Move;
        }

        private void Form1_DragDrop(object sender, DragEventArgs e)
        {
            Label src = e.Data.GetData(typeof(Label)) as Label;
            src.Location = PointToClient(new Point(e.X, e.Y));
        }

        private void label1_DragEnter(object sender, DragEventArgs e)
        {
            e.Effect = DragDropEffects.Move;
            (sender as Control).BackColor = Color.Yellow;
        }

        private void textBox1_DragDrop(object sender, DragEventArgs e)
        {
            Label src = e.Data.GetData(typeof(Label)) as Label;
            TextBox trg = sender as TextBox;
            if ((int)src.Tag >= (int)trg.Tag)
            {
                trg.Text = src.Text;
                trg.Tag = src.Tag;
            }
            src.Visible = false;
            trg.BackColor = SystemColors.Control;
        }

        private void label1_DragDrop(object sender, DragEventArgs e)
        {
            Label src = e.Data.GetData(typeof(Label)) as Label;
            Label trg = sender as Label;
            trg.BackColor = SystemColors.Control;
            if (src == trg) return;
            if ((int)src.Tag > (int)trg.Tag)
            {
                src.Location = trg.Location;
                trg.Visible = false;
            }
            else
                src.Visible = false;
        }

        private void label1_DragLeave(object sender, EventArgs e)
        {
            (sender as Control).BackColor = SystemColors.Control;
        }
    }
}
