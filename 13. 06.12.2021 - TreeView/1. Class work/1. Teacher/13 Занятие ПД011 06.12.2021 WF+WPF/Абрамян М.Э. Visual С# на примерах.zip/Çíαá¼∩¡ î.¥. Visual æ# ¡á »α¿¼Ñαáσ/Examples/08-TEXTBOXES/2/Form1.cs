/***************************/
/*                         */
/*  �.�.�������            */
/*  C# �� ��������         */
/*                         */
/*  ������ TEXTBOXES       */
/*  ����� 8, ������ 8.2    */
/*                         */
/***************************/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace TEXTBOXES
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            for (int i = 1; i <= 12; i++)
            {
                TextBox tb = Controls["textBox" + i] as TextBox;
                tb.Select(tb.Text.Length, 0);
            }
        }

        private void textBox1_Enter(object sender, EventArgs e)
        {
            TextBox tb = sender as TextBox;
            tb.ForeColor = Color.White;
            tb.BackColor = Color.Green;
        }

        private void textBox1_Leave(object sender, EventArgs e)
        {
            TextBox tb = sender as TextBox;
            tb.ForeColor = SystemColors.WindowText;
            tb.BackColor = SystemColors.Window;
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            if (!(sender as RadioButton).Checked)
                return;
            if (sender == radioButton1)
                for (int i = 0; i <= 11; i++)
                    Controls["textBox" + (i + 1)].TabIndex = i;
            else
                for (int i = 0; i <= 3; i++)
                    for (int j = 0; j <= 2; j++)
                        Controls["textBox" + (3 * i + j + 1)].TabIndex = i + 4 * j;
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            switch (e.KeyCode)
            {
                case Keys.F2:
                    radioButton1.Checked = true; break;
                case Keys.F3:
                    radioButton2.Checked = true; break;
            }
        }
    }
}
