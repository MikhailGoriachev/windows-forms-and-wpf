/***************************/
/*                         */
/*  �.�.�������            */
/*  C# �� ��������         */
/*                         */
/*  ������ TEXTBOXES       */
/*  ����� 8, ������ 8.1    */
/*                         */
/***************************/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace TEXTBOXES
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            for (int i = 1; i <= 12; i++)
            {
                TextBox tb = Controls["textBox" + i] as TextBox;
                tb.Select(tb.Text.Length, 0);
            }
        }

        private void textBox1_Enter(object sender, EventArgs e)
        {
            TextBox tb = sender as TextBox;
            tb.ForeColor = Color.White;
            tb.BackColor = Color.Green;
        }

        private void textBox1_Leave(object sender, EventArgs e)
        {
            TextBox tb = sender as TextBox;
            tb.ForeColor = SystemColors.WindowText;
            tb.BackColor = SystemColors.Window;
        }
    }
}
