/***************************/
/*                         */
/*  �.�.�������            */
/*  C# �� ��������         */
/*                         */
/*  ������ DISKINFO        */
/*  ����� 2, ������ 2.3    */
/*                         */
/***************************/

using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace DISKINFO
{
    class Program
    {
        static void DInfo(string path)
        {
            string none = "---",
                d = path[0].ToString().ToUpper();
            if (d[0] < 'A' || d[0] > 'Z')
                return;
            DriveInfo di = new DriveInfo(d);
            StringBuilder s = new StringBuilder(40);
            s.AppendFormat(" {0,-4}", d);
            if (di.DriveType != DriveType.NoRootDirectory)
            {
                s.AppendFormat(" {0,-9}", di.DriveType);
                if (di.IsReady)
                    s.AppendFormat("{0,12:N0} {1,12:N0}", di.TotalSize / 1024,
                        di.TotalFreeSpace / 1024);
                else
                    s.AppendFormat("{0,12} {0,12}", none);
            }
            else
                s.AppendFormat(" {0,-9}{0,12} {0,12}", none);
            Console.WriteLine(s);
        }

        static void Main(string[] args)
        {
            Console.WriteLine("��������� DISKINFO\n");
            Console.WriteLine(" Disk Type         Size (K)     Free (K)");
            Console.WriteLine(new String('=', 40));
            if (args.Length == 0) 
                DInfo(Environment.CurrentDirectory);
            else
                foreach (string d in args)
                    DInfo(d);
            Console.WriteLine("\n��� ���������� ��������� ������� <Enter>...");
            Console.ReadLine();
        }
    }
}
