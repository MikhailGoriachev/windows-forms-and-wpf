/***************************/
/*                         */
/*  �.�.�������            */
/*  C# �� ��������         */
/*                         */
/*  ������ COLORS          */
/*  ����� 9, ������ 9.3    */
/*                         */
/***************************/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace COLORS
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            trackBar1_Scroll(null, null);
        }

        private void trackBar1_Scroll(object sender, EventArgs e)
        {
            label6.BackColor = Color.FromArgb(trackBar1.Value, trackBar2.Value,
                trackBar3.Value, trackBar4.Value);
            Color c = label6.BackColor;
            label6.ForeColor = Color.FromArgb(0xFF ^ c.R, 0xFF ^ c.G, 0xFF ^ c.B);
            label6.Text = c.ToArgb().ToString("X8");
        }

        private void trackBar5_Scroll(object sender, EventArgs e)
        {
            trackBar2.Value = trackBar3.Value = trackBar4.Value = trackBar5.Value;
            trackBar1_Scroll(null, null);
        }
    }
}
