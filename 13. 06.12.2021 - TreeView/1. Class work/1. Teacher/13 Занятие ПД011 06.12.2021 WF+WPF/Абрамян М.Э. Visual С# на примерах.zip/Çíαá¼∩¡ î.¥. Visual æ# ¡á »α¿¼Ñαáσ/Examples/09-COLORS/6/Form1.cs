/***************************/
/*                         */
/*  �.�.�������            */
/*  C# �� ��������         */
/*                         */
/*  ������ COLORS          */
/*  ����� 9, ������ 9.6    */
/*                         */
/***************************/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace COLORS
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            trackBar1_Scroll(null, null);
            MinimumSize = Size;
        }

        private void trackBar1_Scroll(object sender, EventArgs e)
        {
            label6.BackColor = Color.FromArgb(trackBar1.Value, trackBar2.Value,
                trackBar3.Value, trackBar4.Value);
            Color c = label6.BackColor;
            label6.ForeColor = Color.FromArgb(0xFF ^ c.R, 0xFF ^ c.G, 0xFF ^ c.B);
            string s = c.ToArgb().ToString("X8");
            switch (c.A)
            {
                case 0:
                    s += " Transparent";
                    break;
                case 255:
                    string
                      s0 = ColorTranslator.FromWin32(ColorTranslator.ToWin32(c)).Name;
                    if (s0.Substring(0, 2) != "ff")
                        s += " " + s0;
                    break;
            }
            label6.Text = s;
        }

        private void trackBar5_Scroll(object sender, EventArgs e)
        {
            trackBar2.Value = trackBar3.Value = trackBar4.Value = trackBar5.Value;
            trackBar1_Scroll(null, null);
        }
    }
}
