﻿
namespace Appliances.Views
{
    partial class ApplianceForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ApplianceForm));
            this.GrbAddElectrodevice = new System.Windows.Forms.GroupBox();
            this.BtnCancel = new System.Windows.Forms.Button();
            this.BtnOk = new System.Windows.Forms.Button();
            this.LblState = new System.Windows.Forms.Label();
            this.PnlState = new System.Windows.Forms.Panel();
            this.RbtON = new System.Windows.Forms.RadioButton();
            this.RbtOFF = new System.Windows.Forms.RadioButton();
            this.LblPrice = new System.Windows.Forms.Label();
            this.LblPower = new System.Windows.Forms.Label();
            this.LblName = new System.Windows.Forms.Label();
            this.NudPrice = new System.Windows.Forms.NumericUpDown();
            this.NudPower = new System.Windows.Forms.NumericUpDown();
            this.TbxName = new System.Windows.Forms.TextBox();
            this.ErpName = new System.Windows.Forms.ErrorProvider(this.components);
            this.GrbAddElectrodevice.SuspendLayout();
            this.PnlState.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.NudPrice)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NudPower)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ErpName)).BeginInit();
            this.SuspendLayout();
            // 
            // GrbAddElectrodevice
            // 
            this.GrbAddElectrodevice.Controls.Add(this.BtnCancel);
            this.GrbAddElectrodevice.Controls.Add(this.BtnOk);
            this.GrbAddElectrodevice.Controls.Add(this.LblState);
            this.GrbAddElectrodevice.Controls.Add(this.PnlState);
            this.GrbAddElectrodevice.Controls.Add(this.LblPrice);
            this.GrbAddElectrodevice.Controls.Add(this.LblPower);
            this.GrbAddElectrodevice.Controls.Add(this.LblName);
            this.GrbAddElectrodevice.Controls.Add(this.NudPrice);
            this.GrbAddElectrodevice.Controls.Add(this.NudPower);
            this.GrbAddElectrodevice.Controls.Add(this.TbxName);
            this.GrbAddElectrodevice.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.GrbAddElectrodevice.Location = new System.Drawing.Point(12, 12);
            this.GrbAddElectrodevice.Name = "GrbAddElectrodevice";
            this.GrbAddElectrodevice.Size = new System.Drawing.Size(347, 303);
            this.GrbAddElectrodevice.TabIndex = 5;
            this.GrbAddElectrodevice.TabStop = false;
            this.GrbAddElectrodevice.Text = " Данные прибора: ";
            // 
            // BtnCancel
            // 
            this.BtnCancel.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.BtnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.BtnCancel.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.BtnCancel.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BtnCancel.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.BtnCancel.Location = new System.Drawing.Point(185, 246);
            this.BtnCancel.Name = "BtnCancel";
            this.BtnCancel.Size = new System.Drawing.Size(131, 39);
            this.BtnCancel.TabIndex = 9;
            this.BtnCancel.Text = "Отмена";
            this.BtnCancel.UseVisualStyleBackColor = false;
            this.BtnCancel.Click += new System.EventHandler(this.BtnCancel_Click);
            // 
            // BtnOk
            // 
            this.BtnOk.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.BtnOk.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.BtnOk.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.BtnOk.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BtnOk.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.BtnOk.Location = new System.Drawing.Point(20, 246);
            this.BtnOk.Name = "BtnOk";
            this.BtnOk.Size = new System.Drawing.Size(131, 39);
            this.BtnOk.TabIndex = 8;
            this.BtnOk.UseVisualStyleBackColor = false;
            this.BtnOk.Click += new System.EventHandler(this.BtnOk_Click);
            // 
            // LblState
            // 
            this.LblState.AutoSize = true;
            this.LblState.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblState.Location = new System.Drawing.Point(17, 210);
            this.LblState.Name = "LblState";
            this.LblState.Size = new System.Drawing.Size(93, 18);
            this.LblState.TabIndex = 7;
            this.LblState.Text = "Сосотояние:";
            // 
            // PnlState
            // 
            this.PnlState.Controls.Add(this.RbtON);
            this.PnlState.Controls.Add(this.RbtOFF);
            this.PnlState.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.PnlState.Location = new System.Drawing.Point(124, 197);
            this.PnlState.Name = "PnlState";
            this.PnlState.Size = new System.Drawing.Size(192, 31);
            this.PnlState.TabIndex = 6;
            // 
            // RbtON
            // 
            this.RbtON.AutoSize = true;
            this.RbtON.Checked = true;
            this.RbtON.Location = new System.Drawing.Point(36, 5);
            this.RbtON.Name = "RbtON";
            this.RbtON.Size = new System.Drawing.Size(47, 22);
            this.RbtON.TabIndex = 0;
            this.RbtON.TabStop = true;
            this.RbtON.Text = "ON";
            this.RbtON.UseVisualStyleBackColor = true;
            // 
            // RbtOFF
            // 
            this.RbtOFF.AutoSize = true;
            this.RbtOFF.Location = new System.Drawing.Point(102, 5);
            this.RbtOFF.Name = "RbtOFF";
            this.RbtOFF.Size = new System.Drawing.Size(53, 22);
            this.RbtOFF.TabIndex = 1;
            this.RbtOFF.TabStop = true;
            this.RbtOFF.Text = "OFF";
            this.RbtOFF.UseVisualStyleBackColor = true;
            // 
            // LblPrice
            // 
            this.LblPrice.AutoSize = true;
            this.LblPrice.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblPrice.Location = new System.Drawing.Point(17, 158);
            this.LblPrice.Name = "LblPrice";
            this.LblPrice.Size = new System.Drawing.Size(47, 18);
            this.LblPrice.TabIndex = 5;
            this.LblPrice.Text = "Цена:";
            // 
            // LblPower
            // 
            this.LblPower.AutoSize = true;
            this.LblPower.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblPower.Location = new System.Drawing.Point(17, 106);
            this.LblPower.Name = "LblPower";
            this.LblPower.Size = new System.Drawing.Size(85, 18);
            this.LblPower.TabIndex = 4;
            this.LblPower.Text = "Мощность:";
            // 
            // LblName
            // 
            this.LblName.AutoSize = true;
            this.LblName.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblName.Location = new System.Drawing.Point(17, 54);
            this.LblName.Name = "LblName";
            this.LblName.Size = new System.Drawing.Size(78, 18);
            this.LblName.TabIndex = 3;
            this.LblName.Text = "Название:";
            // 
            // NudPrice
            // 
            this.NudPrice.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.NudPrice.Location = new System.Drawing.Point(124, 154);
            this.NudPrice.Maximum = new decimal(new int[] {
            1874919424,
            2328306,
            0,
            0});
            this.NudPrice.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.NudPrice.Name = "NudPrice";
            this.NudPrice.Size = new System.Drawing.Size(192, 26);
            this.NudPrice.TabIndex = 2;
            this.NudPrice.ThousandsSeparator = true;
            this.NudPrice.Value = new decimal(new int[] {
            2100,
            0,
            0,
            0});
            // 
            // NudPower
            // 
            this.NudPower.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.NudPower.Location = new System.Drawing.Point(124, 102);
            this.NudPower.Maximum = new decimal(new int[] {
            1874919424,
            2328306,
            0,
            0});
            this.NudPower.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.NudPower.Name = "NudPower";
            this.NudPower.Size = new System.Drawing.Size(192, 26);
            this.NudPower.TabIndex = 1;
            this.NudPower.ThousandsSeparator = true;
            this.NudPower.Value = new decimal(new int[] {
            1200,
            0,
            0,
            0});
            // 
            // TbxName
            // 
            this.TbxName.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TbxName.Location = new System.Drawing.Point(124, 50);
            this.TbxName.Name = "TbxName";
            this.TbxName.Size = new System.Drawing.Size(192, 26);
            this.TbxName.TabIndex = 0;
            this.TbxName.Text = "чайник";
            this.TbxName.TextChanged += new System.EventHandler(this.Tbx_TextChanged);
            this.TbxName.Validated += new System.EventHandler(this.Txb_Validated);
            // 
            // ErpName
            // 
            this.ErpName.ContainerControl = this;
            // 
            // ApplianceForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(369, 326);
            this.Controls.Add(this.GrbAddElectrodevice);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "ApplianceForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ApplianceForm";
            this.GrbAddElectrodevice.ResumeLayout(false);
            this.GrbAddElectrodevice.PerformLayout();
            this.PnlState.ResumeLayout(false);
            this.PnlState.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.NudPrice)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NudPower)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ErpName)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox GrbAddElectrodevice;
        private System.Windows.Forms.Button BtnOk;
        private System.Windows.Forms.Label LblState;
        private System.Windows.Forms.Panel PnlState;
        private System.Windows.Forms.RadioButton RbtON;
        private System.Windows.Forms.RadioButton RbtOFF;
        private System.Windows.Forms.Label LblPrice;
        private System.Windows.Forms.Label LblPower;
        private System.Windows.Forms.Label LblName;
        private System.Windows.Forms.NumericUpDown NudPrice;
        private System.Windows.Forms.NumericUpDown NudPower;
        private System.Windows.Forms.TextBox TbxName;
        private System.Windows.Forms.Button BtnCancel;
        private System.Windows.Forms.ErrorProvider ErpName;
    }
}