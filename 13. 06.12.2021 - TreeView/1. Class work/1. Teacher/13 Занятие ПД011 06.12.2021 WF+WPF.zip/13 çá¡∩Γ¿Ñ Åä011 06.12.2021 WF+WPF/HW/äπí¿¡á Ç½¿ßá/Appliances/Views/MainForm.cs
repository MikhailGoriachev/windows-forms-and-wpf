﻿using Appliances.Controllers;
using Appliances.Helpers;
using Appliances.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Appliances.Views
{
    public partial class MainForm : Form
    {

        private FlatController _flatController;

        public MainForm() : this(new FlatController()) { } // MainForm

        public MainForm(FlatController flatController) {
            InitializeComponent();

            _flatController = flatController;

            // Если папки и/или файл нет, то создать папку
            if (!File.Exists(@"App_data\" + _flatController.FileName)) { 
                Directory.CreateDirectory(@"App_Data");
                _flatController.Flat.Serialization(@"App_Data\" + _flatController.FileName);
            } 
            else {
                _flatController.Flat.Deserialization(@"App_Data\" + _flatController.FileName);
                WriteToListView(LsvAppliances, _flatController.Flat.Appliances);
            } // if

            // запись коллекции объектов в ListView для табличного отображения
            WriteToListView(LsvAppliances, _flatController.Flat.Appliances);
            StlMain.Text = $"Коллекция электроприборов сформирована. Текущее количество электроприборов: {_flatController.Flat.Count}";
        } // MainForm


        private void Exit_Command(object sender, EventArgs e) => Application.Exit();

        private void About_Command(object sender, EventArgs e) {
            FormAbout formAbout = new FormAbout();
            formAbout.ShowDialog();
        } // About_Command

        // Сохранение данных электрооборудования квартиры
        private void Save_Command(object sender, EventArgs e) =>
            _flatController.Flat.Serialization(@"App_Data\" + _flatController.FileName);


        // Загрузка данных электрооборудования квартиры из выбранного файла
        private void Open_Command(object sender, EventArgs e) {
            OfdMain.Title = "Открыть файл";
            OfdMain.InitialDirectory = Path.GetDirectoryName(@"App_Data\" + _flatController.FileName);
            OfdMain.Filter = "Файлы JSON (*.json)|*.json";
            OfdMain.FilterIndex = 1;
            if (OfdMain.ShowDialog() == DialogResult.OK) {
                _flatController.Flat.Deserialization(OfdMain.FileName);
                WriteToListView(LsvAppliances, _flatController.Flat.Appliances);
                MainForm_Load(sender, e);
            } // if
        } // Open_Command


        // Сохранение данных электрооборудования квартиры в выбранном файле 
        private void SaveAs_Command(object sender, EventArgs e) {
            SfdMain.Title = "Сохранить файл как";
            SfdMain.InitialDirectory = Path.GetDirectoryName(_flatController.FileName);
            SfdMain.Filter = "Файлы JSON (*.json)|*.json";
            //SfdMain.FilterIndex = 1;
            if (SfdMain.ShowDialog() == DialogResult.OK) {
                _flatController.Flat.Serialization(SfdMain.FileName);
            } // if
        } // SaveAs_Command


        // запись коллекции объектов в ListView для табличного отображения
        private void WriteToListView(ListView listView, List<Appliance> appliances) {

            listView.Items.Clear();

            foreach (var appliance in appliances) {
                // получить элемент для заполнения строки ListView, указать в нем данные 0го столбца 
                ListViewItem listViewItem = new ListViewItem("", (appliance.State ? 1 : 0));

                // добавить остальные столбцы
                listViewItem.SubItems.Add(appliance.Name);
                listViewItem.SubItems.Add($"{appliance.Power:f2}");
                listViewItem.SubItems.Add($"{appliance.Price:f2}");

                // добавить строку в ListView
                listView.Items.Add(listViewItem);
            } // foreach person
        } // WriteToListView


        // Начальное формирование данных электрооборудования квартиры
        private void Generate_Command(object sender, EventArgs e) {
            _flatController.Flat.Generate(Utils.GetRandom(12, 15));

            StlMain.Text = $"Коллекция электроприборов сформирована. Текущее количество электроприборов: {_flatController.Flat.Count}";
            WriteToListView(LsvAppliances, _flatController.Flat.Appliances);

            // сериализация данных
            Save_Command(sender, e);

            // делаем главную страницу текущей
            TbcMain.SelectedTab = TbpGeneral;
        } // Generate_Command


        // свернуть в трей
        private void ToTray_Command(object sender, EventArgs e) {
            this.Hide();
            NtiMain.Visible = true;
        } // ToTray_Command


        // восстановить из трея
        private void FromTray_Command(object sender, EventArgs e){
            this.Show();
            WindowState = FormWindowState.Normal;
            NtiMain.Visible = false;
        } // FromTray_Command


        // удаление электроприбора
        private void RemoveAt_Command(object sender, EventArgs e) {
            // если нет выбранных элементов - молча уходим
            int index = LsvAppliances.SelectedIndices[0];
            if (LsvAppliances.SelectedIndices.Count == 0) return;

            // удаление записей и из коллекции
            _flatController.Flat.RemoveAppliance(index);

            WriteToListView(LsvAppliances, _flatController.Flat.Appliances);
            StlMain.Text = $"Электроприбор удалён. Текущее количество электроприборов: {_flatController.Flat.Count}";

            if(LsvAppliances.Items.Count > 0)
                LsvAppliances.Items[index -= LsvAppliances.Items.Count == index ? 1 : 0].Selected = true;

            // сериализация данных
            Save_Command(sender, e);
        } // RemoveAt_Command


        // Включение/выключение выбранного электроприбора
        private void TurnOnOff_Command(object sender, EventArgs e) {
            // если нет выбранных элементов - молча уходим
            if (LsvAppliances.SelectedIndices.Count == 0) return;

            int index = LsvAppliances.SelectedIndices[0];

            _flatController.Flat.ChangeState(index);

            WriteToListView(LsvAppliances, _flatController.Flat.Appliances);
            StlMain.Text = $"";

            LsvAppliances.Items[index].Selected = true;

            // сериализация данных
            Save_Command(sender, e);
        } // TurnOnOff_Command


        // Включение всех электроприборов квартиры
        private void TurnOn_Command(object sender, EventArgs e) {
            _flatController.Flat.TurnOnOff(true);

            WriteToListView(LsvAppliances, _flatController.Flat.Appliances);
            StlMain.Text = $"Все электроприборы включены.";
        } // TurnOn_Command


        // Выключение всех электроприборов квартиры
        private void TurnOff_Command(object sender, EventArgs e) {
            _flatController.Flat.TurnOnOff(false);

            WriteToListView(LsvAppliances, _flatController.Flat.Appliances);
            StlMain.Text = $"Все электроприборы выключены.";
        } // TurnOff_Command


        // сортировка коллекции электроприборов по названию
        private void OrderByName_Command(object sender, EventArgs e) {
            WriteToListView(LsvOrderedAppliances, _flatController.OrderByName());

            // делаем страницу отсортированных данных текущей
            TbcMain.SelectedTab = TbpOrdered;

            // формирование заголовка поля вывода данных
            LblHeaderOrdered.Text = "Коллекция электроприборов упорядочена по названию:"; ;
        } // OrderByName_Command


        // сортировка коллекции электроприборов по состоянию
        private void OrderByState_Command(object sender, EventArgs e) {
            WriteToListView(LsvOrderedAppliances, _flatController.OrderByState());

            // делаем страницу отсортированных данных текущей
            TbcMain.SelectedTab = TbpOrdered;

            // формирование заголовка поля вывода данных
            LblHeaderOrdered.Text = "Коллекция электроприборов упорядочена по состоянию:"; ;
        } // OrderByState_Command


        // сортировка коллекции электроприборов по мощности
        private void OrderByPower_Command(object sender, EventArgs e) {
            WriteToListView(LsvOrderedAppliances, _flatController.OrderByPower());

            // делаем страницу отсортированных данных текущей
            TbcMain.SelectedTab = TbpOrdered;

            // формирование заголовка поля вывода данных
            LblHeaderOrdered.Text = "Коллекция электроприборов упорядочена по мощности:"; ;
        } // OrderByPower_Command


        // сортировка коллекции электроприборов по убыванию цены
        private void OrderByPriceDesc_Command(object sender, EventArgs e) {
            WriteToListView(LsvOrderedAppliances, _flatController.OrderByPriceDesc());

            // делаем страницу отсортированных данных текущей
            TbcMain.SelectedTab = TbpOrdered;

            // формирование заголовка поля вывода данных
            LblHeaderOrdered.Text = "Коллекция электроприборов упорядочена по убыванию цены:"; ;
        } // OrderByPriceDesc_Command


        // Выборка и вывод в отдельной вкладке коллекции электроприборов, с заданным названием
        private void SelectByName_Command(object sender, EventArgs e) {
            // получить список названий из коллекции
            List<string> names = _flatController.GetNames();

            // создание формы выбора названия, передача в окно списка названий
            ChoiceForm choiceForm = new ChoiceForm("Выбор названия", "Название для выборки:", names);

            if (choiceForm.ShowDialog() != DialogResult.OK) return;
            string name = choiceForm.Option;

            LblHeaderSelected.Text = $"Выборка коллекции электроприборов, с заданным названием\n\rНазвание электроприбора: {name}";
            WriteToListView(LsvSelectedAppliances, _flatController.SelectWhereName(name));

            TbcMain.SelectedTab = TbpSelected; ;
        } // SelectByName_Command

        // Выборка и вывод в отдельной вкладке коллекции электроприборов, с заданным состоянием
        private void SelectByState_Command(object sender, EventArgs e) {
            // получить список названий из коллекции
            // List<string> states = _flatController.GetStates();
            List<string> states = new List<string>(new string[] { "включен", "выключен" });

            // создание формы выбора состояния, передача в окно списка состояний
            ChoiceForm choiceForm = new ChoiceForm("Выбор состояния", "Состояние для выборки:", states);

            if (choiceForm.ShowDialog() != DialogResult.OK) return;
            string state = choiceForm.Option;

            LblHeaderSelected.Text = $"Выборка коллекции электроприборов, с заданным состоянием\n\rСостояние электроприбора: {state}";
            WriteToListView(LsvSelectedAppliances, _flatController.SelectWhereState(state == "включен"));

            TbcMain.SelectedTab = TbpSelected; ;
        } // SelectByState_Command

        // Разрешаем работу кнопок правки данных о электроприборе только на главной вкладке формы  
        private void TbcMain_SelectedIndexChanged(object sender, EventArgs e) {
            TsbAddAppliance.Enabled = TsbEditAppliance.Enabled =
                TsbRemoveAppliance.Enabled = TsbTurnOff.Enabled =
                TsbTurnOn.Enabled = TsbTurnOnOff.Enabled = 
                MniAppliances.Enabled = TsmAppliances.Enabled =
                TbcMain.SelectedTab == TbpGeneral;
        } // TbcMain_SelectedIndexChanged

        // Добавление электроприбора в коллекцию 
        private void AddAppliance_Command(object sender, EventArgs e) {
            ApplianceForm applianceForm = new ApplianceForm();

            // если окно закрыто не по кнопке BtnOk - молча уходим
            if (applianceForm.ShowDialog() != DialogResult.OK) return;

            // получить данные из свойства формы
            _flatController.Flat.AddAppliance(applianceForm.Appliance);

            WriteToListView(LsvAppliances, _flatController.Flat.Appliances);

            StlMain.Text = $"Электроприбор добавлен. Текущее количество электроприборов: {_flatController.Flat.Count}";
            // сериализация данных
            Save_Command(sender, e);
        } // AddAppliance_Command

        // Редактирование выбранного электроприбора
        private void EditAppliance_Command(object sender, EventArgs e) {
            // если нет выбранных элементов - молча уходим
            if (LsvAppliances.SelectedIndices.Count == 0) return;

            ApplianceForm applianceForm = new ApplianceForm("Редактирование электроприбора", "Сохранить");

            int index = LsvAppliances.SelectedIndices[0];
            applianceForm.Appliance = _flatController.Flat.Appliances[index];
            // если окно закрыто не по кнопке BtnOk - молча уходим
            if (applianceForm.ShowDialog() != DialogResult.OK) return;

            // получить данные из свойства формы
            _flatController.Flat.EditAppliance(index, applianceForm.Appliance);

            WriteToListView(LsvAppliances, _flatController.Flat.Appliances);

            StlMain.Text = $"Электроприбор изменён. Текущее количество электроприборов: {_flatController.Flat.Count}";
            LsvAppliances.Items[index].Selected = true;
            // сериализация данных
            Save_Command(sender, e);
        } // AddAppliance_Command

        private void MainForm_Load(object sender, EventArgs e) => 
            LblAddress.Text = $"Адрес квартиры: {_flatController.Flat.Address}";

        // Редактирование данных квартиры
        private void EditFlat_Command(object sender, EventArgs e) {
            FlatForm flatForm = new FlatForm(_flatController.Flat.Address);

            // если окно закрыто не по кнопке BtnOk - молча уходим
            if (flatForm.ShowDialog() != DialogResult.OK) return;

            // получить данные
            _flatController.Flat.Address = flatForm.Address;

            // сериализация данных
            Save_Command(sender, e);

            MainForm_Load(sender, e);
        } // EditFlat_Command

        private void LsvAppliances_DragDrop(object sender, DragEventArgs e) {
            string[] fileNames = (string[])e.Data.GetData(DataFormats.FileDrop);
            _flatController.Flat.Deserialization(fileNames[0]);
            WriteToListView(LsvAppliances, _flatController.Flat.Appliances);
            MainForm_Load(sender, e);
            } // LsvAppliances_DragDrop

        private void LsvAppliances_DragEnter(object sender, DragEventArgs e)  {
            e.Effect = DragDropEffects.Copy;
        } // LsvAppliances_DragEnter
    }
}
