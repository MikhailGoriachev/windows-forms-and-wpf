﻿
namespace Appliances.Views
{
    partial class FlatForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.GrbTelevision = new System.Windows.Forms.GroupBox();
            this.TbxAddress = new System.Windows.Forms.TextBox();
            this.LblAddress = new System.Windows.Forms.Label();
            this.BtnCancel = new System.Windows.Forms.Button();
            this.BtnOk = new System.Windows.Forms.Button();
            this.ErpAddress = new System.Windows.Forms.ErrorProvider(this.components);
            this.GrbTelevision.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ErpAddress)).BeginInit();
            this.SuspendLayout();
            // 
            // GrbTelevision
            // 
            this.GrbTelevision.BackColor = System.Drawing.SystemColors.Control;
            this.GrbTelevision.Controls.Add(this.TbxAddress);
            this.GrbTelevision.Controls.Add(this.LblAddress);
            this.GrbTelevision.Location = new System.Drawing.Point(12, 12);
            this.GrbTelevision.Name = "GrbTelevision";
            this.GrbTelevision.Size = new System.Drawing.Size(634, 115);
            this.GrbTelevision.TabIndex = 5;
            this.GrbTelevision.TabStop = false;
            this.GrbTelevision.Text = " Данные квартиры: ";
            // 
            // TbxAddress
            // 
            this.TbxAddress.Location = new System.Drawing.Point(201, 54);
            this.TbxAddress.Name = "TbxAddress";
            this.TbxAddress.Size = new System.Drawing.Size(393, 27);
            this.TbxAddress.TabIndex = 10;
            this.TbxAddress.TextChanged += new System.EventHandler(this.Tbx_TextChanged);
            this.TbxAddress.Validated += new System.EventHandler(this.Tbx_Validated);
            // 
            // LblAddress
            // 
            this.LblAddress.AutoSize = true;
            this.LblAddress.Location = new System.Drawing.Point(19, 58);
            this.LblAddress.Name = "LblAddress";
            this.LblAddress.Size = new System.Drawing.Size(128, 19);
            this.LblAddress.TabIndex = 11;
            this.LblAddress.Text = "Адрес квартиры";
            // 
            // BtnCancel
            // 
            this.BtnCancel.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.BtnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.BtnCancel.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.BtnCancel.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.BtnCancel.Location = new System.Drawing.Point(513, 133);
            this.BtnCancel.Name = "BtnCancel";
            this.BtnCancel.Size = new System.Drawing.Size(133, 27);
            this.BtnCancel.TabIndex = 4;
            this.BtnCancel.Text = "Отмена";
            this.BtnCancel.UseVisualStyleBackColor = false;
            // 
            // BtnOk
            // 
            this.BtnOk.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.BtnOk.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.BtnOk.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.BtnOk.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.BtnOk.Location = new System.Drawing.Point(368, 133);
            this.BtnOk.Name = "BtnOk";
            this.BtnOk.Size = new System.Drawing.Size(133, 27);
            this.BtnOk.TabIndex = 3;
            this.BtnOk.Text = "Сохранить";
            this.BtnOk.UseVisualStyleBackColor = false;
            this.BtnOk.Click += new System.EventHandler(this.BtnOk_Click);
            // 
            // ErpAddress
            // 
            this.ErpAddress.ContainerControl = this;
            // 
            // RepairShopForm
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(655, 168);
            this.Controls.Add(this.GrbTelevision);
            this.Controls.Add(this.BtnCancel);
            this.Controls.Add(this.BtnOk);
            this.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "RepairShopForm";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Редактирование данных квартиры";
            this.GrbTelevision.ResumeLayout(false);
            this.GrbTelevision.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ErpAddress)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox GrbTelevision;
        private System.Windows.Forms.TextBox TbxAddress;
        private System.Windows.Forms.Label LblAddress;
        private System.Windows.Forms.Button BtnCancel;
        private System.Windows.Forms.Button BtnOk;
        private System.Windows.Forms.ErrorProvider ErpAddress;
    }
}