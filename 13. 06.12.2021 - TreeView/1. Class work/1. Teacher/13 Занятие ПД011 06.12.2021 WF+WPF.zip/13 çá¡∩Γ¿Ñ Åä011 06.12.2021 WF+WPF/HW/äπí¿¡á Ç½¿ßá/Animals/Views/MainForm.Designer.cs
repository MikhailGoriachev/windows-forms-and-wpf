﻿
namespace Animals.Views
{
    partial class MainForm
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.ImlAnimals = new System.Windows.Forms.ImageList(this.components);
            this.TbsMain = new System.Windows.Forms.ToolStrip();
            this.TsbFileOpen = new System.Windows.Forms.ToolStripButton();
            this.TsbFileSave = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.TsbNewFlat = new System.Windows.Forms.ToolStripButton();
            this.TsbSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.TsbAddAppliance = new System.Windows.Forms.ToolStripButton();
            this.TsbEditAppliance = new System.Windows.Forms.ToolStripButton();
            this.TsbRemoveAppliance = new System.Windows.Forms.ToolStripButton();
            this.TsbSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.TsdOrderBy = new System.Windows.Forms.ToolStripDropDownButton();
            this.DmiOrderByAge = new System.Windows.Forms.ToolStripMenuItem();
            this.DmiOrderByType = new System.Windows.Forms.ToolStripMenuItem();
            this.DmiOrderByOwner = new System.Windows.Forms.ToolStripMenuItem();
            this.TsbSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.TsbExit = new System.Windows.Forms.ToolStripButton();
            this.TsbAbout = new System.Windows.Forms.ToolStripButton();
            this.TsbToTray = new System.Windows.Forms.ToolStripButton();
            this.TsdSelectWhere = new System.Windows.Forms.ToolStripDropDownButton();
            this.TsdSelectWhereMaxWeight = new System.Windows.Forms.ToolStripMenuItem();
            this.TsdSelectWhereState = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.MnsMain = new System.Windows.Forms.MenuStrip();
            this.MniFile = new System.Windows.Forms.ToolStripMenuItem();
            this.MniFileOpen = new System.Windows.Forms.ToolStripMenuItem();
            this.MniFileSave = new System.Windows.Forms.ToolStripMenuItem();
            this.MniFileSaveAs = new System.Windows.Forms.ToolStripMenuItem();
            this.MniFileSep1 = new System.Windows.Forms.ToolStripSeparator();
            this.MniFileExit = new System.Windows.Forms.ToolStripMenuItem();
            this.MniAnimals = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem52 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem53 = new System.Windows.Forms.ToolStripSeparator();
            this.MniAnimalsAdd = new System.Windows.Forms.ToolStripMenuItem();
            this.MniAnimalsEdit = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripSeparator();
            this.MniAnimalsRemoveAt = new System.Windows.Forms.ToolStripMenuItem();
            this.MniOrderBy = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem29 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem30 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem33 = new System.Windows.Forms.ToolStripMenuItem();
            this.MniSelectWhere = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem50 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem51 = new System.Windows.Forms.ToolStripMenuItem();
            this.MniHelp = new System.Windows.Forms.ToolStripMenuItem();
            this.MniHelpAbout = new System.Windows.Forms.ToolStripMenuItem();
            this.StsMain = new System.Windows.Forms.StatusStrip();
            this.StlMain = new System.Windows.Forms.ToolStripStatusLabel();
            this.OfdMain = new System.Windows.Forms.OpenFileDialog();
            this.CmnMain = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.toolStripMenuItem10 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripMenuItem11 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripMenuItem21 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem26 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem20 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripMenuItem6 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem7 = new System.Windows.Forms.ToolStripMenuItem();
            this.SfdMain = new System.Windows.Forms.SaveFileDialog();
            this.NtiMain = new System.Windows.Forms.NotifyIcon(this.components);
            this.CmnTray = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem4 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.вToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.TbcMain = new System.Windows.Forms.TabControl();
            this.TbpGeneral = new System.Windows.Forms.TabPage();
            this.LblHeaderGeneral = new System.Windows.Forms.Label();
            this.LsvAnimals = new System.Windows.Forms.ListView();
            this.ClhPhoto1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.ClhType1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.ClhPetName1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.ClhWeight1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.ClhAge1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.ClhColor1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.ClhOwner1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.TbpOrdered = new System.Windows.Forms.TabPage();
            this.LsvOrderedAnimals = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader9 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader10 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader11 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.LblHeaderOrdered = new System.Windows.Forms.Label();
            this.TbpSelected = new System.Windows.Forms.TabPage();
            this.TbxOwner = new System.Windows.Forms.TextBox();
            this.LblOwner = new System.Windows.Forms.Label();
            this.LsvSelectedAnimals = new System.Windows.Forms.ListView();
            this.columnHeader5 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader6 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader7 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader8 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader12 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader13 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader14 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.LblHeaderSelected = new System.Windows.Forms.Label();
            this.StlFilePath = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripMenuItem12 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem13 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem14 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem15 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem16 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem5 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem8 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem9 = new System.Windows.Forms.ToolStripMenuItem();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripMenuItem22 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem23 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem24 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem25 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem27 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem28 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem31 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem32 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator6 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripMenuItem34 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem35 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator7 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripMenuItem17 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem18 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator8 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripMenuItem19 = new System.Windows.Forms.ToolStripMenuItem();
            this.TbsMain.SuspendLayout();
            this.MnsMain.SuspendLayout();
            this.StsMain.SuspendLayout();
            this.CmnMain.SuspendLayout();
            this.CmnTray.SuspendLayout();
            this.TbcMain.SuspendLayout();
            this.TbpGeneral.SuspendLayout();
            this.TbpOrdered.SuspendLayout();
            this.TbpSelected.SuspendLayout();
            this.contextMenuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // ImlAnimals
            // 
            this.ImlAnimals.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("ImlAnimals.ImageStream")));
            this.ImlAnimals.TransparentColor = System.Drawing.Color.Transparent;
            this.ImlAnimals.Images.SetKeyName(0, "bird.png");
            this.ImlAnimals.Images.SetKeyName(1, "bull.png");
            this.ImlAnimals.Images.SetKeyName(2, "cat.png");
            this.ImlAnimals.Images.SetKeyName(3, "cow.png");
            this.ImlAnimals.Images.SetKeyName(4, "dog.png");
            this.ImlAnimals.Images.SetKeyName(5, "duck.png");
            this.ImlAnimals.Images.SetKeyName(6, "elephant.png");
            this.ImlAnimals.Images.SetKeyName(7, "fish.png");
            this.ImlAnimals.Images.SetKeyName(8, "horse.png");
            this.ImlAnimals.Images.SetKeyName(9, "ladybug.png");
            this.ImlAnimals.Images.SetKeyName(10, "leopard.png");
            this.ImlAnimals.Images.SetKeyName(11, "lion.png");
            this.ImlAnimals.Images.SetKeyName(12, "lobster.png");
            this.ImlAnimals.Images.SetKeyName(13, "rabbit.png");
            this.ImlAnimals.Images.SetKeyName(14, "snail.png");
            this.ImlAnimals.Images.SetKeyName(15, "turtle.png");
            // 
            // TbsMain
            // 
            this.TbsMain.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TbsMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.TsbFileOpen,
            this.TsbFileSave,
            this.toolStripSeparator1,
            this.TsbNewFlat,
            this.TsbSeparator1,
            this.TsbAddAppliance,
            this.TsbEditAppliance,
            this.TsbRemoveAppliance,
            this.TsbSeparator2,
            this.TsdOrderBy,
            this.TsbSeparator3,
            this.TsbExit,
            this.TsbAbout,
            this.TsbToTray,
            this.TsdSelectWhere,
            this.toolStripSeparator2});
            this.TbsMain.Location = new System.Drawing.Point(0, 29);
            this.TbsMain.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.TbsMain.Name = "TbsMain";
            this.TbsMain.Size = new System.Drawing.Size(962, 39);
            this.TbsMain.TabIndex = 8;
            this.TbsMain.Text = "toolStrip1";
            // 
            // TsbFileOpen
            // 
            this.TsbFileOpen.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbFileOpen.Image = global::Animals.Properties.Resources.folder_blue;
            this.TsbFileOpen.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbFileOpen.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbFileOpen.Name = "TsbFileOpen";
            this.TsbFileOpen.Size = new System.Drawing.Size(36, 36);
            this.TsbFileOpen.ToolTipText = "Открыть файл данных\r\n";
            this.TsbFileOpen.Click += new System.EventHandler(this.Open_Command);
            // 
            // TsbFileSave
            // 
            this.TsbFileSave.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbFileSave.Image = global::Animals.Properties.Resources.save_as;
            this.TsbFileSave.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbFileSave.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbFileSave.Name = "TsbFileSave";
            this.TsbFileSave.Size = new System.Drawing.Size(36, 36);
            this.TsbFileSave.ToolTipText = "Сохранить файл данных ";
            this.TsbFileSave.Click += new System.EventHandler(this.SaveAs_Command);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 39);
            // 
            // TsbNewFlat
            // 
            this.TsbNewFlat.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbNewFlat.Image = global::Animals.Properties.Resources.Create;
            this.TsbNewFlat.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbNewFlat.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbNewFlat.Name = "TsbNewFlat";
            this.TsbNewFlat.Size = new System.Drawing.Size(34, 36);
            this.TsbNewFlat.ToolTipText = "Создание новых сведений о квартире";
            this.TsbNewFlat.Click += new System.EventHandler(this.Generate_Command);
            // 
            // TsbSeparator1
            // 
            this.TsbSeparator1.Name = "TsbSeparator1";
            this.TsbSeparator1.Size = new System.Drawing.Size(6, 39);
            // 
            // TsbAddAppliance
            // 
            this.TsbAddAppliance.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbAddAppliance.Image = global::Animals.Properties.Resources.Add;
            this.TsbAddAppliance.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbAddAppliance.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbAddAppliance.Name = "TsbAddAppliance";
            this.TsbAddAppliance.Size = new System.Drawing.Size(34, 36);
            this.TsbAddAppliance.ToolTipText = "Добавить животное\r\n";
            this.TsbAddAppliance.Click += new System.EventHandler(this.AddAnimal_Command);
            // 
            // TsbEditAppliance
            // 
            this.TsbEditAppliance.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbEditAppliance.Image = global::Animals.Properties.Resources.edit;
            this.TsbEditAppliance.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbEditAppliance.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbEditAppliance.Name = "TsbEditAppliance";
            this.TsbEditAppliance.Size = new System.Drawing.Size(34, 36);
            this.TsbEditAppliance.ToolTipText = "Редактирование данных животного\r\n\r\n";
            this.TsbEditAppliance.Click += new System.EventHandler(this.EditAnimal_Command);
            // 
            // TsbRemoveAppliance
            // 
            this.TsbRemoveAppliance.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbRemoveAppliance.Image = global::Animals.Properties.Resources.remove;
            this.TsbRemoveAppliance.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbRemoveAppliance.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbRemoveAppliance.Name = "TsbRemoveAppliance";
            this.TsbRemoveAppliance.Size = new System.Drawing.Size(34, 36);
            this.TsbRemoveAppliance.ToolTipText = "Удалить животное";
            this.TsbRemoveAppliance.Click += new System.EventHandler(this.RemoveAt_Command);
            // 
            // TsbSeparator2
            // 
            this.TsbSeparator2.Name = "TsbSeparator2";
            this.TsbSeparator2.Size = new System.Drawing.Size(6, 39);
            // 
            // TsdOrderBy
            // 
            this.TsdOrderBy.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsdOrderBy.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.DmiOrderByAge,
            this.DmiOrderByType,
            this.DmiOrderByOwner});
            this.TsdOrderBy.Image = global::Animals.Properties.Resources.OrderBy;
            this.TsdOrderBy.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsdOrderBy.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsdOrderBy.Name = "TsdOrderBy";
            this.TsdOrderBy.Size = new System.Drawing.Size(43, 36);
            this.TsdOrderBy.Text = "Сортировка";
            this.TsdOrderBy.ToolTipText = "Сортировка коллекции\r\n";
            // 
            // DmiOrderByAge
            // 
            this.DmiOrderByAge.Image = global::Animals.Properties.Resources.sort_number1;
            this.DmiOrderByAge.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.DmiOrderByAge.Name = "DmiOrderByAge";
            this.DmiOrderByAge.Size = new System.Drawing.Size(282, 38);
            this.DmiOrderByAge.Text = "По возрасту";
            this.DmiOrderByAge.Click += new System.EventHandler(this.OrderByAge_Command);
            // 
            // DmiOrderByType
            // 
            this.DmiOrderByType.Image = global::Animals.Properties.Resources.sort_alphabel_column;
            this.DmiOrderByType.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.DmiOrderByType.Name = "DmiOrderByType";
            this.DmiOrderByType.Size = new System.Drawing.Size(282, 38);
            this.DmiOrderByType.Text = "По виду";
            this.DmiOrderByType.Click += new System.EventHandler(this.OrderByType_Command);
            // 
            // DmiOrderByOwner
            // 
            this.DmiOrderByOwner.Image = global::Animals.Properties.Resources.sort_alphabel;
            this.DmiOrderByOwner.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.DmiOrderByOwner.Name = "DmiOrderByOwner";
            this.DmiOrderByOwner.Size = new System.Drawing.Size(282, 38);
            this.DmiOrderByOwner.Text = "По фамилиям владельцев";
            this.DmiOrderByOwner.Click += new System.EventHandler(this.OrderByOwner_Command);
            // 
            // TsbSeparator3
            // 
            this.TsbSeparator3.Name = "TsbSeparator3";
            this.TsbSeparator3.Size = new System.Drawing.Size(6, 39);
            // 
            // TsbExit
            // 
            this.TsbExit.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.TsbExit.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbExit.Image = global::Animals.Properties.Resources.exit;
            this.TsbExit.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbExit.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbExit.Name = "TsbExit";
            this.TsbExit.Size = new System.Drawing.Size(34, 36);
            this.TsbExit.ToolTipText = "Выход из приложения";
            this.TsbExit.Click += new System.EventHandler(this.Exit_Command);
            // 
            // TsbAbout
            // 
            this.TsbAbout.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.TsbAbout.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbAbout.Image = global::Animals.Properties.Resources.help;
            this.TsbAbout.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbAbout.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbAbout.Name = "TsbAbout";
            this.TsbAbout.Size = new System.Drawing.Size(36, 36);
            this.TsbAbout.ToolTipText = "Сведения о программе";
            this.TsbAbout.Click += new System.EventHandler(this.About_Command);
            // 
            // TsbToTray
            // 
            this.TsbToTray.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.TsbToTray.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbToTray.Image = global::Animals.Properties.Resources.ToTray;
            this.TsbToTray.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbToTray.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbToTray.Name = "TsbToTray";
            this.TsbToTray.Size = new System.Drawing.Size(34, 36);
            this.TsbToTray.Text = "Свернуть в трей";
            this.TsbToTray.ToolTipText = "Свернуть в трей";
            this.TsbToTray.Click += new System.EventHandler(this.ToTray_Command);
            // 
            // TsdSelectWhere
            // 
            this.TsdSelectWhere.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsdSelectWhere.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.TsdSelectWhereMaxWeight,
            this.TsdSelectWhereState});
            this.TsdSelectWhere.Image = global::Animals.Properties.Resources.Select;
            this.TsdSelectWhere.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsdSelectWhere.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsdSelectWhere.Name = "TsdSelectWhere";
            this.TsdSelectWhere.Size = new System.Drawing.Size(43, 36);
            this.TsdSelectWhere.Text = "Выборка";
            this.TsdSelectWhere.ToolTipText = "Выборка из коллекции";
            // 
            // TsdSelectWhereMaxWeight
            // 
            this.TsdSelectWhereMaxWeight.Image = global::Animals.Properties.Resources.mixx;
            this.TsdSelectWhereMaxWeight.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsdSelectWhereMaxWeight.Name = "TsdSelectWhereMaxWeight";
            this.TsdSelectWhereMaxWeight.Size = new System.Drawing.Size(266, 38);
            this.TsdSelectWhereMaxWeight.Text = "С максимальным весом";
            this.TsdSelectWhereMaxWeight.Click += new System.EventHandler(this.SelectWhereMaxWeight_Command);
            // 
            // TsdSelectWhereState
            // 
            this.TsdSelectWhereState.Image = global::Animals.Properties.Resources.name;
            this.TsdSelectWhereState.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsdSelectWhereState.Name = "TsdSelectWhereState";
            this.TsdSelectWhereState.Size = new System.Drawing.Size(266, 38);
            this.TsdSelectWhereState.Text = "С фамилией владельца";
            this.TsdSelectWhereState.Click += new System.EventHandler(this.SelectWhereOwner_Command);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 39);
            // 
            // MnsMain
            // 
            this.MnsMain.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.MnsMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniFile,
            this.MniAnimals,
            this.MniOrderBy,
            this.MniSelectWhere,
            this.MniHelp});
            this.MnsMain.Location = new System.Drawing.Point(0, 0);
            this.MnsMain.Name = "MnsMain";
            this.MnsMain.Size = new System.Drawing.Size(962, 29);
            this.MnsMain.TabIndex = 7;
            this.MnsMain.Text = "menuStrip1";
            // 
            // MniFile
            // 
            this.MniFile.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniFileOpen,
            this.MniFileSave,
            this.MniFileSaveAs,
            this.MniFileSep1,
            this.MniFileExit});
            this.MniFile.Name = "MniFile";
            this.MniFile.Size = new System.Drawing.Size(59, 25);
            this.MniFile.Text = "Файл";
            // 
            // MniFileOpen
            // 
            this.MniFileOpen.Image = global::Animals.Properties.Resources.folder_blue;
            this.MniFileOpen.Name = "MniFileOpen";
            this.MniFileOpen.Size = new System.Drawing.Size(193, 26);
            this.MniFileOpen.Text = "Открыть...";
            this.MniFileOpen.Click += new System.EventHandler(this.Open_Command);
            // 
            // MniFileSave
            // 
            this.MniFileSave.Name = "MniFileSave";
            this.MniFileSave.Size = new System.Drawing.Size(193, 26);
            this.MniFileSave.Text = "Сохранить";
            this.MniFileSave.Click += new System.EventHandler(this.Save_Command);
            // 
            // MniFileSaveAs
            // 
            this.MniFileSaveAs.Image = global::Animals.Properties.Resources.save_as;
            this.MniFileSaveAs.Name = "MniFileSaveAs";
            this.MniFileSaveAs.Size = new System.Drawing.Size(193, 26);
            this.MniFileSaveAs.Text = "Сохранить как...";
            this.MniFileSaveAs.Click += new System.EventHandler(this.SaveAs_Command);
            // 
            // MniFileSep1
            // 
            this.MniFileSep1.Name = "MniFileSep1";
            this.MniFileSep1.Size = new System.Drawing.Size(190, 6);
            // 
            // MniFileExit
            // 
            this.MniFileExit.Image = global::Animals.Properties.Resources.exit;
            this.MniFileExit.Name = "MniFileExit";
            this.MniFileExit.Size = new System.Drawing.Size(193, 26);
            this.MniFileExit.Text = "Выход";
            this.MniFileExit.Click += new System.EventHandler(this.Exit_Command);
            // 
            // MniAnimals
            // 
            this.MniAnimals.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem52,
            this.toolStripMenuItem53,
            this.MniAnimalsAdd,
            this.MniAnimalsEdit,
            this.toolStripMenuItem1,
            this.MniAnimalsRemoveAt});
            this.MniAnimals.Name = "MniAnimals";
            this.MniAnimals.Size = new System.Drawing.Size(97, 25);
            this.MniAnimals.Text = "Животные";
            // 
            // toolStripMenuItem52
            // 
            this.toolStripMenuItem52.Image = global::Animals.Properties.Resources.Create;
            this.toolStripMenuItem52.Name = "toolStripMenuItem52";
            this.toolStripMenuItem52.Size = new System.Drawing.Size(194, 26);
            this.toolStripMenuItem52.Text = "Новая коллекия";
            this.toolStripMenuItem52.Click += new System.EventHandler(this.Generate_Command);
            // 
            // toolStripMenuItem53
            // 
            this.toolStripMenuItem53.Name = "toolStripMenuItem53";
            this.toolStripMenuItem53.Size = new System.Drawing.Size(191, 6);
            // 
            // MniAnimalsAdd
            // 
            this.MniAnimalsAdd.Image = global::Animals.Properties.Resources.Add;
            this.MniAnimalsAdd.Name = "MniAnimalsAdd";
            this.MniAnimalsAdd.Size = new System.Drawing.Size(194, 26);
            this.MniAnimalsAdd.Text = "Добавить...";
            this.MniAnimalsAdd.Click += new System.EventHandler(this.AddAnimal_Command);
            // 
            // MniAnimalsEdit
            // 
            this.MniAnimalsEdit.Image = global::Animals.Properties.Resources.edit;
            this.MniAnimalsEdit.Name = "MniAnimalsEdit";
            this.MniAnimalsEdit.Size = new System.Drawing.Size(194, 26);
            this.MniAnimalsEdit.Text = "Изменить...";
            this.MniAnimalsEdit.Click += new System.EventHandler(this.EditAnimal_Command);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(191, 6);
            // 
            // MniAnimalsRemoveAt
            // 
            this.MniAnimalsRemoveAt.Image = global::Animals.Properties.Resources.remove;
            this.MniAnimalsRemoveAt.Name = "MniAnimalsRemoveAt";
            this.MniAnimalsRemoveAt.Size = new System.Drawing.Size(194, 26);
            this.MniAnimalsRemoveAt.Text = "Удалить";
            this.MniAnimalsRemoveAt.Click += new System.EventHandler(this.RemoveAt_Command);
            // 
            // MniOrderBy
            // 
            this.MniOrderBy.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem29,
            this.toolStripMenuItem30,
            this.toolStripMenuItem33});
            this.MniOrderBy.Name = "MniOrderBy";
            this.MniOrderBy.Size = new System.Drawing.Size(108, 25);
            this.MniOrderBy.Text = "Сортировка";
            // 
            // toolStripMenuItem29
            // 
            this.toolStripMenuItem29.Image = global::Animals.Properties.Resources.sort_number1;
            this.toolStripMenuItem29.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripMenuItem29.Name = "toolStripMenuItem29";
            this.toolStripMenuItem29.Size = new System.Drawing.Size(282, 38);
            this.toolStripMenuItem29.Text = "По возрасту";
            this.toolStripMenuItem29.Click += new System.EventHandler(this.OrderByAge_Command);
            // 
            // toolStripMenuItem30
            // 
            this.toolStripMenuItem30.Image = global::Animals.Properties.Resources.sort_alphabel_column;
            this.toolStripMenuItem30.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripMenuItem30.Name = "toolStripMenuItem30";
            this.toolStripMenuItem30.Size = new System.Drawing.Size(282, 38);
            this.toolStripMenuItem30.Text = "По виду";
            this.toolStripMenuItem30.Click += new System.EventHandler(this.OrderByType_Command);
            // 
            // toolStripMenuItem33
            // 
            this.toolStripMenuItem33.Image = global::Animals.Properties.Resources.sort_alphabel;
            this.toolStripMenuItem33.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripMenuItem33.Name = "toolStripMenuItem33";
            this.toolStripMenuItem33.Size = new System.Drawing.Size(282, 38);
            this.toolStripMenuItem33.Text = "По фамилиям владельцев";
            this.toolStripMenuItem33.Click += new System.EventHandler(this.OrderByOwner_Command);
            // 
            // MniSelectWhere
            // 
            this.MniSelectWhere.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem50,
            this.toolStripMenuItem51});
            this.MniSelectWhere.Name = "MniSelectWhere";
            this.MniSelectWhere.Size = new System.Drawing.Size(85, 25);
            this.MniSelectWhere.Text = "Выборка";
            // 
            // toolStripMenuItem50
            // 
            this.toolStripMenuItem50.Image = global::Animals.Properties.Resources.mixx;
            this.toolStripMenuItem50.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripMenuItem50.Name = "toolStripMenuItem50";
            this.toolStripMenuItem50.Size = new System.Drawing.Size(266, 38);
            this.toolStripMenuItem50.Text = "С максимальным весом";
            this.toolStripMenuItem50.Click += new System.EventHandler(this.SelectWhereMaxWeight_Command);
            // 
            // toolStripMenuItem51
            // 
            this.toolStripMenuItem51.Image = global::Animals.Properties.Resources.name;
            this.toolStripMenuItem51.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripMenuItem51.Name = "toolStripMenuItem51";
            this.toolStripMenuItem51.Size = new System.Drawing.Size(266, 38);
            this.toolStripMenuItem51.Text = "С фамилией владельца";
            this.toolStripMenuItem51.Click += new System.EventHandler(this.SelectWhereOwner_Command);
            // 
            // MniHelp
            // 
            this.MniHelp.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.MniHelp.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniHelpAbout});
            this.MniHelp.Name = "MniHelp";
            this.MniHelp.Size = new System.Drawing.Size(82, 25);
            this.MniHelp.Text = "Справка";
            // 
            // MniHelpAbout
            // 
            this.MniHelpAbout.Image = global::Animals.Properties.Resources.help;
            this.MniHelpAbout.Name = "MniHelpAbout";
            this.MniHelpAbout.Size = new System.Drawing.Size(185, 26);
            this.MniHelpAbout.Text = "О программе...";
            this.MniHelpAbout.Click += new System.EventHandler(this.About_Command);
            // 
            // StsMain
            // 
            this.StsMain.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.StsMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.StlFilePath,
            this.StlMain});
            this.StsMain.Location = new System.Drawing.Point(0, 588);
            this.StsMain.Name = "StsMain";
            this.StsMain.Size = new System.Drawing.Size(962, 22);
            this.StsMain.TabIndex = 10;
            this.StsMain.Text = "statusStrip1";
            // 
            // StlMain
            // 
            this.StlMain.Name = "StlMain";
            this.StlMain.Size = new System.Drawing.Size(947, 17);
            this.StlMain.Spring = true;
            this.StlMain.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // OfdMain
            // 
            this.OfdMain.InitialDirectory = ".. \\.. \\";
            // 
            // CmnMain
            // 
            this.CmnMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem9,
            this.toolStripMenuItem8,
            this.toolStripMenuItem5,
            this.toolStripMenuItem10,
            this.toolStripMenuItem11,
            this.toolStripSeparator3,
            this.toolStripMenuItem21,
            this.toolStripMenuItem26,
            this.toolStripMenuItem20,
            this.toolStripMenuItem6,
            this.toolStripMenuItem7});
            this.CmnMain.Name = "CmnMain";
            this.CmnMain.Size = new System.Drawing.Size(164, 198);
            // 
            // toolStripMenuItem10
            // 
            this.toolStripMenuItem10.Name = "toolStripMenuItem10";
            this.toolStripMenuItem10.Size = new System.Drawing.Size(160, 6);
            // 
            // toolStripMenuItem11
            // 
            this.toolStripMenuItem11.Image = global::Animals.Properties.Resources.Create;
            this.toolStripMenuItem11.Name = "toolStripMenuItem11";
            this.toolStripMenuItem11.Size = new System.Drawing.Size(163, 22);
            this.toolStripMenuItem11.Text = "Новые данные";
            this.toolStripMenuItem11.Click += new System.EventHandler(this.Generate_Command);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(160, 6);
            // 
            // toolStripMenuItem21
            // 
            this.toolStripMenuItem21.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem12,
            this.toolStripMenuItem13,
            this.toolStripMenuItem14});
            this.toolStripMenuItem21.Name = "toolStripMenuItem21";
            this.toolStripMenuItem21.Size = new System.Drawing.Size(163, 22);
            this.toolStripMenuItem21.Text = "Сортировка";
            // 
            // toolStripMenuItem26
            // 
            this.toolStripMenuItem26.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem15,
            this.toolStripMenuItem16});
            this.toolStripMenuItem26.Name = "toolStripMenuItem26";
            this.toolStripMenuItem26.Size = new System.Drawing.Size(163, 22);
            this.toolStripMenuItem26.Text = "Выборка";
            // 
            // toolStripMenuItem20
            // 
            this.toolStripMenuItem20.Name = "toolStripMenuItem20";
            this.toolStripMenuItem20.Size = new System.Drawing.Size(160, 6);
            // 
            // toolStripMenuItem6
            // 
            this.toolStripMenuItem6.Image = global::Animals.Properties.Resources.help;
            this.toolStripMenuItem6.Name = "toolStripMenuItem6";
            this.toolStripMenuItem6.Size = new System.Drawing.Size(163, 22);
            this.toolStripMenuItem6.Text = "О программе...";
            this.toolStripMenuItem6.Click += new System.EventHandler(this.About_Command);
            // 
            // toolStripMenuItem7
            // 
            this.toolStripMenuItem7.Image = global::Animals.Properties.Resources.exit;
            this.toolStripMenuItem7.Name = "toolStripMenuItem7";
            this.toolStripMenuItem7.Size = new System.Drawing.Size(163, 22);
            this.toolStripMenuItem7.Text = "Выход";
            this.toolStripMenuItem7.Click += new System.EventHandler(this.Exit_Command);
            // 
            // NtiMain
            // 
            this.NtiMain.ContextMenuStrip = this.CmnTray;
            this.NtiMain.Icon = ((System.Drawing.Icon)(resources.GetObject("NtiMain.Icon")));
            this.NtiMain.Text = "Приложение свернуто в трей";
            // 
            // CmnTray
            // 
            this.CmnTray.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem3,
            this.toolStripMenuItem4,
            this.toolStripMenuItem2,
            this.вToolStripMenuItem});
            this.CmnTray.Name = "contextMenuStrip1";
            this.CmnTray.Size = new System.Drawing.Size(192, 76);
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.Image = global::Animals.Properties.Resources.FromTray;
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(191, 22);
            this.toolStripMenuItem3.Text = "Восстановить из трея";
            this.toolStripMenuItem3.Click += new System.EventHandler(this.FromTray_Command);
            // 
            // toolStripMenuItem4
            // 
            this.toolStripMenuItem4.Name = "toolStripMenuItem4";
            this.toolStripMenuItem4.Size = new System.Drawing.Size(188, 6);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Image = global::Animals.Properties.Resources.help;
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(191, 22);
            this.toolStripMenuItem2.Text = "О программе...";
            this.toolStripMenuItem2.Click += new System.EventHandler(this.About_Command);
            // 
            // вToolStripMenuItem
            // 
            this.вToolStripMenuItem.Image = global::Animals.Properties.Resources.exit;
            this.вToolStripMenuItem.Name = "вToolStripMenuItem";
            this.вToolStripMenuItem.Size = new System.Drawing.Size(191, 22);
            this.вToolStripMenuItem.Text = "Выход";
            this.вToolStripMenuItem.Click += new System.EventHandler(this.Exit_Command);
            // 
            // TbcMain
            // 
            this.TbcMain.Controls.Add(this.TbpGeneral);
            this.TbcMain.Controls.Add(this.TbpOrdered);
            this.TbcMain.Controls.Add(this.TbpSelected);
            this.TbcMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TbcMain.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TbcMain.Location = new System.Drawing.Point(0, 68);
            this.TbcMain.Name = "TbcMain";
            this.TbcMain.SelectedIndex = 0;
            this.TbcMain.Size = new System.Drawing.Size(962, 520);
            this.TbcMain.TabIndex = 17;
            this.TbcMain.SelectedIndexChanged += new System.EventHandler(this.TbcMain_SelectedIndexChanged);
            this.TbcMain.KeyDown += new System.Windows.Forms.KeyEventHandler(this.TbcMain_KeyDown);
            // 
            // TbpGeneral
            // 
            this.TbpGeneral.BackColor = System.Drawing.Color.WhiteSmoke;
            this.TbpGeneral.Controls.Add(this.LblHeaderGeneral);
            this.TbpGeneral.Controls.Add(this.LsvAnimals);
            this.TbpGeneral.ImageIndex = 0;
            this.TbpGeneral.Location = new System.Drawing.Point(4, 29);
            this.TbpGeneral.Name = "TbpGeneral";
            this.TbpGeneral.Padding = new System.Windows.Forms.Padding(3);
            this.TbpGeneral.Size = new System.Drawing.Size(954, 487);
            this.TbpGeneral.TabIndex = 0;
            this.TbpGeneral.Text = "Общие сведения";
            // 
            // LblHeaderGeneral
            // 
            this.LblHeaderGeneral.Font = new System.Drawing.Font("Consolas", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblHeaderGeneral.Location = new System.Drawing.Point(6, 3);
            this.LblHeaderGeneral.Name = "LblHeaderGeneral";
            this.LblHeaderGeneral.Size = new System.Drawing.Size(744, 27);
            this.LblHeaderGeneral.TabIndex = 5;
            this.LblHeaderGeneral.Text = "Коллекция животных";
            // 
            // LsvAnimals
            // 
            this.LsvAnimals.AllowDrop = true;
            this.LsvAnimals.BackColor = System.Drawing.Color.Lavender;
            this.LsvAnimals.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.ClhPhoto1,
            this.ClhType1,
            this.ClhPetName1,
            this.ClhWeight1,
            this.ClhAge1,
            this.ClhColor1,
            this.ClhOwner1});
            this.LsvAnimals.ContextMenuStrip = this.contextMenuStrip1;
            this.LsvAnimals.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LsvAnimals.FullRowSelect = true;
            this.LsvAnimals.GridLines = true;
            this.LsvAnimals.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
            this.LsvAnimals.HideSelection = false;
            this.LsvAnimals.LargeImageList = this.ImlAnimals;
            this.LsvAnimals.Location = new System.Drawing.Point(13, 44);
            this.LsvAnimals.MultiSelect = false;
            this.LsvAnimals.Name = "LsvAnimals";
            this.LsvAnimals.Size = new System.Drawing.Size(929, 406);
            this.LsvAnimals.SmallImageList = this.ImlAnimals;
            this.LsvAnimals.TabIndex = 15;
            this.LsvAnimals.UseCompatibleStateImageBehavior = false;
            this.LsvAnimals.View = System.Windows.Forms.View.Details;
            this.LsvAnimals.DragDrop += new System.Windows.Forms.DragEventHandler(this.LsvAnimals_DragDrop);
            this.LsvAnimals.DragEnter += new System.Windows.Forms.DragEventHandler(this.LsvAnimals_DragEnter);
            // 
            // ClhPhoto1
            // 
            this.ClhPhoto1.Text = "Фото";
            // 
            // ClhType1
            // 
            this.ClhType1.Text = "Вид животного";
            this.ClhType1.Width = 120;
            // 
            // ClhPetName1
            // 
            this.ClhPetName1.Text = "Кличка животного";
            this.ClhPetName1.Width = 150;
            // 
            // ClhWeight1
            // 
            this.ClhWeight1.Text = "Вес животного, кг.";
            this.ClhWeight1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.ClhWeight1.Width = 145;
            // 
            // ClhAge1
            // 
            this.ClhAge1.Text = "Возраст животного";
            this.ClhAge1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.ClhAge1.Width = 150;
            // 
            // ClhColor1
            // 
            this.ClhColor1.Text = "Цвет животного";
            this.ClhColor1.Width = 125;
            // 
            // ClhOwner1
            // 
            this.ClhOwner1.Text = "Владелец";
            this.ClhOwner1.Width = 150;
            // 
            // TbpOrdered
            // 
            this.TbpOrdered.BackColor = System.Drawing.Color.WhiteSmoke;
            this.TbpOrdered.Controls.Add(this.LsvOrderedAnimals);
            this.TbpOrdered.Controls.Add(this.LblHeaderOrdered);
            this.TbpOrdered.ImageIndex = 1;
            this.TbpOrdered.Location = new System.Drawing.Point(4, 29);
            this.TbpOrdered.Name = "TbpOrdered";
            this.TbpOrdered.Padding = new System.Windows.Forms.Padding(3);
            this.TbpOrdered.Size = new System.Drawing.Size(954, 487);
            this.TbpOrdered.TabIndex = 1;
            this.TbpOrdered.Text = "Отсортированные сведения";
            // 
            // LsvOrderedAnimals
            // 
            this.LsvOrderedAnimals.AllowDrop = true;
            this.LsvOrderedAnimals.BackColor = System.Drawing.Color.Lavender;
            this.LsvOrderedAnimals.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3,
            this.columnHeader4,
            this.columnHeader9,
            this.columnHeader10,
            this.columnHeader11});
            this.LsvOrderedAnimals.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LsvOrderedAnimals.FullRowSelect = true;
            this.LsvOrderedAnimals.GridLines = true;
            this.LsvOrderedAnimals.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
            this.LsvOrderedAnimals.HideSelection = false;
            this.LsvOrderedAnimals.LargeImageList = this.ImlAnimals;
            this.LsvOrderedAnimals.Location = new System.Drawing.Point(13, 44);
            this.LsvOrderedAnimals.MultiSelect = false;
            this.LsvOrderedAnimals.Name = "LsvOrderedAnimals";
            this.LsvOrderedAnimals.Size = new System.Drawing.Size(929, 406);
            this.LsvOrderedAnimals.SmallImageList = this.ImlAnimals;
            this.LsvOrderedAnimals.TabIndex = 16;
            this.LsvOrderedAnimals.UseCompatibleStateImageBehavior = false;
            this.LsvOrderedAnimals.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Фото";
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Вид животного";
            this.columnHeader2.Width = 120;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Кличка животного";
            this.columnHeader3.Width = 150;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "Вес животного, кг.";
            this.columnHeader4.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.columnHeader4.Width = 145;
            // 
            // columnHeader9
            // 
            this.columnHeader9.Text = "Возраст животного";
            this.columnHeader9.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.columnHeader9.Width = 150;
            // 
            // columnHeader10
            // 
            this.columnHeader10.Text = "Цвет животного";
            this.columnHeader10.Width = 125;
            // 
            // columnHeader11
            // 
            this.columnHeader11.Text = "Владелец";
            this.columnHeader11.Width = 150;
            // 
            // LblHeaderOrdered
            // 
            this.LblHeaderOrdered.Font = new System.Drawing.Font("Consolas", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblHeaderOrdered.Location = new System.Drawing.Point(6, 3);
            this.LblHeaderOrdered.Name = "LblHeaderOrdered";
            this.LblHeaderOrdered.Size = new System.Drawing.Size(744, 68);
            this.LblHeaderOrdered.TabIndex = 7;
            this.LblHeaderOrdered.Text = "Коллекция животных";
            // 
            // TbpSelected
            // 
            this.TbpSelected.BackColor = System.Drawing.Color.WhiteSmoke;
            this.TbpSelected.Controls.Add(this.TbxOwner);
            this.TbpSelected.Controls.Add(this.LblOwner);
            this.TbpSelected.Controls.Add(this.LsvSelectedAnimals);
            this.TbpSelected.Controls.Add(this.LblHeaderSelected);
            this.TbpSelected.ImageIndex = 2;
            this.TbpSelected.Location = new System.Drawing.Point(4, 29);
            this.TbpSelected.Name = "TbpSelected";
            this.TbpSelected.Size = new System.Drawing.Size(954, 487);
            this.TbpSelected.TabIndex = 2;
            this.TbpSelected.Text = "Выборка данных";
            // 
            // TbxOwner
            // 
            this.TbxOwner.Location = new System.Drawing.Point(156, 27);
            this.TbxOwner.Name = "TbxOwner";
            this.TbxOwner.Size = new System.Drawing.Size(284, 27);
            this.TbxOwner.TabIndex = 17;
            this.TbxOwner.Visible = false;
            this.TbxOwner.TextChanged += new System.EventHandler(this.TbxOwner_TextChanged);
            // 
            // LblOwner
            // 
            this.LblOwner.Font = new System.Drawing.Font("Consolas", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblOwner.Location = new System.Drawing.Point(9, 28);
            this.LblOwner.Name = "LblOwner";
            this.LblOwner.Size = new System.Drawing.Size(147, 28);
            this.LblOwner.TabIndex = 18;
            this.LblOwner.Text = "Ввод подстроки:\r\n";
            this.LblOwner.Visible = false;
            // 
            // LsvSelectedAnimals
            // 
            this.LsvSelectedAnimals.AllowDrop = true;
            this.LsvSelectedAnimals.BackColor = System.Drawing.Color.Lavender;
            this.LsvSelectedAnimals.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader5,
            this.columnHeader6,
            this.columnHeader7,
            this.columnHeader8,
            this.columnHeader12,
            this.columnHeader13,
            this.columnHeader14});
            this.LsvSelectedAnimals.ContextMenuStrip = this.CmnMain;
            this.LsvSelectedAnimals.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LsvSelectedAnimals.FullRowSelect = true;
            this.LsvSelectedAnimals.GridLines = true;
            this.LsvSelectedAnimals.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
            this.LsvSelectedAnimals.HideSelection = false;
            this.LsvSelectedAnimals.LargeImageList = this.ImlAnimals;
            this.LsvSelectedAnimals.Location = new System.Drawing.Point(13, 62);
            this.LsvSelectedAnimals.MultiSelect = false;
            this.LsvSelectedAnimals.Name = "LsvSelectedAnimals";
            this.LsvSelectedAnimals.Size = new System.Drawing.Size(929, 406);
            this.LsvSelectedAnimals.SmallImageList = this.ImlAnimals;
            this.LsvSelectedAnimals.TabIndex = 16;
            this.LsvSelectedAnimals.UseCompatibleStateImageBehavior = false;
            this.LsvSelectedAnimals.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader5
            // 
            this.columnHeader5.Text = "Фото";
            // 
            // columnHeader6
            // 
            this.columnHeader6.Text = "Вид животного";
            this.columnHeader6.Width = 120;
            // 
            // columnHeader7
            // 
            this.columnHeader7.Text = "Кличка животного";
            this.columnHeader7.Width = 150;
            // 
            // columnHeader8
            // 
            this.columnHeader8.Text = "Вес животного, кг.";
            this.columnHeader8.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.columnHeader8.Width = 145;
            // 
            // columnHeader12
            // 
            this.columnHeader12.Text = "Возраст животного";
            this.columnHeader12.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.columnHeader12.Width = 150;
            // 
            // columnHeader13
            // 
            this.columnHeader13.Text = "Цвет животного";
            this.columnHeader13.Width = 125;
            // 
            // columnHeader14
            // 
            this.columnHeader14.Text = "Владелец";
            this.columnHeader14.Width = 150;
            // 
            // LblHeaderSelected
            // 
            this.LblHeaderSelected.Font = new System.Drawing.Font("Consolas", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblHeaderSelected.Location = new System.Drawing.Point(6, 3);
            this.LblHeaderSelected.Name = "LblHeaderSelected";
            this.LblHeaderSelected.Size = new System.Drawing.Size(940, 59);
            this.LblHeaderSelected.TabIndex = 11;
            this.LblHeaderSelected.Text = "Коллекция животных";
            // 
            // StlFilePath
            // 
            this.StlFilePath.Name = "StlFilePath";
            this.StlFilePath.Size = new System.Drawing.Size(0, 17);
            // 
            // toolStripMenuItem12
            // 
            this.toolStripMenuItem12.Image = global::Animals.Properties.Resources.sort_number1;
            this.toolStripMenuItem12.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripMenuItem12.Name = "toolStripMenuItem12";
            this.toolStripMenuItem12.Size = new System.Drawing.Size(235, 38);
            this.toolStripMenuItem12.Text = "По возрасту";
            this.toolStripMenuItem12.Click += new System.EventHandler(this.OrderByAge_Command);
            // 
            // toolStripMenuItem13
            // 
            this.toolStripMenuItem13.Image = global::Animals.Properties.Resources.sort_alphabel_column;
            this.toolStripMenuItem13.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripMenuItem13.Name = "toolStripMenuItem13";
            this.toolStripMenuItem13.Size = new System.Drawing.Size(235, 38);
            this.toolStripMenuItem13.Text = "По виду";
            this.toolStripMenuItem13.Click += new System.EventHandler(this.OrderByType_Command);
            // 
            // toolStripMenuItem14
            // 
            this.toolStripMenuItem14.Image = global::Animals.Properties.Resources.sort_alphabel;
            this.toolStripMenuItem14.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripMenuItem14.Name = "toolStripMenuItem14";
            this.toolStripMenuItem14.Size = new System.Drawing.Size(235, 38);
            this.toolStripMenuItem14.Text = "По фамилиям владельцев";
            this.toolStripMenuItem14.Click += new System.EventHandler(this.OrderByOwner_Command);
            // 
            // toolStripMenuItem15
            // 
            this.toolStripMenuItem15.Image = global::Animals.Properties.Resources.mixx;
            this.toolStripMenuItem15.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripMenuItem15.Name = "toolStripMenuItem15";
            this.toolStripMenuItem15.Size = new System.Drawing.Size(225, 38);
            this.toolStripMenuItem15.Text = "С максимальным весом";
            // 
            // toolStripMenuItem16
            // 
            this.toolStripMenuItem16.Image = global::Animals.Properties.Resources.name;
            this.toolStripMenuItem16.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripMenuItem16.Name = "toolStripMenuItem16";
            this.toolStripMenuItem16.Size = new System.Drawing.Size(225, 38);
            this.toolStripMenuItem16.Text = "С фамилией владельца";
            // 
            // toolStripMenuItem5
            // 
            this.toolStripMenuItem5.Image = global::Animals.Properties.Resources.folder_blue;
            this.toolStripMenuItem5.Name = "toolStripMenuItem5";
            this.toolStripMenuItem5.Size = new System.Drawing.Size(163, 22);
            this.toolStripMenuItem5.Text = "Открыть...";
            this.toolStripMenuItem5.Click += new System.EventHandler(this.Open_Command);
            // 
            // toolStripMenuItem8
            // 
            this.toolStripMenuItem8.Name = "toolStripMenuItem8";
            this.toolStripMenuItem8.Size = new System.Drawing.Size(163, 22);
            this.toolStripMenuItem8.Text = "Сохранить";
            this.toolStripMenuItem8.Click += new System.EventHandler(this.Save_Command);
            // 
            // toolStripMenuItem9
            // 
            this.toolStripMenuItem9.Image = global::Animals.Properties.Resources.save_as;
            this.toolStripMenuItem9.Name = "toolStripMenuItem9";
            this.toolStripMenuItem9.Size = new System.Drawing.Size(163, 22);
            this.toolStripMenuItem9.Text = "Сохранить как...";
            this.toolStripMenuItem9.Click += new System.EventHandler(this.SaveAs_Command);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem22,
            this.toolStripSeparator4,
            this.toolStripMenuItem19,
            this.toolStripSeparator8,
            this.toolStripMenuItem18,
            this.toolStripMenuItem17,
            this.toolStripSeparator7,
            this.toolStripMenuItem23,
            this.toolStripMenuItem28,
            this.toolStripSeparator6,
            this.toolStripMenuItem34,
            this.toolStripMenuItem35});
            this.contextMenuStrip1.Name = "CmnMain";
            this.contextMenuStrip1.Size = new System.Drawing.Size(159, 204);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(155, 6);
            // 
            // toolStripMenuItem22
            // 
            this.toolStripMenuItem22.Image = global::Animals.Properties.Resources.Create;
            this.toolStripMenuItem22.Name = "toolStripMenuItem22";
            this.toolStripMenuItem22.Size = new System.Drawing.Size(180, 22);
            this.toolStripMenuItem22.Text = "Новые данные";
            this.toolStripMenuItem22.Click += new System.EventHandler(this.Generate_Command);
            // 
            // toolStripMenuItem23
            // 
            this.toolStripMenuItem23.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem24,
            this.toolStripMenuItem27,
            this.toolStripMenuItem25});
            this.toolStripMenuItem23.Image = global::Animals.Properties.Resources.OrderBy;
            this.toolStripMenuItem23.Name = "toolStripMenuItem23";
            this.toolStripMenuItem23.Size = new System.Drawing.Size(180, 22);
            this.toolStripMenuItem23.Text = "Сортировка";
            // 
            // toolStripMenuItem24
            // 
            this.toolStripMenuItem24.Image = global::Animals.Properties.Resources.sort_number1;
            this.toolStripMenuItem24.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripMenuItem24.Name = "toolStripMenuItem24";
            this.toolStripMenuItem24.Size = new System.Drawing.Size(235, 38);
            this.toolStripMenuItem24.Text = "По возрасту";
            this.toolStripMenuItem24.Click += new System.EventHandler(this.OrderByAge_Command);
            // 
            // toolStripMenuItem25
            // 
            this.toolStripMenuItem25.Image = global::Animals.Properties.Resources.sort_alphabel_column;
            this.toolStripMenuItem25.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripMenuItem25.Name = "toolStripMenuItem25";
            this.toolStripMenuItem25.Size = new System.Drawing.Size(235, 38);
            this.toolStripMenuItem25.Text = "По виду";
            this.toolStripMenuItem25.Click += new System.EventHandler(this.OrderByType_Command);
            // 
            // toolStripMenuItem27
            // 
            this.toolStripMenuItem27.Image = global::Animals.Properties.Resources.sort_alphabel;
            this.toolStripMenuItem27.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripMenuItem27.Name = "toolStripMenuItem27";
            this.toolStripMenuItem27.Size = new System.Drawing.Size(235, 38);
            this.toolStripMenuItem27.Text = "По фамилиям владельцев";
            this.toolStripMenuItem27.Click += new System.EventHandler(this.OrderByOwner_Command);
            // 
            // toolStripMenuItem28
            // 
            this.toolStripMenuItem28.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem31,
            this.toolStripMenuItem32});
            this.toolStripMenuItem28.Image = global::Animals.Properties.Resources.Select;
            this.toolStripMenuItem28.Name = "toolStripMenuItem28";
            this.toolStripMenuItem28.Size = new System.Drawing.Size(180, 22);
            this.toolStripMenuItem28.Text = "Выборка";
            // 
            // toolStripMenuItem31
            // 
            this.toolStripMenuItem31.Image = global::Animals.Properties.Resources.mixx;
            this.toolStripMenuItem31.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripMenuItem31.Name = "toolStripMenuItem31";
            this.toolStripMenuItem31.Size = new System.Drawing.Size(225, 38);
            this.toolStripMenuItem31.Text = "С максимальным весом";
            this.toolStripMenuItem31.Click += new System.EventHandler(this.SelectWhereMaxWeight_Command);
            // 
            // toolStripMenuItem32
            // 
            this.toolStripMenuItem32.Image = global::Animals.Properties.Resources.name;
            this.toolStripMenuItem32.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripMenuItem32.Name = "toolStripMenuItem32";
            this.toolStripMenuItem32.Size = new System.Drawing.Size(225, 38);
            this.toolStripMenuItem32.Text = "С фамилией владельца";
            this.toolStripMenuItem32.Click += new System.EventHandler(this.SelectWhereOwner_Command);
            // 
            // toolStripSeparator6
            // 
            this.toolStripSeparator6.Name = "toolStripSeparator6";
            this.toolStripSeparator6.Size = new System.Drawing.Size(155, 6);
            // 
            // toolStripMenuItem34
            // 
            this.toolStripMenuItem34.Image = global::Animals.Properties.Resources.help;
            this.toolStripMenuItem34.Name = "toolStripMenuItem34";
            this.toolStripMenuItem34.Size = new System.Drawing.Size(180, 22);
            this.toolStripMenuItem34.Text = "О программе...";
            this.toolStripMenuItem34.Click += new System.EventHandler(this.About_Command);
            // 
            // toolStripMenuItem35
            // 
            this.toolStripMenuItem35.Image = global::Animals.Properties.Resources.exit;
            this.toolStripMenuItem35.Name = "toolStripMenuItem35";
            this.toolStripMenuItem35.Size = new System.Drawing.Size(180, 22);
            this.toolStripMenuItem35.Text = "Выход";
            this.toolStripMenuItem35.Click += new System.EventHandler(this.Exit_Command);
            // 
            // toolStripSeparator7
            // 
            this.toolStripSeparator7.Name = "toolStripSeparator7";
            this.toolStripSeparator7.Size = new System.Drawing.Size(155, 6);
            // 
            // toolStripMenuItem17
            // 
            this.toolStripMenuItem17.Image = global::Animals.Properties.Resources.Add;
            this.toolStripMenuItem17.Name = "toolStripMenuItem17";
            this.toolStripMenuItem17.Size = new System.Drawing.Size(158, 22);
            this.toolStripMenuItem17.Text = "Добавить...";
            this.toolStripMenuItem17.Click += new System.EventHandler(this.AddAnimal_Command);
            // 
            // toolStripMenuItem18
            // 
            this.toolStripMenuItem18.Image = global::Animals.Properties.Resources.edit;
            this.toolStripMenuItem18.Name = "toolStripMenuItem18";
            this.toolStripMenuItem18.Size = new System.Drawing.Size(158, 22);
            this.toolStripMenuItem18.Text = "Изменить...";
            this.toolStripMenuItem18.Click += new System.EventHandler(this.EditAnimal_Command);
            // 
            // toolStripSeparator8
            // 
            this.toolStripSeparator8.Name = "toolStripSeparator8";
            this.toolStripSeparator8.Size = new System.Drawing.Size(155, 6);
            // 
            // toolStripMenuItem19
            // 
            this.toolStripMenuItem19.Image = global::Animals.Properties.Resources.remove;
            this.toolStripMenuItem19.Name = "toolStripMenuItem19";
            this.toolStripMenuItem19.Size = new System.Drawing.Size(158, 22);
            this.toolStripMenuItem19.Text = "Удалить";
            this.toolStripMenuItem19.Click += new System.EventHandler(this.RemoveAt_Command);
            // 
            // MainForm
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.Gainsboro;
            this.ClientSize = new System.Drawing.Size(962, 610);
            this.ContextMenuStrip = this.CmnMain;
            this.Controls.Add(this.TbcMain);
            this.Controls.Add(this.StsMain);
            this.Controls.Add(this.TbsMain);
            this.Controls.Add(this.MnsMain);
            this.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Задание на 06.12.2021";
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.TbsMain.ResumeLayout(false);
            this.TbsMain.PerformLayout();
            this.MnsMain.ResumeLayout(false);
            this.MnsMain.PerformLayout();
            this.StsMain.ResumeLayout(false);
            this.StsMain.PerformLayout();
            this.CmnMain.ResumeLayout(false);
            this.CmnTray.ResumeLayout(false);
            this.TbcMain.ResumeLayout(false);
            this.TbpGeneral.ResumeLayout(false);
            this.TbpOrdered.ResumeLayout(false);
            this.TbpSelected.ResumeLayout(false);
            this.TbpSelected.PerformLayout();
            this.contextMenuStrip1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.ToolStrip TbsMain;
        private System.Windows.Forms.ToolStripButton TsbFileOpen;
        private System.Windows.Forms.ToolStripButton TsbFileSave;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripButton TsbNewFlat;
        private System.Windows.Forms.ToolStripSeparator TsbSeparator1;
        private System.Windows.Forms.ToolStripButton TsbAddAppliance;
        private System.Windows.Forms.ToolStripButton TsbEditAppliance;
        private System.Windows.Forms.ToolStripButton TsbRemoveAppliance;
        private System.Windows.Forms.ToolStripSeparator TsbSeparator2;
        private System.Windows.Forms.ToolStripDropDownButton TsdOrderBy;
        private System.Windows.Forms.ToolStripMenuItem DmiOrderByAge;
        private System.Windows.Forms.ToolStripMenuItem DmiOrderByType;
        private System.Windows.Forms.ToolStripMenuItem DmiOrderByOwner;
        private System.Windows.Forms.ToolStripSeparator TsbSeparator3;
        private System.Windows.Forms.ToolStripButton TsbToTray;
        private System.Windows.Forms.ToolStripButton TsbAbout;
        private System.Windows.Forms.ToolStripButton TsbExit;
        private System.Windows.Forms.MenuStrip MnsMain;
        private System.Windows.Forms.ToolStripMenuItem MniFile;
        private System.Windows.Forms.ToolStripMenuItem MniFileOpen;
        private System.Windows.Forms.ToolStripMenuItem MniFileSave;
        private System.Windows.Forms.ToolStripMenuItem MniFileSaveAs;
        private System.Windows.Forms.ToolStripSeparator MniFileSep1;
        private System.Windows.Forms.ToolStripMenuItem MniFileExit;
        private System.Windows.Forms.ToolStripMenuItem MniOrderBy;
        private System.Windows.Forms.ToolStripMenuItem MniHelp;
        private System.Windows.Forms.ToolStripMenuItem MniHelpAbout;
        private System.Windows.Forms.ToolStripDropDownButton TsdSelectWhere;
        private System.Windows.Forms.ToolStripMenuItem TsdSelectWhereMaxWeight;
        private System.Windows.Forms.ToolStripMenuItem TsdSelectWhereState;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripMenuItem MniSelectWhere;
        private System.Windows.Forms.StatusStrip StsMain;
        private System.Windows.Forms.ToolStripStatusLabel StlMain;
        private System.Windows.Forms.OpenFileDialog OfdMain;
        private System.Windows.Forms.ImageList ImlAnimals;
        private System.Windows.Forms.SaveFileDialog SfdMain;
        private System.Windows.Forms.NotifyIcon NtiMain;
        private System.Windows.Forms.ContextMenuStrip CmnTray;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem3;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem4;
        private System.Windows.Forms.ToolStripMenuItem вToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private System.Windows.Forms.ContextMenuStrip CmnMain;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem10;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem11;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem6;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem7;
        private System.Windows.Forms.ToolStripMenuItem MniAnimals;
        private System.Windows.Forms.ToolStripMenuItem MniAnimalsAdd;
        private System.Windows.Forms.ToolStripMenuItem MniAnimalsEdit;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem MniAnimalsRemoveAt;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem21;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem26;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem20;
        private System.Windows.Forms.TabControl TbcMain;
        private System.Windows.Forms.TabPage TbpGeneral;
        private System.Windows.Forms.Label LblHeaderGeneral;
        private System.Windows.Forms.ListView LsvAnimals;
        private System.Windows.Forms.ColumnHeader ClhPhoto1;
        private System.Windows.Forms.ColumnHeader ClhType1;
        private System.Windows.Forms.ColumnHeader ClhPetName1;
        private System.Windows.Forms.ColumnHeader ClhWeight1;
        private System.Windows.Forms.TabPage TbpOrdered;
        private System.Windows.Forms.Label LblHeaderOrdered;
        private System.Windows.Forms.TabPage TbpSelected;
        private System.Windows.Forms.Label LblHeaderSelected;
        private System.Windows.Forms.ColumnHeader ClhAge1;
        private System.Windows.Forms.ColumnHeader ClhColor1;
        private System.Windows.Forms.ColumnHeader ClhOwner1;
        private System.Windows.Forms.ListView LsvOrderedAnimals;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.ColumnHeader columnHeader9;
        private System.Windows.Forms.ColumnHeader columnHeader10;
        private System.Windows.Forms.ColumnHeader columnHeader11;
        private System.Windows.Forms.ListView LsvSelectedAnimals;
        private System.Windows.Forms.ColumnHeader columnHeader5;
        private System.Windows.Forms.ColumnHeader columnHeader6;
        private System.Windows.Forms.ColumnHeader columnHeader7;
        private System.Windows.Forms.ColumnHeader columnHeader8;
        private System.Windows.Forms.ColumnHeader columnHeader12;
        private System.Windows.Forms.ColumnHeader columnHeader13;
        private System.Windows.Forms.ColumnHeader columnHeader14;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem29;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem30;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem33;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem50;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem51;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem52;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem53;
        private System.Windows.Forms.TextBox TbxOwner;
        private System.Windows.Forms.Label LblOwner;
        private System.Windows.Forms.ToolStripStatusLabel StlFilePath;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem9;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem8;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem5;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem12;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem13;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem14;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem15;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem16;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem22;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem19;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator8;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem18;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem17;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator7;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem23;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem24;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem27;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem25;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem28;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem31;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem32;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator6;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem34;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem35;
    }
}

