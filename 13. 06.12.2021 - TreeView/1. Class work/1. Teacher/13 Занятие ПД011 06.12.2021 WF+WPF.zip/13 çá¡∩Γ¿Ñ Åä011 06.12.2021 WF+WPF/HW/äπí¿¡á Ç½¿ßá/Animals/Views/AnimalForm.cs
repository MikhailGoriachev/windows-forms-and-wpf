﻿using Animals.Models;
using Animals.Helpers;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Animals.Views
{
    public partial class AnimalForm : Form
    {
        private Animal _animal;
        public Animal Animal {
            get => _animal;
            set {
                _animal = value;

                // запись в элементы управления
                TbxPetName.Text = _animal.PetName;
                TbxOwner.Text = _animal.Owner;
                CbxType.Text = _animal.Type;
                TbxColor.Text = _animal.Color;
                NudAge.Value = _animal.Age;
                NudWeight.Value = (Decimal)_animal.Weight;

                TbxPetName.Tag = ErpName;
            } // set
        } // Appliance

        public AnimalForm() : this("Добавление записи", "Добавить") { }
        public AnimalForm(string title, string btnText) {
            InitializeComponent();
            foreach (var item in Utils.AnimalsData)
                CbxType.Items.Add(item.type);
            CbxType.SelectedIndex = 0;
            _animal = new Animal();
            Text = title;
            BtnOk.Text = btnText;

            TbxColor.Tag = ErpColor;
            TbxOwner.Tag = ErpName;
            TbxPetName.Tag = ErpPetName;
        } // ApplianceForm

        private void BtnOk_Click(object sender, EventArgs e) {
            _animal.Age = (int)NudAge.Value;
            _animal.Weight = (double)NudWeight.Value;
            _animal.Owner = TbxOwner.Text;
            _animal.PetName = TbxPetName.Text;
            int id = -1;
            foreach (var item in Utils.AnimalsData)
                if (item.type == CbxType.Text) id = item.ImageId;

            _animal.ImageId = id;
            _animal.Color = TbxColor.Text;
            _animal.Type = CbxType.Text;
        } // BtnOk_Click

        private void BtnCancel_Click(object sender, EventArgs e) => Close();

        private void Txb_Validated(object sender, EventArgs e) {
            TextBox tb = sender as TextBox;
            ErrorProvider errorProvider = tb.Tag as ErrorProvider;
            if (String.IsNullOrEmpty(tb.Text)) {
                errorProvider.SetError(tb, "Некорректный ввод!");
                BtnOk.Enabled = false;
            } // if
        } // Txb_Validated

        private void Tbx_TextChanged(object sender, EventArgs e) {
            TextBox tb = sender as TextBox;
            ErrorProvider errorProvider = tb.Tag as ErrorProvider;
            errorProvider.SetError(tb, "");

            if(!String.IsNullOrEmpty(TbxPetName.Text) && !String.IsNullOrEmpty(TbxOwner.Text) && !String.IsNullOrEmpty(TbxColor.Text))
                BtnOk.Enabled = true;
        } // Tbx_TextChanged

        private void Txb_Validated(object sender, CancelEventArgs e)
        {

        }
    }
}
