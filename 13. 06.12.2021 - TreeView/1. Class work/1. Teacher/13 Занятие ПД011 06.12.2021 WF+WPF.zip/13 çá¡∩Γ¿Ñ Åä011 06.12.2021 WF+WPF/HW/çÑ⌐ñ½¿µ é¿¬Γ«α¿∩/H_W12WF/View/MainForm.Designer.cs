﻿
namespace H_W12WF
{
    partial class MainForm
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.MnuMain = new System.Windows.Forms.MenuStrip();
            this.MniFile = new System.Windows.Forms.ToolStripMenuItem();
            this.MniFileOpen = new System.Windows.Forms.ToolStripMenuItem();
            this.MniFileSave = new System.Windows.Forms.ToolStripMenuItem();
            this.MniFileSaveAs = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripSeparator();
            this.MniFileExit = new System.Windows.Forms.ToolStripMenuItem();
            this.MniWindow = new System.Windows.Forms.ToolStripMenuItem();
            this.MniToTray = new System.Windows.Forms.ToolStripMenuItem();
            this.MniEdit = new System.Windows.Forms.ToolStripMenuItem();
            this.MniNewCollection = new System.Windows.Forms.ToolStripMenuItem();
            this.MniAddAppliance = new System.Windows.Forms.ToolStripMenuItem();
            this.MniDeleleAppliance = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripSeparator();
            this.MniEditAppliance = new System.Windows.Forms.ToolStripMenuItem();
            this.MniEditApartment = new System.Windows.Forms.ToolStripMenuItem();
            this.MniOrderBy = new System.Windows.Forms.ToolStripMenuItem();
            this.MniOrderByName = new System.Windows.Forms.ToolStripMenuItem();
            this.MniOrderByState = new System.Windows.Forms.ToolStripMenuItem();
            this.MniOrderByPower = new System.Windows.Forms.ToolStripMenuItem();
            this.MniOrderByPrice = new System.Windows.Forms.ToolStripMenuItem();
            this.MniSelectWhere = new System.Windows.Forms.ToolStripMenuItem();
            this.MniSelectWhereName = new System.Windows.Forms.ToolStripMenuItem();
            this.MniSelectWhereState = new System.Windows.Forms.ToolStripMenuItem();
            this.MniTurnOn = new System.Windows.Forms.ToolStripMenuItem();
            this.MniTurnOnAt = new System.Windows.Forms.ToolStripMenuItem();
            this.MniTurnOnAll = new System.Windows.Forms.ToolStripMenuItem();
            this.MniTurnOff = new System.Windows.Forms.ToolStripMenuItem();
            this.MniTurnOffAt = new System.Windows.Forms.ToolStripMenuItem();
            this.выключитьВсеПриборыToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.MniHelp = new System.Windows.Forms.ToolStripMenuItem();
            this.MniAbout = new System.Windows.Forms.ToolStripMenuItem();
            this.TsbMain = new System.Windows.Forms.ToolStrip();
            this.TsbFileOpen = new System.Windows.Forms.ToolStripButton();
            this.TsbFileSave = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.TsbToTray = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.TsbNewApplication = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.TsbAddApplication = new System.Windows.Forms.ToolStripButton();
            this.TsbRemoveAt = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.TsbEditApplitions = new System.Windows.Forms.ToolStripButton();
            this.TsbEditApartment = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator6 = new System.Windows.Forms.ToolStripSeparator();
            this.TsdOrderBy = new System.Windows.Forms.ToolStripDropDownButton();
            this.TsdOrderByName = new System.Windows.Forms.ToolStripMenuItem();
            this.TsdOrderByState = new System.Windows.Forms.ToolStripMenuItem();
            this.TsdOrderByPower = new System.Windows.Forms.ToolStripMenuItem();
            this.TsdOrderByPrice = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.TsbSelectName = new System.Windows.Forms.ToolStripButton();
            this.TsbSelectState = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator7 = new System.Windows.Forms.ToolStripSeparator();
            this.TsbTurnOnAt = new System.Windows.Forms.ToolStripButton();
            this.TsbTurnOffAt = new System.Windows.Forms.ToolStripButton();
            this.TsbTurnOnAll = new System.Windows.Forms.ToolStripButton();
            this.TsbTurnOffAll = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator8 = new System.Windows.Forms.ToolStripSeparator();
            this.TsbAboutProgram = new System.Windows.Forms.ToolStripButton();
            this.StsMain = new System.Windows.Forms.StatusStrip();
            this.StlMain = new System.Windows.Forms.ToolStripStatusLabel();
            this.TbcMain = new System.Windows.Forms.TabControl();
            this.TbpGeneral = new System.Windows.Forms.TabPage();
            this.CmnApplication = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.CmnNewCollection = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem4 = new System.Windows.Forms.ToolStripSeparator();
            this.CmnSortBy = new System.Windows.Forms.ToolStripMenuItem();
            this.CmnSortByName = new System.Windows.Forms.ToolStripMenuItem();
            this.CmnSortByState = new System.Windows.Forms.ToolStripMenuItem();
            this.CmnSortByPower = new System.Windows.Forms.ToolStripMenuItem();
            this.CmnSortByPrice = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem5 = new System.Windows.Forms.ToolStripSeparator();
            this.CmnAddApplication = new System.Windows.Forms.ToolStripMenuItem();
            this.CmnEditApplication = new System.Windows.Forms.ToolStripMenuItem();
            this.CmnEditApartment = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem6 = new System.Windows.Forms.ToolStripSeparator();
            this.CmnSelectedBy = new System.Windows.Forms.ToolStripMenuItem();
            this.CmnSelectedByName = new System.Windows.Forms.ToolStripMenuItem();
            this.CmnSelectedByState = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem7 = new System.Windows.Forms.ToolStripSeparator();
            this.CmnExitApp = new System.Windows.Forms.ToolStripMenuItem();
            this.CmnAbout = new System.Windows.Forms.ToolStripMenuItem();
            this.LblHeaderOrdered = new System.Windows.Forms.Label();
            this.LsvAppliance = new System.Windows.Forms.ListView();
            this.ClhState = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.ClhName = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.ClhPower = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.ClhPrice = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.ImlAppliances = new System.Windows.Forms.ImageList(this.components);
            this.TbpOrdered = new System.Windows.Forms.TabPage();
            this.LblHeaderOrder = new System.Windows.Forms.Label();
            this.TbpSelected = new System.Windows.Forms.TabPage();
            this.LblHeaderSelected = new System.Windows.Forms.Label();
            this.OfdMain = new System.Windows.Forms.OpenFileDialog();
            this.SfdMain = new System.Windows.Forms.SaveFileDialog();
            this.NtiMain = new System.Windows.Forms.NotifyIcon(this.components);
            this.CmnNotify = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.CmiNotifyRestore = new System.Windows.Forms.ToolStripMenuItem();
            this.CmiNotifyAbout = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripSeparator();
            this.CmiNotifyExit = new System.Windows.Forms.ToolStripMenuItem();
            this.CmnMain = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.CmnExit = new System.Windows.Forms.ToolStripMenuItem();
            this.CmnAboutProgram = new System.Windows.Forms.ToolStripMenuItem();
            this.LsvOrdered = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.LsvSelected = new System.Windows.Forms.ListView();
            this.columnHeader5 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader6 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader7 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader8 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.MnuMain.SuspendLayout();
            this.TsbMain.SuspendLayout();
            this.StsMain.SuspendLayout();
            this.TbcMain.SuspendLayout();
            this.TbpGeneral.SuspendLayout();
            this.CmnApplication.SuspendLayout();
            this.TbpOrdered.SuspendLayout();
            this.TbpSelected.SuspendLayout();
            this.CmnNotify.SuspendLayout();
            this.CmnMain.SuspendLayout();
            this.SuspendLayout();
            // 
            // MnuMain
            // 
            this.MnuMain.Font = new System.Drawing.Font("Lucida Console", 12F);
            this.MnuMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniFile,
            this.MniWindow,
            this.MniEdit,
            this.MniOrderBy,
            this.MniSelectWhere,
            this.MniTurnOn,
            this.MniTurnOff,
            this.MniHelp});
            this.MnuMain.Location = new System.Drawing.Point(0, 0);
            this.MnuMain.Name = "MnuMain";
            this.MnuMain.Size = new System.Drawing.Size(984, 24);
            this.MnuMain.TabIndex = 0;
            this.MnuMain.Text = "menuStrip1";
            // 
            // MniFile
            // 
            this.MniFile.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniFileOpen,
            this.MniFileSave,
            this.MniFileSaveAs,
            this.toolStripMenuItem1,
            this.MniFileExit});
            this.MniFile.Name = "MniFile";
            this.MniFile.Size = new System.Drawing.Size(60, 20);
            this.MniFile.Text = "Файл";
            // 
            // MniFileOpen
            // 
            this.MniFileOpen.Image = global::H_W12WF.Properties.Resources.folder_blue;
            this.MniFileOpen.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MniFileOpen.Name = "MniFileOpen";
            this.MniFileOpen.Size = new System.Drawing.Size(242, 38);
            this.MniFileOpen.Text = "Открыть..";
            this.MniFileOpen.Click += new System.EventHandler(this.LoadFile_Command);
            // 
            // MniFileSave
            // 
            this.MniFileSave.Image = global::H_W12WF.Properties.Resources.filein_79740;
            this.MniFileSave.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MniFileSave.Name = "MniFileSave";
            this.MniFileSave.Size = new System.Drawing.Size(242, 38);
            this.MniFileSave.Text = "Сохранить";
            this.MniFileSave.Click += new System.EventHandler(this.SaveAsFile_Command);
            // 
            // MniFileSaveAs
            // 
            this.MniFileSaveAs.Image = global::H_W12WF.Properties.Resources.save_as;
            this.MniFileSaveAs.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MniFileSaveAs.Name = "MniFileSaveAs";
            this.MniFileSaveAs.Size = new System.Drawing.Size(242, 38);
            this.MniFileSaveAs.Text = "Сохранить как..";
            this.MniFileSaveAs.Click += new System.EventHandler(this.SaveAsFile_Command);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(239, 6);
            // 
            // MniFileExit
            // 
            this.MniFileExit.Image = global::H_W12WF.Properties.Resources.выход_28;
            this.MniFileExit.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MniFileExit.Name = "MniFileExit";
            this.MniFileExit.Size = new System.Drawing.Size(242, 38);
            this.MniFileExit.Text = "Выход";
            this.MniFileExit.Click += new System.EventHandler(this.Exit_Command);
            // 
            // MniWindow
            // 
            this.MniWindow.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniToTray});
            this.MniWindow.Name = "MniWindow";
            this.MniWindow.Size = new System.Drawing.Size(60, 20);
            this.MniWindow.Text = "Окно";
            // 
            // MniToTray
            // 
            this.MniToTray.Image = global::H_W12WF.Properties.Resources.свернуть_окно_32;
            this.MniToTray.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MniToTray.Name = "MniToTray";
            this.MniToTray.Size = new System.Drawing.Size(242, 38);
            this.MniToTray.Text = "Свернуть в трей";
            this.MniToTray.Click += new System.EventHandler(this.ToTray_Command);
            // 
            // MniEdit
            // 
            this.MniEdit.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniNewCollection,
            this.MniAddAppliance,
            this.MniDeleleAppliance,
            this.toolStripMenuItem3,
            this.MniEditAppliance,
            this.MniEditApartment});
            this.MniEdit.Name = "MniEdit";
            this.MniEdit.Size = new System.Drawing.Size(80, 20);
            this.MniEdit.Text = "Правка";
            // 
            // MniNewCollection
            // 
            this.MniNewCollection.Image = global::H_W12WF.Properties.Resources._new;
            this.MniNewCollection.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MniNewCollection.Name = "MniNewCollection";
            this.MniNewCollection.Size = new System.Drawing.Size(382, 38);
            this.MniNewCollection.Text = "Новая коллеция";
            this.MniNewCollection.Click += new System.EventHandler(this.NewCollection_Command);
            // 
            // MniAddAppliance
            // 
            this.MniAddAppliance.Image = global::H_W12WF.Properties.Resources.add;
            this.MniAddAppliance.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MniAddAppliance.Name = "MniAddAppliance";
            this.MniAddAppliance.Size = new System.Drawing.Size(382, 38);
            this.MniAddAppliance.Text = "Добавить прибор";
            this.MniAddAppliance.Click += new System.EventHandler(this.AddAppliance_Command);
            // 
            // MniDeleleAppliance
            // 
            this.MniDeleleAppliance.Image = global::H_W12WF.Properties.Resources.delete;
            this.MniDeleleAppliance.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MniDeleleAppliance.Name = "MniDeleleAppliance";
            this.MniDeleleAppliance.Size = new System.Drawing.Size(382, 38);
            this.MniDeleleAppliance.Text = "Удалить прибор";
            this.MniDeleleAppliance.Click += new System.EventHandler(this.RemoveAppliance_Command);
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(379, 6);
            // 
            // MniEditAppliance
            // 
            this.MniEditAppliance.Image = global::H_W12WF.Properties.Resources.edit_button;
            this.MniEditAppliance.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MniEditAppliance.Name = "MniEditAppliance";
            this.MniEditAppliance.Size = new System.Drawing.Size(382, 38);
            this.MniEditAppliance.Text = "Редактировать данные прибора";
            this.MniEditAppliance.Click += new System.EventHandler(this.ApplicationEdit_Command);
            // 
            // MniEditApartment
            // 
            this.MniEditApartment.Image = global::H_W12WF.Properties.Resources.редактировать_свойство_28;
            this.MniEditApartment.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MniEditApartment.Name = "MniEditApartment";
            this.MniEditApartment.Size = new System.Drawing.Size(382, 38);
            this.MniEditApartment.Text = "Редактировать данные квартиры";
            this.MniEditApartment.Click += new System.EventHandler(this.ApartmentEdit_Command);
            // 
            // MniOrderBy
            // 
            this.MniOrderBy.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniOrderByName,
            this.MniOrderByState,
            this.MniOrderByPower,
            this.MniOrderByPrice});
            this.MniOrderBy.Name = "MniOrderBy";
            this.MniOrderBy.Size = new System.Drawing.Size(120, 20);
            this.MniOrderBy.Text = "Сортировка";
            // 
            // MniOrderByName
            // 
            this.MniOrderByName.Image = global::H_W12WF.Properties.Resources.сортировка_по_алфавиту_28;
            this.MniOrderByName.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MniOrderByName.Name = "MniOrderByName";
            this.MniOrderByName.Size = new System.Drawing.Size(212, 38);
            this.MniOrderByName.Text = "По названию";
            this.MniOrderByName.Click += new System.EventHandler(this.OrderByNameApplic_Command);
            // 
            // MniOrderByState
            // 
            this.MniOrderByState.Image = global::H_W12WF.Properties.Resources.выключить_свет_28;
            this.MniOrderByState.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MniOrderByState.Name = "MniOrderByState";
            this.MniOrderByState.Size = new System.Drawing.Size(212, 38);
            this.MniOrderByState.Text = "По состоянию";
            this.MniOrderByState.Click += new System.EventHandler(this.OrderByState_Command);
            // 
            // MniOrderByPower
            // 
            this.MniOrderByPower.Image = global::H_W12WF.Properties.Resources.электроприборы_28;
            this.MniOrderByPower.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MniOrderByPower.Name = "MniOrderByPower";
            this.MniOrderByPower.Size = new System.Drawing.Size(212, 38);
            this.MniOrderByPower.Text = "По мощности";
            this.MniOrderByPower.Click += new System.EventHandler(this.OrderByPower_Command);
            // 
            // MniOrderByPrice
            // 
            this.MniOrderByPrice.Image = global::H_W12WF.Properties.Resources.money;
            this.MniOrderByPrice.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MniOrderByPrice.Name = "MniOrderByPrice";
            this.MniOrderByPrice.Size = new System.Drawing.Size(212, 38);
            this.MniOrderByPrice.Text = "По цене";
            this.MniOrderByPrice.Click += new System.EventHandler(this.OrderByPrice_Command);
            // 
            // MniSelectWhere
            // 
            this.MniSelectWhere.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniSelectWhereName,
            this.MniSelectWhereState});
            this.MniSelectWhere.Name = "MniSelectWhere";
            this.MniSelectWhere.Size = new System.Drawing.Size(90, 20);
            this.MniSelectWhere.Text = "Выборка";
            // 
            // MniSelectWhereName
            // 
            this.MniSelectWhereName.Image = global::H_W12WF.Properties.Resources._486_abc_blocks;
            this.MniSelectWhereName.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MniSelectWhereName.Name = "MniSelectWhereName";
            this.MniSelectWhereName.Size = new System.Drawing.Size(382, 38);
            this.MniSelectWhereName.Text = "Приборы с заданным названием";
            this.MniSelectWhereName.Click += new System.EventHandler(this.SelectApplicationName_Command);
            // 
            // MniSelectWhereState
            // 
            this.MniSelectWhereState.Image = global::H_W12WF.Properties.Resources.включить_свет_28;
            this.MniSelectWhereState.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MniSelectWhereState.Name = "MniSelectWhereState";
            this.MniSelectWhereState.Size = new System.Drawing.Size(382, 38);
            this.MniSelectWhereState.Text = "Приборы с заданным состоянием";
            this.MniSelectWhereState.Click += new System.EventHandler(this.SelectApplicationState_Command);
            // 
            // MniTurnOn
            // 
            this.MniTurnOn.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniTurnOnAt,
            this.MniTurnOnAll});
            this.MniTurnOn.Name = "MniTurnOn";
            this.MniTurnOn.Size = new System.Drawing.Size(110, 20);
            this.MniTurnOn.Text = "Включение";
            // 
            // MniTurnOnAt
            // 
            this.MniTurnOnAt.Image = global::H_W12WF.Properties.Resources.lightbulb;
            this.MniTurnOnAt.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MniTurnOnAt.Name = "MniTurnOnAt";
            this.MniTurnOnAt.Size = new System.Drawing.Size(292, 38);
            this.MniTurnOnAt.Text = "Включить прибор";
            this.MniTurnOnAt.Click += new System.EventHandler(this.TurnOnAt_Command);
            // 
            // MniTurnOnAll
            // 
            this.MniTurnOnAll.Image = global::H_W12WF.Properties.Resources.электчество_28;
            this.MniTurnOnAll.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MniTurnOnAll.Name = "MniTurnOnAll";
            this.MniTurnOnAll.Size = new System.Drawing.Size(292, 38);
            this.MniTurnOnAll.Text = "Включить все приборы";
            this.MniTurnOnAll.Click += new System.EventHandler(this.TurnOnAll_Command);
            // 
            // MniTurnOff
            // 
            this.MniTurnOff.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniTurnOffAt,
            this.выключитьВсеПриборыToolStripMenuItem});
            this.MniTurnOff.Name = "MniTurnOff";
            this.MniTurnOff.Size = new System.Drawing.Size(120, 20);
            this.MniTurnOff.Text = "Выключение";
            // 
            // MniTurnOffAt
            // 
            this.MniTurnOffAt.Image = global::H_W12WF.Properties.Resources.lightbulb_off;
            this.MniTurnOffAt.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MniTurnOffAt.Name = "MniTurnOffAt";
            this.MniTurnOffAt.Size = new System.Drawing.Size(302, 38);
            this.MniTurnOffAt.Text = "Выключить прибор";
            this.MniTurnOffAt.Click += new System.EventHandler(this.TurnOffAt_Command);
            // 
            // выключитьВсеПриборыToolStripMenuItem
            // 
            this.выключитьВсеПриборыToolStripMenuItem.Image = global::H_W12WF.Properties.Resources.электричество_28;
            this.выключитьВсеПриборыToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.выключитьВсеПриборыToolStripMenuItem.Name = "выключитьВсеПриборыToolStripMenuItem";
            this.выключитьВсеПриборыToolStripMenuItem.Size = new System.Drawing.Size(302, 38);
            this.выключитьВсеПриборыToolStripMenuItem.Text = "Выключить все приборы";
            this.выключитьВсеПриборыToolStripMenuItem.Click += new System.EventHandler(this.TurnOffAll_Command);
            // 
            // MniHelp
            // 
            this.MniHelp.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.MniHelp.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MniAbout});
            this.MniHelp.Name = "MniHelp";
            this.MniHelp.Size = new System.Drawing.Size(90, 20);
            this.MniHelp.Text = "Справка";
            // 
            // MniAbout
            // 
            this.MniAbout.Image = global::H_W12WF.Properties.Resources.о_программе_28;
            this.MniAbout.Name = "MniAbout";
            this.MniAbout.Size = new System.Drawing.Size(206, 22);
            this.MniAbout.Text = "О программе..";
            this.MniAbout.Click += new System.EventHandler(this.About_Command);
            // 
            // TsbMain
            // 
            this.TsbMain.Font = new System.Drawing.Font("Lucida Console", 12F);
            this.TsbMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.TsbFileOpen,
            this.TsbFileSave,
            this.toolStripSeparator1,
            this.TsbToTray,
            this.toolStripSeparator2,
            this.TsbNewApplication,
            this.toolStripSeparator3,
            this.TsbAddApplication,
            this.TsbRemoveAt,
            this.toolStripSeparator4,
            this.TsbEditApplitions,
            this.TsbEditApartment,
            this.toolStripSeparator6,
            this.TsdOrderBy,
            this.toolStripSeparator5,
            this.TsbSelectName,
            this.TsbSelectState,
            this.toolStripSeparator7,
            this.TsbTurnOnAt,
            this.TsbTurnOffAt,
            this.TsbTurnOnAll,
            this.TsbTurnOffAll,
            this.toolStripSeparator8,
            this.TsbAboutProgram});
            this.TsbMain.Location = new System.Drawing.Point(0, 24);
            this.TsbMain.Name = "TsbMain";
            this.TsbMain.Size = new System.Drawing.Size(984, 39);
            this.TsbMain.TabIndex = 1;
            this.TsbMain.Text = "toolStrip1";
            // 
            // TsbFileOpen
            // 
            this.TsbFileOpen.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbFileOpen.Image = global::H_W12WF.Properties.Resources.folder_blue;
            this.TsbFileOpen.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbFileOpen.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbFileOpen.Name = "TsbFileOpen";
            this.TsbFileOpen.Size = new System.Drawing.Size(36, 36);
            this.TsbFileOpen.Text = "toolStripButton1";
            this.TsbFileOpen.ToolTipText = "Открыть файл данных\r\nэлектроприборов";
            this.TsbFileOpen.Click += new System.EventHandler(this.LoadFile_Command);
            // 
            // TsbFileSave
            // 
            this.TsbFileSave.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbFileSave.Image = global::H_W12WF.Properties.Resources.save_as;
            this.TsbFileSave.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbFileSave.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbFileSave.Name = "TsbFileSave";
            this.TsbFileSave.Size = new System.Drawing.Size(36, 36);
            this.TsbFileSave.Text = "toolStripButton2";
            this.TsbFileSave.ToolTipText = "Сохранить файл данны \r\nэлектроприборов";
            this.TsbFileSave.Click += new System.EventHandler(this.SaveAsFile_Command);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 39);
            // 
            // TsbToTray
            // 
            this.TsbToTray.BackColor = System.Drawing.Color.LightSteelBlue;
            this.TsbToTray.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbToTray.Image = global::H_W12WF.Properties.Resources.свернуть_окно_32;
            this.TsbToTray.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbToTray.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbToTray.Name = "TsbToTray";
            this.TsbToTray.Size = new System.Drawing.Size(36, 36);
            this.TsbToTray.Text = "Свернуть в трей";
            this.TsbToTray.Click += new System.EventHandler(this.ToTray_Command);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 39);
            // 
            // TsbNewApplication
            // 
            this.TsbNewApplication.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbNewApplication.Image = global::H_W12WF.Properties.Resources._new;
            this.TsbNewApplication.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbNewApplication.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbNewApplication.Name = "TsbNewApplication";
            this.TsbNewApplication.Size = new System.Drawing.Size(36, 36);
            this.TsbNewApplication.Text = "toolStripButton4";
            this.TsbNewApplication.ToolTipText = "Создание новых приборов\r\nв квартире";
            this.TsbNewApplication.Click += new System.EventHandler(this.NewCollection_Command);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(6, 39);
            // 
            // TsbAddApplication
            // 
            this.TsbAddApplication.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbAddApplication.Image = global::H_W12WF.Properties.Resources.add;
            this.TsbAddApplication.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbAddApplication.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbAddApplication.Name = "TsbAddApplication";
            this.TsbAddApplication.Size = new System.Drawing.Size(36, 36);
            this.TsbAddApplication.Text = "toolStripButton5";
            this.TsbAddApplication.ToolTipText = "Добавить электроприбор";
            this.TsbAddApplication.Click += new System.EventHandler(this.AddAppliance_Command);
            // 
            // TsbRemoveAt
            // 
            this.TsbRemoveAt.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbRemoveAt.Image = global::H_W12WF.Properties.Resources.delete;
            this.TsbRemoveAt.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbRemoveAt.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbRemoveAt.Name = "TsbRemoveAt";
            this.TsbRemoveAt.Size = new System.Drawing.Size(36, 36);
            this.TsbRemoveAt.Text = "toolStripButton6";
            this.TsbRemoveAt.ToolTipText = "Удалить электроприбор";
            this.TsbRemoveAt.Click += new System.EventHandler(this.RemoveAppliance_Command);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(6, 39);
            // 
            // TsbEditApplitions
            // 
            this.TsbEditApplitions.BackColor = System.Drawing.Color.LightGray;
            this.TsbEditApplitions.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbEditApplitions.Image = global::H_W12WF.Properties.Resources.edit_button;
            this.TsbEditApplitions.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbEditApplitions.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbEditApplitions.Name = "TsbEditApplitions";
            this.TsbEditApplitions.Size = new System.Drawing.Size(36, 36);
            this.TsbEditApplitions.Text = "toolStripButton1";
            this.TsbEditApplitions.ToolTipText = "Редактировать данные выбранного\r\nэлектроприбора";
            this.TsbEditApplitions.Click += new System.EventHandler(this.ApplicationEdit_Command);
            // 
            // TsbEditApartment
            // 
            this.TsbEditApartment.BackColor = System.Drawing.Color.LightGray;
            this.TsbEditApartment.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbEditApartment.Image = global::H_W12WF.Properties.Resources.редактировать_свойство_28;
            this.TsbEditApartment.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbEditApartment.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbEditApartment.Name = "TsbEditApartment";
            this.TsbEditApartment.Size = new System.Drawing.Size(32, 36);
            this.TsbEditApartment.Text = "toolStripButton1";
            this.TsbEditApartment.ToolTipText = "Редактировать данные \r\nквартиры";
            this.TsbEditApartment.Click += new System.EventHandler(this.ApartmentEdit_Command);
            // 
            // toolStripSeparator6
            // 
            this.toolStripSeparator6.Name = "toolStripSeparator6";
            this.toolStripSeparator6.Size = new System.Drawing.Size(6, 39);
            // 
            // TsdOrderBy
            // 
            this.TsdOrderBy.BackColor = System.Drawing.Color.LightCyan;
            this.TsdOrderBy.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsdOrderBy.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.TsdOrderByName,
            this.TsdOrderByState,
            this.TsdOrderByPower,
            this.TsdOrderByPrice});
            this.TsdOrderBy.Image = global::H_W12WF.Properties.Resources.sort;
            this.TsdOrderBy.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsdOrderBy.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsdOrderBy.Name = "TsdOrderBy";
            this.TsdOrderBy.Size = new System.Drawing.Size(45, 36);
            this.TsdOrderBy.Text = "toolStripDropDownButton1";
            this.TsdOrderBy.ToolTipText = "Сортировка коллекции\r\nэлектроприборов";
            // 
            // TsdOrderByName
            // 
            this.TsdOrderByName.Image = global::H_W12WF.Properties.Resources.сортировка_по_алфавиту_28;
            this.TsdOrderByName.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsdOrderByName.Name = "TsdOrderByName";
            this.TsdOrderByName.Size = new System.Drawing.Size(212, 38);
            this.TsdOrderByName.Text = "По названию";
            this.TsdOrderByName.Click += new System.EventHandler(this.OrderByNameApplic_Command);
            // 
            // TsdOrderByState
            // 
            this.TsdOrderByState.Image = global::H_W12WF.Properties.Resources.выключить_свет_28;
            this.TsdOrderByState.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsdOrderByState.Name = "TsdOrderByState";
            this.TsdOrderByState.Size = new System.Drawing.Size(212, 38);
            this.TsdOrderByState.Text = "По состоянию";
            this.TsdOrderByState.Click += new System.EventHandler(this.OrderByState_Command);
            // 
            // TsdOrderByPower
            // 
            this.TsdOrderByPower.Image = global::H_W12WF.Properties.Resources.электроприборы_28;
            this.TsdOrderByPower.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsdOrderByPower.Name = "TsdOrderByPower";
            this.TsdOrderByPower.Size = new System.Drawing.Size(212, 38);
            this.TsdOrderByPower.Text = "По мощности";
            this.TsdOrderByPower.Click += new System.EventHandler(this.OrderByPower_Command);
            // 
            // TsdOrderByPrice
            // 
            this.TsdOrderByPrice.Image = global::H_W12WF.Properties.Resources.money;
            this.TsdOrderByPrice.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsdOrderByPrice.Name = "TsdOrderByPrice";
            this.TsdOrderByPrice.Size = new System.Drawing.Size(212, 38);
            this.TsdOrderByPrice.Text = "По цене";
            this.TsdOrderByPrice.Click += new System.EventHandler(this.OrderByPrice_Command);
            // 
            // toolStripSeparator5
            // 
            this.toolStripSeparator5.Name = "toolStripSeparator5";
            this.toolStripSeparator5.Size = new System.Drawing.Size(6, 39);
            // 
            // TsbSelectName
            // 
            this.TsbSelectName.BackColor = System.Drawing.Color.LavenderBlush;
            this.TsbSelectName.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbSelectName.Image = global::H_W12WF.Properties.Resources._486_abc_blocks;
            this.TsbSelectName.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbSelectName.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbSelectName.Name = "TsbSelectName";
            this.TsbSelectName.Size = new System.Drawing.Size(36, 36);
            this.TsbSelectName.Text = "toolStripButton1";
            this.TsbSelectName.ToolTipText = "Выборка прибора с\r\nзаданным названием";
            this.TsbSelectName.Click += new System.EventHandler(this.SelectApplicationName_Command);
            // 
            // TsbSelectState
            // 
            this.TsbSelectState.BackColor = System.Drawing.Color.LavenderBlush;
            this.TsbSelectState.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbSelectState.Image = global::H_W12WF.Properties.Resources.включить_свет_28;
            this.TsbSelectState.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbSelectState.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbSelectState.Name = "TsbSelectState";
            this.TsbSelectState.Size = new System.Drawing.Size(32, 36);
            this.TsbSelectState.Text = "toolStripButton2";
            this.TsbSelectState.ToolTipText = "Выборка приборов с\r\nзаданным состоянием";
            this.TsbSelectState.Click += new System.EventHandler(this.SelectApplicationState_Command);
            // 
            // toolStripSeparator7
            // 
            this.toolStripSeparator7.Name = "toolStripSeparator7";
            this.toolStripSeparator7.Size = new System.Drawing.Size(6, 39);
            // 
            // TsbTurnOnAt
            // 
            this.TsbTurnOnAt.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbTurnOnAt.Image = global::H_W12WF.Properties.Resources.lightbulb;
            this.TsbTurnOnAt.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbTurnOnAt.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbTurnOnAt.Name = "TsbTurnOnAt";
            this.TsbTurnOnAt.Size = new System.Drawing.Size(36, 36);
            this.TsbTurnOnAt.Text = "toolStripButton1";
            this.TsbTurnOnAt.ToolTipText = "Включение выбранного\r\nэлектроприбора";
            this.TsbTurnOnAt.Click += new System.EventHandler(this.TurnOnAt_Command);
            // 
            // TsbTurnOffAt
            // 
            this.TsbTurnOffAt.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbTurnOffAt.Image = global::H_W12WF.Properties.Resources.lightbulb_off;
            this.TsbTurnOffAt.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbTurnOffAt.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbTurnOffAt.Name = "TsbTurnOffAt";
            this.TsbTurnOffAt.Size = new System.Drawing.Size(36, 36);
            this.TsbTurnOffAt.Text = "toolStripButton2";
            this.TsbTurnOffAt.ToolTipText = "Выключение выбранного \r\nэлектроприбора";
            this.TsbTurnOffAt.Click += new System.EventHandler(this.TurnOffAt_Command);
            // 
            // TsbTurnOnAll
            // 
            this.TsbTurnOnAll.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbTurnOnAll.Image = global::H_W12WF.Properties.Resources.электчество_28;
            this.TsbTurnOnAll.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbTurnOnAll.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbTurnOnAll.Name = "TsbTurnOnAll";
            this.TsbTurnOnAll.Size = new System.Drawing.Size(32, 36);
            this.TsbTurnOnAll.Text = "toolStripButton1";
            this.TsbTurnOnAll.ToolTipText = "Включение всех электроприборов";
            this.TsbTurnOnAll.Click += new System.EventHandler(this.TurnOnAll_Command);
            // 
            // TsbTurnOffAll
            // 
            this.TsbTurnOffAll.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbTurnOffAll.Image = global::H_W12WF.Properties.Resources.электричество_28;
            this.TsbTurnOffAll.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbTurnOffAll.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbTurnOffAll.Name = "TsbTurnOffAll";
            this.TsbTurnOffAll.Size = new System.Drawing.Size(32, 36);
            this.TsbTurnOffAll.Text = "toolStripButton2";
            this.TsbTurnOffAll.ToolTipText = "Выключение всех электроприборов";
            this.TsbTurnOffAll.Click += new System.EventHandler(this.TurnOffAll_Command);
            // 
            // toolStripSeparator8
            // 
            this.toolStripSeparator8.Name = "toolStripSeparator8";
            this.toolStripSeparator8.Size = new System.Drawing.Size(6, 39);
            // 
            // TsbAboutProgram
            // 
            this.TsbAboutProgram.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.TsbAboutProgram.Image = global::H_W12WF.Properties.Resources.о_программе_28;
            this.TsbAboutProgram.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TsbAboutProgram.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TsbAboutProgram.Name = "TsbAboutProgram";
            this.TsbAboutProgram.Size = new System.Drawing.Size(32, 36);
            this.TsbAboutProgram.Text = "toolStripButton3";
            this.TsbAboutProgram.ToolTipText = "Сведения о программе";
            this.TsbAboutProgram.Click += new System.EventHandler(this.About_Command);
            // 
            // StsMain
            // 
            this.StsMain.Font = new System.Drawing.Font("Lucida Console", 10F);
            this.StsMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.StlMain});
            this.StsMain.Location = new System.Drawing.Point(0, 539);
            this.StsMain.Name = "StsMain";
            this.StsMain.Size = new System.Drawing.Size(984, 22);
            this.StsMain.TabIndex = 2;
            this.StsMain.Text = "StatusStrip";
            // 
            // StlMain
            // 
            this.StlMain.Name = "StlMain";
            this.StlMain.Size = new System.Drawing.Size(969, 17);
            this.StlMain.Spring = true;
            this.StlMain.Text = "ToolStripStatusLabel1";
            this.StlMain.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // TbcMain
            // 
            this.TbcMain.AllowDrop = true;
            this.TbcMain.Controls.Add(this.TbpGeneral);
            this.TbcMain.Controls.Add(this.TbpOrdered);
            this.TbcMain.Controls.Add(this.TbpSelected);
            this.TbcMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TbcMain.Location = new System.Drawing.Point(0, 63);
            this.TbcMain.Name = "TbcMain";
            this.TbcMain.SelectedIndex = 0;
            this.TbcMain.Size = new System.Drawing.Size(984, 476);
            this.TbcMain.TabIndex = 3;
            // 
            // TbpGeneral
            // 
            this.TbpGeneral.ContextMenuStrip = this.CmnApplication;
            this.TbpGeneral.Controls.Add(this.LblHeaderOrdered);
            this.TbpGeneral.Controls.Add(this.LsvAppliance);
            this.TbpGeneral.Location = new System.Drawing.Point(4, 26);
            this.TbpGeneral.Name = "TbpGeneral";
            this.TbpGeneral.Padding = new System.Windows.Forms.Padding(3);
            this.TbpGeneral.Size = new System.Drawing.Size(976, 446);
            this.TbpGeneral.TabIndex = 0;
            this.TbpGeneral.Text = "Электроприборы";
            this.TbpGeneral.UseVisualStyleBackColor = true;
            // 
            // CmnApplication
            // 
            this.CmnApplication.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.CmnNewCollection,
            this.toolStripMenuItem4,
            this.CmnSortBy,
            this.toolStripMenuItem5,
            this.CmnAddApplication,
            this.CmnEditApplication,
            this.CmnEditApartment,
            this.toolStripMenuItem6,
            this.CmnSelectedBy,
            this.toolStripMenuItem7,
            this.CmnExitApp,
            this.CmnAbout});
            this.CmnApplication.Name = "CmnApplication";
            this.CmnApplication.Size = new System.Drawing.Size(273, 332);
            // 
            // CmnNewCollection
            // 
            this.CmnNewCollection.Image = global::H_W12WF.Properties.Resources._new;
            this.CmnNewCollection.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.CmnNewCollection.Name = "CmnNewCollection";
            this.CmnNewCollection.Size = new System.Drawing.Size(272, 38);
            this.CmnNewCollection.Text = "Новая коллекция";
            this.CmnNewCollection.Click += new System.EventHandler(this.NewCollection_Command);
            // 
            // toolStripMenuItem4
            // 
            this.toolStripMenuItem4.Name = "toolStripMenuItem4";
            this.toolStripMenuItem4.Size = new System.Drawing.Size(269, 6);
            // 
            // CmnSortBy
            // 
            this.CmnSortBy.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.CmnSortByName,
            this.CmnSortByState,
            this.CmnSortByPower,
            this.CmnSortByPrice});
            this.CmnSortBy.Image = global::H_W12WF.Properties.Resources.бытовая_техника_32;
            this.CmnSortBy.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.CmnSortBy.Name = "CmnSortBy";
            this.CmnSortBy.Size = new System.Drawing.Size(272, 38);
            this.CmnSortBy.Text = "Сортировка";
            // 
            // CmnSortByName
            // 
            this.CmnSortByName.Image = global::H_W12WF.Properties.Resources.сортировка_по_алфавиту_28;
            this.CmnSortByName.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.CmnSortByName.Name = "CmnSortByName";
            this.CmnSortByName.Size = new System.Drawing.Size(168, 38);
            this.CmnSortByName.Text = "по названию";
            this.CmnSortByName.Click += new System.EventHandler(this.OrderByNameApplic_Command);
            // 
            // CmnSortByState
            // 
            this.CmnSortByState.Image = global::H_W12WF.Properties.Resources.выключить_свет_28;
            this.CmnSortByState.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.CmnSortByState.Name = "CmnSortByState";
            this.CmnSortByState.Size = new System.Drawing.Size(168, 38);
            this.CmnSortByState.Text = "по состоянию";
            // 
            // CmnSortByPower
            // 
            this.CmnSortByPower.Image = global::H_W12WF.Properties.Resources.электроприборы_28;
            this.CmnSortByPower.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.CmnSortByPower.Name = "CmnSortByPower";
            this.CmnSortByPower.Size = new System.Drawing.Size(168, 38);
            this.CmnSortByPower.Text = "по мощности";
            this.CmnSortByPower.Click += new System.EventHandler(this.OrderByPower_Command);
            // 
            // CmnSortByPrice
            // 
            this.CmnSortByPrice.Image = global::H_W12WF.Properties.Resources.money;
            this.CmnSortByPrice.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.CmnSortByPrice.Name = "CmnSortByPrice";
            this.CmnSortByPrice.Size = new System.Drawing.Size(168, 38);
            this.CmnSortByPrice.Text = "по цене";
            this.CmnSortByPrice.Click += new System.EventHandler(this.OrderByPrice_Command);
            // 
            // toolStripMenuItem5
            // 
            this.toolStripMenuItem5.Name = "toolStripMenuItem5";
            this.toolStripMenuItem5.Size = new System.Drawing.Size(269, 6);
            // 
            // CmnAddApplication
            // 
            this.CmnAddApplication.Image = global::H_W12WF.Properties.Resources.add;
            this.CmnAddApplication.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.CmnAddApplication.Name = "CmnAddApplication";
            this.CmnAddApplication.Size = new System.Drawing.Size(272, 38);
            this.CmnAddApplication.Text = "Добавить прибор..";
            this.CmnAddApplication.Click += new System.EventHandler(this.AddAppliance_Command);
            // 
            // CmnEditApplication
            // 
            this.CmnEditApplication.Image = global::H_W12WF.Properties.Resources.edit_button;
            this.CmnEditApplication.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.CmnEditApplication.Name = "CmnEditApplication";
            this.CmnEditApplication.Size = new System.Drawing.Size(272, 38);
            this.CmnEditApplication.Text = "Редактировать прибор..";
            this.CmnEditApplication.Click += new System.EventHandler(this.ApplicationEdit_Command);
            // 
            // CmnEditApartment
            // 
            this.CmnEditApartment.Image = global::H_W12WF.Properties.Resources.редактировать_свойство_28;
            this.CmnEditApartment.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.CmnEditApartment.Name = "CmnEditApartment";
            this.CmnEditApartment.Size = new System.Drawing.Size(272, 38);
            this.CmnEditApartment.Text = "Редактировать адресс квартиры..";
            this.CmnEditApartment.Click += new System.EventHandler(this.ApartmentEdit_Command);
            // 
            // toolStripMenuItem6
            // 
            this.toolStripMenuItem6.Name = "toolStripMenuItem6";
            this.toolStripMenuItem6.Size = new System.Drawing.Size(269, 6);
            // 
            // CmnSelectedBy
            // 
            this.CmnSelectedBy.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.CmnSelectedByName,
            this.CmnSelectedByState});
            this.CmnSelectedBy.Image = global::H_W12WF.Properties.Resources.бытовая_техника_32;
            this.CmnSelectedBy.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.CmnSelectedBy.Name = "CmnSelectedBy";
            this.CmnSelectedBy.Size = new System.Drawing.Size(272, 38);
            this.CmnSelectedBy.Text = "Выбрать";
            // 
            // CmnSelectedByName
            // 
            this.CmnSelectedByName.Image = global::H_W12WF.Properties.Resources._486_abc_blocks;
            this.CmnSelectedByName.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.CmnSelectedByName.Name = "CmnSelectedByName";
            this.CmnSelectedByName.Size = new System.Drawing.Size(268, 38);
            this.CmnSelectedByName.Text = "прибор с заданным названием";
            this.CmnSelectedByName.Click += new System.EventHandler(this.SelectApplicationName_Command);
            // 
            // CmnSelectedByState
            // 
            this.CmnSelectedByState.Image = global::H_W12WF.Properties.Resources.включить_свет_28;
            this.CmnSelectedByState.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.CmnSelectedByState.Name = "CmnSelectedByState";
            this.CmnSelectedByState.Size = new System.Drawing.Size(268, 38);
            this.CmnSelectedByState.Text = "прибор с заданным состоянием";
            this.CmnSelectedByState.Click += new System.EventHandler(this.SelectApplicationState_Command);
            // 
            // toolStripMenuItem7
            // 
            this.toolStripMenuItem7.Name = "toolStripMenuItem7";
            this.toolStripMenuItem7.Size = new System.Drawing.Size(269, 6);
            // 
            // CmnExitApp
            // 
            this.CmnExitApp.Image = global::H_W12WF.Properties.Resources.выход_28;
            this.CmnExitApp.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.CmnExitApp.Name = "CmnExitApp";
            this.CmnExitApp.Size = new System.Drawing.Size(272, 38);
            this.CmnExitApp.Text = "Выход";
            this.CmnExitApp.Click += new System.EventHandler(this.Exit_Command);
            // 
            // CmnAbout
            // 
            this.CmnAbout.Image = global::H_W12WF.Properties.Resources.о_программе_28;
            this.CmnAbout.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.CmnAbout.Name = "CmnAbout";
            this.CmnAbout.Size = new System.Drawing.Size(272, 38);
            this.CmnAbout.Text = "О программе..";
            this.CmnAbout.Click += new System.EventHandler(this.About_Command);
            // 
            // LblHeaderOrdered
            // 
            this.LblHeaderOrdered.Font = new System.Drawing.Font("Consolas", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblHeaderOrdered.Location = new System.Drawing.Point(20, 3);
            this.LblHeaderOrdered.Name = "LblHeaderOrdered";
            this.LblHeaderOrdered.Size = new System.Drawing.Size(610, 40);
            this.LblHeaderOrdered.TabIndex = 8;
            this.LblHeaderOrdered.Text = "Электроприборы в квартире";
            this.LblHeaderOrdered.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // LsvAppliance
            // 
            this.LsvAppliance.AllowDrop = true;
            this.LsvAppliance.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.ClhState,
            this.ClhName,
            this.ClhPower,
            this.ClhPrice});
            this.LsvAppliance.ContextMenuStrip = this.CmnApplication;
            this.LsvAppliance.FullRowSelect = true;
            this.LsvAppliance.GridLines = true;
            this.LsvAppliance.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
            this.LsvAppliance.HideSelection = false;
            this.LsvAppliance.LargeImageList = this.ImlAppliances;
            this.LsvAppliance.Location = new System.Drawing.Point(20, 46);
            this.LsvAppliance.MultiSelect = false;
            this.LsvAppliance.Name = "LsvAppliance";
            this.LsvAppliance.Size = new System.Drawing.Size(726, 386);
            this.LsvAppliance.SmallImageList = this.ImlAppliances;
            this.LsvAppliance.TabIndex = 0;
            this.LsvAppliance.UseCompatibleStateImageBehavior = false;
            this.LsvAppliance.View = System.Windows.Forms.View.Details;
            this.LsvAppliance.DragDrop += new System.Windows.Forms.DragEventHandler(this.LsvAppliance_DragDrop);
            this.LsvAppliance.DragEnter += new System.Windows.Forms.DragEventHandler(this.Elements_DragEnter);
            // 
            // ClhState
            // 
            this.ClhState.Text = "Состояние";
            this.ClhState.Width = 120;
            // 
            // ClhName
            // 
            this.ClhName.Text = "Название";
            this.ClhName.Width = 250;
            // 
            // ClhPower
            // 
            this.ClhPower.Text = "Мощность (Вт)";
            this.ClhPower.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.ClhPower.Width = 150;
            // 
            // ClhPrice
            // 
            this.ClhPrice.Text = "Цена (рубл.)";
            this.ClhPrice.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.ClhPrice.Width = 140;
            // 
            // ImlAppliances
            // 
            this.ImlAppliances.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("ImlAppliances.ImageStream")));
            this.ImlAppliances.TransparentColor = System.Drawing.Color.Transparent;
            this.ImlAppliances.Images.SetKeyName(0, "выкл-свет-32.png");
            this.ImlAppliances.Images.SetKeyName(1, "icons8-включить-свет-32.png");
            // 
            // TbpOrdered
            // 
            this.TbpOrdered.ContextMenuStrip = this.CmnApplication;
            this.TbpOrdered.Controls.Add(this.LsvOrdered);
            this.TbpOrdered.Controls.Add(this.LblHeaderOrder);
            this.TbpOrdered.Location = new System.Drawing.Point(4, 26);
            this.TbpOrdered.Name = "TbpOrdered";
            this.TbpOrdered.Padding = new System.Windows.Forms.Padding(3);
            this.TbpOrdered.Size = new System.Drawing.Size(976, 446);
            this.TbpOrdered.TabIndex = 1;
            this.TbpOrdered.Text = "Отсортированные сведения";
            this.TbpOrdered.UseVisualStyleBackColor = true;
            // 
            // LblHeaderOrder
            // 
            this.LblHeaderOrder.Font = new System.Drawing.Font("Consolas", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblHeaderOrder.Location = new System.Drawing.Point(18, 3);
            this.LblHeaderOrder.Name = "LblHeaderOrder";
            this.LblHeaderOrder.Size = new System.Drawing.Size(610, 40);
            this.LblHeaderOrder.TabIndex = 9;
            this.LblHeaderOrder.Text = "Электроприборы в квартире";
            this.LblHeaderOrder.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // TbpSelected
            // 
            this.TbpSelected.ContextMenuStrip = this.CmnApplication;
            this.TbpSelected.Controls.Add(this.LsvSelected);
            this.TbpSelected.Controls.Add(this.LblHeaderSelected);
            this.TbpSelected.Location = new System.Drawing.Point(4, 26);
            this.TbpSelected.Name = "TbpSelected";
            this.TbpSelected.Padding = new System.Windows.Forms.Padding(3);
            this.TbpSelected.Size = new System.Drawing.Size(976, 446);
            this.TbpSelected.TabIndex = 2;
            this.TbpSelected.Text = "Выборка данных";
            this.TbpSelected.UseVisualStyleBackColor = true;
            // 
            // LblHeaderSelected
            // 
            this.LblHeaderSelected.Font = new System.Drawing.Font("Consolas", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblHeaderSelected.Location = new System.Drawing.Point(8, 3);
            this.LblHeaderSelected.Name = "LblHeaderSelected";
            this.LblHeaderSelected.Size = new System.Drawing.Size(610, 40);
            this.LblHeaderSelected.TabIndex = 10;
            this.LblHeaderSelected.Text = "Электроприборы в квартире";
            this.LblHeaderSelected.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // OfdMain
            // 
            this.OfdMain.DefaultExt = "json";
            this.OfdMain.FileName = "appliances";
            this.OfdMain.Filter = "Файл данных (*.json)|*.json|Все файлы (*.*)|*.*";
            this.OfdMain.InitialDirectory = ".\\";
            this.OfdMain.Title = "Загрузить данные электроприборов";
            // 
            // SfdMain
            // 
            this.SfdMain.DefaultExt = "json";
            this.SfdMain.FileName = "appliances";
            this.SfdMain.Filter = "Файл данных (*.json)|*.json|Все файлы (*.*)|*.*";
            this.SfdMain.InitialDirectory = ".\\";
            this.SfdMain.Title = "Сохранить данные электроприборов";
            // 
            // NtiMain
            // 
            this.NtiMain.ContextMenuStrip = this.CmnNotify;
            this.NtiMain.Icon = ((System.Drawing.Icon)(resources.GetObject("NtiMain.Icon")));
            this.NtiMain.Text = "Электроприборы в квартире";
            this.NtiMain.Visible = true;
            // 
            // CmnNotify
            // 
            this.CmnNotify.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.CmnNotify.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.CmnNotify.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.CmiNotifyRestore,
            this.CmiNotifyAbout,
            this.toolStripMenuItem2,
            this.CmiNotifyExit});
            this.CmnNotify.Name = "CmnNotify";
            this.CmnNotify.Size = new System.Drawing.Size(183, 88);
            // 
            // CmiNotifyRestore
            // 
            this.CmiNotifyRestore.Name = "CmiNotifyRestore";
            this.CmiNotifyRestore.Size = new System.Drawing.Size(182, 26);
            this.CmiNotifyRestore.Text = "Восстановить";
            this.CmiNotifyRestore.Click += new System.EventHandler(this.FromTray_Command);
            // 
            // CmiNotifyAbout
            // 
            this.CmiNotifyAbout.Name = "CmiNotifyAbout";
            this.CmiNotifyAbout.Size = new System.Drawing.Size(182, 26);
            this.CmiNotifyAbout.Text = "О программе..";
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(179, 6);
            // 
            // CmiNotifyExit
            // 
            this.CmiNotifyExit.Name = "CmiNotifyExit";
            this.CmiNotifyExit.Size = new System.Drawing.Size(182, 26);
            this.CmiNotifyExit.Text = "Выход";
            this.CmiNotifyExit.Click += new System.EventHandler(this.Exit_Command);
            // 
            // CmnMain
            // 
            this.CmnMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.CmnExit,
            this.CmnAboutProgram});
            this.CmnMain.Name = "CmnMain";
            this.CmnMain.Size = new System.Drawing.Size(168, 72);
            // 
            // CmnExit
            // 
            this.CmnExit.Image = global::H_W12WF.Properties.Resources.выход_28;
            this.CmnExit.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.CmnExit.Name = "CmnExit";
            this.CmnExit.Size = new System.Drawing.Size(167, 34);
            this.CmnExit.Text = "Выход";
            this.CmnExit.Click += new System.EventHandler(this.Exit_Command);
            // 
            // CmnAboutProgram
            // 
            this.CmnAboutProgram.Image = global::H_W12WF.Properties.Resources.о_программе_28;
            this.CmnAboutProgram.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.CmnAboutProgram.Name = "CmnAboutProgram";
            this.CmnAboutProgram.Size = new System.Drawing.Size(167, 34);
            this.CmnAboutProgram.Text = "О программе..";
            this.CmnAboutProgram.Click += new System.EventHandler(this.About_Command);
            // 
            // LsvOrdered
            // 
            this.LsvOrdered.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3,
            this.columnHeader4});
            this.LsvOrdered.ContextMenuStrip = this.CmnApplication;
            this.LsvOrdered.FullRowSelect = true;
            this.LsvOrdered.GridLines = true;
            this.LsvOrdered.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
            this.LsvOrdered.HideSelection = false;
            this.LsvOrdered.LargeImageList = this.ImlAppliances;
            this.LsvOrdered.Location = new System.Drawing.Point(22, 46);
            this.LsvOrdered.MultiSelect = false;
            this.LsvOrdered.Name = "LsvOrdered";
            this.LsvOrdered.Size = new System.Drawing.Size(726, 386);
            this.LsvOrdered.SmallImageList = this.ImlAppliances;
            this.LsvOrdered.TabIndex = 10;
            this.LsvOrdered.UseCompatibleStateImageBehavior = false;
            this.LsvOrdered.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Состояние";
            this.columnHeader1.Width = 120;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Название";
            this.columnHeader2.Width = 250;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Мощность (Вт)";
            this.columnHeader3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader3.Width = 150;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "Цена (рубл.)";
            this.columnHeader4.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.columnHeader4.Width = 140;
            // 
            // LsvSelected
            // 
            this.LsvSelected.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader5,
            this.columnHeader6,
            this.columnHeader7,
            this.columnHeader8});
            this.LsvSelected.ContextMenuStrip = this.CmnApplication;
            this.LsvSelected.FullRowSelect = true;
            this.LsvSelected.GridLines = true;
            this.LsvSelected.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
            this.LsvSelected.HideSelection = false;
            this.LsvSelected.LargeImageList = this.ImlAppliances;
            this.LsvSelected.Location = new System.Drawing.Point(12, 46);
            this.LsvSelected.MultiSelect = false;
            this.LsvSelected.Name = "LsvSelected";
            this.LsvSelected.Size = new System.Drawing.Size(726, 386);
            this.LsvSelected.SmallImageList = this.ImlAppliances;
            this.LsvSelected.TabIndex = 11;
            this.LsvSelected.UseCompatibleStateImageBehavior = false;
            this.LsvSelected.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader5
            // 
            this.columnHeader5.Text = "Состояние";
            this.columnHeader5.Width = 120;
            // 
            // columnHeader6
            // 
            this.columnHeader6.Text = "Название";
            this.columnHeader6.Width = 250;
            // 
            // columnHeader7
            // 
            this.columnHeader7.Text = "Мощность (Вт)";
            this.columnHeader7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader7.Width = 150;
            // 
            // columnHeader8
            // 
            this.columnHeader8.Text = "Цена (рубл.)";
            this.columnHeader8.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.columnHeader8.Width = 140;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Cornsilk;
            this.ClientSize = new System.Drawing.Size(984, 561);
            this.ContextMenuStrip = this.CmnMain;
            this.Controls.Add(this.TbcMain);
            this.Controls.Add(this.StsMain);
            this.Controls.Add(this.TsbMain);
            this.Controls.Add(this.MnuMain);
            this.Font = new System.Drawing.Font("Lucida Console", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.MnuMain;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximumSize = new System.Drawing.Size(1100, 600);
            this.MinimumSize = new System.Drawing.Size(1000, 566);
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Домашнее задание №12";
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.MnuMain.ResumeLayout(false);
            this.MnuMain.PerformLayout();
            this.TsbMain.ResumeLayout(false);
            this.TsbMain.PerformLayout();
            this.StsMain.ResumeLayout(false);
            this.StsMain.PerformLayout();
            this.TbcMain.ResumeLayout(false);
            this.TbpGeneral.ResumeLayout(false);
            this.CmnApplication.ResumeLayout(false);
            this.TbpOrdered.ResumeLayout(false);
            this.TbpSelected.ResumeLayout(false);
            this.CmnNotify.ResumeLayout(false);
            this.CmnMain.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip MnuMain;
        private System.Windows.Forms.ToolStripMenuItem MniFile;
        private System.Windows.Forms.ToolStripMenuItem MniFileOpen;
        private System.Windows.Forms.ToolStripMenuItem MniFileSave;
        private System.Windows.Forms.ToolStripMenuItem MniFileSaveAs;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem MniFileExit;
        private System.Windows.Forms.ToolStrip TsbMain;
        private System.Windows.Forms.StatusStrip StsMain;
        private System.Windows.Forms.ToolStripButton TsbFileOpen;
        private System.Windows.Forms.ToolStripButton TsbFileSave;
        private System.Windows.Forms.ToolStripButton TsbToTray;
        private System.Windows.Forms.ToolStripButton TsbNewApplication;
        private System.Windows.Forms.ToolStripButton TsbAddApplication;
        private System.Windows.Forms.ToolStripButton TsbRemoveAt;
        private System.Windows.Forms.TabControl TbcMain;
        private System.Windows.Forms.TabPage TbpGeneral;
        private System.Windows.Forms.TabPage TbpOrdered;
        private System.Windows.Forms.ListView LsvAppliance;
        private System.Windows.Forms.ColumnHeader ClhState;
        private System.Windows.Forms.ColumnHeader ClhName;
        private System.Windows.Forms.ColumnHeader ClhPower;
        private System.Windows.Forms.ColumnHeader ClhPrice;
        private System.Windows.Forms.ToolStripStatusLabel StlMain;
        private System.Windows.Forms.OpenFileDialog OfdMain;
        private System.Windows.Forms.SaveFileDialog SfdMain;
        private System.Windows.Forms.ToolStripMenuItem MniWindow;
        private System.Windows.Forms.ToolStripMenuItem MniToTray;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.NotifyIcon NtiMain;
        private System.Windows.Forms.ContextMenuStrip CmnNotify;
        private System.Windows.Forms.ToolStripMenuItem CmiNotifyRestore;
        private System.Windows.Forms.ToolStripMenuItem CmiNotifyAbout;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem CmiNotifyExit;
        private System.Windows.Forms.ToolStripMenuItem MniEdit;
        private System.Windows.Forms.ToolStripMenuItem MniNewCollection;
        private System.Windows.Forms.ToolStripMenuItem MniAddAppliance;
        private System.Windows.Forms.ToolStripMenuItem MniDeleleAppliance;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem MniEditAppliance;
        private System.Windows.Forms.ToolStripMenuItem MniEditApartment;
        private System.Windows.Forms.ToolStripMenuItem MniOrderBy;
        private System.Windows.Forms.ToolStripMenuItem MniOrderByName;
        private System.Windows.Forms.ToolStripMenuItem MniOrderByState;
        private System.Windows.Forms.ToolStripMenuItem MniOrderByPower;
        private System.Windows.Forms.ToolStripMenuItem MniOrderByPrice;
        private System.Windows.Forms.Label LblHeaderOrdered;
        private System.Windows.Forms.Label LblHeaderOrder;
        private System.Windows.Forms.ToolStripMenuItem MniSelectWhere;
        private System.Windows.Forms.ToolStripMenuItem MniSelectWhereName;
        private System.Windows.Forms.ToolStripMenuItem MniSelectWhereState;
        private System.Windows.Forms.TabPage TbpSelected;
        private System.Windows.Forms.Label LblHeaderSelected;
        private System.Windows.Forms.ToolStripMenuItem MniTurnOn;
        private System.Windows.Forms.ToolStripMenuItem MniTurnOnAt;
        private System.Windows.Forms.ToolStripMenuItem MniTurnOnAll;
        private System.Windows.Forms.ToolStripMenuItem MniTurnOff;
        private System.Windows.Forms.ToolStripMenuItem MniTurnOffAt;
        private System.Windows.Forms.ToolStripMenuItem выключитьВсеПриборыToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem MniHelp;
        private System.Windows.Forms.ToolStripMenuItem MniAbout;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripButton TsbEditApplitions;
        private System.Windows.Forms.ToolStripButton TsbEditApartment;
        private System.Windows.Forms.ToolStripButton TsbSelectName;
        private System.Windows.Forms.ToolStripDropDownButton TsdOrderBy;
        private System.Windows.Forms.ToolStripMenuItem TsdOrderByName;
        private System.Windows.Forms.ToolStripMenuItem TsdOrderByState;
        private System.Windows.Forms.ToolStripMenuItem TsdOrderByPower;
        private System.Windows.Forms.ToolStripMenuItem TsdOrderByPrice;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator6;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator5;
        private System.Windows.Forms.ToolStripButton TsbSelectState;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator7;
        private System.Windows.Forms.ToolStripButton TsbTurnOnAt;
        private System.Windows.Forms.ToolStripButton TsbTurnOffAt;
        private System.Windows.Forms.ToolStripButton TsbTurnOnAll;
        private System.Windows.Forms.ToolStripButton TsbTurnOffAll;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator8;
        private System.Windows.Forms.ToolStripButton TsbAboutProgram;
        private System.Windows.Forms.ContextMenuStrip CmnMain;
        private System.Windows.Forms.ToolStripMenuItem CmnExit;
        private System.Windows.Forms.ToolStripMenuItem CmnAboutProgram;
        private System.Windows.Forms.ContextMenuStrip CmnApplication;
        private System.Windows.Forms.ToolStripMenuItem CmnNewCollection;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem4;
        private System.Windows.Forms.ToolStripMenuItem CmnSortBy;
        private System.Windows.Forms.ToolStripMenuItem CmnSortByName;
        private System.Windows.Forms.ToolStripMenuItem CmnSortByState;
        private System.Windows.Forms.ToolStripMenuItem CmnSortByPower;
        private System.Windows.Forms.ToolStripMenuItem CmnSortByPrice;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem5;
        private System.Windows.Forms.ToolStripMenuItem CmnAddApplication;
        private System.Windows.Forms.ToolStripMenuItem CmnEditApplication;
        private System.Windows.Forms.ToolStripMenuItem CmnEditApartment;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem6;
        private System.Windows.Forms.ToolStripMenuItem CmnSelectedBy;
        private System.Windows.Forms.ToolStripMenuItem CmnSelectedByName;
        private System.Windows.Forms.ToolStripMenuItem CmnSelectedByState;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem7;
        private System.Windows.Forms.ToolStripMenuItem CmnExitApp;
        private System.Windows.Forms.ToolStripMenuItem CmnAbout;
        private System.Windows.Forms.ImageList ImlAppliances;
        private System.Windows.Forms.ListView LsvOrdered;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.ListView LsvSelected;
        private System.Windows.Forms.ColumnHeader columnHeader5;
        private System.Windows.Forms.ColumnHeader columnHeader6;
        private System.Windows.Forms.ColumnHeader columnHeader7;
        private System.Windows.Forms.ColumnHeader columnHeader8;
    }
}

