﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using H_W12WF.Controllers;
using H_W12WF.Models;
using H_W12WF.View;
using H_W12WF.Views;

namespace H_W12WF
{
    public partial class MainForm : Form
    {
        // контроллер для работы с формой
        private ElectAppliancesController _appliancesController;

        // конструкторы формы
        public MainForm() : this(new ElectAppliancesController()) { }
        public MainForm(ElectAppliancesController appliancesController)
        {
            InitializeComponent();

            // получить контроллер для работы с данными электроприборов в квартире
            _appliancesController = appliancesController;

            //LsvAppliance.DragDrop += new DragEventHandler(this.LsvAppliance_DragDrop);
            //LsvAppliance.DragEnter += new DragEventHandler(this.elements_DragEnter);
        }// MainForm

        private void Exit_Command(object sender, EventArgs e) => Application.Exit();

        private void About_Command(object sender, EventArgs e)
        {
            AboutForm aboutForm = new AboutForm();
            aboutForm.ShowDialog();
        }// About_Command

        // запись коллекции объектов в ListView для табличного отображения
        private void WriteToListView()
        {
            LsvAppliance.Items.Clear();

            foreach(var appliance in _appliancesController.Controller.Appliances)
            {
                // получить элемент для заполнения строки ListView, указать в нем данные 0го столбца 
                ListViewItem listViewItem = new ListViewItem("", (appliance.OffOnn ? 1 : 0));

                // добавить остальные столбцы
                listViewItem.SubItems.Add(appliance.Name);
                listViewItem.SubItems.Add($"{appliance.Power}");
                listViewItem.SubItems.Add($"{appliance.Price:f2}");
                

                // добавить строку в ListView
                LsvAppliance.Items.Add(listViewItem);
            }// foreach appliance

        }// WriteToListView

        // после готовности всех элементов, после работы конструктора
        // заполнить ListView данными коллекции
        private void MainForm_Load(object sender, EventArgs e)
        {
            Text =" Адрес: " + _appliancesController.Controller.Address;

            WriteToListView();

            // вывод в строку состояния
            StlMain.Text = $"Сформировано приборов: {_appliancesController.Controller.Count}";
        } // MainForm_Load


        // свернуть в трей
        private void ToTray_Command(object sender, EventArgs e)
        {
            this.Hide();
            NtiMain.Visible = true;
        } // ToTray_Command


        // восстановить из трея
        private void FromTray_Command(object sender, EventArgs e)
        {
            this.Show();
            WindowState = FormWindowState.Normal;
            NtiMain.Visible = false;
        } // FromTray_Command


        private void NewCollection_Command(object sender, EventArgs e)
        {
            _appliancesController.Controller.Initialize(Utils.Random.Next(10, 15));

            WriteToListView();

            // обновить строку состояния
            StlMain.Text = $"Коллекция данных сформирована. Текущее количество приборов: {_appliancesController.Controller.Count}";
        }// NewCollection_Command


        // yдаление прибора из коллекции, сериализация данных
        private void RemoveAppliance_Command(object sender, EventArgs e)
        {
            // если нет выбранных элементов - молча уходим
            if (LsvAppliance.SelectedIndices.Count == 0) return;

            // получить индекс выбранного элемента в ListView
            int index = LsvAppliance.SelectedIndices[0];

            // удаление записей и из коллекции и из ListView
            _appliancesController.Controller.RemoveAt(index);
            LsvAppliance.Items.RemoveAt(index);

            // сериализация данных
            _appliancesController.SerializeData();

            // обновить строку состояния
            StlMain.Text = $"Данные удалены. Текущее количество телевизоров: {_appliancesController.Controller.Count}";
        }// RemoveAppliance_Command


        // добавление прибора в коллекцию
        private void AddAppliance_Command(object sender, EventArgs e)
        {

            ElectApplianceForm applianceForm = new ElectApplianceForm();

            DialogResult dialogResult = applianceForm.ShowDialog();

            // если окно закрыто не по кнопке "Добавить" - молча уходим
            if (dialogResult != DialogResult.OK) return;

            // получить данные из свойства формы
            ElectricalAppliance appliance = applianceForm.Appliance;
            _appliancesController.Controller.AddAppliance(appliance);

            // сериализация данных
           _appliancesController.SerializeData();

            WriteToListView();
            // обновить строку состояния
            StlMain.Text = $"Данные добавлены. Текущее количество приборов: {_appliancesController.Controller.Count}";
        }// AddAppliance_Command


        // pедактирование выбранного прибора в отдельной форме
        private void ApplicationEdit_Command(object sender, EventArgs e)
        { 
            // если нет выбранных элементов - молча уходим
            if (LsvAppliance.SelectedIndices.Count == 0) return;
            int index = LsvAppliance.SelectedIndices[0];
            // передача данных в форму
            ElectApplianceForm applianceForm = new ElectApplianceForm("Редактировать данные о приборе", "Сохранить");
            
            applianceForm.Appliance = _appliancesController.Controller[index];

            DialogResult dialogResult = applianceForm.ShowDialog();

            // если окно закрыто не по кнопке "Добавить" - молча уходим
            if (dialogResult != DialogResult.OK) return;

            // получить данные
            _appliancesController.Controller[index] = applianceForm.Appliance;

            WriteToListView();

            // сериализация данных
            _appliancesController.SerializeData();


            // обновить строку состояния
            StlMain.Text = $"Данные обновлены. Текущее количество приборов: {_appliancesController.Controller.Count}";
        }// ApplicationEdit_Command


        // pедактирование данных о квартире в отдельной форме
        private void ApartmentEdit_Command(object sender, EventArgs e)
        {
            ApartmentEditForm apartmentEdit =
                new ApartmentEditForm(_appliancesController.Controller.Address);

            if (apartmentEdit.ShowDialog() != DialogResult.OK) return;

            _appliancesController.Controller.Address = apartmentEdit.Address;

            // сериализация данных
            _appliancesController.SerializeData();

            Text = " Адрес: " + _appliancesController.Controller.Address;
        }// ApartmentEdit_Command

        #region Сортировка
        // запись отсортированной коллекции объектов в ListView для табличного отображения
        private void WriteTbcMainToListView(List<ElectricalAppliance> appliancelist)
        {
            LsvOrdered.Items.Clear();
            foreach (var appliance in appliancelist)
            {
                // получить элемент для заполнения строки ListView, указать в нем данные 0го столбца 
                ListViewItem listViewItem = new ListViewItem("", (appliance.OffOnn ? 1 : 0));

                // добавить остальные столбцы
                listViewItem.SubItems.Add(appliance.Name);
                listViewItem.SubItems.Add($"{appliance.Power}");
                listViewItem.SubItems.Add($"{appliance.Price:f2}");

                // добавить строку в ListView
                LsvOrdered.Items.Add(listViewItem);
            }// foreach appliance
        }// WriteTbcMainToListView

        // сортировка коллекции приборов по наименованию
        private void OrderByNameApplic_Command(object sender, EventArgs e)
        {
            List<ElectricalAppliance> list = _appliancesController.OrderByName();

            WriteTbcMainToListView(list);

            // делаем страницу отсортированных данных текущей
            TbcMain.SelectedTab = TbpOrdered;

            // формирование заголовка поля вывода данных о приборах
            LblHeaderOrder.Text =
              $"{_appliancesController.Controller.Address}, приборы по наименованию\r\n";
        } // OrderByNameApplic_Command

        // сортировка коллекции приборов по состоянию
        private void OrderByState_Command(object sender, EventArgs e)
        {
            List<ElectricalAppliance> list = _appliancesController.OrderByState();

            WriteTbcMainToListView(list);

            // делаем страницу отсортированных данных текущей
            TbcMain.SelectedTab = TbpOrdered;

            // формирование заголовка поля вывода данных о приборах
            LblHeaderOrder.Text =
              $"{_appliancesController.Controller.Address}, приборы по состоянию\r\n";
        } // OrderByState_Command


        // сортировка коллекции приборов по мощности
        private void OrderByPower_Command(object sender, EventArgs e)
        {
            List<ElectricalAppliance> list = _appliancesController.OrderByPower();

            WriteTbcMainToListView(list);

            // делаем страницу отсортированных данных текущей
            TbcMain.SelectedTab = TbpOrdered;

            // формирование заголовка поля вывода данных о приборах
            LblHeaderOrder.Text =
              $"{_appliancesController.Controller.Address}, приборы по мощности\r\n";
        } // OrderByPower_Command


        // сортировка коллекции приборов по цене
        private void OrderByPrice_Command(object sender, EventArgs e)
        {
            List<ElectricalAppliance> list = _appliancesController.OrderByPrice();

            WriteTbcMainToListView(list);

            // делаем страницу отсортированных данных текущей
            TbcMain.SelectedTab = TbpOrdered;

            // формирование заголовка поля вывода данных о приборах
            LblHeaderOrder.Text =
              $"{_appliancesController.Controller.Address}, приборы по убыванию цены\r\n";
        } // OrderByPrice_Command
        #endregion

        #region Выборка записей
        // запись выбранной коллекции объектов в ListView для табличного отображения
        private void WriteSelectToListView(List<ElectricalAppliance> appliancelist)
        {
            LsvSelected.Items.Clear();
            foreach (var appliance in appliancelist)
            {
                // получить элемент для заполнения строки ListView, указать в нем данные 0го столбца 
                ListViewItem listViewItem = new ListViewItem("", (appliance.OffOnn ? 1 : 0));

                // добавить остальные столбцы
                listViewItem.SubItems.Add(appliance.Name);
                listViewItem.SubItems.Add($"{appliance.Power}");
                listViewItem.SubItems.Add($"{appliance.Price:f2}");

                // добавить строку в ListView
                LsvSelected.Items.Add(listViewItem);
            }// foreach appliance
        }// WriteTbcMainToListView

        // выборка приборов с заданным наименованием
        private void SelectApplicationName_Command(object sender, EventArgs e)
        {
            // получить список наименований из коллекции приборов
            List<string> names = _appliancesController.Controller.GetNameAppliance;

            // создание формы выбора прибора, передача в окно наименования приборов
            ChoiceForm choiceForm = new ChoiceForm(names);

            if (choiceForm.ShowDialog() != DialogResult.OK) return;

            // выбор прибора произведен, получим наименование, построим выборку
            SelectApplicationName(choiceForm.Names);
        } // SelectApplicationName_Command


        // выборка приборов с заданным состоянием
        private void SelectApplicationState_Command(object sender, EventArgs e)
        {
            // получить список состояний из коллекции приборов
            List<string> states = _appliancesController.GetStates();

            // создание формы выбора прибора, передача в окно состояние приборов
            ChoiceForm choiceForm = new ChoiceForm(states);

            if (choiceForm.ShowDialog() != DialogResult.OK) return;
            string state = choiceForm.Names;

            // выбор прибора произведен, получим состояние, построим выборку
            SelectApplicationState(state == "включен");
        } // SelectApplicationState_Command


        // формирование выборки приборов с заданным наименованием
        private void SelectApplicationName(string name)
        {
            // выбрать приборы с заданным наименованием
            List<ElectricalAppliance> list = _appliancesController.SelectWhereName(name);

            WriteSelectToListView(list);

            // делаем страницу выбранных данных текущей
            TbcMain.SelectedTab = TbpSelected;

            // изменить заголовок выбранных данных
            LblHeaderSelected.Text =
                 $"{_appliancesController.Controller.Address}, приборы c заданным наименованием\r\n";
        } // SelectApplicationName


        // формирование выборки приборов с заданным состоянием
        private void SelectApplicationState(bool state)
        {
            // выбрать приборы с заданным состоянием
            List<ElectricalAppliance> list = _appliancesController.SelectWhereState(state);

            WriteSelectToListView(list);

            // делаем страницу выбранных данных текущей
            TbcMain.SelectedTab = TbpSelected;

            // изменить заголовок выбранных данных
            LblHeaderSelected.Text =
                 $"{_appliancesController.Controller.Address}, приборы c заданным состоянием\r\n";
        } // SelectApplicationState
        #endregion


        // Включить выбранный прибор
        private void TurnOnAt_Command(object sender, EventArgs e)
        {            
            // если нет выбранных элементов - молча уходим
            if (LsvAppliance.SelectedIndices.Count == 0) return;

            int index = LsvAppliance.SelectedIndices[0];

            _appliancesController.Controller.TurnOnAt(index);

            WriteToListView();

            // обновить строку состояния
            StlMain.Text = $"Прибор включен. Текущее количество приборов: {_appliancesController.Controller.Count}";
        }// TurnOnAt_Command

        // Включить все приборы
        private void TurnOnAll_Command(object sender, EventArgs e)
        {
            _appliancesController.Controller.TurnOnAll();

            WriteToListView();

            // обновить строку состояния
            StlMain.Text = $"Все приборы включены. Текущее количество приборов: {_appliancesController.Controller.Count}";
        }// TurnOnAll_Command

        // Выключить выбранный прибор
        private void TurnOffAt_Command(object sender, EventArgs e)
        {
            // если нет выбранных элементов - молча уходим
            if (LsvAppliance.SelectedIndices.Count == 0) return;

            int index = LsvAppliance.SelectedIndices[0];

            _appliancesController.Controller.TurnOffAt(index);

            WriteToListView();

            // обновить строку состояния
            StlMain.Text = $"Прибор выключен. Текущее количество приборов: {_appliancesController.Controller.Count}";
        }// TurnOffAt_Command

        // Выключить все приборы
        private void TurnOffAll_Command(object sender, EventArgs e)
        {
            _appliancesController.Controller.TurnOffAll();

            WriteToListView();

            // обновить строку состояния
            StlMain.Text = $"Все приборы выключены. Текущее количество приборов: {_appliancesController.Controller.Count}";
        }// TurnOffAll_Command

        // Загрузка файла данных
        private void LoadFile_Command(object sender, EventArgs e)
        {
            if (OfdMain.ShowDialog() != DialogResult.OK) return;

            // загрузка данных в контроллер
            _appliancesController.DataFileName = OfdMain.FileName;
            _appliancesController.DeserializeData();

            WriteToListView(); 
            // вывести в строку состояния новые данные
            StlMain.Text = $"Приборов в квартире: {_appliancesController.Controller.Count}";
        } // LoadFile_Command

        // Сохранить файл данных с выбором имени файла
        private void SaveAsFile_Command(object sender, EventArgs e)
        {
            // выбор имени файла 
            if (SfdMain.ShowDialog() != DialogResult.OK) return;

            _appliancesController.DataFileName = SfdMain.FileName;
            _appliancesController.SerializeData();

            StlMain.Text = $"Данные сохранены в файле {_appliancesController.DataFileName}";
        } // SaveAsFile_Command

        private void Elements_DragEnter(object sender, DragEventArgs e)
        {
            e.Effect = e.Data.GetDataPresent(DataFormats.StringFormat) // строковые данные 
                || e.Data.GetDataPresent(DataFormats.FileDrop) ?  // файл данных - имя файла
                                                                  // DragDropEffects.All:    // разрешены все операции
                                                                  // DragDropEffects.Move:   // разрешена только операция Move
                DragDropEffects.Copy :     // разрешена только операция Copy
                DragDropEffects.None;
        }// Elements_DragEnter


        // Приемником перетаскивания сделаем строку ввода
        private void LsvAppliance_DragDrop(object sender, DragEventArgs e)
        {                      
           if (e.Data.GetDataPresent(DataFormats.StringFormat))
                
            // Прием текста
            LsvAppliance.Text = e.Data.GetData(DataFormats.StringFormat).ToString();
           else
           {
                string[] fileNames = (string[])e.Data.GetData(DataFormats.FileDrop);
                foreach (var file in fileNames) {                   
                    _appliancesController.DeserializeData();
                    //File.Copy(file, _appliancesController.DataFileName);
                    //LsvAppliance.Items.Add(file);

                    LsvAppliance.Text += File.ReadAllText(_appliancesController.DataFileName, Encoding.UTF8);
                    LsvAppliance.Items.Add(file);
                    WriteToListView();
                } // foreach
           } // if
        } // LsvAppliance_DragDrop


    }// class MainForm
}
