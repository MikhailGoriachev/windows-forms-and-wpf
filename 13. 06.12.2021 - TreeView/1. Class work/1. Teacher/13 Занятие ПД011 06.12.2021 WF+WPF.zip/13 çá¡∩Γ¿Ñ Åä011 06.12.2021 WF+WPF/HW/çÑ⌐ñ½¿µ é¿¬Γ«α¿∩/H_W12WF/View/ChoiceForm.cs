﻿using H_W12WF.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace H_W12WF.View
{
    public partial class ChoiceForm : Form
    {
        public ChoiceForm() : this(new List<string>()) { }
        public ChoiceForm(List<string> name)
        {
            InitializeComponent();

            
            CbxName.DataSource = name;
            CbxName.SelectedIndex = 0;
        }// ChoiceForm

        // вернуть выбранное наименование или состояние прибора
        public string Names => CbxName.Text;
    }// class ChoiceForm
}
