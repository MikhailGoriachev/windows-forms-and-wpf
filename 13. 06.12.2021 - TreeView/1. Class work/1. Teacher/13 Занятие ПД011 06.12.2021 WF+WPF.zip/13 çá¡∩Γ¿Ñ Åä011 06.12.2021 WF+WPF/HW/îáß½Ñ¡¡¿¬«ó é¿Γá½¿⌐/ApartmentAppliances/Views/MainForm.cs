﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Text;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ApartmentAppliances.Controllers;
using ApartmentAppliances.Models;
using ApartmentAppliances.Helpers;

namespace ApartmentAppliances.Views	
{
	public partial class MainForm : Form
	{
		// Объект контроллера для работы с коллекцией
		private ApplianceNetworkController _applianceNetworkController;


		// Конструкторы
		public MainForm():this(new ApplianceNetworkController())
		{}

		public MainForm(ApplianceNetworkController applianceNetworkController)
		{
			InitializeComponent();
			_applianceNetworkController = applianceNetworkController;

		}

		// Обработка при загрузке формы
		private void MainForm_Load(object sender, EventArgs e)
		{
			// Обновить содержимое ListView
			UpdateMainListViewAppliances();

			// Обновить заголовок окна
			UpdateMainTitle();

			GrbMain.Text = _applianceNetworkController.ApplianceNetwork.Name + ", адрес: " +
			               _applianceNetworkController.ApplianceNetwork.Address;

			StlLabel.Text = $"Устройств в сети: {_applianceNetworkController.ApplianceNetwork.Count}";
		}

		// Обновить содержимого ListView главной вкладки
		private void UpdateMainListViewAppliances() =>
			UpdateListView(LsvAppliances, _applianceNetworkController.Appliances);

		// Метод обновления ListView по параметрам
		private static void UpdateListView(ListView listView, List<Appliance> appliances)
		{
			listView.Items.Clear();

			if (appliances.Count == 0) return;

			appliances.ForEach(ap => listView.Items.Add(
				new ListViewItem(new[] { "", $"{ap.Name}", $"{ap.Power}", $"{ap.Price}" }, ap.State ? 1 : 0)));
		}

		
		// Обновление заголовка главной формы
		private void UpdateMainTitle()
		{
			// формировка заголовка с проверкой на наличией изменений с последнего сохранения
			StringBuilder sb = new StringBuilder();
			sb.Append(_applianceNetworkController.ApplianceNetwork.Name);
			//Path.GetFileNameWithoutExtension(_repairShopController.FileName));
			sb.Append(" - " + _applianceNetworkController.FileName);

			// установка заголовка в форму
			Text = sb.ToString();
		}

		// о программе
		private void About_Command(object sender, EventArgs e) => new AboutForm().ShowDialog();

		// выход из приложения
		private void Exit_Command(object sender, EventArgs e) => Application.Exit();

		// Команда отображения формы изменения данных о ремонтной мастерской
		private void NetworkSettings_Command(object sender, EventArgs e)
		{
			NetworkSettingsForm settingsForm =
				new NetworkSettingsForm(_applianceNetworkController.ApplianceNetwork.Name, 
					_applianceNetworkController.ApplianceNetwork.Address);

			if (settingsForm.ShowDialog() != DialogResult.OK) return;

			_applianceNetworkController.ApplianceNetwork.Name = settingsForm.Title;
			_applianceNetworkController.ApplianceNetwork.Address = settingsForm.Address;

			GrbMain.Text = _applianceNetworkController.ApplianceNetwork.Name + ". Адрес: " +
			               _applianceNetworkController.ApplianceNetwork.Address;

			UpdateMainTitle();

			SaveData();
		}

		#region Обработка ListView

		// установить выделение в ListView
		private void SetLsvSelectedIndex(int index)
		{
			if (index == -1) return;
			LsvAppliances.Items[index].Selected = true;
			LsvAppliances.Select();
			LsvAppliances.EnsureVisible(index);
		}

		// Обработка нажатий клавиш при фокусе ListView
		private void LsvAppliances_KeyDown(object sender, KeyEventArgs e)
		{
			if (e.KeyCode == Keys.Delete) DeleteAppliance_Command(sender, e);
			if (e.KeyCode == Keys.Enter) EditAppliance_Command(sender, e);
		}

		private void LsvAppliances_MouseDoubleClick(object sender, MouseEventArgs e) =>
			EditAppliance_Command(sender, e);

		private void TbcMain_SelectedIndexChanged(object sender, EventArgs e)
		{
			TstrAdd.Enabled = TstrEdit.Enabled = TstrDelete.Enabled = TstrDeleteAll.Enabled = 
			MnuEditAdd.Enabled = MnuEditEdit.Enabled = MnuEditDelete.Enabled = MnuEditDeleteAll.Enabled =
			TstrOn.Enabled = TstrOff.Enabled = MnuControlOnCurrent.Enabled = MnuControlOffCurrent.Enabled =
					TbcMain.SelectedTab == TbpMain;
		}

		#endregion


		#region Изменение коллекции электроприборов
		// сформировать коллекцию
		private void GenerateCollection_Command(object sender, EventArgs e)
		{
			_applianceNetworkController.ApplianceNetwork.Initialize();
			UpdateMainListViewAppliances();
			
			SaveData();

			TbcMain.SelectedTab = TbpMain;

			// обновить строку состояния
			StlLabel.Text = $"Коллекция приборов переформированна. Текущее количество электроприборов: " +
			                $"{_applianceNetworkController.ApplianceNetwork.Count}";
		}

		// добавить прибор
		private void Add_Command(object sender, EventArgs e)
		{
			ApplianceForm applianceForm = new ApplianceForm();

			// отмена добавления
			if (applianceForm.ShowDialog() != DialogResult.OK) 
				return;
			
			// доабвление прибора в текущую коллекцию
			_applianceNetworkController.AddAppliance(applianceForm.Appliance);

			// обновить главный listView
			UpdateMainListViewAppliances();

			// установка выделения в конец списка на новый элемент
			SetLsvSelectedIndex(LsvAppliances.Items.Count - 1);

			// обновить строку состояния
			StlLabel.Text = $"Добавлено устройство. Текущее количество электроприборов: " +
			               $"{_applianceNetworkController.ApplianceNetwork.Count}";

			// сохранение изменений в файл
			SaveData();
		}

		// удалить прибор
		private void DeleteAppliance_Command(object sender, EventArgs e)
		{
			if (LsvAppliances.SelectedIndices.Count == 0) return;

			// получить индекс выбранного элемента в ListView
			int index = LsvAppliances.SelectedIndices[0];

			string name = _applianceNetworkController.Appliances[index].Name;
			// удаление записи из коллекции и ListView
			_applianceNetworkController.RemoveAt(index);
			LsvAppliances.Items.RemoveAt(index);

			StlLabel.Text = $"Удалено устройство {name}." +
			                $" Текущее количество электроприборов: " +
			                $"{_applianceNetworkController.ApplianceNetwork.Count}";

			// Возврат выделения элемента на место удаленного, если возможно
			int count = LsvAppliances.Items.Count;
			SetLsvSelectedIndex(count != 0 ? (index < count ? index : count - 1) : -1);

			// сохранение изменений в файл
			SaveData();
		}

		// удалить все приборы
		private void DeleteAllAppliances_Command(object sender, EventArgs e)
		{
			// очистка коллекции и listView
			_applianceNetworkController.RemoveAll();
			LsvAppliances.Items.Clear();

			StlLabel.Text = "Все устройства удалены.";

			// сохранение изменений в файл
			SaveData();
		}

		private void EditAppliance_Command(object sender, EventArgs e)
		{
			if (LsvAppliances.SelectedIndices.Count == 0) return;

			// получить индекс выбранного элемента в ListView
			int index = LsvAppliances.SelectedIndices[0];

			// передача данных в форму
			ApplianceForm applianceForm = new ApplianceForm("Редактировать данные электроприбора", "Сохранить")
			{
				Appliance = _applianceNetworkController.ApplianceNetwork[index]
			};

			// проверка на подтверджение изменения данных
			if (applianceForm.ShowDialog() != DialogResult.OK)
				return;

			_applianceNetworkController.ApplianceNetwork[index] = applianceForm.Appliance;

			UpdateMainListViewAppliances();

			SetLsvSelectedIndex(index);

			StlLabel.Text = $"Данные об электроприборе изменены." +
			                $" Текущее количество электроприборов: " +
			                $"{_applianceNetworkController.ApplianceNetwork.Count}";

			SaveData();
		}

		#endregion


		#region Сортировки

		// сортировка по названию
		private void OrderByName_Command(object sender, EventArgs e) =>
			Order(ApplianceNetworkController.OrderByName, "Приборы отсортированны по названию");

		// сотировка по мощности
		private void OrderByPower_Command(object sender, EventArgs e) =>
			Order(ApplianceNetworkController.OrderByPower, "Приборы отсортированны по мощности");

		// сотировка по состоянию
		private void OrderByPower_State(object sender, EventArgs e) =>
			Order(ApplianceNetworkController.OrderByState, "Приборы отсортированны по состоянию");

		// сортировка по убыванию цены
		private void OrderByPriceDesc_State(object sender, EventArgs e) =>
			Order(ApplianceNetworkController.OrderByPriceDesc, "Приборы отсортированны по убыванию цены");

		// метод сортировки копии и вывода в соответствующий listView
		private void Order(Action<List<Appliance>> sorter, string prompt)
		{
			// получить копию коллекции
			List<Appliance> appliances = _applianceNetworkController.Appliances;
			// сортировка копии
			sorter(appliances);
			// отобразить отсортированные элементы в соответствующем listView
			UpdateListView(LsvSorted, appliances);
			// изменение информации о сортировке
			GrbSorted.Text = prompt;
			// установока фокуса на вкладку с оттсортированной коллекции
			TbcMain.SelectedTab = TbpOrder;
		}

		#endregion


		#region Управление состоянием

		// включить все приборы
		private void OnAll_Command(object sender, EventArgs e)
		{
			_applianceNetworkController.TurnOnAll();
			UpdateMainListViewAppliances();

			TbcMain.SelectedTab = TbpMain;
		}


		// включить выбранный прибор
		private void OnCurrent_Command(object sender, EventArgs e)
		{
			if (LsvAppliances.SelectedIndices.Count == 0) return;

			int index = LsvAppliances.SelectedIndices[0];
			_applianceNetworkController.TurnOnAt(index);
			
			UpdateMainListViewAppliances();
			
			SetLsvSelectedIndex(index);
			
			TbcMain.SelectedTab = TbpMain;
		}

		// выключить все приборы
		private void OffAll_Command(object sender, EventArgs e)
		{
			_applianceNetworkController.TurnOffAll();
			UpdateMainListViewAppliances();
			
			TbcMain.SelectedTab = TbpMain;
		}

		// выключить выбранный прибор
		private void OffCurrent_Command(object sender, EventArgs e)
		{
			if (LsvAppliances.SelectedIndices.Count == 0) return;

			int index = LsvAppliances.SelectedIndices[0];
			_applianceNetworkController.TurnOffAt(index);

			UpdateMainListViewAppliances();
			SetLsvSelectedIndex(index);

			TbcMain.SelectedTab = TbpMain;
		}

		#endregion


		#region Выборки

		// Выборка по названию прибора
		private void SelectWhereName_Command(object sender, EventArgs e)
		{
			// Получение списка мастеров
			List<string> names = _applianceNetworkController.ApplianceNetwork.GetAppliancesNames();

			// Создание формы выбора названия
			SelectingForm selectingForm = new SelectingForm(names, "Выберите название прибора:");

			if (selectingForm.ShowDialog() != DialogResult.OK) return;

			List<Appliance> selected = _applianceNetworkController.SelectWhereName(selectingForm.Choosen);

			UpdateListView(LsvSelect, selected);

			GrbSelect.Text = $"Отобраны приборы с названием {selectingForm.Choosen}";

			TbcMain.SelectedTab = TbpSelect;
		}

		// Выборка по состоянию прибора
		private void SelectWhereState_Command(object sender, EventArgs e)
		{
			// Создание формы выбора состояния
			SelectingForm selectingForm = new SelectingForm();

			if (selectingForm.ShowDialog() != DialogResult.OK) return;

			List<Appliance> selected = _applianceNetworkController.SelectWhereState(selectingForm.Choosen != "выключено");

			UpdateListView(LsvSelect, selected);

			GrbSelect.Text = $"Отобраны приборы с названием {selectingForm.Choosen}";

			TbcMain.SelectedTab = TbpSelect;
		}

		#endregion


		#region Сохранение\загрузка
		private void SaveData() => _applianceNetworkController.SaveJsonToFile(_applianceNetworkController.FileName);

		// Обработка команды "сохранить"
		private void Save_Command(object sender, EventArgs e)
		{
			SaveData();
			StlLabel.Text = $"Данные сохранены в файл {_applianceNetworkController.FileName}";
		}

		// Обработка команды "сохранить как"
		private void SaveAs_Command(object sender, EventArgs e)
		{
			// установка директории для выбора файла 
			SfdMain.InitialDirectory = Path.GetDirectoryName(_applianceNetworkController.FileName);

			if (SfdMain.ShowDialog() != DialogResult.OK) return;

			_applianceNetworkController.FileName = SfdMain.FileName;
			_applianceNetworkController.SaveJsonToFile(_applianceNetworkController.FileName);

			StlLabel.Text = $"Данные сохранены в файл {_applianceNetworkController.FileName}";
		}


		// Команда открытия файла
		private void FileOpen_Command(object sender, EventArgs e)
		{
			// установка директории для выбора файла 
			OfdMain.InitialDirectory = Path.GetDirectoryName(_applianceNetworkController.FileName);

			// запуск диалогового окна открытия и проверка на результат
			if (OfdMain.ShowDialog() != DialogResult.OK) return;


			_applianceNetworkController.FileName = OfdMain.FileName;
			_applianceNetworkController.ReadJsonFromFile(_applianceNetworkController.FileName);

			UpdateMainListViewAppliances();

			StlLabel.Text = $"Данные загружены из файла {_applianceNetworkController.FileName}";

			GrbMain.Text = _applianceNetworkController.ApplianceNetwork.Name + ", адрес: " +
			               _applianceNetworkController.ApplianceNetwork.Address;

			UpdateMainTitle();
		}

		// Команда создания нового файла коллекции
		private void FileNew_Command(object sender, EventArgs e)
		{
			SaveAs_Command(sender, e);

			NetworkSettings_Command(sender, e);

			// Очистить данные и обновить листбокс
			_applianceNetworkController.ApplianceNetwork.Initialize();
			UpdateMainListViewAppliances();
		}

		#endregion


		#region Команды для трея
		// Команда сворачивания в трей
		private void ToTray_Command(object sender, EventArgs e)
		{
			this.Hide();
			NtiMain.BalloonTipText = _applianceNetworkController.ApplianceNetwork.Name;
			NtiMain.Visible = true;
		}

		// Команда востановления из трея
		private void Restore_Command(object sender, EventArgs e)
		{
			this.Show();
			WindowState = FormWindowState.Normal;
			NtiMain.Visible = false;
		}

		// Восстановление из трея по дабл-клику
		private void CmnTray_MouseDoubleClick(object sender, MouseEventArgs e) =>
			Restore_Command(sender, e);


		#endregion


		#region Смена шрифта и фона

		// Команда смены шрифта
		private void Font_Command(object sender, EventArgs e)
		{
			if (FdlTextFont.ShowDialog() == DialogResult.OK)
				SetFont();
		}

		// Обработка кнопки применить в диалоге смены шрифта
		private void FdlTextFont_Apply(object sender, EventArgs e) => SetFont();

		// Непосредственно установка значения фона
		public void SetFont() => LsvAppliances.Font = FdlTextFont.Font;

		// Команда смены цвета фона
		private void BackColor_Command(object sender, EventArgs e)
		{
			if (CdlBackColor.ShowDialog() == DialogResult.OK)
				LsvAppliances.BackColor = CdlBackColor.Color;
		}

		// Команда смены цвета текста
		private void ForeColor_Command(object sender, EventArgs e)
		{
			if (CdlBackColor.ShowDialog() == DialogResult.OK)
				LsvAppliances.ForeColor = CdlBackColor.Color;
		}
		#endregion

		private void LsvAppliances_DragEnter(object sender, DragEventArgs e) =>
			e.Effect = e.Data.GetDataPresent(DataFormats.FileDrop) ? DragDropEffects.Move : DragDropEffects.None;
		
		private void LsvAppliances_DragOver(object sender, DragEventArgs e)
		{

		}

		private void LsvAppliances_DragLeave(object sender, EventArgs e)
		{

		}

		private void LsvAppliances_DragDrop(object sender, DragEventArgs e)
		{
			if (!e.Data.GetDataPresent(DataFormats.FileDrop))
				return;

			var data = e.Data.GetData(DataFormats.FileDrop) as string[];

			_applianceNetworkController.ReadJsonFromFile(data[0]);

			UpdateMainTitle();
			UpdateMainListViewAppliances();

			GrbMain.Text = _applianceNetworkController.ApplianceNetwork.Name + ", адрес: " +
			               _applianceNetworkController.ApplianceNetwork.Address;

			StlLabel.Text = $"Данные загружены из файла {_applianceNetworkController.FileName}";
		}

	}
}
