﻿
namespace ApartmentAppliances.Views
{
	partial class ApplianceForm
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.GrbAddAppliance = new System.Windows.Forms.GroupBox();
			this.BtnCancel = new System.Windows.Forms.Button();
			this.TxbName = new System.Windows.Forms.TextBox();
			this.BtnAdd = new System.Windows.Forms.Button();
			this.CbxState = new System.Windows.Forms.ComboBox();
			this.NudPrice = new System.Windows.Forms.NumericUpDown();
			this.NudPower = new System.Windows.Forms.NumericUpDown();
			this.LblState = new System.Windows.Forms.Label();
			this.LblPrice = new System.Windows.Forms.Label();
			this.LblPower = new System.Windows.Forms.Label();
			this.LblName = new System.Windows.Forms.Label();
			this.GrbAddAppliance.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.NudPrice)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.NudPower)).BeginInit();
			this.SuspendLayout();
			// 
			// GrbAddAppliance
			// 
			this.GrbAddAppliance.Controls.Add(this.BtnCancel);
			this.GrbAddAppliance.Controls.Add(this.TxbName);
			this.GrbAddAppliance.Controls.Add(this.BtnAdd);
			this.GrbAddAppliance.Controls.Add(this.CbxState);
			this.GrbAddAppliance.Controls.Add(this.NudPrice);
			this.GrbAddAppliance.Controls.Add(this.NudPower);
			this.GrbAddAppliance.Controls.Add(this.LblState);
			this.GrbAddAppliance.Controls.Add(this.LblPrice);
			this.GrbAddAppliance.Controls.Add(this.LblPower);
			this.GrbAddAppliance.Controls.Add(this.LblName);
			this.GrbAddAppliance.Location = new System.Drawing.Point(9, 8);
			this.GrbAddAppliance.Name = "GrbAddAppliance";
			this.GrbAddAppliance.Size = new System.Drawing.Size(280, 292);
			this.GrbAddAppliance.TabIndex = 10;
			this.GrbAddAppliance.TabStop = false;
			// 
			// BtnCancel
			// 
			this.BtnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.BtnCancel.Location = new System.Drawing.Point(144, 240);
			this.BtnCancel.Name = "BtnCancel";
			this.BtnCancel.Size = new System.Drawing.Size(112, 32);
			this.BtnCancel.TabIndex = 6;
			this.BtnCancel.Text = "Отмена";
			this.BtnCancel.UseVisualStyleBackColor = true;
			// 
			// TxbName
			// 
			this.TxbName.Location = new System.Drawing.Point(120, 32);
			this.TxbName.Name = "TxbName";
			this.TxbName.Size = new System.Drawing.Size(136, 24);
			this.TxbName.TabIndex = 1;
			// 
			// BtnAdd
			// 
			this.BtnAdd.BackColor = System.Drawing.SystemColors.Control;
			this.BtnAdd.DialogResult = System.Windows.Forms.DialogResult.OK;
			this.BtnAdd.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.BtnAdd.Location = new System.Drawing.Point(8, 240);
			this.BtnAdd.Name = "BtnAdd";
			this.BtnAdd.Size = new System.Drawing.Size(112, 32);
			this.BtnAdd.TabIndex = 5;
			this.BtnAdd.Text = "Добавить";
			this.BtnAdd.UseVisualStyleBackColor = false;
			this.BtnAdd.Click += new System.EventHandler(this.BtnAdd_Click);
			// 
			// CbxState
			// 
			this.CbxState.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.CbxState.FormattingEnabled = true;
			this.CbxState.Items.AddRange(new object[] {
            "выключен",
            "включен"});
			this.CbxState.Location = new System.Drawing.Point(120, 182);
			this.CbxState.Name = "CbxState";
			this.CbxState.Size = new System.Drawing.Size(136, 26);
			this.CbxState.TabIndex = 4;
			// 
			// NudPrice
			// 
			this.NudPrice.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.NudPrice.Location = new System.Drawing.Point(120, 138);
			this.NudPrice.Maximum = new decimal(new int[] {
            1874919424,
            2328306,
            0,
            0});
			this.NudPrice.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
			this.NudPrice.Name = "NudPrice";
			this.NudPrice.Size = new System.Drawing.Size(136, 26);
			this.NudPrice.TabIndex = 3;
			this.NudPrice.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.NudPrice.ThousandsSeparator = true;
			this.NudPrice.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
			this.NudPrice.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Nud_KeyDown);
			// 
			// NudPower
			// 
			this.NudPower.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.NudPower.Location = new System.Drawing.Point(120, 86);
			this.NudPower.Maximum = new decimal(new int[] {
            1874919424,
            2328306,
            0,
            0});
			this.NudPower.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
			this.NudPower.Name = "NudPower";
			this.NudPower.Size = new System.Drawing.Size(136, 26);
			this.NudPower.TabIndex = 2;
			this.NudPower.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.NudPower.ThousandsSeparator = true;
			this.NudPower.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
			this.NudPower.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Nud_KeyDown);
			// 
			// LblState
			// 
			this.LblState.AutoSize = true;
			this.LblState.Font = new System.Drawing.Font("Segoe UI", 11.25F);
			this.LblState.Location = new System.Drawing.Point(16, 190);
			this.LblState.Name = "LblState";
			this.LblState.Size = new System.Drawing.Size(95, 20);
			this.LblState.TabIndex = 11;
			this.LblState.Text = "Сосотояние:";
			// 
			// LblPrice
			// 
			this.LblPrice.AutoSize = true;
			this.LblPrice.Font = new System.Drawing.Font("Segoe UI", 11.25F);
			this.LblPrice.Location = new System.Drawing.Point(16, 138);
			this.LblPrice.Name = "LblPrice";
			this.LblPrice.Size = new System.Drawing.Size(48, 20);
			this.LblPrice.TabIndex = 10;
			this.LblPrice.Text = "Цена:";
			// 
			// LblPower
			// 
			this.LblPower.AutoSize = true;
			this.LblPower.Font = new System.Drawing.Font("Segoe UI", 11.25F);
			this.LblPower.Location = new System.Drawing.Point(16, 86);
			this.LblPower.Name = "LblPower";
			this.LblPower.Size = new System.Drawing.Size(85, 20);
			this.LblPower.TabIndex = 9;
			this.LblPower.Text = "Мощность:";
			// 
			// LblName
			// 
			this.LblName.AutoSize = true;
			this.LblName.Font = new System.Drawing.Font("Segoe UI", 11.25F);
			this.LblName.Location = new System.Drawing.Point(16, 34);
			this.LblName.Name = "LblName";
			this.LblName.Size = new System.Drawing.Size(80, 20);
			this.LblName.TabIndex = 8;
			this.LblName.Text = "Название:";
			// 
			// ApplianceForm
			// 
			this.AcceptButton = this.BtnAdd;
			this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
			this.CancelButton = this.BtnCancel;
			this.ClientSize = new System.Drawing.Size(298, 308);
			this.Controls.Add(this.GrbAddAppliance);
			this.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.MaximizeBox = false;
			this.Name = "ApplianceForm";
			this.ShowInTaskbar = false;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Прибор";
			this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.TVForm_FormClosing);
			this.Load += new System.EventHandler(this.ApplianceForm_Load);
			this.GrbAddAppliance.ResumeLayout(false);
			this.GrbAddAppliance.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.NudPrice)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.NudPower)).EndInit();
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.GroupBox GrbAddAppliance;
		private System.Windows.Forms.Button BtnCancel;
		private System.Windows.Forms.TextBox TxbName;
		private System.Windows.Forms.Button BtnAdd;
		private System.Windows.Forms.ComboBox CbxState;
		private System.Windows.Forms.NumericUpDown NudPrice;
		private System.Windows.Forms.NumericUpDown NudPower;
		private System.Windows.Forms.Label LblState;
		private System.Windows.Forms.Label LblPrice;
		private System.Windows.Forms.Label LblPower;
		private System.Windows.Forms.Label LblName;
	}
}