﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ApartmentAppliances.Models;

namespace ApartmentAppliances.Views
{
	public partial class ApplianceForm : Form
	{
		private Appliance _appliance;

		public Appliance Appliance
		{
			get => _appliance;
			set
			{
				_appliance = value;
				TxbName.Text = _appliance.Name;
				NudPower.Value = _appliance.Power;
				NudPrice.Value = _appliance.Price;
				CbxState.SelectedIndex = _appliance.State ? 1 : 0;
			}
		}

		// Конструктор по умолчанию для ситуации добавления 
		public ApplianceForm()
		{
			InitializeComponent();
			_appliance = new Appliance();
		}

		// Конструктор с параметарми для ситуации изменения
		public ApplianceForm(string formTitle, string btnTitle)
		{
			InitializeComponent();
			_appliance = new Appliance();
			
			// Заголовок формы и кнопки
			Text = formTitle;
			BtnAdd.Text = btnTitle;

		}

		private void ApplianceForm_Load(object sender, EventArgs e) =>
				CbxState.SelectedIndex = 0;

		// Обработчик кнопки "Добавить"/"Сохранить" - собрать данные из элементов
		// интерфейса
		private void BtnAdd_Click(object sender, EventArgs e)
		{
			if (IsEmptyFields()) return;

			_appliance = new Appliance()
			{
				Name = TxbName.Text,
				Power = (int)NudPower.Value,
				Price = (int)NudPrice.Value,
				State = CbxState.SelectedIndex != 0
			};

		}

		// Не даём закрыться окну по кнопке подтверждения, если есть пустые поля
		private void TVForm_FormClosing(object sender, FormClosingEventArgs e)
		{
			if ((DialogResult == DialogResult.OK) & IsEmptyFields())
			{
				MessageBox.Show("Не все данные заполнены", "Ошибка",
					MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				e.Cancel = true;
			}
		}
		public bool IsEmptyFields() =>
			string.IsNullOrWhiteSpace(TxbName.Text) ||
			string.IsNullOrWhiteSpace(NudPower.Text) ||
			string.IsNullOrWhiteSpace(NudPrice.Text);

		private void Nud_KeyDown(object sender, KeyEventArgs e) =>
			e.SuppressKeyPress = e.KeyData == Keys.OemMinus || e.KeyData == Keys.Subtract;

	}
}

