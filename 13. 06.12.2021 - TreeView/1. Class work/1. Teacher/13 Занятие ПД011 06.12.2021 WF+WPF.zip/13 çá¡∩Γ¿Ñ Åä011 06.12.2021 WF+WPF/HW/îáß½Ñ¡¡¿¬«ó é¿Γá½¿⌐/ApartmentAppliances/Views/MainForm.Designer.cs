﻿
namespace ApartmentAppliances.Views
{
	partial class MainForm
	{
		/// <summary>
		/// Обязательная переменная конструктора.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Освободить все используемые ресурсы.
		/// </summary>
		/// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Код, автоматически созданный конструктором форм Windows

		/// <summary>
		/// Требуемый метод для поддержки конструктора — не изменяйте 
		/// содержимое этого метода с помощью редактора кода.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
			this.MnuMain = new System.Windows.Forms.MenuStrip();
			this.MnuFile = new System.Windows.Forms.ToolStripMenuItem();
			this.MnuFileNew = new System.Windows.Forms.ToolStripMenuItem();
			this.MnuFileOpen = new System.Windows.Forms.ToolStripMenuItem();
			this.MnuFileSave = new System.Windows.Forms.ToolStripMenuItem();
			this.MnuFileSaveAs = new System.Windows.Forms.ToolStripMenuItem();
			this.toolStripSeparator6 = new System.Windows.Forms.ToolStripSeparator();
			this.MnuFileExit = new System.Windows.Forms.ToolStripMenuItem();
			this.MnuEdit = new System.Windows.Forms.ToolStripMenuItem();
			this.MnuEditGenerate = new System.Windows.Forms.ToolStripMenuItem();
			this.separatorToolStripMenuItem = new System.Windows.Forms.ToolStripSeparator();
			this.MnuEditAdd = new System.Windows.Forms.ToolStripMenuItem();
			this.MnuEditEdit = new System.Windows.Forms.ToolStripMenuItem();
			this.toolStripSeparator7 = new System.Windows.Forms.ToolStripSeparator();
			this.MnuEditDelete = new System.Windows.Forms.ToolStripMenuItem();
			this.MnuEditDeleteAll = new System.Windows.Forms.ToolStripMenuItem();
			this.MnuControl = new System.Windows.Forms.ToolStripMenuItem();
			this.MnuControlOnCurrent = new System.Windows.Forms.ToolStripMenuItem();
			this.MnuControlOffCurrent = new System.Windows.Forms.ToolStripMenuItem();
			this.ъToolStripMenuItem = new System.Windows.Forms.ToolStripSeparator();
			this.MnuControlOnAll = new System.Windows.Forms.ToolStripMenuItem();
			this.MnuControlOffAll = new System.Windows.Forms.ToolStripMenuItem();
			this.MnuOrder = new System.Windows.Forms.ToolStripMenuItem();
			this.MnuOrderByName = new System.Windows.Forms.ToolStripMenuItem();
			this.MnuOrderByPower = new System.Windows.Forms.ToolStripMenuItem();
			this.поСостояниюToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.поУбыванииюЦеныToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.MnuSelectWhere = new System.Windows.Forms.ToolStripMenuItem();
			this.MnuSelectWhereName = new System.Windows.Forms.ToolStripMenuItem();
			this.MnuSelectWhereState = new System.Windows.Forms.ToolStripMenuItem();
			this.MnuSettings = new System.Windows.Forms.ToolStripMenuItem();
			this.MnuSettingsEditNetworkInfo = new System.Windows.Forms.ToolStripMenuItem();
			this.toolStripSeparator9 = new System.Windows.Forms.ToolStripSeparator();
			this.MnuSettingsFont = new System.Windows.Forms.ToolStripMenuItem();
			this.MnuSettingsBackColor = new System.Windows.Forms.ToolStripMenuItem();
			this.MnuSettingsForeColor = new System.Windows.Forms.ToolStripMenuItem();
			this.MnuHelp = new System.Windows.Forms.ToolStripMenuItem();
			this.MnuHelpAbout = new System.Windows.Forms.ToolStripMenuItem();
			this.MnuToTray = new System.Windows.Forms.ToolStripMenuItem();
			this.CmnForm = new System.Windows.Forms.ContextMenuStrip(this.components);
			this.файлToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.выходToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.TsbMain = new System.Windows.Forms.ToolStrip();
			this.TbsNew = new System.Windows.Forms.ToolStripButton();
			this.TbsFileOpen = new System.Windows.Forms.ToolStripButton();
			this.TbsSave = new System.Windows.Forms.ToolStripButton();
			this.TbsSaveAs = new System.Windows.Forms.ToolStripButton();
			this.toolStripSeparator8 = new System.Windows.Forms.ToolStripSeparator();
			this.TstrGenerate = new System.Windows.Forms.ToolStripButton();
			this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
			this.TstrAdd = new System.Windows.Forms.ToolStripButton();
			this.TstrEdit = new System.Windows.Forms.ToolStripButton();
			this.TstrDelete = new System.Windows.Forms.ToolStripButton();
			this.TstrDeleteAll = new System.Windows.Forms.ToolStripButton();
			this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
			this.TstrOn = new System.Windows.Forms.ToolStripButton();
			this.TstrOff = new System.Windows.Forms.ToolStripButton();
			this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
			this.TstrOnAll = new System.Windows.Forms.ToolStripButton();
			this.TstrOffAll = new System.Windows.Forms.ToolStripButton();
			this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
			this.TstrOrderBy = new System.Windows.Forms.ToolStripDropDownButton();
			this.TstrOrderByName = new System.Windows.Forms.ToolStripMenuItem();
			this.TstrOrderByPower = new System.Windows.Forms.ToolStripMenuItem();
			this.TstrOrderByState = new System.Windows.Forms.ToolStripMenuItem();
			this.TstrOrderByPriceDesc = new System.Windows.Forms.ToolStripMenuItem();
			this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
			this.TsbExit = new System.Windows.Forms.ToolStripButton();
			this.TstrAbout = new System.Windows.Forms.ToolStripButton();
			this.TstrSelectWhere = new System.Windows.Forms.ToolStripDropDownButton();
			this.TstrSelectWhereName = new System.Windows.Forms.ToolStripMenuItem();
			this.TstrSelectWhereState = new System.Windows.Forms.ToolStripMenuItem();
			this.GrbMain = new System.Windows.Forms.GroupBox();
			this.LsvAppliances = new System.Windows.Forms.ListView();
			this.ClhState = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
			this.ClhName = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
			this.ClhPower = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
			this.ClhPrice = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
			this.CmnListView = new System.Windows.Forms.ContextMenuStrip(this.components);
			this.CmnListViewAdd = new System.Windows.Forms.ToolStripMenuItem();
			this.CmnListViewEdit = new System.Windows.Forms.ToolStripMenuItem();
			this.CmnListViewRemove = new System.Windows.Forms.ToolStripMenuItem();
			this.ImlStates = new System.Windows.Forms.ImageList(this.components);
			this.LblAppliances = new System.Windows.Forms.Label();
			this.TbcMain = new System.Windows.Forms.TabControl();
			this.TbpMain = new System.Windows.Forms.TabPage();
			this.TbpOrder = new System.Windows.Forms.TabPage();
			this.GrbSorted = new System.Windows.Forms.GroupBox();
			this.LsvSorted = new System.Windows.Forms.ListView();
			this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
			this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
			this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
			this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
			this.LblSorted = new System.Windows.Forms.Label();
			this.TbpSelect = new System.Windows.Forms.TabPage();
			this.GrbSelect = new System.Windows.Forms.GroupBox();
			this.LsvSelect = new System.Windows.Forms.ListView();
			this.columnHeader5 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
			this.columnHeader6 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
			this.columnHeader7 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
			this.columnHeader8 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
			this.LblSelect = new System.Windows.Forms.Label();
			this.ImlTabs = new System.Windows.Forms.ImageList(this.components);
			this.SfdMain = new System.Windows.Forms.SaveFileDialog();
			this.OfdMain = new System.Windows.Forms.OpenFileDialog();
			this.StlMain = new System.Windows.Forms.StatusStrip();
			this.StlLabel = new System.Windows.Forms.ToolStripStatusLabel();
			this.CmnTray = new System.Windows.Forms.ContextMenuStrip(this.components);
			this.CmnTrayRestore = new System.Windows.Forms.ToolStripMenuItem();
			this.CmnTrayAbout = new System.Windows.Forms.ToolStripMenuItem();
			this.toolStripSeparator11 = new System.Windows.Forms.ToolStripSeparator();
			this.CmnTrayExit = new System.Windows.Forms.ToolStripMenuItem();
			this.NtiMain = new System.Windows.Forms.NotifyIcon(this.components);
			this.FdlTextFont = new System.Windows.Forms.FontDialog();
			this.CdlBackColor = new System.Windows.Forms.ColorDialog();
			this.MnuMain.SuspendLayout();
			this.CmnForm.SuspendLayout();
			this.TsbMain.SuspendLayout();
			this.GrbMain.SuspendLayout();
			this.CmnListView.SuspendLayout();
			this.TbcMain.SuspendLayout();
			this.TbpMain.SuspendLayout();
			this.TbpOrder.SuspendLayout();
			this.GrbSorted.SuspendLayout();
			this.TbpSelect.SuspendLayout();
			this.GrbSelect.SuspendLayout();
			this.StlMain.SuspendLayout();
			this.CmnTray.SuspendLayout();
			this.SuspendLayout();
			// 
			// MnuMain
			// 
			this.MnuMain.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
			this.MnuMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MnuFile,
            this.MnuEdit,
            this.MnuControl,
            this.MnuOrder,
            this.MnuSelectWhere,
            this.MnuSettings,
            this.MnuHelp,
            this.MnuToTray});
			this.MnuMain.Location = new System.Drawing.Point(0, 0);
			this.MnuMain.Margin = new System.Windows.Forms.Padding(6, 0, 0, 4);
			this.MnuMain.Name = "MnuMain";
			this.MnuMain.Padding = new System.Windows.Forms.Padding(7, 2, 0, 2);
			this.MnuMain.Size = new System.Drawing.Size(716, 26);
			this.MnuMain.TabIndex = 6;
			this.MnuMain.Text = "menuStrip1";
			// 
			// MnuFile
			// 
			this.MnuFile.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MnuFileNew,
            this.MnuFileOpen,
            this.MnuFileSave,
            this.MnuFileSaveAs,
            this.toolStripSeparator6,
            this.MnuFileExit});
			this.MnuFile.Name = "MnuFile";
			this.MnuFile.Size = new System.Drawing.Size(58, 22);
			this.MnuFile.Text = "Файл";
			// 
			// MnuFileNew
			// 
			this.MnuFileNew.Image = global::ApartmentAppliances.Properties.Resources.file_new;
			this.MnuFileNew.Name = "MnuFileNew";
			this.MnuFileNew.Size = new System.Drawing.Size(295, 22);
			this.MnuFileNew.Text = "Новая сеть электроприборов...";
			this.MnuFileNew.Click += new System.EventHandler(this.FileNew_Command);
			// 
			// MnuFileOpen
			// 
			this.MnuFileOpen.Image = global::ApartmentAppliances.Properties.Resources.file_open;
			this.MnuFileOpen.Name = "MnuFileOpen";
			this.MnuFileOpen.Size = new System.Drawing.Size(295, 22);
			this.MnuFileOpen.Text = "Открыть...";
			this.MnuFileOpen.Click += new System.EventHandler(this.FileOpen_Command);
			// 
			// MnuFileSave
			// 
			this.MnuFileSave.Image = global::ApartmentAppliances.Properties.Resources.file_save;
			this.MnuFileSave.Name = "MnuFileSave";
			this.MnuFileSave.Size = new System.Drawing.Size(295, 22);
			this.MnuFileSave.Text = "Сохранить";
			this.MnuFileSave.Click += new System.EventHandler(this.Save_Command);
			// 
			// MnuFileSaveAs
			// 
			this.MnuFileSaveAs.Image = global::ApartmentAppliances.Properties.Resources.file_saveas;
			this.MnuFileSaveAs.Name = "MnuFileSaveAs";
			this.MnuFileSaveAs.Size = new System.Drawing.Size(295, 22);
			this.MnuFileSaveAs.Text = "Сохранить как ...";
			this.MnuFileSaveAs.Click += new System.EventHandler(this.SaveAs_Command);
			// 
			// toolStripSeparator6
			// 
			this.toolStripSeparator6.Name = "toolStripSeparator6";
			this.toolStripSeparator6.Size = new System.Drawing.Size(292, 6);
			// 
			// MnuFileExit
			// 
			this.MnuFileExit.Image = global::ApartmentAppliances.Properties.Resources.exit;
			this.MnuFileExit.Name = "MnuFileExit";
			this.MnuFileExit.Size = new System.Drawing.Size(295, 22);
			this.MnuFileExit.Text = "Выход";
			this.MnuFileExit.Click += new System.EventHandler(this.Exit_Command);
			// 
			// MnuEdit
			// 
			this.MnuEdit.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MnuEditGenerate,
            this.separatorToolStripMenuItem,
            this.MnuEditAdd,
            this.MnuEditEdit,
            this.toolStripSeparator7,
            this.MnuEditDelete,
            this.MnuEditDeleteAll});
			this.MnuEdit.Name = "MnuEdit";
			this.MnuEdit.Size = new System.Drawing.Size(71, 22);
			this.MnuEdit.Text = "Правка";
			// 
			// MnuEditGenerate
			// 
			this.MnuEditGenerate.Image = global::ApartmentAppliances.Properties.Resources.regenerate;
			this.MnuEditGenerate.Name = "MnuEditGenerate";
			this.MnuEditGenerate.Size = new System.Drawing.Size(266, 22);
			this.MnuEditGenerate.Text = "Сформировать коллекцию";
			this.MnuEditGenerate.Click += new System.EventHandler(this.GenerateCollection_Command);
			// 
			// separatorToolStripMenuItem
			// 
			this.separatorToolStripMenuItem.Name = "separatorToolStripMenuItem";
			this.separatorToolStripMenuItem.Size = new System.Drawing.Size(263, 6);
			// 
			// MnuEditAdd
			// 
			this.MnuEditAdd.Image = global::ApartmentAppliances.Properties.Resources.add;
			this.MnuEditAdd.Name = "MnuEditAdd";
			this.MnuEditAdd.Size = new System.Drawing.Size(266, 22);
			this.MnuEditAdd.Text = "Добавить прибор";
			this.MnuEditAdd.Click += new System.EventHandler(this.Add_Command);
			// 
			// MnuEditEdit
			// 
			this.MnuEditEdit.Image = global::ApartmentAppliances.Properties.Resources.edit;
			this.MnuEditEdit.Name = "MnuEditEdit";
			this.MnuEditEdit.Size = new System.Drawing.Size(266, 22);
			this.MnuEditEdit.Text = "Изменить прибор";
			this.MnuEditEdit.Click += new System.EventHandler(this.EditAppliance_Command);
			// 
			// toolStripSeparator7
			// 
			this.toolStripSeparator7.Name = "toolStripSeparator7";
			this.toolStripSeparator7.Size = new System.Drawing.Size(263, 6);
			// 
			// MnuEditDelete
			// 
			this.MnuEditDelete.Image = global::ApartmentAppliances.Properties.Resources.remove;
			this.MnuEditDelete.Name = "MnuEditDelete";
			this.MnuEditDelete.Size = new System.Drawing.Size(266, 22);
			this.MnuEditDelete.Text = "Удалить прибор";
			this.MnuEditDelete.Click += new System.EventHandler(this.DeleteAppliance_Command);
			// 
			// MnuEditDeleteAll
			// 
			this.MnuEditDeleteAll.Image = global::ApartmentAppliances.Properties.Resources.remove_all;
			this.MnuEditDeleteAll.Name = "MnuEditDeleteAll";
			this.MnuEditDeleteAll.Size = new System.Drawing.Size(266, 22);
			this.MnuEditDeleteAll.Text = "Удалить все приборы";
			this.MnuEditDeleteAll.Click += new System.EventHandler(this.DeleteAllAppliances_Command);
			// 
			// MnuControl
			// 
			this.MnuControl.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MnuControlOnCurrent,
            this.MnuControlOffCurrent,
            this.ъToolStripMenuItem,
            this.MnuControlOnAll,
            this.MnuControlOffAll});
			this.MnuControl.Name = "MnuControl";
			this.MnuControl.Size = new System.Drawing.Size(103, 22);
			this.MnuControl.Text = "Управление";
			// 
			// MnuControlOnCurrent
			// 
			this.MnuControlOnCurrent.Image = global::ApartmentAppliances.Properties.Resources.turn_on;
			this.MnuControlOnCurrent.Name = "MnuControlOnCurrent";
			this.MnuControlOnCurrent.Size = new System.Drawing.Size(239, 22);
			this.MnuControlOnCurrent.Text = "Включить выбранный";
			this.MnuControlOnCurrent.Click += new System.EventHandler(this.OnCurrent_Command);
			// 
			// MnuControlOffCurrent
			// 
			this.MnuControlOffCurrent.Image = global::ApartmentAppliances.Properties.Resources.turn_off;
			this.MnuControlOffCurrent.Name = "MnuControlOffCurrent";
			this.MnuControlOffCurrent.Size = new System.Drawing.Size(239, 22);
			this.MnuControlOffCurrent.Text = "Выключить выбранный";
			this.MnuControlOffCurrent.Click += new System.EventHandler(this.OffCurrent_Command);
			// 
			// ъToolStripMenuItem
			// 
			this.ъToolStripMenuItem.Name = "ъToolStripMenuItem";
			this.ъToolStripMenuItem.Size = new System.Drawing.Size(236, 6);
			// 
			// MnuControlOnAll
			// 
			this.MnuControlOnAll.Image = global::ApartmentAppliances.Properties.Resources.on_all;
			this.MnuControlOnAll.Name = "MnuControlOnAll";
			this.MnuControlOnAll.Size = new System.Drawing.Size(239, 22);
			this.MnuControlOnAll.Text = "Включить все";
			this.MnuControlOnAll.Click += new System.EventHandler(this.OnAll_Command);
			// 
			// MnuControlOffAll
			// 
			this.MnuControlOffAll.Image = global::ApartmentAppliances.Properties.Resources.off_all;
			this.MnuControlOffAll.Name = "MnuControlOffAll";
			this.MnuControlOffAll.Size = new System.Drawing.Size(239, 22);
			this.MnuControlOffAll.Text = "Выключить все";
			this.MnuControlOffAll.Click += new System.EventHandler(this.OffAll_Command);
			// 
			// MnuOrder
			// 
			this.MnuOrder.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MnuOrderByName,
            this.MnuOrderByPower,
            this.поСостояниюToolStripMenuItem,
            this.поУбыванииюЦеныToolStripMenuItem});
			this.MnuOrder.Name = "MnuOrder";
			this.MnuOrder.Size = new System.Drawing.Size(104, 22);
			this.MnuOrder.Text = "Сортировка";
			// 
			// MnuOrderByName
			// 
			this.MnuOrderByName.Name = "MnuOrderByName";
			this.MnuOrderByName.Size = new System.Drawing.Size(217, 22);
			this.MnuOrderByName.Text = "По названию";
			this.MnuOrderByName.Click += new System.EventHandler(this.OrderByName_Command);
			// 
			// MnuOrderByPower
			// 
			this.MnuOrderByPower.Name = "MnuOrderByPower";
			this.MnuOrderByPower.Size = new System.Drawing.Size(217, 22);
			this.MnuOrderByPower.Text = "По мощности";
			this.MnuOrderByPower.Click += new System.EventHandler(this.OrderByPower_Command);
			// 
			// поСостояниюToolStripMenuItem
			// 
			this.поСостояниюToolStripMenuItem.Name = "поСостояниюToolStripMenuItem";
			this.поСостояниюToolStripMenuItem.Size = new System.Drawing.Size(217, 22);
			this.поСостояниюToolStripMenuItem.Text = "По состоянию";
			// 
			// поУбыванииюЦеныToolStripMenuItem
			// 
			this.поУбыванииюЦеныToolStripMenuItem.Name = "поУбыванииюЦеныToolStripMenuItem";
			this.поУбыванииюЦеныToolStripMenuItem.Size = new System.Drawing.Size(217, 22);
			this.поУбыванииюЦеныToolStripMenuItem.Text = "По убываниию цены";
			// 
			// MnuSelectWhere
			// 
			this.MnuSelectWhere.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MnuSelectWhereName,
            this.MnuSelectWhereState});
			this.MnuSelectWhere.Name = "MnuSelectWhere";
			this.MnuSelectWhere.Size = new System.Drawing.Size(83, 22);
			this.MnuSelectWhere.Text = "Выборка";
			// 
			// MnuSelectWhereName
			// 
			this.MnuSelectWhereName.Name = "MnuSelectWhereName";
			this.MnuSelectWhereName.Size = new System.Drawing.Size(176, 22);
			this.MnuSelectWhereName.Text = "По названию";
			this.MnuSelectWhereName.Click += new System.EventHandler(this.SelectWhereName_Command);
			// 
			// MnuSelectWhereState
			// 
			this.MnuSelectWhereState.Name = "MnuSelectWhereState";
			this.MnuSelectWhereState.Size = new System.Drawing.Size(176, 22);
			this.MnuSelectWhereState.Text = "По состоянию";
			this.MnuSelectWhereState.Click += new System.EventHandler(this.SelectWhereState_Command);
			// 
			// MnuSettings
			// 
			this.MnuSettings.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MnuSettingsEditNetworkInfo,
            this.toolStripSeparator9,
            this.MnuSettingsFont,
            this.MnuSettingsBackColor,
            this.MnuSettingsForeColor});
			this.MnuSettings.Name = "MnuSettings";
			this.MnuSettings.Size = new System.Drawing.Size(95, 22);
			this.MnuSettings.Text = "Настройки";
			// 
			// MnuSettingsEditNetworkInfo
			// 
			this.MnuSettingsEditNetworkInfo.Image = global::ApartmentAppliances.Properties.Resources.settings;
			this.MnuSettingsEditNetworkInfo.Name = "MnuSettingsEditNetworkInfo";
			this.MnuSettingsEditNetworkInfo.Size = new System.Drawing.Size(332, 22);
			this.MnuSettingsEditNetworkInfo.Text = "Изменить данные о сети приборов...";
			this.MnuSettingsEditNetworkInfo.Click += new System.EventHandler(this.NetworkSettings_Command);
			// 
			// toolStripSeparator9
			// 
			this.toolStripSeparator9.Name = "toolStripSeparator9";
			this.toolStripSeparator9.Size = new System.Drawing.Size(329, 6);
			// 
			// MnuSettingsFont
			// 
			this.MnuSettingsFont.Image = global::ApartmentAppliances.Properties.Resources.font;
			this.MnuSettingsFont.Name = "MnuSettingsFont";
			this.MnuSettingsFont.Size = new System.Drawing.Size(332, 22);
			this.MnuSettingsFont.Text = "Шрифт...";
			this.MnuSettingsFont.Click += new System.EventHandler(this.Font_Command);
			// 
			// MnuSettingsBackColor
			// 
			this.MnuSettingsBackColor.Image = global::ApartmentAppliances.Properties.Resources.color_management;
			this.MnuSettingsBackColor.Name = "MnuSettingsBackColor";
			this.MnuSettingsBackColor.Size = new System.Drawing.Size(332, 22);
			this.MnuSettingsBackColor.Text = "Цвет фона...";
			this.MnuSettingsBackColor.Click += new System.EventHandler(this.BackColor_Command);
			// 
			// MnuSettingsForeColor
			// 
			this.MnuSettingsForeColor.Image = global::ApartmentAppliances.Properties.Resources.font_color;
			this.MnuSettingsForeColor.Name = "MnuSettingsForeColor";
			this.MnuSettingsForeColor.Size = new System.Drawing.Size(332, 22);
			this.MnuSettingsForeColor.Text = "Цвет текста...";
			this.MnuSettingsForeColor.Click += new System.EventHandler(this.ForeColor_Command);
			// 
			// MnuHelp
			// 
			this.MnuHelp.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MnuHelpAbout});
			this.MnuHelp.Name = "MnuHelp";
			this.MnuHelp.Size = new System.Drawing.Size(79, 22);
			this.MnuHelp.Text = "Справка";
			// 
			// MnuHelpAbout
			// 
			this.MnuHelpAbout.Image = global::ApartmentAppliances.Properties.Resources.about;
			this.MnuHelpAbout.Name = "MnuHelpAbout";
			this.MnuHelpAbout.Size = new System.Drawing.Size(169, 22);
			this.MnuHelpAbout.Text = "О программе";
			this.MnuHelpAbout.Click += new System.EventHandler(this.About_Command);
			// 
			// MnuToTray
			// 
			this.MnuToTray.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
			this.MnuToTray.Image = global::ApartmentAppliances.Properties.Resources.to_tray;
			this.MnuToTray.Margin = new System.Windows.Forms.Padding(0, 0, 20, 0);
			this.MnuToTray.Name = "MnuToTray";
			this.MnuToTray.Size = new System.Drawing.Size(28, 22);
			this.MnuToTray.Click += new System.EventHandler(this.ToTray_Command);
			// 
			// CmnForm
			// 
			this.CmnForm.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.файлToolStripMenuItem,
            this.выходToolStripMenuItem});
			this.CmnForm.Name = "contextMenuStrip1";
			this.CmnForm.Size = new System.Drawing.Size(181, 70);
			// 
			// файлToolStripMenuItem
			// 
			this.файлToolStripMenuItem.Image = global::ApartmentAppliances.Properties.Resources.about;
			this.файлToolStripMenuItem.Name = "файлToolStripMenuItem";
			this.файлToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
			this.файлToolStripMenuItem.Text = "О программе..";
			this.файлToolStripMenuItem.Click += new System.EventHandler(this.About_Command);
			// 
			// выходToolStripMenuItem
			// 
			this.выходToolStripMenuItem.Image = global::ApartmentAppliances.Properties.Resources.exit;
			this.выходToolStripMenuItem.Name = "выходToolStripMenuItem";
			this.выходToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
			this.выходToolStripMenuItem.Text = "Выход";
			this.выходToolStripMenuItem.Click += new System.EventHandler(this.Exit_Command);
			// 
			// TsbMain
			// 
			this.TsbMain.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.TsbMain.ImageScalingSize = new System.Drawing.Size(30, 30);
			this.TsbMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.TbsNew,
            this.TbsFileOpen,
            this.TbsSave,
            this.TbsSaveAs,
            this.toolStripSeparator8,
            this.TstrGenerate,
            this.toolStripSeparator1,
            this.TstrAdd,
            this.TstrEdit,
            this.TstrDelete,
            this.TstrDeleteAll,
            this.toolStripSeparator5,
            this.TstrOn,
            this.TstrOff,
            this.toolStripSeparator3,
            this.TstrOnAll,
            this.TstrOffAll,
            this.toolStripSeparator4,
            this.TstrOrderBy,
            this.toolStripSeparator2,
            this.TsbExit,
            this.TstrAbout,
            this.TstrSelectWhere});
			this.TsbMain.Location = new System.Drawing.Point(0, 26);
			this.TsbMain.Name = "TsbMain";
			this.TsbMain.Padding = new System.Windows.Forms.Padding(6, 1, 17, 1);
			this.TsbMain.Size = new System.Drawing.Size(716, 39);
			this.TsbMain.TabIndex = 8;
			this.TsbMain.Text = "toolStrip1";
			// 
			// TbsNew
			// 
			this.TbsNew.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.TbsNew.Image = global::ApartmentAppliances.Properties.Resources.file_new;
			this.TbsNew.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.TbsNew.Name = "TbsNew";
			this.TbsNew.Size = new System.Drawing.Size(34, 34);
			this.TbsNew.Text = "Новая сеть электроприборов...";
			this.TbsNew.Click += new System.EventHandler(this.FileNew_Command);
			// 
			// TbsFileOpen
			// 
			this.TbsFileOpen.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.TbsFileOpen.Image = global::ApartmentAppliances.Properties.Resources.file_open;
			this.TbsFileOpen.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.TbsFileOpen.Name = "TbsFileOpen";
			this.TbsFileOpen.Size = new System.Drawing.Size(34, 34);
			this.TbsFileOpen.Text = "Открыть...";
			this.TbsFileOpen.Click += new System.EventHandler(this.FileOpen_Command);
			// 
			// TbsSave
			// 
			this.TbsSave.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.TbsSave.Image = global::ApartmentAppliances.Properties.Resources.file_save;
			this.TbsSave.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.TbsSave.Name = "TbsSave";
			this.TbsSave.Size = new System.Drawing.Size(34, 34);
			this.TbsSave.Text = "Сохранить";
			this.TbsSave.Click += new System.EventHandler(this.Save_Command);
			// 
			// TbsSaveAs
			// 
			this.TbsSaveAs.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.TbsSaveAs.Image = global::ApartmentAppliances.Properties.Resources.file_saveas;
			this.TbsSaveAs.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.TbsSaveAs.Name = "TbsSaveAs";
			this.TbsSaveAs.Size = new System.Drawing.Size(34, 34);
			this.TbsSaveAs.Text = "Сохранить как...";
			this.TbsSaveAs.Click += new System.EventHandler(this.SaveAs_Command);
			// 
			// toolStripSeparator8
			// 
			this.toolStripSeparator8.Name = "toolStripSeparator8";
			this.toolStripSeparator8.Size = new System.Drawing.Size(6, 37);
			// 
			// TstrGenerate
			// 
			this.TstrGenerate.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.TstrGenerate.Image = global::ApartmentAppliances.Properties.Resources.regenerate;
			this.TstrGenerate.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.TstrGenerate.Name = "TstrGenerate";
			this.TstrGenerate.Size = new System.Drawing.Size(34, 34);
			this.TstrGenerate.ToolTipText = "Сформировать коллекцию";
			this.TstrGenerate.Click += new System.EventHandler(this.GenerateCollection_Command);
			// 
			// toolStripSeparator1
			// 
			this.toolStripSeparator1.Name = "toolStripSeparator1";
			this.toolStripSeparator1.Size = new System.Drawing.Size(6, 37);
			// 
			// TstrAdd
			// 
			this.TstrAdd.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.TstrAdd.Image = global::ApartmentAppliances.Properties.Resources.add;
			this.TstrAdd.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.TstrAdd.Name = "TstrAdd";
			this.TstrAdd.Size = new System.Drawing.Size(34, 34);
			this.TstrAdd.Text = "Добавить прибор";
			this.TstrAdd.Click += new System.EventHandler(this.Add_Command);
			// 
			// TstrEdit
			// 
			this.TstrEdit.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.TstrEdit.Image = global::ApartmentAppliances.Properties.Resources.edit;
			this.TstrEdit.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.TstrEdit.Name = "TstrEdit";
			this.TstrEdit.Size = new System.Drawing.Size(34, 34);
			this.TstrEdit.Text = "Редактировать прибор";
			this.TstrEdit.Click += new System.EventHandler(this.EditAppliance_Command);
			// 
			// TstrDelete
			// 
			this.TstrDelete.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.TstrDelete.Image = global::ApartmentAppliances.Properties.Resources.remove;
			this.TstrDelete.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.TstrDelete.Name = "TstrDelete";
			this.TstrDelete.Size = new System.Drawing.Size(34, 34);
			this.TstrDelete.ToolTipText = "Удаление выбранного прибора";
			this.TstrDelete.Click += new System.EventHandler(this.DeleteAppliance_Command);
			// 
			// TstrDeleteAll
			// 
			this.TstrDeleteAll.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.TstrDeleteAll.Image = global::ApartmentAppliances.Properties.Resources.remove_all;
			this.TstrDeleteAll.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.TstrDeleteAll.Name = "TstrDeleteAll";
			this.TstrDeleteAll.Size = new System.Drawing.Size(34, 34);
			this.TstrDeleteAll.ToolTipText = "Удаление всех приборов";
			this.TstrDeleteAll.Click += new System.EventHandler(this.DeleteAllAppliances_Command);
			// 
			// toolStripSeparator5
			// 
			this.toolStripSeparator5.Name = "toolStripSeparator5";
			this.toolStripSeparator5.Size = new System.Drawing.Size(6, 37);
			// 
			// TstrOn
			// 
			this.TstrOn.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.TstrOn.Image = global::ApartmentAppliances.Properties.Resources.turn_on;
			this.TstrOn.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.TstrOn.Name = "TstrOn";
			this.TstrOn.Size = new System.Drawing.Size(34, 34);
			this.TstrOn.ToolTipText = "Включить выбранный прибор";
			this.TstrOn.Click += new System.EventHandler(this.OnCurrent_Command);
			// 
			// TstrOff
			// 
			this.TstrOff.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.TstrOff.Image = global::ApartmentAppliances.Properties.Resources.turn_off;
			this.TstrOff.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.TstrOff.Name = "TstrOff";
			this.TstrOff.Size = new System.Drawing.Size(34, 34);
			this.TstrOff.ToolTipText = "Выключить выбранный прибор";
			this.TstrOff.Click += new System.EventHandler(this.OffCurrent_Command);
			// 
			// toolStripSeparator3
			// 
			this.toolStripSeparator3.Name = "toolStripSeparator3";
			this.toolStripSeparator3.Size = new System.Drawing.Size(6, 37);
			// 
			// TstrOnAll
			// 
			this.TstrOnAll.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.TstrOnAll.Image = global::ApartmentAppliances.Properties.Resources.on_all;
			this.TstrOnAll.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.TstrOnAll.Name = "TstrOnAll";
			this.TstrOnAll.Size = new System.Drawing.Size(34, 34);
			this.TstrOnAll.ToolTipText = "Включить все приборы";
			this.TstrOnAll.Click += new System.EventHandler(this.OnAll_Command);
			// 
			// TstrOffAll
			// 
			this.TstrOffAll.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.TstrOffAll.Image = global::ApartmentAppliances.Properties.Resources.off_all;
			this.TstrOffAll.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.TstrOffAll.Name = "TstrOffAll";
			this.TstrOffAll.Size = new System.Drawing.Size(34, 34);
			this.TstrOffAll.ToolTipText = "Выключить все приборы";
			this.TstrOffAll.Click += new System.EventHandler(this.OffAll_Command);
			// 
			// toolStripSeparator4
			// 
			this.toolStripSeparator4.Name = "toolStripSeparator4";
			this.toolStripSeparator4.Size = new System.Drawing.Size(6, 37);
			// 
			// TstrOrderBy
			// 
			this.TstrOrderBy.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.TstrOrderBy.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.TstrOrderByName,
            this.TstrOrderByPower,
            this.TstrOrderByState,
            this.TstrOrderByPriceDesc});
			this.TstrOrderBy.Image = global::ApartmentAppliances.Properties.Resources.order_name;
			this.TstrOrderBy.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.TstrOrderBy.Name = "TstrOrderBy";
			this.TstrOrderBy.Size = new System.Drawing.Size(43, 34);
			this.TstrOrderBy.ToolTipText = "Сортировка приборов\r\nпо наименованию";
			// 
			// TstrOrderByName
			// 
			this.TstrOrderByName.Name = "TstrOrderByName";
			this.TstrOrderByName.Size = new System.Drawing.Size(216, 24);
			this.TstrOrderByName.Text = "По названию";
			this.TstrOrderByName.Click += new System.EventHandler(this.OrderByName_Command);
			// 
			// TstrOrderByPower
			// 
			this.TstrOrderByPower.Name = "TstrOrderByPower";
			this.TstrOrderByPower.Size = new System.Drawing.Size(216, 24);
			this.TstrOrderByPower.Text = "По мощности";
			this.TstrOrderByPower.Click += new System.EventHandler(this.OrderByPower_Command);
			// 
			// TstrOrderByState
			// 
			this.TstrOrderByState.Name = "TstrOrderByState";
			this.TstrOrderByState.Size = new System.Drawing.Size(216, 24);
			this.TstrOrderByState.Text = "По состоянию";
			this.TstrOrderByState.Click += new System.EventHandler(this.OrderByPower_State);
			// 
			// TstrOrderByPriceDesc
			// 
			this.TstrOrderByPriceDesc.Name = "TstrOrderByPriceDesc";
			this.TstrOrderByPriceDesc.Size = new System.Drawing.Size(216, 24);
			this.TstrOrderByPriceDesc.Text = "По убыванию цены";
			this.TstrOrderByPriceDesc.Click += new System.EventHandler(this.OrderByPriceDesc_State);
			// 
			// toolStripSeparator2
			// 
			this.toolStripSeparator2.Name = "toolStripSeparator2";
			this.toolStripSeparator2.Size = new System.Drawing.Size(6, 37);
			// 
			// TsbExit
			// 
			this.TsbExit.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
			this.TsbExit.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.TsbExit.Image = global::ApartmentAppliances.Properties.Resources.exit;
			this.TsbExit.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.TsbExit.Name = "TsbExit";
			this.TsbExit.Size = new System.Drawing.Size(34, 34);
			this.TsbExit.Text = "toolStripButton10";
			this.TsbExit.ToolTipText = "Завершение работы приложения";
			this.TsbExit.Click += new System.EventHandler(this.Exit_Command);
			// 
			// TstrAbout
			// 
			this.TstrAbout.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
			this.TstrAbout.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.TstrAbout.Image = global::ApartmentAppliances.Properties.Resources.about;
			this.TstrAbout.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.TstrAbout.Margin = new System.Windows.Forms.Padding(0, 1, 0, 1);
			this.TstrAbout.Name = "TstrAbout";
			this.TstrAbout.Size = new System.Drawing.Size(34, 35);
			this.TstrAbout.Text = "toolStripButton9";
			this.TstrAbout.ToolTipText = "О программе";
			this.TstrAbout.Click += new System.EventHandler(this.About_Command);
			// 
			// TstrSelectWhere
			// 
			this.TstrSelectWhere.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.TstrSelectWhere.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.TstrSelectWhereName,
            this.TstrSelectWhereState});
			this.TstrSelectWhere.Image = global::ApartmentAppliances.Properties.Resources.select;
			this.TstrSelectWhere.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.TstrSelectWhere.Name = "TstrSelectWhere";
			this.TstrSelectWhere.Size = new System.Drawing.Size(43, 34);
			this.TstrSelectWhere.Text = "Выборка данных";
			// 
			// TstrSelectWhereName
			// 
			this.TstrSelectWhereName.Name = "TstrSelectWhereName";
			this.TstrSelectWhereName.Size = new System.Drawing.Size(178, 24);
			this.TstrSelectWhereName.Text = "По названию";
			this.TstrSelectWhereName.Click += new System.EventHandler(this.SelectWhereName_Command);
			// 
			// TstrSelectWhereState
			// 
			this.TstrSelectWhereState.Name = "TstrSelectWhereState";
			this.TstrSelectWhereState.Size = new System.Drawing.Size(178, 24);
			this.TstrSelectWhereState.Text = "По состоянию";
			this.TstrSelectWhereState.Click += new System.EventHandler(this.SelectWhereState_Command);
			// 
			// GrbMain
			// 
			this.GrbMain.Controls.Add(this.LsvAppliances);
			this.GrbMain.Controls.Add(this.LblAppliances);
			this.GrbMain.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.GrbMain.Location = new System.Drawing.Point(8, 8);
			this.GrbMain.Name = "GrbMain";
			this.GrbMain.Size = new System.Drawing.Size(664, 294);
			this.GrbMain.TabIndex = 11;
			this.GrbMain.TabStop = false;
			this.GrbMain.Text = "Название и адрес";
			// 
			// LsvAppliances
			// 
			this.LsvAppliances.AllowDrop = true;
			this.LsvAppliances.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.ClhState,
            this.ClhName,
            this.ClhPower,
            this.ClhPrice});
			this.LsvAppliances.ContextMenuStrip = this.CmnListView;
			this.LsvAppliances.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.LsvAppliances.FullRowSelect = true;
			this.LsvAppliances.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
			this.LsvAppliances.HideSelection = false;
			this.LsvAppliances.LargeImageList = this.ImlStates;
			this.LsvAppliances.Location = new System.Drawing.Point(16, 64);
			this.LsvAppliances.MultiSelect = false;
			this.LsvAppliances.Name = "LsvAppliances";
			this.LsvAppliances.Size = new System.Drawing.Size(640, 216);
			this.LsvAppliances.SmallImageList = this.ImlStates;
			this.LsvAppliances.StateImageList = this.ImlStates;
			this.LsvAppliances.TabIndex = 11;
			this.LsvAppliances.UseCompatibleStateImageBehavior = false;
			this.LsvAppliances.View = System.Windows.Forms.View.Details;
			this.LsvAppliances.DragDrop += new System.Windows.Forms.DragEventHandler(this.LsvAppliances_DragDrop);
			this.LsvAppliances.DragEnter += new System.Windows.Forms.DragEventHandler(this.LsvAppliances_DragEnter);
			this.LsvAppliances.DragOver += new System.Windows.Forms.DragEventHandler(this.LsvAppliances_DragOver);
			this.LsvAppliances.DragLeave += new System.EventHandler(this.LsvAppliances_DragLeave);
			this.LsvAppliances.KeyDown += new System.Windows.Forms.KeyEventHandler(this.LsvAppliances_KeyDown);
			this.LsvAppliances.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.LsvAppliances_MouseDoubleClick);
			// 
			// ClhState
			// 
			this.ClhState.Text = "Состояние";
			this.ClhState.Width = 85;
			// 
			// ClhName
			// 
			this.ClhName.Text = "Название";
			this.ClhName.Width = 220;
			// 
			// ClhPower
			// 
			this.ClhPower.Text = "Мощность";
			this.ClhPower.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.ClhPower.Width = 80;
			// 
			// ClhPrice
			// 
			this.ClhPrice.Text = "Стоимость";
			this.ClhPrice.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.ClhPrice.Width = 90;
			// 
			// CmnListView
			// 
			this.CmnListView.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
			this.CmnListView.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.CmnListViewAdd,
            this.CmnListViewEdit,
            this.CmnListViewRemove});
			this.CmnListView.Name = "CmnList";
			this.CmnListView.Size = new System.Drawing.Size(158, 70);
			// 
			// CmnListViewAdd
			// 
			this.CmnListViewAdd.Image = global::ApartmentAppliances.Properties.Resources.add;
			this.CmnListViewAdd.Name = "CmnListViewAdd";
			this.CmnListViewAdd.Size = new System.Drawing.Size(157, 22);
			this.CmnListViewAdd.Text = "Добавить...";
			this.CmnListViewAdd.Click += new System.EventHandler(this.Add_Command);
			// 
			// CmnListViewEdit
			// 
			this.CmnListViewEdit.Image = global::ApartmentAppliances.Properties.Resources.edit;
			this.CmnListViewEdit.Name = "CmnListViewEdit";
			this.CmnListViewEdit.Size = new System.Drawing.Size(157, 22);
			this.CmnListViewEdit.Text = "Изменить...";
			this.CmnListViewEdit.Click += new System.EventHandler(this.EditAppliance_Command);
			// 
			// CmnListViewRemove
			// 
			this.CmnListViewRemove.Image = global::ApartmentAppliances.Properties.Resources.remove;
			this.CmnListViewRemove.Name = "CmnListViewRemove";
			this.CmnListViewRemove.Size = new System.Drawing.Size(157, 22);
			this.CmnListViewRemove.Text = "Удалить";
			this.CmnListViewRemove.Click += new System.EventHandler(this.DeleteAppliance_Command);
			// 
			// ImlStates
			// 
			this.ImlStates.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("ImlStates.ImageStream")));
			this.ImlStates.TransparentColor = System.Drawing.Color.Transparent;
			this.ImlStates.Images.SetKeyName(0, "light_off.png");
			this.ImlStates.Images.SetKeyName(1, "light_on2.png");
			// 
			// LblAppliances
			// 
			this.LblAppliances.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.24F);
			this.LblAppliances.Location = new System.Drawing.Point(16, 32);
			this.LblAppliances.Name = "LblAppliances";
			this.LblAppliances.Size = new System.Drawing.Size(640, 21);
			this.LblAppliances.TabIndex = 10;
			this.LblAppliances.Text = "Список устройств:";
			// 
			// TbcMain
			// 
			this.TbcMain.Controls.Add(this.TbpMain);
			this.TbcMain.Controls.Add(this.TbpOrder);
			this.TbcMain.Controls.Add(this.TbpSelect);
			this.TbcMain.ImageList = this.ImlTabs;
			this.TbcMain.Location = new System.Drawing.Point(8, 72);
			this.TbcMain.Name = "TbcMain";
			this.TbcMain.SelectedIndex = 0;
			this.TbcMain.Size = new System.Drawing.Size(688, 344);
			this.TbcMain.TabIndex = 12;
			this.TbcMain.SelectedIndexChanged += new System.EventHandler(this.TbcMain_SelectedIndexChanged);
			// 
			// TbpMain
			// 
			this.TbpMain.Controls.Add(this.GrbMain);
			this.TbpMain.ImageIndex = 0;
			this.TbpMain.Location = new System.Drawing.Point(4, 27);
			this.TbpMain.Name = "TbpMain";
			this.TbpMain.Padding = new System.Windows.Forms.Padding(3);
			this.TbpMain.Size = new System.Drawing.Size(680, 313);
			this.TbpMain.TabIndex = 0;
			this.TbpMain.Text = "Главная";
			this.TbpMain.UseVisualStyleBackColor = true;
			// 
			// TbpOrder
			// 
			this.TbpOrder.Controls.Add(this.GrbSorted);
			this.TbpOrder.ImageIndex = 1;
			this.TbpOrder.Location = new System.Drawing.Point(4, 27);
			this.TbpOrder.Name = "TbpOrder";
			this.TbpOrder.Padding = new System.Windows.Forms.Padding(3);
			this.TbpOrder.Size = new System.Drawing.Size(680, 313);
			this.TbpOrder.TabIndex = 1;
			this.TbpOrder.Text = "Отсортированные данные";
			this.TbpOrder.UseVisualStyleBackColor = true;
			// 
			// GrbSorted
			// 
			this.GrbSorted.Controls.Add(this.LsvSorted);
			this.GrbSorted.Controls.Add(this.LblSorted);
			this.GrbSorted.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.GrbSorted.Location = new System.Drawing.Point(8, 9);
			this.GrbSorted.Name = "GrbSorted";
			this.GrbSorted.Size = new System.Drawing.Size(664, 294);
			this.GrbSorted.TabIndex = 12;
			this.GrbSorted.TabStop = false;
			this.GrbSorted.Text = "Отсортировано";
			// 
			// LsvSorted
			// 
			this.LsvSorted.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3,
            this.columnHeader4});
			this.LsvSorted.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.LsvSorted.FullRowSelect = true;
			this.LsvSorted.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
			this.LsvSorted.HideSelection = false;
			this.LsvSorted.LargeImageList = this.ImlStates;
			this.LsvSorted.Location = new System.Drawing.Point(16, 64);
			this.LsvSorted.MultiSelect = false;
			this.LsvSorted.Name = "LsvSorted";
			this.LsvSorted.Size = new System.Drawing.Size(640, 216);
			this.LsvSorted.SmallImageList = this.ImlStates;
			this.LsvSorted.StateImageList = this.ImlStates;
			this.LsvSorted.TabIndex = 11;
			this.LsvSorted.UseCompatibleStateImageBehavior = false;
			this.LsvSorted.View = System.Windows.Forms.View.Details;
			// 
			// columnHeader1
			// 
			this.columnHeader1.Text = "Состояние";
			this.columnHeader1.Width = 85;
			// 
			// columnHeader2
			// 
			this.columnHeader2.Text = "Название";
			this.columnHeader2.Width = 220;
			// 
			// columnHeader3
			// 
			this.columnHeader3.Text = "Мощность";
			this.columnHeader3.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.columnHeader3.Width = 80;
			// 
			// columnHeader4
			// 
			this.columnHeader4.Text = "Стоимость";
			this.columnHeader4.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.columnHeader4.Width = 90;
			// 
			// LblSorted
			// 
			this.LblSorted.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.24F);
			this.LblSorted.Location = new System.Drawing.Point(16, 32);
			this.LblSorted.Name = "LblSorted";
			this.LblSorted.Size = new System.Drawing.Size(640, 21);
			this.LblSorted.TabIndex = 10;
			this.LblSorted.Text = "Список устройств:";
			// 
			// TbpSelect
			// 
			this.TbpSelect.Controls.Add(this.GrbSelect);
			this.TbpSelect.ImageIndex = 2;
			this.TbpSelect.Location = new System.Drawing.Point(4, 27);
			this.TbpSelect.Name = "TbpSelect";
			this.TbpSelect.Padding = new System.Windows.Forms.Padding(3);
			this.TbpSelect.Size = new System.Drawing.Size(680, 313);
			this.TbpSelect.TabIndex = 2;
			this.TbpSelect.Text = "Выборка данных";
			this.TbpSelect.UseVisualStyleBackColor = true;
			// 
			// GrbSelect
			// 
			this.GrbSelect.Controls.Add(this.LsvSelect);
			this.GrbSelect.Controls.Add(this.LblSelect);
			this.GrbSelect.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.GrbSelect.Location = new System.Drawing.Point(8, 9);
			this.GrbSelect.Name = "GrbSelect";
			this.GrbSelect.Size = new System.Drawing.Size(664, 294);
			this.GrbSelect.TabIndex = 13;
			this.GrbSelect.TabStop = false;
			this.GrbSelect.Text = "Выборка";
			// 
			// LsvSelect
			// 
			this.LsvSelect.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader5,
            this.columnHeader6,
            this.columnHeader7,
            this.columnHeader8});
			this.LsvSelect.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.LsvSelect.FullRowSelect = true;
			this.LsvSelect.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
			this.LsvSelect.HideSelection = false;
			this.LsvSelect.LargeImageList = this.ImlStates;
			this.LsvSelect.Location = new System.Drawing.Point(16, 64);
			this.LsvSelect.MultiSelect = false;
			this.LsvSelect.Name = "LsvSelect";
			this.LsvSelect.Size = new System.Drawing.Size(640, 216);
			this.LsvSelect.SmallImageList = this.ImlStates;
			this.LsvSelect.StateImageList = this.ImlStates;
			this.LsvSelect.TabIndex = 11;
			this.LsvSelect.UseCompatibleStateImageBehavior = false;
			this.LsvSelect.View = System.Windows.Forms.View.Details;
			// 
			// columnHeader5
			// 
			this.columnHeader5.Text = "Состояние";
			this.columnHeader5.Width = 85;
			// 
			// columnHeader6
			// 
			this.columnHeader6.Text = "Название";
			this.columnHeader6.Width = 220;
			// 
			// columnHeader7
			// 
			this.columnHeader7.Text = "Мощность";
			this.columnHeader7.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.columnHeader7.Width = 80;
			// 
			// columnHeader8
			// 
			this.columnHeader8.Text = "Стоимость";
			this.columnHeader8.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.columnHeader8.Width = 90;
			// 
			// LblSelect
			// 
			this.LblSelect.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.24F);
			this.LblSelect.Location = new System.Drawing.Point(16, 32);
			this.LblSelect.Name = "LblSelect";
			this.LblSelect.Size = new System.Drawing.Size(640, 21);
			this.LblSelect.TabIndex = 10;
			this.LblSelect.Text = "Список устройств:";
			// 
			// ImlTabs
			// 
			this.ImlTabs.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("ImlTabs.ImageStream")));
			this.ImlTabs.TransparentColor = System.Drawing.Color.Transparent;
			this.ImlTabs.Images.SetKeyName(0, "home.png");
			this.ImlTabs.Images.SetKeyName(1, "order_name.png");
			this.ImlTabs.Images.SetKeyName(2, "select.png");
			// 
			// SfdMain
			// 
			this.SfdMain.FileName = "appliances.json";
			this.SfdMain.Filter = "Файлы JSON(*.json)|*.json";
			this.SfdMain.SupportMultiDottedExtensions = true;
			this.SfdMain.Title = "Сохранить данные в файл";
			// 
			// OfdMain
			// 
			this.OfdMain.FileName = "appliances.json";
			this.OfdMain.Filter = "Файлы JSON(*.json)|*.json";
			this.OfdMain.Title = "Загрузить данные из файла";
			// 
			// StlMain
			// 
			this.StlMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.StlLabel});
			this.StlMain.Location = new System.Drawing.Point(0, 428);
			this.StlMain.Name = "StlMain";
			this.StlMain.Size = new System.Drawing.Size(716, 22);
			this.StlMain.TabIndex = 13;
			// 
			// StlLabel
			// 
			this.StlLabel.Name = "StlLabel";
			this.StlLabel.Size = new System.Drawing.Size(0, 17);
			// 
			// CmnTray
			// 
			this.CmnTray.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.CmnTrayRestore,
            this.CmnTrayAbout,
            this.toolStripSeparator11,
            this.CmnTrayExit});
			this.CmnTray.Name = "CmnTray";
			this.CmnTray.Size = new System.Drawing.Size(159, 76);
			this.CmnTray.Text = "RepairShop";
			// 
			// CmnTrayRestore
			// 
			this.CmnTrayRestore.Image = global::ApartmentAppliances.Properties.Resources.restore;
			this.CmnTrayRestore.Name = "CmnTrayRestore";
			this.CmnTrayRestore.Size = new System.Drawing.Size(158, 22);
			this.CmnTrayRestore.Text = "Восстановить";
			this.CmnTrayRestore.Click += new System.EventHandler(this.Restore_Command);
			// 
			// CmnTrayAbout
			// 
			this.CmnTrayAbout.Image = global::ApartmentAppliances.Properties.Resources.about;
			this.CmnTrayAbout.Name = "CmnTrayAbout";
			this.CmnTrayAbout.Size = new System.Drawing.Size(158, 22);
			this.CmnTrayAbout.Text = "О программе...";
			this.CmnTrayAbout.Click += new System.EventHandler(this.About_Command);
			// 
			// toolStripSeparator11
			// 
			this.toolStripSeparator11.Name = "toolStripSeparator11";
			this.toolStripSeparator11.Size = new System.Drawing.Size(155, 6);
			// 
			// CmnTrayExit
			// 
			this.CmnTrayExit.Image = global::ApartmentAppliances.Properties.Resources.exit;
			this.CmnTrayExit.Name = "CmnTrayExit";
			this.CmnTrayExit.Size = new System.Drawing.Size(158, 22);
			this.CmnTrayExit.Text = "Выход";
			this.CmnTrayExit.Click += new System.EventHandler(this.Exit_Command);
			// 
			// NtiMain
			// 
			this.NtiMain.ContextMenuStrip = this.CmnTray;
			this.NtiMain.Icon = ((System.Drawing.Icon)(resources.GetObject("NtiMain.Icon")));
			this.NtiMain.Text = "AppliancesNetwork";
			this.NtiMain.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.CmnTray_MouseDoubleClick);
			// 
			// FdlTextFont
			// 
			this.FdlTextFont.Font = new System.Drawing.Font("Consolas", 12F);
			this.FdlTextFont.ShowApply = true;
			this.FdlTextFont.ShowColor = true;
			this.FdlTextFont.Apply += new System.EventHandler(this.FdlTextFont_Apply);
			// 
			// CdlBackColor
			// 
			this.CdlBackColor.AnyColor = true;
			this.CdlBackColor.FullOpen = true;
			// 
			// MainForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(716, 450);
			this.ContextMenuStrip = this.CmnForm;
			this.Controls.Add(this.StlMain);
			this.Controls.Add(this.TsbMain);
			this.Controls.Add(this.MnuMain);
			this.Controls.Add(this.TbcMain);
			this.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.MainMenuStrip = this.MnuMain;
			this.Margin = new System.Windows.Forms.Padding(4);
			this.MaximizeBox = false;
			this.Name = "MainForm";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Домашняя работа";
			this.Load += new System.EventHandler(this.MainForm_Load);
			this.MnuMain.ResumeLayout(false);
			this.MnuMain.PerformLayout();
			this.CmnForm.ResumeLayout(false);
			this.TsbMain.ResumeLayout(false);
			this.TsbMain.PerformLayout();
			this.GrbMain.ResumeLayout(false);
			this.CmnListView.ResumeLayout(false);
			this.TbcMain.ResumeLayout(false);
			this.TbpMain.ResumeLayout(false);
			this.TbpOrder.ResumeLayout(false);
			this.GrbSorted.ResumeLayout(false);
			this.TbpSelect.ResumeLayout(false);
			this.GrbSelect.ResumeLayout(false);
			this.StlMain.ResumeLayout(false);
			this.StlMain.PerformLayout();
			this.CmnTray.ResumeLayout(false);
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion
		private System.Windows.Forms.MenuStrip MnuMain;
		private System.Windows.Forms.ToolStripMenuItem MnuFile;
		private System.Windows.Forms.ToolStripMenuItem MnuEdit;
		private System.Windows.Forms.ToolStripMenuItem MnuEditGenerate;
		private System.Windows.Forms.ToolStripSeparator separatorToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem MnuEditDelete;
		private System.Windows.Forms.ToolStripMenuItem MnuEditDeleteAll;
		private System.Windows.Forms.ToolStripMenuItem MnuOrder;
		private System.Windows.Forms.ToolStripMenuItem MnuControl;
		private System.Windows.Forms.ToolStripMenuItem MnuHelp;
		private System.Windows.Forms.ContextMenuStrip CmnForm;
		private System.Windows.Forms.ToolStripMenuItem файлToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem выходToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem MnuFileExit;
		private System.Windows.Forms.ToolStripMenuItem MnuOrderByName;
		private System.Windows.Forms.ToolStripMenuItem MnuOrderByPower;
		private System.Windows.Forms.ToolStripMenuItem MnuControlOnAll;
		private System.Windows.Forms.ToolStripMenuItem MnuControlOnCurrent;
		private System.Windows.Forms.ToolStripSeparator ъToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem MnuControlOffAll;
		private System.Windows.Forms.ToolStripMenuItem MnuControlOffCurrent;
		private System.Windows.Forms.ToolStripMenuItem MnuHelpAbout;
		private System.Windows.Forms.ToolStrip TsbMain;
		private System.Windows.Forms.ToolStripButton TstrGenerate;
		private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
		private System.Windows.Forms.ToolStripButton TstrDelete;
		private System.Windows.Forms.ToolStripButton TstrDeleteAll;
		private System.Windows.Forms.ToolStripSeparator toolStripSeparator5;
		private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
		private System.Windows.Forms.ToolStripButton TstrOn;
		private System.Windows.Forms.ToolStripButton TstrOff;
		private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
		private System.Windows.Forms.ToolStripButton TstrOnAll;
		private System.Windows.Forms.ToolStripButton TstrOffAll;
		private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
		private System.Windows.Forms.ToolStripButton TstrAbout;
		private System.Windows.Forms.ToolStripButton TsbExit;
		private System.Windows.Forms.GroupBox GrbMain;
		private System.Windows.Forms.ListView LsvAppliances;
		private System.Windows.Forms.Label LblAppliances;
		private System.Windows.Forms.TabControl TbcMain;
		private System.Windows.Forms.TabPage TbpOrder;
		private System.Windows.Forms.TabPage TbpMain;
		private System.Windows.Forms.ColumnHeader ClhState;
		private System.Windows.Forms.ColumnHeader ClhName;
		private System.Windows.Forms.ColumnHeader ClhPower;
		private System.Windows.Forms.ColumnHeader ClhPrice;
		private System.Windows.Forms.ImageList ImlStates;
		private System.Windows.Forms.ToolStripMenuItem MnuFileNew;
		private System.Windows.Forms.ToolStripMenuItem MnuFileOpen;
		private System.Windows.Forms.ToolStripMenuItem MnuFileSave;
		private System.Windows.Forms.ToolStripMenuItem MnuFileSaveAs;
		private System.Windows.Forms.ToolStripSeparator toolStripSeparator6;
		private System.Windows.Forms.SaveFileDialog SfdMain;
		private System.Windows.Forms.OpenFileDialog OfdMain;
		private System.Windows.Forms.StatusStrip StlMain;
		private System.Windows.Forms.ToolStripStatusLabel StlLabel;
		private System.Windows.Forms.ToolStripMenuItem MnuEditAdd;
		private System.Windows.Forms.ToolStripMenuItem MnuEditEdit;
		private System.Windows.Forms.ToolStripSeparator toolStripSeparator7;
		private System.Windows.Forms.GroupBox GrbSorted;
		private System.Windows.Forms.ListView LsvSorted;
		private System.Windows.Forms.ColumnHeader columnHeader1;
		private System.Windows.Forms.ColumnHeader columnHeader2;
		private System.Windows.Forms.ColumnHeader columnHeader3;
		private System.Windows.Forms.ColumnHeader columnHeader4;
		private System.Windows.Forms.Label LblSorted;
		private System.Windows.Forms.ToolStripMenuItem поСостояниюToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem поУбыванииюЦеныToolStripMenuItem;
		private System.Windows.Forms.ToolStripButton TbsNew;
		private System.Windows.Forms.ToolStripButton TbsFileOpen;
		private System.Windows.Forms.ToolStripButton TbsSave;
		private System.Windows.Forms.ToolStripButton TbsSaveAs;
		private System.Windows.Forms.ToolStripSeparator toolStripSeparator8;
		private System.Windows.Forms.ToolStripButton TstrAdd;
		private System.Windows.Forms.ToolStripButton TstrEdit;
		private System.Windows.Forms.ToolStripDropDownButton TstrOrderBy;
		private System.Windows.Forms.ToolStripMenuItem TstrOrderByName;
		private System.Windows.Forms.ToolStripMenuItem TstrOrderByPower;
		private System.Windows.Forms.ToolStripMenuItem TstrOrderByState;
		private System.Windows.Forms.ToolStripMenuItem TstrOrderByPriceDesc;
		private System.Windows.Forms.ToolStripMenuItem MnuSelectWhere;
		private System.Windows.Forms.ToolStripMenuItem MnuSettings;
		private System.Windows.Forms.ContextMenuStrip CmnTray;
		private System.Windows.Forms.ToolStripMenuItem CmnTrayRestore;
		private System.Windows.Forms.ToolStripMenuItem CmnTrayAbout;
		private System.Windows.Forms.ToolStripSeparator toolStripSeparator11;
		private System.Windows.Forms.ToolStripMenuItem CmnTrayExit;
		private System.Windows.Forms.NotifyIcon NtiMain;
		private System.Windows.Forms.ToolStripMenuItem MnuToTray;
		private System.Windows.Forms.ToolStripMenuItem MnuSelectWhereName;
		private System.Windows.Forms.ToolStripMenuItem MnuSelectWhereState;
		private System.Windows.Forms.TabPage TbpSelect;
		private System.Windows.Forms.GroupBox GrbSelect;
		private System.Windows.Forms.ListView LsvSelect;
		private System.Windows.Forms.ColumnHeader columnHeader5;
		private System.Windows.Forms.ColumnHeader columnHeader6;
		private System.Windows.Forms.ColumnHeader columnHeader7;
		private System.Windows.Forms.ColumnHeader columnHeader8;
		private System.Windows.Forms.Label LblSelect;
		private System.Windows.Forms.ToolStripDropDownButton TstrSelectWhere;
		private System.Windows.Forms.ToolStripMenuItem TstrSelectWhereName;
		private System.Windows.Forms.ToolStripMenuItem TstrSelectWhereState;
		private System.Windows.Forms.ToolStripMenuItem MnuSettingsEditNetworkInfo;
		private System.Windows.Forms.ContextMenuStrip CmnListView;
		private System.Windows.Forms.ToolStripMenuItem CmnListViewAdd;
		private System.Windows.Forms.ToolStripMenuItem CmnListViewEdit;
		private System.Windows.Forms.ToolStripMenuItem CmnListViewRemove;
		private System.Windows.Forms.ImageList ImlTabs;
		private System.Windows.Forms.ToolStripSeparator toolStripSeparator9;
		private System.Windows.Forms.ToolStripMenuItem MnuSettingsFont;
		private System.Windows.Forms.ToolStripMenuItem MnuSettingsBackColor;
		private System.Windows.Forms.ToolStripMenuItem MnuSettingsForeColor;
		private System.Windows.Forms.FontDialog FdlTextFont;
		private System.Windows.Forms.ColorDialog CdlBackColor;
	}
}

