﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pets.Models
{
	// класс, описывающий коллекцию животных
	public class PetsClub
	{
		// коллекция животных
		private List<Animal> _animals;

		public List<Animal> Animals
		{
			get => _animals;
			private set => _animals = value;
		}

		// название коллекции животных
		private string _name;
		public string Name
		{
			get => _name;
			set
			{
				if (string.IsNullOrEmpty(value))
					throw new ArgumentNullException("Пустая строка в названии коллекции");
				_name = value;
			}
		}

		// конструкторы
		public PetsClub() : this(new List<Animal>(), "Клуб питомцев \"Дружок\"")
		{ }

		public PetsClub(List<Animal> animals, string name)
		{
			Animals = animals;
			Name = name;
		}

		// количество эл-тов в коллекции
		public int Count => Animals.Count;

		// проверка на наличие элементов
		public bool IsEmpty => Count == 0;

		// реинициализация коллекции
		public void Initialize(int n = 20)
		{
			_animals.Clear();
			_animals = AnimalsFabric.GenerateCollection(n);
		}

		// индексатор
		public Animal this[int index]
		{
			get
			{
				if (index < 0 || index >= Count)
					throw new IndexOutOfRangeException("Попытка доступа к элементу вне диапазона");
				return _animals[index];
			}
			set
			{
				if (index < 0 || index >= Count)
					throw new IndexOutOfRangeException("Попытка доступа к элементу вне диапазона");

				_animals[index] = value;
			}
		}

		// добавление животного в коллекцию
		public void AddAnimal(Animal Animal) => _animals.Add(Animal);

		// удаление выбранного животного по индексу
		public void RemoveAnimal(int index) => _animals.RemoveAt(index);

		// удаление всех животных
		public void Clear() => _animals.Clear();

		// упорядочивание коллекции по заданному компаратору
		public void OrderBy(Comparison<Animal> comparison) => _animals.Sort(comparison);

		// упорядочивание копии коллекции по заданному компаратору
		public List<Animal> OrderCopyBy(Comparison<Animal> comparison)
		{
			// получить копию коллекции 
			List<Animal> animals = new List<Animal>(_animals);

			// упорядочить копию коллекции и вернуть эту копию
			animals.Sort(comparison);
			return animals;
		}


		public static void OrderBy(List<Animal> list, Comparison<Animal> comparison) => list.Sort(comparison);

		// выборка данных из коллекции по заданному предикату
		public List<Animal> Filter(Predicate<Animal> predicate) =>
			_animals.FindAll(predicate);

		// получить список владельцев животных
		public List<string> GetAnimalsOwners() //=> _animals.Select(Animal => Animal.Owner).Distinct().ToList();
		{
			HashSet<string> names = new HashSet<string>();

			_animals.ForEach(ap => names.Add(ap.Owner));

			return names.ToList();
		}

		// Максимальный вес животного
		public double MaxWeight() // => _animals.Min(a => a.Weight);
		{
			double maxWeight = _animals[0].Weight;
		
			_animals.ForEach(a => maxWeight = a.Weight > maxWeight ? a.Weight : maxWeight);
		
			return maxWeight;
		}
	}
}
