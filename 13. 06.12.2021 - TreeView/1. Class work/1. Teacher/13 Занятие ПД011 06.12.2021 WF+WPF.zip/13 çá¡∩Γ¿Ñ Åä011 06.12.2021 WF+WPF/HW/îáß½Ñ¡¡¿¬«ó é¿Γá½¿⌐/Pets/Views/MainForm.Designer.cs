﻿
namespace Pets.Views
{
	partial class MainForm
	{
		/// <summary>
		/// Обязательная переменная конструктора.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Освободить все используемые ресурсы.
		/// </summary>
		/// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Код, автоматически созданный конструктором форм Windows

		/// <summary>
		/// Требуемый метод для поддержки конструктора — не изменяйте 
		/// содержимое этого метода с помощью редактора кода.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
			this.MnuMain = new System.Windows.Forms.MenuStrip();
			this.MnuFile = new System.Windows.Forms.ToolStripMenuItem();
			this.MnuFileNew = new System.Windows.Forms.ToolStripMenuItem();
			this.MnuFileOpen = new System.Windows.Forms.ToolStripMenuItem();
			this.MnuFileSave = new System.Windows.Forms.ToolStripMenuItem();
			this.MnuFileSaveAs = new System.Windows.Forms.ToolStripMenuItem();
			this.toolStripSeparator6 = new System.Windows.Forms.ToolStripSeparator();
			this.MnuFileExit = new System.Windows.Forms.ToolStripMenuItem();
			this.MnuEdit = new System.Windows.Forms.ToolStripMenuItem();
			this.MnuEditGenerate = new System.Windows.Forms.ToolStripMenuItem();
			this.separatorToolStripMenuItem = new System.Windows.Forms.ToolStripSeparator();
			this.MnuEditAdd = new System.Windows.Forms.ToolStripMenuItem();
			this.MnuEditEdit = new System.Windows.Forms.ToolStripMenuItem();
			this.toolStripSeparator7 = new System.Windows.Forms.ToolStripSeparator();
			this.MnuEditDelete = new System.Windows.Forms.ToolStripMenuItem();
			this.MnuEditDeleteAll = new System.Windows.Forms.ToolStripMenuItem();
			this.MnuOrder = new System.Windows.Forms.ToolStripMenuItem();
			this.MnuOrderByAge = new System.Windows.Forms.ToolStripMenuItem();
			this.MnuOrderBySpecies = new System.Windows.Forms.ToolStripMenuItem();
			this.MnuOrderByOwners = new System.Windows.Forms.ToolStripMenuItem();
			this.MnuSelectWhere = new System.Windows.Forms.ToolStripMenuItem();
			this.MnuSelectWhereOwner = new System.Windows.Forms.ToolStripMenuItem();
			this.MnuSelectWhereMaxWeight = new System.Windows.Forms.ToolStripMenuItem();
			this.MnuSettings = new System.Windows.Forms.ToolStripMenuItem();
			this.MnuSettingsEditPetClubInfo = new System.Windows.Forms.ToolStripMenuItem();
			this.toolStripSeparator9 = new System.Windows.Forms.ToolStripSeparator();
			this.MnuSettingsFont = new System.Windows.Forms.ToolStripMenuItem();
			this.MnuSettingsBackColor = new System.Windows.Forms.ToolStripMenuItem();
			this.MnuSettingsForeColor = new System.Windows.Forms.ToolStripMenuItem();
			this.MnuHelp = new System.Windows.Forms.ToolStripMenuItem();
			this.MnuHelpAbout = new System.Windows.Forms.ToolStripMenuItem();
			this.MnuToTray = new System.Windows.Forms.ToolStripMenuItem();
			this.TsbMain = new System.Windows.Forms.ToolStrip();
			this.TsbNew = new System.Windows.Forms.ToolStripButton();
			this.TsbFileOpen = new System.Windows.Forms.ToolStripButton();
			this.TsbSave = new System.Windows.Forms.ToolStripButton();
			this.TsbSaveAs = new System.Windows.Forms.ToolStripButton();
			this.toolStripSeparator8 = new System.Windows.Forms.ToolStripSeparator();
			this.TsbGenerate = new System.Windows.Forms.ToolStripButton();
			this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
			this.TsbAdd = new System.Windows.Forms.ToolStripButton();
			this.TsbEdit = new System.Windows.Forms.ToolStripButton();
			this.TsbDelete = new System.Windows.Forms.ToolStripButton();
			this.TsbDeleteAll = new System.Windows.Forms.ToolStripButton();
			this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
			this.TsbOrderBy = new System.Windows.Forms.ToolStripDropDownButton();
			this.TstrOrderByAge = new System.Windows.Forms.ToolStripMenuItem();
			this.TstrOrderBySpecies = new System.Windows.Forms.ToolStripMenuItem();
			this.TstrOrderByOwner = new System.Windows.Forms.ToolStripMenuItem();
			this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
			this.TsbExit = new System.Windows.Forms.ToolStripButton();
			this.TstrAbout = new System.Windows.Forms.ToolStripButton();
			this.TsbSelectWhereMaxWeight = new System.Windows.Forms.ToolStripButton();
			this.TsbSelectWhereOwner = new System.Windows.Forms.ToolStripButton();
			this.ImlPets = new System.Windows.Forms.ImageList(this.components);
			this.StlMain = new System.Windows.Forms.StatusStrip();
			this.StlLblMessage = new System.Windows.Forms.ToolStripStatusLabel();
			this.GrbMain = new System.Windows.Forms.GroupBox();
			this.TbcMain = new System.Windows.Forms.TabControl();
			this.TbpMain = new System.Windows.Forms.TabPage();
			this.LsvAnimals = new System.Windows.Forms.ListView();
			this.ClhImage = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
			this.ClhSpecies = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
			this.ClhName = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
			this.ClhAge = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
			this.ClhWeight = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
			this.ClhPaint = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
			this.ClhOwner = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
			this.LblAnimals = new System.Windows.Forms.Label();
			this.TbpOrder = new System.Windows.Forms.TabPage();
			this.LsvOrdered = new System.Windows.Forms.ListView();
			this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
			this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
			this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
			this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
			this.columnHeader5 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
			this.columnHeader6 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
			this.columnHeader7 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
			this.LblOrdered = new System.Windows.Forms.Label();
			this.TbpSelect = new System.Windows.Forms.TabPage();
			this.TxbOwnerInput = new System.Windows.Forms.TextBox();
			this.LsvSelected = new System.Windows.Forms.ListView();
			this.columnHeader8 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
			this.columnHeader9 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
			this.columnHeader10 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
			this.columnHeader11 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
			this.columnHeader12 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
			this.columnHeader13 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
			this.columnHeader14 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
			this.LblSelected = new System.Windows.Forms.Label();
			this.SfdMain = new System.Windows.Forms.SaveFileDialog();
			this.OfdMain = new System.Windows.Forms.OpenFileDialog();
			this.CmnListView = new System.Windows.Forms.ContextMenuStrip(this.components);
			this.CmnListViewAdd = new System.Windows.Forms.ToolStripMenuItem();
			this.CmnListViewEdit = new System.Windows.Forms.ToolStripMenuItem();
			this.CmnListViewRemove = new System.Windows.Forms.ToolStripMenuItem();
			this.CmnTray = new System.Windows.Forms.ContextMenuStrip(this.components);
			this.CmnTrayRestore = new System.Windows.Forms.ToolStripMenuItem();
			this.CmnTrayAbout = new System.Windows.Forms.ToolStripMenuItem();
			this.toolStripSeparator11 = new System.Windows.Forms.ToolStripSeparator();
			this.CmnTrayExit = new System.Windows.Forms.ToolStripMenuItem();
			this.CmnForm = new System.Windows.Forms.ContextMenuStrip(this.components);
			this.CmnFormAbout = new System.Windows.Forms.ToolStripMenuItem();
			this.CmnFormExit = new System.Windows.Forms.ToolStripMenuItem();
			this.NtiMain = new System.Windows.Forms.NotifyIcon(this.components);
			this.FdlTextFont = new System.Windows.Forms.FontDialog();
			this.CdlBackColor = new System.Windows.Forms.ColorDialog();
			this.StlLblStatus = new System.Windows.Forms.ToolStripStatusLabel();
			this.MnuMain.SuspendLayout();
			this.TsbMain.SuspendLayout();
			this.StlMain.SuspendLayout();
			this.GrbMain.SuspendLayout();
			this.TbcMain.SuspendLayout();
			this.TbpMain.SuspendLayout();
			this.TbpOrder.SuspendLayout();
			this.TbpSelect.SuspendLayout();
			this.CmnListView.SuspendLayout();
			this.CmnTray.SuspendLayout();
			this.CmnForm.SuspendLayout();
			this.SuspendLayout();
			// 
			// MnuMain
			// 
			this.MnuMain.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
			this.MnuMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MnuFile,
            this.MnuEdit,
            this.MnuOrder,
            this.MnuSelectWhere,
            this.MnuSettings,
            this.MnuHelp,
            this.MnuToTray});
			this.MnuMain.Location = new System.Drawing.Point(0, 0);
			this.MnuMain.Margin = new System.Windows.Forms.Padding(6, 0, 0, 4);
			this.MnuMain.Name = "MnuMain";
			this.MnuMain.Padding = new System.Windows.Forms.Padding(7, 2, 0, 2);
			this.MnuMain.Size = new System.Drawing.Size(765, 26);
			this.MnuMain.TabIndex = 7;
			this.MnuMain.Text = "menuStrip1";
			// 
			// MnuFile
			// 
			this.MnuFile.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MnuFileNew,
            this.MnuFileOpen,
            this.MnuFileSave,
            this.MnuFileSaveAs,
            this.toolStripSeparator6,
            this.MnuFileExit});
			this.MnuFile.Name = "MnuFile";
			this.MnuFile.Size = new System.Drawing.Size(58, 22);
			this.MnuFile.Text = "Файл";
			// 
			// MnuFileNew
			// 
			this.MnuFileNew.Image = global::Pets.Properties.Resources.file_new;
			this.MnuFileNew.Name = "MnuFileNew";
			this.MnuFileNew.Size = new System.Drawing.Size(194, 22);
			this.MnuFileNew.Text = "Создать...";
			this.MnuFileNew.Click += new System.EventHandler(this.FileNew_Command);
			// 
			// MnuFileOpen
			// 
			this.MnuFileOpen.Image = global::Pets.Properties.Resources.file_open;
			this.MnuFileOpen.Name = "MnuFileOpen";
			this.MnuFileOpen.Size = new System.Drawing.Size(194, 22);
			this.MnuFileOpen.Text = "Открыть...";
			this.MnuFileOpen.Click += new System.EventHandler(this.FileOpen_Command);
			// 
			// MnuFileSave
			// 
			this.MnuFileSave.Image = global::Pets.Properties.Resources.file_save;
			this.MnuFileSave.Name = "MnuFileSave";
			this.MnuFileSave.Size = new System.Drawing.Size(194, 22);
			this.MnuFileSave.Text = "Сохранить";
			this.MnuFileSave.Click += new System.EventHandler(this.Save_Command);
			// 
			// MnuFileSaveAs
			// 
			this.MnuFileSaveAs.Image = global::Pets.Properties.Resources.file_saveas;
			this.MnuFileSaveAs.Name = "MnuFileSaveAs";
			this.MnuFileSaveAs.Size = new System.Drawing.Size(194, 22);
			this.MnuFileSaveAs.Text = "Сохранить как ...";
			this.MnuFileSaveAs.Click += new System.EventHandler(this.SaveAs_Command);
			// 
			// toolStripSeparator6
			// 
			this.toolStripSeparator6.Name = "toolStripSeparator6";
			this.toolStripSeparator6.Size = new System.Drawing.Size(191, 6);
			// 
			// MnuFileExit
			// 
			this.MnuFileExit.Image = global::Pets.Properties.Resources.exit;
			this.MnuFileExit.Name = "MnuFileExit";
			this.MnuFileExit.Size = new System.Drawing.Size(194, 22);
			this.MnuFileExit.Text = "Выход";
			this.MnuFileExit.Click += new System.EventHandler(this.Exit_Command);
			// 
			// MnuEdit
			// 
			this.MnuEdit.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MnuEditGenerate,
            this.separatorToolStripMenuItem,
            this.MnuEditAdd,
            this.MnuEditEdit,
            this.toolStripSeparator7,
            this.MnuEditDelete,
            this.MnuEditDeleteAll});
			this.MnuEdit.Name = "MnuEdit";
			this.MnuEdit.Size = new System.Drawing.Size(71, 22);
			this.MnuEdit.Text = "Правка";
			// 
			// MnuEditGenerate
			// 
			this.MnuEditGenerate.Image = global::Pets.Properties.Resources.regenerate;
			this.MnuEditGenerate.Name = "MnuEditGenerate";
			this.MnuEditGenerate.Size = new System.Drawing.Size(266, 22);
			this.MnuEditGenerate.Text = "Сформировать коллекцию";
			this.MnuEditGenerate.Click += new System.EventHandler(this.GenerateCollection_Command);
			// 
			// separatorToolStripMenuItem
			// 
			this.separatorToolStripMenuItem.Name = "separatorToolStripMenuItem";
			this.separatorToolStripMenuItem.Size = new System.Drawing.Size(263, 6);
			// 
			// MnuEditAdd
			// 
			this.MnuEditAdd.Image = global::Pets.Properties.Resources.add;
			this.MnuEditAdd.Name = "MnuEditAdd";
			this.MnuEditAdd.Size = new System.Drawing.Size(266, 22);
			this.MnuEditAdd.Text = "Добавить прибор";
			this.MnuEditAdd.Click += new System.EventHandler(this.Add_Command);
			// 
			// MnuEditEdit
			// 
			this.MnuEditEdit.Image = global::Pets.Properties.Resources.edit;
			this.MnuEditEdit.Name = "MnuEditEdit";
			this.MnuEditEdit.Size = new System.Drawing.Size(266, 22);
			this.MnuEditEdit.Text = "Изменить прибор";
			this.MnuEditEdit.Click += new System.EventHandler(this.Edit_Command);
			// 
			// toolStripSeparator7
			// 
			this.toolStripSeparator7.Name = "toolStripSeparator7";
			this.toolStripSeparator7.Size = new System.Drawing.Size(263, 6);
			// 
			// MnuEditDelete
			// 
			this.MnuEditDelete.Image = global::Pets.Properties.Resources.remove;
			this.MnuEditDelete.Name = "MnuEditDelete";
			this.MnuEditDelete.Size = new System.Drawing.Size(266, 22);
			this.MnuEditDelete.Text = "Удалить прибор";
			this.MnuEditDelete.Click += new System.EventHandler(this.Delete_Command);
			// 
			// MnuEditDeleteAll
			// 
			this.MnuEditDeleteAll.Image = global::Pets.Properties.Resources.remove_all;
			this.MnuEditDeleteAll.Name = "MnuEditDeleteAll";
			this.MnuEditDeleteAll.Size = new System.Drawing.Size(266, 22);
			this.MnuEditDeleteAll.Text = "Удалить все приборы";
			this.MnuEditDeleteAll.Click += new System.EventHandler(this.DeleteAll_Command);
			// 
			// MnuOrder
			// 
			this.MnuOrder.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MnuOrderByAge,
            this.MnuOrderBySpecies,
            this.MnuOrderByOwners});
			this.MnuOrder.Name = "MnuOrder";
			this.MnuOrder.Size = new System.Drawing.Size(104, 22);
			this.MnuOrder.Text = "Сортировка";
			// 
			// MnuOrderByAge
			// 
			this.MnuOrderByAge.Name = "MnuOrderByAge";
			this.MnuOrderByAge.Size = new System.Drawing.Size(263, 22);
			this.MnuOrderByAge.Text = "По возрасту";
			this.MnuOrderByAge.Click += new System.EventHandler(this.OrderByAge_Command);
			// 
			// MnuOrderBySpecies
			// 
			this.MnuOrderBySpecies.Name = "MnuOrderBySpecies";
			this.MnuOrderBySpecies.Size = new System.Drawing.Size(263, 22);
			this.MnuOrderBySpecies.Text = "По виду";
			this.MnuOrderBySpecies.Click += new System.EventHandler(this.OrderBySpecies_Command);
			// 
			// MnuOrderByOwners
			// 
			this.MnuOrderByOwners.Name = "MnuOrderByOwners";
			this.MnuOrderByOwners.Size = new System.Drawing.Size(263, 22);
			this.MnuOrderByOwners.Text = "По фамилиям владельцев";
			this.MnuOrderByOwners.Click += new System.EventHandler(this.OrderByOwner_Command);
			// 
			// MnuSelectWhere
			// 
			this.MnuSelectWhere.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MnuSelectWhereOwner,
            this.MnuSelectWhereMaxWeight});
			this.MnuSelectWhere.Name = "MnuSelectWhere";
			this.MnuSelectWhere.Size = new System.Drawing.Size(73, 22);
			this.MnuSelectWhere.Text = "Фильтр";
			// 
			// MnuSelectWhereOwner
			// 
			this.MnuSelectWhereOwner.Image = global::Pets.Properties.Resources.owner;
			this.MnuSelectWhereOwner.Name = "MnuSelectWhereOwner";
			this.MnuSelectWhereOwner.Size = new System.Drawing.Size(249, 22);
			this.MnuSelectWhereOwner.Text = "По фамилии владельца";
			this.MnuSelectWhereOwner.Click += new System.EventHandler(this.SelectWhereOwnerName_Command);
			// 
			// MnuSelectWhereMaxWeight
			// 
			this.MnuSelectWhereMaxWeight.Image = global::Pets.Properties.Resources.weight;
			this.MnuSelectWhereMaxWeight.Name = "MnuSelectWhereMaxWeight";
			this.MnuSelectWhereMaxWeight.Size = new System.Drawing.Size(249, 22);
			this.MnuSelectWhereMaxWeight.Text = "По максимальному весу";
			this.MnuSelectWhereMaxWeight.Click += new System.EventHandler(this.SelectWhereMaxWeight_Command);
			// 
			// MnuSettings
			// 
			this.MnuSettings.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MnuSettingsEditPetClubInfo,
            this.toolStripSeparator9,
            this.MnuSettingsFont,
            this.MnuSettingsBackColor,
            this.MnuSettingsForeColor});
			this.MnuSettings.Name = "MnuSettings";
			this.MnuSettings.Size = new System.Drawing.Size(95, 22);
			this.MnuSettings.Text = "Настройки";
			// 
			// MnuSettingsEditPetClubInfo
			// 
			this.MnuSettingsEditPetClubInfo.Image = global::Pets.Properties.Resources.settings;
			this.MnuSettingsEditPetClubInfo.Name = "MnuSettingsEditPetClubInfo";
			this.MnuSettingsEditPetClubInfo.Size = new System.Drawing.Size(342, 22);
			this.MnuSettingsEditPetClubInfo.Text = "Изменить данные о клубе питомцев...";
			this.MnuSettingsEditPetClubInfo.Click += new System.EventHandler(this.PetsClubSettings_Command);
			// 
			// toolStripSeparator9
			// 
			this.toolStripSeparator9.Name = "toolStripSeparator9";
			this.toolStripSeparator9.Size = new System.Drawing.Size(339, 6);
			// 
			// MnuSettingsFont
			// 
			this.MnuSettingsFont.Image = global::Pets.Properties.Resources.font;
			this.MnuSettingsFont.Name = "MnuSettingsFont";
			this.MnuSettingsFont.Size = new System.Drawing.Size(342, 22);
			this.MnuSettingsFont.Text = "Шрифт...";
			this.MnuSettingsFont.Click += new System.EventHandler(this.Font_Command);
			// 
			// MnuSettingsBackColor
			// 
			this.MnuSettingsBackColor.Image = global::Pets.Properties.Resources.color_management;
			this.MnuSettingsBackColor.Name = "MnuSettingsBackColor";
			this.MnuSettingsBackColor.Size = new System.Drawing.Size(342, 22);
			this.MnuSettingsBackColor.Text = "Цвет фона...";
			this.MnuSettingsBackColor.Click += new System.EventHandler(this.BackColor_Command);
			// 
			// MnuSettingsForeColor
			// 
			this.MnuSettingsForeColor.Image = global::Pets.Properties.Resources.font_color;
			this.MnuSettingsForeColor.Name = "MnuSettingsForeColor";
			this.MnuSettingsForeColor.Size = new System.Drawing.Size(342, 22);
			this.MnuSettingsForeColor.Text = "Цвет текста...";
			this.MnuSettingsForeColor.Click += new System.EventHandler(this.ForeColor_Command);
			// 
			// MnuHelp
			// 
			this.MnuHelp.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MnuHelpAbout});
			this.MnuHelp.Name = "MnuHelp";
			this.MnuHelp.Size = new System.Drawing.Size(79, 22);
			this.MnuHelp.Text = "Справка";
			// 
			// MnuHelpAbout
			// 
			this.MnuHelpAbout.Image = global::Pets.Properties.Resources.about;
			this.MnuHelpAbout.Name = "MnuHelpAbout";
			this.MnuHelpAbout.Size = new System.Drawing.Size(180, 22);
			this.MnuHelpAbout.Text = "О программе";
			this.MnuHelpAbout.Click += new System.EventHandler(this.About_Command);
			// 
			// MnuToTray
			// 
			this.MnuToTray.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
			this.MnuToTray.Image = global::Pets.Properties.Resources.to_tray;
			this.MnuToTray.Margin = new System.Windows.Forms.Padding(0, 0, 20, 0);
			this.MnuToTray.Name = "MnuToTray";
			this.MnuToTray.Size = new System.Drawing.Size(28, 22);
			this.MnuToTray.Click += new System.EventHandler(this.ToTray_Command);
			// 
			// TsbMain
			// 
			this.TsbMain.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.TsbMain.ImageScalingSize = new System.Drawing.Size(30, 30);
			this.TsbMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.TsbNew,
            this.TsbFileOpen,
            this.TsbSave,
            this.TsbSaveAs,
            this.toolStripSeparator8,
            this.TsbGenerate,
            this.toolStripSeparator1,
            this.TsbAdd,
            this.TsbEdit,
            this.TsbDelete,
            this.TsbDeleteAll,
            this.toolStripSeparator5,
            this.TsbOrderBy,
            this.toolStripSeparator2,
            this.TsbExit,
            this.TstrAbout,
            this.TsbSelectWhereMaxWeight,
            this.TsbSelectWhereOwner});
			this.TsbMain.Location = new System.Drawing.Point(0, 26);
			this.TsbMain.Name = "TsbMain";
			this.TsbMain.Padding = new System.Windows.Forms.Padding(6, 1, 17, 1);
			this.TsbMain.Size = new System.Drawing.Size(765, 39);
			this.TsbMain.TabIndex = 9;
			this.TsbMain.Text = "toolStrip1";
			// 
			// TsbNew
			// 
			this.TsbNew.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.TsbNew.Image = global::Pets.Properties.Resources.file_new;
			this.TsbNew.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.TsbNew.Name = "TsbNew";
			this.TsbNew.Size = new System.Drawing.Size(34, 34);
			this.TsbNew.Text = "Новая сеть электроприборов...";
			this.TsbNew.Click += new System.EventHandler(this.FileNew_Command);
			// 
			// TsbFileOpen
			// 
			this.TsbFileOpen.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.TsbFileOpen.Image = global::Pets.Properties.Resources.file_open;
			this.TsbFileOpen.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.TsbFileOpen.Name = "TsbFileOpen";
			this.TsbFileOpen.Size = new System.Drawing.Size(34, 34);
			this.TsbFileOpen.Text = "Открыть...";
			this.TsbFileOpen.Click += new System.EventHandler(this.FileOpen_Command);
			// 
			// TsbSave
			// 
			this.TsbSave.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.TsbSave.Image = global::Pets.Properties.Resources.file_save;
			this.TsbSave.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.TsbSave.Name = "TsbSave";
			this.TsbSave.Size = new System.Drawing.Size(34, 34);
			this.TsbSave.Text = "Сохранить";
			this.TsbSave.Click += new System.EventHandler(this.Save_Command);
			// 
			// TsbSaveAs
			// 
			this.TsbSaveAs.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.TsbSaveAs.Image = global::Pets.Properties.Resources.file_saveas;
			this.TsbSaveAs.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.TsbSaveAs.Name = "TsbSaveAs";
			this.TsbSaveAs.Size = new System.Drawing.Size(34, 34);
			this.TsbSaveAs.Text = "Сохранить как...";
			this.TsbSaveAs.Click += new System.EventHandler(this.SaveAs_Command);
			// 
			// toolStripSeparator8
			// 
			this.toolStripSeparator8.Name = "toolStripSeparator8";
			this.toolStripSeparator8.Size = new System.Drawing.Size(6, 37);
			// 
			// TsbGenerate
			// 
			this.TsbGenerate.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.TsbGenerate.Image = global::Pets.Properties.Resources.regenerate;
			this.TsbGenerate.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.TsbGenerate.Name = "TsbGenerate";
			this.TsbGenerate.Size = new System.Drawing.Size(34, 34);
			this.TsbGenerate.ToolTipText = "Сформировать коллекцию";
			this.TsbGenerate.Click += new System.EventHandler(this.GenerateCollection_Command);
			// 
			// toolStripSeparator1
			// 
			this.toolStripSeparator1.Name = "toolStripSeparator1";
			this.toolStripSeparator1.Size = new System.Drawing.Size(6, 37);
			// 
			// TsbAdd
			// 
			this.TsbAdd.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.TsbAdd.Image = global::Pets.Properties.Resources.add;
			this.TsbAdd.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.TsbAdd.Name = "TsbAdd";
			this.TsbAdd.Size = new System.Drawing.Size(34, 34);
			this.TsbAdd.Text = "Добавить прибор";
			this.TsbAdd.Click += new System.EventHandler(this.Add_Command);
			// 
			// TsbEdit
			// 
			this.TsbEdit.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.TsbEdit.Image = global::Pets.Properties.Resources.edit;
			this.TsbEdit.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.TsbEdit.Name = "TsbEdit";
			this.TsbEdit.Size = new System.Drawing.Size(34, 34);
			this.TsbEdit.Text = "Редактировать прибор";
			this.TsbEdit.Click += new System.EventHandler(this.Edit_Command);
			// 
			// TsbDelete
			// 
			this.TsbDelete.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.TsbDelete.Image = global::Pets.Properties.Resources.remove;
			this.TsbDelete.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.TsbDelete.Name = "TsbDelete";
			this.TsbDelete.Size = new System.Drawing.Size(34, 34);
			this.TsbDelete.ToolTipText = "Удаление выбранного прибора";
			this.TsbDelete.Click += new System.EventHandler(this.Delete_Command);
			// 
			// TsbDeleteAll
			// 
			this.TsbDeleteAll.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.TsbDeleteAll.Image = global::Pets.Properties.Resources.remove_all;
			this.TsbDeleteAll.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.TsbDeleteAll.Name = "TsbDeleteAll";
			this.TsbDeleteAll.Size = new System.Drawing.Size(34, 34);
			this.TsbDeleteAll.ToolTipText = "Удаление всех приборов";
			this.TsbDeleteAll.Click += new System.EventHandler(this.DeleteAll_Command);
			// 
			// toolStripSeparator5
			// 
			this.toolStripSeparator5.Name = "toolStripSeparator5";
			this.toolStripSeparator5.Size = new System.Drawing.Size(6, 37);
			// 
			// TsbOrderBy
			// 
			this.TsbOrderBy.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.TsbOrderBy.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.TstrOrderByAge,
            this.TstrOrderBySpecies,
            this.TstrOrderByOwner});
			this.TsbOrderBy.Image = global::Pets.Properties.Resources.order_name;
			this.TsbOrderBy.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.TsbOrderBy.Name = "TsbOrderBy";
			this.TsbOrderBy.Size = new System.Drawing.Size(43, 34);
			this.TsbOrderBy.ToolTipText = "Сортировка приборов\r\nпо наименованию";
			// 
			// TstrOrderByAge
			// 
			this.TstrOrderByAge.Name = "TstrOrderByAge";
			this.TstrOrderByAge.Size = new System.Drawing.Size(261, 24);
			this.TstrOrderByAge.Text = "По возрасту";
			this.TstrOrderByAge.Click += new System.EventHandler(this.OrderByAge_Command);
			// 
			// TstrOrderBySpecies
			// 
			this.TstrOrderBySpecies.Name = "TstrOrderBySpecies";
			this.TstrOrderBySpecies.Size = new System.Drawing.Size(261, 24);
			this.TstrOrderBySpecies.Text = "По виду";
			this.TstrOrderBySpecies.Click += new System.EventHandler(this.OrderBySpecies_Command);
			// 
			// TstrOrderByOwner
			// 
			this.TstrOrderByOwner.Name = "TstrOrderByOwner";
			this.TstrOrderByOwner.Size = new System.Drawing.Size(261, 24);
			this.TstrOrderByOwner.Text = "По фамилиям владельцев";
			this.TstrOrderByOwner.Click += new System.EventHandler(this.OrderByOwner_Command);
			// 
			// toolStripSeparator2
			// 
			this.toolStripSeparator2.Name = "toolStripSeparator2";
			this.toolStripSeparator2.Size = new System.Drawing.Size(6, 37);
			// 
			// TsbExit
			// 
			this.TsbExit.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
			this.TsbExit.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.TsbExit.Image = global::Pets.Properties.Resources.exit;
			this.TsbExit.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.TsbExit.Name = "TsbExit";
			this.TsbExit.Size = new System.Drawing.Size(34, 34);
			this.TsbExit.Text = "toolStripButton10";
			this.TsbExit.ToolTipText = "Завершение работы приложения";
			this.TsbExit.Click += new System.EventHandler(this.Exit_Command);
			// 
			// TstrAbout
			// 
			this.TstrAbout.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
			this.TstrAbout.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.TstrAbout.Image = global::Pets.Properties.Resources.about;
			this.TstrAbout.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.TstrAbout.Margin = new System.Windows.Forms.Padding(0, 1, 0, 1);
			this.TstrAbout.Name = "TstrAbout";
			this.TstrAbout.Size = new System.Drawing.Size(34, 35);
			this.TstrAbout.Text = "toolStripButton9";
			this.TstrAbout.ToolTipText = "О программе";
			this.TstrAbout.Click += new System.EventHandler(this.About_Command);
			// 
			// TsbSelectWhereMaxWeight
			// 
			this.TsbSelectWhereMaxWeight.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.TsbSelectWhereMaxWeight.Image = global::Pets.Properties.Resources.weight;
			this.TsbSelectWhereMaxWeight.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.TsbSelectWhereMaxWeight.Name = "TsbSelectWhereMaxWeight";
			this.TsbSelectWhereMaxWeight.Size = new System.Drawing.Size(34, 34);
			this.TsbSelectWhereMaxWeight.Text = "Фильтр по максимальному весу";
			this.TsbSelectWhereMaxWeight.Click += new System.EventHandler(this.SelectWhereMaxWeight_Command);
			// 
			// TsbSelectWhereOwner
			// 
			this.TsbSelectWhereOwner.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.TsbSelectWhereOwner.Image = global::Pets.Properties.Resources.owner;
			this.TsbSelectWhereOwner.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.TsbSelectWhereOwner.Name = "TsbSelectWhereOwner";
			this.TsbSelectWhereOwner.Size = new System.Drawing.Size(34, 34);
			this.TsbSelectWhereOwner.Text = "Фильтр по фамилии владельца";
			this.TsbSelectWhereOwner.Click += new System.EventHandler(this.SelectWhereOwnerName_Command);
			// 
			// ImlPets
			// 
			this.ImlPets.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("ImlPets.ImageStream")));
			this.ImlPets.TransparentColor = System.Drawing.Color.Transparent;
			this.ImlPets.Images.SetKeyName(0, "bird.png");
			this.ImlPets.Images.SetKeyName(1, "bull.png");
			this.ImlPets.Images.SetKeyName(2, "cat.png");
			this.ImlPets.Images.SetKeyName(3, "cow.png");
			this.ImlPets.Images.SetKeyName(4, "dog.png");
			this.ImlPets.Images.SetKeyName(5, "duck.png");
			this.ImlPets.Images.SetKeyName(6, "elephant.png");
			this.ImlPets.Images.SetKeyName(7, "fish.png");
			this.ImlPets.Images.SetKeyName(8, "horse.png");
			this.ImlPets.Images.SetKeyName(9, "ladybug.png");
			this.ImlPets.Images.SetKeyName(10, "leopard.png");
			this.ImlPets.Images.SetKeyName(11, "lion.png");
			this.ImlPets.Images.SetKeyName(12, "lobster.png");
			this.ImlPets.Images.SetKeyName(13, "rabbit.png");
			this.ImlPets.Images.SetKeyName(14, "snail.png");
			this.ImlPets.Images.SetKeyName(15, "turtle.png");
			// 
			// StlMain
			// 
			this.StlMain.ContextMenuStrip = this.CmnTray;
			this.StlMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.StlLblMessage,
            this.StlLblStatus});
			this.StlMain.Location = new System.Drawing.Point(0, 488);
			this.StlMain.Name = "StlMain";
			this.StlMain.Size = new System.Drawing.Size(765, 22);
			this.StlMain.TabIndex = 14;
			this.StlMain.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.CmnTray_MouseDoubleClick);
			// 
			// StlLblMessage
			// 
			this.StlLblMessage.Name = "StlLblMessage";
			this.StlLblMessage.Size = new System.Drawing.Size(73, 19);
			this.StlLblMessage.Text = "Сообщение";
			// 
			// GrbMain
			// 
			this.GrbMain.Controls.Add(this.TbcMain);
			this.GrbMain.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.GrbMain.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.GrbMain.Location = new System.Drawing.Point(0, 72);
			this.GrbMain.Name = "GrbMain";
			this.GrbMain.Size = new System.Drawing.Size(765, 416);
			this.GrbMain.TabIndex = 15;
			this.GrbMain.TabStop = false;
			this.GrbMain.Text = "Название клуба";
			// 
			// TbcMain
			// 
			this.TbcMain.Controls.Add(this.TbpMain);
			this.TbcMain.Controls.Add(this.TbpOrder);
			this.TbcMain.Controls.Add(this.TbpSelect);
			this.TbcMain.Dock = System.Windows.Forms.DockStyle.Fill;
			this.TbcMain.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.TbcMain.Location = new System.Drawing.Point(3, 20);
			this.TbcMain.Name = "TbcMain";
			this.TbcMain.SelectedIndex = 0;
			this.TbcMain.Size = new System.Drawing.Size(759, 393);
			this.TbcMain.TabIndex = 14;
			this.TbcMain.SelectedIndexChanged += new System.EventHandler(this.TbcMain_SelectedIndexChanged);
			// 
			// TbpMain
			// 
			this.TbpMain.Controls.Add(this.LsvAnimals);
			this.TbpMain.Controls.Add(this.LblAnimals);
			this.TbpMain.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.TbpMain.ImageIndex = 0;
			this.TbpMain.Location = new System.Drawing.Point(4, 27);
			this.TbpMain.Name = "TbpMain";
			this.TbpMain.Padding = new System.Windows.Forms.Padding(3);
			this.TbpMain.Size = new System.Drawing.Size(751, 362);
			this.TbpMain.TabIndex = 0;
			this.TbpMain.Text = "Главная";
			this.TbpMain.UseVisualStyleBackColor = true;
			// 
			// LsvAnimals
			// 
			this.LsvAnimals.AllowDrop = true;
			this.LsvAnimals.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.ClhImage,
            this.ClhSpecies,
            this.ClhName,
            this.ClhAge,
            this.ClhWeight,
            this.ClhPaint,
            this.ClhOwner});
			this.LsvAnimals.ContextMenuStrip = this.CmnListView;
			this.LsvAnimals.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.LsvAnimals.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.LsvAnimals.FullRowSelect = true;
			this.LsvAnimals.GridLines = true;
			this.LsvAnimals.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
			this.LsvAnimals.HideSelection = false;
			this.LsvAnimals.LargeImageList = this.ImlPets;
			this.LsvAnimals.Location = new System.Drawing.Point(3, 32);
			this.LsvAnimals.MultiSelect = false;
			this.LsvAnimals.Name = "LsvAnimals";
			this.LsvAnimals.Size = new System.Drawing.Size(745, 327);
			this.LsvAnimals.SmallImageList = this.ImlPets;
			this.LsvAnimals.StateImageList = this.ImlPets;
			this.LsvAnimals.TabIndex = 13;
			this.LsvAnimals.UseCompatibleStateImageBehavior = false;
			this.LsvAnimals.View = System.Windows.Forms.View.Details;
			this.LsvAnimals.DragDrop += new System.Windows.Forms.DragEventHandler(this.LsvAppliances_DragDrop);
			this.LsvAnimals.DragEnter += new System.Windows.Forms.DragEventHandler(this.LsvAppliances_DragEnter);
			this.LsvAnimals.KeyDown += new System.Windows.Forms.KeyEventHandler(this.LsvAppliances_KeyDown);
			this.LsvAnimals.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.LsvAnimals_MouseDoubleClick);
			// 
			// ClhImage
			// 
			this.ClhImage.Text = "";
			this.ClhImage.Width = 107;
			// 
			// ClhSpecies
			// 
			this.ClhSpecies.Text = "Вид";
			this.ClhSpecies.Width = 118;
			// 
			// ClhName
			// 
			this.ClhName.Text = "Кличка";
			this.ClhName.Width = 100;
			// 
			// ClhAge
			// 
			this.ClhAge.Text = "Возраст, г";
			this.ClhAge.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.ClhAge.Width = 93;
			// 
			// ClhWeight
			// 
			this.ClhWeight.Text = "Вес, кг";
			this.ClhWeight.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			// 
			// ClhPaint
			// 
			this.ClhPaint.Text = "Цвет";
			this.ClhPaint.Width = 90;
			// 
			// ClhOwner
			// 
			this.ClhOwner.Text = "Владелец";
			this.ClhOwner.Width = 151;
			// 
			// LblAnimals
			// 
			this.LblAnimals.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.24F);
			this.LblAnimals.Location = new System.Drawing.Point(8, 8);
			this.LblAnimals.Name = "LblAnimals";
			this.LblAnimals.Size = new System.Drawing.Size(144, 20);
			this.LblAnimals.TabIndex = 12;
			this.LblAnimals.Text = "Список питомцев:";
			// 
			// TbpOrder
			// 
			this.TbpOrder.Controls.Add(this.LsvOrdered);
			this.TbpOrder.Controls.Add(this.LblOrdered);
			this.TbpOrder.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.TbpOrder.ImageIndex = 1;
			this.TbpOrder.Location = new System.Drawing.Point(4, 27);
			this.TbpOrder.Name = "TbpOrder";
			this.TbpOrder.Padding = new System.Windows.Forms.Padding(3);
			this.TbpOrder.Size = new System.Drawing.Size(751, 362);
			this.TbpOrder.TabIndex = 1;
			this.TbpOrder.Text = "Упорядоченные данные";
			this.TbpOrder.UseVisualStyleBackColor = true;
			// 
			// LsvOrdered
			// 
			this.LsvOrdered.AllowDrop = true;
			this.LsvOrdered.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3,
            this.columnHeader4,
            this.columnHeader5,
            this.columnHeader6,
            this.columnHeader7});
			this.LsvOrdered.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.LsvOrdered.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.LsvOrdered.FullRowSelect = true;
			this.LsvOrdered.GridLines = true;
			this.LsvOrdered.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
			this.LsvOrdered.HideSelection = false;
			this.LsvOrdered.LargeImageList = this.ImlPets;
			this.LsvOrdered.Location = new System.Drawing.Point(3, 32);
			this.LsvOrdered.MultiSelect = false;
			this.LsvOrdered.Name = "LsvOrdered";
			this.LsvOrdered.Size = new System.Drawing.Size(745, 327);
			this.LsvOrdered.SmallImageList = this.ImlPets;
			this.LsvOrdered.StateImageList = this.ImlPets;
			this.LsvOrdered.TabIndex = 15;
			this.LsvOrdered.UseCompatibleStateImageBehavior = false;
			this.LsvOrdered.View = System.Windows.Forms.View.Details;
			// 
			// columnHeader1
			// 
			this.columnHeader1.Text = "     ";
			this.columnHeader1.Width = 107;
			// 
			// columnHeader2
			// 
			this.columnHeader2.Text = "Вид";
			this.columnHeader2.Width = 118;
			// 
			// columnHeader3
			// 
			this.columnHeader3.Text = "Кличка";
			this.columnHeader3.Width = 100;
			// 
			// columnHeader4
			// 
			this.columnHeader4.Text = "Возраст, г";
			this.columnHeader4.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.columnHeader4.Width = 93;
			// 
			// columnHeader5
			// 
			this.columnHeader5.Text = "Вес, кг";
			this.columnHeader5.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			// 
			// columnHeader6
			// 
			this.columnHeader6.Text = "Цвет";
			this.columnHeader6.Width = 90;
			// 
			// columnHeader7
			// 
			this.columnHeader7.Text = "Владелец";
			this.columnHeader7.Width = 151;
			// 
			// LblOrdered
			// 
			this.LblOrdered.AutoSize = true;
			this.LblOrdered.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.24F);
			this.LblOrdered.Location = new System.Drawing.Point(8, 6);
			this.LblOrdered.Name = "LblOrdered";
			this.LblOrdered.Size = new System.Drawing.Size(135, 18);
			this.LblOrdered.TabIndex = 14;
			this.LblOrdered.Text = "Список питомцев:";
			// 
			// TbpSelect
			// 
			this.TbpSelect.Controls.Add(this.TxbOwnerInput);
			this.TbpSelect.Controls.Add(this.LsvSelected);
			this.TbpSelect.Controls.Add(this.LblSelected);
			this.TbpSelect.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.TbpSelect.ImageIndex = 2;
			this.TbpSelect.Location = new System.Drawing.Point(4, 27);
			this.TbpSelect.Name = "TbpSelect";
			this.TbpSelect.Padding = new System.Windows.Forms.Padding(3);
			this.TbpSelect.Size = new System.Drawing.Size(751, 362);
			this.TbpSelect.TabIndex = 2;
			this.TbpSelect.Text = "Фильтр";
			this.TbpSelect.UseVisualStyleBackColor = true;
			// 
			// TxbOwnerInput
			// 
			this.TxbOwnerInput.Location = new System.Drawing.Point(287, 5);
			this.TxbOwnerInput.Name = "TxbOwnerInput";
			this.TxbOwnerInput.Size = new System.Drawing.Size(176, 24);
			this.TxbOwnerInput.TabIndex = 16;
			this.TxbOwnerInput.TextChanged += new System.EventHandler(this.TxbOwnerInput_TextChanged);
			// 
			// LsvSelected
			// 
			this.LsvSelected.AllowDrop = true;
			this.LsvSelected.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader8,
            this.columnHeader9,
            this.columnHeader10,
            this.columnHeader11,
            this.columnHeader12,
            this.columnHeader13,
            this.columnHeader14});
			this.LsvSelected.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.LsvSelected.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.LsvSelected.FullRowSelect = true;
			this.LsvSelected.GridLines = true;
			this.LsvSelected.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
			this.LsvSelected.HideSelection = false;
			this.LsvSelected.LargeImageList = this.ImlPets;
			this.LsvSelected.Location = new System.Drawing.Point(3, 32);
			this.LsvSelected.MultiSelect = false;
			this.LsvSelected.Name = "LsvSelected";
			this.LsvSelected.Size = new System.Drawing.Size(745, 327);
			this.LsvSelected.SmallImageList = this.ImlPets;
			this.LsvSelected.StateImageList = this.ImlPets;
			this.LsvSelected.TabIndex = 15;
			this.LsvSelected.UseCompatibleStateImageBehavior = false;
			this.LsvSelected.View = System.Windows.Forms.View.Details;
			// 
			// columnHeader8
			// 
			this.columnHeader8.Text = "     ";
			this.columnHeader8.Width = 107;
			// 
			// columnHeader9
			// 
			this.columnHeader9.Text = "Вид";
			this.columnHeader9.Width = 118;
			// 
			// columnHeader10
			// 
			this.columnHeader10.Text = "Кличка";
			this.columnHeader10.Width = 100;
			// 
			// columnHeader11
			// 
			this.columnHeader11.Text = "Возраст, г";
			this.columnHeader11.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.columnHeader11.Width = 93;
			// 
			// columnHeader12
			// 
			this.columnHeader12.Text = "Вес, кг";
			this.columnHeader12.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			// 
			// columnHeader13
			// 
			this.columnHeader13.Text = "Цвет";
			this.columnHeader13.Width = 90;
			// 
			// columnHeader14
			// 
			this.columnHeader14.Text = "Владелец";
			this.columnHeader14.Width = 151;
			// 
			// LblSelected
			// 
			this.LblSelected.AutoSize = true;
			this.LblSelected.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.24F);
			this.LblSelected.Location = new System.Drawing.Point(8, 6);
			this.LblSelected.Name = "LblSelected";
			this.LblSelected.Size = new System.Drawing.Size(277, 18);
			this.LblSelected.TabIndex = 14;
			this.LblSelected.Text = "Введите часть фамилии для фильтра:";
			// 
			// SfdMain
			// 
			this.SfdMain.FileName = "PetsClub.json";
			this.SfdMain.Filter = "Файлы JSON(*.json)|*.json";
			this.SfdMain.SupportMultiDottedExtensions = true;
			this.SfdMain.Title = "Сохранить данные в файл";
			// 
			// OfdMain
			// 
			this.OfdMain.FileName = "PetsClub.json";
			this.OfdMain.Filter = "Файлы JSON(*.json)|*.json";
			this.OfdMain.Title = "Загрузить данные из файла";
			// 
			// CmnListView
			// 
			this.CmnListView.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
			this.CmnListView.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.CmnListViewAdd,
            this.CmnListViewEdit,
            this.CmnListViewRemove});
			this.CmnListView.Name = "CmnList";
			this.CmnListView.Size = new System.Drawing.Size(158, 70);
			// 
			// CmnListViewAdd
			// 
			this.CmnListViewAdd.Image = global::Pets.Properties.Resources.add;
			this.CmnListViewAdd.Name = "CmnListViewAdd";
			this.CmnListViewAdd.Size = new System.Drawing.Size(157, 22);
			this.CmnListViewAdd.Text = "Добавить...";
			this.CmnListViewAdd.Click += new System.EventHandler(this.Add_Command);
			// 
			// CmnListViewEdit
			// 
			this.CmnListViewEdit.Image = global::Pets.Properties.Resources.edit;
			this.CmnListViewEdit.Name = "CmnListViewEdit";
			this.CmnListViewEdit.Size = new System.Drawing.Size(157, 22);
			this.CmnListViewEdit.Text = "Изменить...";
			this.CmnListViewEdit.Click += new System.EventHandler(this.Edit_Command);
			// 
			// CmnListViewRemove
			// 
			this.CmnListViewRemove.Image = global::Pets.Properties.Resources.remove;
			this.CmnListViewRemove.Name = "CmnListViewRemove";
			this.CmnListViewRemove.Size = new System.Drawing.Size(157, 22);
			this.CmnListViewRemove.Text = "Удалить";
			this.CmnListViewRemove.Click += new System.EventHandler(this.Delete_Command);
			// 
			// CmnTray
			// 
			this.CmnTray.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.CmnTrayRestore,
            this.CmnTrayAbout,
            this.toolStripSeparator11,
            this.CmnTrayExit});
			this.CmnTray.Name = "CmnTray";
			this.CmnTray.Size = new System.Drawing.Size(159, 76);
			this.CmnTray.Text = "RepairShop";
			// 
			// CmnTrayRestore
			// 
			this.CmnTrayRestore.Image = global::Pets.Properties.Resources.restore;
			this.CmnTrayRestore.Name = "CmnTrayRestore";
			this.CmnTrayRestore.Size = new System.Drawing.Size(158, 22);
			this.CmnTrayRestore.Text = "Восстановить";
			this.CmnTrayRestore.Click += new System.EventHandler(this.Restore_Command);
			// 
			// CmnTrayAbout
			// 
			this.CmnTrayAbout.Image = global::Pets.Properties.Resources.about;
			this.CmnTrayAbout.Name = "CmnTrayAbout";
			this.CmnTrayAbout.Size = new System.Drawing.Size(158, 22);
			this.CmnTrayAbout.Text = "О программе...";
			this.CmnTrayAbout.Click += new System.EventHandler(this.About_Command);
			// 
			// toolStripSeparator11
			// 
			this.toolStripSeparator11.Name = "toolStripSeparator11";
			this.toolStripSeparator11.Size = new System.Drawing.Size(155, 6);
			// 
			// CmnTrayExit
			// 
			this.CmnTrayExit.Image = global::Pets.Properties.Resources.exit;
			this.CmnTrayExit.Name = "CmnTrayExit";
			this.CmnTrayExit.Size = new System.Drawing.Size(158, 22);
			this.CmnTrayExit.Text = "Выход";
			this.CmnTrayExit.Click += new System.EventHandler(this.Exit_Command);
			// 
			// CmnForm
			// 
			this.CmnForm.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.CmnFormAbout,
            this.CmnFormExit});
			this.CmnForm.Name = "contextMenuStrip1";
			this.CmnForm.Size = new System.Drawing.Size(156, 48);
			// 
			// CmnFormAbout
			// 
			this.CmnFormAbout.Image = global::Pets.Properties.Resources.about;
			this.CmnFormAbout.Name = "CmnFormAbout";
			this.CmnFormAbout.Size = new System.Drawing.Size(155, 22);
			this.CmnFormAbout.Text = "О программе..";
			this.CmnFormAbout.Click += new System.EventHandler(this.About_Command);
			// 
			// CmnFormExit
			// 
			this.CmnFormExit.Image = global::Pets.Properties.Resources.exit;
			this.CmnFormExit.Name = "CmnFormExit";
			this.CmnFormExit.Size = new System.Drawing.Size(155, 22);
			this.CmnFormExit.Text = "Выход";
			this.CmnFormExit.Click += new System.EventHandler(this.Exit_Command);
			// 
			// NtiMain
			// 
			this.NtiMain.ContextMenuStrip = this.CmnTray;
			this.NtiMain.Icon = ((System.Drawing.Icon)(resources.GetObject("NtiMain.Icon")));
			this.NtiMain.Text = "AppliancesNetwork";
			this.NtiMain.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.CmnTray_MouseDoubleClick);
			// 
			// FdlTextFont
			// 
			this.FdlTextFont.Font = new System.Drawing.Font("Consolas", 12F);
			this.FdlTextFont.ShowApply = true;
			this.FdlTextFont.ShowColor = true;
			this.FdlTextFont.Apply += new System.EventHandler(this.FdlTextFont_Apply);
			// 
			// CdlBackColor
			// 
			this.CdlBackColor.AnyColor = true;
			this.CdlBackColor.FullOpen = true;
			// 
			// StlLblStatus
			// 
			this.StlLblStatus.Name = "StlLblStatus";
			this.StlLblStatus.Size = new System.Drawing.Size(677, 17);
			this.StlLblStatus.Spring = true;
			this.StlLblStatus.Text = "toolStripStatusLabel2";
			this.StlLblStatus.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// MainForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(765, 510);
			this.ContextMenuStrip = this.CmnForm;
			this.Controls.Add(this.GrbMain);
			this.Controls.Add(this.StlMain);
			this.Controls.Add(this.TsbMain);
			this.Controls.Add(this.MnuMain);
			this.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Margin = new System.Windows.Forms.Padding(4);
			this.MaximizeBox = false;
			this.Name = "MainForm";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "PetClub";
			this.Load += new System.EventHandler(this.MainForm_Load);
			this.MnuMain.ResumeLayout(false);
			this.MnuMain.PerformLayout();
			this.TsbMain.ResumeLayout(false);
			this.TsbMain.PerformLayout();
			this.StlMain.ResumeLayout(false);
			this.StlMain.PerformLayout();
			this.GrbMain.ResumeLayout(false);
			this.TbcMain.ResumeLayout(false);
			this.TbpMain.ResumeLayout(false);
			this.TbpOrder.ResumeLayout(false);
			this.TbpOrder.PerformLayout();
			this.TbpSelect.ResumeLayout(false);
			this.TbpSelect.PerformLayout();
			this.CmnListView.ResumeLayout(false);
			this.CmnTray.ResumeLayout(false);
			this.CmnForm.ResumeLayout(false);
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.MenuStrip MnuMain;
		private System.Windows.Forms.ToolStripMenuItem MnuFile;
		private System.Windows.Forms.ToolStripMenuItem MnuFileNew;
		private System.Windows.Forms.ToolStripMenuItem MnuFileOpen;
		private System.Windows.Forms.ToolStripMenuItem MnuFileSave;
		private System.Windows.Forms.ToolStripMenuItem MnuFileSaveAs;
		private System.Windows.Forms.ToolStripSeparator toolStripSeparator6;
		private System.Windows.Forms.ToolStripMenuItem MnuFileExit;
		private System.Windows.Forms.ToolStripMenuItem MnuEdit;
		private System.Windows.Forms.ToolStripMenuItem MnuEditGenerate;
		private System.Windows.Forms.ToolStripSeparator separatorToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem MnuEditAdd;
		private System.Windows.Forms.ToolStripMenuItem MnuEditEdit;
		private System.Windows.Forms.ToolStripSeparator toolStripSeparator7;
		private System.Windows.Forms.ToolStripMenuItem MnuEditDelete;
		private System.Windows.Forms.ToolStripMenuItem MnuEditDeleteAll;
		private System.Windows.Forms.ToolStripMenuItem MnuOrder;
		private System.Windows.Forms.ToolStripMenuItem MnuOrderByAge;
		private System.Windows.Forms.ToolStripMenuItem MnuOrderBySpecies;
		private System.Windows.Forms.ToolStripMenuItem MnuOrderByOwners;
		private System.Windows.Forms.ToolStripMenuItem MnuSelectWhere;
		private System.Windows.Forms.ToolStripMenuItem MnuSelectWhereOwner;
		private System.Windows.Forms.ToolStripMenuItem MnuSelectWhereMaxWeight;
		private System.Windows.Forms.ToolStripMenuItem MnuSettings;
		private System.Windows.Forms.ToolStripMenuItem MnuSettingsEditPetClubInfo;
		private System.Windows.Forms.ToolStripSeparator toolStripSeparator9;
		private System.Windows.Forms.ToolStripMenuItem MnuSettingsFont;
		private System.Windows.Forms.ToolStripMenuItem MnuSettingsBackColor;
		private System.Windows.Forms.ToolStripMenuItem MnuSettingsForeColor;
		private System.Windows.Forms.ToolStripMenuItem MnuHelp;
		private System.Windows.Forms.ToolStripMenuItem MnuHelpAbout;
		private System.Windows.Forms.ToolStripMenuItem MnuToTray;
		private System.Windows.Forms.ToolStrip TsbMain;
		private System.Windows.Forms.ToolStripButton TsbNew;
		private System.Windows.Forms.ToolStripButton TsbFileOpen;
		private System.Windows.Forms.ToolStripButton TsbSave;
		private System.Windows.Forms.ToolStripButton TsbSaveAs;
		private System.Windows.Forms.ToolStripSeparator toolStripSeparator8;
		private System.Windows.Forms.ToolStripButton TsbGenerate;
		private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
		private System.Windows.Forms.ToolStripButton TsbAdd;
		private System.Windows.Forms.ToolStripButton TsbEdit;
		private System.Windows.Forms.ToolStripButton TsbDelete;
		private System.Windows.Forms.ToolStripButton TsbDeleteAll;
		private System.Windows.Forms.ToolStripSeparator toolStripSeparator5;
		private System.Windows.Forms.ToolStripDropDownButton TsbOrderBy;
		private System.Windows.Forms.ToolStripMenuItem TstrOrderByAge;
		private System.Windows.Forms.ToolStripMenuItem TstrOrderBySpecies;
		private System.Windows.Forms.ToolStripMenuItem TstrOrderByOwner;
		private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
		private System.Windows.Forms.ToolStripButton TsbExit;
		private System.Windows.Forms.ToolStripButton TstrAbout;
		private System.Windows.Forms.StatusStrip StlMain;
		private System.Windows.Forms.ToolStripStatusLabel StlLblMessage;
		private System.Windows.Forms.ImageList ImlPets;
		private System.Windows.Forms.GroupBox GrbMain;
		private System.Windows.Forms.TabControl TbcMain;
		private System.Windows.Forms.TabPage TbpMain;
		private System.Windows.Forms.ListView LsvAnimals;
		private System.Windows.Forms.ColumnHeader ClhImage;
		private System.Windows.Forms.ColumnHeader ClhSpecies;
		private System.Windows.Forms.ColumnHeader ClhName;
		private System.Windows.Forms.ColumnHeader ClhAge;
		private System.Windows.Forms.ColumnHeader ClhWeight;
		private System.Windows.Forms.ColumnHeader ClhPaint;
		private System.Windows.Forms.ColumnHeader ClhOwner;
		private System.Windows.Forms.Label LblAnimals;
		private System.Windows.Forms.TabPage TbpOrder;
		private System.Windows.Forms.TabPage TbpSelect;
		private System.Windows.Forms.ListView LsvOrdered;
		private System.Windows.Forms.ColumnHeader columnHeader1;
		private System.Windows.Forms.ColumnHeader columnHeader2;
		private System.Windows.Forms.ColumnHeader columnHeader3;
		private System.Windows.Forms.ColumnHeader columnHeader4;
		private System.Windows.Forms.ColumnHeader columnHeader5;
		private System.Windows.Forms.ColumnHeader columnHeader6;
		private System.Windows.Forms.ColumnHeader columnHeader7;
		private System.Windows.Forms.Label LblOrdered;
		private System.Windows.Forms.ListView LsvSelected;
		private System.Windows.Forms.ColumnHeader columnHeader8;
		private System.Windows.Forms.ColumnHeader columnHeader9;
		private System.Windows.Forms.ColumnHeader columnHeader10;
		private System.Windows.Forms.ColumnHeader columnHeader11;
		private System.Windows.Forms.ColumnHeader columnHeader12;
		private System.Windows.Forms.ColumnHeader columnHeader13;
		private System.Windows.Forms.ColumnHeader columnHeader14;
		private System.Windows.Forms.Label LblSelected;
		private System.Windows.Forms.SaveFileDialog SfdMain;
		private System.Windows.Forms.OpenFileDialog OfdMain;
		private System.Windows.Forms.ToolStripButton TsbSelectWhereMaxWeight;
		private System.Windows.Forms.ToolStripButton TsbSelectWhereOwner;
		private System.Windows.Forms.TextBox TxbOwnerInput;
		private System.Windows.Forms.ContextMenuStrip CmnListView;
		private System.Windows.Forms.ToolStripMenuItem CmnListViewAdd;
		private System.Windows.Forms.ToolStripMenuItem CmnListViewEdit;
		private System.Windows.Forms.ToolStripMenuItem CmnListViewRemove;
		private System.Windows.Forms.ContextMenuStrip CmnTray;
		private System.Windows.Forms.ToolStripMenuItem CmnTrayRestore;
		private System.Windows.Forms.ToolStripMenuItem CmnTrayAbout;
		private System.Windows.Forms.ToolStripSeparator toolStripSeparator11;
		private System.Windows.Forms.ToolStripMenuItem CmnTrayExit;
		private System.Windows.Forms.ContextMenuStrip CmnForm;
		private System.Windows.Forms.ToolStripMenuItem CmnFormAbout;
		private System.Windows.Forms.ToolStripMenuItem CmnFormExit;
		private System.Windows.Forms.NotifyIcon NtiMain;
		private System.Windows.Forms.FontDialog FdlTextFont;
		private System.Windows.Forms.ColorDialog CdlBackColor;
		private System.Windows.Forms.ToolStripStatusLabel StlLblStatus;
	}
}

