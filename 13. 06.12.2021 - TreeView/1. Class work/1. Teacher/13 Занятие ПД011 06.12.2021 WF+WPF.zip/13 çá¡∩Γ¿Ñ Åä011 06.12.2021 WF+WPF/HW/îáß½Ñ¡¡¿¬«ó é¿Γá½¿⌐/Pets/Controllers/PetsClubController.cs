﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Pets.Models;
using Newtonsoft.Json;


namespace Pets.Controllers
{
	public class PetsClubController
	{
		// объект для обработки
		private PetsClub _petsClub;

		public PetsClub PetsClub
		{
			get => _petsClub;
			private set => _petsClub = value;
		}

		public List<Animal> Animals { get => _petsClub.Animals; }

		// директория и имя файля для сохранения
		public string FileName { get; set; }

		// директория и имя файля для сохранения по-умолчанию
		public static readonly string FileNameDefault = Environment.CurrentDirectory + @"\App_Data\PetsClub.json";


		// конструкторы
		public PetsClubController() : this(FileNameDefault, new PetsClub())
		{
			string dir = Path.GetDirectoryName(FileNameDefault);
			if (!Directory.Exists(dir))
				Directory.CreateDirectory(dir);

			if (File.Exists(FileNameDefault))
				ReadJsonFromFile(FileNameDefault);
			else
			{
				_petsClub.Initialize();
				SaveJsonToFile(FileNameDefault);
			}
		}

		public PetsClubController(string fileName, PetsClub petsClub)
		{
			_petsClub = petsClub;
			FileName = fileName;
		}

		// получить список владельцев
		public List<string> GetPetsOwner => _petsClub.GetAnimalsOwners();

		#region CRUD

		// добавление животного в коллекцию
		public void AddAnimal(Animal animal) => _petsClub.AddAnimal(animal);

		// удаление выбранного животного
		public void RemoveAt(int index) => _petsClub.RemoveAnimal(index);


		// удаление всех животных
		public void RemoveAll() => _petsClub.Clear();

		#endregion


		#region Сериализация
		// Сохранение в файл JSON формата
		public void SaveJsonToFile(string fileName)
		{
			using (StreamWriter file = File.CreateText(fileName))
			{
				new JsonSerializer { Formatting = Formatting.Indented }.Serialize(file, _petsClub);
			}
		}

		// Чтение из файла JSON формата
		public void ReadJsonFromFile(string fileName)
		{

			using (StreamReader file = File.OpenText(fileName))
			{
				JsonSerializer serializer = new JsonSerializer();
				_petsClub.Clear();
				_petsClub = (PetsClub)serializer.Deserialize(file, typeof(PetsClub));
				FileName = fileName;
			}
		}
		#endregion


		#region Сортировки

		// Методы сортировки
		public List<Animal> CopyOrderedByAge() => PetsClub.OrderCopyBy(
			(a1, a2) => a1.Age.CompareTo(a2.Age));

		public List<Animal> CopyOrderedBySpecies() => PetsClub.OrderCopyBy(
			(a1, a2) => a1.Species.CompareTo(a2.Species));

		public List<Animal> CopyOrderedByOwnersAnimals() => PetsClub.OrderCopyBy(
			(a1, a2) => a1.Owner.CompareTo(a2.Owner));
		


		// Статические методы сортировки
		public static void OrderByAge(List<Animal> list) =>
			Models.PetsClub.OrderBy(list, (a1, a2) =>
			a1.Age.CompareTo(a2.Age));

		public static void OrderBySpecies(List<Animal> list) =>
			Models.PetsClub.OrderBy(list, (a1, a2) =>
				a1.Species.CompareTo(a2.Species));

		public static void OrderByOwners(List<Animal> list) =>
			Models.PetsClub.OrderBy(list, (a1, a2) =>
				a1.Owner.CompareTo(a2.Owner));

		#endregion


		#region Выборка

		// Запрос на выборку из коллекции животных с максимальным весом (с точностью до 100г)
		public List<Animal> SelectWhereMaxWeight() =>
			_petsClub.Filter(a => PetsClub.MaxWeight() - a.Weight < 0.1);

		// Запрос на выборку из коллекции животных с фамилией владельца,
		// которая содержит заданную подстроку 
		public List<Animal> SelectWhereOwnerSurnameContains(string substring) =>
			_petsClub.Filter(app => app.Owner.ToUpper().Contains(substring.ToUpper()));

		#endregion

	}
}
