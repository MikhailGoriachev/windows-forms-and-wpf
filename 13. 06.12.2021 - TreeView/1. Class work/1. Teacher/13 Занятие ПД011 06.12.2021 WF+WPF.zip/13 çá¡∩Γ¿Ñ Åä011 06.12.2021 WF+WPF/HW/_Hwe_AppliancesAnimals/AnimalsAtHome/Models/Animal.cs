﻿using System;
using System.Windows.Forms;
using AnimalsAtPetShop.Helpers;

namespace AnimalsAtPetShop.Models
{
    /*
     * Класс для представления данных животного:
     *     • индекс иконки животного в коллекции ImageList
     *     • вид животного (кот, лев, слон, рыба, …)
     *     • кличка животного 
     *     • вес животного (в кг) 
     *     • возраст животного (в годах) 
     *     • цвет (масть) животного, 
     *     • фамилия и инициалы владельца (Иванов И.И., …).
     */
    public class Animal
    {
        // индекс иконки животного в коллекции ImageList
        private int _imageIndex;

        public int ImageIndex {
            get => _imageIndex;
            set { _imageIndex = value; }
        } // ImageIndex

        // вид животного (кот, лев, слон, рыба, …)
        private string _animalType;

        public string AnimalType {
            get => _animalType;
            set { _animalType = value; }
        } // AnimalType


        // кличка животного 
        private string _name;

        public string Name {
            get => _name;
            set { _name = value; }
        } // Name


        // вес животного (в кг)
        private double _weight;

        public double Weight {
            get => _weight;
            set { _weight = value; }
        } // Weight


        // возраст животного (в годах)
        private int _age;

        public int Age {
            get => _age;
            set { _age = value; }
        } // Age


        // цвет (масть) животного 
        private string _color;

        public string Color {
            get => _color;
            set { _color = value; }
        } // Color


        // фамилия и инициалы владельца 
        private string _ownerOwnerFullName;

        public string OwnerFullName {
            get => _ownerOwnerFullName;
            set { _ownerOwnerFullName = value; }
        } // OwnerFullName


        #region Ансамбль конструкторов
        public Animal() : this(0, Templates[0].Type, "Кара", Templates[0].Weight, 3, 
            "черный", "Иванов И.И.") { } // Animal

        public Animal(int imageIndex, string animalType, string name, double weight, int age, string color,
            string ownerFullName) {
            ImageIndex = imageIndex;
            AnimalType = animalType;
            Name = name;
            Weight = weight;
            Age = age;
            Color = color;
            OwnerFullName = ownerFullName;
        } // Animal
        #endregion


        // формирование данных животного
        public static Animal Generate(int id) {
            int indexTemplate = Utils.GetRandom(0, Templates.Length - 1);
            return new Animal {
                _imageIndex         = indexTemplate,
                _animalType         = Templates[indexTemplate].Type,
                _name               = Utils.GetAnimalName(),
                _weight             = Templates[indexTemplate].Weight,
                _age                = Utils.GetRandom(1, 12),
                _color              = Utils.GetColor(),
                _ownerOwnerFullName = Utils.GetOwnerFullName()
            };
        } // Generate

        
        // формирование строки для ListView
        public ListViewItem ToListViewItem() {
            // получить элемент для заполнения строки ListView,
            // указать в нем данные 0го столбца: если без текста и только число,
            // то это индекс картинки из ImageList, 0 - выключен, 1 - включен
            ListViewItem listViewItem = new ListViewItem("", _imageIndex);

            // добавить остальные столбцы
            listViewItem.SubItems.Add($"{_animalType}");
            listViewItem.SubItems.Add(_name);
            listViewItem.SubItems.Add(_color);
            listViewItem.SubItems.Add($"{_weight:n2}");
            listViewItem.SubItems.Add($"{_age}");
            listViewItem.SubItems.Add($"{_ownerOwnerFullName}");

            return listViewItem;
        } // ToListViewItem


        // данные для формирования животного - индекс картинки в ImageList
        // и соответствующие им названия, вес
        private static readonly (string Type, double Weight)[] Templates = new[] {
            ("Птица",           5.2),
            ("Бык",           452.1),
            ("Кот",             4.2),
            ("Корова",        290.1),
            ("Собака",         23.4),
            ("Утка",            3.2),
            ("Слон",         1230.2),
            ("Рыба",           45.1),
            ("Лошадь",        260.1),
            ("Божья коровка",   0.01),
            ("Леопард",        23.1),
            ("Лев",           160.1),
            ("Лобстер",         6.2),
            ("Кролик",          4.1),
            ("Улитка",          0.12),
            ("Черепаха",        3.1)
        };
    } // class Animal
}
