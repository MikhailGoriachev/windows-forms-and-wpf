﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using AnimalsAtPetShop.Controllers;
using AnimalsAtPetShop.Models;

namespace AnimalsAtPetShop.Views
{
    public partial class MainForm : Form
    {
        // контроллер для обработки данных по заданию
        private PetShopController _petShopController;

        public MainForm() : this(new PetShopController()) { } // MainForm
        

        public MainForm(PetShopController petShopController) {
            InitializeComponent();

            // получить данные по контроллеру 
            _petShopController = petShopController;

            // Вывести данные магазина
            LblPetShopInfo.Text = _petShopController.PetShop.Address;

            // сформировать данные в ListView: приборы, отсортированные приборы, выборка по наименованию
            FillListView(_petShopController.GetAll(), LsvAnimals);
            FillListView(_petShopController.OrderByBrand(), LsvOrdered);
            FillListView(_petShopController.SelectWhereMaxWeight(), LsvFiltered);

            // Сформировать заголовок вкладки отсортированной коллекции
            TbpSorted.Text += ": по названию";
            
            // вывести количество приборов квартире
            TslStatus.Text = $"Количество животных в коллекции: {_petShopController.Count}";
        } // MainForm


        // вывод коллекции животных в ListView в табличном формате,
        // состояние прибора отображать картинкой
        public void FillListView(List<Animal> animals, ListView listView) {
            listView.Items.Clear();

            animals.ForEach(a => listView.Items.Add(a.ToListViewItem()));
        } // FillListView


        // завершение приложения
        private void Exit_Command(object sender, EventArgs e) => Application.Exit();

        // свернуть в трей
        private void ToTray_Command(object sender, EventArgs e) {
            this.Hide();
            NtfMain.Visible = true;
        } // ToTray_Command


        // восстановить из трея
        private void FromTray_Command(object sender, EventArgs e) {
            this.Show();
            WindowState = FormWindowState.Normal;
            NtfMain.Visible = false;
        } // FromTray_Command


        // вывод формы со сведениями о приложении и разработчике
        private void About_Command(object sender, EventArgs e) {
            AboutForm aboutForm = new AboutForm();
            aboutForm.ShowDialog();
        } // About_Command


        // Обработчик события сброса данных по технике Drag'n'Drop
        private void LsvAnimals_DragDrop(object sender, DragEventArgs e) {
            if (e.Data.GetDataPresent(DataFormats.FileDrop)) {
                // Прием файла, data[] - массив имен файлов
                _petShopController.DataFileName = ((string[])e.Data.GetData(DataFormats.FileDrop))[0];
                _petShopController.DeserializeData();

                FillListView(_petShopController.GetAll(), LsvAnimals);
            } // if
        } // LsvAnimals_DragDrop

        // Подтверждение операции необходимо, оно задает операцию при
        // завершении буксировки
        private void LsvAnimals_DragEnter(object sender, DragEventArgs e)  {
            e.Effect = DragDropEffects.Copy;
        } // LsvAppliances_DragEnter
        
        
        // Для проверки!!! Это временное решение 
        private void Save_Command(object sender, EventArgs e) {
            _petShopController.DataFileName = "test.json";
            _petShopController.SerializeData();

            TslStatus.Text = "Данные сохранены.";
        }

        private void New_Command(object sender, EventArgs e) {
            // сформировать новые данные
            _petShopController.Generate();
            _petShopController.DataFileName = "pet_shop.json";
            _petShopController.SerializeData();

            // покащать новые данные
            FillListView(_petShopController.GetAll(), LsvAnimals);
            TslStatus.Text = "Данные сформированы.";
        }
    } // class MainForm
}
