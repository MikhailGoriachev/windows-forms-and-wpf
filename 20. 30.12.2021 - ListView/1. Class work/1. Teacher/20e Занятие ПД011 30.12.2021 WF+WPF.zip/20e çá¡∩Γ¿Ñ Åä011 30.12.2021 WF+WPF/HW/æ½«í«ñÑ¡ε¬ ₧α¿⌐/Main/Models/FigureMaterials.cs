﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media.Imaging;
using Ardalis.SmartEnum;
using Main.Common;


namespace Main.Models
{
	internal sealed class FigureMaterials : SmartEnum<FigureMaterials, double>
	{
		public static readonly FigureMaterials Copper = new("Медь", 920d,
			new($"{Routes.MaterialsImages}/{nameof(Copper)}.png"));

		public static readonly FigureMaterials Steel = new("Сталь", 7800d,
			new($"{Routes.MaterialsImages}/{nameof(Steel)}.png"));

		public static readonly FigureMaterials Granite = new("Гранит", 2700d,
			new($"{Routes.MaterialsImages}/{nameof(Granite)}.png"));

		public static readonly FigureMaterials WaterIce = new("Лёд", 900d,
			new($"{Routes.MaterialsImages}/{nameof(WaterIce)}.png"));


		public Uri ImagePath { get; }


		private FigureMaterials(string name, double volume, Uri imagePath) : base(name, volume)
		{
			ImagePath = imagePath;
		}


		public static IReadOnlyCollection<FigureMaterials> GetAll() => List;
	}
}