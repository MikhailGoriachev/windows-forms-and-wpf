﻿using System;


namespace Main.Models
{
	public interface IFigure
	{
		public string LocalizedName { get; }
		public Uri ImageUri { get; }
		public double Density { get; set; }

		double Area();

		double Volume();

		double Mass() => Volume() * Density;
	}
}