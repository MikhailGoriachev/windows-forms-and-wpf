﻿using System.Collections.Generic;
using System.Windows;
using Main.Models;


namespace Main.Views
{
	public sealed partial class MainWindow : Window
	{
		public ICollection<IFigure> Figures { get; } = new List<IFigure>
		{
			new Cylinder { Height = 20, Radius = 10 },
			new Cylinder { Height = 10, Radius = 20 },

			new Parallelepiped { A = 10, B = 10, C = 10 },
			new Parallelepiped { A = 20, B = 20, C = 20 },

			new Sphere { Radius = 10 },
			new Sphere { Radius = 20 },

			new TruncatedConoid { Height = 20, LowerRadius = 10, UpperRadius = 15 },
			new TruncatedConoid { Height = 20, LowerRadius = 15, UpperRadius = 10 }
		};


		public MainWindow() => InitializeComponent();
	}
}