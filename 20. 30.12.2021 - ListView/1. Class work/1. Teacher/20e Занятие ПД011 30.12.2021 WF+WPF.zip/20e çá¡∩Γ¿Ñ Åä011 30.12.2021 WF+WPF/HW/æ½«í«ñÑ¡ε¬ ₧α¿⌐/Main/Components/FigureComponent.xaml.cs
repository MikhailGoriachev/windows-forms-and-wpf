﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using System.Windows.Media.Imaging;
using Main.Models;


namespace Main.Components
{
	[ContentProperty("AdditionalContent")]
	public sealed partial class FigureComponent : UserControl
	{
		public static readonly DependencyProperty AdditionalContentProperty = DependencyProperty.Register(
			"AdditionalContent", typeof(FrameworkElement), typeof(FigureComponent), new(default(UIElement)));

		public FrameworkElement AdditionalContent
		{
			get => (FrameworkElement)GetValue(AdditionalContentProperty);
			set => SetValue(AdditionalContentProperty, value);
		}


		public static readonly DependencyProperty FigureProperty = DependencyProperty.Register(
			"Figure", typeof(IFigure), typeof(FigureComponent), new PropertyMetadata(default(IFigure)));

		public IFigure Figure
		{
			get { return (IFigure)GetValue(FigureProperty); }
			set { SetValue(FigureProperty, value); }
		}


		public FigureComponent() => InitializeComponent();


		private void MaterialComboBox_OnSelectionChanged(object sender, SelectionChangedEventArgs e)
		{
			if (Figure is not null)
				Figure.Density = ((FigureMaterials)MaterialComboBox.SelectedItem).Value;
		}


		private void FigureComponent_OnLoaded(object sender, RoutedEventArgs e)
		{
			if (Figure is not null)
				FigureImage.Source = new BitmapImage(Figure.ImageUri);
		}
	}
}