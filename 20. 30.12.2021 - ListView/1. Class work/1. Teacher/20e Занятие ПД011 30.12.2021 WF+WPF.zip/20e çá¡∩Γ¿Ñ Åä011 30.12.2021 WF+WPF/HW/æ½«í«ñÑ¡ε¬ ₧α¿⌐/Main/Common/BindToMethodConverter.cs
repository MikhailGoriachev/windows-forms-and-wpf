﻿using System;
using System.Globalization;
using System.Windows.Data;


namespace Main.Common
{
	public sealed class BindToMethodConverter : IValueConverter
	{
		public string MethodName { get; set; }


		public object Convert(object value, Type targetType, object parameter, CultureInfo culture) =>
			value?.GetType()?.GetMethod(MethodName)?.Invoke(value, parameter as object[]) ?? Binding.DoNothing;


		public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture) =>
			Binding.DoNothing;
	}
}