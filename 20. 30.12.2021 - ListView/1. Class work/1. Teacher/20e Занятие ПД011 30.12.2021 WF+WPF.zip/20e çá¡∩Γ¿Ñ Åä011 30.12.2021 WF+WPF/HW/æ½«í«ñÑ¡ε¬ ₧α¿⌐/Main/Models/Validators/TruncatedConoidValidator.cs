﻿using FluentValidation;


namespace Main.Models.Validators
{
	internal sealed class TruncatedConoidValidator : AbstractValidator<TruncatedConoid>
	{
		public TruncatedConoidValidator()
		{
			RuleFor(x => x.LowerRadius)
				.Must(FigureValidator.Positive)
				.WithMessage("Радиус нижнего основания не может быть нулевым или отрицательным");

			RuleFor(x => x.UpperRadius)
				.Must(FigureValidator.Positive)
				.WithMessage("Радиус верхнего основания не может быть нулевым или отрицательным");

			RuleFor(x => x.Height)
				.Must(FigureValidator.Positive)
				.WithMessage("Высота не может быть нулевой или отрицательной");

			FigureValidator.CheckDensity(this);
		}
	}
}