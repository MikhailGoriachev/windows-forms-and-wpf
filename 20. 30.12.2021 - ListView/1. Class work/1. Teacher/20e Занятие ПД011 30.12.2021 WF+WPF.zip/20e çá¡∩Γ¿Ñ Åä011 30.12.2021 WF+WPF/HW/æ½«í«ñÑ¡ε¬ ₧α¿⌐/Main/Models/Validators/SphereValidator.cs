﻿using FluentValidation;


namespace Main.Models.Validators
{
	internal sealed class SphereValidator : AbstractValidator<Sphere>
	{
		public SphereValidator()
		{
			RuleFor(s => s.Radius)
				.Must(FigureValidator.Positive)
				.WithMessage("Радиус не может быть нулевым или отрицательным");

			FigureValidator.CheckDensity(this);
		}
	}
}