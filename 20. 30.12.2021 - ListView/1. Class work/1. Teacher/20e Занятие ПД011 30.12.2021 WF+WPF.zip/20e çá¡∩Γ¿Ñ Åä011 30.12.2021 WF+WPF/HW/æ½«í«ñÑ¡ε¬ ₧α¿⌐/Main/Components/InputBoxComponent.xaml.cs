﻿using System.Windows;
using System.Windows.Controls;


namespace Main.Components
{
	public sealed partial class InputBoxComponent : UserControl
	{
		public static readonly DependencyProperty CaptionProperty = DependencyProperty.Register(
			"Caption", typeof(string), typeof(InputBoxComponent), new PropertyMetadata(default(string)));

		public string Caption { get { return (string)GetValue(CaptionProperty); } set { SetValue(CaptionProperty, value); } }

		public static readonly DependencyProperty IsReadOnlyProperty = DependencyProperty.Register(
			"IsReadOnly", typeof(bool), typeof(InputBoxComponent), new PropertyMetadata(default(bool)));

		public bool IsReadOnly { get { return (bool)GetValue(IsReadOnlyProperty); } set { SetValue(IsReadOnlyProperty, value); } }

		public static readonly DependencyProperty ValueProperty = DependencyProperty.Register(
			"Value", typeof(string), typeof(InputBoxComponent), new PropertyMetadata(default(string?)));

		public string Value { get { return (string)GetValue(ValueProperty); } set { SetValue(ValueProperty, value); } }


		public InputBoxComponent() =>
			InitializeComponent();
	}
}