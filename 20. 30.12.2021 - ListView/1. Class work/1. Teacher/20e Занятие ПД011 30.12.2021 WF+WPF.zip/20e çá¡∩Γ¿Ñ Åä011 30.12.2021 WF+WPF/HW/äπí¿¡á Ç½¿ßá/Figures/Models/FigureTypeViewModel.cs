﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Figures.Models
{
    // данные по типу фигуры
    class FigureTypeViewModel {
        // название типа фигуры
        public string Name { get; set; }

        // имя файла изображения фигуры
        public string ImageFile { get; set; }
    } // FigureTypeViewModel
}
