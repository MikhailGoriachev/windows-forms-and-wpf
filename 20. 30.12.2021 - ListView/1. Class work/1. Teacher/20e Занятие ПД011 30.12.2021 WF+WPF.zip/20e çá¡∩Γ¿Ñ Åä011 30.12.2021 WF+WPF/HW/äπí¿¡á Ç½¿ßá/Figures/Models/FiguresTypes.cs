﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Figures.Models
{
    class FiguresTypes {

        // справочник типов фигур 
        public static Dictionary<string, FigureTypeViewModel> Data = new Dictionary<string, FigureTypeViewModel>()
        {
            ["conoid"]         = new FigureTypeViewModel {Name = "усеченный конус", ImageFile = "conoid.png" }, 
            ["cylinder"]       = new FigureTypeViewModel {Name = "сфера",           ImageFile = "cylinder.png" }, 
            ["parallelepiped"] = new FigureTypeViewModel {Name = "цилиндр",         ImageFile = "parallelepiped.png" }, 
            ["sphere"]         = new FigureTypeViewModel {Name = "параллелепипед",  ImageFile = "sphere.png" }, 
        };
    } // FiguresTypes
}
