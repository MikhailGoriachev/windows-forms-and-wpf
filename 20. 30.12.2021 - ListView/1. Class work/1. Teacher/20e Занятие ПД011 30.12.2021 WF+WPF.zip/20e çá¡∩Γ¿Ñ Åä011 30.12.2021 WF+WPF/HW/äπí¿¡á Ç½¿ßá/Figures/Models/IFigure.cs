﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Figures.Models
{
    public interface IFigure {
        // Наименование типа фигуры
        string Type { get; } // Type

        // площадь поверхности
        double Area { get; } // Area

        // объем 
        double Volume { get; } // Volume

        // масса 
        double Mass { get; } // Mass
    }
}
