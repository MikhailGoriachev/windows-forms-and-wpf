﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Figures.Models;

namespace Figures.Views
{
    /// <summary>
    /// Логика взаимодействия для FigureWindow.xaml
    /// </summary>
    public partial class FigureWindow : Window
    {
        // Модель
        private IFigure _figure;

        // представление для пустой строки результата
        private const string EmptyResult = "---''---";

        // ссылка на поле ввода плотности
        private TextBox _txbDensity;

        public FigureWindow() : this(new Conoid(), "") { }
        public FigureWindow(string type) : this(new Conoid(), type) { }

        public FigureWindow(IFigure figure, string type) {
            InitializeComponent();
            _figure = figure;

            _txbDensity = TxbFourth;
            // Записать значения в элементы интерфейса, поля ввода
            TxbFirst.Text = $"{1:n3}";
            TxbSecond.Text = $"{1:n3}";
            TxbThird.Text = $"{1:n3}";
            TxbFourth.Text = $"{Materials.Data["steel"].Density:n3}";

            RbtCopper.Tag   = "copper";
            RbtGranite.Tag  = "granite";
            RbtSteel.Tag    = "steel";
            RbtWaterIce.Tag = "water_ice";
            RbtSteel.IsChecked = true;

            RbtConoid.Tag = "conoid";
            RbtCylinder.Tag = "cylinder";
            RbtSphere.Tag = "sphere";
            RbtParallelepiped.Tag = "parallelepiped";

            TxbFirst.TextChanged += TextBox_TextChanged;
            TxbFourth.TextChanged += TextBox_TextChanged;
            TxbSecond.TextChanged += TextBox_TextChanged;
            TxbThird.TextChanged += TextBox_TextChanged;

            switch (type) {
                case "Усеченный конус":
                    RbtConoid.IsChecked = true;
                    break;

                case "Сфера":
                    RbtSphere.IsChecked = true;
                    break;

                case "Цилиндр":
                    RbtCylinder.IsChecked = true;
                    break;

                case "Параллелепипед":
                    RbtParallelepiped.IsChecked = true;
                    break;
            } // switch type
        } // ParallelepipedWindow


        #region Изменение цвета надписи на кнопке при перемещении курсора мыши на кнопку
        private void Button_MouseEnter(object sender, MouseEventArgs e) {
            Button btn = e.OriginalSource as Button;
            btn.Foreground = new SolidColorBrush(Color.FromArgb(255, 0, 0, 0));
        } // Button_MouseEnter

        private void Button_MouseLeave(object sender, MouseEventArgs e) {
            Button btn = e.OriginalSource as Button;
            btn.Foreground = new SolidColorBrush(Colors.White);
        } // Button_MouseLeave
        #endregion

        // закрытие окна
        private void Close_Click(object sender, RoutedEventArgs e) => Close();

        // вычисление параметров по заданию
        private void Calculate_Click(object sender, RoutedEventArgs e) {
            try {

                // Получить данные от элементов управления
                if (RbtConoid.IsChecked == true) {
                    _figure = new Conoid
                    {
                        RadiusUp = double.Parse(TxbFirst.Text),
                        RadiusDown = double.Parse(TxbSecond.Text),
                        Height = double.Parse(TxbThird.Text),
                        Density = double.Parse(TxbFourth.Text)
                    };
                }
                else if (RbtCylinder.IsChecked == true) {
                    _figure = new Cylinder {
                        Radius = double.Parse(TxbFirst.Text),
                        Height = double.Parse(TxbSecond.Text),
                        Density = double.Parse(TxbThird.Text)
                    };
                }
                else if (RbtSphere.IsChecked == true)
                {
                    _figure = new Sphere {
                        Radius = double.Parse(TxbFirst.Text),
                        Density = double.Parse(TxbSecond.Text)
                    };
                } 
                else {
                    _figure = new Parallelepiped {
                        A = double.Parse(TxbFirst.Text),
                        B = double.Parse(TxbSecond.Text),
                        C = double.Parse(TxbThird.Text),
                        Density = double.Parse(TxbFourth.Text)
                    };
                } // if


                // Вычислить параметры тела в зависимости от установленных чек-боксов
                TblArea.Text = CbxArea.IsChecked == true
                    ? $"{_figure.Area:n3}"
                    : "Расчет не задан";

                TblVolume.Text = CbxVolume.IsChecked == true
                    ? $"{_figure.Volume:n3}"
                    : "Расчет не задан";

                TblMass.Text = CbxMass.IsChecked == true
                    ? $"{_figure.Mass:n3}"
                    : "Расчет не задан";
            }
            catch (Exception ex) {
                MessageBox.Show(ex.Message, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            } // try-catch
        } // Calculate_Click

        // обработчик кликов по радиокнопкам выбора материала, из которого создано тело
        private void RadioButton_Checked(object sender, RoutedEventArgs e) {
            RadioButton rbt = e.OriginalSource as RadioButton;
            MaterialViewModel viewModel = Materials.Data[(string)rbt.Tag];

            // _figure.Density = viewModel.Density;

            _txbDensity.Text = $"{viewModel.Density:n3}";
            ImgMaterial.Source = new BitmapImage(new Uri($"../Images/Materials/{viewModel.ImageFile}", UriKind.Relative));
            // очищаем поле вывода результата
            TblArea.Text = TblMass.Text = TblVolume.Text = EmptyResult;
        } // RadioButton_Checked

        // обработчик кликов по радиокнопкам выбора материала, из которого создано тело
        private void RbtFigure_Checked(object sender, RoutedEventArgs e) {
            RadioButton rbt = e.OriginalSource as RadioButton;
            string figure = (string)rbt.Tag;
            FigureTypeViewModel viewModel = FiguresTypes.Data[figure];

            ImgFigure.Source = new BitmapImage(new Uri($"../Images/Bodies/{viewModel.ImageFile}", UriKind.Relative));
            // запомнить значение плотности
            double temp = double.Parse(_txbDensity.Text);
            _txbDensity.Text = $"{1:n3}";
            _txbDensity.IsReadOnly = false;
            _txbDensity.Background = new SolidColorBrush(Colors.White);
            // изменить поля ввода
            switch (figure) {
                case "conoid":
                    LblThird.Visibility = LblFourth.Visibility =
                    TxbThird.Visibility = TxbFourth.Visibility = Visibility.Visible;

                    LblFirst.Text  = "Верхний радиус, м:";
                    LblSecond.Text = "Нижний радиус, м:";
                    LblThird.Text  = "Высота, м:";
                    LblFourth.Text = "Плотность, кг/м3:";
                    _txbDensity = TxbFourth;
                    break;

                case "cylinder":
                    LblThird.Visibility = TxbThird.Visibility = Visibility.Visible;
                    LblFourth.Visibility = TxbFourth.Visibility = Visibility.Hidden;

                    LblFirst.Text = "Радиус, м:";
                    LblSecond.Text = "Высота, м:";
                    LblThird.Text = "Плотность, кг/м3:";
                    _txbDensity = TxbThird;
                    break;

                case "sphere":
                    LblThird.Visibility = LblFourth.Visibility =
                    TxbThird.Visibility = TxbFourth.Visibility = Visibility.Hidden;

                    LblFirst.Text = "Радиус, м:";
                    LblSecond.Text = "Плотность, кг/м3:";
                    _txbDensity = TxbSecond;
                    break;

                case "parallelepiped":
                    LblThird.Visibility = LblFourth.Visibility =
                    TxbThird.Visibility = TxbFourth.Visibility = Visibility.Visible;

                    LblFirst.Text  = "Сторона A, м:";
                    LblSecond.Text = "Сторона B, м:";
                    LblThird.Text  = "Сторона C, м:";
                    LblFourth.Text = "Плотность, кг/м3:";
                    _txbDensity = TxbFourth;
                    break;
            } // switch figure

            _txbDensity.Text = $"{temp:n3}";
            _txbDensity.IsReadOnly = true;
            _txbDensity.Background = new SolidColorBrush(Colors.LightGray);
            // очищаем поле вывода результата
            TblArea.Text = TblMass.Text = TblVolume.Text = EmptyResult;
        } // RbtFigure_Checked

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e) {
            // очищаем поле вывода результата
            TblArea.Text = TblMass.Text = TblVolume.Text = EmptyResult;
        } // TextBox_TextChanged

    }
}
