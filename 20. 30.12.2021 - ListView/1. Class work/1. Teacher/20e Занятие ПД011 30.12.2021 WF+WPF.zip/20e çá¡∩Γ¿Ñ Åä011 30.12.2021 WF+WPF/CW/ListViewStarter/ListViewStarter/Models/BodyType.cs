﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ListViewStarter.Models
{
    // перечисление: типы тел
    public enum BodyType: byte
    {
        None, Conoid, Cylinder, Parallelepiped, Sphere
    }
}
