﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GenericCollections.Helpers;

namespace GenericCollections.App
{
    // Решение трех простых задач на обобщенные коллекции
    internal class Application
    {
        // диапазон генерации случайных чисел
        private int _lo;  // нижняя граница
        private int _hi;  // верхняя граница

        #region Конструкторы класса
        public Application():this(-10, 10) { }

        public Application(int lo, int hi) {
            if (lo > hi)
                throw new ArgumentException("Параметры не образуют корректный интервал");

            _lo = lo;
            _hi = hi;
        } // Application        
        #endregion


        // Dynamic10. Обработка стеков int
        // Dynamic10. Дан непустой стек. Создать два новых стека, переместив
        // в первый из них все элементы исходного стека с четными значениями,
        // а во второй — с нечетными (элементы в новых стеках будут
        // располагаться в порядке, обратном исходному; один из этих стеков
        // может оказаться пустым). 
        public void SolveDynamic10() {
            Utils.ShowNavBarTask("  Задача Dynamic10. Обработка стеков, закрытых типом int, Stack<int>");

            // создание стеков для обработки
            Stack<int> stack1 = GenerateStack(Utils.GetRandom(12, 22));
            Stack<int> stackEven = new Stack<int>();  // стек четных чисел
            Stack<int> stackOdd = new Stack<int>();   // стек нечетных чисел

            int m = 12;  // количестов элементов в строке 
            Action<int, int> outStackItem = (d, i) => {
                if ((d & 1) == 0) {
                    (Console.BackgroundColor, Console.ForegroundColor) =
                        (ConsoleColor.Gray, ConsoleColor.Black);
                } // if

                Console.Write($"{d, 5}  ");
                (Console.BackgroundColor, Console.ForegroundColor) =
                    (ConsoleColor.DarkGray, ConsoleColor.Gray);
                Console.Write(" ");

                // после вывода каждых m элементов перевод строки, смещение для вывода
                // первого элемента новой строки под первым элементом предыдущей строки
                if (i % m == 0)
                    Console.Write("\n\t\t       ");
            }; 

            // выводим исходное состояние стеков
            Console.WriteLine("\n\n\n\n\tСостояние стеков для обработки:\n");
            Show("\tИсходный стек: ", stack1, outStackItem);
            Show("\tСтек четных  : ", stackEven, outStackItem);
            Show("\tСтек нечетных: ", stackOdd, outStackItem);

            // перемещение элементов из исходного стека в стек четных и стек
            // нечетных чисел соответственно
            while (stack1.Count > 0) {
                int item = stack1.Pop();
                Stack<int> dest = ((item & 1) == 0) ? stackEven : stackOdd;
                dest.Push(item);

                // С-style :)
                // (((stack1.Peek() & 1) == 0) ? stackEven : stackOdd).Push(stack1.Pop());
            } // while

            // выводим состояние стеков после перемещения
            Console.WriteLine("\n\n\n\n\tСостояние стеков после перемещения четных и нечетных по разным стекам:\n");
            Show("\tИсходный стек: ", stack1, outStackItem);
            Show("\tСтек четных  : ", stackEven, outStackItem);
            Show("\tСтек нечетных: ", stackOdd, outStackItem);
        } // SolveDynamic10


        // Dynamic24. Обработка очередей int
        // Dynamic24. Даны две непустые очереди, очереди содержат одинаковое
        // количество элементов. Объединить очереди в одну, в которой элементы
        // исходных очередей чередуются (начиная с первого элемента первой
        // очереди)
        public void SolveDynamic24() {
            Utils.ShowNavBarTask("  Задача Dynamic24. Обработка очередей, закрытых типом int, Queue<int>");

            // создание очередей для обработки
            int n = Utils.GetRandom(12, 23);
            Queue<int> queue1 = new Queue<int>(GenerateArray(n));
            Queue<int> queue2 = new Queue<int>(GenerateArray(n));
            Queue<int> queue3 = new Queue<int>();   // итоговая очередь

            int m = 12;  // количестов элементов в строке 
            Action<int, int> outQueueItem = (d, i) => {
                Console.Write($"{d, 6}");

                // после вывода каждых m элементов перевод строки, смещение для вывода
                // первого элемента новой строки под первым элементом предыдущей строки
                if (i % m == 0)
                    Console.Write("\n\t\t\t      ");
            };

            // выводим исходное состояние очередей
            Console.WriteLine("\n\n\n\n\tСостояние очередей для обработки\n");
            Show("\tИсходная очередь 1  : ", queue1, outQueueItem);
            Show("\tИсходная очередь 2  : ", queue2, outQueueItem);
            Show("\tОбъединенная очередь: ", queue3, outQueueItem);

            // слияние двух очередей - чередование элементов, начиная 
            // с первого элемента первой очереди
            while (queue1.Count > 0) {
                queue3.Enqueue(queue1.Dequeue());
                queue3.Enqueue(queue2.Dequeue());
            } // while

            // выводим состояние очередей после слияния
            Console.WriteLine("\n\n\n\n\tСостояние очередей после объединенеия без нарушения упорядоченности:\n");
            Show("\tИсходная очередь 1  : ", queue1, outQueueItem);
            Show("\tИсходная очередь 2  : ", queue2, outQueueItem);
            Show("\tОбъединенная очередь: ", queue3, outQueueItem);
        } // SolveDynamic24


        // Dynamic37. Обработка списков int
        // Dynamic37. Дан непустой список. Продублировать в списке все элементы
        // с нечетными номерами (новые элементы добавлять перед существующими
        // элементами с такими же значениями)
        public void SolveDynamic37() {
            Utils.ShowNavBarTask("  Задача Dynamic37. Обработка списков, закрытых типом int, List<int>");
            List<int> list = new List<int>(GenerateArray(Utils.GetRandom(12, 23)));

            int m = 12;  // количестов элементов в строке 
            Action<int, int> outListItem1 = (d, i) => {
                if ((i & 1) != 0) {
                    (Console.BackgroundColor, Console.ForegroundColor) =
                        (ConsoleColor.Gray, ConsoleColor.Black);
                } // if

                Console.Write($"{d, 5}  ");
                (Console.BackgroundColor, Console.ForegroundColor) =
                    (ConsoleColor.DarkGray, ConsoleColor.Gray);
                Console.Write(" ");

                // после вывода каждых m элементов перевод строки, смещение для вывода
                // первого элемента новой строки под первым элементом предыдущей строки
                if (i % m == 0)
                    Console.Write("\n\t\t\t\t");
            };

            // вывод с выделением цвеом продублированных элементов
            Action<int, int> outListItem2 = (d, i) => {
                // выделение цветом двух дубликатов - их номера не кратны 3
                if (i % 3 != 0) {
                    (Console.BackgroundColor, Console.ForegroundColor) =
                        (ConsoleColor.Gray, ConsoleColor.Black);
                } // if

                Console.Write($"{d,5}  ");
                (Console.BackgroundColor, Console.ForegroundColor) =
                    (ConsoleColor.DarkGray, ConsoleColor.Gray);
                Console.Write(" ");

                // после вывода каждых m элементов перевод строки, смещение для вывода
                // первого элемента новой строки под первым элементом предыдущей строки
                if (i % m == 0)
                    Console.Write("\n\t\t\t\t");
            };

            // выводим исходное состояние списка
            Show("\n\n\n\n\tСписок для обработки   :", list, outListItem1);

            // Продублировать в списке все элементы с нечетными номерами (новые
            // элементы добавлять перед существующими элементами с такими же
            // значениями) 
            // Нечетные номера == четные индексы
            // Если в списке четное количество элементов, (например 8) то
            // начинаем с номера 7, т.е. индекс 6, т.е. list.Count-2
            // при нечетном количестве элементов (например 9)
            // начинаем с последнего элемента списка, т.е. индекс 8,
            // т.е. list.Count - 1 
            int start = (list.Count & 1) == 0 
                ? list.Count - 2    // для списков с четным количеством
                : list.Count - 1;   // для списков с нечетным количеством
            for (int j = start; j >= 0; j-=2) {
                list.Insert(j, list[j]);
            } // for j

            // выводим список с продублированными значениями элементов
            // с нечетными номерами 
            Show("\n\n\n\n\tПродублировны НЧ номера:", list, outListItem2);
        } // SolveDynamic37


        // формирование массива данных из случайных целых чисел
        // диапазон генерации - поля класса Application
        private int[] GenerateArray(int n) {
            int[] data = new int[n];
            for (int i = 0; i < n; i++) {
                data[i] = Utils.GetRandom(_lo, _hi);
            } // for i

            return data;
        } // GenerateArray

        // формирование стека, заполненного случайными числами
        private Stack<int> GenerateStack(int n) => 
            new Stack<int>(GenerateArray(n));

        // формирование упорядоченной очереди из случайных целых чисел
        private Queue<int> GenerateOrderedQueue(int n) {
            
            // создать упорядоченный массив данных 
            int[] data = GenerateArray(n);
            Array.Sort(data);

            // сформировать очередь из упорядоченного массива
            return new Queue<int>(data);
        } // GenerateOrderedQueue


        /// <summary>
        /// Вывод коллекции в консоль 
        /// </summary>
        /// <param name="title"></param>Выводимый заголовок коллекции
        /// <param name="collection"></param>Коллекция
        /// <param name="outItem"></param>делегат вывода элемента коллекции?
        /// получает собственно элемент для вывода и его номер
        private void Show(string title, IEnumerable<int> collection, 
            Action<int, int> outItem) {
            Console.Write(title);

            // номер выводимого элемента коллекции
            int i = 1;

            // выводим все элементы коллекции
            foreach (var item in collection) {
                outItem(item, i++);
            } // foreach

            // перевод строки после вывода всех элементов коллекции
            Console.WriteLine();
        } // Show
    } // class Application
}
