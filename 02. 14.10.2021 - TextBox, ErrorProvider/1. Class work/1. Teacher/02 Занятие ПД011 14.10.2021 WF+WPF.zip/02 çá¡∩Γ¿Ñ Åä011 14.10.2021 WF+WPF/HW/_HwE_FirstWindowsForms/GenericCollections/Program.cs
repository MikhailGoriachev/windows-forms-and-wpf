﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Microsoft.VisualBasic;   // для класса Interaction

// пространства имен проекта
using GenericCollections.App;
using GenericCollections.Helpers;

/*
 * Задача 1.
 * Разработайте, пожалуйста, консольное приложение C# для решения следующих
 * задач, с использованием типизированных коллекций, закрытых типом int. 
 *     • Dynamic10. Дан непустой стек. Создать два новых стека, переместив
 *       в первый из них все элементы исходного стека с четными значениями,
 *       а во второй — с нечетными (элементы в новых стеках будут
 *       располагаться в порядке, обратном исходному; один из этих стеков
 *       может оказаться пустым). 
 *     • Dynamic24. Даны две непустые очереди, очереди содержат одинаковое
 *       количество элементов. Объединить очереди в одну, в которой элементы
 *       исходных очередей чередуются (начиная с первого элемента первой
 *       очереди)
 *     • Dynamic37. Дан непустой список. Продублировать в списке все элементы
 *       с нечетными номерами (новые элементы добавлять перед существующими
 *       элементами с такими же значениями)
 *
 */
namespace GenericCollections
{
    internal class Program
    {
        static void Main(string[] args) {
            Console.Title = "Задание на 14.10.2021 - введение в обработку обобщенных коллекций в C#";

            // простейшее меню приложения
            MenuItem[] menu = new[] {
                new MenuItem {HotKey = ConsoleKey.Q, Text = "Dynamic10. Обработка стеков int"},
                new MenuItem {HotKey = ConsoleKey.W, Text = "Dynamic24. Обработка очередей int"},
                new MenuItem {HotKey = ConsoleKey.E, Text = "Dynamic37. Обработка списков int"},
                //----------------------------------------------------------------------------------------------
                new MenuItem {HotKey = ConsoleKey.Z, Text = "Выход"},
            };

            // Создание экземпляра класса приложения
            Application app = new Application();

            // главный цикл приложения
            while (true) {
                try {
                    // настройка цветового оформления
                    (Console.ForegroundColor, Console.BackgroundColor) = (ConsoleColor.Gray, ConsoleColor.DarkGray);
                    Console.Clear();
                    Console.CursorVisible = false;

                    Utils.ShowNavBarTask("  ООП C# - введение в обобощенные коллекции");
                    Utils.ShowMenu(12, 5, "Меню приложения для демонстрации работы с обобщенными коллекциями в C#", menu);

                    // получить код нажатой клавиши, не отображать символ клавиши
                    Console.BackgroundColor = ConsoleColor.Gray;
                    string msg =
                        "  Нажмите выделенную цветом клавишу для выбора пункта меню".PadRight(Console.WindowWidth - 1);
                    Utils.WriteXY(0, Console.WindowHeight - 1, msg, ConsoleColor.Black);

                    ConsoleKey key = Console.ReadKey(true).Key;
                    (Console.ForegroundColor, Console.BackgroundColor) = (ConsoleColor.Gray, ConsoleColor.DarkGray);
                    Console.Clear();

                    switch (key) {

                        // Dynamic10. Обработка стеков int
                        case ConsoleKey.Q:
                            app.SolveDynamic10();
                            break;

                        // Dynamic24. Обработка очередей int
                        case ConsoleKey.W:
                            app.SolveDynamic24();
                            break;

                        // Dynamic37. Обработка списков int
                        case ConsoleKey.E:
                            app.SolveDynamic37();
                            break;

                        // Выход из приложения назначен на клавишу F10 или клавишу M или клавишу Escape
                        case ConsoleKey.F10:
                        case ConsoleKey.Escape:
                        case ConsoleKey.Z:
                            Console.ResetColor(); // сброс цветового сочетания к исходному
                            Console.Clear();
                            Utils.WriteXY(0, Console.WindowHeight - 1, "Нажмите любую клавишу...", ConsoleColor.Gray);
                            Console.CursorVisible = true;
                            return;

                        default:
                            throw new Exception("Нет такой команды меню");
                    } // switch

                    // Ожидать нажатия любой клавиши по окончании работы пункта меню
                    Console.CursorVisible = true;
                    Console.BackgroundColor = ConsoleColor.Gray;
                    msg = "  Нажмите любую клавишу...".PadRight(Console.WindowWidth - 1);
                    Utils.WriteXY(0, Console.WindowHeight - 1, msg, ConsoleColor.Black);
                    Console.ReadKey(true);
                } // try

                // обработка исключений - просто вывести сообщение
                catch (Exception ex) {
                    Interaction.MsgBox(ex.Message, MsgBoxStyle.Critical | MsgBoxStyle.OkOnly, "Ошибка");
                } // try-catch
            } // while
        } // Main
    } // class Program
}
