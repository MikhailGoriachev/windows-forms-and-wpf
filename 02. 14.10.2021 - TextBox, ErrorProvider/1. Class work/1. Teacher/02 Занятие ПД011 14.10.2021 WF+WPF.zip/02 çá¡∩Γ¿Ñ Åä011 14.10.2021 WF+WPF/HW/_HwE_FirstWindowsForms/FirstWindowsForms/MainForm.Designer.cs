﻿namespace FirstWindowsForms
{
    partial class MainForm
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.LblOutput = new System.Windows.Forms.Label();
            this.GrbOutput = new System.Windows.Forms.GroupBox();
            this.BtnAsciiDraw = new System.Windows.Forms.Button();
            this.BtnGreeting = new System.Windows.Forms.Button();
            this.BtnQuit = new System.Windows.Forms.Button();
            this.TmrMain = new System.Windows.Forms.Timer(this.components);
            this.GrbOutput.SuspendLayout();
            this.SuspendLayout();
            // 
            // LblOutput
            // 
            this.LblOutput.BackColor = System.Drawing.Color.MintCream;
            this.LblOutput.Dock = System.Windows.Forms.DockStyle.Fill;
            this.LblOutput.Font = new System.Drawing.Font("Cascadia Code", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblOutput.Location = new System.Drawing.Point(3, 22);
            this.LblOutput.Name = "LblOutput";
            this.LblOutput.Size = new System.Drawing.Size(746, 355);
            this.LblOutput.TabIndex = 0;
            this.LblOutput.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // GrbOutput
            // 
            this.GrbOutput.Controls.Add(this.LblOutput);
            this.GrbOutput.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.GrbOutput.Location = new System.Drawing.Point(24, 12);
            this.GrbOutput.Name = "GrbOutput";
            this.GrbOutput.Size = new System.Drawing.Size(752, 380);
            this.GrbOutput.TabIndex = 1;
            this.GrbOutput.TabStop = false;
            this.GrbOutput.Text = " Область вывода ";
            // 
            // BtnAsciiDraw
            // 
            this.BtnAsciiDraw.BackColor = System.Drawing.Color.PaleGreen;
            this.BtnAsciiDraw.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BtnAsciiDraw.Location = new System.Drawing.Point(24, 408);
            this.BtnAsciiDraw.Name = "BtnAsciiDraw";
            this.BtnAsciiDraw.Size = new System.Drawing.Size(208, 42);
            this.BtnAsciiDraw.TabIndex = 2;
            this.BtnAsciiDraw.Text = "Рисунок";
            this.BtnAsciiDraw.UseVisualStyleBackColor = false;
            this.BtnAsciiDraw.Click += new System.EventHandler(this.BtnAsciiDraw_Click);
            // 
            // BtnGreeting
            // 
            this.BtnGreeting.BackColor = System.Drawing.Color.PaleGreen;
            this.BtnGreeting.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BtnGreeting.Location = new System.Drawing.Point(248, 408);
            this.BtnGreeting.Name = "BtnGreeting";
            this.BtnGreeting.Size = new System.Drawing.Size(208, 42);
            this.BtnGreeting.TabIndex = 3;
            this.BtnGreeting.Text = "Приветствие";
            this.BtnGreeting.UseVisualStyleBackColor = false;
            this.BtnGreeting.Click += new System.EventHandler(this.BtnGreeting_Click);
            // 
            // BtnQuit
            // 
            this.BtnQuit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.BtnQuit.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BtnQuit.Location = new System.Drawing.Point(568, 408);
            this.BtnQuit.Name = "BtnQuit";
            this.BtnQuit.Size = new System.Drawing.Size(208, 42);
            this.BtnQuit.TabIndex = 4;
            this.BtnQuit.Text = "Выход";
            this.BtnQuit.UseVisualStyleBackColor = false;
            this.BtnQuit.Click += new System.EventHandler(this.BtnQuit_Click);
            // 
            // TmrMain
            // 
            this.TmrMain.Interval = 5000;
            this.TmrMain.Tick += new System.EventHandler(this.TmrMain_Tick);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 459);
            this.Controls.Add(this.BtnQuit);
            this.Controls.Add(this.BtnGreeting);
            this.Controls.Add(this.BtnAsciiDraw);
            this.Controls.Add(this.GrbOutput);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Задание на на 14.10.2021";
            this.GrbOutput.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label LblOutput;
        private System.Windows.Forms.GroupBox GrbOutput;
        private System.Windows.Forms.Button BtnAsciiDraw;
        private System.Windows.Forms.Button BtnGreeting;
        private System.Windows.Forms.Button BtnQuit;
        private System.Windows.Forms.Timer TmrMain;
    }
}

