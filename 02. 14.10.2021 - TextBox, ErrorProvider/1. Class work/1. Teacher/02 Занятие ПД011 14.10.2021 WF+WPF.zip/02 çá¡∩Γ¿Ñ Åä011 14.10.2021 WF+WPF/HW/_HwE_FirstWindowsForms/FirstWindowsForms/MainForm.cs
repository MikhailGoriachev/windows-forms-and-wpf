﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/*
 * Задача 2.
 * Разработайте приложение Windows Forms, разместите на форме элементы Label,
 * Button, Timer для выполнения обработок:
 *     • По кнопке «Рисунок» выводите в Label с моноширинным шрифтом ASCII-art,
 *       приведенный в файле ascii.txt. Рисунок стирается при помощи таймера
 *       через 5 секунд
 *     • По кнопке «Приветствие» выводите сообщение «Привет, Windows Forms»,
 *       сообщение стирается при помощи таймера через 5 секунд
 *     • По кнопке «Выход» работа приложения завершается
 */

namespace FirstWindowsForms
{
    public partial class MainForm : Form
    {
        public MainForm() {
            InitializeComponent();
        } // MainForm

        // По клику на кнопку "Выход" завершать работу приложения
        private void BtnQuit_Click(object sender, EventArgs e) => Application.Exit();

        // По кнопке «Рисунок» выводите в  Label с моноширинным шрифтом ASCII-art,
        // приведенный в файле ascii.txt. Рисунок стирается при помощи таймера
        // через 5 секунд
        private void BtnAsciiDraw_Click(object sender, EventArgs e) {
            LblOutput.Text = 
                 @"                            ,%%%," + "\n" +
                 @"                          ,%%%` %==--" + "\n" +
                 @"                         ,%%`( '|" + "\n" +
                 @"                        ,%%@ /\_/" + "\n" +
                 @"              ,%.-""""""-- %%% ""@@__" + "\n" +
                 @"             %%/             | __`\" + "\n" +
                 @"            .% '\     |   \   /  //" + "\n" +
                 @"            ,% ' >   .'----\ |  [/" + "\n" +
                 @"                < <<`       ||" + "\n" +
                 @"                 `\\\       ||" + "\n" +
                 @"                   )\\      )\" + "\n" +
                 @"^^^^^^^^^^^^^^^^^^^""""""^^^^^^""""^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^";
            
            // Выравнивание рисунка влево по горизонтали и по центру по вертикали
            LblOutput.TextAlign = ContentAlignment.MiddleLeft;

            // пуск таймера для очистки рисунка через 5 с (задано в свойствах таймера)
            TmrMain.Enabled = true;

            // запрещаем клик по кнопкам
            BtnAsciiDraw.Enabled = BtnGreeting.Enabled = false;
        } // BtnAsciiDraw_Click


        // По кнопке «Приветствие» выводите сообщение «Привет, Windows Forms»,
        // сообщение стирается при помощи таймера через 5 секунд
        private void BtnGreeting_Click(object sender, EventArgs e) {
            LblOutput.Text = "Привет, Windows Forms";

            // Выравнивание приветствия по центру и по горизонтали и по вертикали
            LblOutput.TextAlign = ContentAlignment.MiddleCenter;

            // пуск таймера для очистки приветствия через 5 с (задано в свойствах таймера)
            TmrMain.Enabled = true;

            // запрещаем клик по кнопкам
            BtnGreeting.Enabled = BtnAsciiDraw.Enabled = false;
        } // BtnGreeting_Click


        // Обработчик события таймера - таймер досчитал интервал 5 с
        // стираем все, что было выведено в Label, останавливаем счет таймера
        // и разрешаем клики по кнопкам
        private void TmrMain_Tick(object sender, EventArgs e) {
            LblOutput.Text = "";
            TmrMain.Enabled = false;
            BtnAsciiDraw.Enabled = BtnGreeting.Enabled = true;
        } // TmrMain_Tick
    } // class MainForm
}
