﻿
namespace H_W1WF
{
    partial class MainForm
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.BtnPickcher = new System.Windows.Forms.Button();
            this.BtnHello = new System.Windows.Forms.Button();
            this.BtnEx = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.LblBtnHello = new System.Windows.Forms.Label();
            this.TmrFirst = new System.Windows.Forms.Timer(this.components);
            this.LblBtnPickcher = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Lucida Console", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(124, 32);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(408, 27);
            this.label1.TabIndex = 0;
            this.label1.Text = "Вывод первого приветствия\r\n";
            this.label1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // BtnPickcher
            // 
            this.BtnPickcher.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.BtnPickcher.Font = new System.Drawing.Font("Lucida Console", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BtnPickcher.Location = new System.Drawing.Point(34, 314);
            this.BtnPickcher.Margin = new System.Windows.Forms.Padding(4);
            this.BtnPickcher.Name = "BtnPickcher";
            this.BtnPickcher.Size = new System.Drawing.Size(158, 43);
            this.BtnPickcher.TabIndex = 1;
            this.BtnPickcher.Text = "Рисунок";
            this.BtnPickcher.UseVisualStyleBackColor = false;
            this.BtnPickcher.Click += new System.EventHandler(this.BtnPickcher_Click);
            // 
            // BtnHello
            // 
            this.BtnHello.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.BtnHello.Location = new System.Drawing.Point(244, 314);
            this.BtnHello.Margin = new System.Windows.Forms.Padding(4);
            this.BtnHello.Name = "BtnHello";
            this.BtnHello.Size = new System.Drawing.Size(167, 43);
            this.BtnHello.TabIndex = 2;
            this.BtnHello.Text = "Приветствие";
            this.BtnHello.UseVisualStyleBackColor = false;
            this.BtnHello.Click += new System.EventHandler(this.BtnHello_Click);
            // 
            // BtnEx
            // 
            this.BtnEx.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.BtnEx.Location = new System.Drawing.Point(454, 314);
            this.BtnEx.Margin = new System.Windows.Forms.Padding(4);
            this.BtnEx.Name = "BtnEx";
            this.BtnEx.Size = new System.Drawing.Size(157, 43);
            this.BtnEx.TabIndex = 3;
            this.BtnEx.Text = "Выход\r\n";
            this.BtnEx.UseVisualStyleBackColor = false;
            this.BtnEx.Click += new System.EventHandler(this.BtnEx_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(124, 117);
            this.textBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(408, 23);
            this.textBox1.TabIndex = 4;
            // 
            // LblBtnHello
            // 
            this.LblBtnHello.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.LblBtnHello.Font = new System.Drawing.Font("Lucida Console", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblBtnHello.Location = new System.Drawing.Point(124, 75);
            this.LblBtnHello.Name = "LblBtnHello";
            this.LblBtnHello.Size = new System.Drawing.Size(408, 220);
            this.LblBtnHello.TabIndex = 5;
            this.LblBtnHello.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // TmrFirst
            // 
            this.TmrFirst.Interval = 5000;
            this.TmrFirst.Tick += new System.EventHandler(this.TmrFirst_Tick);
            // 
            // LblBtnPickcher
            // 
            this.LblBtnPickcher.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.LblBtnPickcher.Font = new System.Drawing.Font("Lucida Console", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblBtnPickcher.Location = new System.Drawing.Point(124, 75);
            this.LblBtnPickcher.Name = "LblBtnPickcher";
            this.LblBtnPickcher.Size = new System.Drawing.Size(408, 220);
            this.LblBtnPickcher.TabIndex = 6;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(624, 441);
            this.Controls.Add(this.LblBtnPickcher);
            this.Controls.Add(this.LblBtnHello);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.BtnEx);
            this.Controls.Add(this.BtnHello);
            this.Controls.Add(this.BtnPickcher);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Lucida Console", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Первое приложение Windows  Forms";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button BtnPickcher;
        private System.Windows.Forms.Button BtnHello;
        private System.Windows.Forms.Button BtnEx;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label LblBtnHello;
        private System.Windows.Forms.Timer TmrFirst;
        private System.Windows.Forms.Label LblBtnPickcher;
    }
}

