﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace H_W1WF
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void BtnHello_Click(object sender, EventArgs e)
        {

            //LblBtnPickcher.Text = "\n\n\nПривет, Windows Forms!";

            string str = $"\n\n\n\n          Привет, Windows Forms!";
            LblBtnPickcher.Text = str;
            TmrFirst.Enabled = true;
            
        }


        private void BtnEx_Click(object sender, EventArgs e) => Application.Exit();

        private void TmrFirst_Tick(object sender, EventArgs e)
        {
            LblBtnPickcher.Text = "";
            LblBtnHello.Text = "";
            TmrFirst.Enabled = false;
        }

        private void BtnPickcher_Click(object sender, EventArgs e)
        {
            string str = @"                   ,%%%,"+"\n"+
                         @"                  ,%%%` %==--"+"\n"+
                         @"                 ,%%`( '|" + "\n" +
                         @"               ,%%@ /\_/" + "\n" +
                         @"   ,%.-""""-- %%% ""@@__" + "\n" +
                         @"   %%/             | __`\" + "\n" +
                         @"  .% '\     |   \   /  //" + "\n" +
                         @"  ,% ' >   .'----\ |  [/" + "\n" +
                         @"      < <<`       ||" + "\n" +
                         @"       `\\\       ||" + "\n" +
                         @"         )\\      )\" + "\n" +
                         @"  ^^^^^^^^^^""""^^^^^^""""^^^^^^^^^^^^^^^^^^^^^^^^^^^^ ";


            LblBtnPickcher.Text = str;
            TmrFirst.Enabled = true;
        }


    }
}
