﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace H_W16C_
{
    /// <summary>
    /// •	Dynamic10. Дан непустой стек. Создать два новых стека,
    ///   переместив в первый из них все элементы исходного стека с четными значениями,
    ///   а во второй — с нечетными (элементы в новых стеках будут располагаться в порядке,
    ///   обратном исходному; один из этих стеков может оказаться пустым). 
    /// 
    ///•	Dynamic24.Даны две непустые очереди, очереди содержат одинаковое количество элементов.
    ///   Объединить очереди в одну, в которой элементы
    ///   исходных очередей чередуются (начиная с первого элемента первой очереди)
    /// 
    ///•	Dynamic37.Дан непустой список.Продублировать в списке все элементы
    ///   с нечетными номерами(новые элементы добавлять перед существующими элементами
    ///   с такими же значениями)
    /// </summary>
    class Program
    {
        static void Main(string[] args)
        {

            Console.Title = "Домашнее задание № 16.";
            try
            {
                // меню приложения
                MenuItem[] menu = new[] {
                new MenuItem { HotKey = ConsoleKey.F5, Text = "Stack. Решение задачи Dynamic10." },
                new MenuItem { HotKey = ConsoleKey.F6, Text = "Queue. Решение задачи Dynamic24" },
                new MenuItem { HotKey = ConsoleKey.F7, Text = "List.  Решение задачи Dynamic37" },
                new MenuItem { HotKey = ConsoleKey.Escape, Text = "Выход" },
            };

                // Создание экземпляра класса приложения
                App app = new App();

                // главный цикл приложения
                while (true)
                {
                    // настройка цветового оформления
                    Console.ForegroundColor = ConsoleColor.White;
                    Console.BackgroundColor = ConsoleColor.DarkCyan;
                    Console.Clear();
                    Console.CursorVisible = false;

                    Utils.ShowMenu(25, 5, "Меню приложения : ", menu);

                    // получить код нажатой клавиши, не отображать символ клавиши
                    ConsoleKey key = Console.ReadKey(true).Key;
                    Console.Clear();

                    switch (key)
                    {
                        // Stack. Решение задачи Dynamic10
                        case ConsoleKey.F5:
                            app.Dynamic10();
                            break;

                        // Queue. Решение задачи Dynamic24
                        case ConsoleKey.F6:
                            app.Dynamic24();
                            break;

                        // List.  Решение задачи Dynamic37
                        case ConsoleKey.F7:
                            app.Dynamic37();
                            break;

                        // Выход клавиша Esc
                        case ConsoleKey.Escape:
                            Console.ResetColor();   // сброс цветового сочетания к исходному
                            Console.Clear();
                            Utils.WriteXY(0, Console.WindowHeight - 1, "Нажмите любую клавишу...", ConsoleColor.White);
                            Console.CursorVisible = true;
                            return;
                        default:
                            continue;
                    } // switch

                    // Ожидать нажатия любой клавиши по окончании работы пункта меню
                    Console.CursorVisible = true;
                    Utils.WriteXY(0, Console.WindowHeight - 1, "Нажмите любую клавишу...", ConsoleColor.White);
                    Console.ReadKey(true);
                } // while

            }
            catch (Exception ex)
            {
                Console.ForegroundColor = ConsoleColor.Magenta;
                Console.WriteLine($"\n{ex.Message}");
                //throw;
            }
            finally
            {
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine("\nКод финализации");
                Console.ForegroundColor = ConsoleColor.Gray;
            }// try- catch- finally
            Console.ForegroundColor = ConsoleColor.White;
        }// Main
    }// class Program
}
