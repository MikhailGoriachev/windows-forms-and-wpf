﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace H_W16C_
{
    internal class App
    {
        // поля для решения Dynamic10
        public Stack<int> Stack1 { get; set; }
        public Stack<int> Stack2 { get; set; }
        public Stack<int> Stack3 { get; set; }

        // поля для решения Dynamic24
        public Queue<int> Queue1 { get; set; }
        public Queue<int> Queue2 { get; set; }
        public Queue<int> Queue3 { get; set; }

        // поля для решения Dynamic37
        public List<int> List1 { get; set; }

        // исходные размеры стека
        private int _size1;
        private int _size2;
        private int _size3;

        public App() : this(0, 0, 0) { }
        public App(int size1, int size2, int size3)
        {
            _size1 = size1;
            _size2 = size2;
            _size2 = size3;

        } // App


        #region Решение задачи Dynamic10
        public void Dynamic10()
        {
            Utils.ShowNavBarTask("     Решение задачи Dynamic 10.");
            Console.WriteLine("\n\n Создать два новых стека, переместив в первый из них" +
                " элементы с четными значениями, а во второй — с нечетными.");
            Stack1 = Generate(Utils.Random.Next(8, 12));
            Stack2 = new Stack<int>();
            Stack3 = new Stack<int>();

            Console.Write("\n\n Stack1 :");
            Show(Stack1);
            Console.Write("\n\n Stack2 :");
            var tuple = MovingStack(Stack1, Stack2, Stack3);
            Show(tuple.Item1);
            Console.Write("\n\n Stack3 :");
            Show(tuple.Item2);

        }// Dynamic10

        // применение кортежа для обработки задачи по условию
        private static Tuple<Stack<int>, Stack<int>> MovingStack(Stack<int> stack, Stack<int> odd, Stack<int> even)
        {
            foreach (var item in stack)
                if ((item & 1) == 0)
                    even.Push(item);
                else
                    odd.Push(item);

            return new Tuple<Stack<int>, Stack<int>>(odd, even);
        }// MovingStack

        // заполнение стека случайными значениями
        private static Stack<int> Generate(int size)
        {
            var stack = new Stack<int>();
            for (int i = 0; i < size; i++) {
                stack.Push(Utils.Random.Next(-20, 20));
            }// for i

            return stack;
        } // Generate

        // вывод стека
        private static void Show(Stack<int> stack)
        {
            foreach (var item in stack)
                Console.Write($"{item,7}");
        }// Show

        #endregion

        #region Решение задачи Dynamic24
        public void Dynamic24()
        {
            Utils.ShowNavBarTask("     Решение задачи Dynamic 24.");
            Console.WriteLine("\n\n  Даны две непустые очереди, объединить очереди в одну, в которой элементы исходных очередей чередуются.");

            Queue1 = GenerateQ(6);
            Queue2 = GenerateQ(6);
            Queue3 = new Queue<int>();

            Console.Write("\n\n Queue1 :");
            Show(Queue1);
            Console.Write("\n\n Queue2 :");
            Show(Queue2);
            MovingQueue(Queue1, Queue2, Queue3, 6);
            Console.Write("\n\n Queue3 :");
            Show(Queue3);
        }// Dynamic24

        // перемещение элементов из двух очередей в одну
        private static Queue<int> MovingQueue(Queue<int> q1, Queue<int> q2, Queue<int> q3, int size) 
        { 
            for (int i = 0; i < size; i++) {
                q3.Enqueue(q1.Peek());
                q1.Peek();
                q1.Dequeue();
                q3.Enqueue(q2.Peek());
                q2.Peek();
                q2.Dequeue();
            }// for i

            return q3;
        }// MovingQueue

        // заполнение очереди случайными значениями
        private static Queue<int> GenerateQ(int size)
        {
            var queue = new Queue<int>();
            for (int i = 0; i < size; i++)
            {
                queue.Enqueue(Utils.Random.Next(-20, 20));
            }// for i

            return queue;
        } // GenerateQ

        // вывод очереди
        private static void Show(Queue<int> queue)
        {
            foreach (var item in queue)
                Console.Write($"{item,7}");
        }// Show

        #endregion

        #region Решение задачи Dynamic37
        public void Dynamic37()
        {
            Utils.ShowNavBarTask("     Решение задачи Dynamic 37.");
            Console.WriteLine("\n\n Дан непустой список.Продублировать в списке все элементы с нечетными номерами.");

            List1 = GenerateL(Utils.Random.Next(8, 10));

            Console.Write("\n\n List1 :");
            Show(List1);
            DuplicateList(List1);
            Console.Write("\n\n\n List1 :");
            Show(List1);

        }// Dynamic37

        // дублирование элементов с нечётными номерами
        private static List<int> DuplicateList(List<int> list1)
        {
            for (int i = 1; i < list1.Count; i+=3) {
                list1.Insert(i, list1[i]);
            }// for i

            return list1;
        }// DuplicateList

        // заполнение списка случайными значениями
        private static List<int> GenerateL(int size)
        {
            var list = new List<int>();
            for (int i = 0; i < size; i++)
            {
                list.Add(Utils.Random.Next(-20, 20));
            }// for i

            return list;
        } // GenerateL

        // вывод списка
        private static void Show(List<int> list)
        {
            foreach (var item in list)
                Console.Write($"{item,7}");
        }// Show
        #endregion

    }// class App
}
