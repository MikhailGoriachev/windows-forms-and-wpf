﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HW_1
{
    public partial class MainForm : Form
    {
        public MainForm(){
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e) { }
        private void tmr_Tick(object sender, EventArgs e){
            lbl.Text = "";
            tmr.Enabled = false;
        }

        private void btnArt_Click(object sender, EventArgs e){
            string str = @"" +
         @"                  ,%%%,                                " + "\n" +
         @"                 ,%%%` %==--                           " + "\n" +
         @"                ,%%`( '|                               " + "\n" +
         @"               ,%%@ /\_/                               " + "\n" +
         @"     ,%.-""""""-- %%% ""@@__                           " + "\n" +
         @"    %%/             | __`\                             " + "\n" +
         @"   .% '\     |   \   /  //                             " + "\n" +
         @"   ,% ' >   .'----\ |  [/                              " + "\n" +
         @"       < <<`       ||                                  " + "\n" +
         @"        `\\\       ||                                  " + "\n" +
         @"          )\\      )\                                  " + "\n" +
         @" ^^^^^^^^^""""^^^^^^""""^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^""";
            lbl.Text = str;
            tmr.Enabled = true;
        }

        private void btnHello_Click(object sender, EventArgs e){
            lbl.Text = "Привет, Windows Forms";
            tmr.Enabled = true;
        }

        private void btnExit_Click(object sender, EventArgs e){
            Application.Exit();
        }
    }
}
