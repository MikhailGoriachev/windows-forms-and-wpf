﻿using System;
using System.Collections.Generic;
using System.Linq;

using HW_15.Helpers;


namespace HW_15.Appllication{
    internal class App{
        private int _size;
        public int Size{
            get => _size;
            private set => _size = value > 0 ? value : throw new Exception("Недопустимый размер стека");
        } // Size

        //  стек для первой задачи
        public Stack<int> StackInt { get; set; }

        // для задача №2 

        // очереди для второй задачи
        public Queue<int> QueueInt1 { get; set; }
        public Queue<int> QueueInt2 { get; set; }

        // для задача №3

        List<int> ListInt { get; set; }

        public App() : this(7) { }


        public App(int size) => Size = size;



        /* Дан непустой стек. Создать два новых стека, переместив 
           в первый из них все элементы исходного стека с четными значениями,
           а во второй — с нечетными
           (элементы в новых стеках будут располагаться в порядке, обратном исходному;
           один из этих стеков может оказаться пустым). */

        public void task1(){
            Console.WriteLine("\n\n");

            GenerationStack();
            Stack<int> StackEven = new Stack<int>();
            Stack<int> StackOdd = new Stack<int>();
            Console.WriteLine($"\n\tСтеки до обработки. Начальный стек: {Utils.ToString(StackInt)}");
            Console.WriteLine($"\n\tСтеки до обработки. Четный    стек: {Utils.ToString(StackEven)}");
            Console.WriteLine($"\n\tСтеки до обработки. Нечетный  стек: {Utils.ToString(StackOdd)}");

            while (StackInt.Count > 0){
                int temp = StackInt.Pop();
                if ((temp & 1) == 0) StackEven.Push(temp);
                else StackOdd.Push(temp);
            } // while

            Console.WriteLine($"\n\t\tСтеки после обработки:");
            Console.WriteLine($"\n\tНачальный стек: {Utils.ToString(StackInt)}");
            Console.WriteLine($"\n\tЧетный    стек: {Utils.ToString(StackEven)}");
            Console.WriteLine($"\n\tНечетный  стек: {Utils.ToString(StackOdd)}");

        } // task1

        /*  Даны две непустые очереди, очереди содержат одинаковое количество элементов. 
           Объединить очереди в одну, в которой элементы исходных очередей чередуются  
           (начиная с первого элемента первой очереди)    
        */

        public void task2(){
            Console.WriteLine("\n\n");

            GenerationQueue();
            Queue<int> EatenQueue = new Queue<int>();
            Console.WriteLine($"\n\t\tОчереди до обработки:");
            Console.WriteLine($"\n\tОчередь №1          : {Utils.ToString(QueueInt1)}");
            Console.WriteLine($"\n\tОчередь №2          : {Utils.ToString(QueueInt2)}");
            Console.WriteLine($"\n\tОбъедененная очередь: {Utils.ToString(EatenQueue)}");

            int i = 0;

            while (QueueInt2.Count > 0){
                if ((i & 1) == 0) EatenQueue.Enqueue(QueueInt1.Dequeue());
                else EatenQueue.Enqueue(QueueInt2.Dequeue());
                i++;
            } //  while 

            Console.WriteLine($"\n\t\tОчереди до обработки:");
            Console.WriteLine($"\n\tОчередь №1          : {Utils.ToString(QueueInt1)}");
            Console.WriteLine($"\n\tОчередь №2          : {Utils.ToString(QueueInt2)}");
            Console.WriteLine($"\n\tОбъедененная очередь: {Utils.ToString(EatenQueue)}");

        } // task2

        //  Дан непустой список. Продублировать в списке все элементы с нечетными номерами 
        // (новые элементы добавлять перед существующими элементами с такими же значениями)
        public void task3(){
            Console.WriteLine("\n\n");

            GenerationList();

            Console.WriteLine($"\n\t\tЛист до обработки:");
            Console.WriteLine($"\n\tЛист: {Utils.ToString(ListInt)}");

            int n = ListInt.Count() / 2;
            int[] arr = new int[n];
            for (int i = 1, k = 0; i < ListInt.Count(); i += 2)
                arr[k++] = ListInt[i];


            for (int i = 0; i < n; i++){
                int temp = arr[i];
                ListInt.Insert(ListInt.FindIndex(item => item == temp),temp);
            } // for

            Console.WriteLine($"\n\t\tЛист после обработки:");
            Console.WriteLine($"\n\tЛист: {Utils.ToString(ListInt)}");
        } // task3


        // заполнение данными всех полей класса
        public void Generation(){
            GenerationStack();
            GenerationQueue();
        } // Generation

        // заполнение стека данными для обработки
        public void GenerationStack() => StackInt = Utils.CreateStack(Size, -10, 10);

        // заполнение очереди данными для обработки
        public void GenerationQueue(){
            QueueInt1 = Utils.CreateQueue(Size, -10, 10);
            QueueInt2 = Utils.CreateQueue(Size, -10, 10);
        } // GenerationQueue

        // заполнение листа данными для обработки
        public void GenerationList() => ListInt = Utils.CreateList(Size, -10, 10);

    }
} // App
