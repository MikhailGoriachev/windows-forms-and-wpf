﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp4.Application
{
    public class App
    {




        public Random r = new Random();

        public void StackDemo()
        {

            //исходный стек
            Stack<int> stack1= new Stack<int>();
            //стек для четных числе
            Stack<int> stack2= new Stack<int>();
            //стек для нечетных 
            Stack<int> stack3= new Stack<int>();

            //заполнение исходного стека
            for (int i = 0; i < 10; i++)
            {
                stack1.Push(r.Next(0, 21));
            }


            //вывод стека
            Console.Write("Stack 1 : ");
            foreach (var item in stack1)
            {
                Console.Write($" {item} ");
            }

            Console.WriteLine();
            

            foreach (var item in stack1)
            {
                if (item % 2 == 0)
                {
                    stack2.Push(item);
                    

                }
                else stack3.Push(item);
            }
            stack1.Clear();

            //вывод стеков
            Console.Write("Stack 1 после обработки : ");
            foreach (var item in stack1)
            {
                Console.Write($" {item} ");
            }

            Console.WriteLine( );

            Console.Write("Stack 2 c четными числами :");

            foreach (var item in stack2)
            {
                Console.Write($" {item} ");
            }

            Console.WriteLine();

            Console.Write("Stack 3 c нечетными числами :");

            foreach (var item in stack3)
            {
                Console.Write($" {item} ");
            }

        }//STACKDEMO

        public void QueueDemo()
        {
            Queue<int> queue1 = new Queue<int>();

            Queue<int> queue2 = new Queue<int>();

            Queue<int> queue3 = new Queue<int>();

            for (int i = 0; i < 10; i++)
            {
                queue1.Enqueue(r.Next(0, 21));
                queue2.Enqueue(r.Next(10, 31));
            }


         
            Console.Write("Queue1  : ");
            foreach (var item in queue1)
            {
                Console.Write($" {item} ");
            }


            Console.WriteLine();
            Console.Write("Queue2  : ");
            foreach (var item in queue2)
            {
                Console.Write($" {item} ");
            }
            //перемещение
            while(queue1.Count>0 && queue2.Count>0)
            {
                int q1 = queue1.Dequeue();
                int q2 = queue2.Dequeue();
                queue3.Enqueue(q1);
                queue3.Enqueue(q2);
            }


            Console.WriteLine();
            Console.Write("Queue3  : ");
            foreach (var item in queue3)
            {
                Console.Write($" {item} ");
            }
        }//QUEUEDEMO


        public void ListDemo()
        {
            List<int> list = new List<int>();

            List<int> list2 = new List<int>();

            for (int i = 0; i < 10; i++)
            {
                list.Add(r.Next(0, 31));
            }

            Console.Write("List  : ");
            foreach (var item in list)
            {
                Console.Write($" {item} ");
            }
           
            for (int i = 0; i < list.Count; i++)
            {

                if (i % 2 != 0)
                {
                    list2.Add(list[i]);
                    list2.Add(list[i]);
                }
                else list2.Add(list[i]);
               
            }



            Console.WriteLine();
            Console.Write("List после обработки  : ");
            foreach (var item in list2)
            {
                Console.Write($" {item} ");
            }
        }
    }
}
