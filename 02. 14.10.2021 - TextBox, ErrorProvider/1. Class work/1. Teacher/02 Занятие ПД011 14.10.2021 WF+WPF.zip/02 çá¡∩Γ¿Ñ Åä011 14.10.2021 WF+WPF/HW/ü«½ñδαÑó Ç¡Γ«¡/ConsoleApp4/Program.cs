﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ConsoleApp4.Application;

namespace ConsoleApp4
{
    
    /*Задача 1. Разработайте, пожалуйста, консольное приложение C# для решения следующих задач, с использованием типизированных коллекций, закрытых типом int. 
Dynamic10. Дан непустой стек. Создать два новых стека, переместив в первый из них все элементы исходного стека с четными значениями, а во второй — с нечетными (элементы в новых стеках будут располагаться в порядке, обратном исходному; один из этих стеков может оказаться пустым). 
Dynamic24. Даны две непустые очереди, очереди содержат одинаковое количество элементов. Объединить очереди в одну, в которой элементы исходных очередей чередуются (начиная с первого элемента первой очереди)
Dynamic37. Дан непустой список. Продублировать в списке все элементы с нечетными номерами (новые элементы добавлять перед существующими элементами с такими же значениями)
*/

    class Program
    {
        
        static void Main(string[] args)
        {


            App app = new App();
            Console.WriteLine();
            Console.WriteLine("Демнострация стека:");
            app.StackDemo();

            Console.WriteLine("\n");
            Console.WriteLine("Демнострация очереди:");
            Console.WriteLine("Демнострация очереди:");
            app.QueueDemo();

            Console.WriteLine("\n");
            Console.WriteLine("Демнострация списка :");
            app.ListDemo();
                
                     
               
            

          



        }


        
     
    }
}
