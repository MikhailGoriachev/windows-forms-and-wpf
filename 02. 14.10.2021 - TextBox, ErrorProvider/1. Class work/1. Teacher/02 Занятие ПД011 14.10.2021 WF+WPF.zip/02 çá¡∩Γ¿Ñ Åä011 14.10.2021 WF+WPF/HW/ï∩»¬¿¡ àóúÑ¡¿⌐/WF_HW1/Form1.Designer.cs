﻿
namespace WF_HW1
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.Btn_Drawing = new System.Windows.Forms.Button();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.Btn_Greeting = new System.Windows.Forms.Button();
            this.Lbl_Header = new System.Windows.Forms.Label();
            this.Lbl_Greeting = new System.Windows.Forms.Label();
            this.Btn_Exit = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Btn_Drawing
            // 
            this.Btn_Drawing.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.Btn_Drawing.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.Btn_Drawing.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Btn_Drawing.Location = new System.Drawing.Point(273, 358);
            this.Btn_Drawing.Name = "Btn_Drawing";
            this.Btn_Drawing.Size = new System.Drawing.Size(144, 58);
            this.Btn_Drawing.TabIndex = 1;
            this.Btn_Drawing.Text = "Рисунок";
            this.Btn_Drawing.UseVisualStyleBackColor = false;
            this.Btn_Drawing.Click += new System.EventHandler(this.BtnDrawing_Click);
            // 
            // timer1
            // 
            this.timer1.Interval = 5000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // Btn_Greeting
            // 
            this.Btn_Greeting.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.Btn_Greeting.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Btn_Greeting.Location = new System.Drawing.Point(106, 358);
            this.Btn_Greeting.Name = "Btn_Greeting";
            this.Btn_Greeting.Size = new System.Drawing.Size(144, 58);
            this.Btn_Greeting.TabIndex = 2;
            this.Btn_Greeting.Text = "Приветствие";
            this.Btn_Greeting.UseVisualStyleBackColor = false;
            this.Btn_Greeting.Click += new System.EventHandler(this.BtnGreeting_Click);
            // 
            // Lbl_Header
            // 
            this.Lbl_Header.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.Lbl_Header.Font = new System.Drawing.Font("Trebuchet MS", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Lbl_Header.Location = new System.Drawing.Point(101, 28);
            this.Lbl_Header.Name = "Lbl_Header";
            this.Lbl_Header.Size = new System.Drawing.Size(613, 61);
            this.Lbl_Header.TabIndex = 3;
            this.Lbl_Header.Text = "Вывод текстового приветствия";
            this.Lbl_Header.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Lbl_Header.Click += new System.EventHandler(this.LblHeader_Click);
            // 
            // Lbl_Greeting
            // 
            this.Lbl_Greeting.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.Lbl_Greeting.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Lbl_Greeting.Font = new System.Drawing.Font("Consolas", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Lbl_Greeting.ForeColor = System.Drawing.Color.Black;
            this.Lbl_Greeting.Location = new System.Drawing.Point(102, 106);
            this.Lbl_Greeting.Name = "Lbl_Greeting";
            this.Lbl_Greeting.Size = new System.Drawing.Size(613, 227);
            this.Lbl_Greeting.TabIndex = 4;
            this.Lbl_Greeting.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Lbl_Greeting.Click += new System.EventHandler(this.LblGreating_Click);
            // 
            // Btn_Exit
            // 
            this.Btn_Exit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.Btn_Exit.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Btn_Exit.Location = new System.Drawing.Point(597, 358);
            this.Btn_Exit.Name = "Btn_Exit";
            this.Btn_Exit.Size = new System.Drawing.Size(117, 58);
            this.Btn_Exit.TabIndex = 5;
            this.Btn_Exit.Text = "Выход";
            this.Btn_Exit.UseVisualStyleBackColor = false;
            this.Btn_Exit.Click += new System.EventHandler(this.BtnExit_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.Btn_Exit);
            this.Controls.Add(this.Lbl_Greeting);
            this.Controls.Add(this.Lbl_Header);
            this.Controls.Add(this.Btn_Greeting);
            this.Controls.Add(this.Btn_Drawing);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button Btn_Drawing;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Button Btn_Greeting;
        private System.Windows.Forms.Label Lbl_Header;
        private System.Windows.Forms.Label Lbl_Greeting;
        private System.Windows.Forms.Button Btn_Exit;
    }
}

