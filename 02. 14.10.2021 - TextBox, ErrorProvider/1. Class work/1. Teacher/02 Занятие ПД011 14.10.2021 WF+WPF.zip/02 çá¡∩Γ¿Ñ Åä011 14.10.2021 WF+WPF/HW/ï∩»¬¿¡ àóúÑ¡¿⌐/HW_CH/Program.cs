﻿using HW_CH.Application;
using HW_CH.Helpers;
using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HW_CH
{
    class Program
    {
        static void Main(string[] args)
        {

            // простейшее меню приложения
            MenuItem[] menu = new[] {
                new MenuItem { HotKey = ConsoleKey.Q, Text = "Обработка стека" },
                new MenuItem { HotKey = ConsoleKey.W, Text = "Обработка очереди" },
                new MenuItem { HotKey = ConsoleKey.A, Text = "Обработка списка" },
                new MenuItem { HotKey = ConsoleKey.Z, Text = "Выход" },
            };

            // Создание экземпляра класса приложения
            App_Common app = new App_Common();

            // главный цикл приложения
            while (true)
            {
                try
                {
                    // настройка цветового оформления
                    Console.ForegroundColor = ConsoleColor.Cyan;
                    Console.Clear();
                    Console.CursorVisible = false;

                    Utils.ShowNavBarTask("  Введение в ООП C# - классы, свойства, массивы объектов");
                    Utils.ShowMenu(12, 5, "Меню приложения для работы с массивами объектов", menu);

                    // получить код нажатой клавиши, не отображать символ клавиши
                    ConsoleKey key = Console.ReadKey(true).Key;
                    Console.Clear();

                    switch (key)
                    {
                        case ConsoleKey.Q:
                            app.Task1();
                            break;

                        case ConsoleKey.W:
                            app.Task2();
                            break;

                        case ConsoleKey.A:
                            app.Task3();
                            break;

                        // выход из приложения назначен на клавишу F10 или кавишу Z
                        case ConsoleKey.F10:
                        case ConsoleKey.Z:
                            Console.ResetColor();   // сброс цветового сочетания к исходному
                            Console.Clear();
                            Utils.WriteXY(0, Console.WindowHeight - 1, "Нажмите любую клавишу...", ConsoleColor.Gray);
                            Console.CursorVisible = true;
                            return;

                        default:
                            throw new Exception("Нет такой команды меню");
                    } // switch

                    // Ожидать нажатия любой клавиши по окончании работы пункта меню
                    Console.CursorVisible = true;
                    Utils.WriteXY(0, Console.WindowHeight - 1, "Нажмите любую клавишу...", ConsoleColor.Gray);
                    Console.ReadKey(true);
                } // try

                // обработка исключений - просто вывести сообщение
                catch (Exception ex)
                {
                    Interaction.MsgBox(ex.Message, MsgBoxStyle.Critical | MsgBoxStyle.OkOnly, "Ошибка");
                } // try-catch
            } // while
        } // Main
    }//Program
}
