﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HW_CH.Application
{
    // Общая часть приложения, создание объектов для выполнения задания
     public class App_Common
     {
        public void Task1() 
        {
            Stack<int> stack = new Stack<int>(new[] { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 });
            Stack<int> stackEven = new Stack<int>();
            Stack<int> stackOdd = new Stack<int>();

            Console.WriteLine("\t\tИсходный стек:");
            Show(stack);
            Console.WriteLine("\n\n\t\tЧетный стек:");
            Show(stackEven);
            Console.WriteLine("\n\n\t\tНечетный стек:");
            Show(stackOdd);

            int n = stack.Count();

            for (int i = 0; i < n; i++)
            {
                if ((stack.Peek() & 1) == 0)
                    stackEven.Push(stack.Pop());
                else 
                    stackOdd.Push(stack.Pop());
            }


            Console.WriteLine("\n\n\n\t\tИсходный стек после изменения:");
            Show(stack);
            Console.WriteLine("\n\n\t\tЧетный стек: ");
            Show(stackEven);
            Console.WriteLine("\n\n\t\tНечетный стек: ");
            Show(stackOdd);
        }

        public void Task2()
        {
            Queue<int> queue1 = new Queue<int>(new[] { 1, 2, 3, 4, 5, 6, 7, 8 });
            Queue<int> queue2 = new Queue<int>(new[] { 8, 7, 6, 5, 4, 3, 2, 1 });
            Queue<int> queue3 = new Queue<int>();

            Console.WriteLine("\t\tПервая очередь:");
            Show(queue1);
            Console.WriteLine("\n\n\tВторая очередь:");
            Show(queue2);


            for (int i = 0; i < queue1.Count + queue2.Count; i++)
            {
                queue3.Enqueue(queue1.Dequeue());
                queue3.Enqueue(queue2.Dequeue());
            }

            Console.WriteLine("\n\n\t\tПолученная очередь: ");
            Show(queue3);

        }

        public void Task3()
        {
            List<int> list = new List<int>(new int[] { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 });
            Console.WriteLine("\t\tСписок до обработки");
            Show(list);

            for (int i = 0; i < list.Count; i++)
            {

                list.Insert(i, list[i]);
                i += 2;
            }

            Console.WriteLine("\n\t\t\tСписок после обработки");
            Show(list);
            Console.WriteLine();

        }

        //функция для вывода стека
        private void Show(Stack<int> stack)
        {
            if (stack.Count == 0)
            {
                Console.WriteLine("Пусто!");
                return;
            }
            foreach (var item in stack)
                Console.Write($"   {item}");
        }

        //функция для вывода очереди
        private void Show(Queue<int> queue)
        {
            if (queue.Count == 0)
            {
                Console.WriteLine("Пусто!");
                return;
            }
            foreach (var item in queue)
                Console.Write($"   {item}");
        }

        //функция для вывода списка
        private void Show(List<int> list)
        {
            if (list.Count == 0)
            {
                Console.WriteLine("Пусто!");
                return;
            }
            foreach (var item in list)
                Console.Write($"   {item}");
        }
    } // class App
}
