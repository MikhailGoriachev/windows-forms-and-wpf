﻿
namespace HW1
{
	partial class MainForm
	{
		/// <summary>
		/// Обязательная переменная конструктора.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Освободить все используемые ресурсы.
		/// </summary>
		/// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Код, автоматически созданный конструктором форм Windows

		/// <summary>
		/// Требуемый метод для поддержки конструктора — не изменяйте 
		/// содержимое этого метода с помощью редактора кода.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			this.LblGreeting = new System.Windows.Forms.Label();
			this.BtnDrawing = new System.Windows.Forms.Button();
			this.BtnQuit = new System.Windows.Forms.Button();
			this.BtnGreeting = new System.Windows.Forms.Button();
			this.tmrFirst = new System.Windows.Forms.Timer(this.components);
			this.SuspendLayout();
			// 
			// LblGreeting
			// 
			this.LblGreeting.BackColor = System.Drawing.Color.LavenderBlush;
			this.LblGreeting.Font = new System.Drawing.Font("Consolas", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.LblGreeting.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
			this.LblGreeting.Location = new System.Drawing.Point(12, 21);
			this.LblGreeting.Name = "LblGreeting";
			this.LblGreeting.Size = new System.Drawing.Size(515, 250);
			this.LblGreeting.TabIndex = 5;
			// 
			// BtnDrawing
			// 
			this.BtnDrawing.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.BtnDrawing.Location = new System.Drawing.Point(13, 285);
			this.BtnDrawing.Name = "BtnDrawing";
			this.BtnDrawing.Size = new System.Drawing.Size(157, 45);
			this.BtnDrawing.TabIndex = 6;
			this.BtnDrawing.Text = "Рисунок";
			this.BtnDrawing.UseVisualStyleBackColor = true;
			this.BtnDrawing.Click += new System.EventHandler(this.BtnDrawing_Click);
			// 
			// BtnQuit
			// 
			this.BtnQuit.BackColor = System.Drawing.Color.Silver;
			this.BtnQuit.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.BtnQuit.Location = new System.Drawing.Point(370, 285);
			this.BtnQuit.Name = "BtnQuit";
			this.BtnQuit.Size = new System.Drawing.Size(157, 44);
			this.BtnQuit.TabIndex = 7;
			this.BtnQuit.Text = "Выход";
			this.BtnQuit.UseVisualStyleBackColor = false;
			this.BtnQuit.Click += new System.EventHandler(this.BtnQuit_Click);
			// 
			// BtnGreeting
			// 
			this.BtnGreeting.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.BtnGreeting.Location = new System.Drawing.Point(197, 286);
			this.BtnGreeting.Name = "BtnGreeting";
			this.BtnGreeting.Size = new System.Drawing.Size(157, 44);
			this.BtnGreeting.TabIndex = 8;
			this.BtnGreeting.Text = "Приветствие";
			this.BtnGreeting.UseVisualStyleBackColor = true;
			this.BtnGreeting.Click += new System.EventHandler(this.BtnGreeting_Click);
			// 
			// tmrFirst
			// 
			this.tmrFirst.Interval = 5000;
			this.tmrFirst.Tick += new System.EventHandler(this.tmrFirst_Tick);
			// 
			// MainForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(560, 351);
			this.Controls.Add(this.BtnGreeting);
			this.Controls.Add(this.BtnQuit);
			this.Controls.Add(this.BtnDrawing);
			this.Controls.Add(this.LblGreeting);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.MaximizeBox = false;
			this.Name = "MainForm";
			this.Text = "Домашнее задание";
			this.ResumeLayout(false);

		}

		#endregion
		private System.Windows.Forms.Label LblGreeting;
		private System.Windows.Forms.Button BtnDrawing;
		private System.Windows.Forms.Button BtnQuit;
		private System.Windows.Forms.Button BtnGreeting;
		private System.Windows.Forms.Timer tmrFirst;
	}
}

