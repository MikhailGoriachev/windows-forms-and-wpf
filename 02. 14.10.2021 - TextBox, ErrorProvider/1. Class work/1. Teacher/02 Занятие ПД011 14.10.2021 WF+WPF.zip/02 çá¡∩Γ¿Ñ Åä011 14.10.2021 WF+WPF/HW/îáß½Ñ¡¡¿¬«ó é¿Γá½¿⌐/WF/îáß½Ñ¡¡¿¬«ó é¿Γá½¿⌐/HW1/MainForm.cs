﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HW1
{
	public partial class MainForm : Form
	{
		public MainForm()
		{
			InitializeComponent();
		}

		// Обработчик клика на кнопку Рисунок
		private void BtnDrawing_Click(object sender, EventArgs e)
		{
			// Изменение выравнивания текста - по центру (горизонталь и вертикаль)
			LblGreeting.TextAlign = ContentAlignment.MiddleCenter;

			// Изменение цвета элемента
			LblGreeting.ForeColor = System.Drawing.Color.Black;
			LblGreeting.BackColor = System.Drawing.Color.AliceBlue;

			// Изменение текста
			LblGreeting.Text  =
						 @"                    ,%%%,       " + "\n" +
						 @"                 ,%%%` %==--	  " + "\n" +
						 @"               ,%%`( '|     " + "\n" +
						 @"             ,%%@ /\_/	    " + "\n" +
						 @"     ,%.-""""""--%%% ""@@__     	  " + "\n" +
						 @"    %%/             |__`\    " + "\n" +
						 @"   .%'\     |   \   /  //	    " + "\n" +
						 @"   ,%' >   .'----\ |  [/     " + "\n" +
						 @"    < <<`       ||        " + "\n" +
						 @"     `\\\       ||        " + "\n" +
						 @"       )\\      )\        " + "\n" +
						 @"^^^^^""""""^^^^^^""""^^^^^^" + "\n";

			// Обнуление и запуск таймера
			ResetTimer(tmrFirst);
		}

		// Обработчик окончания таймера
		private void tmrFirst_Tick(object sender, EventArgs e)
		{
			// Изменение текста
			LblGreeting.Text = "";

			// Обнуление и запуск таймера
			ResetTimer(tmrFirst);
		}

		// Обработчик клика на кнопку Приветствие
		private void BtnGreeting_Click(object sender, EventArgs e)
		{
			// Изменение цвета элемента
			LblGreeting.ForeColor = Color.AliceBlue;
			LblGreeting.BackColor = Color.CadetBlue;

			// Изменение выравнивания текста - по центру (горизонталь и вертикаль)
			LblGreeting.TextAlign = ContentAlignment.MiddleCenter;
			
			// Изменение текста
			LblGreeting.Text = "Привет, Windows Forms";

			// Обнуление и запуск таймера
			ResetTimer(tmrFirst);
		}

		// Обработчик клика на кнопку Выход
		private void BtnQuit_Click(object sender, EventArgs e) => Application.Exit();

		// Обнуление и запуск таймера
		private void ResetTimer(Timer timer)
		{
			timer.Stop();
			timer.Start();
		}

	}

}
