﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HW16.Models;

namespace HW16
{
	internal partial class App
	{
		private Menu _mainMenu;
		private Menu _subMenu1;

		private Task1 _task;

		public App() : this(new Task1())
		{
			InitMenu();
		}

		public App(Task1 task)
		{
			_task = task;
		}


		// Создание объектов меню
		private void InitMenu()
		{
			// Главное меню
			_mainMenu = new Menu(new[]
				{
					new Menu.MenuItem("Задание 1", MainMenuItem1),
					new Menu.MenuItem("Выход")
				}, new Point(5, 5),
				"Меню приложения");

			// Подменю - первое задание
			_subMenu1 = new Menu(new[]
				{
					new Menu.MenuItem("Dynamic10", Task1MenuItem1),
					new Menu.MenuItem("Dynamic24", Task1MenuItem2),
					new Menu.MenuItem("Dynamic37", Task1MenuItem3),
					new Menu.MenuItem("Назад")
				}, new Point(5, 5),
				"Задание 1");

			
		}

		public void Run() => _mainMenu.Run();
		private void MainMenuItem1() => _subMenu1.Run(true);
	}
}
