﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HW16
{
	public static class Utilities
	{
		public const int indent = 4;

		public static string spaces = " ".PadRight(indent);

		public static Random _rand = new Random();
		public static void ShowNavBar(string promt, int nIndentLines = 0, int leftIndents = indent)
		{
			// сохранить цвета консоли
			ColorSet curColors = new ColorSet(true);

			string header = new string(' ', Console.WindowWidth);

			Palette.Hint.SetToConsole();
			Console.SetCursorPosition(0, 0);
			Console.Write(header);

			// Выводим текст в верхнюю строку
			WriteXY(indent, 0, promt, ConsoleColor.Black);

			// восстановить цвета консоли
			curColors.SetToConsole();

			NewLines(nIndentLines);
		}

		public static void NewLines(int n)
		{
			for (int i = 0; i < n; i++)
			{
				Console.WriteLine();
			}
		}

		// Вспомогательный метод для вывода в заданных координатах окна консоли текста
		// заданным цветом
		public static void WriteXY(int x, int y, string s, ConsoleColor color)
		{
			// сохранить текущий цвет консоли и установить заданный
			ConsoleColor oldColor = Console.ForegroundColor;
			Console.ForegroundColor = color;

			Console.SetCursorPosition(x, y);
			Console.WriteLine(s);

			// восстановить цвет консоли
			Console.ForegroundColor = oldColor;
		}

		public static void WriteColored(string str, ColorSet colors)
		{
			ColorSet curColors = new ColorSet(true);
			colors.SetToConsole();
			Console.Write(str);
			curColors.SetToConsole();
		}


		public static double GenerateDouble(double from, double to)
			=> from + _rand.NextDouble() * (to - from);
		public static int GenerateInt(int from, int to) => _rand.Next(from, to);


		public static T GetRandom<T>(T min, T max) where T : struct
		{
			// значение по умолчанию для заданного типа
			T rand = default(T);

			// генерация случайного числа, в зависимости от типа T
			// обратите внимание на двойное приведение типов 
			if (typeof(T) == typeof(int))            // для int
				rand = (T)(object)(_rand.Next((int)(object)min, (int)(object)max + 1));
			else if (typeof(T) == typeof(double))   // для double
				rand = (T)(object)((double)(object)min + ((double)(object)max - (double)(object)min) * _rand.NextDouble());
			else                                    // для остальных типов
				rand = (T)(object)_rand.Next();
			return rand;
		}

		public class ColorSet
		{
			public ConsoleColor Foreground { get; set; }
			public ConsoleColor Background { get; set; }

			public ColorSet(bool currentConsole = false)
			{
				if (currentConsole)
				{
					Foreground = Console.ForegroundColor;
					Background = Console.BackgroundColor;
				}
			}

			public void SetToConsole()
			{
				Console.ForegroundColor = Foreground;
				Console.BackgroundColor = Background;
			}

			public static void SetToConsole(ColorSet colors)
			{
				Console.ForegroundColor = colors.Foreground;
				Console.BackgroundColor = colors.Background;
			}

		}

		public static class Palette
		{
			public static ColorSet Ordinary = new ColorSet()
			{ Foreground = ConsoleColor.Green, Background = ConsoleColor.Black };

			public static ColorSet Hint = new ColorSet()
			{ Foreground = ConsoleColor.Black, Background = ConsoleColor.Gray };

			public static ColorSet Notice = new ColorSet()
			{ Foreground = ConsoleColor.DarkCyan, Background = ConsoleColor.Black };

			public static ColorSet Context = new ColorSet()
			{ Foreground = ConsoleColor.Yellow, Background = ConsoleColor.Black };

			public static ColorSet TableRow = new ColorSet()
			{ Foreground = ConsoleColor.Black, Background = ConsoleColor.Green };

			public static ColorSet HighLight = new ColorSet()
			{ Foreground = ConsoleColor.Black, Background = ConsoleColor.Green };
		}
	}

	public static class Collections
	{
		// создание очереди из size элементов, заполнение ее 
		// случайными числами в диапазоне значаений от from 
		// до to
		public static Queue<T> CreateQueue<T>(int size, T from, T to) where T : struct
		{
			Queue<T> queue = new Queue<T>();

			for (int i = 0; i < size; i++)
			{
				queue.Enqueue(Utilities.GetRandom(from, to));
			} 
			return queue;
		}

		public static Stack<T> CreateStack<T>(int size, T from, T to) where T : struct
		{
			Stack<T> stack = new Stack<T>();

			for (int i = 0; i < size; i++)
			{
				stack.Push(Utilities.GetRandom(from, to));
			} // for i
			return stack;
		}

		public static List<T> CreateList<T>(int size, T from, T to) where T : struct
		{
			List<T> list = new List<T>();

			for (int i = 0; i < size; i++)
			{
				list.Add(Utilities.GetRandom(from, to));
			} // for i
			return list;
		}


		/// <summary>
		/// Возвращает упорядоченную обобщенную очередь из случайных чисел 
		/// </summary>
		/// <param name="size">Размер очереди</param>
		/// <param name="from">Начальное значение диапазона случайных</param>
		/// <param name="to">Конечное значение диапазона случайных</param>
		/// <returns>Упорядоченную по возрастанию обобщенную очередь</returns>
		public static Queue<T> CreateOrderedQueue<T>(int size, T from, T to) where T : struct
		{
			T[] a = CreateOrderedArray<T>(size, from, to);
			Queue<T> queue = new Queue<T>(a);
			return queue;
		} // CreateOrderedQueue

		/// <summary>
		/// Возвращает массив элементов, отсортированных по возрастанию
		/// </summary>
		/// <param name="size"></param>Размер массива
		/// <param name="from">Начальное значение диапазона случайных значений</param>
		/// <param name="to">Конечное значение диапазона случайных значений</param>
		/// <returns>Упорядоченный по возрастанию массив значений</returns>
		private static T[] CreateOrderedArray<T>(int size, T from, T to) where T : struct
		{
			T[] a = new T[size];
			for (int i = 0; i < a.Length; i++) a[i] = Utilities.GetRandom(from, to);
			Array.Sort(a);
			return a;
		} // CreateOrderedArray


		// Преобразование list очереди в строку
		public static string ToString<T>(Queue<T> queue)
		{
			if (!queue.Any())
			{
				return "Пустой список";
			}

			StringBuilder sb = new StringBuilder("");
			foreach (var item in queue)
			{
				if (typeof(T) == typeof(double) || typeof(T) == typeof(float))
					sb.Append($"{item,12:n3}");
				else
					sb.Append($"{item,5}");
			} 
			return sb.ToString();
		}


		public static string ToString<T>(Stack<T> stack)
		{
			if (!stack.Any())
			{
				return "Пустой стек";
			}
			StringBuilder sb = new StringBuilder("");
			foreach (var item in stack)
			{
				if (typeof(T) == typeof(double) || typeof(T) == typeof(float))
					sb.Append($"{item,12:n3}");
				else
					sb.Append($"{item,5}");
			}
			return sb.ToString();
		}


		public static string ToString<T>(List<T> list)
		{
			if (!list.Any()) 
			{
				return "Пустой список";
			}

			StringBuilder sb = new StringBuilder("");

			foreach (var item in list)
			{
				if (typeof(T) == typeof(double) || typeof(T) == typeof(float))
					sb.Append($"{item,12:n3}");
				else
					sb.Append($"{item,5}");
			}
			return sb.ToString();
		}
	}

}
