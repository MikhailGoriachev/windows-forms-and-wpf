﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel.Design;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HW16.Models
{
	class Task1
	{
		private const int lo = -50;
		private const int hi = 50;
		private const int nElements = 10;
		
		/*
		 * •	Дан непустой стек. Создать два новых стека, переместив в первый из них все элементы исходного стека с четными значениями,
		 * а во второй — с нечетными (элементы в новых стеках будут располагаться в порядке, обратном исходному; один из этих стеков может
		 * оказаться пустым). 
		 */
		public void Dynamic10()
		{
			Stack<int> stack = Collections.CreateStack(nElements, lo, hi);
			Stack<int> evens = new Stack<int>(nElements);
			Stack<int> odds = new Stack<int>(nElements);

			Console.WriteLine($"{Utilities.spaces}Сгенерированный стек: {Collections.ToString(stack)}\n\n");

			while (stack.Any())
			{
				int i = stack.Pop();
				if((i & 1) == 0)
					evens.Push(i);
				else odds.Push(i);
			}

			Console.WriteLine($"{Utilities.spaces}Исходный стек после обработки: {Collections.ToString(stack)}\n\n");
			Console.WriteLine($"{Utilities.spaces}Стек с четными числами: {Collections.ToString(evens)}\n\n");
			Console.WriteLine($"{Utilities.spaces}Стек с нечетными числами: {Collections.ToString(odds)}\n\n");
		}


		/*
		 * •	Dynamic24. Даны две непустые очереди, очереди содержат одинаковое количество элементов.
		 * Объединить очереди в одну, в которой элементы исходных очередей чередуются (начиная с первого элемента первой очереди)
		 */
		public void Dynamic24()
		{
			Queue<int> queue1 = Collections.CreateQueue(nElements, lo, hi);
			Queue<int> queue2 = Collections.CreateQueue(nElements, lo, hi);
			Queue<int> queueJoin = new Queue<int>(nElements);

			Console.WriteLine($"{Utilities.spaces}Сгенерированная очередь 1: {Collections.ToString(queue1)}\n\n");
			Console.WriteLine($"{Utilities.spaces}Сгенерированная очередь 2: {Collections.ToString(queue2)}\n\n");

			for (int i = 0; i < nElements * 2; i++)
			{
				int tmp;
				if ((i & 1) == 0)
					tmp = queue1.Dequeue();
				else tmp = queue2.Dequeue();

				queueJoin.Enqueue(tmp);
			}

			Console.WriteLine($"{Utilities.spaces}Результирующая очередь: {Collections.ToString(queueJoin)}\n\n");
		}


		/*
		 *•	Dynamic37. Дан непустой список. Продублировать в списке все элементы с нечетными номерами
		 * (новые элементы добавлять перед существующими элементами с такими же значениями)
		 */
		public void Dynamic37()
		{
			List<int> list = Collections.CreateList(nElements, lo, hi);

			Console.WriteLine($"{Utilities.spaces}Сгенерированный список: {Collections.ToString(list)}\n\n");

			for (int i = 0; i < nElements * 2; i++)
			{
				list.Insert(i, list[i++]);
			}

			Console.WriteLine($"{Utilities.spaces}Список после обработки: {Collections.ToString(list)}\n\n");
		}
	}
}