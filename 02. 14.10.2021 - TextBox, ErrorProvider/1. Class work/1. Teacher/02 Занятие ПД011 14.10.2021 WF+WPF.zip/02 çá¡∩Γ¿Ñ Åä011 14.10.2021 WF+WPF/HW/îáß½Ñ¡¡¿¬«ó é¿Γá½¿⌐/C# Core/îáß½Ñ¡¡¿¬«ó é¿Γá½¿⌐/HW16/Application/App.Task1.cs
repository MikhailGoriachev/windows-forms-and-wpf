﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using HW16.Models;

namespace HW16
{
	internal partial class App
	{
		private void Task1MenuItem1()
		{
			Utilities.ShowNavBar("Dynamic10", 2);

			string text =
				$"{Utilities.spaces}Дан непустой стек. Создать два новых стека, переместив в первый из них все элементы исходного стека с\n" +
				$"{Utilities.spaces}четными значениями, а во второй — с нечетными (элементы в новых стеках будут располагаться в порядке,\n" +
				$"{Utilities.spaces}обратном исходному; один из этих стеков может оказаться пустым). \n\n\n";

			Console.WriteLine(text);

			_task.Dynamic10();
		}

		private void Task1MenuItem2()
		{
			Utilities.ShowNavBar("Dynamic24",2);

			string text =
				$"{Utilities.spaces}Даны две непустые очереди, очереди содержат одинаковое количество элементов. Объединить очереди в одну,\n" +
				$"{Utilities.spaces}в которой элементы исходных очередей чередуются (начиная с первого элемента первой очереди)\n\n\n";

			Console.WriteLine(text);

			_task.Dynamic24();
		}

		private void Task1MenuItem3()
		{
			Utilities.ShowNavBar("Dynamic37", 2);

			string text =
				$"{Utilities.spaces}Дан непустой список. Продублировать в списке все элементы с нечетными номерами\n" +
				$"{Utilities.spaces}(новые элементы добавлять перед существующими элементами с такими же значениями)\n\n\n";

			Console.WriteLine(text);

			_task.Dynamic37();
		}
	}
}
