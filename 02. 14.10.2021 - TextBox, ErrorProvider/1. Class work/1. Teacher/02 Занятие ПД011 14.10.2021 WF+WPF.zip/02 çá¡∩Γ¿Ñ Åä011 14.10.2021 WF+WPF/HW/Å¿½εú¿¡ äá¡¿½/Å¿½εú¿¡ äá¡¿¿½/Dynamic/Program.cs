﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.Generic;

//извините за такое оформление, делал за пол часа до выхода


namespace Dynamic
{
    class Program
    {
        static void Main(string[] args)
        {
            App app = new App();
            app.Task1();
            app.Task2();
            app.Task3();
        }
    }
}
