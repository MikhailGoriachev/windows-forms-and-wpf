﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dynamic
{
    class App
    {
        private void Show(Stack<int> st)
        {
            if (st.Count == 0)
            {
                Console.WriteLine("Пусто!");
                return;
            }
            foreach (var item in st)
                Console.Write($"   {item}");
        }
        private void Show(Queue<int> st)
        {
            if (st.Count == 0)
            {
                Console.WriteLine("Пусто!");
                return;
            }
            foreach (var item in st)
                Console.Write($"   {item}");
        }
        private void Show(List<int> st)
        {
            if (st.Count == 0)
            {
                Console.WriteLine("Пусто!");
                return;
            }
            foreach (var item in st)
                Console.Write($"   {item}");
        }

        public void Task1()
        {
            Stack<int> stack1 = new Stack<int>(new[] { 1, 3, 4, 2, 5, 2, 4, 5 });
            Stack<int> stack2 = new Stack<int>();
            Stack<int> stack3 = new Stack<int>();


            Console.WriteLine("\t\tИсходный стэк");
            Show(stack1);
            Console.WriteLine("\n\n\t\tЧетный стек");
            Show(stack2);
            Console.WriteLine("\n\n\t\tНечетный стек");
            Show(stack3);

            foreach (var item in stack1)
            {
                if ((item & 1) == 0)
                    stack2.Push(item);
                else stack3.Push(item);
            }
            Console.WriteLine("____________________________________________________________");
            Console.WriteLine("\t\tИсходный стэк");
            Show(stack1);
            Console.WriteLine("\n\n\t\tЧетный стек");
            Show(stack2);
            Console.WriteLine("\n\n\t\tНечетный стек");
            Show(stack3);
            Console.WriteLine();
            Console.ReadKey();
            Console.Clear();
        }
        public void Task2()
        {
            Queue<int> queue1 = new Queue<int>(new[] { 1, 3, 4, 2, 5, 2, 4, 5 });
            Queue<int> queue2 = new Queue<int>(new[] { 1, 3, 4, 2, 5, 2, 4, 5 });
            Queue<int> queue3 = new Queue<int>();

            Console.WriteLine("\t\tqueue1");
            Show(queue1);
            Console.WriteLine("\n\n\t\tqueue2");
            Show(queue2);

            int n = queue1.Count;
            for (int i = 0; i < n; i++)
            {
                queue3.Enqueue(queue1.Dequeue());
                queue3.Enqueue(queue2.Dequeue());
            }
            
            

            Console.WriteLine("\n\n\t\tqueue3");
            Show(queue3);

            Console.ReadKey();
            Console.Clear();
        }
        public void Task3()
        {
            List<int> list = new List<int>(new int[] { 1, 4, 3, 7, 4, 8, 4, 6, 2, 4 });
            Console.WriteLine("\t\t\tList до обработки");
            Show(list);

            for (int i = 0; i < list.Count; i++)
            {
                
                    list.Insert(i, list[i]);
                    i += 2;
            }

            Console.WriteLine("\n\t\t\tList после обработки");
            Show(list);
            Console.WriteLine();

        }


    }
}
