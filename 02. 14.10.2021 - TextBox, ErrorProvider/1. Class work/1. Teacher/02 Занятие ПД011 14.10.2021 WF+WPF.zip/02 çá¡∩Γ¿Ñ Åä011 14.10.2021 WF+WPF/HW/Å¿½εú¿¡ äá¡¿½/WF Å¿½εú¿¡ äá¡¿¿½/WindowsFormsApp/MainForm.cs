﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void BtnHallo_Click(object sender, EventArgs e)
        {
            Lbl.TextAlign = ContentAlignment.MiddleCenter;
            Lbl.Text = "Привет, Windows Forms";
            Tmr.Enabled = true;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string str = 
            "                            ,%%%,\n" +
            "                         ,%%%`    %== --\n" +
            "                        ,%%` (     '|\n"       +
            "                     ,%%@   /\\_ /\n"    +
            "     ,%.%%%% \"@@__\n"  +
            "  %%/                   __   \\\n"  +
            ".% '  \\     |   \\     /     //\n"    +
            ",% '  ,>   /'-----\\ |    [/\n"     +
            "     <` <`          ||\n"         +
            "       `\\\\          ||\n"         +
            "          | \\       | \\\n" +
            "^^^^^\"\"\"\"^^^^\"\"\"\"^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\"";
            Lbl.TextAlign = ContentAlignment.TopLeft;
            Lbl.Text = str;
            Tmr.Enabled = true;

        }

        private void Tmr_Tick(object sender, EventArgs e)
        {
            Lbl.Text = "";
            Tmr.Enabled = false;
        }
    }
}
