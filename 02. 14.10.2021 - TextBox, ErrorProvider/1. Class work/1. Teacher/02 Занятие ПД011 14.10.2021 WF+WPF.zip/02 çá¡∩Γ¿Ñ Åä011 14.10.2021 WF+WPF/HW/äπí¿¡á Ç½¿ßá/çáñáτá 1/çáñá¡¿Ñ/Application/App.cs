﻿using System;
using System.Collections.Generic;                // необобщенные коллекции - т.е. коллекции для типа object
using System.Linq;
using System.Text;
using System.Threading;
using Задание.Helpers;

namespace Задание.Application
{

    // Класс приложения - обработка по заданию
    internal partial class App {
        

        // Дан непустой стек. Создать два новых стека, переместив в первый из них все
        // элементы исходного стека с четными значениями, а во второй — с нечетными
        // (элементы в новых стеках будут располагаться в порядке, обратном исходному
        // один из этих стеков может оказаться пустым). 
        public void Dynamic10() {
            Utils.ShowNavBarTask("   Из исходного стека переместить четные элементы в первый стек, а нечетные - во второй");
            int n = Utils.Random.Next(5, 15); // размер стека
            Predicate<int> isEven = a => (a & 1) == 0;
            Stack<int> st   = new Stack<int>(Fill(n));
            Stack<int> odd  = new Stack<int>();
            Stack<int> even = new Stack<int>();

            Utils.WriteXY(12, 3, "Стеки до обработки:", ConsoleColor.Yellow);

            Show("Исходный стек:", 12, st, isEven);
            Show("Стек с четными значениями:", 12, even, isEven);
            Show("Стек с нечетными значениями:", 12, odd, isEven);

            while(st.Count > 0) {
                int item = st.Pop();
                if (isEven(item)) even.Push(item);
                else odd.Push(item);
            } // while


            Utils.WriteXY(12, Console.CursorTop + 1, "Стеки после обработки:", ConsoleColor.Yellow);
            Show("Исходный стек:", 12, st, a => (a & 1) == 0);
            Show("Стек с четными значениями:", 12, even, a => (a & 1) == 0);
            Show("Стек с нечетными значениями:", 12, odd, a => (a & 1) == 0);

        } // Dynamic10

        // Даны две непустые очереди, очереди содержат одинаковое количество элементов.
        // Объединить очереди в одну, в которой элементы исходных очередей чередуются
        // (начиная с первого элемента первой очереди)
        public void Dynamic24() {
            Utils.ShowNavBarTask("   Объединить очереди в одну, в которой элементы исходных очередей чередуются");
            int n = Utils.Random.Next(5, 15); // размер очередей

            Queue<int> qFirst  = new Queue<int>(Fill(n));
            Queue<int> qSecond = new Queue<int>(Fill(n));
            Queue<int> q = new Queue<int>();

            Show("Первая очередь:", 12, qFirst);
            Show("Вторая очередь:", 12, qSecond);

            while (qFirst.Count > 0 && qSecond.Count > 0) {
                q.Enqueue(qFirst.Dequeue());
                q.Enqueue(qSecond.Dequeue());
            } // while
            Show("Сфрормированная очередь:", 12, q);

        } // Dynamic24

        // Дан непустой список. Продублировать в списке все элементы с нечетными номерами
        // (новые элементы добавлять перед существующими элементами с такими же значениями)
        public void Dynamic37() {
            Utils.ShowNavBarTask("   Продублировать в списке все элементы с нечетными номерами");
            int n = Utils.Random.Next(5, 15); // размер спискa

            LinkedList<int> list = new LinkedList<int>(Fill(n));
            LinkedList<int> temp = new LinkedList<int>();

            bool isEvenNum = false;
            Show("Список до обработки:", 12, list, a => { isEvenNum = !isEvenNum; return isEvenNum; });

            int i = 1; // номер элемента
            foreach(int item in list) {
                temp.AddLast(item);
                if((i & 1)!= 0) temp.AddLast(item);
                i++;
            } // foreach

            list = temp;

            Show("Список после обработки:", 12, list);

        } // Dynamic37

        // генерация массива для инициализации коллекций
        private static int[] Fill(int n, int lo = -10, int hi = 10) {
            int[] temp = new int[n];
            for (int i = 0; i < n; i++) temp[i] = Utils.Random.Next(lo, hi + 1);
            return temp;
        } // Fill

        private static void Show<T>(string title, int indent, IEnumerable<T> arr) =>
            Show(title, indent, arr, a => false);

        // вывод коллекций
        private static void Show<T>(string title, int indent, IEnumerable<T> arr, Predicate<T> predicate, ConsoleColor color = ConsoleColor.Yellow){
            Utils.SaveColor();
            string spaces = " ".PadRight(indent);
            Console.Write($"\n\n{spaces}{title}\n{spaces}");

            // счетчик выведенных элементов
            int elemCounter = 0;

            foreach (var item in arr){
                if (predicate(item)) Utils.SetColor(color, Console.BackgroundColor);
                Console.Write($"{item,8}");
                Utils.RestoreColor();
                // принудительный переход на новую строку 
                if (++elemCounter == 10){
                    Console.Write($"\n{spaces}");
                    elemCounter = 0;
                } // if
            } // foreach

            Console.WriteLine();
        } // Show
    } // class App
}