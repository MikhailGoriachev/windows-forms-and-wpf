﻿
namespace Задание
{
    partial class MainForm
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.LblFirst = new System.Windows.Forms.Label();
            this.BtnDrawing = new System.Windows.Forms.Button();
            this.BtnQuit = new System.Windows.Forms.Button();
            this.BtnGreeting = new System.Windows.Forms.Button();
            this.TmrFirst = new System.Windows.Forms.Timer(this.components);
            this.SuspendLayout();
            // 
            // LblFirst
            // 
            this.LblFirst.BackColor = System.Drawing.Color.LavenderBlush;
            this.LblFirst.Font = new System.Drawing.Font("Consolas", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblFirst.Location = new System.Drawing.Point(31, 20);
            this.LblFirst.Name = "LblFirst";
            this.LblFirst.Size = new System.Drawing.Size(741, 364);
            this.LblFirst.TabIndex = 0;
            this.LblFirst.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // BtnDrawing
            // 
            this.BtnDrawing.BackColor = System.Drawing.Color.LightSkyBlue;
            this.BtnDrawing.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BtnDrawing.Location = new System.Drawing.Point(31, 400);
            this.BtnDrawing.Name = "BtnDrawing";
            this.BtnDrawing.Size = new System.Drawing.Size(184, 38);
            this.BtnDrawing.TabIndex = 1;
            this.BtnDrawing.Text = "Рисунок";
            this.BtnDrawing.UseVisualStyleBackColor = false;
            this.BtnDrawing.Click += new System.EventHandler(this.BtnDrawing_Click);
            // 
            // BtnQuit
            // 
            this.BtnQuit.BackColor = System.Drawing.Color.LightCoral;
            this.BtnQuit.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BtnQuit.Location = new System.Drawing.Point(588, 400);
            this.BtnQuit.Name = "BtnQuit";
            this.BtnQuit.Size = new System.Drawing.Size(184, 38);
            this.BtnQuit.TabIndex = 2;
            this.BtnQuit.Text = "Выход";
            this.BtnQuit.UseVisualStyleBackColor = false;
            this.BtnQuit.Click += new System.EventHandler(this.BtnQuit_Click);
            // 
            // BtnGreeting
            // 
            this.BtnGreeting.BackColor = System.Drawing.Color.LightSkyBlue;
            this.BtnGreeting.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BtnGreeting.Location = new System.Drawing.Point(305, 400);
            this.BtnGreeting.Name = "BtnGreeting";
            this.BtnGreeting.Size = new System.Drawing.Size(184, 38);
            this.BtnGreeting.TabIndex = 3;
            this.BtnGreeting.Text = "Приветствие";
            this.BtnGreeting.UseVisualStyleBackColor = false;
            this.BtnGreeting.Click += new System.EventHandler(this.BtnGreeting_Click);
            // 
            // TmrFirst
            // 
            this.TmrFirst.Interval = 5000;
            this.TmrFirst.Tick += new System.EventHandler(this.TmrFirst_Tick);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Thistle;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.BtnGreeting);
            this.Controls.Add(this.BtnQuit);
            this.Controls.Add(this.BtnDrawing);
            this.Controls.Add(this.LblFirst);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Задание на 13.11.2021";
            this.TransparencyKey = System.Drawing.Color.White;
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label LblFirst;
        private System.Windows.Forms.Button BtnDrawing;
        private System.Windows.Forms.Button BtnQuit;
        private System.Windows.Forms.Button BtnGreeting;
        private System.Windows.Forms.Timer TmrFirst;
    }
}

