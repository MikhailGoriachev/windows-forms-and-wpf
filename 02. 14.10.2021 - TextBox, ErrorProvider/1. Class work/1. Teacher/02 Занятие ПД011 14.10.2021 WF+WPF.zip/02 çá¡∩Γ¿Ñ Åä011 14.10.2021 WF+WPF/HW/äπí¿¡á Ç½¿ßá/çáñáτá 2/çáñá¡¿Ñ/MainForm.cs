﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Задание
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }


        private void BtnQuit_Click(object sender, EventArgs e) => Application.Exit();

        private void BtnGreeting_Click(object sender, EventArgs e) {
            LblFirst.Text = "Привет, Windows Forms";
            TmrFirst.Enabled = true;
        } // BtnGreeting_Click

        private void BtnDrawing_Click(object sender, EventArgs e) {
            string str = @"                       ,%%%,                               " + "\n" +
                         @"                    ,%%%` %==--                            " + "\n" +
                         @"                   ,%%`( '|                                " + "\n" +
                         @"                  ,%%@ /\_/                                " + "\n" +
                         @"    ,%.-""""""--%%% ""@@__                             " + "\n" +
                         @"       %%/             |__`\                               " + "\n" +
                         @"      .%'\     |   \   /  //                               " + "\n" +
                         @"      ,%' >   .'----\ |  [/                                " + "\n" +
                         @"         < <<`       ||                                    " + "\n" +
                         @"          `\\\       ||                                    " + "\n" +
                         @"            )\\      )\                                    " + "\n" +
                         @" ^^^^^^^^""""""^^^^^^""""^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^";
            LblFirst.Text = str;
            TmrFirst.Enabled = true;
        } // BtnDrawing_Click

        private void TmrFirst_Tick(object sender, EventArgs e) {
            LblFirst.Text = "";
            TmrFirst.Enabled = false;
        } // TmrFirst_Tick
    }
}
