﻿
namespace HomeWork13._10._21
{
    partial class HomeWork
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.BtnGreeting = new System.Windows.Forms.Button();
            this.BtnDrawing = new System.Windows.Forms.Button();
            this.BtnQuit = new System.Windows.Forms.Button();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.label2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // BtnGreeting
            // 
            this.BtnGreeting.Font = new System.Drawing.Font("Consolas", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BtnGreeting.Location = new System.Drawing.Point(391, 348);
            this.BtnGreeting.Name = "BtnGreeting";
            this.BtnGreeting.Size = new System.Drawing.Size(160, 39);
            this.BtnGreeting.TabIndex = 0;
            this.BtnGreeting.Text = "Приветствие";
            this.BtnGreeting.UseVisualStyleBackColor = true;
            this.BtnGreeting.Click += new System.EventHandler(this.BtnGreeting_Click);
            // 
            // BtnDrawing
            // 
            this.BtnDrawing.Font = new System.Drawing.Font("Consolas", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BtnDrawing.Location = new System.Drawing.Point(164, 348);
            this.BtnDrawing.Name = "BtnDrawing";
            this.BtnDrawing.Size = new System.Drawing.Size(160, 39);
            this.BtnDrawing.TabIndex = 1;
            this.BtnDrawing.Text = "Рисунок";
            this.BtnDrawing.UseVisualStyleBackColor = true;
            this.BtnDrawing.Click += new System.EventHandler(this.BtnDrawing_Click);
            // 
            // BtnQuit
            // 
            this.BtnQuit.Font = new System.Drawing.Font("Consolas", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BtnQuit.Location = new System.Drawing.Point(619, 348);
            this.BtnQuit.Name = "BtnQuit";
            this.BtnQuit.Size = new System.Drawing.Size(160, 39);
            this.BtnQuit.TabIndex = 2;
            this.BtnQuit.Text = "Выход";
            this.BtnQuit.UseVisualStyleBackColor = true;
            this.BtnQuit.Click += new System.EventHandler(this.BtnQuit_Click);
            // 
            // timer1
            // 
            this.timer1.Interval = 5000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.SystemColors.Info;
            this.label2.Font = new System.Drawing.Font("Consolas", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(164, 54);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(615, 263);
            this.label2.TabIndex = 3;
            // 
            // HomeWork
            // 
            this.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.ClientSize = new System.Drawing.Size(937, 426);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.BtnQuit);
            this.Controls.Add(this.BtnDrawing);
            this.Controls.Add(this.BtnGreeting);
            this.Name = "HomeWork";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnPrint;
        private System.Windows.Forms.Button btnHello;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Timer tmrFirst;
        private System.Windows.Forms.Button BtnGreeting;
        private System.Windows.Forms.Button BtnDrawing;
        private System.Windows.Forms.Button BtnQuit;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label label2;
    }
}

