﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HomeWork13._10._21
{
    public partial class HomeWork : Form
    {
        public HomeWork()
        {
            InitializeComponent();
        }

        private void BtnDrawing_Click(object sender, EventArgs e)
        {
            label2.TextAlign = ContentAlignment.TopLeft;
            label2.Font = new Font("Consolas",  12);
            string str = @"                                                            " + "\n" +
                         @"                  ,%%%,                                     " + "\n" +
                         @"                 ,%%%` %== --                               " + "\n" +
                         @"                ,%%`( '|                                    " + "\n" +
                         @"               ,%%@ /\_/                                    " + "\n" +
                         @"     ,%.- """"""-- %%% ""@@__                                   " + "\n" +
                         @"     %%/             | __`\                                 " + "\n" +
                         @"    .% '\     |   \   /  //                                 " + "\n" +
                         @"    ,% ' >   .'----\ |  [/                                  " + "\n" +
                         @"        < <<`       ||                                      " + "\n" +
                         @"         `\\\       ||                                      " + "\n" +
                         @"           )\\      )\                                      " + "\n" +
                         @"^^^^^^^^"""""" ^ ^^^^^"""" ^ ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^" + "\n";
            label2.Text = str;
            timer1.Enabled = true;









        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            label2.Text = "";
            timer1.Enabled = false;
        }

        private void BtnGreeting_Click(object sender, EventArgs e)
        {
            label2.Font = new Font("Calibri", 20);
            label2.Text = "Привет, Windows Forms";
            label2.TextAlign= ContentAlignment.MiddleCenter;
            timer1.Enabled = true;

        }

        private void BtnQuit_Click(object sender, EventArgs e) => Application.Exit();
        
    }
}
