﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using HomeWork13._10._21.Controllers;

namespace HomeWork13._10._21.Application
{
    internal partial class App
    {
        // инициализация стека случайными значениями в заданном количестве
        public void DemoTask1()
        {
            Task1Control.DemoTask1(_stackInt);
            
        }

        public void DemoTask2()
        {

            Task2Control.DemoTask2(_queueInt1, _queueInt2);



        }

        public void DemoTask3()
        {

            Task3Control.DemoTask3(_listInt);



        }


    }
}
