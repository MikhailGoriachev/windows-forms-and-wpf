﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HomeWork13._10._21.Controllers
{
    class Task3Control
    {
        // инициализация списка случайными значениями в заданном количестве
        public static void InitList(List<int> list, int n, int lo, int hi)
        {
            for (int i = 0; i < n; i++)
            {
                list.Add(Utils.GetRandom(lo, hi));
            }
        }

        // метод для выполнения задания Dynamic37
        public static void EditList(List<int> list)
        {
            
            for (int i = 0, j=0, end = list.Count(); i < end; i++,j++)
            {
                if((i & 1) != 0){
                    list.Insert(list.IndexOf(list[j]) , list[j++]);
                    
                }               

            }
            
        }


        // метод для вывода очереди 
        public static void ShowList(List<int> list, string tittle, (int x, int y) startPosition)
        {
            // сохранить цвет фона

            Console.SetCursorPosition(startPosition.x, startPosition.y++);
            Console.WriteLine($"{tittle}");
            Console.SetCursorPosition(startPosition.x, startPosition.y++);
            Console.WriteLine(" ".PadRight(tittle.Length / 2 - 4) + "┌────────┐");


            for (int i = 0; i < list.Count() ; i++)
            {
                Console.SetCursorPosition(startPosition.x, startPosition.y++);
                Console.WriteLine($" ".PadRight(tittle.Length / 2 - 4) + $"│ { list[i],6} │");
            }

            Console.SetCursorPosition(startPosition.x, startPosition.y++);
            Console.WriteLine(" ".PadRight(tittle.Length / 2 - 4) + "└────────┘");


        }


        public static void DemoTask3(List<int> list)
        {
            (ConsoleColor oldBg, ConsoleColor oldFg) = (Console.BackgroundColor, Console.ForegroundColor);


            Console.WriteLine($"\n\tОбработка списка");

            Task3Control.InitList(list, Utils.GetRandom(10, 20), -20, 20);      

            Task3Control.ShowList(list, "Исходный список", (5, 5));

            Task3Control.EditList(list);

            Task3Control.ShowList(list, "Результирующий список", (45, 5));


        }
    }
}
