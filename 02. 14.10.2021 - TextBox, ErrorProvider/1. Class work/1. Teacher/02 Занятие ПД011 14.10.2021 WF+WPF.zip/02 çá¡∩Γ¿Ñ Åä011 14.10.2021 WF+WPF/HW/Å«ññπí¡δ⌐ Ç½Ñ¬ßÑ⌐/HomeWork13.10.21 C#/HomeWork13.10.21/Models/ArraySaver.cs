﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HomeWork13._10._21.Models
{
    class ArraySaver<T>
        where T : IComparable<T>, new()//, IComparer<T>, new()
    {
        // контейнер для массива
        private T[] _array;
        public T[] ArrayT
        {
            get { return _array; }
            private set { _array = value; }
        }

        public ArraySaver() : this(10) { }
        public ArraySaver(int n)
        {
            _array = new T[n];
            // Заполнение массива значениями по умолчанию для типа T
            for (int i = 0; i < _array.Length; i++) _array[i] = new T();
        } // Vector

        public int Length => _array.Length;


        // Индексатор
        public T this[int index]
        {
            get => _array[index];
            set => _array[index] = value;
        } // this


        // Вывод массива
        public void Show(string title) =>
            Console.Write($"{title}\n{this}");


        //// Заполнение массива случайными величинами
        // public void Fill(T low, T high)
        // {
        //     for (int i = 0; i < _array.Length; i++)
        //     {
        //         _array[i] = Utils.GetRandom(low, high);
        //     } // for i

        // } // Fill

        // вычисление количества максимальных элементов массива (для массива персон по параматру Salary)
        public int CountMaxElem()
        {

            int res = 0;
            T max = FindMax();
            for (int i = 0; i < _array.Length; i++)
            {
                if (_array[i].CompareTo(max) == 0) res++;

            } // for i

            return res;
        }

        // Поиск  максимального элемента массива(для массива персон по параматру Salary)
        public T FindMax()
        {
            T max = _array[0];
            for (int i = 1; i < _array.Length; i++)
            {
                if (_array[i].CompareTo(max) > 0) max = _array[i];

            } // for i

            return max;
        } // FindMinMax


        // сортировка массива  (для массива персон сортировка по параматру Age)
        public void Sort()
        {
            Array.Sort(_array, CompareTo);

        }




        // Вывод массива в строку
        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendLine(Header());

            for (int i = 0; i < _array.Length; i++)
            {

                sb.AppendLine($"│ {i + 1,-3} │ {_array[i],60} │");

            } // for i

            sb.AppendLine(Footer());


            return sb.ToString();
        } // ToString


        public static string Header()
        {

            return $"┌─────┬──────────────────────────────────────────────────────────────┐\n" +
                   $"│  №  │ Значение                                                     │\n" +
                   $"├─────┼──────────────────────────────────────────────────────────────┤";   //60

        }

        public static string Footer() =>
             $"└─────┴──────────────────────────────────────────────────────────────┘";


        //// это будет компратор для возрастра(для класса Person)
        //public int Compare(T x, T y)
        //{
        //    return x.Compare(x, y);
        //}

        // это будет компратор для зарплаты(для класса Person)
        public int CompareTo(T t1, T t2)
        {
            return t1.CompareTo(t2);

        }



        public void Initialize(T lo, T hi, Func<T, T, T> generator)
        {
            for (int i = 0; i < _array.Length; i++)
            {
                _array[i] = generator(lo, hi);
            }

        }

        public void Initialize(Func<T> generator)
        {
            for (int i = 0; i < _array.Length; i++)
            {
                _array[i] = generator();
            }
        }


















    }


}
