﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HomeWork13._10._21.Controllers
{
    class Task2Control
    {
        // инициализация очереди случайными значениями в заданном количестве
        public static void InitQueue(Queue<int> queue, int n, int lo, int hi)
        {
            for (int i = 0; i < n; i++)
            {
                queue.Enqueue(Utils.GetRandom(lo, hi));
            }
        }

        // метод для создания очереди с заполнением чередующимися элементами
        public static Queue<int> UnionQueue(Queue<int> queue1, Queue<int> queue2)
        {
            Queue<int> result = new Queue<int>();
            

            for (int i=0; queue1.Count()>0 || queue2.Count() > 0 ;i++)
            {
                // если елементы есть в обоих очередях
                if (queue1.Count() > 0 && queue2.Count() > 0)
                {

                    if ((i & 1) == 0)
                        result.Enqueue(queue1.Dequeue());
                    else
                        result.Enqueue(queue2.Dequeue());

                }
                else if (queue1.Count() > 0 && queue2.Count() == 0)//если елементы есть только в первой очереди
                {
                    result.Enqueue(queue1.Dequeue());
                }
                else if (queue2.Count() > 0 && queue1.Count() == 0) //если елементы есть только во второй очереди
                {
                    result.Enqueue(queue2.Dequeue());
                }




            }

            return (result);
        }


        // метод для вывода очереди 
        public static void ShowQueue(Queue<int> queue, string tittle, (int x, int y) startPosition)
        {
            // сохранить цвет фона
            
            Console.SetCursorPosition(startPosition.x, startPosition.y++);
            Console.WriteLine($"{tittle}");
            Console.SetCursorPosition(startPosition.x, startPosition.y++);
            Console.WriteLine(" ".PadRight(tittle.Length / 2 - 4) + "┌────────┐");


            for (int i = 0; queue.Count() > 0; i++)
            {

                
                    Console.SetCursorPosition(startPosition.x, startPosition.y++);
                    Console.WriteLine($" ".PadRight(tittle.Length / 2 - 4) + $"│ { queue.Dequeue(),6} │"); 
            }

            Console.SetCursorPosition(startPosition.x, startPosition.y++);
            Console.WriteLine(" ".PadRight(tittle.Length / 2 - 4) + "└────────┘");


        }


        public static void DemoTask2(Queue<int> queue1, Queue<int> queue2)
        {
            (ConsoleColor oldBg, ConsoleColor oldFg) = (Console.BackgroundColor, Console.ForegroundColor);


            Console.WriteLine($"\n\tОбработка очередей");


            Task2Control.InitQueue(queue1, Utils.GetRandom(10, 20), -20,-10);
            Task2Control.InitQueue(queue2, Utils.GetRandom(10, 20), 10,20);


            Queue<int> queue1Copy = new Queue<int>(queue1);
            Queue<int> queue2Copy = new Queue<int>(queue2);

            Task2Control.ShowQueue(queue1Copy, "Очередь 1", (5, 5));
            Task2Control.ShowQueue(queue2Copy, "Очередь 2", (25, 5));

            Queue<int> result = Task2Control.UnionQueue(queue1, queue2);
            Task2Control.ShowQueue(result, "Результирующая очередь", (45, 5));


        }
    }
}
