﻿using HomeWork13._10._21.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HomeWork13._10._21.Controllers
{
    class Task1Control
    {
        // инициализация стека случайными значениями в заданном количестве
        public static void InitStack(Stack<int> stack, int n)
        {
            for (int i = 0; i < n; i++)
            {
                stack.Push(Utils.GetRandom(1, 20));
            }
        }

        // метод для создания стека четных и нечетных чисел
        public static (Stack<int> evenStack, Stack<int> oddStack) SortEvenOddStack(Stack<int> stack)
        {
            Stack<int> evenStack = new Stack<int>();
            Stack<int> oddStack = new Stack<int>();

            for (int i = 0; i < stack.Count; )
            {
                // если число четное, то положить в стек четных числе, если нет то в стек нечетных
                if ((stack.Peek() & 1) == 0)
                    evenStack.Push(stack.Pop());
                else
                    oddStack.Push(stack.Pop());
            }

            return (evenStack, oddStack);
        }


        // метод для вывода стека с подсветкой четных и нечетных чисел
        public static void ShowColorStack(Stack<int> stack, string tittle, (int x,int y) startPosition)
        {
            // сохранить цвет фона
            (ConsoleColor oldBg, ConsoleColor oldFg) = (Console.BackgroundColor, Console.ForegroundColor);
            Console.WriteLine();
            Console.SetCursorPosition(startPosition.x, startPosition.y++);
            Console.WriteLine($"{tittle}");
            Console.SetCursorPosition(startPosition.x, startPosition.y++);
            Console.WriteLine(" ".PadRight(tittle.Length/2 - 4) + "┌────────┐");


            for (int i = 0; i < stack.Count; )
            {

                // если число четное, то вывести в зеленом цвете, если нет то в красном
                if ((stack.Peek() & 1) == 0)
                {
                    Console.SetCursorPosition(startPosition.x, startPosition.y++);
                    Console.Write($" ".PadRight(tittle.Length / 2-4) + "│ ");
                    (Console.BackgroundColor, Console.ForegroundColor) = (ConsoleColor.DarkGreen, ConsoleColor.Cyan);
                    Console.Write($"{ stack.Pop(),6}");
                    (Console.BackgroundColor, Console.ForegroundColor) = (oldBg, oldFg);
                    Console.Write($" │\n"); 
                }
                else
                {
                    Console.SetCursorPosition(startPosition.x, startPosition.y++);
                    Console.Write($" ".PadRight(tittle.Length / 2 - 4) + "│ ");
                    (Console.BackgroundColor, Console.ForegroundColor) = (ConsoleColor.Magenta, ConsoleColor.Yellow);
                    Console.Write($"{ stack.Pop(),6}");
                    (Console.BackgroundColor, Console.ForegroundColor) = (oldBg, oldFg);
                    Console.Write($" │\n");


                }
                    


            }

            Console.SetCursorPosition(startPosition.x, startPosition.y++);
            Console.WriteLine(" ".PadRight(tittle.Length / 2-4) + "└────────┘");


        }


        public static void DemoTask1(Stack<int> stack)
        {
            (ConsoleColor oldBg, ConsoleColor oldFg) = (Console.BackgroundColor, Console.ForegroundColor);

            Console.Write("\n\tЧисла в стеках выведены: ");
            (Console.BackgroundColor, Console.ForegroundColor) = (ConsoleColor.DarkGreen, ConsoleColor.Cyan);
            Console.Write(" четные ");
            (Console.BackgroundColor, Console.ForegroundColor) = (oldBg, oldFg);
            Console.Write(" , ");
            (Console.BackgroundColor, Console.ForegroundColor) = (ConsoleColor.Magenta, ConsoleColor.Yellow);
            Console.Write(" нечетные ");
            (Console.BackgroundColor, Console.ForegroundColor) = (oldBg, oldFg);
            Console.WriteLine();

            

            Task1Control.InitStack(stack, 10);
            Stack<int> stackCopy = new Stack<int>(stack);

            Task1Control.ShowColorStack(stackCopy, "Начальный стек",(5,5));

            (Stack<int> evenStack, Stack<int> oddStack) = SortEvenOddStack(stack);
            Task1Control.ShowColorStack(evenStack, "Стек четных чисел", (25, 5));
            Task1Control.ShowColorStack(oddStack, "Стек нечетных чисел", (45, 5));



        }


    }
}
