﻿using HomeWork13._10._21.Controllers;
using HomeWork13._10._21.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace HomeWork13._10._21.Application
{
    internal partial class App
    {
        
        private Stack<int> _stackInt;
        private Queue<int> _queueInt1;
        private Queue<int> _queueInt2;
        private List<int> _listInt;



        //  конструктор
        public App() 
        {
            _stackInt = new Stack<int>();
            _queueInt1 = new Queue<int>();
            _queueInt2 = new Queue<int>();
            _listInt = new List<int>();

        } // App

        

    }
}
