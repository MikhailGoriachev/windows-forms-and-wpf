﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace dz13._10
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string str =    @"                   ,%%%,                              " +"\n" + 
                            @"                  ,%%%` %== --                        " +"\n" +
                            @"                 ,%%`('|                              " +"\n" +
                            @"                ,%%@/\_/                              " +"\n" +
                            @"    ,%.- """"--%%% ""@@__                             " +"\n" +
                            @"    %%/             | __`\                            " +"\n" +
                            @"  .% '\     |   \   /  //                             " +"\n" +
                            @"  ,% ' >   .'----\ |  [/                              " +"\n" +
                            @"      < <<`       ||                                  " +"\n" +
                            @"       `\\\       ||                                  " +"\n" +
                            @"         )\\      )\                                  " +"\n" +
                            @"^^^^^^^^^""""""^^^^^^""""^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^";

            label2.Text = str;
            tmrFirst.Enabled = true;
        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }
        private void tmrFirst_Tick(object sender, EventArgs e)
        {
            label2.Text = "";
            label3.Text = "";
            tmrFirst.Enabled = false;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string str = @"Привет, Windows Forms";
            label3.Text = str;
            tmrFirst.Enabled = true;
        }

        private void label3_Click_1(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e) => Application.Exit();

    }
}
