﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using C_Sharp_.NET_Framework__15___Generic_Collection_.Application;


namespace C_Sharp_.NET_Framework__15___Generic_Collection_
{
    class Program
    {
        static void Main(string[] args)
        {

            App app = new App();
            Console.SetWindowSize(130, 35);
            while (true)
            {
                try
                {

                    int y;
                    int x = 17;
                    int choi;
                    bool flu = true;

                    string sep1 = "<|-----------------------------------------------|>";
                    string[] items = {
                        "<|                       MENU                    |>",
                        "<|   №   >|<             Задания                 |>",
                        "<|   1   >|<              Задача 1               |>",
                        "<|   2   >|<              Задача 2               |>",
                        "<|   3   >|<              Задача 3               |>",
                        "<|   0   >|<               EXIT                  |>"
                    };
                    do
                    {
                        y = 4;
                        if (!flu) Console.Clear();
                        
                        Array.ForEach(items, item => {
                            Utils.WriteXY(x, y++, sep1, ConsoleColor.Black, ConsoleColor.White);
                            Utils.WriteXY(x, y++, item, ConsoleColor.Black, ConsoleColor.White);
                        });
                        Utils.WriteXY(x, y++, sep1, ConsoleColor.Black, ConsoleColor.White);

                        Console.CursorVisible = false;

                        Console.Write("\n\n\t    Введите пункт: ");

                        choi = 0;
                        flu = int.TryParse(Console.ReadLine(), out choi);

                    } while (!flu);
                    Console.Clear();
                    Console.CursorVisible = true;

                    switch (choi)
                    {
                        // ------------Демонстрация работы над типизированными классами(Stack,Queue,List)<int>-----------
                        case 1: app.task1();    break;   // Демонстрация работы над типизированной коллекцией Stack
                        case 2: app.task2();    break;  //  Демонстрация работы над типизированной коллекцией Queue
                        case 3: app.task3();    break; //   Демонстрация работы над типизированной коллекцией List


                        case 0: Console.Write("\n\n\tДо свидания\n"); return;
                    } // switch

                } // try
                
                catch (Exception ex)
                {
                    Console.Clear();
                    Utils.WriteXY(45, 15, "**********************************************", ConsoleColor.White, ConsoleColor.Red);

                    Utils.WriteXY(45, 16, "*", ConsoleColor.White, ConsoleColor.Red);
                    Utils.WriteXY(46, 16, "                    Error                    ", ConsoleColor.DarkRed);
                    Utils.WriteXY(90, 16, "*", ConsoleColor.White, ConsoleColor.Red);

                    Utils.WriteXY(45, 17, "*", ConsoleColor.White, ConsoleColor.Red);
                    Utils.WriteXY(46, 17, "  " + ex.Message, ConsoleColor.Red);
                    Utils.WriteXY(90, 17, "*", ConsoleColor.White, ConsoleColor.Red);

                    Utils.WriteXY(45, 18, "**********************************************", ConsoleColor.White, ConsoleColor.Red);
                } // try-catch
            
                Console.ReadKey(false);
                Console.Clear();
            }// while
 
        } // Main

    } // Program
} // C_Sharp_.NET_Framework__10___Abstract_
