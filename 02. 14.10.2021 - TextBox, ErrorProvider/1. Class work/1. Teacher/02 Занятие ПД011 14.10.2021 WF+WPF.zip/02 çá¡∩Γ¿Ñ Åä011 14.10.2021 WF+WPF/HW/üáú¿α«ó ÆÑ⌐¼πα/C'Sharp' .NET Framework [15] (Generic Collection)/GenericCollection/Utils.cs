﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace C_Sharp_.NET_Framework__15___Generic_Collection_
{
    // вспомогательные методы и объекты - статический класс, т.е. класс,
    // содержащий только статические члены и методы
    public static class Utils
    {
        // объект для получения случайных чисел
        public static Random random = new Random();

        // Обобщенный метод для формирования случайного числа
        public static T GetRandom<T>(T min, T max) where T : struct
        {
            // значение по умолчанию для заданного типа
            T rand = default(T);

            // генерация случайного числа, в зависимости от типа T
            // обратите внимание на двойное приведение типов 
            if (typeof(T) == typeof(int))            // для int
                rand = (T)(object)(random.Next((int)(object)min, (int)(object)max + 1));
            else if (typeof(T) == typeof(double))   // для double
                rand = (T)(object)((double)(object)min + ((double)(object)max - (double)(object)min) * random.NextDouble());
            else                                    // для остальных типов
                rand = (T)(object)random.Next();
            return rand;
        } // GetRandom

        // формирование случайных логических значений (true или false)
        public static bool GetTrueOrFalse()
             => GetRandom(0, 1)==1?true:false;


        // создание стека из size элементов, заполнение ее 
        // случайными числами в диапазоне значаений от from 
        // до to
        public static Stack<T> CreateStack<T>(int size, T from, T to) where T : struct
        {
            Stack<T> stack = new Stack<T>();

            for (int i = 0; i < size; i++)
                stack.Push(GetRandom(from, to));
 
            return stack;
        } // CreateStack

        // создание очереди из size элементов, заполнение ее 
        // случайными числами в диапазоне значаений от from 
        // до to
        public static Queue<T> CreateQueue<T>(int size, T from, T to) where T : struct
        {
            Queue<T> queue = new Queue<T>();

            for (int i = 0; i < size; i++)
                queue.Enqueue(GetRandom(from, to));

            return queue;
        } // CreateQueue

        // создание листа из size элементов, заполнение ее 
        // случайными числами в диапазоне значаений от from 
        // до to
        public static List<T> CreateList<T>(int size, T from, T to) where T : struct
        {
            List<T> list = new List<T>();

            for (int i = 0; i < size; i++)
                list.Add(GetRandom(from, to));

            return list;
        } // CreateList

        // Преобразование stack стека в строку
        public static string ToString<T>(Stack<T> stack) {
            StringBuilder sb = new StringBuilder("");
            if(stack.Count == 0){
                sb.Append($"стек пуст");
                return sb.ToString();
            }
           
            foreach (var item in stack)
            {
                if (typeof(T) == typeof(double) || typeof(T) == typeof(float))
                    sb.Append($"{item,12:n3}");
                else
                    sb.Append($"{item,5}");
            } // foreach
            return sb.ToString();
        } // ToString (Stack)

        // Преобразование queue очереди в строку
        public static string ToString<T>(Queue<T> queue)  {
            StringBuilder sb = new StringBuilder("");
            if (queue.Count == 0){
                sb.Append($"очередь пуста");
                return sb.ToString();
            }
            
            foreach (var item in queue)
            {
                if (typeof(T) == typeof(double) || typeof(T) == typeof(float))
                    sb.Append($"{item,12:n3}");
                else
                    sb.Append($"{item,5}");
            } // foreach
            return sb.ToString();
        } // ToString (Queue)

        // Преобразование list лсита в строку
        public static string ToString<T>(List<T> list) {
            StringBuilder sb = new StringBuilder("");
            if (list.Count == 0){
                sb.Append($"список пуст");
                return sb.ToString();
            }

            foreach (var item in list)
            {
                if (typeof(T) == typeof(double) || typeof(T) == typeof(float))
                    sb.Append($"{item,12:n3}");
                else
                    sb.Append($"{item,5}");
            } // foreach
            return sb.ToString();
        } // ToString (Queue)

        // формирует и выводит верхнюю строку для задач
        public static void ShowNavBarTask(string line)
        {
            // сохранить цвет фона
            ConsoleColor oldBgColor = Console.BackgroundColor;
            ConsoleColor oldFgColor = Console.ForegroundColor;

            // при выводе немного используем методы класса strring :)
            // PadRight() дополняет строку справа пробелами до заданной длины
         
            WriteXY(0, 0, line.PadRight(Console.WindowWidth), ConsoleColor.DarkBlue, ConsoleColor.Yellow);

            // восстановить цвет фона
            Console.BackgroundColor = oldBgColor;
            Console.ForegroundColor = oldFgColor;
        } // ShowNavBarTask


        // Вспомогательный метод для вывода в заданных координатах окна консоли текста
        // заданным цветом
        public static void WriteXY(int x, int y, string s, ConsoleColor colorF = ConsoleColor.White, ConsoleColor colorB = ConsoleColor.Black)
        {
            // сохранить текущий цвет консоли и установить заданный
            ConsoleColor oldColorF = Console.ForegroundColor;
            ConsoleColor oldColorB = Console.BackgroundColor;
            Console.ForegroundColor = colorF;
            Console.BackgroundColor = colorB;

            Console.SetCursorPosition(x, y);
            Console.Write(s);

            // восстановить цвет консоли
            Console.ForegroundColor = oldColorF;
            Console.BackgroundColor = oldColorB;
        } // WriteXY

    } // class Utils
}
