﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using C_Sharp_.NET_Framework__15___Generic_Collection_;

namespace C_Sharp_.NET_Framework__15___Generic_Collection_.Application
{
    class App{

        // количество элементов в стеке для начального заполнения
        private int _size;
        public int Size
        {
            get => _size;
            private set => _size = value > 0 ? value : throw new Exception("Недопустимый размер стека");
        }

        // ------------- Задача №1 -------------

        //  Стек для первой задачи
        public Stack<int> StackInt { get; set; }

        // ------------- Задача №2 -------------

        // Очереди для второй задачи
        public Queue<int> QueueInt1 { get; set; }
        public Queue<int> QueueInt2 { get; set; }

        // ------------- Задача №3 -------------

        List<int> ListInt { get; set; }

        public App(): this(7){}


        public App(int size) => Size = size;

        

        // Дан непустой стек. Создать два новых стека, переместив 
        // в первый из них все элементы исходного стека с четными значениями,
        // а во второй — с нечетными
        // (элементы в новых стеках будут располагаться в порядке, обратном исходному;
        // один из этих стеков может оказаться пустым). 
       
        public void task1(){
            int y = 3;
            int x = 12;
            Utils.WriteXY(x, y++, "    ================================== Задание №1 ================================    ", ConsoleColor.Cyan, ConsoleColor.DarkGray);
            Utils.WriteXY(x, y++, "      Дан непустой стек. Создать два новых стека, переместив в первый из них все      ", ConsoleColor.Blue, ConsoleColor.DarkMagenta);
            Utils.WriteXY(x, y++, "      элементы исходного стека с четными значениями, а во второй — с нечетными        ", ConsoleColor.Blue, ConsoleColor.DarkMagenta);
            Utils.WriteXY(x, y++, "     (элементы в новых стеках будут располагаться в порядке, обратном исходному;      ", ConsoleColor.Blue, ConsoleColor.DarkMagenta);
            Utils.WriteXY(x, y++, "                        один из этих стеков может оказаться пустым).                  ", ConsoleColor.Blue, ConsoleColor.DarkMagenta);
            Utils.WriteXY(x, y++, "    ==============================================================================    ", ConsoleColor.Cyan, ConsoleColor.DarkGray);

            Console.ResetColor();
            Console.WriteLine("\n\n");

            GenerationStack();
            Stack<int> stackEven = new Stack<int>();
            Stack<int> stackOdd = new Stack<int>();
            Console.WriteLine($"\n\tСтеки до обработки. Начальный стек: {Utils.ToString(StackInt)}");
            Console.WriteLine($"\n\tСтеки до обработки. Четный    стек: {Utils.ToString(stackEven)}");
            Console.WriteLine($"\n\tСтеки до обработки. Нечетный  стек: {Utils.ToString(stackOdd)}");

            while(StackInt.Count > 0){
                int temp = StackInt.Pop();
                // if ((temp & 1) == 0) 
                //     stackEven.Push(temp);
                // else 
                //     stackOdd.Push(temp);

                (((temp & 1) == 0)?stackEven:stackOdd).Push(temp);
            } //  while(StackInt.Count > 0)

            Console.WriteLine($"\n\n\t\tСтеки после обработки:");
            Console.WriteLine($"\n\tНачальный стек: {Utils.ToString(StackInt)}");
            Console.WriteLine($"\n\tЧетный    стек: {Utils.ToString(stackEven)}");
            Console.WriteLine($"\n\tНечетный  стек: {Utils.ToString(stackOdd)}");

        } // task1
        
        //  Даны две непустые очереди, очереди содержат одинаковое количество элементов. 
        //   Объединить очереди в одну, в которой элементы исходных очередей чередуются  
        //                     (начиная с первого элемента первой очереди)               
        public void task2(){
            int y = 3;
            int x = 12;
            Utils.WriteXY(x, y++, "    ================================== Задание №2 ================================    ", ConsoleColor.Cyan, ConsoleColor.DarkGray);
            Utils.WriteXY(x, y++, "     Даны две непустые очереди, очереди содержат одинаковое количество элементов.     ", ConsoleColor.Blue, ConsoleColor.DarkMagenta);
            Utils.WriteXY(x, y++, "      Объединить очереди в одну, в которой элементы исходных очередей чередуются      ", ConsoleColor.Blue, ConsoleColor.DarkMagenta);
            Utils.WriteXY(x, y++, "                        (начиная с первого элемента первой очереди)                   ", ConsoleColor.Blue, ConsoleColor.DarkMagenta);
            Utils.WriteXY(x, y++, "    ==============================================================================    ", ConsoleColor.Cyan, ConsoleColor.DarkGray);

            Console.ResetColor();
            Console.WriteLine("\n\n");

            GenerationQueue();
            Queue<int> eatenQueue = new Queue<int>();
            Console.WriteLine($"\n\n\t\tОчереди до обработки:");
            Console.WriteLine($"\n\tОчередь №1          : {Utils.ToString(QueueInt1)}");
            Console.WriteLine($"\n\tОчередь №2          : {Utils.ToString(QueueInt2)}");
            Console.WriteLine($"\n\tОбъедененная очередь: {Utils.ToString(eatenQueue)}");

            int i = 0;
            // По скольку очереди одного размера, а объеденение мы начинаем с первой очереди,
            // нам достаточно проверки только на 1 очереди (QueueInt2)
            while (QueueInt2.Count > 0) {
                if ((i & 1) == 0) 
                    eatenQueue.Enqueue(QueueInt1.Dequeue());
                else 
                    eatenQueue.Enqueue(QueueInt2.Dequeue());
                i++;
            } //  while (QueueInt1.Count > 0)

            Console.WriteLine($"\n\n\t\tОчереди до обработки:");
            Console.WriteLine($"\n\tОчередь №1          : {Utils.ToString(QueueInt1)}");
            Console.WriteLine($"\n\tОчередь №2          : {Utils.ToString(QueueInt2)}");
            Console.WriteLine($"\n\tОбъедененная очередь: {Utils.ToString(eatenQueue)}");

        } // task2

        //  Дан непустой список. Продублировать в списке все элементы с нечетными номерами 
        // (новые элементы добавлять перед существующими элементами с такими же значениями)
        public void task3() {
            int y = 3;
            int x = 12;
            Utils.WriteXY(x, y++, "    ================================== Задание №3 ================================    ", ConsoleColor.Cyan, ConsoleColor.DarkGray);
            Utils.WriteXY(x, y++, "    Дан непустой список. Продублировать в списке все элементы с нечетными номерами    ", ConsoleColor.Blue, ConsoleColor.DarkMagenta);
            Utils.WriteXY(x, y++, "   (новые элементы добавлять перед существующими элементами с такими же значениями)   ", ConsoleColor.Blue, ConsoleColor.DarkMagenta);
            Utils.WriteXY(x, y++, "    ==============================================================================    ", ConsoleColor.Cyan, ConsoleColor.DarkGray);

            Console.ResetColor();
            Console.WriteLine("\n\n");

            GenerationList();

            Console.WriteLine($"\n\n\t\tЛист до обработки:");
            Console.WriteLine($"\n\tЛист: {Utils.ToString(ListInt)}");

            // Устанавливаем размер для массива, в который будем записывать все элементы 
            // из listInt c нечетными номерами 
            int n = ListInt.Count() / 2;
            int[] arr = new int[n];
            for (int i = 1,k=0 ; i < ListInt.Count(); i+=2) 
                arr[k++] = ListInt[i];
            
            
            for (int i = 0; i < n; i++){
                int temp = arr[i];

                // По шарпейному?
                ListInt.Insert(ListInt.FindIndex
                    (item => item == temp),
                    temp);
            } // for

            Console.WriteLine($"\n\n\t\tЛист после обработки:");
            Console.WriteLine($"\n\tЛист: {Utils.ToString(ListInt)}");



        } // task3


        // Заполнение данными всех полей класса
        public void Generation()
        {
            GenerationStack();
            GenerationQueue();
        } // Generation

        // Заполнение стека данными для обработки
        public void GenerationStack() => StackInt = Utils.CreateStack(Size, -10, 10);

        // Заполнение очереди данными для обработки
        public void GenerationQueue() {
            QueueInt1 = Utils.CreateQueue(Size, -10, 10);
            QueueInt2 = Utils.CreateQueue(Size, -10, 10);
        } // GenerationQueue

        // Заполнение листа данными для обработки
        public void GenerationList() => ListInt = Utils.CreateList(Size, -10, 10);
 
    }
}

