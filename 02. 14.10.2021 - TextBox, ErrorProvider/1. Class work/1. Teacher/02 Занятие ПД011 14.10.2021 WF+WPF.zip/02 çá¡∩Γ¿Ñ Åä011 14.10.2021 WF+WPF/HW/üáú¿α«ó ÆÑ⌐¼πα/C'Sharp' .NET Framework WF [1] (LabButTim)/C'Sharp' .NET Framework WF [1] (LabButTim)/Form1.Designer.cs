﻿
namespace C_Sharp_.NET_Framework_WF__1___LabButTim_
{
    partial class MainForm
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.labelDraw = new System.Windows.Forms.Label();
            this.labelHeader = new System.Windows.Forms.Label();
            this.BthDraw = new System.Windows.Forms.Button();
            this.tmr1 = new System.Windows.Forms.Timer(this.components);
            this.BthGreeting = new System.Windows.Forms.Button();
            this.ButExit = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // labelDraw
            // 
            this.labelDraw.BackColor = System.Drawing.Color.Gray;
            this.labelDraw.Font = new System.Drawing.Font("Consolas", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelDraw.ForeColor = System.Drawing.Color.Aqua;
            this.labelDraw.Location = new System.Drawing.Point(104, 80);
            this.labelDraw.Name = "labelDraw";
            this.labelDraw.Size = new System.Drawing.Size(816, 344);
            this.labelDraw.TabIndex = 1;
            this.labelDraw.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.labelDraw.Click += new System.EventHandler(this.labelHeader_Click_1);
            // 
            // labelHeader
            // 
            this.labelHeader.BackColor = System.Drawing.Color.Transparent;
            this.labelHeader.Font = new System.Drawing.Font("Malgun Gothic", 28.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelHeader.Location = new System.Drawing.Point(0, 0);
            this.labelHeader.Name = "labelHeader";
            this.labelHeader.Size = new System.Drawing.Size(1032, 80);
            this.labelHeader.TabIndex = 2;
            this.labelHeader.Text = "Привет всем!";
            this.labelHeader.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.labelHeader.Click += new System.EventHandler(this.labelDraw_Click);
            // 
            // BthDraw
            // 
            this.BthDraw.BackColor = System.Drawing.Color.Azure;
            this.BthDraw.Location = new System.Drawing.Point(104, 464);
            this.BthDraw.Name = "BthDraw";
            this.BthDraw.Size = new System.Drawing.Size(232, 48);
            this.BthDraw.TabIndex = 1;
            this.BthDraw.Text = "Рисунок";
            this.BthDraw.UseVisualStyleBackColor = false;
            this.BthDraw.Click += new System.EventHandler(this.BthDraw_Click);
            // 
            // tmr1
            // 
            this.tmr1.Interval = 5000;
            this.tmr1.Tick += new System.EventHandler(this.tmr1_Tick);
            // 
            // BthGreeting
            // 
            this.BthGreeting.BackColor = System.Drawing.Color.Azure;
            this.BthGreeting.Location = new System.Drawing.Point(688, 464);
            this.BthGreeting.Name = "BthGreeting";
            this.BthGreeting.Size = new System.Drawing.Size(232, 48);
            this.BthGreeting.TabIndex = 3;
            this.BthGreeting.Text = "Приветствие";
            this.BthGreeting.UseVisualStyleBackColor = false;
            this.BthGreeting.Click += new System.EventHandler(this.BthGreeting_Click);
            // 
            // ButExit
            // 
            this.ButExit.BackColor = System.Drawing.Color.LightPink;
            this.ButExit.Location = new System.Drawing.Point(396, 464);
            this.ButExit.Name = "ButExit";
            this.ButExit.Size = new System.Drawing.Size(232, 48);
            this.ButExit.TabIndex = 2;
            this.ButExit.Text = "Выход";
            this.ButExit.UseVisualStyleBackColor = false;
            this.ButExit.Click += new System.EventHandler(this.ButExit_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Honeydew;
            this.ClientSize = new System.Drawing.Size(1033, 566);
            this.Controls.Add(this.ButExit);
            this.Controls.Add(this.BthGreeting);
            this.Controls.Add(this.BthDraw);
            this.Controls.Add(this.labelHeader);
            this.Controls.Add(this.labelDraw);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ДЗ№1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label labelDraw;
        private System.Windows.Forms.Label labelHeader;
        private System.Windows.Forms.Button BthDraw;
        private System.Windows.Forms.Timer tmr1;
        private System.Windows.Forms.Button BthGreeting;
        private System.Windows.Forms.Button ButExit;
    }
}

