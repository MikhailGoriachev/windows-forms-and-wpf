﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace C_Sharp_.NET_Framework_WF__1___LabButTim_
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

 

        private void labelHeader_Click_1(object sender, EventArgs e){



        }

        private void BthDraw_Click(object sender, EventArgs e){
            string str =  @"                 ,%%%," + "\n" +
                          @"                   ,%%%` %==--" + "\n" +
                          @"              ,%%`( '|" + "\n" +
                          @"             ,%%@ /\_/" + "\n" +
                          @"   ,%.-""""""-- %%% ""@@__" + "\n" +
                          @"  %%/               | __`\" + "\n" +
                          @" .%'\      |   \   /  //" + "\n" +
                          @" ,%' >   .'----\ |  [/" + "\n" +
                          @"< <<`       ||" + "\n" +
                          @" `\\\       ||" + "\n" +
                          @"   )\\      )\" + "\n" +
                          @"               ^^^^^^^^^^""""""^^^^^^""""^^^^^^^^^^^^^^^^^^^^^";
            
            labelDraw.Text = str;
            tmr1.Enabled = true;
        }

        private void labelDraw_Click(object sender, EventArgs e)
        {

        }

        private void tmr1_Tick(object sender, EventArgs e){

            labelDraw.Text = "";
            tmr1.Enabled = false;
        }

        private void BthGreeting_Click(object sender, EventArgs e){

            string str = @"Привет, Windows Forms";

            labelDraw.Text = str;
            tmr1.Enabled = true;
        }

        private void ButExit_Click(object sender, EventArgs e) => Application.Exit();
    }
}
