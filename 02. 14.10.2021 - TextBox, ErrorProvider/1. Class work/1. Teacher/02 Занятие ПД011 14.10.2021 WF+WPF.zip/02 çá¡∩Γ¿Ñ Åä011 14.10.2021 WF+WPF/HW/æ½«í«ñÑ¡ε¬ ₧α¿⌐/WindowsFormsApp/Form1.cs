﻿using System;
using System.Timers;
using System.Windows.Forms;


namespace WindowsFormsApp
{


	public sealed partial class Form1 : Form
	{
		public Form1() => InitializeComponent();


		private void PictureBtn_Click(object sender, EventArgs e)
		{
			InformationLbl.Text = @"
                   ,%%%,									
                 ,%%%` %==--							
                ,%%`( '|						
               ,%%@ /\_/							
     ,%.-""""--%%% ""@@__							
    %%/             |__`\							
   .%'\     |   \   /  //						
   ,%' >   .'----\ |  [/					
      < <<`       ||						
       `\\\       ||						
         )\\      )\						
^^^^^^^^^^^^^^^^^^^^^^^^^^^..^^^^^^^.^^^^^^^^^^^^^^^^
";
			
			MainTimer.Start();
		}


		private void HelloBtn_Click(object sender, EventArgs e)
		{
			InformationLbl.Text = "Привет, Windows Forms";
			
			MainTimer.Start();
		}


		private void ExitBtn_Click(object sender, EventArgs e) => Application.Exit();
		
		
		private void MainTimer_Elapsed(object sender, ElapsedEventArgs e)
		{
			InformationLbl.Text = "";
		}
	}


}
