﻿namespace WindowsFormsApp
{


	sealed partial class Form1
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;


		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}

			base.Dispose(disposing);
		}


#region Windows Form Designer generated code


		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
			this.InformationLbl = new System.Windows.Forms.Label();
			this.PictureBtn = new System.Windows.Forms.Button();
			this.HelloBtn = new System.Windows.Forms.Button();
			this.ExitBtn = new System.Windows.Forms.Button();
			this.MainTimer = new System.Timers.Timer();
			((System.ComponentModel.ISupportInitialize)(this.MainTimer)).BeginInit();
			this.SuspendLayout();
			// 
			// InformationLbl
			// 
			this.InformationLbl.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(191)))), ((int)(((byte)(159)))));
			this.InformationLbl.Dock = System.Windows.Forms.DockStyle.Top;
			this.InformationLbl.Font = new System.Drawing.Font("Consolas", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point,
				((byte)(204)));
			this.InformationLbl.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(33)))), ((int)(((byte)(45)))));
			this.InformationLbl.Location = new System.Drawing.Point(0, 0);
			this.InformationLbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			this.InformationLbl.Name = "InformationLbl";
			this.InformationLbl.Padding = new System.Windows.Forms.Padding(15, 29, 15, 0);
			this.InformationLbl.Size = new System.Drawing.Size(784, 390);
			this.InformationLbl.TabIndex = 0;
			this.InformationLbl.TextAlign = System.Drawing.ContentAlignment.TopCenter;
			// 
			// PictureBtn
			// 
			this.PictureBtn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.PictureBtn.Location = new System.Drawing.Point(70, 432);
			this.PictureBtn.Name = "PictureBtn";
			this.PictureBtn.Size = new System.Drawing.Size(150, 50);
			this.PictureBtn.TabIndex = 1;
			this.PictureBtn.Text = "Рисунок";
			this.PictureBtn.UseVisualStyleBackColor = true;
			this.PictureBtn.Click += new System.EventHandler(this.PictureBtn_Click);
			// 
			// HelloBtn
			// 
			this.HelloBtn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.HelloBtn.Location = new System.Drawing.Point(550, 432);
			this.HelloBtn.Name = "HelloBtn";
			this.HelloBtn.Size = new System.Drawing.Size(150, 50);
			this.HelloBtn.TabIndex = 2;
			this.HelloBtn.Text = "Приветствие";
			this.HelloBtn.UseVisualStyleBackColor = true;
			this.HelloBtn.Click += new System.EventHandler(this.HelloBtn_Click);
			// 
			// ExitBtn
			// 
			this.ExitBtn.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
			this.ExitBtn.Location = new System.Drawing.Point(311, 432);
			this.ExitBtn.Name = "ExitBtn";
			this.ExitBtn.Size = new System.Drawing.Size(150, 50);
			this.ExitBtn.TabIndex = 3;
			this.ExitBtn.Text = "Выход";
			this.ExitBtn.UseVisualStyleBackColor = true;
			this.ExitBtn.Click += new System.EventHandler(this.ExitBtn_Click);
			// 
			// MainTimer
			// 
			this.MainTimer.AutoReset = false;
			this.MainTimer.Interval = 5000D;
			this.MainTimer.SynchronizingObject = this;
			this.MainTimer.Elapsed += new System.Timers.ElapsedEventHandler(this.MainTimer_Elapsed);
			// 
			// Form1
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 19F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(243)))), ((int)(((byte)(224)))));
			this.ClientSize = new System.Drawing.Size(784, 513);
			this.Controls.Add(this.ExitBtn);
			this.Controls.Add(this.HelloBtn);
			this.Controls.Add(this.PictureBtn);
			this.Controls.Add(this.InformationLbl);
			this.Font = new System.Drawing.Font("Roboto", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point,
				((byte)(204)));
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Margin = new System.Windows.Forms.Padding(4);
			this.Name = "Form1";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Домашнее задание на 13.10.2021";
			((System.ComponentModel.ISupportInitialize)(this.MainTimer)).EndInit();
			this.ResumeLayout(false);
		}


		private System.Windows.Forms.Label InformationLbl;


		private System.Timers.Timer MainTimer;


		private System.Windows.Forms.Button ExitBtn;


		private System.Windows.Forms.Button PictureBtn;


		private System.Windows.Forms.Button HelloBtn;


		private System.Windows.Forms.Button button1;


		private System.Windows.Forms.Label label1;


#endregion
	}


}
