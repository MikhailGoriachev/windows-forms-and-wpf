﻿using System;
using System.Collections.Generic;
using Main.Utilities;


namespace Main
{


	public static class Controller
	{
		public static int NumbersPerRow = 7;
		public static int NumberWidth = 12;


		public static IEnumerable<int> GenerateEnumerable((int min, int max) size, (int min, int max) random)
		{
			var returned = new int[General.Rand.Next(size.min, size.max)];

			for (int i = 0; i < returned.Length; i++)
				returned[i] = General.Rand.Next(random.min, random.max);

			return returned;
		}


		public static void ShowEnumerable(IEnumerable<int> enumerable, Action<int> color = null)
		{
			int currentNumberEnumerator = 0;

			foreach (var i in enumerable)
			{
				color?.Invoke(i);
				Console.Write($" {i} ".Center(NumberWidth));
				Palette.Default.AsCurrent();

				if ((currentNumberEnumerator + 1) % NumbersPerRow == 0)
					Console.WriteLine();

				currentNumberEnumerator++;
			}

			if (currentNumberEnumerator % NumbersPerRow == 0)
				Console.WriteLine();
			else
				Console.WriteLine("\n");
		}
	}


}
