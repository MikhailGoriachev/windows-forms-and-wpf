﻿using System;
using System.Collections.Generic;
using Main.Utilities.Menu;


namespace Main
{


	public sealed class App : MenuWrapper
	{
		private readonly (int min, int max) _randomRanges = (-5, 6);
		private readonly (int min, int max) _sizeRanges = (9, 16);


		public App() => Menu = new Menu("Главное меню приложения", new[]
		{
			new MenuItem("Перемещение элементов из оригинального стека", Dynamic10),
			new MenuItem("Обьединение двух очередей", Dynamic24),
			new MenuItem("Продублировать элементы с нечетными номерами", Dynamic37)
		});


		private void Dynamic10()
		{
			var original = new Stack<int>(Controller.GenerateEnumerable(_sizeRanges, _randomRanges));
			Console.WriteLine("Оригинальный стек:");
			Controller.ShowEnumerable(original);

			var odds = new Stack<int>();
			var evens = new Stack<int>();

			while (original.Count != 0)
			{
				var i = original.Pop();

				((i & 1) == 0 ? evens : odds).Push(i);
			}

			Console.WriteLine("Четные:");
			Controller.ShowEnumerable(evens);

			Console.WriteLine("Не четные:");
			Controller.ShowEnumerable(odds);
		}


		private void Dynamic24()
		{
			var first = new Queue<int>(Controller.GenerateEnumerable(_sizeRanges, _randomRanges));
			var second = new Queue<int>(Controller.GenerateEnumerable(_sizeRanges, _randomRanges));

			Console.WriteLine("Первая очередь:");
			Controller.ShowEnumerable(first);

			Console.WriteLine("Вторая очередь:");
			Controller.ShowEnumerable(second);

			var resultQueue = new Queue<int>(first);
			var secondCopy = new Queue<int>(second);
			while (secondCopy.Count != 0)
				resultQueue.Enqueue(secondCopy.Dequeue());

			// var result = new int[first.Count + second.Count];
			// first.CopyTo(result, 0);
			// second.CopyTo(result, first.Count);
			// var resultQueue = new Queue<int>(result);

			Console.WriteLine("Результирующая очередь:");
			Controller.ShowEnumerable(resultQueue);
		}


		private void Dynamic37()
		{
			var original = new List<int>(Controller.GenerateEnumerable(_sizeRanges, _randomRanges));
			Console.WriteLine("Оригинальный список:");
			Controller.ShowEnumerable(original);

			var resultList = new List<int>(original.Count);
			
			for (int i = 0; i < original.Count; i++)
				resultList.AddRange(((i + 1) & 1) != 0
											  ? new[] { original[i], original[i] }
											  : new[] { original[i] });

			Console.WriteLine("Элементы с нечетными номерами продублированы");
			Controller.ShowEnumerable(resultList);
		}
	}


}
