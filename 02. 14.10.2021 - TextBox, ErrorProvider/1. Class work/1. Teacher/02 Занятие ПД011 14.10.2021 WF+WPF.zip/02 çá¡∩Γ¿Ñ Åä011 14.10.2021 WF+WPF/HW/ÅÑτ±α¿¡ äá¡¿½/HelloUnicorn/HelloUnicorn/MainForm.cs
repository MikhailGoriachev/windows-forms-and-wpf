﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HelloUnicorn
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void MainForm_Load(object sender, EventArgs e)
        {

        }

        private void Drawing_Click(object sender, EventArgs e)
        {
            string str = @"              ,%%%," + "\n" +
            @"                         ,%%%` %==--" + "\n" +
            @"                        ,%%`( '|" + "\n" +
            @"                      ,%.- "" -- %%%  @@___" + "\n" +
            @"                     %%/             |__`\" + "\n" +
            @"                     .%'\     |   \   /  //" + "\n" +
            @"              ,%' >   .'----\ |  [/" + "\n" +
            @"                  < <<`       || " + "\n" +
            @"                   `\\\       ||" + "\n" +
            @"                     )\\      )\" + "\n" +
            @"^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^ " + "\n" +
            @"" + "\n";

            Unicorn.Text = str;
        }

        private void button1_Click(object sender, EventArgs e) => Application.Exit();

        private void tmrFirst_Tick(object sender, EventArgs e)
        {
            Greeting.Text = " ";
            tmrFirst.Enabled = false;
        }

        private void Grt_Click(object sender, EventArgs e)
        {
            Greeting.Text = "Привет, Window Forms";
            tmrFirst.Enabled = true;
        }

        private void Unicorn_Click(object sender, EventArgs e)
        {

        }
    }
}
