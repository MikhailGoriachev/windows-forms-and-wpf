﻿
namespace HelloUnicorn
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.Greeting = new System.Windows.Forms.Label();
            this.Drawing = new System.Windows.Forms.Button();
            this.Grt = new System.Windows.Forms.Button();
            this.Unicorn = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.tmrFirst = new System.Windows.Forms.Timer(this.components);
            this.SuspendLayout();
            // 
            // Greeting
            // 
            this.Greeting.Font = new System.Drawing.Font("Tahoma", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Greeting.Location = new System.Drawing.Point(24, 18);
            this.Greeting.Name = "Greeting";
            this.Greeting.Size = new System.Drawing.Size(759, 89);
            this.Greeting.TabIndex = 0;
            this.Greeting.Text = "\r\n\r\n\r\n\r\n";
            this.Greeting.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Greeting.Click += new System.EventHandler(this.label1_Click);
            // 
            // Drawing
            // 
            this.Drawing.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Drawing.Location = new System.Drawing.Point(85, 533);
            this.Drawing.Name = "Drawing";
            this.Drawing.Size = new System.Drawing.Size(159, 65);
            this.Drawing.TabIndex = 2;
            this.Drawing.Text = "Рисунок";
            this.Drawing.UseVisualStyleBackColor = true;
            this.Drawing.Click += new System.EventHandler(this.Drawing_Click);
            // 
            // Grt
            // 
            this.Grt.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Grt.Location = new System.Drawing.Point(321, 533);
            this.Grt.Name = "Grt";
            this.Grt.Size = new System.Drawing.Size(190, 65);
            this.Grt.TabIndex = 3;
            this.Grt.Text = "Приветствие";
            this.Grt.UseVisualStyleBackColor = true;
            this.Grt.Click += new System.EventHandler(this.Grt_Click);
            // 
            // Unicorn
            // 
            this.Unicorn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Unicorn.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Unicorn.Location = new System.Drawing.Point(51, 132);
            this.Unicorn.Name = "Unicorn";
            this.Unicorn.Size = new System.Drawing.Size(759, 321);
            this.Unicorn.TabIndex = 4;
            this.Unicorn.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Unicorn.Click += new System.EventHandler(this.Unicorn_Click);
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Tahoma", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button1.Location = new System.Drawing.Point(657, 533);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(190, 65);
            this.button1.TabIndex = 5;
            this.button1.Text = "Выход";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // tmrFirst
            // 
            this.tmrFirst.Interval = 5000;
            this.tmrFirst.Tick += new System.EventHandler(this.tmrFirst_Tick);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(978, 1050);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.Unicorn);
            this.Controls.Add(this.Grt);
            this.Controls.Add(this.Drawing);
            this.Controls.Add(this.Greeting);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Домашняя работа 1";
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label Greeting;
        private System.Windows.Forms.Button Drawing;
        private System.Windows.Forms.Button Grt;
        private System.Windows.Forms.Label Unicorn;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Timer tmrFirst;
    }
}

