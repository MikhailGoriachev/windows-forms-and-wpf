﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Collections.Helpers;


namespace Collections.Application
{
    internal partial class App 
    {
       
        public void TaskDynamic10()
        {
            Utils.ShowNavBarTask("Задание Dymanic10");

            Console.WriteLine("\n\n\n");
            Console.Write("Дан непустой стек ");
            Stack<int> stack = new Stack<int>();
            Stack<int> odd = new Stack<int>(); // стек для нечетных
            Stack<int> even = new Stack<int>(); // стек для четных
            int stackSize = Utils.GetRandomInt(5, 15);

            for (int i =0; i<stackSize;++i)
            {
                stack.Push(Utils.GetRandomInt(1, 21));
            }
            // вывод стека в консоль
            foreach(var item in stack)
            {
                Console.Write($"{item, 6}");
            }
            // перемещение из основного стека в четный 
            while(stack.Count !=0)
            {
                if (stack.Peek() % 2 == 0)
                    even.Push(stack.Pop());
                else
                    odd.Push(stack.Pop());
            }
            Console.Write("\nСтек четных чисел");
            foreach(var item in even)
            {
                Console.Write($"{item, 6}");
            }
            
            Console.Write("\nСтек нечетных чисел");
            foreach (var item in odd)
            {
                Console.Write($"{item,6}");
            }






            Console.ReadKey();

        }
        public void TaskDynamic24()
        {
            Utils.ShowNavBarTask("Задание Dymanic24");

            Console.WriteLine("\n\n\n");
            Console.WriteLine("Даны две непустые очереди ");

            int queueSize = Utils.GetRandomInt(5, 10);
            Queue<int> queue1 = new Queue<int>();
            Queue<int> queue2 = new Queue<int>();
            Queue<int> queue3 = new Queue<int>();
            for(int i =0; i< queueSize; i++)
            {
                queue1.Enqueue(Utils.GetRandomInt(1, 15));
                queue2.Enqueue(Utils.GetRandomInt(1, 15));
            }

            //  вывод очереденй 
            Console.Write($"Первая очередь : ");
            foreach(var item in queue1)
            {
                Console.Write($"{item,4}");
            }
            Console.WriteLine("\n");
            Console.Write($"Вторая очередь : ");
            foreach (var item in queue2)
            {
                Console.Write($"{item,4}");
            }
            // объединение очередей
            for(int i = 0; i<queueSize*2; i++)
            {
                if ((i & 1) != 0)
                {
                    queue3.Enqueue(queue1.Dequeue());
                }
                else queue3.Enqueue(queue2.Dequeue());
            }
            Console.Write($"\nОбъединенная очередь : ");
            foreach (var item in queue3)
            {
                Console.Write($"{item,4}");
            }


            Console.ReadKey();
        }
        public void TaskDynamic37()
        {
            Utils.ShowNavBarTask("Задание Dymanic37");

            Console.Write("\n\n\nДан непустой список : ");

            int listSize = Utils.GetRandomInt(3, 15);
            List<int> list = new List<int>();
            List<int> newList = new List<int>();
            for(int i  =0; i<listSize; i++)
            {
                list.Add(Utils.GetRandomInt(3, 15));
            }
            foreach(var item in list)
            {
                Console.Write($"{item,4}");
            }

            // удваивание элементов
            for(int i = 0; i<listSize; i++)
            {
                newList.AddRange(((i + 1) & 1) != 0
                                          ? new[] { list[i], list[i] }
                                          : new[] { list[i] });
            }
            Console.Write($"\n\nНовый список : ");
            foreach (var item in newList)
            {
                Console.Write($"{item,4}");
            }




            Console.ReadKey();
        }
    }
}
