﻿using System.Windows.Forms;

namespace ListBox_ComboBox_Menu
{
    public partial class AboutForm : Form
    {
        public AboutForm () {
            InitializeComponent();
        }
    }
}
