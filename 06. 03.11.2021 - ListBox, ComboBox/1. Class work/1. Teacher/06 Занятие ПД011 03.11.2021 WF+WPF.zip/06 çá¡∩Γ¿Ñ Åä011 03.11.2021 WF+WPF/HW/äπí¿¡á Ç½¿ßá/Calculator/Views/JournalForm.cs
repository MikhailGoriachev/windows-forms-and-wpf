﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calculator.Views
{
    public partial class JournalForm : Form
    {
        public JournalForm()
        {
            InitializeComponent();
        }

        private void BtnQuit_Click(object sender, EventArgs e) => Close();

        private void JournalForm_Load(object sender, EventArgs e) {
            TxbJournal.Text =
                "┌─────┬─────────────────────┬────────────────┬──────────┬────────────────┬───────────┐\r\n" +
                "│  N  │     Дата и время    │ Первый операнд │ Операция │ Второй операнд │ Результат │\r\n" +
                "├─────┼─────────────────────┼────────────────┼──────────┼────────────────┼───────────┤\r\n";

            string[] text = File.ReadAllLines(Program.fileName, Encoding.Default);
            int i = 1;
            foreach (var line in text) {
                string[] tokens = line.Split(";\r\n".ToCharArray(), StringSplitOptions.RemoveEmptyEntries);

                TxbJournal.Text +=
                    $"│ {i,3} │ {tokens[tokens.Length - 1],-19} │ {tokens[1],14} │ {tokens[0],8} │";

                TxbJournal.Text +=
                    tokens.Length == 5
                    ? $" {tokens[2],14} | {tokens[3],9} │\r\n"  // бинарная операция
                    : $"                | {tokens[2],9} │\r\n"; // унарная операция

                i++;
            } // foreach

            TxbJournal.Text +=
                "└─────┴─────────────────────┴────────────────┴──────────┴────────────────┴───────────┘\r\n";
        } // JournalForm_Load

        private void BtnClear_Click(object sender, EventArgs e) {
            File.WriteAllText(Program.fileName, "");
            TxbJournal.Text = "\r\n\r\nЖурнал очищен!";
        } // BtnClear_Click
    }
}
