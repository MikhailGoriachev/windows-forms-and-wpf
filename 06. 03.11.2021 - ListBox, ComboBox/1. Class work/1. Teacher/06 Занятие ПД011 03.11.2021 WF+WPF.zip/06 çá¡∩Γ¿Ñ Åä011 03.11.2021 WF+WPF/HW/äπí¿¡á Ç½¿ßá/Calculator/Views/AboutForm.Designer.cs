﻿
namespace Calculator.Views
{
    partial class AboutForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AboutForm));
            this.GrbAbout = new System.Windows.Forms.GroupBox();
            this.BtnOk = new System.Windows.Forms.Button();
            this.LblAbout = new System.Windows.Forms.Label();
            this.LblDeveloper = new System.Windows.Forms.Label();
            this.tmr = new System.Windows.Forms.Timer(this.components);
            this.GrbAbout.SuspendLayout();
            this.SuspendLayout();
            // 
            // GrbAbout
            // 
            this.GrbAbout.Controls.Add(this.LblAbout);
            this.GrbAbout.Controls.Add(this.BtnOk);
            this.GrbAbout.Controls.Add(this.LblDeveloper);
            this.GrbAbout.Location = new System.Drawing.Point(16, 19);
            this.GrbAbout.Name = "GrbAbout";
            this.GrbAbout.Size = new System.Drawing.Size(478, 296);
            this.GrbAbout.TabIndex = 0;
            this.GrbAbout.TabStop = false;
            this.GrbAbout.Text = " О программе: ";
            // 
            // BtnOk
            // 
            this.BtnOk.BackColor = System.Drawing.Color.Red;
            this.BtnOk.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.BtnOk.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.BtnOk.Location = new System.Drawing.Point(341, 247);
            this.BtnOk.Name = "BtnOk";
            this.BtnOk.Size = new System.Drawing.Size(122, 33);
            this.BtnOk.TabIndex = 0;
            this.BtnOk.Text = "ОК";
            this.BtnOk.UseVisualStyleBackColor = false;
            this.BtnOk.Click += new System.EventHandler(this.BtnOk_Click);
            // 
            // LblAbout
            // 
            this.LblAbout.Location = new System.Drawing.Point(28, 29);
            this.LblAbout.Name = "LblAbout";
            this.LblAbout.Size = new System.Drawing.Size(363, 171);
            this.LblAbout.TabIndex = 1;
            this.LblAbout.Text = resources.GetString("LblAbout.Text");
            // 
            // LblDeveloper
            // 
            this.LblDeveloper.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblDeveloper.Location = new System.Drawing.Point(6, 271);
            this.LblDeveloper.Name = "LblDeveloper";
            this.LblDeveloper.Size = new System.Drawing.Size(338, 22);
            this.LblDeveloper.TabIndex = 15;
            this.LblDeveloper.Text = "Дубина Алиса, группа ПД011, КА Шаг, Донецк, 2021";
            this.LblDeveloper.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tmr
            // 
            this.tmr.Interval = 10000;
            this.tmr.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // AboutForm
            // 
            this.AcceptButton = this.BtnOk;
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.WhiteSmoke;
            this.ClientSize = new System.Drawing.Size(512, 335);
            this.Controls.Add(this.GrbAbout);
            this.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.Name = "AboutForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "О программе";
            this.GrbAbout.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox GrbAbout;
        private System.Windows.Forms.Button BtnOk;
        private System.Windows.Forms.Label LblAbout;
        private System.Windows.Forms.Label LblDeveloper;
        private System.Windows.Forms.Timer tmr;
    }
}