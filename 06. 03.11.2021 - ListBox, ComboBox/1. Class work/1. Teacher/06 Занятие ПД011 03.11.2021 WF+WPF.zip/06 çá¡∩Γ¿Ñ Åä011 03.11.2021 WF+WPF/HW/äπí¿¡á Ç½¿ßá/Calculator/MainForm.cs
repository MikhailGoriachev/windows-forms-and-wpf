﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Calculator.Views;

namespace Calculator
{
    public partial class MainForm : Form
    {
        public MainForm() {
            InitializeComponent();
        } // MainForm


        private void LnlQuit_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e) => Application.Exit();


        private void RdbSinus_CheckedChanged(object sender, EventArgs e) {
            TxbResult.Text = "";
            RadioButton rb = sender as RadioButton;
            NudFirstNum.Enabled = RdbDegrees.Checked = RdbDegrees.Enabled = RdbRadians.Enabled = rb.Checked;
            NudFirstNum.Minimum = -10000M;
            BtnCalculate.Tag = rb.Tag;
        } // RdbSinus_CheckedChanged


        private void RdbSqrt_CheckedChanged(object sender, EventArgs e) {
            TxbResult.Text = "";
            RadioButton rb = sender as RadioButton;
            NudFirstNum.Enabled = rb.Checked;
            NudFirstNum.Minimum = 0.001M;
            BtnCalculate.Tag = rb.Tag;
        } // RdbSqrt_CheckedChanged


        private void Rdb_CheckedChanged(object sender, EventArgs e) {
            TxbResult.Text = "";
            RadioButton rb = sender as RadioButton;
            NudFirstNum.Enabled = NudSecndNum.Enabled = rb.Checked;
            NudFirstNum.Minimum = -10000M;
            BtnCalculate.Tag = rb.Tag;
        } // Rdb_CheckedChanged


        int operationNum = 1; // номер операции

        private void BtnCalculate_Click(object sender, EventArgs e) {
            TxbResult.Text = "";
            Button b = sender as Button;
            double firstNum = (double)NudFirstNum.Value;
            double secndNum = (double)NudSecndNum.Value;

            string operation = (string)b.Tag;

            double result = 0;

            switch (operation) {
                case "+":
                    result = firstNum + secndNum;
                    goto case "two operands";

                case "-":
                    result = firstNum - secndNum;
                    goto case "two operands";

                case "*":
                    result = firstNum * secndNum;
                    goto case "two operands";

                case "/":
                    result = firstNum / secndNum;
                    goto case "two operands";

                case "^":
                    result = Math.Pow(firstNum, secndNum);
                    goto case "two operands";

                case "sin":
                    result = RdbDegrees.Checked 
                        ? Math.Sin(firstNum / 180d * Math.PI) 
                        : Math.Sin(firstNum);
                    goto case "one operand";

                case "sqrt":
                    result = Math.Sqrt(firstNum);
                    goto case "one operand";

                case "two operands":
                    TxbResult.Text = $"{firstNum:f3} {operation} {secndNum:f3} = {result:f3}";
                    TxbHistory.Text += $"{operationNum}) {firstNum:f3} {operation} {secndNum:f3} = {result:f3}\r\n";
                    WriteOperationToFile(firstNum, secndNum, operation, result);
                    break;

                case "one operand":
                    TxbResult.Text = $"{operation}({firstNum:f3}) = {result:f3}";
                    TxbHistory.Text += $"{operationNum}) {operation}({firstNum:f3}) = {result:f3}\r\n";
                    WriteOperationToFile(firstNum, operation, result);
                    break;
                default:
                    break;
            } // switch
            operationNum++;
        } // BtnCalculate_Click


        private void BtnClear_Click(object sender, EventArgs e) {
            // сброс счетчика операций
            operationNum = 1;
            TxbHistory.Text = "";
        } // BtnClear_Click


        private void LnlAbout_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e) {
            AboutForm aboutForm = new AboutForm();
            aboutForm.ShowDialog();
        } // LnlAbout_LinkClicked


        private void LnlJournal_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e) {
            JournalForm journalForm = new JournalForm();
            journalForm.ShowDialog();
        } // LnlJournal_LinkClicked


        // запись в файл бинарной операции
        private void WriteOperationToFile(double n1, double n2, string operation, double result) {
            using (StreamWriter sw = new StreamWriter(Program.fileName, true, Encoding.Default)){
                // запись строки в файл
                sw.WriteLine($"{operation};{n1:f3};{n2:f3};{result:f3};{DateTime.Now:dd/MM/yyyy HH:mm:ss}");
            } // using
        } // WriteOperationToFile


        // запись в файл унарной операции
        private void WriteOperationToFile(double n1, string operation, double result) {
            using (StreamWriter sw = new StreamWriter(Program.fileName, true, Encoding.Default)) {
                // запись строки в файл
                sw.WriteLine($"{operation};{n1:f3};{result:f3};{DateTime.Now:dd/MM/yyyy HH:mm:ss}");
            } // using
        } // WriteOperationToFile
    }
}
