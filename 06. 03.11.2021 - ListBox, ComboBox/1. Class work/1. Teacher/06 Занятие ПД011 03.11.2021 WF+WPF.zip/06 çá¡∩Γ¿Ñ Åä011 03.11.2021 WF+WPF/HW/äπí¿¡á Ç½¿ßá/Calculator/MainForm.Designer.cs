﻿
namespace Calculator
{
    partial class MainForm
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.NudFirstNum = new System.Windows.Forms.NumericUpDown();
            this.NudSecndNum = new System.Windows.Forms.NumericUpDown();
            this.BrbOperations = new System.Windows.Forms.GroupBox();
            this.RdbAddition = new System.Windows.Forms.RadioButton();
            this.RdbSubtraction = new System.Windows.Forms.RadioButton();
            this.RdbMultiplication = new System.Windows.Forms.RadioButton();
            this.RdbDivision = new System.Windows.Forms.RadioButton();
            this.RdbSinus = new System.Windows.Forms.RadioButton();
            this.RdbSqrt = new System.Windows.Forms.RadioButton();
            this.RdbExponenriation = new System.Windows.Forms.RadioButton();
            this.LnlQuit = new System.Windows.Forms.LinkLabel();
            this.LnlAbout = new System.Windows.Forms.LinkLabel();
            this.LnlJournal = new System.Windows.Forms.LinkLabel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.RdbDegrees = new System.Windows.Forms.RadioButton();
            this.RdbRadians = new System.Windows.Forms.RadioButton();
            this.BtnCalculate = new System.Windows.Forms.Button();
            this.TxbResult = new System.Windows.Forms.TextBox();
            this.LblFirstNum = new System.Windows.Forms.Label();
            this.LblSecndNum = new System.Windows.Forms.Label();
            this.LblResult = new System.Windows.Forms.Label();
            this.TxbHistory = new System.Windows.Forms.TextBox();
            this.LblHistory = new System.Windows.Forms.Label();
            this.BtnClear = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.NudFirstNum)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NudSecndNum)).BeginInit();
            this.BrbOperations.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.LightGray;
            this.panel1.Controls.Add(this.LnlJournal);
            this.panel1.Controls.Add(this.LnlAbout);
            this.panel1.Controls.Add(this.LnlQuit);
            this.panel1.Location = new System.Drawing.Point(-1, -1);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(750, 27);
            this.panel1.TabIndex = 0;
            // 
            // NudFirstNum
            // 
            this.NudFirstNum.BackColor = System.Drawing.Color.LightGray;
            this.NudFirstNum.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.NudFirstNum.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.NudFirstNum.DecimalPlaces = 3;
            this.NudFirstNum.Enabled = false;
            this.NudFirstNum.ForeColor = System.Drawing.Color.Black;
            this.NudFirstNum.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.NudFirstNum.Location = new System.Drawing.Point(229, 123);
            this.NudFirstNum.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.NudFirstNum.Minimum = new decimal(new int[] {
            10000,
            0,
            0,
            -2147483648});
            this.NudFirstNum.Name = "NudFirstNum";
            this.NudFirstNum.Size = new System.Drawing.Size(188, 23);
            this.NudFirstNum.TabIndex = 1;
            this.NudFirstNum.ThousandsSeparator = true;
            this.NudFirstNum.Value = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            // 
            // NudSecndNum
            // 
            this.NudSecndNum.BackColor = System.Drawing.Color.LightGray;
            this.NudSecndNum.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.NudSecndNum.DecimalPlaces = 3;
            this.NudSecndNum.Enabled = false;
            this.NudSecndNum.ForeColor = System.Drawing.Color.Black;
            this.NudSecndNum.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.NudSecndNum.Location = new System.Drawing.Point(229, 179);
            this.NudSecndNum.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.NudSecndNum.Minimum = new decimal(new int[] {
            10000,
            0,
            0,
            -2147483648});
            this.NudSecndNum.Name = "NudSecndNum";
            this.NudSecndNum.Size = new System.Drawing.Size(188, 23);
            this.NudSecndNum.TabIndex = 2;
            this.NudSecndNum.ThousandsSeparator = true;
            this.NudSecndNum.Value = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            // 
            // BrbOperations
            // 
            this.BrbOperations.BackColor = System.Drawing.Color.LightGray;
            this.BrbOperations.Controls.Add(this.RdbExponenriation);
            this.BrbOperations.Controls.Add(this.RdbSqrt);
            this.BrbOperations.Controls.Add(this.RdbSinus);
            this.BrbOperations.Controls.Add(this.RdbDivision);
            this.BrbOperations.Controls.Add(this.RdbMultiplication);
            this.BrbOperations.Controls.Add(this.RdbSubtraction);
            this.BrbOperations.Controls.Add(this.RdbAddition);
            this.BrbOperations.Location = new System.Drawing.Point(27, 73);
            this.BrbOperations.Name = "BrbOperations";
            this.BrbOperations.Size = new System.Drawing.Size(169, 219);
            this.BrbOperations.TabIndex = 3;
            this.BrbOperations.TabStop = false;
            this.BrbOperations.Text = " Выбор операции: ";
            // 
            // RdbAddition
            // 
            this.RdbAddition.AutoSize = true;
            this.RdbAddition.BackColor = System.Drawing.Color.LightGray;
            this.RdbAddition.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.RdbAddition.Location = new System.Drawing.Point(6, 22);
            this.RdbAddition.Name = "RdbAddition";
            this.RdbAddition.Size = new System.Drawing.Size(93, 20);
            this.RdbAddition.TabIndex = 0;
            this.RdbAddition.TabStop = true;
            this.RdbAddition.Tag = "+";
            this.RdbAddition.Text = "сложение";
            this.RdbAddition.UseVisualStyleBackColor = false;
            this.RdbAddition.CheckedChanged += new System.EventHandler(this.Rdb_CheckedChanged);
            // 
            // RdbSubtraction
            // 
            this.RdbSubtraction.AutoSize = true;
            this.RdbSubtraction.BackColor = System.Drawing.Color.LightGray;
            this.RdbSubtraction.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.RdbSubtraction.Location = new System.Drawing.Point(6, 50);
            this.RdbSubtraction.Name = "RdbSubtraction";
            this.RdbSubtraction.Size = new System.Drawing.Size(97, 20);
            this.RdbSubtraction.TabIndex = 1;
            this.RdbSubtraction.TabStop = true;
            this.RdbSubtraction.Tag = "-";
            this.RdbSubtraction.Text = "вычитание";
            this.RdbSubtraction.UseVisualStyleBackColor = false;
            this.RdbSubtraction.CheckedChanged += new System.EventHandler(this.Rdb_CheckedChanged);
            // 
            // RdbMultiplication
            // 
            this.RdbMultiplication.AutoSize = true;
            this.RdbMultiplication.BackColor = System.Drawing.Color.LightGray;
            this.RdbMultiplication.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.RdbMultiplication.Location = new System.Drawing.Point(6, 78);
            this.RdbMultiplication.Name = "RdbMultiplication";
            this.RdbMultiplication.Size = new System.Drawing.Size(103, 20);
            this.RdbMultiplication.TabIndex = 2;
            this.RdbMultiplication.TabStop = true;
            this.RdbMultiplication.Tag = "*";
            this.RdbMultiplication.Text = "умножение";
            this.RdbMultiplication.UseVisualStyleBackColor = false;
            this.RdbMultiplication.CheckedChanged += new System.EventHandler(this.Rdb_CheckedChanged);
            // 
            // RdbDivision
            // 
            this.RdbDivision.AutoSize = true;
            this.RdbDivision.BackColor = System.Drawing.Color.LightGray;
            this.RdbDivision.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.RdbDivision.Location = new System.Drawing.Point(6, 106);
            this.RdbDivision.Name = "RdbDivision";
            this.RdbDivision.Size = new System.Drawing.Size(82, 20);
            this.RdbDivision.TabIndex = 3;
            this.RdbDivision.TabStop = true;
            this.RdbDivision.Tag = "/";
            this.RdbDivision.Text = "деление";
            this.RdbDivision.UseVisualStyleBackColor = false;
            this.RdbDivision.CheckedChanged += new System.EventHandler(this.Rdb_CheckedChanged);
            // 
            // RdbSinus
            // 
            this.RdbSinus.AutoSize = true;
            this.RdbSinus.BackColor = System.Drawing.Color.LightGray;
            this.RdbSinus.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.RdbSinus.Location = new System.Drawing.Point(6, 134);
            this.RdbSinus.Name = "RdbSinus";
            this.RdbSinus.Size = new System.Drawing.Size(155, 20);
            this.RdbSinus.TabIndex = 4;
            this.RdbSinus.TabStop = true;
            this.RdbSinus.Tag = "sin";
            this.RdbSinus.Text = "вычисление синуса";
            this.RdbSinus.UseVisualStyleBackColor = false;
            this.RdbSinus.CheckedChanged += new System.EventHandler(this.RdbSinus_CheckedChanged);
            // 
            // RdbSqrt
            // 
            this.RdbSqrt.AutoSize = true;
            this.RdbSqrt.BackColor = System.Drawing.Color.LightGray;
            this.RdbSqrt.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.RdbSqrt.Location = new System.Drawing.Point(4, 162);
            this.RdbSqrt.Name = "RdbSqrt";
            this.RdbSqrt.Size = new System.Drawing.Size(150, 20);
            this.RdbSqrt.TabIndex = 5;
            this.RdbSqrt.TabStop = true;
            this.RdbSqrt.Tag = "sqrt";
            this.RdbSqrt.Text = "вычисление корня";
            this.RdbSqrt.UseVisualStyleBackColor = false;
            this.RdbSqrt.CheckedChanged += new System.EventHandler(this.RdbSqrt_CheckedChanged);
            // 
            // RdbExponenriation
            // 
            this.RdbExponenriation.AutoSize = true;
            this.RdbExponenriation.BackColor = System.Drawing.Color.LightGray;
            this.RdbExponenriation.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.RdbExponenriation.Location = new System.Drawing.Point(6, 190);
            this.RdbExponenriation.Name = "RdbExponenriation";
            this.RdbExponenriation.Size = new System.Drawing.Size(163, 20);
            this.RdbExponenriation.TabIndex = 6;
            this.RdbExponenriation.TabStop = true;
            this.RdbExponenriation.Tag = "^";
            this.RdbExponenriation.Text = "вычисление степени";
            this.RdbExponenriation.UseVisualStyleBackColor = false;
            this.RdbExponenriation.CheckedChanged += new System.EventHandler(this.Rdb_CheckedChanged);
            // 
            // LnlQuit
            // 
            this.LnlQuit.AutoSize = true;
            this.LnlQuit.LinkColor = System.Drawing.Color.Red;
            this.LnlQuit.Location = new System.Drawing.Point(684, 4);
            this.LnlQuit.Name = "LnlQuit";
            this.LnlQuit.Size = new System.Drawing.Size(51, 16);
            this.LnlQuit.TabIndex = 4;
            this.LnlQuit.TabStop = true;
            this.LnlQuit.Text = "Выход";
            this.LnlQuit.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.LnlQuit_LinkClicked);
            // 
            // LnlAbout
            // 
            this.LnlAbout.AutoSize = true;
            this.LnlAbout.LinkColor = System.Drawing.Color.Red;
            this.LnlAbout.Location = new System.Drawing.Point(140, 4);
            this.LnlAbout.Name = "LnlAbout";
            this.LnlAbout.Size = new System.Drawing.Size(95, 16);
            this.LnlAbout.TabIndex = 5;
            this.LnlAbout.TabStop = true;
            this.LnlAbout.Text = "О программе";
            this.LnlAbout.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.LnlAbout_LinkClicked);
            // 
            // LnlJournal
            // 
            this.LnlJournal.AutoSize = true;
            this.LnlJournal.LinkColor = System.Drawing.Color.Red;
            this.LnlJournal.Location = new System.Drawing.Point(42, 4);
            this.LnlJournal.Name = "LnlJournal";
            this.LnlJournal.Size = new System.Drawing.Size(62, 16);
            this.LnlJournal.TabIndex = 6;
            this.LnlJournal.TabStop = true;
            this.LnlJournal.Text = "Журнал";
            this.LnlJournal.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.LnlJournal_LinkClicked);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.RdbRadians);
            this.panel2.Controls.Add(this.RdbDegrees);
            this.panel2.Location = new System.Drawing.Point(229, 235);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(114, 57);
            this.panel2.TabIndex = 4;
            // 
            // RdbDegrees
            // 
            this.RdbDegrees.AutoSize = true;
            this.RdbDegrees.BackColor = System.Drawing.Color.WhiteSmoke;
            this.RdbDegrees.Enabled = false;
            this.RdbDegrees.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.RdbDegrees.Location = new System.Drawing.Point(3, 3);
            this.RdbDegrees.Name = "RdbDegrees";
            this.RdbDegrees.Size = new System.Drawing.Size(98, 20);
            this.RdbDegrees.TabIndex = 7;
            this.RdbDegrees.TabStop = true;
            this.RdbDegrees.Text = "в градусах";
            this.RdbDegrees.UseVisualStyleBackColor = false;
            // 
            // RdbRadians
            // 
            this.RdbRadians.AutoSize = true;
            this.RdbRadians.BackColor = System.Drawing.Color.WhiteSmoke;
            this.RdbRadians.Enabled = false;
            this.RdbRadians.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.RdbRadians.Location = new System.Drawing.Point(3, 34);
            this.RdbRadians.Name = "RdbRadians";
            this.RdbRadians.Size = new System.Drawing.Size(100, 20);
            this.RdbRadians.TabIndex = 8;
            this.RdbRadians.TabStop = true;
            this.RdbRadians.Text = "в радианах";
            this.RdbRadians.UseVisualStyleBackColor = false;
            // 
            // BtnCalculate
            // 
            this.BtnCalculate.BackColor = System.Drawing.Color.Red;
            this.BtnCalculate.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.BtnCalculate.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.BtnCalculate.Location = new System.Drawing.Point(27, 320);
            this.BtnCalculate.Name = "BtnCalculate";
            this.BtnCalculate.Size = new System.Drawing.Size(169, 38);
            this.BtnCalculate.TabIndex = 5;
            this.BtnCalculate.Text = "Рассчитать";
            this.BtnCalculate.UseVisualStyleBackColor = false;
            this.BtnCalculate.Click += new System.EventHandler(this.BtnCalculate_Click);
            // 
            // TxbResult
            // 
            this.TxbResult.Location = new System.Drawing.Point(470, 91);
            this.TxbResult.Name = "TxbResult";
            this.TxbResult.ReadOnly = true;
            this.TxbResult.Size = new System.Drawing.Size(247, 23);
            this.TxbResult.TabIndex = 6;
            // 
            // LblFirstNum
            // 
            this.LblFirstNum.Location = new System.Drawing.Point(227, 103);
            this.LblFirstNum.Name = "LblFirstNum";
            this.LblFirstNum.Size = new System.Drawing.Size(131, 20);
            this.LblFirstNum.TabIndex = 7;
            this.LblFirstNum.Text = "Первый операнд: ";
            // 
            // LblSecndNum
            // 
            this.LblSecndNum.Location = new System.Drawing.Point(227, 161);
            this.LblSecndNum.Name = "LblSecndNum";
            this.LblSecndNum.Size = new System.Drawing.Size(131, 20);
            this.LblSecndNum.TabIndex = 8;
            this.LblSecndNum.Text = "Второй операнд: ";
            // 
            // LblResult
            // 
            this.LblResult.Location = new System.Drawing.Point(470, 73);
            this.LblResult.Name = "LblResult";
            this.LblResult.Size = new System.Drawing.Size(131, 20);
            this.LblResult.TabIndex = 9;
            this.LblResult.Text = "Результат: ";
            // 
            // TxbHistory
            // 
            this.TxbHistory.Location = new System.Drawing.Point(470, 149);
            this.TxbHistory.Multiline = true;
            this.TxbHistory.Name = "TxbHistory";
            this.TxbHistory.ReadOnly = true;
            this.TxbHistory.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.TxbHistory.Size = new System.Drawing.Size(247, 209);
            this.TxbHistory.TabIndex = 10;
            // 
            // LblHistory
            // 
            this.LblHistory.Location = new System.Drawing.Point(470, 130);
            this.LblHistory.Name = "LblHistory";
            this.LblHistory.Size = new System.Drawing.Size(153, 20);
            this.LblHistory.TabIndex = 11;
            this.LblHistory.Text = "История операций: ";
            // 
            // BtnClear
            // 
            this.BtnClear.BackColor = System.Drawing.Color.Red;
            this.BtnClear.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.BtnClear.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.BtnClear.Location = new System.Drawing.Point(638, 124);
            this.BtnClear.Name = "BtnClear";
            this.BtnClear.Size = new System.Drawing.Size(79, 23);
            this.BtnClear.TabIndex = 12;
            this.BtnClear.Text = "Очистить";
            this.BtnClear.UseVisualStyleBackColor = false;
            this.BtnClear.Click += new System.EventHandler(this.BtnClear_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.WhiteSmoke;
            this.ClientSize = new System.Drawing.Size(747, 382);
            this.Controls.Add(this.BtnClear);
            this.Controls.Add(this.TxbHistory);
            this.Controls.Add(this.LblFirstNum);
            this.Controls.Add(this.TxbResult);
            this.Controls.Add(this.BtnCalculate);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.BrbOperations);
            this.Controls.Add(this.NudSecndNum);
            this.Controls.Add(this.NudFirstNum);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.LblSecndNum);
            this.Controls.Add(this.LblHistory);
            this.Controls.Add(this.LblResult);
            this.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.MaximizeBox = false;
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Задание на 03.11.2021";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.NudFirstNum)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NudSecndNum)).EndInit();
            this.BrbOperations.ResumeLayout(false);
            this.BrbOperations.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.NumericUpDown NudFirstNum;
        private System.Windows.Forms.NumericUpDown NudSecndNum;
        private System.Windows.Forms.GroupBox BrbOperations;
        private System.Windows.Forms.RadioButton RdbAddition;
        private System.Windows.Forms.RadioButton RdbSubtraction;
        private System.Windows.Forms.LinkLabel LnlQuit;
        private System.Windows.Forms.RadioButton RdbExponenriation;
        private System.Windows.Forms.RadioButton RdbSqrt;
        private System.Windows.Forms.RadioButton RdbSinus;
        private System.Windows.Forms.RadioButton RdbDivision;
        private System.Windows.Forms.RadioButton RdbMultiplication;
        private System.Windows.Forms.LinkLabel LnlJournal;
        private System.Windows.Forms.LinkLabel LnlAbout;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.RadioButton RdbRadians;
        private System.Windows.Forms.RadioButton RdbDegrees;
        private System.Windows.Forms.Button BtnCalculate;
        private System.Windows.Forms.TextBox TxbResult;
        private System.Windows.Forms.Label LblFirstNum;
        private System.Windows.Forms.Label LblSecndNum;
        private System.Windows.Forms.Label LblResult;
        private System.Windows.Forms.TextBox TxbHistory;
        private System.Windows.Forms.Label LblHistory;
        private System.Windows.Forms.Button BtnClear;
    }
}

