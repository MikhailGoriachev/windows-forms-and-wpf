﻿namespace Main.Common
{
	internal interface IPresenter
	{
		void Run();
	}
}