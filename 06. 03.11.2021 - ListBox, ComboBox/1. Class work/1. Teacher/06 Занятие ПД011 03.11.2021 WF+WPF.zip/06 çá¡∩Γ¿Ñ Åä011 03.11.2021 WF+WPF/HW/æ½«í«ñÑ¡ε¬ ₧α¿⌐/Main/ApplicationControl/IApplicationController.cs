﻿using Main.Common;
using Microsoft.Extensions.Configuration;
using Serilog;


namespace Main.ApplicationControl
{
	internal interface IApplicationController
	{
		public IConfiguration AppConfig { get; }
		public ILogger AppLogger { get; }


		void Run<TPresenter>() where TPresenter : IPresenter;
	}
}