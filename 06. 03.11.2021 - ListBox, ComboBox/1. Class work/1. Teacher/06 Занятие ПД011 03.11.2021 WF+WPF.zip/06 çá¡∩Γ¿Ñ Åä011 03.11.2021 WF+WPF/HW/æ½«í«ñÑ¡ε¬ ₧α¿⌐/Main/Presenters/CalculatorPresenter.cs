﻿using System;
using Main.ApplicationControl;
using Main.Common;
using Main.Models;
using Main.Views;


namespace Main.Presenters
{
	internal sealed class CalculatorPresenter : BasePresenter<ICalculatorView>
	{
		public CalculatorPresenter(ICalculatorView view, IApplicationController controller)
			: base(view, controller)
		{
			view.OperationChanged += ViewOnOperationChanged;
			view.SolveRequested += ViewOnSolveRequested;
		}


		private object CollectInfoAboutOperation() =>
			new
			{
				Operation.GetType().Name,
				View.FirstOperand,
				View.SecondOperand
			};


		public IOperation Operation { get; set; }


		private void ViewOnOperationChanged(IOperation operation) =>
			Operation = operation;


		private void ViewOnSolveRequested()
		{
			try
			{
				double result = Operation.Solve();

				View.Result = $"{result:F}";

				Controller
					.AppLogger
					.Information("Process {@OperationInfo} with result {@result}",
						CollectInfoAboutOperation(), result);
			}
			catch (NullReferenceException e)
			{
				Controller.AppLogger.Error(e, "The operation was not selected");
			}
			catch (Exception e)
			{
				Controller.AppLogger.Error(e,
					"An error has occured {@OperationInfo}",
					CollectInfoAboutOperation());

				View.Result = double.NaN.ToString();
			}
		}
	}
}