﻿using System;
using System.Windows.Forms;
using Main.Common;


namespace Main.Views
{
	internal interface ILoggerView : IView
	{
		public string[] Logs { set; }

		public event Action LoadingLogs;
		public event Action LogsDeleting;
	}


	public sealed partial class LoggerForm : BaseForm, ILoggerView
	{
		public string[] Logs { set => LogsTextBox.Lines = value; }
		public event Action LoadingLogs;
		public event Action LogsDeleting;


		public void Show() => ShowDialog();


		public LoggerForm() =>
			InitializeComponent();


		private void ClearLogButton_Click(object sender, EventArgs e) =>
			LogsDeleting?.Invoke();


		private void LoggerForm_Load(object sender, EventArgs e) =>
			LoadingLogs?.Invoke();
	}
}