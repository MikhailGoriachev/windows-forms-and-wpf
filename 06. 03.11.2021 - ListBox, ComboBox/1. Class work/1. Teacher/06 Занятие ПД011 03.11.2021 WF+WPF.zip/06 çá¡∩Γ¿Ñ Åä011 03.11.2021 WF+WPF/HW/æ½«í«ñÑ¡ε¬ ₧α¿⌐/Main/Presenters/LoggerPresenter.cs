﻿using System;
using System.Collections.Generic;
using System.IO;
using Main.ApplicationControl;
using Main.Common;
using Main.Views;


namespace Main.Presenters
{
	internal sealed class LoggerPresenter : BasePresenter<ILoggerView>
	{
		public LoggerPresenter(ILoggerView view, IApplicationController controller)
			: base(view, controller)
		{
			view.LoadingLogs += ViewOnLoadingLogs;
			view.LogsDeleting += ViewOnLogsDeleting;
		}


		private readonly struct Log
		{
			public Log(DateTime timestamp) =>
				Timestamp = timestamp;


			public DateTime Timestamp { get; }
		}


		private void ViewOnLoadingLogs()
		{
			var path = Controller.AppConfig.GetFilePathForSerilog();

			var logFile = Controller.AppLogger.GetSharedWithLoggerFile(path);

			List<string> lines = new List<string>();
			using (var reader = new StreamReader(logFile))
			{
				while (!logFile.IsEndOfFile())
					lines.Add(reader.ReadLine());
			}

			View.Logs = lines.ToArray();
		}


		private void ViewOnLogsDeleting()
		{
			var path = Controller.AppConfig.GetFilePathForSerilog();

			using var logFile = Controller.AppLogger.GetSharedWithLoggerFile(path);
			logFile.SetLength(0L);
		}
	}
}