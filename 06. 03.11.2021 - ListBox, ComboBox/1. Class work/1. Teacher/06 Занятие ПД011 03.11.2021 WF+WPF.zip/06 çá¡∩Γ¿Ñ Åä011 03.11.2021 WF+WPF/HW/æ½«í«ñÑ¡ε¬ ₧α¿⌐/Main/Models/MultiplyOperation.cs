﻿namespace Main.Models
{
	internal sealed class MultiplyOperation : BinaryOperation
	{
		public MultiplyOperation(double firstOperand, double secondOperand)
			: base(firstOperand, secondOperand) { }


		public override double Solve() => FirstOperand * SecondOperand;
	}
}