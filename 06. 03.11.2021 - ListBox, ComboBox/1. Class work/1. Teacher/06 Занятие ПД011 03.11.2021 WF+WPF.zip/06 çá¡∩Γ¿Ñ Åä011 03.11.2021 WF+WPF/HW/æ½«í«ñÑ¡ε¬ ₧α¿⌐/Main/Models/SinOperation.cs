﻿using System;


namespace Main.Models
{
	public enum AngleType
	{
		Radian, Degree
	}


	internal sealed class SinOperation : UnaryOperation
	{
		public AngleType Angle { get; }


		public SinOperation(double firstOperand, AngleType angle) : base(firstOperand) =>
			Angle = angle;


		public override double Solve() =>
			Math.Sin(Angle == AngleType.Degree
						 ? FirstOperand * Math.PI / 180d
						 : FirstOperand);
	}
}