﻿namespace Main.Models
{
	internal sealed class MinusOperation : BinaryOperation
	{
		public MinusOperation(double firstOperand, double secondOperand)
			: base(firstOperand, secondOperand) { }


		public override double Solve() => FirstOperand - SecondOperand;
	}
}