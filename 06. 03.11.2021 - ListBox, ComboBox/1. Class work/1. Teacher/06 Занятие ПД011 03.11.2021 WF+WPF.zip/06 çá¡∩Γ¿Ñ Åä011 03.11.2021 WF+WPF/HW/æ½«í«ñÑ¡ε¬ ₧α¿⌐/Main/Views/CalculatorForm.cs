﻿using System;
using System.Linq;
using System.Windows.Forms;
using Main.Common;
using Main.Models;


namespace Main.Views
{
	internal interface ICalculatorView : IView
	{
		public double FirstOperand { get; }


		public event Action<IOperation> OperationChanged;
		public string Result { set; }
		public double SecondOperand { get; }

		public event Action SolveRequested;
	}


	public sealed partial class CalculatorForm : BaseForm, ICalculatorView
	{
		public double FirstOperand { init; get; }

		public event Action<IOperation> OperationChanged;

		public string Result { set => ResultTextBox.Text = value; }

		public double SecondOperand { init; get; }

		public event Action SolveRequested;


		public new void Show() => ShowDialog();


		public CalculatorForm()
		{
			InitializeComponent();

			var numerics = InputGroupBox
						   .Controls.OfType<NumericUpDown>();
			foreach (var numericUpDown in numerics)
			{
				numericUpDown.Minimum = decimal.MinValue;
				numericUpDown.Maximum = decimal.MaxValue;
			}

			FirstOperandNumeric
				.DataBindings
				.Add("Value", this, nameof(FirstOperand));

			SecondOperandNumeric
				.DataBindings
				.Add("Value", this, nameof(SecondOperand));
		}


		private void OperationChange(IOperation operation) =>
			OperationChanged?.Invoke(operation);


		private void SolveButton_Click(object sender, EventArgs e) =>
			SolveRequested?.Invoke();


	#region Смена операции

		private void PlusButton_Click(object sender, EventArgs e) =>
			OperationChange(new PlusOperation(FirstOperand, SecondOperand));


		private void MinusButton_Click(object sender, EventArgs e) =>
			OperationChange(new MinusOperation(FirstOperand, SecondOperand));


		private void MultiplyButton_Click(object sender, EventArgs e) =>
			OperationChange(new MultiplyOperation(FirstOperand, SecondOperand));


		private void DivideButton_Click(object sender, EventArgs e) =>
			OperationChange(new DivideOperation(FirstOperand, SecondOperand));


		private void SinButton_Click(object sender, EventArgs e) =>
			OperationChange(new SinOperation(FirstOperand,
				DegreeRadioButton.Checked ? AngleType.Degree : AngleType.Radian));


		private void SquareRootButton_Click(object sender, EventArgs e) =>
			OperationChange(new SquareRootOperation(FirstOperand));


		private void PowButton_Click(object sender, EventArgs e) =>
			OperationChange(new PoweringOperation(FirstOperand, SecondOperand));

	#endregion
	}
}