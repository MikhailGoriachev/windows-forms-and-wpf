﻿namespace Main.Models
{
	internal abstract class BinaryOperation : IOperation
	{
		public double FirstOperand { get; }

		public double SecondOperand { get; }


		protected BinaryOperation(double firstOperand, double secondOperand)
		{
			FirstOperand = firstOperand;
			SecondOperand = secondOperand;
		}


		public abstract double Solve();
	}
}