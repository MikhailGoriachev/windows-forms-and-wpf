﻿using System.IO;
using System.Windows.Forms;
using Autofac;
using Autofac.Features.ResolveAnything;
using Main.Common;
using Main.Views;
using Microsoft.Extensions.Configuration;
using Serilog;


namespace Main.ApplicationControl
{
	internal sealed class ApplicationController : IApplicationController
	{
		private IContainer Container { get; }
		public IConfiguration AppConfig { get; }
		public ILogger AppLogger { get; }


		public ApplicationController()
		{
			Container = PrepareDependencies();
			AppConfig = GetConfigurationOfApplication();
			AppLogger = CreateJsonLogger();
		}


		private IContainer PrepareDependencies()
		{
			var builder = new ContainerBuilder();

			builder.RegisterInstance(this).As<IApplicationController>();
			builder.RegisterInstance(new ApplicationContext()).AsSelf();

			builder.RegisterType<MainMenuForm>().As<IMainMenuView>();
			builder.RegisterType<CalculatorForm>().As<ICalculatorView>();
			builder.RegisterType<LoggerForm>().As<ILoggerView>();
			builder.RegisterType<AboutProgramForm>().As<IAboutProgramView>();

			builder.RegisterSource<AnyConcreteTypeNotAlreadyRegisteredSource>();
			return builder.Build();
		}


		private IConfiguration GetConfigurationOfApplication() =>
			new ConfigurationBuilder()
				.SetBasePath(Directory.GetCurrentDirectory())
				.AddJsonFile("AppSettings.json")
				.Build();


		private ILogger CreateJsonLogger() =>
			new LoggerConfiguration()
				.ReadFrom.Configuration(AppConfig)
				.CreateLogger();


		public void Run<TPresenter>() where TPresenter : IPresenter => 
			Container.Resolve<TPresenter>().Run();
	}
}