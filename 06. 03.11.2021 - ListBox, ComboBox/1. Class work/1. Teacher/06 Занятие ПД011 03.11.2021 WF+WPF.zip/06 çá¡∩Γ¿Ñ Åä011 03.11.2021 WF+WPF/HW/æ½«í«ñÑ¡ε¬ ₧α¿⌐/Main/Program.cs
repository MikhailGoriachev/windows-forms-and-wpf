using System;
using System.Windows.Forms;
using Main.ApplicationControl;
using Main.Presenters;


namespace Main
{
	internal static class Program
	{
		[STAThread]
		private static void Main()
		{
			Application.SetHighDpiMode(HighDpiMode.SystemAware);
			Application.EnableVisualStyles();
			Application.SetCompatibleTextRenderingDefault(false);

			new ApplicationController()
				.Run<MainMenuPresenter>();
		}
	}
}