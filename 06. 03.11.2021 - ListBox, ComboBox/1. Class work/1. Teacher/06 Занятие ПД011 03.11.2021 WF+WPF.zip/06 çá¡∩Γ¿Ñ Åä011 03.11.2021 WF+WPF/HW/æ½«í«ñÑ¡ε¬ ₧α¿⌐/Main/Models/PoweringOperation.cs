﻿using System;


namespace Main.Models
{
	internal sealed class PoweringOperation : BinaryOperation
	{
		public PoweringOperation(double firstOperand, double secondOperand)
			: base(firstOperand, secondOperand) { }


		public override double Solve() => Math.Pow(FirstOperand, SecondOperand);
	}
}