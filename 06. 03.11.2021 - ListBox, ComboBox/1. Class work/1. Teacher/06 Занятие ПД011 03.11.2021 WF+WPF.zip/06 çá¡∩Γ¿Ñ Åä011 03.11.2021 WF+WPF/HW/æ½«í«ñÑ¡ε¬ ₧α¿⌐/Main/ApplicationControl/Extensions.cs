﻿using System.IO;
using Microsoft.Extensions.Configuration;
using Serilog;


namespace Main.ApplicationControl
{
	internal static class Extensions
	{
		public static string GetFilePathForSerilog(this IConfiguration configuration) =>
			configuration.GetValue<string>("Serilog:WriteTo:0:Args:path");


		public static FileStream GetSharedWithLoggerFile(this ILogger logger, string path) =>
			File.Open(path, FileMode.Open, FileAccess.ReadWrite, FileShare.ReadWrite);


		public static bool IsEndOfFile(this FileStream file) =>
			file.Position >= file.Length;
	}
}