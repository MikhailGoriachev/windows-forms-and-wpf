﻿
namespace Main.Views
{
	sealed partial class CalculatorForm
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CalculatorForm));
			this.MainGrid = new System.Windows.Forms.TableLayoutPanel();
			this.SolveGroupBox = new System.Windows.Forms.GroupBox();
			this.SolveButton = new System.Windows.Forms.Button();
			this.AngleFormatGroupBox = new System.Windows.Forms.GroupBox();
			this.RadianRadioButton = new System.Windows.Forms.RadioButton();
			this.DegreeRadioButton = new System.Windows.Forms.RadioButton();
			this.ResultGroupBox = new System.Windows.Forms.GroupBox();
			this.ResultLabel = new System.Windows.Forms.Label();
			this.ResultTextBox = new System.Windows.Forms.TextBox();
			this.OperationsGroupBox = new System.Windows.Forms.GroupBox();
			this.OperationsFlowPanel = new System.Windows.Forms.FlowLayoutPanel();
			this.PlusButton = new System.Windows.Forms.Button();
			this.MinusButton = new System.Windows.Forms.Button();
			this.MultiplyButton = new System.Windows.Forms.Button();
			this.DivideButton = new System.Windows.Forms.Button();
			this.SinButton = new System.Windows.Forms.Button();
			this.SquareRootButton = new System.Windows.Forms.Button();
			this.PowButton = new System.Windows.Forms.Button();
			this.InputGroupBox = new System.Windows.Forms.GroupBox();
			this.SecondOperandLabel = new System.Windows.Forms.Label();
			this.SecondOperandNumeric = new System.Windows.Forms.NumericUpDown();
			this.FirstOperandLabel = new System.Windows.Forms.Label();
			this.FirstOperandNumeric = new System.Windows.Forms.NumericUpDown();
			this.MainGrid.SuspendLayout();
			this.SolveGroupBox.SuspendLayout();
			this.AngleFormatGroupBox.SuspendLayout();
			this.ResultGroupBox.SuspendLayout();
			this.OperationsGroupBox.SuspendLayout();
			this.OperationsFlowPanel.SuspendLayout();
			this.InputGroupBox.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.SecondOperandNumeric)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.FirstOperandNumeric)).BeginInit();
			this.SuspendLayout();
			// 
			// MainGrid
			// 
			this.MainGrid.ColumnCount = 2;
			this.MainGrid.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 73.96529F));
			this.MainGrid.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 26.03471F));
			this.MainGrid.Controls.Add(this.SolveGroupBox, 1, 1);
			this.MainGrid.Controls.Add(this.AngleFormatGroupBox, 1, 0);
			this.MainGrid.Controls.Add(this.ResultGroupBox, 0, 1);
			this.MainGrid.Controls.Add(this.OperationsGroupBox, 1, 1);
			this.MainGrid.Controls.Add(this.InputGroupBox, 0, 0);
			this.MainGrid.Dock = System.Windows.Forms.DockStyle.Fill;
			this.MainGrid.Location = new System.Drawing.Point(0, 0);
			this.MainGrid.Name = "MainGrid";
			this.MainGrid.RowCount = 3;
			this.MainGrid.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 36.15639F));
			this.MainGrid.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 36.14198F));
			this.MainGrid.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 27.70163F));
			this.MainGrid.Size = new System.Drawing.Size(749, 462);
			this.MainGrid.TabIndex = 0;
			// 
			// SolveGroupBox
			// 
			this.SolveGroupBox.Controls.Add(this.SolveButton);
			this.SolveGroupBox.Dock = System.Windows.Forms.DockStyle.Fill;
			this.SolveGroupBox.Location = new System.Drawing.Point(557, 170);
			this.SolveGroupBox.Name = "SolveGroupBox";
			this.SolveGroupBox.Size = new System.Drawing.Size(189, 160);
			this.SolveGroupBox.TabIndex = 2;
			this.SolveGroupBox.TabStop = false;
			// 
			// SolveButton
			// 
			this.SolveButton.Anchor = System.Windows.Forms.AnchorStyles.None;
			this.SolveButton.AutoSize = true;
			this.SolveButton.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
			this.SolveButton.Location = new System.Drawing.Point(23, 59);
			this.SolveButton.Name = "SolveButton";
			this.SolveButton.Size = new System.Drawing.Size(143, 42);
			this.SolveButton.TabIndex = 0;
			this.SolveButton.Text = "Вычислить";
			this.SolveButton.UseVisualStyleBackColor = true;
			this.SolveButton.Click += new System.EventHandler(this.SolveButton_Click);
			// 
			// AngleFormatGroupBox
			// 
			this.AngleFormatGroupBox.Controls.Add(this.RadianRadioButton);
			this.AngleFormatGroupBox.Controls.Add(this.DegreeRadioButton);
			this.AngleFormatGroupBox.Dock = System.Windows.Forms.DockStyle.Fill;
			this.AngleFormatGroupBox.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
			this.AngleFormatGroupBox.Location = new System.Drawing.Point(557, 3);
			this.AngleFormatGroupBox.Name = "AngleFormatGroupBox";
			this.AngleFormatGroupBox.Size = new System.Drawing.Size(189, 161);
			this.AngleFormatGroupBox.TabIndex = 1;
			this.AngleFormatGroupBox.TabStop = false;
			this.AngleFormatGroupBox.Text = "Формат угла";
			// 
			// RadianRadioButton
			// 
			this.RadianRadioButton.Anchor = System.Windows.Forms.AnchorStyles.None;
			this.RadianRadioButton.AutoSize = true;
			this.RadianRadioButton.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
			this.RadianRadioButton.Location = new System.Drawing.Point(49, 92);
			this.RadianRadioButton.Name = "RadianRadioButton";
			this.RadianRadioButton.Size = new System.Drawing.Size(91, 25);
			this.RadianRadioButton.TabIndex = 1;
			this.RadianRadioButton.Text = "Радианы";
			this.RadianRadioButton.UseVisualStyleBackColor = true;
			// 
			// DegreeRadioButton
			// 
			this.DegreeRadioButton.Anchor = System.Windows.Forms.AnchorStyles.None;
			this.DegreeRadioButton.AutoSize = true;
			this.DegreeRadioButton.Checked = true;
			this.DegreeRadioButton.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
			this.DegreeRadioButton.Location = new System.Drawing.Point(51, 44);
			this.DegreeRadioButton.Name = "DegreeRadioButton";
			this.DegreeRadioButton.Size = new System.Drawing.Size(88, 25);
			this.DegreeRadioButton.TabIndex = 0;
			this.DegreeRadioButton.TabStop = true;
			this.DegreeRadioButton.Text = "Градусы";
			this.DegreeRadioButton.UseVisualStyleBackColor = true;
			// 
			// ResultGroupBox
			// 
			this.ResultGroupBox.Controls.Add(this.ResultLabel);
			this.ResultGroupBox.Controls.Add(this.ResultTextBox);
			this.ResultGroupBox.Dock = System.Windows.Forms.DockStyle.Fill;
			this.ResultGroupBox.Location = new System.Drawing.Point(3, 170);
			this.ResultGroupBox.Name = "ResultGroupBox";
			this.ResultGroupBox.Size = new System.Drawing.Size(548, 160);
			this.ResultGroupBox.TabIndex = 2;
			this.ResultGroupBox.TabStop = false;
			// 
			// ResultLabel
			// 
			this.ResultLabel.Anchor = System.Windows.Forms.AnchorStyles.None;
			this.ResultLabel.AutoSize = true;
			this.ResultLabel.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
			this.ResultLabel.Location = new System.Drawing.Point(58, 65);
			this.ResultLabel.Name = "ResultLabel";
			this.ResultLabel.Size = new System.Drawing.Size(117, 30);
			this.ResultLabel.TabIndex = 1;
			this.ResultLabel.Text = "Результат: ";
			// 
			// ResultTextBox
			// 
			this.ResultTextBox.Anchor = System.Windows.Forms.AnchorStyles.None;
			this.ResultTextBox.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
			this.ResultTextBox.Location = new System.Drawing.Point(186, 60);
			this.ResultTextBox.Multiline = true;
			this.ResultTextBox.Name = "ResultTextBox";
			this.ResultTextBox.ReadOnly = true;
			this.ResultTextBox.Size = new System.Drawing.Size(304, 40);
			this.ResultTextBox.TabIndex = 0;
			// 
			// OperationsGroupBox
			// 
			this.MainGrid.SetColumnSpan(this.OperationsGroupBox, 2);
			this.OperationsGroupBox.Controls.Add(this.OperationsFlowPanel);
			this.OperationsGroupBox.Dock = System.Windows.Forms.DockStyle.Fill;
			this.OperationsGroupBox.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
			this.OperationsGroupBox.Location = new System.Drawing.Point(3, 336);
			this.OperationsGroupBox.Name = "OperationsGroupBox";
			this.OperationsGroupBox.Size = new System.Drawing.Size(743, 123);
			this.OperationsGroupBox.TabIndex = 0;
			this.OperationsGroupBox.TabStop = false;
			this.OperationsGroupBox.Text = "Операции";
			// 
			// OperationsFlowPanel
			// 
			this.OperationsFlowPanel.Controls.Add(this.PlusButton);
			this.OperationsFlowPanel.Controls.Add(this.MinusButton);
			this.OperationsFlowPanel.Controls.Add(this.MultiplyButton);
			this.OperationsFlowPanel.Controls.Add(this.DivideButton);
			this.OperationsFlowPanel.Controls.Add(this.SinButton);
			this.OperationsFlowPanel.Controls.Add(this.SquareRootButton);
			this.OperationsFlowPanel.Controls.Add(this.PowButton);
			this.OperationsFlowPanel.Dock = System.Windows.Forms.DockStyle.Fill;
			this.OperationsFlowPanel.Location = new System.Drawing.Point(3, 21);
			this.OperationsFlowPanel.Name = "OperationsFlowPanel";
			this.OperationsFlowPanel.Size = new System.Drawing.Size(737, 99);
			this.OperationsFlowPanel.TabIndex = 0;
			// 
			// PlusButton
			// 
			this.PlusButton.Anchor = System.Windows.Forms.AnchorStyles.None;
			this.PlusButton.BackgroundImage = global::Main.Properties.Resources.PlusIcon;
			this.PlusButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
			this.PlusButton.Location = new System.Drawing.Point(12, 3);
			this.PlusButton.Margin = new System.Windows.Forms.Padding(12, 3, 12, 3);
			this.PlusButton.Name = "PlusButton";
			this.PlusButton.Size = new System.Drawing.Size(80, 78);
			this.PlusButton.TabIndex = 0;
			this.PlusButton.UseVisualStyleBackColor = true;
			this.PlusButton.Click += new System.EventHandler(this.PlusButton_Click);
			// 
			// MinusButton
			// 
			this.MinusButton.Anchor = System.Windows.Forms.AnchorStyles.None;
			this.MinusButton.BackgroundImage = global::Main.Properties.Resources.MinusIcon;
			this.MinusButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
			this.MinusButton.Location = new System.Drawing.Point(116, 3);
			this.MinusButton.Margin = new System.Windows.Forms.Padding(12, 3, 12, 3);
			this.MinusButton.Name = "MinusButton";
			this.MinusButton.Size = new System.Drawing.Size(80, 78);
			this.MinusButton.TabIndex = 1;
			this.MinusButton.UseVisualStyleBackColor = true;
			this.MinusButton.Click += new System.EventHandler(this.MinusButton_Click);
			// 
			// MultiplyButton
			// 
			this.MultiplyButton.Anchor = System.Windows.Forms.AnchorStyles.None;
			this.MultiplyButton.BackgroundImage = global::Main.Properties.Resources.MultiplyIcon;
			this.MultiplyButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
			this.MultiplyButton.Location = new System.Drawing.Point(220, 3);
			this.MultiplyButton.Margin = new System.Windows.Forms.Padding(12, 3, 12, 3);
			this.MultiplyButton.Name = "MultiplyButton";
			this.MultiplyButton.Size = new System.Drawing.Size(80, 78);
			this.MultiplyButton.TabIndex = 2;
			this.MultiplyButton.UseVisualStyleBackColor = true;
			this.MultiplyButton.Click += new System.EventHandler(this.MultiplyButton_Click);
			// 
			// DivideButton
			// 
			this.DivideButton.Anchor = System.Windows.Forms.AnchorStyles.None;
			this.DivideButton.BackgroundImage = global::Main.Properties.Resources.DivideIcon;
			this.DivideButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
			this.DivideButton.Location = new System.Drawing.Point(324, 3);
			this.DivideButton.Margin = new System.Windows.Forms.Padding(12, 3, 12, 3);
			this.DivideButton.Name = "DivideButton";
			this.DivideButton.Size = new System.Drawing.Size(80, 78);
			this.DivideButton.TabIndex = 3;
			this.DivideButton.UseVisualStyleBackColor = true;
			this.DivideButton.Click += new System.EventHandler(this.DivideButton_Click);
			// 
			// SinButton
			// 
			this.SinButton.Anchor = System.Windows.Forms.AnchorStyles.None;
			this.SinButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
			this.SinButton.Font = new System.Drawing.Font("Segoe UI", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
			this.SinButton.Location = new System.Drawing.Point(428, 3);
			this.SinButton.Margin = new System.Windows.Forms.Padding(12, 3, 12, 3);
			this.SinButton.Name = "SinButton";
			this.SinButton.Size = new System.Drawing.Size(80, 78);
			this.SinButton.TabIndex = 4;
			this.SinButton.Text = "SIN";
			this.SinButton.UseVisualStyleBackColor = true;
			this.SinButton.Click += new System.EventHandler(this.SinButton_Click);
			// 
			// SquareRootButton
			// 
			this.SquareRootButton.Anchor = System.Windows.Forms.AnchorStyles.None;
			this.SquareRootButton.BackgroundImage = global::Main.Properties.Resources.SquareRootIcon;
			this.SquareRootButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
			this.SquareRootButton.Location = new System.Drawing.Point(532, 3);
			this.SquareRootButton.Margin = new System.Windows.Forms.Padding(12, 3, 12, 3);
			this.SquareRootButton.Name = "SquareRootButton";
			this.SquareRootButton.Size = new System.Drawing.Size(80, 78);
			this.SquareRootButton.TabIndex = 5;
			this.SquareRootButton.UseVisualStyleBackColor = true;
			this.SquareRootButton.Click += new System.EventHandler(this.SquareRootButton_Click);
			// 
			// PowButton
			// 
			this.PowButton.Anchor = System.Windows.Forms.AnchorStyles.None;
			this.PowButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
			this.PowButton.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
			this.PowButton.Location = new System.Drawing.Point(636, 3);
			this.PowButton.Margin = new System.Windows.Forms.Padding(12, 3, 12, 3);
			this.PowButton.Name = "PowButton";
			this.PowButton.Size = new System.Drawing.Size(80, 78);
			this.PowButton.TabIndex = 6;
			this.PowButton.Text = "POW";
			this.PowButton.UseVisualStyleBackColor = true;
			this.PowButton.Click += new System.EventHandler(this.PowButton_Click);
			// 
			// InputGroupBox
			// 
			this.InputGroupBox.Controls.Add(this.SecondOperandLabel);
			this.InputGroupBox.Controls.Add(this.SecondOperandNumeric);
			this.InputGroupBox.Controls.Add(this.FirstOperandLabel);
			this.InputGroupBox.Controls.Add(this.FirstOperandNumeric);
			this.InputGroupBox.Dock = System.Windows.Forms.DockStyle.Fill;
			this.InputGroupBox.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
			this.InputGroupBox.Location = new System.Drawing.Point(3, 3);
			this.InputGroupBox.Name = "InputGroupBox";
			this.InputGroupBox.Size = new System.Drawing.Size(548, 161);
			this.InputGroupBox.TabIndex = 1;
			this.InputGroupBox.TabStop = false;
			this.InputGroupBox.Text = "Ввод данных";
			// 
			// SecondOperandLabel
			// 
			this.SecondOperandLabel.Anchor = System.Windows.Forms.AnchorStyles.None;
			this.SecondOperandLabel.AutoSize = true;
			this.SecondOperandLabel.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
			this.SecondOperandLabel.Location = new System.Drawing.Point(326, 44);
			this.SecondOperandLabel.Name = "SecondOperandLabel";
			this.SecondOperandLabel.Size = new System.Drawing.Size(154, 25);
			this.SecondOperandLabel.TabIndex = 3;
			this.SecondOperandLabel.Text = "Второй операнд";
			// 
			// SecondOperandNumeric
			// 
			this.SecondOperandNumeric.Anchor = System.Windows.Forms.AnchorStyles.None;
			this.SecondOperandNumeric.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
			this.SecondOperandNumeric.Location = new System.Drawing.Point(326, 84);
			this.SecondOperandNumeric.Name = "SecondOperandNumeric";
			this.SecondOperandNumeric.Size = new System.Drawing.Size(160, 33);
			this.SecondOperandNumeric.TabIndex = 2;
			// 
			// FirstOperandLabel
			// 
			this.FirstOperandLabel.Anchor = System.Windows.Forms.AnchorStyles.None;
			this.FirstOperandLabel.AutoSize = true;
			this.FirstOperandLabel.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
			this.FirstOperandLabel.Location = new System.Drawing.Point(62, 44);
			this.FirstOperandLabel.Name = "FirstOperandLabel";
			this.FirstOperandLabel.Size = new System.Drawing.Size(160, 25);
			this.FirstOperandLabel.TabIndex = 1;
			this.FirstOperandLabel.Text = "Первый операнд";
			// 
			// FirstOperandNumeric
			// 
			this.FirstOperandNumeric.Anchor = System.Windows.Forms.AnchorStyles.None;
			this.FirstOperandNumeric.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
			this.FirstOperandNumeric.Location = new System.Drawing.Point(62, 84);
			this.FirstOperandNumeric.Name = "FirstOperandNumeric";
			this.FirstOperandNumeric.Size = new System.Drawing.Size(160, 33);
			this.FirstOperandNumeric.TabIndex = 0;
			// 
			// CalculatorForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(749, 462);
			this.Controls.Add(this.MainGrid);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.MaximizeBox = false;
			this.Name = "CalculatorForm";
			this.ShowInTaskbar = false;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Калькулятор";
			this.MainGrid.ResumeLayout(false);
			this.SolveGroupBox.ResumeLayout(false);
			this.SolveGroupBox.PerformLayout();
			this.AngleFormatGroupBox.ResumeLayout(false);
			this.AngleFormatGroupBox.PerformLayout();
			this.ResultGroupBox.ResumeLayout(false);
			this.ResultGroupBox.PerformLayout();
			this.OperationsGroupBox.ResumeLayout(false);
			this.OperationsFlowPanel.ResumeLayout(false);
			this.InputGroupBox.ResumeLayout(false);
			this.InputGroupBox.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.SecondOperandNumeric)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.FirstOperandNumeric)).EndInit();
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.TableLayoutPanel MainGrid;
		private System.Windows.Forms.GroupBox OperationsGroupBox;
		private System.Windows.Forms.GroupBox InputGroupBox;
		private System.Windows.Forms.Button SolveButton;
		private System.Windows.Forms.Label ResultLabel;
		private System.Windows.Forms.TextBox ResultTextBox;
		private System.Windows.Forms.Label FirstOperandLabel;
		private System.Windows.Forms.NumericUpDown FirstOperandNumeric;
		private System.Windows.Forms.Label SecondOperandLabel;
		private System.Windows.Forms.NumericUpDown SecondOperandNumeric;
		private System.Windows.Forms.GroupBox AngleFormatGroupBox;
		private System.Windows.Forms.RadioButton RadianRadioButton;
		private System.Windows.Forms.RadioButton DegreeRadioButton;
		private System.Windows.Forms.FlowLayoutPanel OperationsFlowPanel;
		private System.Windows.Forms.Button PlusButton;
		private System.Windows.Forms.Button MinusButton;
		private System.Windows.Forms.Button MultiplyButton;
		private System.Windows.Forms.Button DivideButton;
		private System.Windows.Forms.Button SinButton;
		private System.Windows.Forms.Button SquareRootButton;
		private System.Windows.Forms.Button PowButton;
		private System.Windows.Forms.GroupBox ResultGroupBox;
		private System.Windows.Forms.GroupBox SolveGroupBox;
	}
}