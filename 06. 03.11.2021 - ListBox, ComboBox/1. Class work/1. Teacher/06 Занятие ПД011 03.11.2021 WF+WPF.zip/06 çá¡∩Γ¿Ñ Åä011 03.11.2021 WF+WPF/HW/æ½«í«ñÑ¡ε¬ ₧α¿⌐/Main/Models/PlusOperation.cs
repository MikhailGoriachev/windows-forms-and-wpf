﻿namespace Main.Models
{
	internal sealed class PlusOperation : BinaryOperation
	{
		public PlusOperation(double firstOperand, double secondOperand)
			: base(firstOperand, secondOperand) { }


		public override double Solve() => FirstOperand + SecondOperand;
	}
}