﻿using System;


namespace Main.Models
{
	internal sealed class SquareRootOperation : UnaryOperation
	{
		public SquareRootOperation(double firstOperand) : base(firstOperand) { }


		public override double Solve() => Math.Sqrt(FirstOperand);
	}
}