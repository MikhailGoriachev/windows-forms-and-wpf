﻿using System;


namespace Main.Models
{
	internal sealed class DivideOperation : BinaryOperation
	{
		public DivideOperation(double firstOperand, double secondOperand)
			: base(firstOperand, secondOperand) { }


		public override double Solve()
		{
			if (SecondOperand < 0.01)
				throw new DivideByZeroException();

			return FirstOperand / SecondOperand;
		}
	}
}