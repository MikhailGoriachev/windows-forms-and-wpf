﻿using Main.ApplicationControl;
using Main.Common;
using Main.Views;


namespace Main.Presenters
{
	internal sealed class AboutProgramPresenter : BasePresenter<IAboutProgramView>
	{
		public AboutProgramPresenter(IAboutProgramView view, IApplicationController controller)
			: base(view, controller) =>
			view.TimerTick += () => View.Close();
	}
}