﻿using System;
using Main.Common;


namespace Main.Views
{
	internal interface IAboutProgramView : IView
	{
		public event Action TimerTick;
	}


	public sealed partial class AboutProgramForm : BaseForm, IAboutProgramView
	{
		public event Action TimerTick;


		public new void Show() => ShowDialog();


		public AboutProgramForm() => InitializeComponent();


		private void MainTimer_Tick(object sender, EventArgs e) => TimerTick?.Invoke();
	}
}