﻿using Main.ApplicationControl;
using Main.Common;
using Main.Views;


namespace Main.Presenters
{
	internal sealed class MainMenuPresenter : BasePresenter<IMainMenuView>
	{
		public MainMenuPresenter(IMainMenuView view, IApplicationController controller)
			: base(view, controller)
		{
			View.CalculateFormCall += () => Controller.Run<CalculatorPresenter>(); 

			View.LoggerFormCall += () => Controller.Run<LoggerPresenter>(); 

			View.AboutProgramFormCall += () => Controller.Run<AboutProgramPresenter>(); 
		}
	}
}