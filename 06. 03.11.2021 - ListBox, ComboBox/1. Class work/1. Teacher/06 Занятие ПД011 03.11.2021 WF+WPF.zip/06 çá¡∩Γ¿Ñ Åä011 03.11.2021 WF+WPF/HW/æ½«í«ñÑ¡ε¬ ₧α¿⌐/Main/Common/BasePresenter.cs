﻿using Main.ApplicationControl;


namespace Main.Common
{
	internal class BasePresenter<TView> : IPresenter
		where TView : IView
	{
		public void Run() => View.Show();


		protected BasePresenter(TView view, IApplicationController controller)
		{
			View = view;
			Controller = controller;
		}


		protected IApplicationController Controller { get; }


		protected TView View { get; }
	}
}