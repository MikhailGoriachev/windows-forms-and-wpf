﻿namespace Main.Models
{
	internal abstract class UnaryOperation : IOperation
	{
		public double FirstOperand { get; }


		protected UnaryOperation(double firstOperand) =>
			FirstOperand = firstOperand;


		public abstract double Solve();
	}
}