﻿
namespace Main.Views
{
	partial class LoggerForm
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.MainGrid = new System.Windows.Forms.TableLayoutPanel();
			this.ClearLogPanel = new System.Windows.Forms.Panel();
			this.ClearLogButton = new System.Windows.Forms.Button();
			this.LogsTextBox = new System.Windows.Forms.TextBox();
			this.MainGrid.SuspendLayout();
			this.ClearLogPanel.SuspendLayout();
			this.SuspendLayout();
			// 
			// MainGrid
			// 
			this.MainGrid.ColumnCount = 1;
			this.MainGrid.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
			this.MainGrid.Controls.Add(this.ClearLogPanel, 0, 1);
			this.MainGrid.Controls.Add(this.LogsTextBox, 0, 0);
			this.MainGrid.Dock = System.Windows.Forms.DockStyle.Fill;
			this.MainGrid.Location = new System.Drawing.Point(0, 0);
			this.MainGrid.Name = "MainGrid";
			this.MainGrid.RowCount = 2;
			this.MainGrid.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 83.30523F));
			this.MainGrid.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.69477F));
			this.MainGrid.Size = new System.Drawing.Size(1243, 593);
			this.MainGrid.TabIndex = 0;
			// 
			// ClearLogPanel
			// 
			this.ClearLogPanel.Controls.Add(this.ClearLogButton);
			this.ClearLogPanel.Dock = System.Windows.Forms.DockStyle.Fill;
			this.ClearLogPanel.Location = new System.Drawing.Point(3, 497);
			this.ClearLogPanel.Name = "ClearLogPanel";
			this.ClearLogPanel.Size = new System.Drawing.Size(1237, 93);
			this.ClearLogPanel.TabIndex = 1;
			// 
			// ClearLogButton
			// 
			this.ClearLogButton.Location = new System.Drawing.Point(510, 18);
			this.ClearLogButton.Name = "ClearLogButton";
			this.ClearLogButton.Size = new System.Drawing.Size(216, 56);
			this.ClearLogButton.TabIndex = 0;
			this.ClearLogButton.Text = "Очистить журнал";
			this.ClearLogButton.UseVisualStyleBackColor = true;
			this.ClearLogButton.Click += new System.EventHandler(this.ClearLogButton_Click);
			// 
			// LogsTextBox
			// 
			this.LogsTextBox.Dock = System.Windows.Forms.DockStyle.Fill;
			this.LogsTextBox.Font = new System.Drawing.Font("Consolas", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
			this.LogsTextBox.Location = new System.Drawing.Point(3, 3);
			this.LogsTextBox.Multiline = true;
			this.LogsTextBox.Name = "LogsTextBox";
			this.LogsTextBox.ReadOnly = true;
			this.LogsTextBox.Size = new System.Drawing.Size(1237, 488);
			this.LogsTextBox.TabIndex = 2;
			// 
			// LoggerForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 30F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(1243, 593);
			this.Controls.Add(this.MainGrid);
			this.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
			this.MaximizeBox = false;
			this.Name = "LoggerForm";
			this.ShowInTaskbar = false;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Журнал";
			this.Load += new System.EventHandler(this.LoggerForm_Load);
			this.MainGrid.ResumeLayout(false);
			this.MainGrid.PerformLayout();
			this.ClearLogPanel.ResumeLayout(false);
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.TableLayoutPanel MainGrid;
		private System.Windows.Forms.Panel ClearLogPanel;
		private System.Windows.Forms.Button ClearLogButton;
		private System.Windows.Forms.TextBox LogsTextBox;
	}
}