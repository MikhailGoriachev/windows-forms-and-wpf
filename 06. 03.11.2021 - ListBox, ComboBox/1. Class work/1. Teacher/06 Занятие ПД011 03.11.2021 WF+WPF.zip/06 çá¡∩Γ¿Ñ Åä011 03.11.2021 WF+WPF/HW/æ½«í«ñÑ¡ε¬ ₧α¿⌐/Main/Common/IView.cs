﻿namespace Main.Common
{
	internal interface IView
	{
		void Close();

		void Show();
	}
}