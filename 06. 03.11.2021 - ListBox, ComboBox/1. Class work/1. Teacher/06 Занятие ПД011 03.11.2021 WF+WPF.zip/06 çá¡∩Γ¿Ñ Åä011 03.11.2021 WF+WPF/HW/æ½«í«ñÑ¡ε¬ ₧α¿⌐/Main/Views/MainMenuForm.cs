﻿using System;
using System.Windows.Forms;
using Main.Common;


namespace Main.Views
{
	internal interface IMainMenuView : IView
	{
		event Action CalculateFormCall;
		event Action LoggerFormCall;
		event Action AboutProgramFormCall;
	}


	public sealed partial class MainMenuForm : BaseForm, IMainMenuView
	{
		public event Action CalculateFormCall;
		public event Action LoggerFormCall;
		public event Action AboutProgramFormCall;


		public new void Show()
		{
			_context.MainForm = this;
			Application.Run(_context);
		}


		public MainMenuForm(ApplicationContext context)
		{
			_context = context;
			InitializeComponent();
		}


		private readonly ApplicationContext _context;


		private void LinkToCalculateForm_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e) =>
			CalculateFormCall?.Invoke();


		private void LinkToLoggerForm_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e) =>
			LoggerFormCall?.Invoke();

		private void LinkToAboutProgramForm_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e) =>
			AboutProgramFormCall?.Invoke();
	}
}