﻿namespace Main.Models
{
	public interface IOperation
	{
		double Solve();
	}
}