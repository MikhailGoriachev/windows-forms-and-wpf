﻿
namespace Calculations
{
    partial class MainForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.linkLabel2 = new System.Windows.Forms.LinkLabel();
            this.linkLabel3 = new System.Windows.Forms.LinkLabel();
            this.label1 = new System.Windows.Forms.Label();
            this.textBoxResult = new System.Windows.Forms.TextBox();
            this.numericOperand1 = new System.Windows.Forms.NumericUpDown();
            this.numericOperand2 = new System.Windows.Forms.NumericUpDown();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.buttonPlus = new System.Windows.Forms.Button();
            this.buttonMinus = new System.Windows.Forms.Button();
            this.buttonMultiply = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.buttonDevision = new System.Windows.Forms.Button();
            this.buttonSquare = new System.Windows.Forms.Button();
            this.buttonPow = new System.Windows.Forms.Button();
            this.Calc = new System.Windows.Forms.Button();
            this.buttonSin = new System.Windows.Forms.Button();
            this.radioButtonDegree = new System.Windows.Forms.RadioButton();
            this.radioButtonRadian = new System.Windows.Forms.RadioButton();
            ((System.ComponentModel.ISupportInitialize)(this.numericOperand1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericOperand2)).BeginInit();
            this.SuspendLayout();
            // 
            // linkLabel1
            // 
            this.linkLabel1.AutoSize = true;
            this.linkLabel1.Font = new System.Drawing.Font("Segoe UI Black", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.linkLabel1.Location = new System.Drawing.Point(140, 39);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(111, 32);
            this.linkLabel1.TabIndex = 24;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Text = "Журнал";
            // 
            // linkLabel2
            // 
            this.linkLabel2.AutoSize = true;
            this.linkLabel2.Font = new System.Drawing.Font("Segoe UI Black", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.linkLabel2.Location = new System.Drawing.Point(514, 46);
            this.linkLabel2.Name = "linkLabel2";
            this.linkLabel2.Size = new System.Drawing.Size(175, 32);
            this.linkLabel2.TabIndex = 26;
            this.linkLabel2.TabStop = true;
            this.linkLabel2.Text = "О программе";
            // 
            // linkLabel3
            // 
            this.linkLabel3.AutoSize = true;
            this.linkLabel3.Font = new System.Drawing.Font("Segoe UI Black", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.linkLabel3.Location = new System.Drawing.Point(948, 46);
            this.linkLabel3.Name = "linkLabel3";
            this.linkLabel3.Size = new System.Drawing.Size(109, 32);
            this.linkLabel3.TabIndex = 27;
            this.linkLabel3.TabStop = true;
            this.linkLabel3.Text = "ВЫХОД";
            this.linkLabel3.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel3_LinkClicked);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(90, 122);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(126, 32);
            this.label1.TabIndex = 28;
            this.label1.Text = "Результат";
            // 
            // textBoxResult
            // 
            this.textBoxResult.Location = new System.Drawing.Point(90, 174);
            this.textBoxResult.Name = "textBoxResult";
            this.textBoxResult.Size = new System.Drawing.Size(228, 31);
            this.textBoxResult.TabIndex = 29;
            // 
            // numericOperand1
            // 
            this.numericOperand1.Location = new System.Drawing.Point(90, 270);
            this.numericOperand1.Name = "numericOperand1";
            this.numericOperand1.Size = new System.Drawing.Size(180, 31);
            this.numericOperand1.TabIndex = 30;
            // 
            // numericOperand2
            // 
            this.numericOperand2.Location = new System.Drawing.Point(356, 270);
            this.numericOperand2.Name = "numericOperand2";
            this.numericOperand2.Size = new System.Drawing.Size(180, 31);
            this.numericOperand2.TabIndex = 31;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(90, 226);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(100, 25);
            this.label2.TabIndex = 32;
            this.label2.Text = "Операнд 1";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(356, 226);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(100, 25);
            this.label3.TabIndex = 33;
            this.label3.Text = "Операнд 2";
            // 
            // buttonPlus
            // 
            this.buttonPlus.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.buttonPlus.Image = global::Calculations.Properties.Resources.plussign_874671;
            this.buttonPlus.Location = new System.Drawing.Point(90, 344);
            this.buttonPlus.Name = "buttonPlus";
            this.buttonPlus.Size = new System.Drawing.Size(112, 43);
            this.buttonPlus.TabIndex = 34;
            this.buttonPlus.UseVisualStyleBackColor = false;
            this.buttonPlus.Click += new System.EventHandler(this.buttonPlus_Click);
            // 
            // buttonMinus
            // 
            this.buttonMinus.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.buttonMinus.Image = global::Calculations.Properties.Resources.minus_gross_horizontal_straight_line_symbol_icon_icons_com_74137;
            this.buttonMinus.Location = new System.Drawing.Point(240, 344);
            this.buttonMinus.Name = "buttonMinus";
            this.buttonMinus.Size = new System.Drawing.Size(112, 43);
            this.buttonMinus.TabIndex = 35;
            this.buttonMinus.UseVisualStyleBackColor = false;
            this.buttonMinus.Click += new System.EventHandler(this.buttonMinus_Click);
            // 
            // buttonMultiply
            // 
            this.buttonMultiply.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.buttonMultiply.Image = global::Calculations.Properties.Resources.multiplicationsign_80855;
            this.buttonMultiply.Location = new System.Drawing.Point(383, 344);
            this.buttonMultiply.Name = "buttonMultiply";
            this.buttonMultiply.Size = new System.Drawing.Size(112, 43);
            this.buttonMultiply.TabIndex = 36;
            this.buttonMultiply.UseVisualStyleBackColor = false;
            this.buttonMultiply.Click += new System.EventHandler(this.buttonMultiply_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(90, 415);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(0, 25);
            this.label4.TabIndex = 37;
            // 
            // buttonDevision
            // 
            this.buttonDevision.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.buttonDevision.Image = global::Calculations.Properties.Resources.divisionsign_81003;
            this.buttonDevision.Location = new System.Drawing.Point(90, 415);
            this.buttonDevision.Name = "buttonDevision";
            this.buttonDevision.Size = new System.Drawing.Size(112, 43);
            this.buttonDevision.TabIndex = 38;
            this.buttonDevision.UseVisualStyleBackColor = false;
            this.buttonDevision.Click += new System.EventHandler(this.buttonDevision_Click);
            // 
            // buttonSquare
            // 
            this.buttonSquare.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.buttonSquare.Image = global::Calculations.Properties.Resources.squareroot_cuadrad_3928;
            this.buttonSquare.Location = new System.Drawing.Point(240, 415);
            this.buttonSquare.Name = "buttonSquare";
            this.buttonSquare.Size = new System.Drawing.Size(112, 43);
            this.buttonSquare.TabIndex = 39;
            this.buttonSquare.UseVisualStyleBackColor = false;
            this.buttonSquare.Click += new System.EventHandler(this.buttonSquare_Click);
            // 
            // buttonPow
            // 
            this.buttonPow.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.buttonPow.Font = new System.Drawing.Font("Segoe UI Black", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.buttonPow.Location = new System.Drawing.Point(90, 490);
            this.buttonPow.Name = "buttonPow";
            this.buttonPow.Size = new System.Drawing.Size(112, 43);
            this.buttonPow.TabIndex = 41;
            this.buttonPow.Text = "POW\r\n";
            this.buttonPow.UseVisualStyleBackColor = false;
            this.buttonPow.Click += new System.EventHandler(this.buttonPow_Click);
            // 
            // Calc
            // 
            this.Calc.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.Calc.Font = new System.Drawing.Font("Segoe UI Black", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Calc.Location = new System.Drawing.Point(90, 569);
            this.Calc.Name = "Calc";
            this.Calc.Size = new System.Drawing.Size(405, 55);
            this.Calc.TabIndex = 42;
            this.Calc.Text = "ВЫЧИСЛИТЬ";
            this.Calc.UseVisualStyleBackColor = false;
            this.Calc.Click += new System.EventHandler(this.Calc_Click);
            // 
            // buttonSin
            // 
            this.buttonSin.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.buttonSin.Font = new System.Drawing.Font("Segoe UI Black", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.buttonSin.Location = new System.Drawing.Point(240, 490);
            this.buttonSin.Name = "buttonSin";
            this.buttonSin.Size = new System.Drawing.Size(112, 42);
            this.buttonSin.TabIndex = 43;
            this.buttonSin.Text = "SIN";
            this.buttonSin.UseVisualStyleBackColor = false;
            this.buttonSin.Click += new System.EventHandler(this.buttonSin_Click);
            // 
            // radioButtonDegree
            // 
            this.radioButtonDegree.AutoSize = true;
            this.radioButtonDegree.Location = new System.Drawing.Point(390, 471);
            this.radioButtonDegree.Name = "radioButtonDegree";
            this.radioButtonDegree.Size = new System.Drawing.Size(105, 29);
            this.radioButtonDegree.TabIndex = 46;
            this.radioButtonDegree.TabStop = true;
            this.radioButtonDegree.Text = "Градусы";
            this.radioButtonDegree.UseVisualStyleBackColor = true;
            // 
            // radioButtonRadian
            // 
            this.radioButtonRadian.AutoSize = true;
            this.radioButtonRadian.Location = new System.Drawing.Point(390, 526);
            this.radioButtonRadian.Name = "radioButtonRadian";
            this.radioButtonRadian.Size = new System.Drawing.Size(113, 29);
            this.radioButtonRadian.TabIndex = 47;
            this.radioButtonRadian.TabStop = true;
            this.radioButtonRadian.Text = "Радианы ";
            this.radioButtonRadian.UseVisualStyleBackColor = true;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1340, 697);
            this.Controls.Add(this.radioButtonRadian);
            this.Controls.Add(this.radioButtonDegree);
            this.Controls.Add(this.buttonSin);
            this.Controls.Add(this.Calc);
            this.Controls.Add(this.buttonPow);
            this.Controls.Add(this.buttonSquare);
            this.Controls.Add(this.buttonDevision);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.buttonMultiply);
            this.Controls.Add(this.buttonMinus);
            this.Controls.Add(this.buttonPlus);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.numericOperand2);
            this.Controls.Add(this.numericOperand1);
            this.Controls.Add(this.textBoxResult);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.linkLabel3);
            this.Controls.Add(this.linkLabel2);
            this.Controls.Add(this.linkLabel1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "MainForm";
            this.Text = "Calculations";
            ((System.ComponentModel.ISupportInitialize)(this.numericOperand1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericOperand2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.LinkLabel linkLabel1;
        private System.Windows.Forms.LinkLabel linkLabel2;
        private System.Windows.Forms.LinkLabel linkLabel3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBoxResult;
        private System.Windows.Forms.NumericUpDown numericOperand1;
        private System.Windows.Forms.NumericUpDown numericOperand2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button buttonPlus;
        private System.Windows.Forms.Button buttonMinus;
        private System.Windows.Forms.Button buttonMultiply;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button buttonDevision;
        private System.Windows.Forms.Button buttonSquare;
        private System.Windows.Forms.Button buttonPow;
        private System.Windows.Forms.Button Calc;
        private System.Windows.Forms.Button buttonSin;
        private System.Windows.Forms.RadioButton radioButtonDegree;
        private System.Windows.Forms.RadioButton radioButtonRadian;
    }
}

