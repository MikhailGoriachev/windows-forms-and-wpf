﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calculations
{
    public partial class MainForm : Form
    {
        private double result;
        public MainForm()
        {
            InitializeComponent();
        }

        private void buttonPlus_Click(object sender, EventArgs e)
        {
            result = (double)(numericOperand1.Value + numericOperand2.Value); 
        }

        

        private void Calc_Click(object sender, EventArgs e)
        {
            textBoxResult.Text = result.ToString();
        }

        private void buttonMinus_Click(object sender, EventArgs e)
        {
            result = (double)(numericOperand1.Value - numericOperand2.Value);
        }

        private void buttonMultiply_Click(object sender, EventArgs e)
        {
            result = (double)(numericOperand1.Value * numericOperand2.Value);
        }

        private void buttonDevision_Click(object sender, EventArgs e)
        {
            result = (double)(numericOperand1.Value / numericOperand2.Value); 
        }

        private void buttonSquare_Click(object sender, EventArgs e)
        {
            result = (double)(Math.Sqrt((double)numericOperand1.Value));
        }

        private void buttonPow_Click(object sender, EventArgs e)
        {
            result = (double)(Math.Pow((double)numericOperand1.Value, (double)numericOperand2.Value));
        }

        private void buttonSin_Click(object sender, EventArgs e)
        {
            if (radioButtonRadian.Checked)
                result = (double)(Math.Sin((double)numericOperand1.Value));
            else if (radioButtonDegree.Checked)
                result = (double)(Math.PI / 180 * (Math.Sin((double)numericOperand1.Value)));
        }

        private void linkLabel3_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Close();
        }
    }
}
