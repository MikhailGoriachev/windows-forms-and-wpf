﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Homework5
{
	public partial class AboutForm : Form
	{
		public AboutForm()
		{
			InitializeComponent();
			LblInfo.Text =
				$"Приложение для вычисления операций:\n\n" +
				$"		- сложения\n" +
				$"		- вычитания\n" +
				$"		- умножения\n" +
				$"		- деления\n" +
				$"		- возведения в степень\n" +
				$"		- вычисления синуса\n" +
				$"		- вычисления квадратного корня\n" +
				$"\n\n\n" +
				$"© Масленников Виталий, ПД011, КА Шаг, 2021г";
		}

		
		private void TmrAbout_Tick(object sender, EventArgs e)
		{
			TmrAbout.Enabled = false;
			Close();
		}

		private void BtnOk_Click(object sender, EventArgs e) => Close();
	}
}
