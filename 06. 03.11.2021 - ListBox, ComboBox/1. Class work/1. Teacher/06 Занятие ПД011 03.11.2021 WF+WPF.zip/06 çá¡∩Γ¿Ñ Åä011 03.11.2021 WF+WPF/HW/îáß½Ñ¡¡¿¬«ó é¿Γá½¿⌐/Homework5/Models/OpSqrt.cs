﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Homework5.Models
{
	// Операция вычисления квадратного корня
	internal class OpSqrt: Operation
	{
		public OpSqrt() => base.OpName = "вычисление квадратного корня";
		protected override double CalcResult() => Math.Sqrt(Op1);
	}
}
