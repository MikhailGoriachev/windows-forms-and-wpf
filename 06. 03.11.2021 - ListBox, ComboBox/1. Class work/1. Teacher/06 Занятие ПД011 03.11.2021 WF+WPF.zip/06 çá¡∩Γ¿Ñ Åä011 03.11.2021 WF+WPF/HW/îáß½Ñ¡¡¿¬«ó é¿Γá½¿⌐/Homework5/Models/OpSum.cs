﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Homework5.Models
{
	// Операция сложения
	internal class OpSum : Operation
	{
		public OpSum() => base.OpName = "сложение";
	
		protected override double CalcResult() => Op1 + Op2;
	}
}
