﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Homework5.Services;
using Homework5.Models;

namespace Homework5
{
	public partial class MainForm : Form
	{
		public MainForm() => InitializeComponent();

		// Действия при нажатии на кнопку вычисления операции
		private void BtnOp_Click(object sender, EventArgs e)
		{
			// Объект кнопки, вызвавшей операцию
			Button opButton = sender as Button;

			// Операция, вызванная по кнопке
			Operation operation = OperationsList.Ops[(string)opButton.Tag];

			// Проверка на пустые поля
			if (string.IsNullOrEmpty(NudOperand1.Text) || string.IsNullOrEmpty(NudOperand2.Text))
			{
				MessageBox.Show("Не все данные введены", "Ошибка");
				return;
			}
			
			// Чтение данных из полей
			operation.Op1 = double.Parse(NudOperand1.Text);
			operation.Op2 = double.Parse(NudOperand2.Text);

			// Если вычисление синуса - проверить настройку меры измерения угла
			if ((string)opButton.Tag == "Sin" && RbtDegrees.Checked)
				operation.Op1 = (operation.Op1 / 180) * Math.PI;

			// Вывод сообщения в текстбокс результата
			TxbResult.Text = Services.FormattingMessages.GetResultMsg(operation);

			// Вывод сообщения в текстбокс истории
			TxbHistory.Text += Services.FormattingMessages.GetResultMsg(operation) + "\r\n";

			// Добавление записи в файл журнала
			FileUsing.AppendRecord(FileUsing.fileName, operation);
		}


		// Чтение файла при загрузке формы
		private void MainForm_Load(object sender, EventArgs e) =>
			TxbHistory.Text = string.Join("\r\n", FileUsing.LoadFile(FileUsing.fileName));


		// Вызов "о программе" по LinkButton
		private void LnlAbout_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
		{
			AboutForm aboutForm = new AboutForm();
			aboutForm.ShowDialog();
		}


		// Выход по LinkButton
		private void LnlExit_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e) => Close();
	}
}
