﻿
namespace Homework5
{
	partial class MainForm
	{
		/// <summary>
		/// Обязательная переменная конструктора.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Освободить все используемые ресурсы.
		/// </summary>
		/// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Код, автоматически созданный конструктором форм Windows

		/// <summary>
		/// Требуемый метод для поддержки конструктора — не изменяйте 
		/// содержимое этого метода с помощью редактора кода.
		/// </summary>
		private void InitializeComponent()
		{
			this.NudOperand1 = new System.Windows.Forms.NumericUpDown();
			this.NudOperand2 = new System.Windows.Forms.NumericUpDown();
			this.LblOperand1 = new System.Windows.Forms.Label();
			this.LblOperand2 = new System.Windows.Forms.Label();
			this.GrbInput = new System.Windows.Forms.GroupBox();
			this.BtnOpSum = new System.Windows.Forms.Button();
			this.BtnOpSubtr = new System.Windows.Forms.Button();
			this.BtnOpDiv = new System.Windows.Forms.Button();
			this.BtnOpMult = new System.Windows.Forms.Button();
			this.BtnOpSin = new System.Windows.Forms.Button();
			this.BtnOpSqrt = new System.Windows.Forms.Button();
			this.BtnOpPow = new System.Windows.Forms.Button();
			this.GrbOperations = new System.Windows.Forms.GroupBox();
			this.GrbAngle = new System.Windows.Forms.GroupBox();
			this.RbtDegrees = new System.Windows.Forms.RadioButton();
			this.RbtRadians = new System.Windows.Forms.RadioButton();
			this.TxbResult = new System.Windows.Forms.TextBox();
			this.LblResult = new System.Windows.Forms.Label();
			this.TxbHistory = new System.Windows.Forms.TextBox();
			this.LblHistory = new System.Windows.Forms.Label();
			this.LnlAbout = new System.Windows.Forms.LinkLabel();
			this.LnlExit = new System.Windows.Forms.LinkLabel();
			((System.ComponentModel.ISupportInitialize)(this.NudOperand1)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.NudOperand2)).BeginInit();
			this.GrbInput.SuspendLayout();
			this.GrbOperations.SuspendLayout();
			this.GrbAngle.SuspendLayout();
			this.SuspendLayout();
			// 
			// NudOperand1
			// 
			this.NudOperand1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.NudOperand1.Location = new System.Drawing.Point(24, 44);
			this.NudOperand1.Maximum = new decimal(new int[] {
            1000000000,
            0,
            0,
            0});
			this.NudOperand1.Minimum = new decimal(new int[] {
            1000000000,
            0,
            0,
            -2147483648});
			this.NudOperand1.Name = "NudOperand1";
			this.NudOperand1.Size = new System.Drawing.Size(120, 22);
			this.NudOperand1.TabIndex = 0;
			this.NudOperand1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			// 
			// NudOperand2
			// 
			this.NudOperand2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.NudOperand2.Location = new System.Drawing.Point(24, 100);
			this.NudOperand2.Maximum = new decimal(new int[] {
            1000000000,
            0,
            0,
            0});
			this.NudOperand2.Minimum = new decimal(new int[] {
            1000000000,
            0,
            0,
            -2147483648});
			this.NudOperand2.Name = "NudOperand2";
			this.NudOperand2.Size = new System.Drawing.Size(120, 22);
			this.NudOperand2.TabIndex = 1;
			this.NudOperand2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			// 
			// LblOperand1
			// 
			this.LblOperand1.AutoSize = true;
			this.LblOperand1.Font = new System.Drawing.Font("Tahoma", 8F);
			this.LblOperand1.Location = new System.Drawing.Point(24, 24);
			this.LblOperand1.Name = "LblOperand1";
			this.LblOperand1.Size = new System.Drawing.Size(61, 13);
			this.LblOperand1.TabIndex = 2;
			this.LblOperand1.Text = "Операнд 1";
			// 
			// LblOperand2
			// 
			this.LblOperand2.AutoSize = true;
			this.LblOperand2.Font = new System.Drawing.Font("Tahoma", 8F);
			this.LblOperand2.Location = new System.Drawing.Point(24, 80);
			this.LblOperand2.Name = "LblOperand2";
			this.LblOperand2.Size = new System.Drawing.Size(61, 13);
			this.LblOperand2.TabIndex = 3;
			this.LblOperand2.Text = "Операнд 2";
			// 
			// GrbInput
			// 
			this.GrbInput.Controls.Add(this.LblOperand2);
			this.GrbInput.Controls.Add(this.LblOperand1);
			this.GrbInput.Controls.Add(this.NudOperand2);
			this.GrbInput.Controls.Add(this.NudOperand1);
			this.GrbInput.Font = new System.Drawing.Font("Tahoma", 9F);
			this.GrbInput.Location = new System.Drawing.Point(23, 16);
			this.GrbInput.Name = "GrbInput";
			this.GrbInput.Size = new System.Drawing.Size(168, 136);
			this.GrbInput.TabIndex = 4;
			this.GrbInput.TabStop = false;
			this.GrbInput.Text = "Ввод данных";
			// 
			// BtnOpSum
			// 
			this.BtnOpSum.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold);
			this.BtnOpSum.Location = new System.Drawing.Point(17, 24);
			this.BtnOpSum.Name = "BtnOpSum";
			this.BtnOpSum.Size = new System.Drawing.Size(48, 40);
			this.BtnOpSum.TabIndex = 5;
			this.BtnOpSum.Tag = "Sum";
			this.BtnOpSum.Text = "+";
			this.BtnOpSum.UseVisualStyleBackColor = true;
			this.BtnOpSum.Click += new System.EventHandler(this.BtnOp_Click);
			// 
			// BtnOpSubtr
			// 
			this.BtnOpSubtr.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold);
			this.BtnOpSubtr.Location = new System.Drawing.Point(78, 24);
			this.BtnOpSubtr.Name = "BtnOpSubtr";
			this.BtnOpSubtr.Size = new System.Drawing.Size(48, 40);
			this.BtnOpSubtr.TabIndex = 6;
			this.BtnOpSubtr.Tag = "Subtraction";
			this.BtnOpSubtr.Text = "-";
			this.BtnOpSubtr.UseVisualStyleBackColor = true;
			this.BtnOpSubtr.Click += new System.EventHandler(this.BtnOp_Click);
			// 
			// BtnOpDiv
			// 
			this.BtnOpDiv.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold);
			this.BtnOpDiv.Location = new System.Drawing.Point(200, 24);
			this.BtnOpDiv.Name = "BtnOpDiv";
			this.BtnOpDiv.Size = new System.Drawing.Size(48, 40);
			this.BtnOpDiv.TabIndex = 8;
			this.BtnOpDiv.Tag = "Divide";
			this.BtnOpDiv.Text = "/";
			this.BtnOpDiv.UseVisualStyleBackColor = true;
			this.BtnOpDiv.Click += new System.EventHandler(this.BtnOp_Click);
			// 
			// BtnOpMult
			// 
			this.BtnOpMult.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold);
			this.BtnOpMult.Location = new System.Drawing.Point(139, 24);
			this.BtnOpMult.Name = "BtnOpMult";
			this.BtnOpMult.Size = new System.Drawing.Size(48, 40);
			this.BtnOpMult.TabIndex = 7;
			this.BtnOpMult.Tag = "Multiply";
			this.BtnOpMult.Text = "*";
			this.BtnOpMult.UseVisualStyleBackColor = true;
			this.BtnOpMult.Click += new System.EventHandler(this.BtnOp_Click);
			// 
			// BtnOpSin
			// 
			this.BtnOpSin.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold);
			this.BtnOpSin.Location = new System.Drawing.Point(44, 80);
			this.BtnOpSin.Name = "BtnOpSin";
			this.BtnOpSin.Size = new System.Drawing.Size(48, 40);
			this.BtnOpSin.TabIndex = 9;
			this.BtnOpSin.Tag = "Sin";
			this.BtnOpSin.Text = "Sin";
			this.BtnOpSin.UseVisualStyleBackColor = true;
			this.BtnOpSin.Click += new System.EventHandler(this.BtnOp_Click);
			// 
			// BtnOpSqrt
			// 
			this.BtnOpSqrt.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold);
			this.BtnOpSqrt.Location = new System.Drawing.Point(108, 80);
			this.BtnOpSqrt.Name = "BtnOpSqrt";
			this.BtnOpSqrt.Size = new System.Drawing.Size(48, 40);
			this.BtnOpSqrt.TabIndex = 10;
			this.BtnOpSqrt.Tag = "Sqrt";
			this.BtnOpSqrt.Text = "√";
			this.BtnOpSqrt.UseVisualStyleBackColor = true;
			this.BtnOpSqrt.Click += new System.EventHandler(this.BtnOp_Click);
			// 
			// BtnOpPow
			// 
			this.BtnOpPow.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold);
			this.BtnOpPow.Location = new System.Drawing.Point(172, 80);
			this.BtnOpPow.Name = "BtnOpPow";
			this.BtnOpPow.Size = new System.Drawing.Size(48, 40);
			this.BtnOpPow.TabIndex = 11;
			this.BtnOpPow.Tag = "Pow";
			this.BtnOpPow.Text = "xⁿ";
			this.BtnOpPow.UseVisualStyleBackColor = true;
			this.BtnOpPow.Click += new System.EventHandler(this.BtnOp_Click);
			// 
			// GrbOperations
			// 
			this.GrbOperations.Controls.Add(this.BtnOpPow);
			this.GrbOperations.Controls.Add(this.BtnOpSqrt);
			this.GrbOperations.Controls.Add(this.BtnOpSin);
			this.GrbOperations.Controls.Add(this.BtnOpMult);
			this.GrbOperations.Controls.Add(this.BtnOpDiv);
			this.GrbOperations.Controls.Add(this.BtnOpSubtr);
			this.GrbOperations.Controls.Add(this.BtnOpSum);
			this.GrbOperations.Font = new System.Drawing.Font("Tahoma", 9F);
			this.GrbOperations.Location = new System.Drawing.Point(207, 16);
			this.GrbOperations.Name = "GrbOperations";
			this.GrbOperations.Size = new System.Drawing.Size(264, 136);
			this.GrbOperations.TabIndex = 12;
			this.GrbOperations.TabStop = false;
			this.GrbOperations.Text = "Операции";
			// 
			// GrbAngle
			// 
			this.GrbAngle.Controls.Add(this.RbtDegrees);
			this.GrbAngle.Controls.Add(this.RbtRadians);
			this.GrbAngle.Font = new System.Drawing.Font("Tahoma", 9F);
			this.GrbAngle.Location = new System.Drawing.Point(351, 160);
			this.GrbAngle.Name = "GrbAngle";
			this.GrbAngle.Size = new System.Drawing.Size(120, 88);
			this.GrbAngle.TabIndex = 13;
			this.GrbAngle.TabStop = false;
			this.GrbAngle.Text = "Измерение угла";
			// 
			// RbtDegrees
			// 
			this.RbtDegrees.AutoSize = true;
			this.RbtDegrees.Font = new System.Drawing.Font("Tahoma", 9F);
			this.RbtDegrees.Location = new System.Drawing.Point(24, 56);
			this.RbtDegrees.Name = "RbtDegrees";
			this.RbtDegrees.Size = new System.Drawing.Size(71, 18);
			this.RbtDegrees.TabIndex = 1;
			this.RbtDegrees.TabStop = true;
			this.RbtDegrees.Text = "Градусы";
			this.RbtDegrees.UseVisualStyleBackColor = true;
			// 
			// RbtRadians
			// 
			this.RbtRadians.AutoSize = true;
			this.RbtRadians.Checked = true;
			this.RbtRadians.Font = new System.Drawing.Font("Tahoma", 9F);
			this.RbtRadians.Location = new System.Drawing.Point(24, 24);
			this.RbtRadians.Name = "RbtRadians";
			this.RbtRadians.Size = new System.Drawing.Size(73, 18);
			this.RbtRadians.TabIndex = 0;
			this.RbtRadians.TabStop = true;
			this.RbtRadians.Text = "Радианы";
			this.RbtRadians.UseVisualStyleBackColor = true;
			// 
			// TxbResult
			// 
			this.TxbResult.Font = new System.Drawing.Font("Consolas", 9F);
			this.TxbResult.Location = new System.Drawing.Point(23, 176);
			this.TxbResult.Multiline = true;
			this.TxbResult.Name = "TxbResult";
			this.TxbResult.ReadOnly = true;
			this.TxbResult.Size = new System.Drawing.Size(312, 72);
			this.TxbResult.TabIndex = 14;
			this.TxbResult.Text = "Операция: \r\nОперанд 1:\r\nОперанд 2:\r\nРезультат:";
			// 
			// LblResult
			// 
			this.LblResult.AutoSize = true;
			this.LblResult.Font = new System.Drawing.Font("Tahoma", 9F);
			this.LblResult.Location = new System.Drawing.Point(28, 160);
			this.LblResult.Name = "LblResult";
			this.LblResult.Size = new System.Drawing.Size(67, 14);
			this.LblResult.TabIndex = 15;
			this.LblResult.Text = "Результат:";
			// 
			// TxbHistory
			// 
			this.TxbHistory.Font = new System.Drawing.Font("Consolas", 9F);
			this.TxbHistory.Location = new System.Drawing.Point(495, 40);
			this.TxbHistory.Multiline = true;
			this.TxbHistory.Name = "TxbHistory";
			this.TxbHistory.ReadOnly = true;
			this.TxbHistory.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
			this.TxbHistory.Size = new System.Drawing.Size(312, 208);
			this.TxbHistory.TabIndex = 16;
			// 
			// LblHistory
			// 
			this.LblHistory.AutoSize = true;
			this.LblHistory.Font = new System.Drawing.Font("Tahoma", 9F);
			this.LblHistory.Location = new System.Drawing.Point(495, 16);
			this.LblHistory.Name = "LblHistory";
			this.LblHistory.Size = new System.Drawing.Size(114, 14);
			this.LblHistory.TabIndex = 17;
			this.LblHistory.Text = "История операций";
			// 
			// LnlAbout
			// 
			this.LnlAbout.AutoSize = true;
			this.LnlAbout.Location = new System.Drawing.Point(680, 264);
			this.LnlAbout.Name = "LnlAbout";
			this.LnlAbout.Size = new System.Drawing.Size(75, 13);
			this.LnlAbout.TabIndex = 18;
			this.LnlAbout.TabStop = true;
			this.LnlAbout.Text = "О программе";
			this.LnlAbout.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.LnlAbout_LinkClicked);
			// 
			// LnlExit
			// 
			this.LnlExit.AutoSize = true;
			this.LnlExit.Location = new System.Drawing.Point(768, 264);
			this.LnlExit.Name = "LnlExit";
			this.LnlExit.Size = new System.Drawing.Size(39, 13);
			this.LnlExit.TabIndex = 19;
			this.LnlExit.TabStop = true;
			this.LnlExit.Text = "Выход";
			this.LnlExit.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.LnlExit_LinkClicked);
			// 
			// MainForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(830, 291);
			this.Controls.Add(this.LnlExit);
			this.Controls.Add(this.LnlAbout);
			this.Controls.Add(this.LblHistory);
			this.Controls.Add(this.TxbHistory);
			this.Controls.Add(this.LblResult);
			this.Controls.Add(this.TxbResult);
			this.Controls.Add(this.GrbAngle);
			this.Controls.Add(this.GrbOperations);
			this.Controls.Add(this.GrbInput);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.MaximizeBox = false;
			this.Name = "MainForm";
			this.Text = "Домашнее задание";
			this.Load += new System.EventHandler(this.MainForm_Load);
			((System.ComponentModel.ISupportInitialize)(this.NudOperand1)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.NudOperand2)).EndInit();
			this.GrbInput.ResumeLayout(false);
			this.GrbInput.PerformLayout();
			this.GrbOperations.ResumeLayout(false);
			this.GrbAngle.ResumeLayout(false);
			this.GrbAngle.PerformLayout();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.NumericUpDown NudOperand1;
		private System.Windows.Forms.NumericUpDown NudOperand2;
		private System.Windows.Forms.Label LblOperand1;
		private System.Windows.Forms.Label LblOperand2;
		private System.Windows.Forms.GroupBox GrbInput;
		private System.Windows.Forms.Button BtnOpSum;
		private System.Windows.Forms.Button BtnOpSubtr;
		private System.Windows.Forms.Button BtnOpDiv;
		private System.Windows.Forms.Button BtnOpMult;
		private System.Windows.Forms.Button BtnOpSin;
		private System.Windows.Forms.Button BtnOpSqrt;
		private System.Windows.Forms.Button BtnOpPow;
		private System.Windows.Forms.GroupBox GrbOperations;
		private System.Windows.Forms.GroupBox GrbAngle;
		private System.Windows.Forms.RadioButton RbtDegrees;
		private System.Windows.Forms.RadioButton RbtRadians;
		private System.Windows.Forms.TextBox TxbResult;
		private System.Windows.Forms.Label LblResult;
		private System.Windows.Forms.TextBox TxbHistory;
		private System.Windows.Forms.Label LblHistory;
		private System.Windows.Forms.LinkLabel LnlAbout;
		private System.Windows.Forms.LinkLabel LnlExit;
	}
}

