﻿
namespace Homework5
{
	partial class AboutForm
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			this.BtnOk = new System.Windows.Forms.Button();
			this.LblInfo = new System.Windows.Forms.Label();
			this.TmrAbout = new System.Windows.Forms.Timer(this.components);
			this.SuspendLayout();
			// 
			// BtnOk
			// 
			this.BtnOk.Font = new System.Drawing.Font("Tahoma", 9F);
			this.BtnOk.Location = new System.Drawing.Point(208, 192);
			this.BtnOk.Name = "BtnOk";
			this.BtnOk.Size = new System.Drawing.Size(75, 23);
			this.BtnOk.TabIndex = 0;
			this.BtnOk.Text = "Ok";
			this.BtnOk.UseVisualStyleBackColor = true;
			this.BtnOk.Click += new System.EventHandler(this.BtnOk_Click);
			// 
			// LblInfo
			// 
			this.LblInfo.Font = new System.Drawing.Font("Tahoma", 8F);
			this.LblInfo.Location = new System.Drawing.Point(11, 8);
			this.LblInfo.Name = "LblInfo";
			this.LblInfo.Size = new System.Drawing.Size(272, 176);
			this.LblInfo.TabIndex = 1;
			// 
			// TmrAbout
			// 
			this.TmrAbout.Enabled = true;
			this.TmrAbout.Interval = 10000;
			this.TmrAbout.Tick += new System.EventHandler(this.TmrAbout_Tick);
			// 
			// AboutForm
			// 
			this.AcceptButton = this.BtnOk;
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(295, 224);
			this.Controls.Add(this.LblInfo);
			this.Controls.Add(this.BtnOk);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.MaximizeBox = false;
			this.Name = "AboutForm";
			this.ShowInTaskbar = false;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "О программе";
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.Button BtnOk;
		private System.Windows.Forms.Label LblInfo;
		private System.Windows.Forms.Timer TmrAbout;
	}
}