﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Homework5.Models
{
	// Операция возведения в степень
	internal class OpPow: Operation
	{
		public OpPow() => base.OpName = "возведение в степень";
		protected override double CalcResult() => Math.Pow(Op1, Op2);
	}
}
