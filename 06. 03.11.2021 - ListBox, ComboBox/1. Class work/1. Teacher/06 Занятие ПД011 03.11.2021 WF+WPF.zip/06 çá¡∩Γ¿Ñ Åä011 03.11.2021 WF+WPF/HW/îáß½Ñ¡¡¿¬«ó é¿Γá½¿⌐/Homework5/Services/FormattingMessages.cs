﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Homework5.Models;

namespace Homework5.Services
{
	/// <summary>
	///Формирование текста информации об операциях 
	/// </summary>
	 
	public static class FormattingMessages
	{
		public static string GetResultMsg(Operation operation) => 
			$"Операция: {operation.OpName}\r\n" +
			$"Операнд 1: {operation.Op1}\r\n" + 
			$"Операнд 2: {operation.Op2}\r\n" +
			$"Результат: {operation.Result}\r\n";

		public static string GetResultMsgFileRecord(Operation operation) =>
			$"{DateTime.Now}\n" +
			$"Операция: {operation.OpName}\n" +
			$"Операнд 1: {operation.Op1}\n" +
			$"Операнд 2: {operation.Op2}\n" +
			$"Результат: {operation.Result}\n";
	}
}
