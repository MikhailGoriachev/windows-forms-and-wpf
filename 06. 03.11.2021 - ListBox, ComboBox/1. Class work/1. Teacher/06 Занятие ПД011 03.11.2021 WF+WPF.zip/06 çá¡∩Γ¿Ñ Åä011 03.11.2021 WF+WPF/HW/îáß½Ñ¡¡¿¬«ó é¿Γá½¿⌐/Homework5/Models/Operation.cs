﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Homework5.Models
{
	// Базовый класс операций
	public abstract class Operation
	{
		// Название операции
		protected string _opName; 

		public string OpName { get; set; }

		// Первый операнд
		public double Op1 { get; set; }

		// Второй операнд
		public double Op2 { get; set; }

		// Свойство вычисления результата
		public double Result => CalcResult();

		// Вычисление результата
		protected abstract double CalcResult();
	}
}
