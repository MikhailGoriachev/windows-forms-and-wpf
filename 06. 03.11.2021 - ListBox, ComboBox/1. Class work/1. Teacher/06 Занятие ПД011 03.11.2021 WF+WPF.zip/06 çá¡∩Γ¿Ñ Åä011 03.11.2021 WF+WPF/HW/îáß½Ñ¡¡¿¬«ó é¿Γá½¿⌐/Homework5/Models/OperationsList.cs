﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Homework5.Models
{
	internal static class OperationsList
	{
		// Словарь-список операций
		public static Dictionary<string, Operation> Ops = new()
		{
			["Multiply"] = new OpMultiply(),
			["Subtraction"] = new OpSubstraction(),
			["Sum"] = new OpSum(),
			["Divide"] = new OpDivide(),
			["Sin"] = new OpSin(),
			["Sqrt"] = new OpSqrt(),
			["Pow"] = new OpPow()
		};
	}
}
