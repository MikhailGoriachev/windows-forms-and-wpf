﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Homework5.Models
{
	// Операция вычитания
	internal class OpSubstraction : Operation
	{
		public OpSubstraction() => base.OpName = "вычитание";
		protected override double CalcResult() => Op1 - Op2;
	}
}
