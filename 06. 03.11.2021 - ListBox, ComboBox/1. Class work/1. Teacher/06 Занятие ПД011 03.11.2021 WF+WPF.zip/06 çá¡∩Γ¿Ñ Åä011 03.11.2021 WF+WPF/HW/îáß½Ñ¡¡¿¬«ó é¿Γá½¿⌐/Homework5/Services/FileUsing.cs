﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Homework5.Models;

namespace Homework5.Services
{
	// Класс работы с файлами
	public static class FileUsing
	{
		// константа путь и имя файла (не сделал внедряемой)
		public const string fileName= @"..\..\log.txt";

		// Дозаписать информацию об произведенной операции в файл
		public static void AppendRecord(string fileName, Operation operation)
		{
			File.AppendAllLines(
				fileName, FormattingMessages.GetResultMsgFileRecord(operation).
					Split('\n'));
		}

		// Прочесть файл и получить массив строк
		public static string[] LoadFile(string fileName) => File.ReadAllLines(fileName);
	}
}
