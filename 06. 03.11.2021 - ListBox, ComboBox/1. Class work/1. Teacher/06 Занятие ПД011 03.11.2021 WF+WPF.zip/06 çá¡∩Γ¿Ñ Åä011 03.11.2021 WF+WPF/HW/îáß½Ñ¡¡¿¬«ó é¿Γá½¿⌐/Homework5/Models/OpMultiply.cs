﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Homework5.Models
{
	// Операция умножения
	internal class OpMultiply : Operation
	{
		public OpMultiply() => base.OpName = "умножение";
		protected override double CalcResult() => Op1 * Op2;
	}
}
