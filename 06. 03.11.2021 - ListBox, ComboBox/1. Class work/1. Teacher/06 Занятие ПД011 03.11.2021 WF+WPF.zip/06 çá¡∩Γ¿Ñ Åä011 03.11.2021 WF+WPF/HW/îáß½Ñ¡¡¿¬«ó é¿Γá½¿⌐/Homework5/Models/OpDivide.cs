﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Homework5.Models
{
	// Операция деления
	internal class OpDivide : Operation
	{
		public OpDivide() => base.OpName = "деление";

		protected override double CalcResult() => Op1 / Op2;
	}
}
