﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calculator
{
    public partial class FormMenu : Form
    {
        static public DataSaver ds = new DataSaver();
        public FormMenu()
        {
            InitializeComponent();
        }

        //закрытие приложение
        private void LinkLblExit_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
            => Application.Exit();
        
        //открыть окно калькулятора
        private void LinkLblCalc_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            FormCalc calc = new FormCalc();
            calc.ShowDialog();
        }

        //открыть окно журнала
        private void LinLblJnl_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            FormJournal journal = new FormJournal();
            journal.ShowDialog();
        }

        //открыть окно о программе
        private void LinkLblAbout_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            FormAboutProg about = new FormAboutProg();
            about.ShowDialog();
        }
    }
}
