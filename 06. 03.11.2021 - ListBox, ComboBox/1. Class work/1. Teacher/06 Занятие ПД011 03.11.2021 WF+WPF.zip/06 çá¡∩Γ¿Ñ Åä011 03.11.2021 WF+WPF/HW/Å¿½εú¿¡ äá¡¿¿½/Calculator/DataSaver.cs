﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Calculator
{
    public class DataSaver
    {
        string fileName = "../../data.txt";

        public void Save(string str)
        {
            using (FileStream fstream = new FileStream(fileName, FileMode.Append))
            {
                // преобразуем строку в байты
                byte[] array = System.Text.Encoding.Default.GetBytes(str + "\n");
                // запись массива байтов в файл
                fstream.Write(array, 0, array.Length);
            }
        }

        public string Read()
        {
            string textFromFile = null;
            try
            {
                using (FileStream fstream = File.OpenRead(fileName))
                {
                    // преобразуем строку в байты
                    byte[] array = new byte[fstream.Length];
                    // считываем данные
                    fstream.Read(array, 0, array.Length);
                    // декодируем байты в строку
                    textFromFile = System.Text.Encoding.Default.GetString(array);
                }
            }
            catch (Exception ex) { }
            return textFromFile;
        }

        public void Delete()
        {
            File.Delete(fileName);
        }
        
    }
}
