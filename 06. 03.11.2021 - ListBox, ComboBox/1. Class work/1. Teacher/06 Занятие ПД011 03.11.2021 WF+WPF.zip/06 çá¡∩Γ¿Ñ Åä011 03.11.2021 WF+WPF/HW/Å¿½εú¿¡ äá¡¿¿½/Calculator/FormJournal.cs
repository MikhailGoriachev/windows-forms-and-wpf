﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calculator
{
    public partial class FormJournal : Form
    {
        public FormJournal()
        {
            InitializeComponent();
        }

        private void BtnClsJrnl_Click(object sender, EventArgs e) => Close();

        private void BtnClearJrnl_Click(object sender, EventArgs e)
        {
            FormMenu.ds.Delete();
        }

        private void FormJournal_Load(object sender, EventArgs e)
        {
            TxtBxJrnl.Text = FormMenu.ds.Read();
        }
    }
}
