﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calculator
{
    public partial class FormAboutProg : Form
    {
        public FormAboutProg()
        {
            InitializeComponent();
            //активируем таймер
            TmrAbt.Start();
        }

        //закрывает окно о программе
        private void BtnClsAbt_Click(object sender, EventArgs e) => Close();

        //по истечении времени закрывает окно
        private void TmrAbt_Tick(object sender, EventArgs e) => Close();
            
    }
}
