﻿
namespace Calculator
{
    partial class FormCalc
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.TxtBxResult = new System.Windows.Forms.TextBox();
            this.TxtBxJrnl = new System.Windows.Forms.TextBox();
            this.NumUDOprnd1 = new System.Windows.Forms.NumericUpDown();
            this.NumUDOprnd2 = new System.Windows.Forms.NumericUpDown();
            this.GrpBxOperands = new System.Windows.Forms.GroupBox();
            this.LblOprnd2 = new System.Windows.Forms.Label();
            this.LblOprnd1 = new System.Windows.Forms.Label();
            this.RdBtnGrds = new System.Windows.Forms.RadioButton();
            this.RdBtnRad = new System.Windows.Forms.RadioButton();
            this.BtnPlus = new System.Windows.Forms.Button();
            this.BtnMinus = new System.Windows.Forms.Button();
            this.BtnMult = new System.Windows.Forms.Button();
            this.BtnDivide = new System.Windows.Forms.Button();
            this.BtnSin = new System.Windows.Forms.Button();
            this.BtnCos = new System.Windows.Forms.Button();
            this.BtnDergee = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.NumUDOprnd1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NumUDOprnd2)).BeginInit();
            this.GrpBxOperands.SuspendLayout();
            this.SuspendLayout();
            // 
            // TxtBxResult
            // 
            this.TxtBxResult.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TxtBxResult.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.TxtBxResult.Dock = System.Windows.Forms.DockStyle.Top;
            this.TxtBxResult.Font = new System.Drawing.Font("Consolas", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TxtBxResult.ForeColor = System.Drawing.Color.DarkOrange;
            this.TxtBxResult.Location = new System.Drawing.Point(0, 0);
            this.TxtBxResult.Multiline = true;
            this.TxtBxResult.Name = "TxtBxResult";
            this.TxtBxResult.ReadOnly = true;
            this.TxtBxResult.Size = new System.Drawing.Size(531, 110);
            this.TxtBxResult.TabIndex = 0;
            // 
            // TxtBxJrnl
            // 
            this.TxtBxJrnl.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TxtBxJrnl.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.TxtBxJrnl.Dock = System.Windows.Forms.DockStyle.Top;
            this.TxtBxJrnl.Font = new System.Drawing.Font("Consolas", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TxtBxJrnl.ForeColor = System.Drawing.Color.Gray;
            this.TxtBxJrnl.Location = new System.Drawing.Point(0, 110);
            this.TxtBxJrnl.Multiline = true;
            this.TxtBxJrnl.Name = "TxtBxJrnl";
            this.TxtBxJrnl.ReadOnly = true;
            this.TxtBxJrnl.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.TxtBxJrnl.Size = new System.Drawing.Size(531, 110);
            this.TxtBxJrnl.TabIndex = 2;
            // 
            // NumUDOprnd1
            // 
            this.NumUDOprnd1.BackColor = System.Drawing.Color.DarkOrange;
            this.NumUDOprnd1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.NumUDOprnd1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.NumUDOprnd1.Font = new System.Drawing.Font("Consolas", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.NumUDOprnd1.ForeColor = System.Drawing.Color.Gray;
            this.NumUDOprnd1.Location = new System.Drawing.Point(23, 74);
            this.NumUDOprnd1.Maximum = new decimal(new int[] {
            10000000,
            0,
            0,
            0});
            this.NumUDOprnd1.Minimum = new decimal(new int[] {
            100000000,
            0,
            0,
            -2147483648});
            this.NumUDOprnd1.Name = "NumUDOprnd1";
            this.NumUDOprnd1.Size = new System.Drawing.Size(206, 30);
            this.NumUDOprnd1.TabIndex = 3;
            // 
            // NumUDOprnd2
            // 
            this.NumUDOprnd2.BackColor = System.Drawing.Color.DarkOrange;
            this.NumUDOprnd2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.NumUDOprnd2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.NumUDOprnd2.Font = new System.Drawing.Font("Consolas", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.NumUDOprnd2.ForeColor = System.Drawing.Color.Gray;
            this.NumUDOprnd2.Location = new System.Drawing.Point(295, 74);
            this.NumUDOprnd2.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.NumUDOprnd2.Minimum = new decimal(new int[] {
            10000000,
            0,
            0,
            -2147483648});
            this.NumUDOprnd2.Name = "NumUDOprnd2";
            this.NumUDOprnd2.Size = new System.Drawing.Size(206, 30);
            this.NumUDOprnd2.TabIndex = 4;
            // 
            // GrpBxOperands
            // 
            this.GrpBxOperands.Controls.Add(this.LblOprnd2);
            this.GrpBxOperands.Controls.Add(this.LblOprnd1);
            this.GrpBxOperands.Controls.Add(this.NumUDOprnd2);
            this.GrpBxOperands.Controls.Add(this.NumUDOprnd1);
            this.GrpBxOperands.Dock = System.Windows.Forms.DockStyle.Top;
            this.GrpBxOperands.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.GrpBxOperands.ForeColor = System.Drawing.Color.Gray;
            this.GrpBxOperands.Location = new System.Drawing.Point(0, 220);
            this.GrpBxOperands.Name = "GrpBxOperands";
            this.GrpBxOperands.Size = new System.Drawing.Size(531, 142);
            this.GrpBxOperands.TabIndex = 5;
            this.GrpBxOperands.TabStop = false;
            this.GrpBxOperands.Text = "Операнды";
            // 
            // LblOprnd2
            // 
            this.LblOprnd2.AutoSize = true;
            this.LblOprnd2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.LblOprnd2.Location = new System.Drawing.Point(291, 48);
            this.LblOprnd2.Name = "LblOprnd2";
            this.LblOprnd2.Size = new System.Drawing.Size(121, 23);
            this.LblOprnd2.TabIndex = 6;
            this.LblOprnd2.Text = "Операнд 2";
            // 
            // LblOprnd1
            // 
            this.LblOprnd1.AutoSize = true;
            this.LblOprnd1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.LblOprnd1.Location = new System.Drawing.Point(19, 48);
            this.LblOprnd1.Name = "LblOprnd1";
            this.LblOprnd1.Size = new System.Drawing.Size(121, 23);
            this.LblOprnd1.TabIndex = 5;
            this.LblOprnd1.Text = "Операнд 1";
            // 
            // RdBtnGrds
            // 
            this.RdBtnGrds.AutoSize = true;
            this.RdBtnGrds.Checked = true;
            this.RdBtnGrds.Cursor = System.Windows.Forms.Cursors.Hand;
            this.RdBtnGrds.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.RdBtnGrds.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.RdBtnGrds.ForeColor = System.Drawing.Color.Gray;
            this.RdBtnGrds.Location = new System.Drawing.Point(58, 383);
            this.RdBtnGrds.Name = "RdBtnGrds";
            this.RdBtnGrds.Size = new System.Drawing.Size(136, 34);
            this.RdBtnGrds.TabIndex = 6;
            this.RdBtnGrds.TabStop = true;
            this.RdBtnGrds.Text = "Градусы";
            this.RdBtnGrds.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.RdBtnGrds.UseVisualStyleBackColor = true;
            // 
            // RdBtnRad
            // 
            this.RdBtnRad.AutoSize = true;
            this.RdBtnRad.Cursor = System.Windows.Forms.Cursors.Hand;
            this.RdBtnRad.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.RdBtnRad.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.RdBtnRad.ForeColor = System.Drawing.Color.Gray;
            this.RdBtnRad.Location = new System.Drawing.Point(330, 383);
            this.RdBtnRad.Name = "RdBtnRad";
            this.RdBtnRad.Size = new System.Drawing.Size(139, 34);
            this.RdBtnRad.TabIndex = 7;
            this.RdBtnRad.Text = "Радианы";
            this.RdBtnRad.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.RdBtnRad.UseVisualStyleBackColor = true;
            // 
            // BtnPlus
            // 
            this.BtnPlus.BackColor = System.Drawing.Color.DarkOrange;
            this.BtnPlus.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BtnPlus.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnPlus.Font = new System.Drawing.Font("Century Gothic", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BtnPlus.ForeColor = System.Drawing.Color.Gray;
            this.BtnPlus.Location = new System.Drawing.Point(22, 439);
            this.BtnPlus.Name = "BtnPlus";
            this.BtnPlus.Size = new System.Drawing.Size(65, 65);
            this.BtnPlus.TabIndex = 8;
            this.BtnPlus.Text = "+";
            this.BtnPlus.UseVisualStyleBackColor = false;
            this.BtnPlus.Click += new System.EventHandler(this.BtnPlus_Click);
            // 
            // BtnMinus
            // 
            this.BtnMinus.BackColor = System.Drawing.Color.DarkOrange;
            this.BtnMinus.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BtnMinus.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnMinus.Font = new System.Drawing.Font("Century Gothic", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BtnMinus.ForeColor = System.Drawing.Color.Gray;
            this.BtnMinus.Location = new System.Drawing.Point(92, 439);
            this.BtnMinus.Name = "BtnMinus";
            this.BtnMinus.Size = new System.Drawing.Size(65, 65);
            this.BtnMinus.TabIndex = 9;
            this.BtnMinus.Text = "-";
            this.BtnMinus.UseVisualStyleBackColor = false;
            this.BtnMinus.Click += new System.EventHandler(this.BtnMinus_Click);
            // 
            // BtnMult
            // 
            this.BtnMult.BackColor = System.Drawing.Color.DarkOrange;
            this.BtnMult.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BtnMult.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnMult.Font = new System.Drawing.Font("Century Gothic", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BtnMult.ForeColor = System.Drawing.Color.Gray;
            this.BtnMult.Location = new System.Drawing.Point(162, 439);
            this.BtnMult.Name = "BtnMult";
            this.BtnMult.Size = new System.Drawing.Size(65, 65);
            this.BtnMult.TabIndex = 10;
            this.BtnMult.Text = "x";
            this.BtnMult.UseVisualStyleBackColor = false;
            this.BtnMult.Click += new System.EventHandler(this.BtnMult_Click);
            // 
            // BtnDivide
            // 
            this.BtnDivide.BackColor = System.Drawing.Color.DarkOrange;
            this.BtnDivide.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BtnDivide.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnDivide.Font = new System.Drawing.Font("Century Gothic", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BtnDivide.ForeColor = System.Drawing.Color.Gray;
            this.BtnDivide.Location = new System.Drawing.Point(232, 439);
            this.BtnDivide.Name = "BtnDivide";
            this.BtnDivide.Size = new System.Drawing.Size(65, 65);
            this.BtnDivide.TabIndex = 11;
            this.BtnDivide.Text = "/";
            this.BtnDivide.UseVisualStyleBackColor = false;
            this.BtnDivide.Click += new System.EventHandler(this.BtnDivide_Click);
            // 
            // BtnSin
            // 
            this.BtnSin.BackColor = System.Drawing.Color.DarkOrange;
            this.BtnSin.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BtnSin.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnSin.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BtnSin.ForeColor = System.Drawing.Color.Gray;
            this.BtnSin.Location = new System.Drawing.Point(302, 439);
            this.BtnSin.Name = "BtnSin";
            this.BtnSin.Size = new System.Drawing.Size(65, 65);
            this.BtnSin.TabIndex = 12;
            this.BtnSin.Text = "sin";
            this.BtnSin.UseVisualStyleBackColor = false;
            this.BtnSin.Click += new System.EventHandler(this.BtnSin_Click);
            // 
            // BtnCos
            // 
            this.BtnCos.BackColor = System.Drawing.Color.DarkOrange;
            this.BtnCos.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BtnCos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnCos.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BtnCos.ForeColor = System.Drawing.Color.Gray;
            this.BtnCos.Location = new System.Drawing.Point(372, 439);
            this.BtnCos.Name = "BtnCos";
            this.BtnCos.Size = new System.Drawing.Size(65, 65);
            this.BtnCos.TabIndex = 14;
            this.BtnCos.Text = "cos";
            this.BtnCos.UseVisualStyleBackColor = false;
            this.BtnCos.Click += new System.EventHandler(this.BtnCos_Click);
            // 
            // BtnDergee
            // 
            this.BtnDergee.BackColor = System.Drawing.Color.DarkOrange;
            this.BtnDergee.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BtnDergee.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnDergee.Font = new System.Drawing.Font("Century Gothic", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BtnDergee.ForeColor = System.Drawing.Color.Gray;
            this.BtnDergee.Location = new System.Drawing.Point(442, 439);
            this.BtnDergee.Name = "BtnDergee";
            this.BtnDergee.Size = new System.Drawing.Size(65, 65);
            this.BtnDergee.TabIndex = 15;
            this.BtnDergee.Text = "xʸ";
            this.BtnDergee.UseVisualStyleBackColor = false;
            this.BtnDergee.Click += new System.EventHandler(this.BtnDergee_Click);
            // 
            // FormCalc
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(531, 526);
            this.Controls.Add(this.BtnDergee);
            this.Controls.Add(this.BtnCos);
            this.Controls.Add(this.BtnSin);
            this.Controls.Add(this.BtnDivide);
            this.Controls.Add(this.BtnMult);
            this.Controls.Add(this.BtnMinus);
            this.Controls.Add(this.BtnPlus);
            this.Controls.Add(this.RdBtnRad);
            this.Controls.Add(this.RdBtnGrds);
            this.Controls.Add(this.GrpBxOperands);
            this.Controls.Add(this.TxtBxJrnl);
            this.Controls.Add(this.TxtBxResult);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FormCalc";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Calculator";
            ((System.ComponentModel.ISupportInitialize)(this.NumUDOprnd1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NumUDOprnd2)).EndInit();
            this.GrpBxOperands.ResumeLayout(false);
            this.GrpBxOperands.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox TxtBxResult;
        private System.Windows.Forms.TextBox TxtBxJrnl;
        private System.Windows.Forms.NumericUpDown NumUDOprnd1;
        private System.Windows.Forms.NumericUpDown NumUDOprnd2;
        private System.Windows.Forms.GroupBox GrpBxOperands;
        private System.Windows.Forms.Label LblOprnd2;
        private System.Windows.Forms.Label LblOprnd1;
        private System.Windows.Forms.RadioButton RdBtnGrds;
        private System.Windows.Forms.RadioButton RdBtnRad;
        private System.Windows.Forms.Button BtnPlus;
        private System.Windows.Forms.Button BtnMinus;
        private System.Windows.Forms.Button BtnMult;
        private System.Windows.Forms.Button BtnDivide;
        private System.Windows.Forms.Button BtnSin;
        private System.Windows.Forms.Button BtnCos;
        private System.Windows.Forms.Button BtnDergee;
    }
}