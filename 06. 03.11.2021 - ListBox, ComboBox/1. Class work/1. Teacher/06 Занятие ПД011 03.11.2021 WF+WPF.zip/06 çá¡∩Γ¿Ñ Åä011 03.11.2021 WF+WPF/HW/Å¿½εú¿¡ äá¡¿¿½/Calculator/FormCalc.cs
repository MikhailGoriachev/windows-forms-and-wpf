﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calculator
{
    public partial class FormCalc : Form
    {
        //номер вычисления
        int id = 0;
        //для нумерации вывода в окно журнала операций
        public int getId()
        {
            id++;
            return id;
        }

        public FormCalc()
        {
            InitializeComponent();
            //для подсказок кнопок синуса, косинуса и возведения в степень
            System.Windows.Forms.ToolTip ToolTipSin = new System.Windows.Forms.ToolTip();
            System.Windows.Forms.ToolTip ToolTipCos = new System.Windows.Forms.ToolTip();
            System.Windows.Forms.ToolTip ToolTipDegree = new System.Windows.Forms.ToolTip();
            ToolTipSin.SetToolTip(BtnSin, "Введите значение для операнда 1, для расчета синуса.");
            ToolTipCos.SetToolTip(BtnSin, "Введите значение для операнда 1, для расчета косинуса.");
            ToolTipDegree.SetToolTip(BtnSin, "Операнд 1 возводится в степень операнда 2.");
        }

        private void BtnPlus_Click(object sender, EventArgs e)
        {
            double op1 = ((double)NumUDOprnd1.Value);
            double op2 = ((double)NumUDOprnd2.Value);

            string str = $"{op1} + {op2} = {op1 + op2}";
            TxtBxResult.Text = str;
            TxtBxJrnl.Text += $"{getId()}) {str}\r\n";

            //сохранение в файл
            FormMenu.ds.Save(str + " | " + DateTime.Now.ToString());
        }

        private void BtnMinus_Click(object sender, EventArgs e)
        {
            double op1 = ((double)NumUDOprnd1.Value);
            double op2 = ((double)NumUDOprnd2.Value);

            string str = $"{op1} - {op2} = {op1 - op2}";
            TxtBxResult.Text = str;
            TxtBxJrnl.Text += $"{getId()}) {str}\r\n";

            //сохранение в файл
            FormMenu.ds.Save(str + " | " + DateTime.Now.ToString());
        }

        private void BtnMult_Click(object sender, EventArgs e)
        {
            double op1 = ((double)NumUDOprnd1.Value);
            double op2 = ((double)NumUDOprnd2.Value);

            string str = $"{op1} x {op2} = {op1 * op2}";
            TxtBxResult.Text = str;
            TxtBxJrnl.Text += $"{getId()}) {str}\r\n";

            //сохранение в файл
            FormMenu.ds.Save(str + " | " + DateTime.Now.ToString());
        }

        private void BtnDivide_Click(object sender, EventArgs e)
        {
            double op1 = ((double)NumUDOprnd1.Value);
            double op2 = ((double)NumUDOprnd2.Value);

            string str = (op1 == 0 || op2 == 0)
                ? "0 не допустим в делении!"
                : $"{op1} / {op2} = {op1 / op2}";

            TxtBxResult.Text = str;
            TxtBxJrnl.Text += $"{getId()}) {str}\r\n";
            //сохранение в файл
            FormMenu.ds.Save(str + " | " + DateTime.Now.ToString());
        }

        private void BtnSin_Click(object sender, EventArgs e)
        {
            double op1 = ((double)NumUDOprnd1.Value);

            double x = op1 * Math.PI / 180;

            string str = RdBtnGrds.Checked ?
                $"sin({op1}) = {Math.Sin(op1)}"
                : $"sin({x}) = {Math.Sin((x))}";

            TxtBxResult.Text = str;
            TxtBxJrnl.Text += $"{getId()}) {str}\r\n";

            //сохранение в файл
            FormMenu.ds.Save(str + " | " + DateTime.Now.ToString());
        }


        private void BtnCos_Click(object sender, EventArgs e)
        {
            double op1 = ((double)NumUDOprnd1.Value);

            double x = op1 * Math.PI / 180;

            string str = RdBtnGrds.Checked ?
                $"cos({op1}) = {Math.Cos(op1)}"
                : $"cos({x}) = {Math.Cos((x))}";

            TxtBxResult.Text = str;
            TxtBxJrnl.Text += $"{getId()}) {str}\r\n";
            //сохранение в файл
            FormMenu.ds.Save(str + " | " + DateTime.Now.ToString());

        }

        private void BtnDergee_Click(object sender, EventArgs e)
        {
            double op1 = ((double)NumUDOprnd1.Value);
            double op2 = ((double)NumUDOprnd2.Value);

            string str =  $"{op1}^{op2} = {Math.Pow(op1,op2)}";

            TxtBxResult.Text = str;
            TxtBxJrnl.Text += $"{getId()}) {str}\r\n";

            //сохранение в файл
            FormMenu.ds.Save(str + " | " + DateTime.Now.ToString());

        }
    }
}
