﻿
namespace Calculator
{
    partial class FormMenu
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.LinkLblCalc = new System.Windows.Forms.LinkLabel();
            this.LinkLblAbout = new System.Windows.Forms.LinkLabel();
            this.LinLblJnl = new System.Windows.Forms.LinkLabel();
            this.LinkLblExit = new System.Windows.Forms.LinkLabel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // LinkLblCalc
            // 
            this.LinkLblCalc.ActiveLinkColor = System.Drawing.Color.Gray;
            this.LinkLblCalc.AutoSize = true;
            this.LinkLblCalc.Cursor = System.Windows.Forms.Cursors.Hand;
            this.LinkLblCalc.Font = new System.Drawing.Font("Century Gothic", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LinkLblCalc.LinkColor = System.Drawing.Color.DarkOrange;
            this.LinkLblCalc.Location = new System.Drawing.Point(66, 162);
            this.LinkLblCalc.Name = "LinkLblCalc";
            this.LinkLblCalc.Size = new System.Drawing.Size(185, 34);
            this.LinkLblCalc.TabIndex = 1;
            this.LinkLblCalc.TabStop = true;
            this.LinkLblCalc.Text = "Калькулятор";
            this.LinkLblCalc.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.LinkLblCalc.VisitedLinkColor = System.Drawing.Color.Gray;
            this.LinkLblCalc.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.LinkLblCalc_LinkClicked);
            // 
            // LinkLblAbout
            // 
            this.LinkLblAbout.ActiveLinkColor = System.Drawing.Color.Gray;
            this.LinkLblAbout.AutoSize = true;
            this.LinkLblAbout.Cursor = System.Windows.Forms.Cursors.Hand;
            this.LinkLblAbout.Font = new System.Drawing.Font("Century Gothic", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LinkLblAbout.LinkColor = System.Drawing.Color.DarkOrange;
            this.LinkLblAbout.Location = new System.Drawing.Point(57, 343);
            this.LinkLblAbout.Name = "LinkLblAbout";
            this.LinkLblAbout.Size = new System.Drawing.Size(217, 34);
            this.LinkLblAbout.TabIndex = 2;
            this.LinkLblAbout.TabStop = true;
            this.LinkLblAbout.Text = "О программе";
            this.LinkLblAbout.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.LinkLblAbout.VisitedLinkColor = System.Drawing.Color.Gray;
            this.LinkLblAbout.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.LinkLblAbout_LinkClicked);
            // 
            // LinLblJnl
            // 
            this.LinLblJnl.ActiveLinkColor = System.Drawing.Color.Gray;
            this.LinLblJnl.AutoSize = true;
            this.LinLblJnl.Cursor = System.Windows.Forms.Cursors.Hand;
            this.LinLblJnl.Font = new System.Drawing.Font("Century Gothic", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LinLblJnl.LinkColor = System.Drawing.Color.DarkOrange;
            this.LinLblJnl.Location = new System.Drawing.Point(99, 254);
            this.LinLblJnl.Name = "LinLblJnl";
            this.LinLblJnl.Size = new System.Drawing.Size(127, 34);
            this.LinLblJnl.TabIndex = 3;
            this.LinLblJnl.TabStop = true;
            this.LinLblJnl.Text = "Журнал";
            this.LinLblJnl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.LinLblJnl.VisitedLinkColor = System.Drawing.Color.Gray;
            this.LinLblJnl.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.LinLblJnl_LinkClicked);
            // 
            // LinkLblExit
            // 
            this.LinkLblExit.ActiveLinkColor = System.Drawing.Color.DarkOrange;
            this.LinkLblExit.AutoSize = true;
            this.LinkLblExit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.LinkLblExit.Font = new System.Drawing.Font("Century Gothic", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LinkLblExit.LinkColor = System.Drawing.Color.Gray;
            this.LinkLblExit.Location = new System.Drawing.Point(109, 433);
            this.LinkLblExit.Name = "LinkLblExit";
            this.LinkLblExit.Size = new System.Drawing.Size(98, 34);
            this.LinkLblExit.TabIndex = 4;
            this.LinkLblExit.TabStop = true;
            this.LinkLblExit.Text = "Выход";
            this.LinkLblExit.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.LinkLblExit.VisitedLinkColor = System.Drawing.Color.DarkOrange;
            this.LinkLblExit.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.LinkLblExit_LinkClicked);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Calculator.Properties.Resources.CalcIcon;
            this.pictureBox1.Location = new System.Drawing.Point(108, 24);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(100, 100);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 5;
            this.pictureBox1.TabStop = false;
            // 
            // FormMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(323, 528);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.LinkLblExit);
            this.Controls.Add(this.LinLblJnl);
            this.Controls.Add(this.LinkLblAbout);
            this.Controls.Add(this.LinkLblCalc);
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(341, 575);
            this.MinimizeBox = false;
            this.MinimumSize = new System.Drawing.Size(341, 575);
            this.Name = "FormMenu";
            this.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Calculator";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.LinkLabel LinkLblCalc;
        private System.Windows.Forms.LinkLabel LinkLblAbout;
        private System.Windows.Forms.LinkLabel LinLblJnl;
        private System.Windows.Forms.LinkLabel LinkLblExit;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}

