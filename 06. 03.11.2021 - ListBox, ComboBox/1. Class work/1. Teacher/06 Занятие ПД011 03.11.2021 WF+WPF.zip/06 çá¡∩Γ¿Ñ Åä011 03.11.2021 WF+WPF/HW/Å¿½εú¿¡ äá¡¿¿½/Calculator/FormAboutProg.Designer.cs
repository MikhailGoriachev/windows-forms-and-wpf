﻿
namespace Calculator
{
    partial class FormAboutProg
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.BtnClsAbt = new System.Windows.Forms.Button();
            this.TmrAbt = new System.Windows.Forms.Timer(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Calculator.Properties.Resources.AboutImg;
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(1065, 625);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label1.Font = new System.Drawing.Font("Yu Gothic Light", 24F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(22, 52);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(793, 61);
            this.label1.TabIndex = 1;
            this.label1.Text = "Пилюгин Даниил БД011";
            // 
            // BtnClsAbt
            // 
            this.BtnClsAbt.BackColor = System.Drawing.SystemColors.ControlLight;
            this.BtnClsAbt.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BtnClsAbt.FlatAppearance.BorderSize = 0;
            this.BtnClsAbt.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnClsAbt.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BtnClsAbt.Location = new System.Drawing.Point(1005, 12);
            this.BtnClsAbt.Name = "BtnClsAbt";
            this.BtnClsAbt.Size = new System.Drawing.Size(48, 40);
            this.BtnClsAbt.TabIndex = 2;
            this.BtnClsAbt.Text = "X";
            this.BtnClsAbt.UseVisualStyleBackColor = false;
            this.BtnClsAbt.Click += new System.EventHandler(this.BtnClsAbt_Click);
            // 
            // TmrAbt
            // 
            this.TmrAbt.Interval = 10000;
            this.TmrAbt.Tick += new System.EventHandler(this.TmrAbt_Tick);
            // 
            // FormAboutProg
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1065, 622);
            this.Controls.Add(this.BtnClsAbt);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FormAboutProg";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "О программе";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button BtnClsAbt;
        private System.Windows.Forms.Timer TmrAbt;
    }
}