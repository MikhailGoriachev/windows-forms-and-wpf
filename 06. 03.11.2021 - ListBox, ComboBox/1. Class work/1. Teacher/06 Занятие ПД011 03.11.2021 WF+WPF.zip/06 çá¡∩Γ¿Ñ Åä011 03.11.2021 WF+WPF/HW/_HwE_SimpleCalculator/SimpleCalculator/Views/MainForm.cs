﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using SimpleCalculator.Models;

namespace SimpleCalculator.Views
{
    public partial class MainForm : Form
    {
        // модель - калькулятор для выполнения операций по заданию
        private Calculator _calculator;

        // в конструкторе по умолчанию при таком решении нельзя вызывать 
        // метод InitializeComponent()
        public MainForm():this(new Calculator("operations.log")) { } // MainForm
        
        // основной конструктор формы
        public MainForm(Calculator calculator) {
            InitializeComponent();
            _calculator = calculator;

            // Задать начальные значения элементов интерфейса
            NudOperand1.Value = (decimal)_calculator.Operand1;
            NudOperand2.Value = (decimal)_calculator.Operand2;
            RbtGradus.Checked = _calculator.Angles;
            TxbResult.Text = $"{_calculator}";

            // вывести шапку истории операций
            LblHeader.Text = "   Операнд 1    │ Опер │ Операнд 2    │ Результат";
        } // MainForm


        // Обработчик клика по пункту "меню" Выход: закрытие окна, что приводит
        // к завершению приложения
        private void LnlExit_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e) => Close();


        // клик по радиокнопкам переключателя "Градусы - Радианы"
        private void RbtAngles_CheckedCnaged(object sender, EventArgs e) {
            // установить новый режим вычислений синуса
            _calculator.Angles = RbtGradus.Checked;

            // сбросить поле результата, которое теперь не достоверно 
            TxbResult_Clear();

            // изменить состояние индикатора
            LblAngels.Text = _calculator.Angles ? "градусы" : "радианы";
        } // RbtAngles_CheckedCnaged


        // клик по кнопке выполнения вычислительной операции
        private void BtnOperation_Click(object sender, EventArgs e) {
            // получить код операции
            Operation.TryParse((string)(sender as Button).Tag, out Operation operation);

            // получить операнды операции
            _calculator.Operand1 = (double)NudOperand1.Value;
            _calculator.Operand2 = (double)NudOperand2.Value;

            // выполнить операцию
            double? result = _calculator.Compute(operation);

            // вывести результат в текст-бокс результатов
            // если возникла ошибка вычислений - вывод в текст-бокс результатов красным цветом
            TxbResult.ForeColor = result == null?Color.Red:Color.Black;
            TxbResult.Text = $"{_calculator}";

            // вывести результат в текст-бокс истории вычислений
            // (по правилу - последнее вычисление в верхней строке)
            TxbHistory.Text = _calculator.ToTableRow() + "\r\n" + TxbHistory.Text;
        } // BtnOperation_Click


        // клик по кнопкам-стрелкам в поле ввода приводит к изменению значения этого поля ввода,
        // то есть к недостоверным результатам в поле вывода результатов
        private void NudOperand_ValueChanged(object sender, EventArgs e) => TxbResult_Clear();


        // нажатие на цифровые клавиши или клавишу со знаком в поле ввода приводит
        // к изменению значения этого поля ввода,
        // то есть к недостоверным результатам в поле вывода результатов
        private void NudOperand_KeyDown (object sender, KeyEventArgs e) {
            if (e.KeyCode >= Keys.D0 && e.KeyCode <= Keys.D9 || 
                e.KeyCode == Keys.OemMinus || 
                e.KeyCode == Keys.Oemplus)
                TxbResult_Clear();
        } // NudOperand_KeyDown


        // очистка поля вывода результата
        private void TxbResult_Clear() {
            TxbResult.Text = $"{0:n5}";
            TxbResult.ForeColor = Color.Black;
        } // TxbResult_Clear  


        // вывод окна сведений о приложении и разработчике
        private void LnlAbout_LinkClicked (object sender, LinkLabelLinkClickedEventArgs e) {
            AboutForm aboutForm = new AboutForm();
            aboutForm.ShowDialog();
        } // LnlAbout_LinkClicked


        // вывод окна для работы с файлом журнала операций
        private void LnlLog_LinkClicked (object sender, LinkLabelLinkClickedEventArgs e) {
            LogForm logForm = new LogForm();
            logForm.ShowDialog();
        } // LnlLog_LinkClicked
    } // class MainForm
}
