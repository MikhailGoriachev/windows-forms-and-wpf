﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SimpleCalculator.Views
{
    public partial class LogForm : Form
    {
        private string _logFileName;

        public LogForm ():this("operations.log") { } // LogForm

        public LogForm (string logFileName) {
            InitializeComponent();

            // получить имя файла-журнала
            _logFileName = logFileName;

            // вывести шапку журнала операций
            TxbHeader.Text = "  Дата и время     │   Операнд 1   │ Опер │   Операнд 2  │ Результат";
        } // LogForm


        // при загрузка формы прочитать данные из файла-журнала,
        // вывести их в текст-бокс 
        private void LogForm_Load (object sender, EventArgs e) {
            TxbLogging.Lines = File.ReadAllLines(_logFileName, Encoding.UTF8);
        } // LogForm_Load

        // очистка файла-журнала операций
        private void BtnClearLog_Click (object sender, EventArgs e) {
            File.WriteAllText(_logFileName, "", Encoding.UTF8);
            TxbLogging.Text = "";
        } // BtnClearLog_Click
    } // class LogForm
}
