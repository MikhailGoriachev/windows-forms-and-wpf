﻿
namespace SimpleCalculator.Views
{
    partial class AboutForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose (bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent () {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AboutForm));
            this.TbxAbout = new System.Windows.Forms.TextBox();
            this.BtnOk = new System.Windows.Forms.Button();
            this.LblAbout = new System.Windows.Forms.Label();
            this.TmrAbout = new System.Windows.Forms.Timer(this.components);
            this.SuspendLayout();
            // 
            // TbxAbout
            // 
            this.TbxAbout.BackColor = System.Drawing.SystemColors.Window;
            this.TbxAbout.Font = new System.Drawing.Font("Verdana", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TbxAbout.Location = new System.Drawing.Point(24, 16);
            this.TbxAbout.Multiline = true;
            this.TbxAbout.Name = "TbxAbout";
            this.TbxAbout.ReadOnly = true;
            this.TbxAbout.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.TbxAbout.Size = new System.Drawing.Size(744, 344);
            this.TbxAbout.TabIndex = 0;
            this.TbxAbout.TabStop = false;
            this.TbxAbout.Text = resources.GetString("TbxAbout.Text");
            // 
            // BtnOk
            // 
            this.BtnOk.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.BtnOk.Font = new System.Drawing.Font("Verdana", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BtnOk.Location = new System.Drawing.Point(544, 384);
            this.BtnOk.Name = "BtnOk";
            this.BtnOk.Size = new System.Drawing.Size(224, 39);
            this.BtnOk.TabIndex = 1;
            this.BtnOk.Text = "OK";
            this.BtnOk.UseVisualStyleBackColor = true;
            // 
            // LblAbout
            // 
            this.LblAbout.Font = new System.Drawing.Font("Verdana", 10.2F);
            this.LblAbout.Location = new System.Drawing.Point(32, 392);
            this.LblAbout.Name = "LblAbout";
            this.LblAbout.Size = new System.Drawing.Size(480, 23);
            this.LblAbout.TabIndex = 2;
            this.LblAbout.Text = "Студент Программер, ПД011, КА Шаг, Донецк, 2021";
            // 
            // TmrAbout
            // 
            this.TmrAbout.Interval = 10000;
            this.TmrAbout.Tick += new System.EventHandler(this.TmrAbout_Tick);
            // 
            // AboutForm
            // 
            this.AcceptButton = this.BtnOk;
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.LblAbout);
            this.Controls.Add(this.BtnOk);
            this.Controls.Add(this.TbxAbout);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(818, 497);
            this.MinimizeBox = false;
            this.MinimumSize = new System.Drawing.Size(818, 497);
            this.Name = "AboutForm";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Задание на 03.11.2021 - сведения о приложении и разработчике";
            this.Load += new System.EventHandler(this.AboutForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox TbxAbout;
        private System.Windows.Forms.Button BtnOk;
        private System.Windows.Forms.Label LblAbout;
        private System.Windows.Forms.Timer TmrAbout;
    }
}