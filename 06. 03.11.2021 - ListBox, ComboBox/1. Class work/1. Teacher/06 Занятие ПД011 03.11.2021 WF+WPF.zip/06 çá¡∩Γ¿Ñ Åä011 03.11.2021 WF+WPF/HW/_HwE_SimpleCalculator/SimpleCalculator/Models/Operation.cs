﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SimpleCalculator.Models
{
    // коды операций калькулятора
    public enum Operation: byte
    {
        None,  // нет операции
        Add,   // сложение
        Sub,   // вычитание
        Mul,   // умножение
        Div,   // деление
        Sqrt,  // взятие корня квадратного
        Pow,   // возведение в степень
        Sin    // взятие синуса
    } // enum Operation
}
