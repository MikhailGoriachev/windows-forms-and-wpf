﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SimpleCalculator.Views
{
    public partial class AboutForm : Form
    {
        public AboutForm () {
            InitializeComponent();
        }

        // запуск отсчета таймера по окончании загрузки формы
        private void AboutForm_Load(object sender, EventArgs e) => TmrAbout.Enabled = true;


        // обработчик события таймера
        private void TmrAbout_Tick (object sender, EventArgs e) {
            TmrAbout.Enabled = false;
            Close();
        } // TmrAbout_Tick
    }
}
