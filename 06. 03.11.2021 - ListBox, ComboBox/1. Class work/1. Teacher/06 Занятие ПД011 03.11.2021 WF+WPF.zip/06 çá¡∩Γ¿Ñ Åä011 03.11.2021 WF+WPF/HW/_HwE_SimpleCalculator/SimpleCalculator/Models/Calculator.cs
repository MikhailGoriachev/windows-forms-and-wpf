﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SimpleCalculator.Models
{
    // класс для реализации операций по заданию
    public class Calculator
    {
        // первый операнд операции
        private double _operand1;
        public double Operand1 {
            get => _operand1;
            set => _operand1 = value;
        } // Operand1
          
        // второй операнд операции
        private double _operand2;
        public double Operand2 {
            get => _operand2;
            set => _operand2 = value;
        } // Operand2

        // последняя выполненная операция
        private Operation _lastOperation;
        public Operation LastOperation {
            get => _lastOperation;
            private set => _lastOperation = value;
        } // LastOperation


        // представление углов: true - градусы, false - радианы
        private bool _angles;
        public bool Angles {
            get => _angles;
            set => _angles = value;
        } // Angles

        // для хранения результата последней операции
        private double? _result;


        // имя файла-журнала
        private string _logFileName;
        public string LogFileName {
            get => _logFileName;
            set {
                if (string.IsNullOrWhiteSpace(value))
                    throw new Exception("Calculator. Некорректное имя файла-журнала");

                _logFileName = value;
            }
        } // LogFileName


        // конструкторы
        public Calculator(): this("operations.log") { } // Calculator

        public Calculator(string logLogFileName) {
            _logFileName = logLogFileName;

            _operand1 = 0;
            _operand2 = 0;
            _angles = true;          // градусы
            _lastOperation = Operation.None;
            
            // если ни одной операции еще не было выполнено, считаем, что 0 вполне
            // корректный результат (по крайней мере так работают все известные мне
            // приложения-калькуляторы)
            _result = 0;
        } // Calculator


        // выполнение операции, если возвращается null - операция завершилсь
        // с ошибкой
        // данные об операции и ошибке записываем в журнал операций
        public double? Compute(Operation op) {
            _result = null;  // пессимистический прогнз

            // запомнить операцию - это последняя выполненная операция
            _lastOperation = op;

            // строка для вывода данных в журнал операций
            string logLine;

            try {
                switch (op) {
                    case Operation.Add:
                        _result = _operand1 + _operand2;
                        break;

                    case Operation.Sub:
                        _result = _operand1 - _operand2;
                        break;

                    case Operation.Mul:
                        _result = _operand1 * _operand2;
                        break;

                    case Operation.Div:
                        if (Math.Abs(_operand2) < 1e-12)
                            throw new DivideByZeroException("Делить на ноль нельзя");

                        _result = _operand1 / _operand2;
                        break;

                    // извлечение корня квадратного из операнд1
                    case Operation.Sqrt:
                        if (_operand1 < 0)
                            throw new ArgumentException("Извлечь квадратный корень отрицательного числа нельзя");

                        _result = Math.Sqrt(_operand1);
                        break;

                    // возведение в степень, операнд1 в степени операнд2
                    case Operation.Pow:
                        _result = Math.Pow(_operand1, _operand2);
                        break;

                    case Operation.Sin:
                        // если угол указан в градусах - перевести его в радианы
                        double temp = _angles ? Math.PI * _operand1 / 180d : _operand1;

                        _result = Math.Sin(temp);
                        break;
                } // switch

                // подготовить строку для записи в файл операций
                logLine = ToTableRow();
            } catch (Exception ex) {
                // записать операцию и сообщение об ошибке в журнал операций
                string op2 = _lastOperation == Operation.Sin || _lastOperation == Operation.Sqrt
                    ? " ".PadRight(12)
                    : $"{_operand2,12:n5}";
                logLine = $"  {_operand1,12:n5} │ {_lastOperation,-4} │ {op2} │ {ex.Message}";
            } // try-catch

            // записать операцию (в т.ч. и сообщение об ошибке в журанал операций)
            File.AppendAllText(_logFileName, $"{DateTime.Now:dd/MM/yyyy HH.mm.ss}│{logLine}\n", Encoding.UTF8);
            return _result;
        } // Compute


        // строковое представление данных
        public override string ToString() => 
            _result == null?$"Ошибка":$"{_result:n5}";


        // табличное представление данных калькулятора
        public string ToTableRow() {
            string temp = _result == null ?"Ошибка".PadRight(20) : $"{_result, 20:n5}";
            string op2 = _lastOperation == Operation.Sin || _lastOperation == Operation.Sqrt
                ? " ".PadRight(12)
                : $"{_operand2, 12:n5}";
            return $"  {_operand1, 12:n5} │ {_lastOperation, -4} │ {op2} │ {temp}";
        } // ToTableRow

        // шапка таблицы результатов
        public static string Header =>
            "┌──────────────┬──────┬──────────────┬────────────────────────┐\n" +
            "│ Операнд 1    │ Опер │ Операнд 2    │ Результат              │\n" +
            "├──────────────┼──────┼──────────────┼────────────────────────┤\n";

    } // class Calculator
}
