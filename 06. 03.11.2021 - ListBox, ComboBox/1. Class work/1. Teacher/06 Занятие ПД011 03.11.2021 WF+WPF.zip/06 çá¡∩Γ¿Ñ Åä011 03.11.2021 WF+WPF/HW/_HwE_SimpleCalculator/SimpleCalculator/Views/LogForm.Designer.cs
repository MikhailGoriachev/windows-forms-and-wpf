﻿
namespace SimpleCalculator.Views
{
    partial class LogForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose (bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent () {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(LogForm));
            this.BtnClose = new System.Windows.Forms.Button();
            this.TxbLogging = new System.Windows.Forms.TextBox();
            this.BtnClearLog = new System.Windows.Forms.Button();
            this.TxbHeader = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // BtnClose
            // 
            this.BtnClose.BackColor = System.Drawing.Color.PowderBlue;
            this.BtnClose.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.BtnClose.Font = new System.Drawing.Font("Verdana", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BtnClose.Location = new System.Drawing.Point(728, 488);
            this.BtnClose.Name = "BtnClose";
            this.BtnClose.Size = new System.Drawing.Size(224, 39);
            this.BtnClose.TabIndex = 3;
            this.BtnClose.Text = "Закрыть";
            this.BtnClose.UseVisualStyleBackColor = false;
            // 
            // TxbLogging
            // 
            this.TxbLogging.BackColor = System.Drawing.SystemColors.Window;
            this.TxbLogging.Font = new System.Drawing.Font("Consolas", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TxbLogging.Location = new System.Drawing.Point(32, 56);
            this.TxbLogging.Multiline = true;
            this.TxbLogging.Name = "TxbLogging";
            this.TxbLogging.ReadOnly = true;
            this.TxbLogging.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.TxbLogging.Size = new System.Drawing.Size(920, 408);
            this.TxbLogging.TabIndex = 2;
            this.TxbLogging.TabStop = false;
            this.TxbLogging.WordWrap = false;
            // 
            // BtnClearLog
            // 
            this.BtnClearLog.BackColor = System.Drawing.Color.PowderBlue;
            this.BtnClearLog.Font = new System.Drawing.Font("Verdana", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BtnClearLog.Location = new System.Drawing.Point(472, 488);
            this.BtnClearLog.Name = "BtnClearLog";
            this.BtnClearLog.Size = new System.Drawing.Size(224, 39);
            this.BtnClearLog.TabIndex = 4;
            this.BtnClearLog.Text = "Очистка журнала";
            this.BtnClearLog.UseVisualStyleBackColor = false;
            this.BtnClearLog.Click += new System.EventHandler(this.BtnClearLog_Click);
            // 
            // TxbHeader
            // 
            this.TxbHeader.Font = new System.Drawing.Font("Consolas", 10.8F);
            this.TxbHeader.Location = new System.Drawing.Point(32, 24);
            this.TxbHeader.Name = "TxbHeader";
            this.TxbHeader.ReadOnly = true;
            this.TxbHeader.Size = new System.Drawing.Size(920, 29);
            this.TxbHeader.TabIndex = 5;
            // 
            // LogForm
            // 
            this.AcceptButton = this.BtnClose;
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(982, 553);
            this.Controls.Add(this.TxbHeader);
            this.Controls.Add(this.BtnClearLog);
            this.Controls.Add(this.BtnClose);
            this.Controls.Add(this.TxbLogging);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(1000, 600);
            this.MinimizeBox = false;
            this.MinimumSize = new System.Drawing.Size(1000, 600);
            this.Name = "LogForm";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Задание на 03.11.2021 - журнал операций";
            this.Load += new System.EventHandler(this.LogForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button BtnClose;
        private System.Windows.Forms.TextBox TxbLogging;
        private System.Windows.Forms.Button BtnClearLog;
        private System.Windows.Forms.TextBox TxbHeader;
    }
}