﻿
namespace SimpleCalculator.Views
{
    partial class MainForm
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.GrbControls = new System.Windows.Forms.GroupBox();
            this.LblAngels = new System.Windows.Forms.Label();
            this.BtnSin = new System.Windows.Forms.Button();
            this.PnlMode = new System.Windows.Forms.Panel();
            this.RbtRadian = new System.Windows.Forms.RadioButton();
            this.RbtGradus = new System.Windows.Forms.RadioButton();
            this.BtnPower = new System.Windows.Forms.Button();
            this.BtnSqrt = new System.Windows.Forms.Button();
            this.BtnDiv = new System.Windows.Forms.Button();
            this.BtnMul = new System.Windows.Forms.Button();
            this.BtnSub = new System.Windows.Forms.Button();
            this.BtnAdd = new System.Windows.Forms.Button();
            this.NudOperand2 = new System.Windows.Forms.NumericUpDown();
            this.LblOperand2 = new System.Windows.Forms.Label();
            this.NudOperand1 = new System.Windows.Forms.NumericUpDown();
            this.LblOperand1 = new System.Windows.Forms.Label();
            this.TxbResult = new System.Windows.Forms.TextBox();
            this.LblResult = new System.Windows.Forms.Label();
            this.GrbHistory = new System.Windows.Forms.GroupBox();
            this.TxbHistory = new System.Windows.Forms.TextBox();
            this.LblHeader = new System.Windows.Forms.Label();
            this.PnlMenu = new System.Windows.Forms.Panel();
            this.LnlExit = new System.Windows.Forms.LinkLabel();
            this.LnlAbout = new System.Windows.Forms.LinkLabel();
            this.LnlLog = new System.Windows.Forms.LinkLabel();
            this.GrbControls.SuspendLayout();
            this.PnlMode.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.NudOperand2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NudOperand1)).BeginInit();
            this.GrbHistory.SuspendLayout();
            this.PnlMenu.SuspendLayout();
            this.SuspendLayout();
            // 
            // GrbControls
            // 
            this.GrbControls.Controls.Add(this.LblAngels);
            this.GrbControls.Controls.Add(this.BtnSin);
            this.GrbControls.Controls.Add(this.PnlMode);
            this.GrbControls.Controls.Add(this.BtnPower);
            this.GrbControls.Controls.Add(this.BtnSqrt);
            this.GrbControls.Controls.Add(this.BtnDiv);
            this.GrbControls.Controls.Add(this.BtnMul);
            this.GrbControls.Controls.Add(this.BtnSub);
            this.GrbControls.Controls.Add(this.BtnAdd);
            this.GrbControls.Controls.Add(this.NudOperand2);
            this.GrbControls.Controls.Add(this.LblOperand2);
            this.GrbControls.Controls.Add(this.NudOperand1);
            this.GrbControls.Controls.Add(this.LblOperand1);
            this.GrbControls.Controls.Add(this.TxbResult);
            this.GrbControls.Controls.Add(this.LblResult);
            this.GrbControls.Font = new System.Drawing.Font("Verdana", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.GrbControls.Location = new System.Drawing.Point(32, 56);
            this.GrbControls.Name = "GrbControls";
            this.GrbControls.Size = new System.Drawing.Size(472, 336);
            this.GrbControls.TabIndex = 3;
            this.GrbControls.TabStop = false;
            this.GrbControls.Text = " Вычисления";
            // 
            // LblAngels
            // 
            this.LblAngels.AutoSize = true;
            this.LblAngels.Location = new System.Drawing.Point(366, 40);
            this.LblAngels.Name = "LblAngels";
            this.LblAngels.Size = new System.Drawing.Size(82, 20);
            this.LblAngels.TabIndex = 14;
            this.LblAngels.Text = "градусы";
            // 
            // BtnSin
            // 
            this.BtnSin.Font = new System.Drawing.Font("Verdana", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BtnSin.Location = new System.Drawing.Point(24, 256);
            this.BtnSin.Name = "BtnSin";
            this.BtnSin.Size = new System.Drawing.Size(128, 40);
            this.BtnSin.TabIndex = 13;
            this.BtnSin.Tag = "Sin";
            this.BtnSin.Text = "sin(x)";
            this.BtnSin.UseVisualStyleBackColor = true;
            this.BtnSin.Click += new System.EventHandler(this.BtnOperation_Click);
            // 
            // PnlMode
            // 
            this.PnlMode.Controls.Add(this.RbtRadian);
            this.PnlMode.Controls.Add(this.RbtGradus);
            this.PnlMode.Location = new System.Drawing.Point(168, 256);
            this.PnlMode.Name = "PnlMode";
            this.PnlMode.Size = new System.Drawing.Size(264, 40);
            this.PnlMode.TabIndex = 12;
            // 
            // RbtRadian
            // 
            this.RbtRadian.AutoSize = true;
            this.RbtRadian.Location = new System.Drawing.Point(136, 8);
            this.RbtRadian.Name = "RbtRadian";
            this.RbtRadian.Size = new System.Drawing.Size(108, 24);
            this.RbtRadian.TabIndex = 1;
            this.RbtRadian.TabStop = true;
            this.RbtRadian.Text = "радианы";
            this.RbtRadian.UseVisualStyleBackColor = true;
            this.RbtRadian.CheckedChanged += new System.EventHandler(this.RbtAngles_CheckedCnaged);
            // 
            // RbtGradus
            // 
            this.RbtGradus.AutoSize = true;
            this.RbtGradus.Location = new System.Drawing.Point(16, 8);
            this.RbtGradus.Name = "RbtGradus";
            this.RbtGradus.Size = new System.Drawing.Size(103, 24);
            this.RbtGradus.TabIndex = 0;
            this.RbtGradus.TabStop = true;
            this.RbtGradus.Text = "градусы";
            this.RbtGradus.UseVisualStyleBackColor = true;
            this.RbtGradus.CheckedChanged += new System.EventHandler(this.RbtAngles_CheckedCnaged);
            // 
            // BtnPower
            // 
            this.BtnPower.Font = new System.Drawing.Font("Verdana", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BtnPower.Location = new System.Drawing.Point(374, 200);
            this.BtnPower.Name = "BtnPower";
            this.BtnPower.Size = new System.Drawing.Size(64, 40);
            this.BtnPower.TabIndex = 11;
            this.BtnPower.Tag = "Pow";
            this.BtnPower.Text = "xˆn";
            this.BtnPower.UseVisualStyleBackColor = true;
            this.BtnPower.Click += new System.EventHandler(this.BtnOperation_Click);
            // 
            // BtnSqrt
            // 
            this.BtnSqrt.Font = new System.Drawing.Font("Verdana", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BtnSqrt.Location = new System.Drawing.Point(304, 200);
            this.BtnSqrt.Name = "BtnSqrt";
            this.BtnSqrt.Size = new System.Drawing.Size(64, 40);
            this.BtnSqrt.TabIndex = 10;
            this.BtnSqrt.Tag = "Sqrt";
            this.BtnSqrt.Text = "√";
            this.BtnSqrt.UseVisualStyleBackColor = true;
            this.BtnSqrt.Click += new System.EventHandler(this.BtnOperation_Click);
            // 
            // BtnDiv
            // 
            this.BtnDiv.Font = new System.Drawing.Font("Verdana", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BtnDiv.Location = new System.Drawing.Point(234, 200);
            this.BtnDiv.Name = "BtnDiv";
            this.BtnDiv.Size = new System.Drawing.Size(64, 40);
            this.BtnDiv.TabIndex = 9;
            this.BtnDiv.Tag = "Div";
            this.BtnDiv.Text = "÷";
            this.BtnDiv.UseVisualStyleBackColor = true;
            this.BtnDiv.Click += new System.EventHandler(this.BtnOperation_Click);
            // 
            // BtnMul
            // 
            this.BtnMul.Font = new System.Drawing.Font("Verdana", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BtnMul.Location = new System.Drawing.Point(164, 200);
            this.BtnMul.Name = "BtnMul";
            this.BtnMul.Size = new System.Drawing.Size(64, 40);
            this.BtnMul.TabIndex = 8;
            this.BtnMul.Tag = "Mul";
            this.BtnMul.Text = "×";
            this.BtnMul.UseVisualStyleBackColor = true;
            this.BtnMul.Click += new System.EventHandler(this.BtnOperation_Click);
            // 
            // BtnSub
            // 
            this.BtnSub.Font = new System.Drawing.Font("Verdana", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BtnSub.Location = new System.Drawing.Point(94, 200);
            this.BtnSub.Name = "BtnSub";
            this.BtnSub.Size = new System.Drawing.Size(64, 40);
            this.BtnSub.TabIndex = 7;
            this.BtnSub.Tag = "Sub";
            this.BtnSub.Text = "−";
            this.BtnSub.UseVisualStyleBackColor = true;
            this.BtnSub.Click += new System.EventHandler(this.BtnOperation_Click);
            // 
            // BtnAdd
            // 
            this.BtnAdd.Font = new System.Drawing.Font("Verdana", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BtnAdd.Location = new System.Drawing.Point(24, 200);
            this.BtnAdd.Name = "BtnAdd";
            this.BtnAdd.Size = new System.Drawing.Size(64, 40);
            this.BtnAdd.TabIndex = 6;
            this.BtnAdd.Tag = "Add";
            this.BtnAdd.Text = "+";
            this.BtnAdd.UseVisualStyleBackColor = true;
            this.BtnAdd.Click += new System.EventHandler(this.BtnOperation_Click);
            // 
            // NudOperand2
            // 
            this.NudOperand2.DecimalPlaces = 5;
            this.NudOperand2.Increment = new decimal(new int[] {
            1,
            0,
            0,
            196608});
            this.NudOperand2.Location = new System.Drawing.Point(240, 144);
            this.NudOperand2.Maximum = new decimal(new int[] {
            1661992960,
            1808227885,
            5,
            0});
            this.NudOperand2.Minimum = new decimal(new int[] {
            1661992960,
            1808227885,
            5,
            -2147483648});
            this.NudOperand2.Name = "NudOperand2";
            this.NudOperand2.Size = new System.Drawing.Size(200, 28);
            this.NudOperand2.TabIndex = 5;
            this.NudOperand2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.NudOperand2.ThousandsSeparator = true;
            this.NudOperand2.ValueChanged += new System.EventHandler(this.NudOperand_ValueChanged);
            this.NudOperand2.KeyDown += new System.Windows.Forms.KeyEventHandler(this.NudOperand_KeyDown);
            // 
            // LblOperand2
            // 
            this.LblOperand2.AutoSize = true;
            this.LblOperand2.Location = new System.Drawing.Point(240, 120);
            this.LblOperand2.Name = "LblOperand2";
            this.LblOperand2.Size = new System.Drawing.Size(141, 20);
            this.LblOperand2.TabIndex = 4;
            this.LblOperand2.Text = "операнд 2 (n):";
            // 
            // NudOperand1
            // 
            this.NudOperand1.DecimalPlaces = 5;
            this.NudOperand1.Increment = new decimal(new int[] {
            1,
            0,
            0,
            196608});
            this.NudOperand1.Location = new System.Drawing.Point(24, 144);
            this.NudOperand1.Maximum = new decimal(new int[] {
            -1530494976,
            232830,
            0,
            0});
            this.NudOperand1.Minimum = new decimal(new int[] {
            1661992960,
            1808227885,
            5,
            -2147483648});
            this.NudOperand1.Name = "NudOperand1";
            this.NudOperand1.Size = new System.Drawing.Size(200, 28);
            this.NudOperand1.TabIndex = 3;
            this.NudOperand1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.NudOperand1.ThousandsSeparator = true;
            this.NudOperand1.ValueChanged += new System.EventHandler(this.NudOperand_ValueChanged);
            this.NudOperand1.KeyDown += new System.Windows.Forms.KeyEventHandler(this.NudOperand_KeyDown);
            // 
            // LblOperand1
            // 
            this.LblOperand1.AutoSize = true;
            this.LblOperand1.Location = new System.Drawing.Point(24, 120);
            this.LblOperand1.Name = "LblOperand1";
            this.LblOperand1.Size = new System.Drawing.Size(140, 20);
            this.LblOperand1.TabIndex = 2;
            this.LblOperand1.Text = "операнд 1 (x):";
            // 
            // TxbResult
            // 
            this.TxbResult.BackColor = System.Drawing.Color.MintCream;
            this.TxbResult.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TxbResult.Location = new System.Drawing.Point(24, 64);
            this.TxbResult.Name = "TxbResult";
            this.TxbResult.ReadOnly = true;
            this.TxbResult.Size = new System.Drawing.Size(424, 32);
            this.TxbResult.TabIndex = 1;
            this.TxbResult.TabStop = false;
            this.TxbResult.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // LblResult
            // 
            this.LblResult.AutoSize = true;
            this.LblResult.Location = new System.Drawing.Point(16, 40);
            this.LblResult.Name = "LblResult";
            this.LblResult.Size = new System.Drawing.Size(103, 20);
            this.LblResult.TabIndex = 0;
            this.LblResult.Text = "результат:";
            // 
            // GrbHistory
            // 
            this.GrbHistory.Controls.Add(this.TxbHistory);
            this.GrbHistory.Controls.Add(this.LblHeader);
            this.GrbHistory.Font = new System.Drawing.Font("Verdana", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.GrbHistory.Location = new System.Drawing.Point(520, 56);
            this.GrbHistory.Name = "GrbHistory";
            this.GrbHistory.Size = new System.Drawing.Size(728, 360);
            this.GrbHistory.TabIndex = 4;
            this.GrbHistory.TabStop = false;
            this.GrbHistory.Text = " История вычислений ";
            // 
            // TxbHistory
            // 
            this.TxbHistory.BackColor = System.Drawing.Color.MintCream;
            this.TxbHistory.Font = new System.Drawing.Font("Consolas", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TxbHistory.Location = new System.Drawing.Point(8, 56);
            this.TxbHistory.Multiline = true;
            this.TxbHistory.Name = "TxbHistory";
            this.TxbHistory.ReadOnly = true;
            this.TxbHistory.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.TxbHistory.Size = new System.Drawing.Size(712, 280);
            this.TxbHistory.TabIndex = 3;
            this.TxbHistory.TabStop = false;
            // 
            // LblHeader
            // 
            this.LblHeader.Font = new System.Drawing.Font("Consolas", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblHeader.Location = new System.Drawing.Point(0, 32);
            this.LblHeader.Name = "LblHeader";
            this.LblHeader.Size = new System.Drawing.Size(736, 22);
            this.LblHeader.TabIndex = 2;
            this.LblHeader.Text = "операнд 1    операция  операнд 2   результат";
            // 
            // PnlMenu
            // 
            this.PnlMenu.BackColor = System.Drawing.Color.AliceBlue;
            this.PnlMenu.Controls.Add(this.LnlExit);
            this.PnlMenu.Controls.Add(this.LnlAbout);
            this.PnlMenu.Controls.Add(this.LnlLog);
            this.PnlMenu.Dock = System.Windows.Forms.DockStyle.Top;
            this.PnlMenu.Location = new System.Drawing.Point(0, 0);
            this.PnlMenu.Name = "PnlMenu";
            this.PnlMenu.Size = new System.Drawing.Size(1286, 32);
            this.PnlMenu.TabIndex = 5;
            // 
            // LnlExit
            // 
            this.LnlExit.AutoSize = true;
            this.LnlExit.Font = new System.Drawing.Font("Verdana", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LnlExit.Location = new System.Drawing.Point(320, 6);
            this.LnlExit.Name = "LnlExit";
            this.LnlExit.Size = new System.Drawing.Size(73, 20);
            this.LnlExit.TabIndex = 5;
            this.LnlExit.TabStop = true;
            this.LnlExit.Text = "Выход";
            this.LnlExit.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.LnlExit_LinkClicked);
            // 
            // LnlAbout
            // 
            this.LnlAbout.AutoSize = true;
            this.LnlAbout.Font = new System.Drawing.Font("Verdana", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LnlAbout.Location = new System.Drawing.Point(152, 6);
            this.LnlAbout.Name = "LnlAbout";
            this.LnlAbout.Size = new System.Drawing.Size(136, 20);
            this.LnlAbout.TabIndex = 4;
            this.LnlAbout.TabStop = true;
            this.LnlAbout.Text = "О программе";
            this.LnlAbout.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.LnlAbout_LinkClicked);
            // 
            // LnlLog
            // 
            this.LnlLog.AutoSize = true;
            this.LnlLog.Font = new System.Drawing.Font("Verdana", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LnlLog.Location = new System.Drawing.Point(40, 6);
            this.LnlLog.Name = "LnlLog";
            this.LnlLog.Size = new System.Drawing.Size(86, 20);
            this.LnlLog.TabIndex = 3;
            this.LnlLog.TabStop = true;
            this.LnlLog.Text = "Журнал";
            this.LnlLog.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.LnlLog_LinkClicked);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1286, 417);
            this.Controls.Add(this.PnlMenu);
            this.Controls.Add(this.GrbHistory);
            this.Controls.Add(this.GrbControls);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(1304, 464);
            this.MinimumSize = new System.Drawing.Size(1304, 464);
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Задание на 03.11.2021 - использование элементов интерфейса";
            this.GrbControls.ResumeLayout(false);
            this.GrbControls.PerformLayout();
            this.PnlMode.ResumeLayout(false);
            this.PnlMode.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.NudOperand2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NudOperand1)).EndInit();
            this.GrbHistory.ResumeLayout(false);
            this.GrbHistory.PerformLayout();
            this.PnlMenu.ResumeLayout(false);
            this.PnlMenu.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.GroupBox GrbControls;
        private System.Windows.Forms.Button BtnPower;
        private System.Windows.Forms.Button BtnSqrt;
        private System.Windows.Forms.Button BtnDiv;
        private System.Windows.Forms.Button BtnMul;
        private System.Windows.Forms.Button BtnSub;
        private System.Windows.Forms.Button BtnAdd;
        private System.Windows.Forms.NumericUpDown NudOperand2;
        private System.Windows.Forms.Label LblOperand2;
        private System.Windows.Forms.NumericUpDown NudOperand1;
        private System.Windows.Forms.Label LblOperand1;
        private System.Windows.Forms.TextBox TxbResult;
        private System.Windows.Forms.Label LblResult;
        private System.Windows.Forms.GroupBox GrbHistory;
        private System.Windows.Forms.Button BtnSin;
        private System.Windows.Forms.Panel PnlMode;
        private System.Windows.Forms.RadioButton RbtRadian;
        private System.Windows.Forms.RadioButton RbtGradus;
        private System.Windows.Forms.TextBox TxbHistory;
        private System.Windows.Forms.Label LblHeader;
        private System.Windows.Forms.Panel PnlMenu;
        private System.Windows.Forms.LinkLabel LnlExit;
        private System.Windows.Forms.LinkLabel LnlAbout;
        private System.Windows.Forms.LinkLabel LnlLog;
        private System.Windows.Forms.Label LblAngels;
    }
}

