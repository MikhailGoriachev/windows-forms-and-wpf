﻿
namespace H_W5WF
{
    partial class FormLog
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.TxbLog = new System.Windows.Forms.TextBox();
            this.BtnLogExit = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // TxbLog
            // 
            this.TxbLog.Font = new System.Drawing.Font("Consolas", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TxbLog.Location = new System.Drawing.Point(12, 39);
            this.TxbLog.Multiline = true;
            this.TxbLog.Name = "TxbLog";
            this.TxbLog.ReadOnly = true;
            this.TxbLog.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.TxbLog.Size = new System.Drawing.Size(354, 335);
            this.TxbLog.TabIndex = 0;
            this.TxbLog.WordWrap = false;
            // 
            // BtnLogExit
            // 
            this.BtnLogExit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.BtnLogExit.Font = new System.Drawing.Font("Lucida Console", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BtnLogExit.Location = new System.Drawing.Point(371, 336);
            this.BtnLogExit.Name = "BtnLogExit";
            this.BtnLogExit.Size = new System.Drawing.Size(184, 50);
            this.BtnLogExit.TabIndex = 1;
            this.BtnLogExit.Text = "Выход";
            this.BtnLogExit.UseVisualStyleBackColor = false;
            this.BtnLogExit.Click += new System.EventHandler(this.BtnLogExit_Click);
            // 
            // FormLog
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.BackColor = System.Drawing.Color.LightCyan;
            this.ClientSize = new System.Drawing.Size(584, 411);
            this.Controls.Add(this.BtnLogExit);
            this.Controls.Add(this.TxbLog);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "FormLog";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Журнал";
            this.Load += new System.EventHandler(this.FormLog_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox TxbLog;
        private System.Windows.Forms.Button BtnLogExit;
    }
}