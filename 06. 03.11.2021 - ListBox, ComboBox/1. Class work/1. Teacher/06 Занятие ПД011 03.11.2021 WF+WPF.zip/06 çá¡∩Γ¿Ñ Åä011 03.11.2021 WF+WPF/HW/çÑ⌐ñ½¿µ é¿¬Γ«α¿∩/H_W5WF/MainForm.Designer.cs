﻿
namespace H_W5WF
{
    partial class MainForm
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.BtnAboutProgm = new System.Windows.Forms.Button();
            this.BtnExit = new System.Windows.Forms.Button();
            this.BtnLog = new System.Windows.Forms.Button();
            this.LblElemA = new System.Windows.Forms.Label();
            this.LblElemB = new System.Windows.Forms.Label();
            this.NudElemA = new System.Windows.Forms.NumericUpDown();
            this.NudElemB = new System.Windows.Forms.NumericUpDown();
            this.LblOperation = new System.Windows.Forms.Label();
            this.CmbOperation = new System.Windows.Forms.ComboBox();
            this.TxbResult = new System.Windows.Forms.TextBox();
            this.BtnResult = new System.Windows.Forms.Button();
            this.LblMessagTxt = new System.Windows.Forms.Label();
            this.BtnClear = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.NudElemA)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NudElemB)).BeginInit();
            this.SuspendLayout();
            // 
            // BtnAboutProgm
            // 
            this.BtnAboutProgm.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.BtnAboutProgm.Font = new System.Drawing.Font("Lucida Console", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BtnAboutProgm.Location = new System.Drawing.Point(12, 374);
            this.BtnAboutProgm.Name = "BtnAboutProgm";
            this.BtnAboutProgm.Size = new System.Drawing.Size(189, 47);
            this.BtnAboutProgm.TabIndex = 0;
            this.BtnAboutProgm.Text = "О программе";
            this.BtnAboutProgm.UseVisualStyleBackColor = false;
            this.BtnAboutProgm.Click += new System.EventHandler(this.BtnAboutProgm_Click);
            // 
            // BtnExit
            // 
            this.BtnExit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.BtnExit.Font = new System.Drawing.Font("Lucida Console", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BtnExit.Location = new System.Drawing.Point(419, 374);
            this.BtnExit.Name = "BtnExit";
            this.BtnExit.Size = new System.Drawing.Size(189, 47);
            this.BtnExit.TabIndex = 1;
            this.BtnExit.Text = "Выход";
            this.BtnExit.UseVisualStyleBackColor = false;
            this.BtnExit.Click += new System.EventHandler(this.BtnExit_Click);
            // 
            // BtnLog
            // 
            this.BtnLog.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.BtnLog.Font = new System.Drawing.Font("Lucida Console", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BtnLog.Location = new System.Drawing.Point(207, 374);
            this.BtnLog.Name = "BtnLog";
            this.BtnLog.Size = new System.Drawing.Size(189, 50);
            this.BtnLog.TabIndex = 2;
            this.BtnLog.Text = "Журнал";
            this.BtnLog.UseVisualStyleBackColor = false;
            this.BtnLog.Click += new System.EventHandler(this.BtnLog_Click);
            // 
            // LblElemA
            // 
            this.LblElemA.AutoSize = true;
            this.LblElemA.Font = new System.Drawing.Font("Lucida Console", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblElemA.Location = new System.Drawing.Point(12, 66);
            this.LblElemA.Name = "LblElemA";
            this.LblElemA.Size = new System.Drawing.Size(95, 14);
            this.LblElemA.TabIndex = 3;
            this.LblElemA.Text = "Значение А:";
            // 
            // LblElemB
            // 
            this.LblElemB.AutoSize = true;
            this.LblElemB.Font = new System.Drawing.Font("Lucida Console", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblElemB.Location = new System.Drawing.Point(12, 190);
            this.LblElemB.Name = "LblElemB";
            this.LblElemB.Size = new System.Drawing.Size(95, 13);
            this.LblElemB.TabIndex = 4;
            this.LblElemB.Text = "Значение B:";
            // 
            // NudElemA
            // 
            this.NudElemA.Location = new System.Drawing.Point(185, 66);
            this.NudElemA.Name = "NudElemA";
            this.NudElemA.Size = new System.Drawing.Size(120, 20);
            this.NudElemA.TabIndex = 5;
            // 
            // NudElemB
            // 
            this.NudElemB.Location = new System.Drawing.Point(185, 189);
            this.NudElemB.Name = "NudElemB";
            this.NudElemB.Size = new System.Drawing.Size(120, 20);
            this.NudElemB.TabIndex = 6;
            // 
            // LblOperation
            // 
            this.LblOperation.AutoSize = true;
            this.LblOperation.Font = new System.Drawing.Font("Lucida Console", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblOperation.Location = new System.Drawing.Point(12, 128);
            this.LblOperation.Name = "LblOperation";
            this.LblOperation.Size = new System.Drawing.Size(151, 14);
            this.LblOperation.TabIndex = 7;
            this.LblOperation.Text = "Выберите операцию:";
            // 
            // CmbOperation
            // 
            this.CmbOperation.FormattingEnabled = true;
            this.CmbOperation.Location = new System.Drawing.Point(185, 127);
            this.CmbOperation.Name = "CmbOperation";
            this.CmbOperation.Size = new System.Drawing.Size(121, 21);
            this.CmbOperation.TabIndex = 8;
            // 
            // TxbResult
            // 
            this.TxbResult.Font = new System.Drawing.Font("Consolas", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TxbResult.Location = new System.Drawing.Point(338, 66);
            this.TxbResult.Multiline = true;
            this.TxbResult.Name = "TxbResult";
            this.TxbResult.Size = new System.Drawing.Size(248, 214);
            this.TxbResult.TabIndex = 9;
            // 
            // BtnResult
            // 
            this.BtnResult.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.BtnResult.Font = new System.Drawing.Font("Lucida Console", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BtnResult.Location = new System.Drawing.Point(207, 308);
            this.BtnResult.Name = "BtnResult";
            this.BtnResult.Size = new System.Drawing.Size(189, 50);
            this.BtnResult.TabIndex = 10;
            this.BtnResult.Text = "Расчитать";
            this.BtnResult.UseVisualStyleBackColor = false;
            this.BtnResult.Click += new System.EventHandler(this.BtnResult_Click);
            // 
            // LblMessagTxt
            // 
            this.LblMessagTxt.Font = new System.Drawing.Font("Lucida Console", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblMessagTxt.Location = new System.Drawing.Point(30, 10);
            this.LblMessagTxt.Name = "LblMessagTxt";
            this.LblMessagTxt.Size = new System.Drawing.Size(538, 23);
            this.LblMessagTxt.TabIndex = 11;
            this.LblMessagTxt.Text = "Арифметические операции";
            this.LblMessagTxt.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // BtnClear
            // 
            this.BtnClear.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.BtnClear.Font = new System.Drawing.Font("Lucida Console", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BtnClear.Location = new System.Drawing.Point(419, 311);
            this.BtnClear.Name = "BtnClear";
            this.BtnClear.Size = new System.Drawing.Size(189, 47);
            this.BtnClear.TabIndex = 12;
            this.BtnClear.Text = "Очистить";
            this.BtnClear.UseVisualStyleBackColor = false;
            this.BtnClear.Click += new System.EventHandler(this.BtnClear_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(624, 441);
            this.Controls.Add(this.BtnClear);
            this.Controls.Add(this.LblMessagTxt);
            this.Controls.Add(this.BtnResult);
            this.Controls.Add(this.TxbResult);
            this.Controls.Add(this.CmbOperation);
            this.Controls.Add(this.LblOperation);
            this.Controls.Add(this.NudElemB);
            this.Controls.Add(this.NudElemA);
            this.Controls.Add(this.LblElemB);
            this.Controls.Add(this.LblElemA);
            this.Controls.Add(this.BtnLog);
            this.Controls.Add(this.BtnExit);
            this.Controls.Add(this.BtnAboutProgm);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MinimizeBox = false;
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Домашнее задание №5";
            this.Load += new System.EventHandler(this.MainForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.NudElemA)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NudElemB)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button BtnAboutProgm;
        private System.Windows.Forms.Button BtnExit;
        private System.Windows.Forms.Button BtnLog;
        private System.Windows.Forms.Label LblElemA;
        private System.Windows.Forms.Label LblElemB;
        private System.Windows.Forms.NumericUpDown NudElemA;
        private System.Windows.Forms.NumericUpDown NudElemB;
        private System.Windows.Forms.Label LblOperation;
        private System.Windows.Forms.ComboBox CmbOperation;
        private System.Windows.Forms.TextBox TxbResult;
        private System.Windows.Forms.Button BtnResult;
        private System.Windows.Forms.Label LblMessagTxt;
        private System.Windows.Forms.Button BtnClear;
    }
}

