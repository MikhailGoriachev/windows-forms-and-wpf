﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace H_W5WF
{
    public partial class FormAboutProgm : Form
    {
        public FormAboutProgm()
        {
            InitializeComponent();
        }

        public string GetText() { return LblAboutProgm.Text; }
        public void SetText(string text)
        {
            LblAboutProgm.Text = text;
            TmrAboutProgm.Enabled = true;
        }

        private void TmrAboutProgm_Tick(object sender, EventArgs e)
        {
            LblAboutProgm.Text = "";
            TmrAboutProgm.Enabled = false;
            Close();
        }
    }
}
