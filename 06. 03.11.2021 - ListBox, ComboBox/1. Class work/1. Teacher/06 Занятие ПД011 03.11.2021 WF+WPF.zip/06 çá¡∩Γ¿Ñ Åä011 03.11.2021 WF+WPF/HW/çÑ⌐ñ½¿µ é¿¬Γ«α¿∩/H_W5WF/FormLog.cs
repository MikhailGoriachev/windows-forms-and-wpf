﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace H_W5WF
{
    public partial class FormLog : Form
    {
        public FormLog()
        {
            InitializeComponent();
        }

        private void FormLog_Load(object sender, EventArgs e)
        {
            //TxbLog.Lines = File.ReadAllLines(@"..\..\MainForm.cs");
        } // FormLog_Load

        private void BtnLogExit_Click(object sender, EventArgs e) => Close();
        
            
        
    }
}
