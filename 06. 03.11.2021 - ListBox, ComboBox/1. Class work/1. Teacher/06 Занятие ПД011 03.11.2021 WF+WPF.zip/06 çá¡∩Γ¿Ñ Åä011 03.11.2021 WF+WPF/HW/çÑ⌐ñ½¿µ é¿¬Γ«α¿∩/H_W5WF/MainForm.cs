﻿using System;
using System.Windows.Forms;

namespace H_W5WF
{
    public partial class MainForm : Form
    {
        // формы приложения
        private FormAboutProgm _first;
        private FormLog _second;
        public MainForm()
        {
            InitializeComponent();
        }

        private void BtnExit_Click(object sender, EventArgs e) => Application.Exit();

        private void BtnAboutProgm_Click(object sender, EventArgs e)
        {
            _first = new FormAboutProgm();

            _first.SetText("Студент: Зейдлиц Виктория\nГруппа: ПД011\nКА Шаг г.Донецк 2021");


            // Отобразить форму в модальном режиме
            _first.ShowDialog();
        }

        private void BtnLog_Click(object sender, EventArgs e)
        {
            _second = new FormLog();

            _second.ShowDialog();
        }

        private void BtnResult_Click(object sender, EventArgs e)
        {  
            try
            {
                int a;
                int b;
                string output;

                string mop = CmbOperation.SelectedItem.ToString();

                // Выводим результат в текстовое поле
                output = "Вычисление операторов:\r\n ";

                a = Convert.ToInt32(NudElemA.Value);
                b = Convert.ToInt32(NudElemB.Value);

                double result = 0;
                if (mop == "+")
                {
                    result = a + b;
                    output += string.Format($" {a} + {b}") + " = " + result;
                }
                else if (mop == "-")
                {
                    result = a - b;
                    output += string.Format($" {a} - {b}") + " = " + result;
                }
                else if (mop == "*")
                {
                    result = a * b;
                    output += string.Format($" {a} * {b}") + " = " + result;
                }
                else if (mop == "/")
                {
                    result = a / b;
                    output += string.Format($" {a} / {b}") + " = " + result;
                }
                else if (mop == "Sin")
                {
                    result = Math.Sin(a);
                    output += string.Format($" Sin {a}") + " = " + result;
                }
                else
                {
                    result = Math.Sqrt(a);
                    output += string.Format($" Sqrt {a}") + " = " + result;
                }// if


                TxbResult.Text = output;
            }
            // Обрабатываем исключение возникающее при делении на ноль
            catch (DivideByZeroException)
            {
                TxbResult.Text = "Деление на 0!";
            }
            // Обрабатываем исключение при некорректном вводе числа в консоль
            catch (FormatException)
            {
                TxbResult.Text = "Это НЕ число!";
            }
            Console.ReadLine();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            CmbOperation.Items.Add("+");
            CmbOperation.Items.Add("-");
            CmbOperation.Items.Add("*");
            CmbOperation.Items.Add("/");
            CmbOperation.Items.Add("Sin");
            CmbOperation.Items.Add("Sqrt");

            CmbOperation.SelectedIndex = 0;
        }

        private void BtnClear_Click(object sender, EventArgs e)
        {
            TxbResult.Clear();
            NudElemA.Focus();
        }
    }
}
