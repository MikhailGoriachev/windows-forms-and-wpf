﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HomeWork03._11._21
{
    public partial class Log : Form
    {
        private string filename = @"..\..\Log.txt";

        public Log()
        {
            InitializeComponent();
        }

        // чтение из лога
        private void btn_read_log_Click(object sender, EventArgs e)
        {
            string text1 = File.ReadAllText(filename, Encoding.UTF8);
            txb_log.Text = text1;            
        }

        private void btn_clear_log_Click(object sender, EventArgs e)
        {
            File.WriteAllText(filename , "", Encoding.UTF8);
        }
    }
}
