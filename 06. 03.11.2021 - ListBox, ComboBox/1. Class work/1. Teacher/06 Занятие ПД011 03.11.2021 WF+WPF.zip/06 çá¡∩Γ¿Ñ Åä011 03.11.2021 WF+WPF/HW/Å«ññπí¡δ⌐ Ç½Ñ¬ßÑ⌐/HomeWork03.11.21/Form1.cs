﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HomeWork03._11._21
{
    public partial class MainForm : Form
    {
        private Info _info;
        private Log _log;
        private string filename = @"..\..\Log.txt";

        public MainForm()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        // сложение
        private void lbl_sum_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            int result = (int)numericUpDownOperand1.Value + (int)numericUpDownOperator2.Value;
            txb_current_oper.Clear();
            txb_current_oper.Text = $"{numericUpDownOperand1.Value} + {numericUpDownOperator2.Value} = {result}\r\n";   // вывести в строку текущей операпции
            txb_result.Text += $"{numericUpDownOperand1.Value} + {numericUpDownOperator2.Value} = {result}\r\n";    // вывести в строку истории
            using (StreamWriter sw = new StreamWriter(filename, true, Encoding.UTF8))
            {
                // запись строки в файл
                sw.Write($"{numericUpDownOperand1.Value} + {numericUpDownOperator2.Value} = {result}\r\n");

            } // using
        }

        // вычитание
        private void lbl_subtraction_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            txb_current_oper.Clear();
            int a = (int)numericUpDownOperand1.Value; // 1 операнд
            int b = (int)numericUpDownOperator2.Value;  // 2 операнд
            if (a < b) // если первый операнд меньше второго
            {
                txb_current_oper.Text = $"{numericUpDownOperand1.Value} - {numericUpDownOperator2.Value} = операция невозможна, {a} < {b}\r\n"; // вывести в строку текущей операпции
                txb_result.Text += $"{numericUpDownOperand1.Value} - {numericUpDownOperator2.Value} = операция невозможна, {a} < {b}\r\n"; // вывести в строку истории
                using (StreamWriter sw = new StreamWriter(filename, true, Encoding.UTF8))
                {
                    // запись строки в файл
                    sw.Write($"{numericUpDownOperand1.Value} - {numericUpDownOperator2.Value} = операция невозможна, {a} < {b}\r\n");

                } // using
            }
            else { 

                int result = a - b;
                txb_current_oper.Text = $"{numericUpDownOperand1.Value} - {numericUpDownOperator2.Value} = {result}\r\n";   // вывести в строку текущей операпции
                txb_result.Text += $"{numericUpDownOperand1.Value} - {numericUpDownOperator2.Value} = {result}\r\n";    // вывести в строку истории
                using (StreamWriter sw = new StreamWriter(filename, true, Encoding.UTF8))
                {
                    // запись строки в файл
                    sw.Write($"{numericUpDownOperand1.Value} - {numericUpDownOperator2.Value} = {result}\r\n");

                } // using
            }
                       
        }

        // умножение
        private void lbl_mult_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            int result = (int)numericUpDownOperand1.Value * (int)numericUpDownOperator2.Value;
            txb_current_oper.Clear();
            txb_current_oper.Text = $"{numericUpDownOperand1.Value} * {numericUpDownOperator2.Value} = {result}\r\n";   // вывести в строку текущей операпции
            txb_result.Text += $"{numericUpDownOperand1.Value} * {numericUpDownOperator2.Value} = {result}\r\n";    // вывести в строку истории
            using (StreamWriter sw = new StreamWriter(filename, true, Encoding.UTF8))
            {
                // запись строки в файл
                sw.Write($"{numericUpDownOperand1.Value} * {numericUpDownOperator2.Value} = {result}\r\n");

            } // using
        }

        // деление
        private void lnl_division_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            txb_current_oper.Clear();
            double a = (double)numericUpDownOperand1.Value; // 1 операнд
            double b = (double)numericUpDownOperator2.Value;  // 2 операнд
            if (b == 0) // если первый операнд меньше второго
            {
                txb_current_oper.Text = $"{numericUpDownOperand1.Value} / {numericUpDownOperator2.Value} = операция невозможна, {b} = 0\r\n"; // вывести в строку текущей операпции
                txb_result.Text += $"{numericUpDownOperand1.Value} / {numericUpDownOperator2.Value} = операция невозможна, на ноль делить нельзя\r\n"; // вывести в строку истории
                using (StreamWriter sw = new StreamWriter(filename, true, Encoding.UTF8))
                {
                    // запись строки в файл
                    sw.Write($"{numericUpDownOperand1.Value} / {numericUpDownOperator2.Value} = операция невозможна, на ноль делить нельзя\r\n");

                } // using
            }
            else
            {

                double result = a / b;
                txb_current_oper.Text = $"{numericUpDownOperand1.Value} / {numericUpDownOperator2.Value} = {result}\r\n";   // вывести в строку текущей операпции
                txb_result.Text += $"{numericUpDownOperand1.Value} / {numericUpDownOperator2.Value} = {result}\r\n";    // вывести в строку истории
                using (StreamWriter sw = new StreamWriter(filename, true, Encoding.UTF8))
                {
                    // запись строки в файл
                    sw.Write($"{numericUpDownOperand1.Value} / {numericUpDownOperator2.Value} = {result}\r\n");

                } // using
            }


        }

        //вычисление квадратного корня
        private void lnl_sqrt_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            txb_current_oper.Clear();
            double a = (double)numericUpDownOperand1.Value; // 1 операнд
            double b = (double)numericUpDownOperator2.Value;  // 2 операнд
            if (a < 0||b < 0) // если первый операнд меньше второго
            {
                txb_current_oper.Text = $" √{a}  , √{b} = операция невозможна\r\n"; // вывести в строку текущей операпции
                txb_result.Text += $" √{a}  , √{b} = операция невозможна\r\n"; // вывести в строку истории
                using (StreamWriter sw = new StreamWriter(filename, true, Encoding.UTF8))
                {
                    // запись строки в файл
                    sw.Write($" √{a}  , √{b} = операция невозможна\r\n");

                } // using
            }
            else
            {

                double result = a / b;
                txb_current_oper.Text = $"√{a} = {Math.Sqrt(a)}  , √{b} = {Math.Sqrt(b)}\r\n";   // вывести в строку текущей операпции
                txb_result.Text += $"√{a} = {Math.Sqrt(a)}  , √{b} = {Math.Sqrt(b)}\r\n";    // вывести в строку истории
                using (StreamWriter sw = new StreamWriter(filename, true, Encoding.UTF8))
                {
                    // запись строки в файл
                    sw.Write($"√{a} = {Math.Sqrt(a)}  , √{b} = {Math.Sqrt(b)}\r\n");

                } // using

            }
        }
        // вычисление степени
        private void lnl_pow_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            txb_current_oper.Clear();
            double a = (double)numericUpDownOperand1.Value; // 1 операнд
            double b = (double)numericUpDownOperator2.Value;  // 2 операнд
            double result = Math.Pow(a, b);            
            txb_current_oper.Text = $"{a} ^ {b} = {result}\r\n";   // вывести в строку текущей операпции
            txb_result.Text += $"{a} ^ {b} = {result}\r\n";    // вывести в строку истории
            using (StreamWriter sw = new StreamWriter(filename, true, Encoding.UTF8))
            {
                // запись строки в файл
                sw.Write($"{a} ^ {b} = {result}\r\n");

            } // using

        }

        private void numericUpDownOperand1_ValueChanged(object sender, EventArgs e)
        {
            txb_current_oper.Clear(); // очистить строку текущей операпции

        }

        private void numericUpDownOperator2_ValueChanged(object sender, EventArgs e)
        {
            txb_current_oper.Clear(); // очистить строку текущей операпции
        }

        private void numericUpDown3_ValueChanged(object sender, EventArgs e)
        {
            txb_current_oper.Clear(); // очистить строку текущей операпции
        }

        private void numericUpDownOperand1_Click(object sender, EventArgs e)
        {
            txb_current_oper.Clear(); // очистить строку текущей операпции

        }

        private void numericUpDownOperator2_Click(object sender, EventArgs e)
        {
            txb_current_oper.Clear(); // очистить строку текущей операпции

        }

        private void numericUpDown3_Click(object sender, EventArgs e)
        {
            txb_current_oper.Clear(); // очистить строку текущей операпции

        }

        private void lnl_about_program_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            _info = new Info();
            _info.ShowDialog();  // модальное отображение формы
        }

        private void lnl_search_sin_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            double result1;
            double result2;
            double a = (double)numericUpDownOperand1.Value; // 1 операнд
            double b = (double)numericUpDownOperator2.Value;  // 2 операнд
            // если градусы
            if (rbt_gradius.Checked)
            {
                result1 = Math.Sin(a);
                result2 = Math.Sin(b);
            }
            else { // если радианы

                 result1=Math.Sin((a*180/ Math.PI));
                 result2=Math.Sin((b*180/ Math.PI));
            }

            txb_current_oper.Clear();           
           
            txb_current_oper.Text = $"Sin {a} = {result1,2:f}, sin {b} = {result2,2:f}\r\n";   // вывести в строку текущей операпции
            txb_result.Text += $"Sin {a} = {result1,2:f}, sin {b} = {result2,2:f}\r\n";    // вывести в строку истории

            using (StreamWriter sw = new StreamWriter(filename, true, Encoding.UTF8))
            {
                // запись строки в файл
                sw.Write($"Sin {a} = {result1,2:f}, sin {b} = {result2,2:f}\r\n");                 
               
            } // using
        }

        // выход
        private void lnl_quit_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Application.Exit();
        }

        // журнал
        private void lnl_log_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            _log = new Log();
            _log.ShowDialog();  // модальное отображение формы
        }
    }
}
