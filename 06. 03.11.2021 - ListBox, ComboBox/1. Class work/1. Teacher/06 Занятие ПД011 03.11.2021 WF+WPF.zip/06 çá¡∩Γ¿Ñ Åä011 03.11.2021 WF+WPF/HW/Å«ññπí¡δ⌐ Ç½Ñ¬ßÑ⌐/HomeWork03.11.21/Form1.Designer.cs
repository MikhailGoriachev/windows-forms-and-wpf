﻿
namespace HomeWork03._11._21
{
    partial class MainForm
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.lnl_about_program = new System.Windows.Forms.LinkLabel();
            this.numericUpDownOperand1 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDownOperator2 = new System.Windows.Forms.NumericUpDown();
            this.lnl_log = new System.Windows.Forms.LinkLabel();
            this.lnl_quit = new System.Windows.Forms.LinkLabel();
            this.lbl_sum = new System.Windows.Forms.LinkLabel();
            this.lbl_subtraction = new System.Windows.Forms.LinkLabel();
            this.lbl_mult = new System.Windows.Forms.LinkLabel();
            this.lnl_division = new System.Windows.Forms.LinkLabel();
            this.lnl_search_sin = new System.Windows.Forms.LinkLabel();
            this.lnl_sqrt = new System.Windows.Forms.LinkLabel();
            this.lnl_pow = new System.Windows.Forms.LinkLabel();
            this.grb_choice_angle = new System.Windows.Forms.GroupBox();
            this.rbt_gradius = new System.Windows.Forms.RadioButton();
            this.rbt_radians = new System.Windows.Forms.RadioButton();
            this.lbl_operand1 = new System.Windows.Forms.Label();
            this.lbl_operand2 = new System.Windows.Forms.Label();
            this.grb_input = new System.Windows.Forms.GroupBox();
            this.grb_choice_operate = new System.Windows.Forms.GroupBox();
            this.txb_current_oper = new System.Windows.Forms.TextBox();
            this.grb_log_oper = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.txb_result = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownOperand1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownOperator2)).BeginInit();
            this.grb_choice_angle.SuspendLayout();
            this.grb_input.SuspendLayout();
            this.grb_choice_operate.SuspendLayout();
            this.grb_log_oper.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // lnl_about_program
            // 
            this.lnl_about_program.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lnl_about_program.AutoSize = true;
            this.lnl_about_program.Font = new System.Drawing.Font("Century", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lnl_about_program.Location = new System.Drawing.Point(51, 460);
            this.lnl_about_program.Name = "lnl_about_program";
            this.lnl_about_program.Size = new System.Drawing.Size(141, 23);
            this.lnl_about_program.TabIndex = 0;
            this.lnl_about_program.TabStop = true;
            this.lnl_about_program.Text = "О программе";
            this.lnl_about_program.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnl_about_program_LinkClicked);
            // 
            // numericUpDownOperand1
            // 
            this.numericUpDownOperand1.Location = new System.Drawing.Point(36, 72);
            this.numericUpDownOperand1.Maximum = new decimal(new int[] {
            999999999,
            0,
            0,
            0});
            this.numericUpDownOperand1.Minimum = new decimal(new int[] {
            999999999,
            0,
            0,
            -2147483648});
            this.numericUpDownOperand1.Name = "numericUpDownOperand1";
            this.numericUpDownOperand1.Size = new System.Drawing.Size(120, 22);
            this.numericUpDownOperand1.TabIndex = 1;
            this.numericUpDownOperand1.Click += new System.EventHandler(this.numericUpDownOperand1_Click);
            // 
            // numericUpDownOperator2
            // 
            this.numericUpDownOperator2.Location = new System.Drawing.Point(36, 113);
            this.numericUpDownOperator2.Maximum = new decimal(new int[] {
            999999999,
            0,
            0,
            0});
            this.numericUpDownOperator2.Minimum = new decimal(new int[] {
            999999999,
            0,
            0,
            -2147483648});
            this.numericUpDownOperator2.Name = "numericUpDownOperator2";
            this.numericUpDownOperator2.Size = new System.Drawing.Size(120, 22);
            this.numericUpDownOperator2.TabIndex = 2;
            this.numericUpDownOperator2.Click += new System.EventHandler(this.numericUpDownOperator2_Click);
            // 
            // lnl_log
            // 
            this.lnl_log.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.lnl_log.AutoSize = true;
            this.lnl_log.Font = new System.Drawing.Font("Century", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lnl_log.Location = new System.Drawing.Point(488, 460);
            this.lnl_log.Name = "lnl_log";
            this.lnl_log.Size = new System.Drawing.Size(91, 23);
            this.lnl_log.TabIndex = 3;
            this.lnl_log.TabStop = true;
            this.lnl_log.Text = "Журнал";
            this.lnl_log.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnl_log_LinkClicked);
            // 
            // lnl_quit
            // 
            this.lnl_quit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.lnl_quit.AutoSize = true;
            this.lnl_quit.Font = new System.Drawing.Font("Century", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lnl_quit.Location = new System.Drawing.Point(875, 460);
            this.lnl_quit.Name = "lnl_quit";
            this.lnl_quit.Size = new System.Drawing.Size(74, 23);
            this.lnl_quit.TabIndex = 4;
            this.lnl_quit.TabStop = true;
            this.lnl_quit.Text = "Выход";
            this.lnl_quit.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnl_quit_LinkClicked);
            // 
            // lbl_sum
            // 
            this.lbl_sum.AutoSize = true;
            this.lbl_sum.Location = new System.Drawing.Point(54, 23);
            this.lbl_sum.Name = "lbl_sum";
            this.lbl_sum.Size = new System.Drawing.Size(62, 13);
            this.lbl_sum.TabIndex = 6;
            this.lbl_sum.TabStop = true;
            this.lbl_sum.Text = "Сложение";
            this.lbl_sum.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lbl_sum_LinkClicked);
            // 
            // lbl_subtraction
            // 
            this.lbl_subtraction.AutoSize = true;
            this.lbl_subtraction.Location = new System.Drawing.Point(54, 68);
            this.lbl_subtraction.Name = "lbl_subtraction";
            this.lbl_subtraction.Size = new System.Drawing.Size(66, 13);
            this.lbl_subtraction.TabIndex = 7;
            this.lbl_subtraction.TabStop = true;
            this.lbl_subtraction.Text = "Вычитание";
            this.lbl_subtraction.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lbl_subtraction_LinkClicked);
            // 
            // lbl_mult
            // 
            this.lbl_mult.AutoSize = true;
            this.lbl_mult.Location = new System.Drawing.Point(54, 113);
            this.lbl_mult.Name = "lbl_mult";
            this.lbl_mult.Size = new System.Drawing.Size(70, 13);
            this.lbl_mult.TabIndex = 8;
            this.lbl_mult.TabStop = true;
            this.lbl_mult.Text = "Умножение";
            this.lbl_mult.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lbl_mult_LinkClicked);
            // 
            // lnl_division
            // 
            this.lnl_division.AutoSize = true;
            this.lnl_division.Location = new System.Drawing.Point(54, 158);
            this.lnl_division.Name = "lnl_division";
            this.lnl_division.Size = new System.Drawing.Size(53, 13);
            this.lnl_division.TabIndex = 9;
            this.lnl_division.TabStop = true;
            this.lnl_division.Text = "Деление";
            this.lnl_division.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnl_division_LinkClicked);
            // 
            // lnl_search_sin
            // 
            this.lnl_search_sin.AutoSize = true;
            this.lnl_search_sin.Location = new System.Drawing.Point(54, 203);
            this.lnl_search_sin.Name = "lnl_search_sin";
            this.lnl_search_sin.Size = new System.Drawing.Size(111, 13);
            this.lnl_search_sin.TabIndex = 10;
            this.lnl_search_sin.TabStop = true;
            this.lnl_search_sin.Text = "Вычисление синуса";
            this.lnl_search_sin.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnl_search_sin_LinkClicked);
            // 
            // lnl_sqrt
            // 
            this.lnl_sqrt.AutoSize = true;
            this.lnl_sqrt.Location = new System.Drawing.Point(54, 248);
            this.lnl_sqrt.Name = "lnl_sqrt";
            this.lnl_sqrt.Size = new System.Drawing.Size(178, 13);
            this.lnl_sqrt.TabIndex = 11;
            this.lnl_sqrt.TabStop = true;
            this.lnl_sqrt.Text = "Вычисление квадратного корня";
            this.lnl_sqrt.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnl_sqrt_LinkClicked);
            // 
            // lnl_pow
            // 
            this.lnl_pow.AutoSize = true;
            this.lnl_pow.Location = new System.Drawing.Point(54, 293);
            this.lnl_pow.Name = "lnl_pow";
            this.lnl_pow.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.lnl_pow.Size = new System.Drawing.Size(118, 13);
            this.lnl_pow.TabIndex = 12;
            this.lnl_pow.TabStop = true;
            this.lnl_pow.Text = "Вычисление степени";
            this.lnl_pow.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnl_pow_LinkClicked);
            // 
            // grb_choice_angle
            // 
            this.grb_choice_angle.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.grb_choice_angle.Controls.Add(this.rbt_radians);
            this.grb_choice_angle.Controls.Add(this.rbt_gradius);
            this.grb_choice_angle.Location = new System.Drawing.Point(55, 268);
            this.grb_choice_angle.Name = "grb_choice_angle";
            this.grb_choice_angle.Size = new System.Drawing.Size(212, 108);
            this.grb_choice_angle.TabIndex = 13;
            this.grb_choice_angle.TabStop = false;
            this.grb_choice_angle.Text = "Единицы измерения угла";
            // 
            // rbt_gradius
            // 
            this.rbt_gradius.AutoSize = true;
            this.rbt_gradius.Checked = true;
            this.rbt_gradius.Location = new System.Drawing.Point(20, 31);
            this.rbt_gradius.Name = "rbt_gradius";
            this.rbt_gradius.Size = new System.Drawing.Size(67, 17);
            this.rbt_gradius.TabIndex = 0;
            this.rbt_gradius.TabStop = true;
            this.rbt_gradius.Text = "Градусы";
            this.rbt_gradius.UseVisualStyleBackColor = true;
            // 
            // rbt_radians
            // 
            this.rbt_radians.AutoSize = true;
            this.rbt_radians.Location = new System.Drawing.Point(20, 68);
            this.rbt_radians.Name = "rbt_radians";
            this.rbt_radians.Size = new System.Drawing.Size(78, 17);
            this.rbt_radians.TabIndex = 1;
            this.rbt_radians.TabStop = true;
            this.rbt_radians.Text = "Радианны";
            this.rbt_radians.UseVisualStyleBackColor = true;
            // 
            // lbl_operand1
            // 
            this.lbl_operand1.AutoSize = true;
            this.lbl_operand1.Location = new System.Drawing.Point(33, 56);
            this.lbl_operand1.Name = "lbl_operand1";
            this.lbl_operand1.Size = new System.Drawing.Size(61, 13);
            this.lbl_operand1.TabIndex = 14;
            this.lbl_operand1.Text = "Операнд 1";
            // 
            // lbl_operand2
            // 
            this.lbl_operand2.AutoSize = true;
            this.lbl_operand2.Location = new System.Drawing.Point(33, 97);
            this.lbl_operand2.Name = "lbl_operand2";
            this.lbl_operand2.Size = new System.Drawing.Size(63, 13);
            this.lbl_operand2.TabIndex = 15;
            this.lbl_operand2.Text = "Операнд 2";
            // 
            // grb_input
            // 
            this.grb_input.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.grb_input.Controls.Add(this.lbl_operand2);
            this.grb_input.Controls.Add(this.lbl_operand1);
            this.grb_input.Controls.Add(this.numericUpDownOperator2);
            this.grb_input.Controls.Add(this.numericUpDownOperand1);
            this.grb_input.Location = new System.Drawing.Point(55, 47);
            this.grb_input.Name = "grb_input";
            this.grb_input.Size = new System.Drawing.Size(212, 199);
            this.grb_input.TabIndex = 16;
            this.grb_input.TabStop = false;
            this.grb_input.Text = "Ввод операндов";
            // 
            // grb_choice_operate
            // 
            this.grb_choice_operate.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.grb_choice_operate.Controls.Add(this.lnl_pow);
            this.grb_choice_operate.Controls.Add(this.lnl_sqrt);
            this.grb_choice_operate.Controls.Add(this.lnl_search_sin);
            this.grb_choice_operate.Controls.Add(this.lnl_division);
            this.grb_choice_operate.Controls.Add(this.lbl_mult);
            this.grb_choice_operate.Controls.Add(this.lbl_subtraction);
            this.grb_choice_operate.Controls.Add(this.lbl_sum);
            this.grb_choice_operate.Location = new System.Drawing.Point(341, 47);
            this.grb_choice_operate.Name = "grb_choice_operate";
            this.grb_choice_operate.Size = new System.Drawing.Size(271, 329);
            this.grb_choice_operate.TabIndex = 17;
            this.grb_choice_operate.TabStop = false;
            this.grb_choice_operate.Text = "Выбор операции";
            // 
            // txb_current_oper
            // 
            this.txb_current_oper.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txb_current_oper.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.AllSystemSources;
            this.txb_current_oper.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.txb_current_oper.Location = new System.Drawing.Point(6, 14);
            this.txb_current_oper.Name = "txb_current_oper";
            this.txb_current_oper.ReadOnly = true;
            this.txb_current_oper.Size = new System.Drawing.Size(289, 22);
            this.txb_current_oper.TabIndex = 18;
            // 
            // grb_log_oper
            // 
            this.grb_log_oper.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.grb_log_oper.Controls.Add(this.txb_result);
            this.grb_log_oper.Location = new System.Drawing.Point(655, 107);
            this.grb_log_oper.Name = "grb_log_oper";
            this.grb_log_oper.Size = new System.Drawing.Size(301, 269);
            this.grb_log_oper.TabIndex = 20;
            this.grb_log_oper.TabStop = false;
            this.grb_log_oper.Text = "История операций";
            // 
            // groupBox2
            // 
            this.groupBox2.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.groupBox2.Controls.Add(this.txb_current_oper);
            this.groupBox2.Location = new System.Drawing.Point(655, 47);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(301, 42);
            this.groupBox2.TabIndex = 21;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Текущая операция";
            // 
            // txb_result
            // 
            this.txb_result.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txb_result.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.txb_result.Location = new System.Drawing.Point(6, 21);
            this.txb_result.Multiline = true;
            this.txb_result.Name = "txb_result";
            this.txb_result.ReadOnly = true;
            this.txb_result.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txb_result.Size = new System.Drawing.Size(289, 242);
            this.txb_result.TabIndex = 0;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1011, 510);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.grb_log_oper);
            this.Controls.Add(this.grb_choice_operate);
            this.Controls.Add(this.grb_input);
            this.Controls.Add(this.grb_choice_angle);
            this.Controls.Add(this.lnl_quit);
            this.Controls.Add(this.lnl_log);
            this.Controls.Add(this.lnl_about_program);
            this.Name = "MainForm";
            this.Text = "Домашние задание 03/11/2021";
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownOperand1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownOperator2)).EndInit();
            this.grb_choice_angle.ResumeLayout(false);
            this.grb_choice_angle.PerformLayout();
            this.grb_input.ResumeLayout(false);
            this.grb_input.PerformLayout();
            this.grb_choice_operate.ResumeLayout(false);
            this.grb_choice_operate.PerformLayout();
            this.grb_log_oper.ResumeLayout(false);
            this.grb_log_oper.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.LinkLabel lnl_about_program;
        private System.Windows.Forms.NumericUpDown numericUpDownOperand1;
        private System.Windows.Forms.NumericUpDown numericUpDownOperator2;
        private System.Windows.Forms.LinkLabel lnl_log;
        private System.Windows.Forms.LinkLabel lnl_quit;
        private System.Windows.Forms.LinkLabel lbl_sum;
        private System.Windows.Forms.LinkLabel lbl_subtraction;
        private System.Windows.Forms.LinkLabel lbl_mult;
        private System.Windows.Forms.LinkLabel lnl_division;
        private System.Windows.Forms.LinkLabel lnl_search_sin;
        private System.Windows.Forms.LinkLabel lnl_sqrt;
        private System.Windows.Forms.LinkLabel lnl_pow;
        private System.Windows.Forms.GroupBox grb_choice_angle;
        private System.Windows.Forms.RadioButton rbt_radians;
        private System.Windows.Forms.RadioButton rbt_gradius;
        private System.Windows.Forms.Label lbl_operand1;
        private System.Windows.Forms.Label lbl_operand2;
        private System.Windows.Forms.GroupBox grb_input;
        private System.Windows.Forms.GroupBox grb_choice_operate;
        private System.Windows.Forms.TextBox txb_current_oper;
        private System.Windows.Forms.GroupBox grb_log_oper;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox txb_result;
    }
}

