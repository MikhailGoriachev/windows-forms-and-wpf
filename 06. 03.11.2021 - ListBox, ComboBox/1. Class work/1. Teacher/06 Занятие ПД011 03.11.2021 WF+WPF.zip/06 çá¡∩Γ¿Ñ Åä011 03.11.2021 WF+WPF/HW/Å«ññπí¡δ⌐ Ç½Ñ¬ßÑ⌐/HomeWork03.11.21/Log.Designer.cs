﻿
namespace HomeWork03._11._21
{
    partial class Log
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txb_log = new System.Windows.Forms.TextBox();
            this.btn_clear_log = new System.Windows.Forms.Button();
            this.btn_read_log = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txb_log
            // 
            this.txb_log.Location = new System.Drawing.Point(0, -2);
            this.txb_log.Multiline = true;
            this.txb_log.Name = "txb_log";
            this.txb_log.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txb_log.Size = new System.Drawing.Size(801, 452);
            this.txb_log.TabIndex = 0;
            // 
            // btn_clear_log
            // 
            this.btn_clear_log.Location = new System.Drawing.Point(463, 455);
            this.btn_clear_log.Name = "btn_clear_log";
            this.btn_clear_log.Size = new System.Drawing.Size(246, 23);
            this.btn_clear_log.TabIndex = 1;
            this.btn_clear_log.Text = "Очистить лог";
            this.btn_clear_log.UseVisualStyleBackColor = true;
            this.btn_clear_log.Click += new System.EventHandler(this.btn_clear_log_Click);
            // 
            // btn_read_log
            // 
            this.btn_read_log.Location = new System.Drawing.Point(89, 455);
            this.btn_read_log.Name = "btn_read_log";
            this.btn_read_log.Size = new System.Drawing.Size(246, 23);
            this.btn_read_log.TabIndex = 2;
            this.btn_read_log.Text = "Прочитать лог";
            this.btn_read_log.UseVisualStyleBackColor = true;
            this.btn_read_log.Click += new System.EventHandler(this.btn_read_log_Click);
            // 
            // Log
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 490);
            this.Controls.Add(this.btn_read_log);
            this.Controls.Add(this.btn_clear_log);
            this.Controls.Add(this.txb_log);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "Log";
            this.Text = "Log";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txb_log;
        private System.Windows.Forms.Button btn_clear_log;
        private System.Windows.Forms.Button btn_read_log;
    }
}