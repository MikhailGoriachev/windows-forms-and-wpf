﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HomeWork03._11._21
{
    public partial class Info : Form
    {
        public Info()
        {
            InitializeComponent();
        }
    }
}
