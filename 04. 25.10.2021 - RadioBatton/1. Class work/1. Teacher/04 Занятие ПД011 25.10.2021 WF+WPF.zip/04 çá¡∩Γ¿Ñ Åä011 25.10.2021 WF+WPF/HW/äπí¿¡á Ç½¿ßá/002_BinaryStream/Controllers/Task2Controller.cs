﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BinaryStream.Helpers;
using BinaryStream.Models;

using System.IO;
using System.Collections;

namespace BinaryStream.Controllers
{
    class Task2Controller {
        // имя файла
        private string _fileName;
        public string FileName { get => _fileName; }

        // контейнер данных
        private List<Request> _requests;

        public int Count => _requests.Count;
        public List<Request> Requests => _requests;

        public Task2Controller() : this(new List<Request>(), "task2.bin") {
            Initialize();
        } // Task2Controller

        public Task2Controller(List<Request> requests, string fileName) {
            _requests = requests;
            _fileName = fileName;
        } // Task2Controller

        // Заполнение массива электроприборов
        public void Initialize(int n = 10) {
            _requests.Clear();

            for (int i = 0; i < n; i++)
                _requests.Add(Request.Generate(i + 1));

        } // Initialize

        // запись в бинарный файл
        public void Write() => Write(_requests, _fileName);

        public static void Write(List<Request> requests, string fileName){
            using (var bwr = new BinaryWriter(File.Create(@"..\..\" + fileName))){
                foreach (var item in requests)
                    item.Write(bwr);
            } // using
        } // Write


        // чтение из бинарного файла
        public void Read() {
            using (var brd = new BinaryReader(File.OpenRead(@"..\..\" + _fileName))) {

                // количество записей в файле
                FileInfo fi = new FileInfo(@"..\..\" + _fileName);
                int n = (int)fi.Length / Request.LenRecord;

                _requests.Clear();
                // чтение из файла 
                for (int i = 0; i < n; i++) {
                    Request request = new Request();
                    request.Read(brd);
                    _requests.Add(request);
                } // for i

            } // using
        } // Read

        public void AddRequest(Request request) {
            _requests.Add(request);
            Write();
        } // AddRequest

        public void RemoveRequest(int num) {
            int index = _requests.FindIndex(x => x.Number == num);
            if (index < 0) throw new Exception("Заявка для удаления не найдена!");
            _requests.RemoveAt(index);
            Write();
        } // AddRequest

        public void RemoveAllRequests() {
            _requests.Clear();
            Write();
        } // RemoveAllRequests


        // Именованный итератор, возвращает только записи с заданным номером рейса и дате вылета 
        public IEnumerable GetByFlightNumAndDate(string flightNum, DateTime date) {
            foreach (var item in _requests)
                if (item.FlightNum == flightNum && item.DepartureDate == date)
                    yield return item;
        } // GetByZodiacSign


        public string Show(string caption, int indent) =>
            Show(caption, indent, _requests);

        // Вывести данные массива  в консоль - для вывода 
        public static string Show(string caption, int indent, List<Request> requests) {
            // вывод заголовка таблицы данных 
            string space = " ".PadRight(indent);
            StringBuilder sb = new StringBuilder($"\n\n{space}{caption}\n{Request.Header(indent)}");

            // вывод всех элементов массива объектов данных
            foreach(var el in requests)
                sb.Append($"{space}{el.ToTableRow()}\n");

            // вывод подвала таблицы
            return sb.Append($"{space}{Request.Footer}\n").ToString();
        } // Show


        
    } // Task2Controller
}
