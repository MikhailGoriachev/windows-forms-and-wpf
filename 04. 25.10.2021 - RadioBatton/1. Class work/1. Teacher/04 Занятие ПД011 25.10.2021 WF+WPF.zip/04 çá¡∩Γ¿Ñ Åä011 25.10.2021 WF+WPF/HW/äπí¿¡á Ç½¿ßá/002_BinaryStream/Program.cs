﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualBasic;   // для доступа к возможностям класса Interaction
using BinaryStream.Helpers;
using BinaryStream.Application;

namespace BinaryStream
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Задание на 25.10.2021";

            // простейшее меню приложения
            MenuItem[] menu = new[] {
                new MenuItem { HotKey = ConsoleKey.Q, Text = "Задача 1. Найти первый локальный минимум" },
                new MenuItem { HotKey = ConsoleKey.W, Text = "Задача 1. Поменять местами минимальный и максимальный элементы" },
                new MenuItem { HotKey = ConsoleKey.E, Text = "Задача 1. Продублировать числа, принадлежащие диапазону значений 5–10" },
                //--------------------------------------------------------------------------------------------------------------------------
                new MenuItem { HotKey = ConsoleKey.A, Text = "Задача 2. Формирование бинарного файла с коллекцией заявок" },
                new MenuItem { HotKey = ConsoleKey.S, Text = "Задача 2. Чтение из бинарного файла в список заявок" },
                new MenuItem { HotKey = ConsoleKey.D, Text = "Задача 2. Вывод всех заявок из коллекции в консоль" },
                new MenuItem { HotKey = ConsoleKey.F, Text = "Задача 2. Выборка заявок по заданному номеру рейса и дате вылета" },
                new MenuItem { HotKey = ConsoleKey.G, Text = "Задача 2. Добавление заявки в список" },
                new MenuItem { HotKey = ConsoleKey.H, Text = "Задача 2. Удаление заявки из списка" },
                new MenuItem { HotKey = ConsoleKey.J, Text = "Задача 2. Удаление всех заявок из списка" },
                new MenuItem { HotKey = ConsoleKey.K, Text = "Задача 2. Упорядочить заявки по номеру рейса" },
                new MenuItem { HotKey = ConsoleKey.L, Text = "Задача 2. Упорядочить заявки по желаемой дате рейса" },
                //--------------------------------------------------------------------------------------------------------------------------
                new MenuItem { HotKey = ConsoleKey.Z, Text = "Выход" },
            };
            // Создание экземпляра класса приложения
            App app = new App();

            // главный цикл приложения
            while (true) {
                try {

                    // настройка цветового оформления
                    Console.ForegroundColor = ConsoleColor.Gray;
                    Console.BackgroundColor = ConsoleColor.DarkGray;
                    Utils.SaveColor();
                    Console.Clear();
                    Console.CursorVisible = false;

                    Utils.ShowNavBarTask("  Задание на 25.10.2021");
                    Utils.ShowMenu(12, 5, "Главное меню приложения", menu);

                    // получить код нажатой клавиши, не отображать символ клавиши
                    ConsoleKey key = Console.ReadKey(true).Key;
                    Console.Clear();

                    switch (key) {
                        // Найти первый локальный минимум
                        case ConsoleKey.Q:
                            app.GetFirstLocalMin();
                            break;

                        // Поменять местами минимальный и максимальный элементы
                        case ConsoleKey.W:
                            app.SwapMinMaxElems();
                            break;

                        // Продублировать числа, принадлежащие диапазону значений 5–10
                        case ConsoleKey.E:
                            app.DuplicateElemsInRange();
                            break;

                        // ------------------------------------------------------------

                        // Формирование бинарного файла с коллекцией заявок
                        case ConsoleKey.A:
                            app.RequestsInitialize();
                            break;

                        // Чтение из бинарного файла в список заявок
                        case ConsoleKey.S:
                            app.RequestsReadFromFile();
                            break;

                        // Вывод всех заявок из коллекции в консоль
                        case ConsoleKey.D:
                            app.ShowRequests();
                            break;

                        // Выборка заявок по заданному номеру рейса и дате вылета
                        case ConsoleKey.F:
                            app.SelectByFlightNumAndDate();
                            break;

                        // Добавление заявки в список
                        case ConsoleKey.G:
                            app.AddRequest();
                            break;

                        // Удаление заявки из списка
                        case ConsoleKey.H:
                            app.RemoveRequest();
                            break;

                        // Удаление всех заявок из списка
                        case ConsoleKey.J:
                            app.RemoveAllRequests();
                            break;

                        // Упорядочить заявки по номеру рейса
                        case ConsoleKey.K:
                            app.DemoOrderByFlightNum();
                            break;

                        // Упорядочить заявки по желаемой дате рейса
                        case ConsoleKey.L:
                            app.DemoOrderByDate();
                            break;

                        // выход из приложения назначен на клавишу F10 или кавишу Z
                        case ConsoleKey.F10:
                        case ConsoleKey.Z:
                            Console.ResetColor();   // сброс цветового сочетания к исходному
                            Console.Clear();
                            Utils.WriteXY(0, Console.WindowHeight - 1, "", ConsoleColor.Gray);
                            Console.CursorVisible = true;
                            return;

                        default:
                            throw new Exception("Такого пункта нет в меню!");
                    } // switch

                }
                catch (Exception ex) {
                    Console.Clear();
                    ConsoleColor oldColor = Console.BackgroundColor;
                    Console.BackgroundColor = ConsoleColor.Red;
                    Utils.WriteXY(20, 9, "                                                                                        \n", ConsoleColor.White);
                    Utils.WriteXY(20, 10, "  ************************************************************************************  \n", ConsoleColor.White);
                    Utils.WriteXY(20, 11, "  *                                   Исключение.                                    *  \n", ConsoleColor.White);
                    Utils.WriteXY(20, 12, $"  * {ex.Message, -79}  *  \n", ConsoleColor.White);
                    Utils.WriteXY(20, 13, "  *                                                                                  *  \n", ConsoleColor.White);
                    Utils.WriteXY(20, 14, "  ************************************************************************************  \n", ConsoleColor.White);
                    Utils.WriteXY(20, 15, "                                                                                        \n", ConsoleColor.White);
                    Console.BackgroundColor = oldColor;
                }
                finally { 
                    // Ожидать нажатия любой клавиши по окончании работы пункта меню
                    Console.CursorVisible = true;
                    Utils.WriteXY(0, Console.WindowHeight - 1, "Нажмите любую клавишу...", ConsoleColor.Gray);
                    Console.ReadKey(true);
                }
            } // while
        } // Main
    }
}
