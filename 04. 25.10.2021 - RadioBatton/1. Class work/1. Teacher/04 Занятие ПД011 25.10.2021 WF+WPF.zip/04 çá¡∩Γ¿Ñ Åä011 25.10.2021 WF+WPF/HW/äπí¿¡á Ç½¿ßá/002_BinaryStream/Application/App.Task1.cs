﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BinaryStream.Controllers;
using BinaryStream.Helpers;

using System.IO;

namespace BinaryStream.Application
{
    /* 
    * Методы для решения задачи 1
    */
    internal partial class App {


        private void WriteToFile(){
            using (BinaryWriter bw = new BinaryWriter(File.Create(@"..\..\" + _task1.FileName))) {
                int n = Utils.GetRand(15, 25);

                for (int i = 0; i < n; i++) 
                    bw.Write(Utils.GetRand(-10d, 10d)); // запись в файл

            } // using
        } // WriteToFile

        // Найти первый локальный минимум
        public void GetFirstLocalMin() {
            Utils.ShowNavBarTask("    Найти первый локальный минимум");
            if (!File.Exists(@"..\..\" + _task1.FileName)) WriteToFile();

            int localMin =_task1.GetIndexLocalMin();

            _task1.Show("Первый локальный минимум выделен цветом:", 12, 
                (item, index) => {
                    if (index == localMin)
                        Utils.SetColor(ConsoleColor.Yellow, Console.BackgroundColor);

                    Console.Write($"{item,8:f2}");

                    Utils.RestoreColor();
                });
        } // GetFirstLocalMin

        // Поменять местами минимальный и максимальный элементы
        public void SwapMinMaxElems() {
            Utils.ShowNavBarTask("    Поменять местами минимальный и максимальный элементы");
            if (!File.Exists(@"..\..\" + _task1.FileName)) WriteToFile();

            (int min, int max) = (_task1.Min(), _task1.Max());

            _task1.Show("Файл до обработки:", 12,
                (item, index) => {
                    Utils.SetColor(index == min 
                        ?ConsoleColor.DarkRed
                        :index == max 
                            ?ConsoleColor.Green
                            :Console.ForegroundColor, Console.BackgroundColor);

                    Console.Write($"{item,8:f2}");

                    Utils.RestoreColor();
                });

            _task1.SwapMinMaxElems();


            _task1.Show("Файл после обработки:", 12,
                (item, index) => {
                    Utils.SetColor(index == min ?
                               ConsoleColor.Green
                               :
                               index == max
                               ?
                               ConsoleColor.DarkRed
                               :
                               Console.ForegroundColor, Console.BackgroundColor);

                    Console.Write($"{item,8:f2}");

                    Utils.RestoreColor();
                });
        } // SwapMinMaxElems

        // Продублировать числа, принадлежащие диапазону значений 5–10
        public void DuplicateElemsInRange() {
            Utils.ShowNavBarTask("    Продублировать числа, принадлежащие диапазону значений 5–10");
            (double lo, double hi) = (5d, 10d);

            Action<double, int> OutItemInRange = (item, index) => {
                Utils.SetColor(item > lo && item < hi ?
                              ConsoleColor.Yellow
                              :
                              Console.ForegroundColor, Console.BackgroundColor);

                Console.Write($"{item,8:f2}");

                Utils.RestoreColor();
            };

            _task1.Show("Файл до обработки:", 12, OutItemInRange);

            _task1.DuplicateElemsInRange();

            _task1.Show("Файл после обработки:", 12, OutItemInRange);
        } // DuplicateElemsInRange
    } // App
}
