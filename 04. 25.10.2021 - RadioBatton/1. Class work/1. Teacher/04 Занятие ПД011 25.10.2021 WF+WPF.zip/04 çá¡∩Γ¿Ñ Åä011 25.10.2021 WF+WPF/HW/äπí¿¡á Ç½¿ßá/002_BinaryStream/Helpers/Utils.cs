﻿using System;
using System.Text;

namespace BinaryStream.Helpers
{
    // вспомогательные методы и объекты - статический класс, т.е. класс,
    // содержащий только статические члены и методы
    public static class Utils
    {
        // объект для получения случайных чисел
        public static Random Random = new Random();
        
        // формирование случайных вещественных чисел в диапазоне от lo до hi
        public static double GetRandom(double lo, double hi)
            => lo + (hi - lo)*Random.NextDouble();
        public static int GetRand(int lo, int hi) => Random.Next(lo, hi + 1);
        public static double GetRand(double lo, double hi) => lo + (hi - lo) * Random.NextDouble();
        public static char GetRand(char min = (char)0, char max = (char)255) =>
            (char)Random.Next(min, max + 1);

        // формирует и выводит верхнюю строку для задач
        public static void ShowNavBarTask(string line) {
            // сохранить цвет фона
            ConsoleColor oldBgColor = Console.BackgroundColor;
            ConsoleColor oldFgColor = Console.ForegroundColor;

            // при выводе немного используем методы класса strring :)
            // PadRight() дополняет строку справа пробелами до заданной длины
            Console.BackgroundColor = ConsoleColor.Gray;
            WriteXY(0, 0, line.PadRight(Console.WindowWidth), ConsoleColor.Black);

            // восстановить цвет фона
            Console.BackgroundColor = oldBgColor;
            Console.ForegroundColor = oldFgColor;
        } // ShowNavBarTask
        
        
        // Вспомогательный метод для вывода в заданных координатах окна консоли текста
        // заданным цветом
        public static void WriteXY(int x, int y, string s, ConsoleColor color) {
            // сохранить текущий цвет консоли и установить заданный
            ConsoleColor oldColor = Console.ForegroundColor;
            Console.ForegroundColor = color;

            Console.SetCursorPosition(x, y);
            Console.Write(s);

            // восстановить цвет консоли
            Console.ForegroundColor = oldColor;
        } // WriteXY

        // Вывод меню приложения
        public static void ShowMenu(int x, int y, string title, MenuItem[] menu) {
            WriteXY(x, y, title, ConsoleColor.Gray);
            int offsetY = 2;

            foreach (var menuItem in menu) {
                WriteXY(x, y + offsetY, menuItem.HotKey.ToString(), ConsoleColor.Cyan);
                WriteXY(x + 2, y + offsetY++, menuItem.Text, ConsoleColor.Gray);
            } // foreach menuItem
        } // ShowMenu

        // Установить текущий цвет символов и фона с сохранением
        // текущего цвета символов и фона
        private static (ConsoleColor Fore, ConsoleColor Back) _storeColor;
        public static void SetColor(ConsoleColor fore, ConsoleColor back)
        {
            _storeColor = (Console.ForegroundColor, Console.BackgroundColor);
            Console.ForegroundColor = fore;
            Console.BackgroundColor = back;
        } // SetColor

        // Сохранить цвет
        public static void SaveColor() =>
            _storeColor = (Console.ForegroundColor, Console.BackgroundColor);

        // Восстановить сохраненный цвет
        public static void RestoreColor() =>
            (Console.ForegroundColor, Console.BackgroundColor) = _storeColor;

        // Подготовка строки к записи в файл - копировать символы
        // строки str в буферный массив байт для вывода
        public static byte[] ToArray(string str, int length) {
            byte[] buf = new byte[length];
            Encoding.Default
                .GetBytes(str)
                .CopyTo(buf, 0);

            return buf;
        } // ToArray

    } // class Utils
}