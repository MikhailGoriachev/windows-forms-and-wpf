﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BinaryStream.Helpers;

using System.IO;

namespace BinaryStream.Controllers
{
    class Task1Controller {
        // имя файла
        private string _fileName;

        public string FileName { get => _fileName; }

        public delegate bool ForShow(int a);
        public Task1Controller() : this("task1.bin") {} // Task1Controller

        Task1Controller(string fileName) {
            _fileName = fileName;
        } // Task1Controller

        private List<double> ReadToList(){
            List<double> temp = new List<double>();

            using (BinaryReader br = new BinaryReader(File.OpenRead(@"..\..\" + _fileName))) {
                // определить длину файла в записях
                FileInfo fi = new FileInfo(@"..\..\" + _fileName);
                int n = (int)fi.Length / sizeof(double);

                // работаем с файлом - чтение записей из файла
                for (int i = 0; i < n; i++)  
                    temp.Add(br.ReadDouble());

            } // using

            return temp;
        } // ReadToList

        private void WriteListToFile(List<double> list){
            using (BinaryWriter bw = new BinaryWriter(File.Create(@"..\..\" + _fileName))) {
                for (int i = 0; i < list.Count; i++)
                    bw.Write(list[i]); // запись в файл

            } // using
        } // WriteListToFile

        // поиск индекса первого локального минимума
        public int GetIndexLocalMin() {
            List<double> temp = ReadToList();

            for (int i = 1; i < temp.Count - 1; i++)
                if (temp[i] < temp[i - 1] && temp[i] < temp[i + 1])
                    return i;

            return -1;
        } // GetIndexLocalMin

        // поиск индекса минимального элемента
        public int Min() {
            List<double> temp = ReadToList();
            int min = 0;

            for (int i = 1; i < temp.Count; i++)
                if (temp[i] < temp[min])
                    min = i;

            return min;
        } // Min

        // поиск индекса максимального элемента
        public int Max() {
            List<double> temp = ReadToList();
            int max = 0;

            for (int i = 1; i < temp.Count; i++)
                if (temp[i] > temp[max])
                    max = i;

            return max;
        } // Max

        public void SwapMinMaxElems() {
            List<double> temp = ReadToList();
            (int min, int max) = (Min(), Max());

            (temp[min], temp[max]) = (temp[max], temp[min]);

            WriteListToFile(temp);
        } // SwapMinMaxElems

        public void DuplicateElemsInRange(double lo = 5d, double hi = 10d) {
            List<double> temp = ReadToList();

            int n = temp.Count;
            for (int i = 0, k = 0; k < n; k++, i++) {
                double t = temp[i];
                if (lo < t && t < hi)
                    temp.Insert(i++, t);
            } // for i

            WriteListToFile(temp);
        } // DuplicateElemsInRange

        // вывод в консоль
        public void Show(string title, int indent) =>
            Show(title, indent, (item, index) => Console.Write($"{item,8:f2}"));

        public void Show(string title, int indent, Action<double, int> outItem) {
            string space = " ".PadRight(indent);

            List<double> temp = ReadToList();
            Console.Write($"\n\n{space}{title}\n{space}");

            for (int i = 0; i < temp.Count; i++)
            {
                outItem.Invoke(temp[i], i);
                if ((i + 1) % 8 == 0) Console.Write($"\n{space}");
            } // for i

        } // Show

    } // Task1Controller
}
