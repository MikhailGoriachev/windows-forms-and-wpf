﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BinaryStream.Helpers;
using BinaryStream.Models;
using BinaryStream.Controllers;

namespace BinaryStream.Application
{
    /* 
    * Методы для решения задачи 2
    */
    internal partial class App {
        // Формирование бинарного файла с коллекцией заявок
        public void RequestsInitialize() {
            Utils.ShowNavBarTask("   Формирование бинарного файла с коллекцией заявок");
            _task2.Initialize();
            Console.WriteLine(_task2.Show("Данные сформированы:", 12));

            _task2.Write();
            Console.WriteLine($"\n{" ".PadLeft(12)}Данные записаны в файл \"{_task2.FileName}\"!");
        } // RequestsInitialize


        // Чтение из бинарного файла в список заявок
        public void RequestsReadFromFile() {
            Utils.ShowNavBarTask("   Чтение из бинарного файла в список заявок");

            _task2.Read();
            Console.WriteLine(_task2.Show($"Данные прочитаны из файла \"{_task2.FileName}\":", 12));
        } // RequestsReadFromFile


        // Вывод всех заявок из коллекции в консоль
        public void ShowRequests() {
            Utils.ShowNavBarTask("   Вывод всех заявок из коллекции в консоль");
            Console.WriteLine(_task2.Show("Коллекция заявок:", 12));
        } // ShowRequests


        // Выборка заявок по заданному номеру рейса и дате вылета
        public void SelectByFlightNumAndDate() {
            Utils.ShowNavBarTask("   Выборка заявок по заданному номеру рейса и дате вылета");
            int index = Utils.GetRand(0, _task2.Count - 1);
            string flightNum = _task2.Requests[index].FlightNum;
            DateTime date = _task2.Requests[index].DepartureDate;

            Console.WriteLine($"\n\t    Заданный номер рейса: {flightNum}\n\t    Заданная дата вылета: {date:dd/MM/yyyy}");

            List<Request> selected = new List<Request>();

            foreach (Request item in _task2.GetByFlightNumAndDate(flightNum, date))
                selected.Add(item);

            Console.WriteLine(Task2Controller.Show("Найденные заявки:", 12, selected));

        } // SelectByFlightNumAndDate


        // Добавление заявки в список
        public void AddRequest() {
            Utils.ShowNavBarTask("   Добавление заявки в список");
            Console.WriteLine(_task2.Show("Коллекция до добавления заявки:", 12));
            _task2.AddRequest(Request.Generate(_task2.Count + 1));
            Console.WriteLine(_task2.Show("Коллекция после добавления заявки:", 12));
        } // RemoveAllRequests


        // Удаление заявки из списка
        public void RemoveRequest() {
            Utils.ShowNavBarTask("   Удаление заявки из списка");

            Console.WriteLine(_task2.Show("Данные для удаления.", 12));
            Console.Write("\n\n\t    Введите номер заявки для удаления: ");
            string str = Console.ReadLine();

            if (!int.TryParse(str, out int num)) throw new Exception("Некорректный ввод!");

            _task2.RemoveRequest(num);

            Console.Clear();
            Utils.ShowNavBarTask("   Удаление заявки из списка");
            Console.WriteLine(_task2.Show("Коллекция после удаления заявки:", 12));

        } // RemoveRequest


        // Удаление всех заявок из списка
        public void RemoveAllRequests() {
            Utils.ShowNavBarTask("   Удаление всех заявок из списка");

            _task2.RemoveAllRequests();
            Console.WriteLine($"\n\n{" ".PadLeft(12)}Данные успешно удалены!");
        } // RemoveAllRequests


        // Упорядочить заявки по номеру рейса
        public void DemoOrderByFlightNum() {
            Utils.ShowNavBarTask("   Упорядочить заявки по номеру рейса");

            List<Request> temp = _task2.Requests;
            temp.Sort((x, y) => x.FlightNum.CompareTo(y.FlightNum));
            Task2Controller.Write(temp, _task2.FileName);

            Console.WriteLine(Task2Controller.Show("Коллекция упорядочена по номеру рейса:", 12, temp));

        } // DemoOrderByFlightNum


        // Упорядочить заявки по желаемой дате рейса
        public void DemoOrderByDate()  {
            Utils.ShowNavBarTask("   Упорядочить заявки по желаемой дате рейса");

            List<Request> temp = _task2.Requests;
            temp.Sort((x, y) => x.DepartureDate.CompareTo(y.DepartureDate));
            Task2Controller.Write(temp, _task2.FileName);

            Console.WriteLine(Task2Controller.Show("Коллекция упорядочена по желаемой дате рейса:", 12, temp));
        } // DemoOrderBy
    } // App
}
