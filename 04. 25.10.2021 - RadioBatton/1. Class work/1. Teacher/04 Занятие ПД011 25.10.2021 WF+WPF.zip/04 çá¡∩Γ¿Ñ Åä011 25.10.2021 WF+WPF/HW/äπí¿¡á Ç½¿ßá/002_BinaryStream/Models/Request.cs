﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BinaryStream.Helpers;

using System.IO;

namespace BinaryStream.Models
{
    // Заявка на авиабилет содержит:
    //                  номер заявки,
    //                  пункт назначения,
    //                  номер рейса,
    //                  фамилию и инициалы пассажира,
    //                  желаемую дату вылета
    class Request {
        // строковые поля одинаковой длины
        private const int LenField = 80;

        public static int LenRecord => 4 * sizeof(int) + 3 * LenField;


        // номер заявки
        private int _number;
        public int Number {
            get  => _number; 
            set { if (value < 0) throw new Exception("Request. Некорректное значение номера заявки!"); _number = value; }
        } // Number

        
        // название пункта назначения
        private string _destination;
        public string Destination {
            get => _destination;
            set { if (string.IsNullOrWhiteSpace(value)) throw new Exception("Request. Некорректное значение пункта назначения!"); _destination = value; }
        } // Destination
        
        
        // номер рейса
        private string _flightNum;
        public string FlightNum {
            get => _flightNum;
            set { if (string.IsNullOrWhiteSpace(value)) throw new Exception("Request. Некорректное значение номера рейса!"); _flightNum = value; }
        } // FlightNum
        

        // фамилию и инициалы пассажира
        private string _passenger;
        public string Passenger {
            get => _passenger;
            set { if (string.IsNullOrWhiteSpace(value)) throw new Exception("Request. Некорректное значение фамилии и инициалов пассажира!"); _passenger = value; }
        } // Passenger


        // желаемая дата вылета
        private DateTime _departureDate;
        public DateTime DepartureDate {
            get => _departureDate;
            set { if (value < DateTime.Now) throw new Exception("Request. Некорректное значение желаемой даты вылета!"); _departureDate = value; }
        } // DepartureDate


        // запись в бинарный файл
        public void Write(BinaryWriter bwr) {
            bwr.Write(_number);
            bwr.Write(Utils.ToArray(_destination, LenField));
            bwr.Write(Utils.ToArray(_flightNum, LenField));
            bwr.Write(Utils.ToArray(_passenger, LenField));
            bwr.Write(_departureDate.Year);
            bwr.Write(_departureDate.Month);
            bwr.Write(_departureDate.Day);
        } // Write


        // чтение из бинарного файла
        public void Read(BinaryReader brd) {
            _number = brd.ReadInt32();

            _destination = Encoding.Default
                .GetString(brd.ReadBytes(LenField))
                .Replace("\0", "")
                .TrimEnd();

            _flightNum = Encoding.Default
                .GetString(brd.ReadBytes(LenField))
                .Replace("\0", "")
                .TrimEnd();

            _passenger = Encoding.Default
                .GetString(brd.ReadBytes(LenField))
                .Replace("\0", "")
                .TrimEnd();

            int year = brd.ReadInt32();
            int month = brd.ReadInt32();
            int day = brd.ReadInt32();

            _departureDate = new DateTime(year, month, day);
        } // Read


        // вывод данных о заявке на авиабилет в формате строки таблицы
        public string ToTableRow() =>
            $"│ {_number, 3} │ {_destination,-16} │ {_flightNum, 11} │ {_passenger,-22} │ {_departureDate, 15:dd/MM/yyyy}      │";


        // статическое свойство для вывода шапки таблицы
        public static string Header(int indent) {
            string spaces = " ".PadRight(indent);
            string str =
                $"{spaces}┌─────┬──────────────────┬─────────────┬────────────────────────┬──────────────────────┐\n" +
                $"{spaces}│  №  │ Пункт назначения │ Номер рейса │ Фамилия И.О. пассажира │ Желаемая дата вылета │\n" +
                $"{spaces}├─────┼──────────────────┼─────────────┼────────────────────────┼──────────────────────┤\n";
            return str;
        } // Header


        public static string Footer =>
            "└─────┴──────────────────┴─────────────┴────────────────────────┴──────────────────────┘";


        // Фабричный метод для создания пользователя из случайных данных
        public static Request Generate(int num) {
            // массив фамилий 
            string[] surnames = new[] { "Семенов ",  "Дунаев ",  "Харламова ", "Олегова ", "Янковский ", "Абалкин ",
                                     "Романова ", "Воликов ", "Жукова ",    "Соколов ", "Лебедев " };

            // массив инициалов 
            string[] initials = new[] { "A.", "Б.", "В.", "Г.", "Д.", "Е.", "Ж.", "З.", "И.", "К.", "Л.", "М.", "Н.", "О.", "П.", "Р.", "С.", "Т.",
                                        "У.", "Ф.", "Х.", "Ц.", "Ч.", "Ш.", "Э.", "Ю.", "Я."};
            // массив пунктов назначения
            string[] destinations = new[] { "Тель-Авив",  "Нью-Йорк",  "Гамбург",  "Франкфурт", "Лиссабон", "Сидней",
                                            "Будапешт",   "Бангкок",   "Барселона", "Кейптаун" };

            var flights = new (string destination, string flightNum, DateTime date)[] {
                ("Тель-Авив", "TDF130", new DateTime(2022, 1, 1)),
                ("Нью-Йорк",  "NYF125", new DateTime(2022, 8, 10)),
                ("Гамбург",   "KTH758", new DateTime(2021, 12, 27)),
                ("Франкфурт", "HYF351", new DateTime(2021, 12, 14)),
                ("Лиссабон",  "JTF354", new DateTime(2022, 8, 9)),
                ("Сидней",    "KVR780", new DateTime(2021, 12, 27)),
                ("Будапешт",  "PDR957", new DateTime(2021, 12, 27)),
                ("Бангкок",   "GYL347", new DateTime(2022, 2, 7)),
                ("Барселона", "FSH589", new DateTime(2021, 11, 3)),
                ("Кейптаун",  "MVT175", new DateTime(2022, 11, 4)),
            };

            int index = Utils.Random.Next(flights.Length);
            return new Request {
                Number = num,
                Destination = flights[index].destination,
                FlightNum = flights[index].flightNum,
                Passenger = surnames[Utils.Random.Next(surnames.Length)]+ initials[Utils.Random.Next(initials.Length)] + initials[Utils.Random.Next(initials.Length)],
                DepartureDate = flights[index].date
            };
        } // Generate
    } // Request
}
