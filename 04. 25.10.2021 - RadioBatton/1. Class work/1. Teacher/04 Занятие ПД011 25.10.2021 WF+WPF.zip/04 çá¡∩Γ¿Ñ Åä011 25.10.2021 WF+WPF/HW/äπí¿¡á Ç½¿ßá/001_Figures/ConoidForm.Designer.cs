﻿
namespace _001_Figures
{
    partial class ConoidForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.PcbConoid = new System.Windows.Forms.PictureBox();
            this.grbData = new System.Windows.Forms.GroupBox();
            this.TbxDensity = new System.Windows.Forms.TextBox();
            this.TbxRadius2 = new System.Windows.Forms.TextBox();
            this.TbxRadius1 = new System.Windows.Forms.TextBox();
            this.LblDensity = new System.Windows.Forms.Label();
            this.LblRadius2 = new System.Windows.Forms.Label();
            this.LblRadius1 = new System.Windows.Forms.Label();
            this.chbVolume = new System.Windows.Forms.CheckBox();
            this.chbArea = new System.Windows.Forms.CheckBox();
            this.chbMassa = new System.Windows.Forms.CheckBox();
            this.grbResult = new System.Windows.Forms.GroupBox();
            this.lblVolume = new System.Windows.Forms.Label();
            this.btnCalculate = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.LblArea = new System.Windows.Forms.Label();
            this.LblMassa = new System.Windows.Forms.Label();
            this.TbxHeight = new System.Windows.Forms.TextBox();
            this.LblHeight = new System.Windows.Forms.Label();
            this.ErpRadius1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.ErpRadius2 = new System.Windows.Forms.ErrorProvider(this.components);
            this.ErpHeight = new System.Windows.Forms.ErrorProvider(this.components);
            this.ErpDensity = new System.Windows.Forms.ErrorProvider(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.PcbConoid)).BeginInit();
            this.grbData.SuspendLayout();
            this.grbResult.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ErpRadius1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ErpRadius2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ErpHeight)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ErpDensity)).BeginInit();
            this.SuspendLayout();
            // 
            // PcbConoid
            // 
            this.PcbConoid.Image = global::_001_Figures.Properties.Resources.Picture_Conoid;
            this.PcbConoid.Location = new System.Drawing.Point(354, 9);
            this.PcbConoid.Name = "PcbConoid";
            this.PcbConoid.Size = new System.Drawing.Size(309, 268);
            this.PcbConoid.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.PcbConoid.TabIndex = 0;
            this.PcbConoid.TabStop = false;
            // 
            // grbData
            // 
            this.grbData.Controls.Add(this.TbxHeight);
            this.grbData.Controls.Add(this.LblHeight);
            this.grbData.Controls.Add(this.TbxDensity);
            this.grbData.Controls.Add(this.TbxRadius2);
            this.grbData.Controls.Add(this.TbxRadius1);
            this.grbData.Controls.Add(this.LblDensity);
            this.grbData.Controls.Add(this.LblRadius2);
            this.grbData.Controls.Add(this.LblRadius1);
            this.grbData.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.grbData.Location = new System.Drawing.Point(26, 12);
            this.grbData.Name = "grbData";
            this.grbData.Size = new System.Drawing.Size(346, 173);
            this.grbData.TabIndex = 1;
            this.grbData.TabStop = false;
            this.grbData.Text = " Исходные данные: ";
            // 
            // TbxDensity
            // 
            this.TbxDensity.Location = new System.Drawing.Point(147, 138);
            this.TbxDensity.Name = "TbxDensity";
            this.TbxDensity.Size = new System.Drawing.Size(175, 23);
            this.TbxDensity.TabIndex = 5;
            this.TbxDensity.Text = "1 200,00";
            this.TbxDensity.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.TbxDensity.TextChanged += new System.EventHandler(this.TbxDensity_TextChanged);
            // 
            // TbxRadius2
            // 
            this.TbxRadius2.Location = new System.Drawing.Point(180, 70);
            this.TbxRadius2.Name = "TbxRadius2";
            this.TbxRadius2.Size = new System.Drawing.Size(142, 23);
            this.TbxRadius2.TabIndex = 4;
            this.TbxRadius2.Text = "1,50";
            this.TbxRadius2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.TbxRadius2.TextChanged += new System.EventHandler(this.TbxRadius2_TextChanged);
            // 
            // TbxRadius1
            // 
            this.TbxRadius1.Location = new System.Drawing.Point(180, 38);
            this.TbxRadius1.Name = "TbxRadius1";
            this.TbxRadius1.Size = new System.Drawing.Size(142, 23);
            this.TbxRadius1.TabIndex = 3;
            this.TbxRadius1.Text = "1,00";
            this.TbxRadius1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.TbxRadius1.TextChanged += new System.EventHandler(this.TbxRadius1_TextChanged);
            // 
            // LblDensity
            // 
            this.LblDensity.AutoSize = true;
            this.LblDensity.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblDensity.Location = new System.Drawing.Point(8, 141);
            this.LblDensity.Name = "LblDensity";
            this.LblDensity.Size = new System.Drawing.Size(141, 16);
            this.LblDensity.TabIndex = 2;
            this.LblDensity.Text = "Плотность материала:";
            // 
            // LblRadius2
            // 
            this.LblRadius2.AutoSize = true;
            this.LblRadius2.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblRadius2.Location = new System.Drawing.Point(8, 73);
            this.LblRadius2.Name = "LblRadius2";
            this.LblRadius2.Size = new System.Drawing.Size(180, 16);
            this.LblRadius2.TabIndex = 1;
            this.LblRadius2.Text = "Радиус верхнего основания: ";
            // 
            // LblRadius1
            // 
            this.LblRadius1.AutoSize = true;
            this.LblRadius1.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblRadius1.Location = new System.Drawing.Point(8, 41);
            this.LblRadius1.Name = "LblRadius1";
            this.LblRadius1.Size = new System.Drawing.Size(177, 16);
            this.LblRadius1.TabIndex = 0;
            this.LblRadius1.Text = "Радиус нижнего основания: ";
            // 
            // chbVolume
            // 
            this.chbVolume.AutoSize = true;
            this.chbVolume.Checked = true;
            this.chbVolume.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chbVolume.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.chbVolume.Location = new System.Drawing.Point(37, 196);
            this.chbVolume.Name = "chbVolume";
            this.chbVolume.Size = new System.Drawing.Size(168, 20);
            this.chbVolume.TabIndex = 2;
            this.chbVolume.Text = "Рассчитывать объем";
            this.chbVolume.UseVisualStyleBackColor = true;
            // 
            // chbArea
            // 
            this.chbArea.AutoSize = true;
            this.chbArea.Checked = true;
            this.chbArea.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chbArea.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.chbArea.Location = new System.Drawing.Point(37, 222);
            this.chbArea.Name = "chbArea";
            this.chbArea.Size = new System.Drawing.Size(189, 20);
            this.chbArea.TabIndex = 3;
            this.chbArea.Text = "Рассчитывать площадь ";
            this.chbArea.UseVisualStyleBackColor = true;
            // 
            // chbMassa
            // 
            this.chbMassa.AutoSize = true;
            this.chbMassa.Checked = true;
            this.chbMassa.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chbMassa.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.chbMassa.Location = new System.Drawing.Point(37, 248);
            this.chbMassa.Name = "chbMassa";
            this.chbMassa.Size = new System.Drawing.Size(164, 20);
            this.chbMassa.TabIndex = 4;
            this.chbMassa.Text = "Рассчитывать массу";
            this.chbMassa.UseVisualStyleBackColor = true;
            // 
            // grbResult
            // 
            this.grbResult.Controls.Add(this.LblMassa);
            this.grbResult.Controls.Add(this.LblArea);
            this.grbResult.Controls.Add(this.lblVolume);
            this.grbResult.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.grbResult.Location = new System.Drawing.Point(25, 283);
            this.grbResult.Name = "grbResult";
            this.grbResult.Size = new System.Drawing.Size(444, 170);
            this.grbResult.TabIndex = 5;
            this.grbResult.TabStop = false;
            this.grbResult.Text = " Результаты расчета: ";
            // 
            // lblVolume
            // 
            this.lblVolume.AutoSize = true;
            this.lblVolume.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblVolume.Location = new System.Drawing.Point(8, 46);
            this.lblVolume.Name = "lblVolume";
            this.lblVolume.Size = new System.Drawing.Size(168, 16);
            this.lblVolume.TabIndex = 6;
            this.lblVolume.Text = "Объем усеченного конуса: ";
            // 
            // btnCalculate
            // 
            this.btnCalculate.Location = new System.Drawing.Point(484, 329);
            this.btnCalculate.Name = "btnCalculate";
            this.btnCalculate.Size = new System.Drawing.Size(149, 30);
            this.btnCalculate.TabIndex = 6;
            this.btnCalculate.Text = "Рассчитать";
            this.btnCalculate.UseVisualStyleBackColor = true;
            this.btnCalculate.Click += new System.EventHandler(this.btnCalculate_Click);
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btnExit.Location = new System.Drawing.Point(484, 385);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(149, 30);
            this.btnExit.TabIndex = 7;
            this.btnExit.Text = "Выход";
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // LblArea
            // 
            this.LblArea.AutoSize = true;
            this.LblArea.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblArea.Location = new System.Drawing.Point(8, 78);
            this.LblArea.Name = "LblArea";
            this.LblArea.Size = new System.Drawing.Size(184, 16);
            this.LblArea.TabIndex = 7;
            this.LblArea.Text = "Площадь усеченного конуса: ";
            // 
            // LblMassa
            // 
            this.LblMassa.AutoSize = true;
            this.LblMassa.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblMassa.Location = new System.Drawing.Point(8, 110);
            this.LblMassa.Name = "LblMassa";
            this.LblMassa.Size = new System.Drawing.Size(166, 16);
            this.LblMassa.TabIndex = 8;
            this.LblMassa.Text = "Масса усеченного конуса: ";
            // 
            // TbxHeight
            // 
            this.TbxHeight.Location = new System.Drawing.Point(104, 105);
            this.TbxHeight.Name = "TbxHeight";
            this.TbxHeight.Size = new System.Drawing.Size(218, 23);
            this.TbxHeight.TabIndex = 7;
            this.TbxHeight.Text = "2,50";
            this.TbxHeight.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.TbxHeight.TextChanged += new System.EventHandler(this.TbxHeight_TextChanged);
            // 
            // LblHeight
            // 
            this.LblHeight.AutoSize = true;
            this.LblHeight.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblHeight.Location = new System.Drawing.Point(8, 108);
            this.LblHeight.Name = "LblHeight";
            this.LblHeight.Size = new System.Drawing.Size(98, 16);
            this.LblHeight.TabIndex = 6;
            this.LblHeight.Text = "Высота конуса:";
            // 
            // ErpRadius1
            // 
            this.ErpRadius1.ContainerControl = this;
            // 
            // ErpRadius2
            // 
            this.ErpRadius2.ContainerControl = this;
            // 
            // ErpHeight
            // 
            this.ErpHeight.ContainerControl = this;
            // 
            // ErpDensity
            // 
            this.ErpDensity.ContainerControl = this;
            // 
            // ConoidForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(680, 472);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnCalculate);
            this.Controls.Add(this.grbResult);
            this.Controls.Add(this.chbMassa);
            this.Controls.Add(this.chbArea);
            this.Controls.Add(this.chbVolume);
            this.Controls.Add(this.grbData);
            this.Controls.Add(this.PcbConoid);
            this.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.MaximizeBox = false;
            this.Name = "ConoidForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Conoid";
            ((System.ComponentModel.ISupportInitialize)(this.PcbConoid)).EndInit();
            this.grbData.ResumeLayout(false);
            this.grbData.PerformLayout();
            this.grbResult.ResumeLayout(false);
            this.grbResult.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ErpRadius1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ErpRadius2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ErpHeight)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ErpDensity)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox PcbConoid;
        private System.Windows.Forms.GroupBox grbData;
        private System.Windows.Forms.CheckBox chbVolume;
        private System.Windows.Forms.CheckBox chbArea;
        private System.Windows.Forms.CheckBox chbMassa;
        private System.Windows.Forms.GroupBox grbResult;
        private System.Windows.Forms.Button btnCalculate;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Label LblRadius2;
        private System.Windows.Forms.Label LblRadius1;
        private System.Windows.Forms.TextBox TbxRadius2;
        private System.Windows.Forms.TextBox TbxRadius1;
        private System.Windows.Forms.Label LblDensity;
        private System.Windows.Forms.TextBox TbxDensity;
        private System.Windows.Forms.Label lblVolume;
        private System.Windows.Forms.Label LblMassa;
        private System.Windows.Forms.Label LblArea;
        private System.Windows.Forms.TextBox TbxHeight;
        private System.Windows.Forms.Label LblHeight;
        private System.Windows.Forms.ErrorProvider ErpRadius1;
        private System.Windows.Forms.ErrorProvider ErpRadius2;
        private System.Windows.Forms.ErrorProvider ErpHeight;
        private System.Windows.Forms.ErrorProvider ErpDensity;
    }
}