﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using _001_Figures.Models;

namespace _001_Figures
{
    public partial class CylinderForm : Form
    {
        // Данные для обработки
        private Cylinder _cylinder;
        public CylinderForm() {
            InitializeComponent();
            _cylinder = new Cylinder();
        } // CylinderForm

        private void btnExit_Click(object sender, EventArgs e) => Close();

        private void btnCalculate_Click(object sender, EventArgs e) {
            double area;   // площадь 
            double massa;   // масса 
            double volume;  // объем 

            // Получить исходные данные для расчета
            _cylinder.Radius = MainForm.ParseValue(TbxRadius, ErpRadius);
            _cylinder.Height = MainForm.ParseValue(TbxHeight, ErpHeight);
            _cylinder.Density = MainForm.ParseValue(TbxDensity, ErpDensity);

            // расчет объема
            if (chbVolume.Checked) {
                volume = _cylinder.CalcVolume();
                lblVolume.Text = $"Объем цилиндра: {volume:n3}";
            }
            else
                lblVolume.Text = "Объем цилиндра: расчет не требуется";

            // расчет площади
            if (chbArea.Checked)
            {
                area = _cylinder.CalcArea();
                LblArea.Text = $"Площадь цилиндра: {area:n3}";
            }
            else
                LblArea.Text = "Площадь цилиндра: расчет не требуется";

            // расчет массы
            if (chbMassa.Checked) {
                massa = _cylinder.CalcMassa();
                LblMassa.Text = $"Масса цилиндра: {massa:n3}";
            }
            else
                LblMassa.Text = "Масса цилиндра: расчет не требуется";
        } // btnCalculate_Click

        private void TbxRadius_TextChanged(object sender, EventArgs e) =>
            ErpRadius.SetError(TbxRadius, "");

        private void TbxHeight_TextChanged(object sender, EventArgs e) =>
            ErpHeight.SetError(TbxHeight, "");

        private void TbxDensity_TextChanged(object sender, EventArgs e) =>
            ErpDensity.SetError(TbxDensity, "");
    }
}
