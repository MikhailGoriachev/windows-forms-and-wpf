﻿
namespace _001_Figures
{
    partial class CylinderForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnCalculate = new System.Windows.Forms.Button();
            this.grbResult = new System.Windows.Forms.GroupBox();
            this.chbMassa = new System.Windows.Forms.CheckBox();
            this.chbArea = new System.Windows.Forms.CheckBox();
            this.chbVolume = new System.Windows.Forms.CheckBox();
            this.grbData = new System.Windows.Forms.GroupBox();
            this.PcbConoid = new System.Windows.Forms.PictureBox();
            this.TbxHeight = new System.Windows.Forms.TextBox();
            this.LblHeight = new System.Windows.Forms.Label();
            this.TbxDensity = new System.Windows.Forms.TextBox();
            this.TbxRadius = new System.Windows.Forms.TextBox();
            this.LblDensity = new System.Windows.Forms.Label();
            this.LblRadius1 = new System.Windows.Forms.Label();
            this.LblMassa = new System.Windows.Forms.Label();
            this.LblArea = new System.Windows.Forms.Label();
            this.lblVolume = new System.Windows.Forms.Label();
            this.ErpDensity = new System.Windows.Forms.ErrorProvider(this.components);
            this.ErpRadius = new System.Windows.Forms.ErrorProvider(this.components);
            this.ErpHeight = new System.Windows.Forms.ErrorProvider(this.components);
            this.grbResult.SuspendLayout();
            this.grbData.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PcbConoid)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ErpDensity)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ErpRadius)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ErpHeight)).BeginInit();
            this.SuspendLayout();
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btnExit.Location = new System.Drawing.Point(480, 390);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(149, 30);
            this.btnExit.TabIndex = 23;
            this.btnExit.Text = "Выход";
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnCalculate
            // 
            this.btnCalculate.Location = new System.Drawing.Point(480, 334);
            this.btnCalculate.Name = "btnCalculate";
            this.btnCalculate.Size = new System.Drawing.Size(149, 30);
            this.btnCalculate.TabIndex = 22;
            this.btnCalculate.Text = "Рассчитать";
            this.btnCalculate.UseVisualStyleBackColor = true;
            this.btnCalculate.Click += new System.EventHandler(this.btnCalculate_Click);
            // 
            // grbResult
            // 
            this.grbResult.Controls.Add(this.LblMassa);
            this.grbResult.Controls.Add(this.LblArea);
            this.grbResult.Controls.Add(this.lblVolume);
            this.grbResult.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.grbResult.Location = new System.Drawing.Point(21, 288);
            this.grbResult.Name = "grbResult";
            this.grbResult.Size = new System.Drawing.Size(444, 170);
            this.grbResult.TabIndex = 21;
            this.grbResult.TabStop = false;
            this.grbResult.Text = " Результаты расчета: ";
            // 
            // chbMassa
            // 
            this.chbMassa.AutoSize = true;
            this.chbMassa.Checked = true;
            this.chbMassa.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chbMassa.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.chbMassa.Location = new System.Drawing.Point(33, 253);
            this.chbMassa.Name = "chbMassa";
            this.chbMassa.Size = new System.Drawing.Size(164, 20);
            this.chbMassa.TabIndex = 20;
            this.chbMassa.Text = "Рассчитывать массу";
            this.chbMassa.UseVisualStyleBackColor = true;
            // 
            // chbArea
            // 
            this.chbArea.AutoSize = true;
            this.chbArea.Checked = true;
            this.chbArea.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chbArea.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.chbArea.Location = new System.Drawing.Point(33, 227);
            this.chbArea.Name = "chbArea";
            this.chbArea.Size = new System.Drawing.Size(189, 20);
            this.chbArea.TabIndex = 19;
            this.chbArea.Text = "Рассчитывать площадь ";
            this.chbArea.UseVisualStyleBackColor = true;
            // 
            // chbVolume
            // 
            this.chbVolume.AutoSize = true;
            this.chbVolume.Checked = true;
            this.chbVolume.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chbVolume.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.chbVolume.Location = new System.Drawing.Point(33, 201);
            this.chbVolume.Name = "chbVolume";
            this.chbVolume.Size = new System.Drawing.Size(168, 20);
            this.chbVolume.TabIndex = 18;
            this.chbVolume.Text = "Рассчитывать объем";
            this.chbVolume.UseVisualStyleBackColor = true;
            // 
            // grbData
            // 
            this.grbData.Controls.Add(this.TbxHeight);
            this.grbData.Controls.Add(this.LblHeight);
            this.grbData.Controls.Add(this.TbxDensity);
            this.grbData.Controls.Add(this.LblDensity);
            this.grbData.Controls.Add(this.TbxRadius);
            this.grbData.Controls.Add(this.LblRadius1);
            this.grbData.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.grbData.Location = new System.Drawing.Point(22, 17);
            this.grbData.Name = "grbData";
            this.grbData.Size = new System.Drawing.Size(338, 173);
            this.grbData.TabIndex = 17;
            this.grbData.TabStop = false;
            this.grbData.Text = " Исходные данные: ";
            // 
            // PcbConoid
            // 
            this.PcbConoid.Image = global::_001_Figures.Properties.Resources.Picture_Cylinder;
            this.PcbConoid.Location = new System.Drawing.Point(362, 14);
            this.PcbConoid.Name = "PcbConoid";
            this.PcbConoid.Size = new System.Drawing.Size(335, 280);
            this.PcbConoid.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.PcbConoid.TabIndex = 16;
            this.PcbConoid.TabStop = false;
            // 
            // TbxHeight
            // 
            this.TbxHeight.Location = new System.Drawing.Point(124, 81);
            this.TbxHeight.Name = "TbxHeight";
            this.TbxHeight.Size = new System.Drawing.Size(196, 23);
            this.TbxHeight.TabIndex = 31;
            this.TbxHeight.Text = "2,50";
            this.TbxHeight.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.TbxHeight.TextChanged += new System.EventHandler(this.TbxHeight_TextChanged);
            // 
            // LblHeight
            // 
            this.LblHeight.AutoSize = true;
            this.LblHeight.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblHeight.Location = new System.Drawing.Point(6, 84);
            this.LblHeight.Name = "LblHeight";
            this.LblHeight.Size = new System.Drawing.Size(115, 16);
            this.LblHeight.TabIndex = 30;
            this.LblHeight.Text = "Высота цилиндра:";
            // 
            // TbxDensity
            // 
            this.TbxDensity.Location = new System.Drawing.Point(145, 117);
            this.TbxDensity.Name = "TbxDensity";
            this.TbxDensity.Size = new System.Drawing.Size(175, 23);
            this.TbxDensity.TabIndex = 29;
            this.TbxDensity.Text = "1 200,00";
            this.TbxDensity.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.TbxDensity.TextChanged += new System.EventHandler(this.TbxDensity_TextChanged);
            // 
            // TbxRadius
            // 
            this.TbxRadius.Location = new System.Drawing.Point(124, 45);
            this.TbxRadius.Name = "TbxRadius";
            this.TbxRadius.Size = new System.Drawing.Size(196, 23);
            this.TbxRadius.TabIndex = 27;
            this.TbxRadius.Text = "1,00";
            this.TbxRadius.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.TbxRadius.TextChanged += new System.EventHandler(this.TbxRadius_TextChanged);
            // 
            // LblDensity
            // 
            this.LblDensity.AutoSize = true;
            this.LblDensity.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblDensity.Location = new System.Drawing.Point(6, 120);
            this.LblDensity.Name = "LblDensity";
            this.LblDensity.Size = new System.Drawing.Size(141, 16);
            this.LblDensity.TabIndex = 26;
            this.LblDensity.Text = "Плотность материала:";
            // 
            // LblRadius1
            // 
            this.LblRadius1.AutoSize = true;
            this.LblRadius1.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblRadius1.Location = new System.Drawing.Point(6, 48);
            this.LblRadius1.Name = "LblRadius1";
            this.LblRadius1.Size = new System.Drawing.Size(123, 16);
            this.LblRadius1.TabIndex = 24;
            this.LblRadius1.Text = "Радиус основания: ";
            // 
            // LblMassa
            // 
            this.LblMassa.AutoSize = true;
            this.LblMassa.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblMassa.Location = new System.Drawing.Point(7, 110);
            this.LblMassa.Name = "LblMassa";
            this.LblMassa.Size = new System.Drawing.Size(113, 16);
            this.LblMassa.TabIndex = 11;
            this.LblMassa.Text = "Масса цилиндра: ";
            // 
            // LblArea
            // 
            this.LblArea.AutoSize = true;
            this.LblArea.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblArea.Location = new System.Drawing.Point(7, 78);
            this.LblArea.Name = "LblArea";
            this.LblArea.Size = new System.Drawing.Size(131, 16);
            this.LblArea.TabIndex = 10;
            this.LblArea.Text = "Площадь цилиндра: ";
            // 
            // lblVolume
            // 
            this.lblVolume.AutoSize = true;
            this.lblVolume.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblVolume.Location = new System.Drawing.Point(7, 46);
            this.lblVolume.Name = "lblVolume";
            this.lblVolume.Size = new System.Drawing.Size(115, 16);
            this.lblVolume.TabIndex = 9;
            this.lblVolume.Text = "Объем цилиндра: ";
            // 
            // ErpDensity
            // 
            this.ErpDensity.ContainerControl = this;
            // 
            // ErpRadius
            // 
            this.ErpRadius.ContainerControl = this;
            // 
            // ErpHeight
            // 
            this.ErpHeight.ContainerControl = this;
            // 
            // CylinderForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(680, 472);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnCalculate);
            this.Controls.Add(this.grbResult);
            this.Controls.Add(this.chbMassa);
            this.Controls.Add(this.chbArea);
            this.Controls.Add(this.chbVolume);
            this.Controls.Add(this.grbData);
            this.Controls.Add(this.PcbConoid);
            this.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.MaximizeBox = false;
            this.Name = "CylinderForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Cylinder";
            this.grbResult.ResumeLayout(false);
            this.grbResult.PerformLayout();
            this.grbData.ResumeLayout(false);
            this.grbData.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PcbConoid)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ErpDensity)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ErpRadius)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ErpHeight)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnCalculate;
        private System.Windows.Forms.GroupBox grbResult;
        private System.Windows.Forms.CheckBox chbMassa;
        private System.Windows.Forms.CheckBox chbArea;
        private System.Windows.Forms.CheckBox chbVolume;
        private System.Windows.Forms.GroupBox grbData;
        private System.Windows.Forms.PictureBox PcbConoid;
        private System.Windows.Forms.TextBox TbxHeight;
        private System.Windows.Forms.Label LblHeight;
        private System.Windows.Forms.TextBox TbxDensity;
        private System.Windows.Forms.Label LblDensity;
        private System.Windows.Forms.TextBox TbxRadius;
        private System.Windows.Forms.Label LblRadius1;
        private System.Windows.Forms.Label LblMassa;
        private System.Windows.Forms.Label LblArea;
        private System.Windows.Forms.Label lblVolume;
        private System.Windows.Forms.ErrorProvider ErpDensity;
        private System.Windows.Forms.ErrorProvider ErpRadius;
        private System.Windows.Forms.ErrorProvider ErpHeight;
    }
}