﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _001_Figures.Models
{
    // Прямоугольный параллелепипед
    class Parallelepiped {
         // сторона А
        private double _a;
        public double A {
            get => _a;
            set => _a = value <= 0d?1d:value;
        } // A


        // сторона B
        private double _b;
        public double B {
            get => _b;
            set => _b = value <= 0d ? 1d : value;
        } // B


        // сторона C
        private double _c;
        public double C {
            get => _c;
            set => _c = value <= 0d ? 1d : value;
        } // C

        // плотность материала
        private double _density;
        public double Density {
            get => _density;
            set => _density = value <= 0d ? 1d : value;
        } // Density

        // Вычисление площади параллелепипеда
        public double CalcArea() => _a * _b * _c;

        // Вычисление объема параллелепипеда
        public double CalcVolume() => 2d * (_a * _b + _a * _c + _c * _b);

        // Вычисление массы параллелепипеда
        public double CalcMassa() =>
            CalcVolume() * Density;
    } // Parallelepiped
}
