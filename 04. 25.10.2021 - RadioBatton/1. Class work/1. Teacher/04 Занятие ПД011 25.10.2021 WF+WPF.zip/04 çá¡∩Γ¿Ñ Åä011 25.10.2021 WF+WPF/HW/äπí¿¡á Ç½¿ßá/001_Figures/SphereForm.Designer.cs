﻿
namespace _001_Figures
{
    partial class SphereForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnCalculate = new System.Windows.Forms.Button();
            this.grbResult = new System.Windows.Forms.GroupBox();
            this.LblMassa = new System.Windows.Forms.Label();
            this.lblVolume = new System.Windows.Forms.Label();
            this.LblArea = new System.Windows.Forms.Label();
            this.chbMassa = new System.Windows.Forms.CheckBox();
            this.chbArea = new System.Windows.Forms.CheckBox();
            this.chbVolume = new System.Windows.Forms.CheckBox();
            this.grbData = new System.Windows.Forms.GroupBox();
            this.TbxDensity = new System.Windows.Forms.TextBox();
            this.LblRadius = new System.Windows.Forms.Label();
            this.TbxRadius = new System.Windows.Forms.TextBox();
            this.LblDensity = new System.Windows.Forms.Label();
            this.PcbConoid = new System.Windows.Forms.PictureBox();
            this.ErpDensity = new System.Windows.Forms.ErrorProvider(this.components);
            this.ErpRadius = new System.Windows.Forms.ErrorProvider(this.components);
            this.grbResult.SuspendLayout();
            this.grbData.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PcbConoid)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ErpDensity)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ErpRadius)).BeginInit();
            this.SuspendLayout();
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btnExit.Location = new System.Drawing.Point(480, 390);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(149, 30);
            this.btnExit.TabIndex = 6;
            this.btnExit.Text = "Выход";
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnCalculate
            // 
            this.btnCalculate.Location = new System.Drawing.Point(480, 334);
            this.btnCalculate.Name = "btnCalculate";
            this.btnCalculate.Size = new System.Drawing.Size(149, 30);
            this.btnCalculate.TabIndex = 5;
            this.btnCalculate.Text = "Рассчитать";
            this.btnCalculate.UseVisualStyleBackColor = true;
            this.btnCalculate.Click += new System.EventHandler(this.btnCalculate_Click);
            // 
            // grbResult
            // 
            this.grbResult.Controls.Add(this.LblMassa);
            this.grbResult.Controls.Add(this.lblVolume);
            this.grbResult.Controls.Add(this.LblArea);
            this.grbResult.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.grbResult.Location = new System.Drawing.Point(21, 288);
            this.grbResult.Name = "grbResult";
            this.grbResult.Size = new System.Drawing.Size(444, 170);
            this.grbResult.TabIndex = 13;
            this.grbResult.TabStop = false;
            this.grbResult.Text = " Результаты расчета: ";
            // 
            // LblMassa
            // 
            this.LblMassa.AutoSize = true;
            this.LblMassa.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblMassa.Location = new System.Drawing.Point(7, 110);
            this.LblMassa.Name = "LblMassa";
            this.LblMassa.Size = new System.Drawing.Size(96, 16);
            this.LblMassa.TabIndex = 18;
            this.LblMassa.Text = "Масса сферы: ";
            // 
            // lblVolume
            // 
            this.lblVolume.AutoSize = true;
            this.lblVolume.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblVolume.Location = new System.Drawing.Point(7, 46);
            this.lblVolume.Name = "lblVolume";
            this.lblVolume.Size = new System.Drawing.Size(98, 16);
            this.lblVolume.TabIndex = 16;
            this.lblVolume.Text = "Объем сферы: ";
            // 
            // LblArea
            // 
            this.LblArea.AutoSize = true;
            this.LblArea.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblArea.Location = new System.Drawing.Point(7, 78);
            this.LblArea.Name = "LblArea";
            this.LblArea.Size = new System.Drawing.Size(114, 16);
            this.LblArea.TabIndex = 17;
            this.LblArea.Text = "Площадь сферы: ";
            // 
            // chbMassa
            // 
            this.chbMassa.AutoSize = true;
            this.chbMassa.Checked = true;
            this.chbMassa.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chbMassa.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.chbMassa.Location = new System.Drawing.Point(33, 253);
            this.chbMassa.Name = "chbMassa";
            this.chbMassa.Size = new System.Drawing.Size(164, 20);
            this.chbMassa.TabIndex = 4;
            this.chbMassa.Text = "Рассчитывать массу";
            this.chbMassa.UseVisualStyleBackColor = true;
            // 
            // chbArea
            // 
            this.chbArea.AutoSize = true;
            this.chbArea.Checked = true;
            this.chbArea.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chbArea.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.chbArea.Location = new System.Drawing.Point(33, 227);
            this.chbArea.Name = "chbArea";
            this.chbArea.Size = new System.Drawing.Size(189, 20);
            this.chbArea.TabIndex = 3;
            this.chbArea.Text = "Рассчитывать площадь ";
            this.chbArea.UseVisualStyleBackColor = true;
            // 
            // chbVolume
            // 
            this.chbVolume.AutoSize = true;
            this.chbVolume.Checked = true;
            this.chbVolume.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chbVolume.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.chbVolume.Location = new System.Drawing.Point(33, 201);
            this.chbVolume.Name = "chbVolume";
            this.chbVolume.Size = new System.Drawing.Size(168, 20);
            this.chbVolume.TabIndex = 2;
            this.chbVolume.Text = "Рассчитывать объем";
            this.chbVolume.UseVisualStyleBackColor = true;
            // 
            // grbData
            // 
            this.grbData.Controls.Add(this.TbxDensity);
            this.grbData.Controls.Add(this.LblRadius);
            this.grbData.Controls.Add(this.TbxRadius);
            this.grbData.Controls.Add(this.LblDensity);
            this.grbData.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.grbData.Location = new System.Drawing.Point(22, 17);
            this.grbData.Name = "grbData";
            this.grbData.Size = new System.Drawing.Size(338, 173);
            this.grbData.TabIndex = 0;
            this.grbData.TabStop = false;
            this.grbData.Text = " Исходные данные: ";
            // 
            // TbxDensity
            // 
            this.TbxDensity.Location = new System.Drawing.Point(154, 97);
            this.TbxDensity.Name = "TbxDensity";
            this.TbxDensity.Size = new System.Drawing.Size(165, 23);
            this.TbxDensity.TabIndex = 1;
            this.TbxDensity.Text = "1 200,00";
            this.TbxDensity.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.TbxDensity.TextChanged += new System.EventHandler(this.TbxDensity_TextChanged);
            // 
            // LblRadius
            // 
            this.LblRadius.AutoSize = true;
            this.LblRadius.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblRadius.Location = new System.Drawing.Point(7, 59);
            this.LblRadius.Name = "LblRadius";
            this.LblRadius.Size = new System.Drawing.Size(57, 16);
            this.LblRadius.TabIndex = 16;
            this.LblRadius.Text = "Радиус: ";
            // 
            // TbxRadius
            // 
            this.TbxRadius.Location = new System.Drawing.Point(68, 56);
            this.TbxRadius.Name = "TbxRadius";
            this.TbxRadius.Size = new System.Drawing.Size(251, 23);
            this.TbxRadius.TabIndex = 0;
            this.TbxRadius.Text = "1,80";
            this.TbxRadius.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.TbxRadius.TextChanged += new System.EventHandler(this.TbxRadius_TextChanged);
            // 
            // LblDensity
            // 
            this.LblDensity.AutoSize = true;
            this.LblDensity.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblDensity.Location = new System.Drawing.Point(7, 100);
            this.LblDensity.Name = "LblDensity";
            this.LblDensity.Size = new System.Drawing.Size(141, 16);
            this.LblDensity.TabIndex = 17;
            this.LblDensity.Text = "Плотность материала:";
            // 
            // PcbConoid
            // 
            this.PcbConoid.Image = global::_001_Figures.Properties.Resources.Picture_Sphere;
            this.PcbConoid.Location = new System.Drawing.Point(362, 14);
            this.PcbConoid.Name = "PcbConoid";
            this.PcbConoid.Size = new System.Drawing.Size(335, 280);
            this.PcbConoid.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.PcbConoid.TabIndex = 8;
            this.PcbConoid.TabStop = false;
            // 
            // ErpDensity
            // 
            this.ErpDensity.ContainerControl = this;
            // 
            // ErpRadius
            // 
            this.ErpRadius.ContainerControl = this;
            // 
            // SphereForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(680, 472);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnCalculate);
            this.Controls.Add(this.grbResult);
            this.Controls.Add(this.chbMassa);
            this.Controls.Add(this.chbArea);
            this.Controls.Add(this.chbVolume);
            this.Controls.Add(this.grbData);
            this.Controls.Add(this.PcbConoid);
            this.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.MinimizeBox = false;
            this.Name = "SphereForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Sphere";
            this.grbResult.ResumeLayout(false);
            this.grbResult.PerformLayout();
            this.grbData.ResumeLayout(false);
            this.grbData.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PcbConoid)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ErpDensity)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ErpRadius)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnCalculate;
        private System.Windows.Forms.GroupBox grbResult;
        private System.Windows.Forms.CheckBox chbMassa;
        private System.Windows.Forms.CheckBox chbArea;
        private System.Windows.Forms.CheckBox chbVolume;
        private System.Windows.Forms.GroupBox grbData;
        private System.Windows.Forms.PictureBox PcbConoid;
        private System.Windows.Forms.TextBox TbxDensity;
        private System.Windows.Forms.Label LblRadius;
        private System.Windows.Forms.TextBox TbxRadius;
        private System.Windows.Forms.Label LblDensity;
        private System.Windows.Forms.ErrorProvider ErpDensity;
        private System.Windows.Forms.ErrorProvider ErpRadius;
        private System.Windows.Forms.Label LblMassa;
        private System.Windows.Forms.Label lblVolume;
        private System.Windows.Forms.Label LblArea;
    }
}