﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using _001_Figures.Models;

namespace _001_Figures
{
    public partial class SphereForm : Form
    {
        // Данные для обработки
        private Sphere _sphere;
        public SphereForm() {
            InitializeComponent();
            _sphere = new Sphere();
        } // SphereForm

        private void btnExit_Click(object sender, EventArgs e) => Close();

        private void btnCalculate_Click(object sender, EventArgs e) {
            double area;   // площадь 
            double massa;   // масса 
            double volume;  // объем 

            // Получить исходные данные для расчета
            _sphere.Radius = MainForm.ParseValue(TbxRadius, ErpRadius);
            _sphere.Density = MainForm.ParseValue(TbxDensity, ErpDensity);

            // расчет объема
            if (chbVolume.Checked) {
                volume = _sphere.CalcVolume();
                lblVolume.Text = $"Объем сферы: {volume:n3}";
            }
            else
                lblVolume.Text = "Объем сферы: расчет не требуется";

            // расчет площади
            if (chbArea.Checked)
            {
                area = _sphere.CalcArea();
                LblArea.Text = $"Площадь сферы: {area:n3}";
            }
            else
                LblArea.Text = "Площадь сферы: расчет не требуется";

            // расчет массы
            if (chbMassa.Checked){
                massa = _sphere.CalcMassa();
                LblMassa.Text = $"Масса сферы: {massa:n3}";
            }
            else
                LblMassa.Text = "Масса сферы: расчет не требуется";
        } // btnCalculate_Click

        private void TbxRadius_TextChanged(object sender, EventArgs e) =>
            ErpRadius.SetError(TbxRadius, "");

        private void TbxDensity_TextChanged(object sender, EventArgs e) =>
            ErpDensity.SetError(TbxDensity, "");
    }
}
