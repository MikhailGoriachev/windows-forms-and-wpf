﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _001_Figures
{
    public partial class MainForm : Form
    {
        // формы приложения
        private ConoidForm         _conoidForm;
        private SphereForm         _sphereForm;
        private CylinderForm       _cylinderForm;
        private ParallelepipedForm _parallelepipedForm;
        private InformationForm    _informationForm;

        public MainForm() {
            InitializeComponent();
        }

        private void BtnOuit_Click(object sender, EventArgs e) => Application.Exit();

        private void BtnConoid_Click(object sender, EventArgs e) {
            _conoidForm = new ConoidForm();
            _conoidForm.ShowDialog();  // модальное отображение формы
        } // BtnConoid_Click

        private void BtnSphere_Click(object sender, EventArgs e) {
            _sphereForm = new SphereForm();
            _sphereForm.ShowDialog();  // модальное отображение формы
        } // BtnSphere_Click

        private void BtnCylinder_Click(object sender, EventArgs e) {
            _cylinderForm = new CylinderForm();
            _cylinderForm.ShowDialog();  // модальное отображение формы
        } // BtnCylinder_Click

        private void BtnParallelepiped_Click(object sender, EventArgs e) {
            _parallelepipedForm = new ParallelepipedForm();
            _parallelepipedForm.ShowDialog();  // модальное отображение формы
        } // BtnParallelepiped_Click

        public static double ParseValue(TextBox textBox, ErrorProvider errorProvider) {
            bool result = double.TryParse(textBox.Text, out double value);
            errorProvider.SetError(textBox, !result || value <= 0 ? "Недопустимый формат" : "");
            return value;
        } // ParseValue

        private void BtnInformation_Click(object sender, EventArgs e) {
            _informationForm = new InformationForm();
            _informationForm.ShowDialog();  // модальное отображение формы
        } // BtnInformation_Click
    }
}
