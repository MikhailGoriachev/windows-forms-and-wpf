﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using _001_Figures.Models;

namespace _001_Figures
{
    public partial class ParallelepipedForm : Form
    {
        // Данные для обработки
        private Parallelepiped _parallelepiped;
        public ParallelepipedForm() {
            InitializeComponent();
            _parallelepiped = new Parallelepiped();
        } // ParallelepipedForm

        private void btnExit_Click(object sender, EventArgs e) => Close();

        private void btnCalculate_Click(object sender, EventArgs e) {
            double area;    // площадь 
            double massa;   // масса 
            double volume;  // объем 

            // Получить исходные данные для расчета
            _parallelepiped.A = MainForm.ParseValue(TbxSideA, ErpSideA);
            _parallelepiped.B = MainForm.ParseValue(TbxSideB, ErpSideB);
            _parallelepiped.C = MainForm.ParseValue(TbxHeight, ErpHeight);
            _parallelepiped.Density = MainForm.ParseValue(TbxDensity, ErpDensity);

            // расчет объема
            if (chbVolume.Checked) {
                volume = _parallelepiped.CalcVolume();
                lblVolume.Text = $"Объем параллелепипеда: {volume:n3}";
            }
            else
                lblVolume.Text = "Объем параллелепипеда: расчет не требуется";

            // расчет площади
            if (chbArea.Checked) {
                area = _parallelepiped.CalcArea();
                LblArea.Text = $"Площадь параллелепипеда: {area:n3}";
            }
            else
                LblArea.Text = "Площадь параллелепипеда: расчет не требуется";

            // расчет массы
            if (chbMassa.Checked) {
                massa = _parallelepiped.CalcMassa();
                LblMassa.Text = $"Масса параллелепипеда: {massa:n3}";
            }
            else
                LblMassa.Text = "Масса параллелепипеда: расчет не требуется";
        } // btnCalculate_Click

        private void TbxSideA_TextChanged(object sender, EventArgs e) =>
            ErpSideA.SetError(TbxSideA, "");

        private void TbxSideB_TextChanged(object sender, EventArgs e) =>
            ErpSideB.SetError(TbxSideB, "");

        private void TbxHeight_TextChanged(object sender, EventArgs e) =>
            ErpHeight.SetError(TbxHeight, "");

        private void TbxDensity_TextChanged(object sender, EventArgs e) =>
            ErpDensity.SetError(TbxDensity, "");
    }
}
