﻿
namespace _001_Figures
{
    partial class ParallelepipedForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnCalculate = new System.Windows.Forms.Button();
            this.grbResult = new System.Windows.Forms.GroupBox();
            this.chbMassa = new System.Windows.Forms.CheckBox();
            this.chbArea = new System.Windows.Forms.CheckBox();
            this.chbVolume = new System.Windows.Forms.CheckBox();
            this.grbData = new System.Windows.Forms.GroupBox();
            this.PcbConoid = new System.Windows.Forms.PictureBox();
            this.TbxHeight = new System.Windows.Forms.TextBox();
            this.LblHeight = new System.Windows.Forms.Label();
            this.TbxDensity = new System.Windows.Forms.TextBox();
            this.TbxSideB = new System.Windows.Forms.TextBox();
            this.TbxSideA = new System.Windows.Forms.TextBox();
            this.LblDensity = new System.Windows.Forms.Label();
            this.LblSideB = new System.Windows.Forms.Label();
            this.LblSideA = new System.Windows.Forms.Label();
            this.LblMassa = new System.Windows.Forms.Label();
            this.LblArea = new System.Windows.Forms.Label();
            this.lblVolume = new System.Windows.Forms.Label();
            this.ErpSideA = new System.Windows.Forms.ErrorProvider(this.components);
            this.ErpSideB = new System.Windows.Forms.ErrorProvider(this.components);
            this.ErpHeight = new System.Windows.Forms.ErrorProvider(this.components);
            this.ErpDensity = new System.Windows.Forms.ErrorProvider(this.components);
            this.grbResult.SuspendLayout();
            this.grbData.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PcbConoid)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ErpSideA)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ErpSideB)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ErpHeight)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ErpDensity)).BeginInit();
            this.SuspendLayout();
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btnExit.Location = new System.Drawing.Point(481, 388);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(149, 30);
            this.btnExit.TabIndex = 23;
            this.btnExit.Text = "Выход";
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnCalculate
            // 
            this.btnCalculate.Location = new System.Drawing.Point(481, 332);
            this.btnCalculate.Name = "btnCalculate";
            this.btnCalculate.Size = new System.Drawing.Size(149, 30);
            this.btnCalculate.TabIndex = 22;
            this.btnCalculate.Text = "Рассчитать";
            this.btnCalculate.UseVisualStyleBackColor = true;
            this.btnCalculate.Click += new System.EventHandler(this.btnCalculate_Click);
            // 
            // grbResult
            // 
            this.grbResult.Controls.Add(this.LblMassa);
            this.grbResult.Controls.Add(this.lblVolume);
            this.grbResult.Controls.Add(this.LblArea);
            this.grbResult.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.grbResult.Location = new System.Drawing.Point(22, 286);
            this.grbResult.Name = "grbResult";
            this.grbResult.Size = new System.Drawing.Size(444, 170);
            this.grbResult.TabIndex = 21;
            this.grbResult.TabStop = false;
            this.grbResult.Text = " Результаты расчета: ";
            // 
            // chbMassa
            // 
            this.chbMassa.AutoSize = true;
            this.chbMassa.Checked = true;
            this.chbMassa.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chbMassa.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.chbMassa.Location = new System.Drawing.Point(34, 251);
            this.chbMassa.Name = "chbMassa";
            this.chbMassa.Size = new System.Drawing.Size(164, 20);
            this.chbMassa.TabIndex = 20;
            this.chbMassa.Text = "Рассчитывать массу";
            this.chbMassa.UseVisualStyleBackColor = true;
            // 
            // chbArea
            // 
            this.chbArea.AutoSize = true;
            this.chbArea.Checked = true;
            this.chbArea.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chbArea.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.chbArea.Location = new System.Drawing.Point(34, 225);
            this.chbArea.Name = "chbArea";
            this.chbArea.Size = new System.Drawing.Size(189, 20);
            this.chbArea.TabIndex = 19;
            this.chbArea.Text = "Рассчитывать площадь ";
            this.chbArea.UseVisualStyleBackColor = true;
            // 
            // chbVolume
            // 
            this.chbVolume.AutoSize = true;
            this.chbVolume.Checked = true;
            this.chbVolume.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chbVolume.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.chbVolume.Location = new System.Drawing.Point(34, 199);
            this.chbVolume.Name = "chbVolume";
            this.chbVolume.Size = new System.Drawing.Size(168, 20);
            this.chbVolume.TabIndex = 18;
            this.chbVolume.Text = "Рассчитывать объем";
            this.chbVolume.UseVisualStyleBackColor = true;
            // 
            // grbData
            // 
            this.grbData.Controls.Add(this.TbxHeight);
            this.grbData.Controls.Add(this.LblSideA);
            this.grbData.Controls.Add(this.LblHeight);
            this.grbData.Controls.Add(this.LblSideB);
            this.grbData.Controls.Add(this.TbxDensity);
            this.grbData.Controls.Add(this.LblDensity);
            this.grbData.Controls.Add(this.TbxSideB);
            this.grbData.Controls.Add(this.TbxSideA);
            this.grbData.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.grbData.Location = new System.Drawing.Point(23, 15);
            this.grbData.Name = "grbData";
            this.grbData.Size = new System.Drawing.Size(338, 173);
            this.grbData.TabIndex = 17;
            this.grbData.TabStop = false;
            this.grbData.Text = " Исходные данные: ";
            // 
            // PcbConoid
            // 
            this.PcbConoid.Image = global::_001_Figures.Properties.Resources.Picture_Parallelepiped;
            this.PcbConoid.Location = new System.Drawing.Point(373, 3);
            this.PcbConoid.Name = "PcbConoid";
            this.PcbConoid.Size = new System.Drawing.Size(305, 268);
            this.PcbConoid.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.PcbConoid.TabIndex = 16;
            this.PcbConoid.TabStop = false;
            // 
            // TbxHeight
            // 
            this.TbxHeight.Location = new System.Drawing.Point(71, 94);
            this.TbxHeight.Name = "TbxHeight";
            this.TbxHeight.Size = new System.Drawing.Size(249, 23);
            this.TbxHeight.TabIndex = 31;
            this.TbxHeight.Text = "2,50";
            this.TbxHeight.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.TbxHeight.TextChanged += new System.EventHandler(this.TbxHeight_TextChanged);
            // 
            // LblHeight
            // 
            this.LblHeight.AutoSize = true;
            this.LblHeight.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblHeight.Location = new System.Drawing.Point(6, 97);
            this.LblHeight.Name = "LblHeight";
            this.LblHeight.Size = new System.Drawing.Size(59, 16);
            this.LblHeight.TabIndex = 30;
            this.LblHeight.Text = "Высота :";
            // 
            // TbxDensity
            // 
            this.TbxDensity.Location = new System.Drawing.Point(153, 127);
            this.TbxDensity.Name = "TbxDensity";
            this.TbxDensity.Size = new System.Drawing.Size(167, 23);
            this.TbxDensity.TabIndex = 29;
            this.TbxDensity.Text = "1 200,00";
            this.TbxDensity.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.TbxDensity.TextChanged += new System.EventHandler(this.TbxDensity_TextChanged);
            // 
            // TbxSideB
            // 
            this.TbxSideB.Location = new System.Drawing.Point(85, 59);
            this.TbxSideB.Name = "TbxSideB";
            this.TbxSideB.Size = new System.Drawing.Size(235, 23);
            this.TbxSideB.TabIndex = 28;
            this.TbxSideB.Text = "1,50";
            this.TbxSideB.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.TbxSideB.TextChanged += new System.EventHandler(this.TbxSideB_TextChanged);
            // 
            // TbxSideA
            // 
            this.TbxSideA.Location = new System.Drawing.Point(85, 27);
            this.TbxSideA.Name = "TbxSideA";
            this.TbxSideA.Size = new System.Drawing.Size(235, 23);
            this.TbxSideA.TabIndex = 27;
            this.TbxSideA.Text = "1,00";
            this.TbxSideA.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.TbxSideA.TextChanged += new System.EventHandler(this.TbxSideA_TextChanged);
            // 
            // LblDensity
            // 
            this.LblDensity.AutoSize = true;
            this.LblDensity.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblDensity.Location = new System.Drawing.Point(6, 130);
            this.LblDensity.Name = "LblDensity";
            this.LblDensity.Size = new System.Drawing.Size(141, 16);
            this.LblDensity.TabIndex = 26;
            this.LblDensity.Text = "Плотность материала:";
            // 
            // LblSideB
            // 
            this.LblSideB.AutoSize = true;
            this.LblSideB.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblSideB.Location = new System.Drawing.Point(6, 62);
            this.LblSideB.Name = "LblSideB";
            this.LblSideB.Size = new System.Drawing.Size(73, 16);
            this.LblSideB.TabIndex = 25;
            this.LblSideB.Text = "Сторона B:";
            // 
            // LblSideA
            // 
            this.LblSideA.AutoSize = true;
            this.LblSideA.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblSideA.Location = new System.Drawing.Point(6, 30);
            this.LblSideA.Name = "LblSideA";
            this.LblSideA.Size = new System.Drawing.Size(74, 16);
            this.LblSideA.TabIndex = 24;
            this.LblSideA.Text = "Сторона A:";
            // 
            // LblMassa
            // 
            this.LblMassa.AutoSize = true;
            this.LblMassa.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblMassa.Location = new System.Drawing.Point(7, 110);
            this.LblMassa.Name = "LblMassa";
            this.LblMassa.Size = new System.Drawing.Size(162, 16);
            this.LblMassa.TabIndex = 34;
            this.LblMassa.Text = "Масса параллелепипеда: ";
            // 
            // LblArea
            // 
            this.LblArea.AutoSize = true;
            this.LblArea.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblArea.Location = new System.Drawing.Point(7, 78);
            this.LblArea.Name = "LblArea";
            this.LblArea.Size = new System.Drawing.Size(180, 16);
            this.LblArea.TabIndex = 33;
            this.LblArea.Text = "Площадь параллелепипеда: ";
            // 
            // lblVolume
            // 
            this.lblVolume.AutoSize = true;
            this.lblVolume.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblVolume.Location = new System.Drawing.Point(7, 46);
            this.lblVolume.Name = "lblVolume";
            this.lblVolume.Size = new System.Drawing.Size(164, 16);
            this.lblVolume.TabIndex = 32;
            this.lblVolume.Text = "Объем параллелепипеда: ";
            // 
            // ErpSideA
            // 
            this.ErpSideA.ContainerControl = this;
            // 
            // ErpSideB
            // 
            this.ErpSideB.ContainerControl = this;
            // 
            // ErpHeight
            // 
            this.ErpHeight.ContainerControl = this;
            // 
            // ErpDensity
            // 
            this.ErpDensity.ContainerControl = this;
            // 
            // ParallelepipedForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(680, 472);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnCalculate);
            this.Controls.Add(this.grbResult);
            this.Controls.Add(this.chbMassa);
            this.Controls.Add(this.chbArea);
            this.Controls.Add(this.chbVolume);
            this.Controls.Add(this.grbData);
            this.Controls.Add(this.PcbConoid);
            this.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.MaximizeBox = false;
            this.Name = "ParallelepipedForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Parallelepiped";
            this.grbResult.ResumeLayout(false);
            this.grbResult.PerformLayout();
            this.grbData.ResumeLayout(false);
            this.grbData.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PcbConoid)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ErpSideA)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ErpSideB)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ErpHeight)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ErpDensity)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnCalculate;
        private System.Windows.Forms.GroupBox grbResult;
        private System.Windows.Forms.CheckBox chbMassa;
        private System.Windows.Forms.CheckBox chbArea;
        private System.Windows.Forms.CheckBox chbVolume;
        private System.Windows.Forms.GroupBox grbData;
        private System.Windows.Forms.PictureBox PcbConoid;
        private System.Windows.Forms.TextBox TbxHeight;
        private System.Windows.Forms.Label LblSideA;
        private System.Windows.Forms.Label LblHeight;
        private System.Windows.Forms.Label LblSideB;
        private System.Windows.Forms.TextBox TbxDensity;
        private System.Windows.Forms.Label LblDensity;
        private System.Windows.Forms.TextBox TbxSideB;
        private System.Windows.Forms.TextBox TbxSideA;
        private System.Windows.Forms.Label LblMassa;
        private System.Windows.Forms.Label lblVolume;
        private System.Windows.Forms.Label LblArea;
        private System.Windows.Forms.ErrorProvider ErpSideA;
        private System.Windows.Forms.ErrorProvider ErpSideB;
        private System.Windows.Forms.ErrorProvider ErpHeight;
        private System.Windows.Forms.ErrorProvider ErpDensity;
    }
}