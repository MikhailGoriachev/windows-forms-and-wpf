﻿#nullable enable
using System;
using System.Drawing;
using System.Linq;


namespace ProcessBinaryFileTask.Utilities.Menu
{
	public sealed class Menu
	{
		private readonly int        _cursorLength;
		private readonly MenuItem[] _items;
		private readonly string     _title;
		private          int        _currentItem;


		public Menu(string title, MenuItem[] items)
		{
			_title = title;
			_items = items;

			_currentItem   = 0;
			_cursorLength  = _items.Max(item => item.Text.Length);
			CursorPosition = new Point(Console.WindowWidth / _cursorLength + 10, 8);
		}


		public string? DivideLine     { get; set; } = null;
		public Point   CursorPosition { get; set; }


		private void Show()
		{
			Console.CursorVisible = false;

			Console.SetCursorPosition(CursorPosition.X, CursorPosition.Y);
			_title.ColoredLine(Palette.Title);
			Console.WriteLine();

			for (int i = 0; i < _items.Length; i++)
			{
				Console.SetCursorPosition(CursorPosition.X, Console.CursorTop + 1);

				string.Intern($"      {_items[i].Text.PadRight(_cursorLength)}     ")
					  .Colored(i == _currentItem ? Palette.Current : Palette.Normal);

				if (!_items[i].IsDivide)
					continue;

				Console.SetCursorPosition(CursorPosition.X, Console.CursorTop + 1);
				Console.WriteLine(DivideLine);
			}
		}


		private bool Navigate()
		{
			switch (Console.ReadKey(true).Key)
			{
				case ConsoleKey.UpArrow:
					_currentItem--;
					if (_currentItem < 0)
						_currentItem = _items.Length - 1;
					break;
				case ConsoleKey.DownArrow:
					_currentItem++;
					if (_currentItem >= _items.Length)
						_currentItem = 0;
					break;
				case ConsoleKey.Enter:
					_items[_currentItem].InvokeItem();
					break;
				case ConsoleKey.Escape:
					return true;
			}

			return false;
		}


		public void Run()
		{
			Palette.Normal.AsCurrent();
			Console.Clear();

			while (true)
			{
				Show();

				try
				{
					if (Navigate())
					{
						Console.Clear();
						return;
					}
				}
				catch (Exception e)
				{
					e.Output();
				}
			}
		}
	}


	public abstract class MenuWrapper
	{
		protected Menu? Menu { get; init; }


		public void Run() => Menu?.Run();
	}
}