﻿using System;


namespace ProcessBinaryFileTask.Utilities
{


	public readonly struct Color
	{
		public ConsoleColor Foreground { get; }
		public ConsoleColor Background { get; }


		public Color(ConsoleColor foreground, ConsoleColor background)
		{
			Foreground = foreground;
			Background = background;
		}


		public void AsCurrent() => (Console.ForegroundColor, Console.BackgroundColor) = (Foreground, Background);


		public static Color Instantiate() => new(Console.ForegroundColor, Console.BackgroundColor);
	}


}
