﻿namespace ProcessBinaryFileTask
{
	internal static class Program
	{
		public static void Main(string[] args)
		{
			App app = new();

			app.Run();
		}
	}
}