﻿using System;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using ProcessBinaryFileTask.Utilities;


namespace ProcessBinaryFileTask
{
	public sealed class Controller
	{
		private Func<double> Factory { get; }
		private Range<int> Size { get; }
		private string FilePath { get; }


		public Controller(Func<double> factory, Range<int> size, string filePath)
		{
			Factory = factory;
			Size = size;
			FilePath = filePath;
		}


		public void GenerateFile()
		{
			var data = new double[Size.RandomBetween];
			data.Fill(Factory);

			WriteData(data);
		}


		private void WriteData(double[] data)
		{
			using var file = new FileStream(FilePath,
				FileMode.Create, FileAccess.Write, FileShare.None);

			new BinaryFormatter().Serialize(file, data);
		}


		private double[] ReadData()
		{
			using var file = new FileStream(FilePath,
				FileMode.Open, FileAccess.Read, FileShare.Read);

			return (double[])new BinaryFormatter().Deserialize(file);
		}


		public void ShowFile(Action<int, double> coloring = null)
		{
			var data = ReadData();

			for (var i = 0; i < data.Length; i++)
			{
				coloring?.Invoke(i, data[i]);

				Console.Write($"{data[i],12:F}");

				Palette.Default.AsCurrent();

				if ((i + 1) % 8 == 0)
					Console.WriteLine();
			}

			Console.WriteLine("\n\n");
		}


		public (int index, double value) FindFirstLocalMin()
		{
			var data = ReadData();

			for (int i = 1; i < data.Length - 1; i++)
			{
				double previous = data[i - 1],
					   current = data[i],
					   next = data[i + 1];

				if (IsLocalMin(previous, current, next))
					return (i, current);
			}

			throw new InvalidOperationException();
		}


		private static bool IsLocalMin(double lhs, double current, double rhs) => current < rhs && current < lhs;


		public (int min, int max) SwapMinAndMax()
		{
			var data = ReadData();

			int min = Array.IndexOf(data, data.Min());
			int max = Array.IndexOf(data, data.Max());

			(data[min], data[max]) = (data[max], data[min]);

			WriteData(data);

			return (max, min);
		}


		public void DuplicateBetween(Range<double> range)
		{
			var data = ReadData();

			data = data.SelectMany(d =>
						   range.IsInRangeExclusive(d)
							   ? new[] { d, d }
							   : new[] { d })
					   .ToArray();

			WriteData(data);
		}
	}
}