﻿using System;
using ProcessBinaryFileTask.Utilities;
using ProcessBinaryFileTask.Utilities.Menu;
using Palette = ProcessBinaryFileTask.Utilities.Palette;


namespace ProcessBinaryFileTask
{
	public sealed class App : MenuWrapper
	{
		private Controller _controller = new(
			() => General.Rand.RealNextDouble(-10d, 10d),
			new(20, 34) { RandomFunc = (min, max) => General.Rand.Next(min, max) },
			"numbers.bin");


		public App() =>
			Menu = new("Главное меню приложения", new[]
			{
				new MenuItem("Задача 1. Найти первый локальный минимум (элемент который меньше своих соседей)",
					LocalMinimum),	  
				new MenuItem("Задача 2. Поменять местами минимальный и максимальный",
					SwapMinAndMax),	 	  
				new MenuItem("Задача 3. Продублировать числа принадлежащие диапазону 5 - 10",
					DuplicateBetween),
			});


		private void LocalMinimum()
		{
			_controller.GenerateFile();

			_controller.ShowFile();

			var localMin = _controller.FindFirstLocalMin();

			Console.WriteLine("Локальный минимум выделен цветом\n");

			_controller.ShowFile((i, d) =>
			{
				if (i == localMin.index)
					Palette.Accent.AsCurrent();
			});
		}


		private void SwapMinAndMax()
		{
			_controller.GenerateFile();

			_controller.ShowFile();

			var minAndMax = _controller.SwapMinAndMax();

			Console.WriteLine("Элементы выделены цветом\n");

			_controller.ShowFile((i, _) =>
			{
				if (i == minAndMax.min)
					Palette.Accent.AsCurrent();

				if (i == minAndMax.max)
					Palette.Secondary.AsCurrent();
			});
		}


		private void DuplicateBetween()
		{
			_controller.GenerateFile();
			
			_controller.ShowFile();

			var range = new Range<double>(5d, 10d);

			_controller.DuplicateBetween(range);

			Console.WriteLine($"Элементы в диапазоне от {range.Min:F} до {range.Max:F} выделены цветом\n");

			_controller.ShowFile((_, d) =>
			{
				  if (range.IsInRangeExclusive(d))
					  Palette.Accent.AsCurrent();
			});
		}
	}
}