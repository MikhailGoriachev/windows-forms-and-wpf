﻿#nullable enable
using System;
using System.Collections.Generic;
using System.Linq;


namespace ProcessBinaryFileTask.Utilities.Guards
{


	public sealed class Guardian
	{
		public string NullEmptyWhitespace(string? message, string nameOf)
		{
			if (string.IsNullOrWhiteSpace(message))
				throw new ArgumentException(nameOf);

			return message;
		}


		public T Null<T>(T? obj, string nameOf)
			where T : class?
		{
			if (obj is null)
				throw new ArgumentNullException(nameOf);

			return obj;
		}


		public T AllNull<T, TItems>(T? collection, string nameOf)
			where T : class?, IEnumerable<TItems>
			where TItems : class?
		{
			if (collection?.Any(triangle => triangle is null) ?? true)
				throw new ArgumentNullException(nameOf);

			return collection;
		}


		public int Negative(int target, string nameOf)
		{
			if (target < 0)
				throw new ArgumentOutOfRangeException(nameOf);

			return target;
		}


		public double Negative(double target, string nameOf)
		{
			if (target < 0d)
				throw new ArgumentOutOfRangeException(nameOf);

			return target;
		}


		public decimal Negative(decimal target, string nameOf)
		{
			if (target < 0m)
				throw new ArgumentOutOfRangeException(nameOf);

			return target;
		}


		public T Zero<T>(T target, string nameOf)
			where T : unmanaged, IComparable
		{
			if (target.CompareTo(0) == 0)
				throw new ArgumentOutOfRangeException(nameOf);

			return target;
		}


		public T AnyOf<T>(T target, T desired, string nameOf)
			where T : unmanaged, IComparable
		{
			if (target.CompareTo(desired) != 0)
				throw new ArgumentOutOfRangeException(nameOf);

			return target;
		}
		

		public int NegativeOrZero(int target, string nameOf)
		{
			Negative(target, nameOf);
			Zero(target, nameOf);

			return target;
		}


		public double NegativeOrZero(double target, string nameOf)
		{
			Negative(target, nameOf);
			Zero(target, nameOf);

			return target;
		}


		public decimal NegativeOrZero(decimal target, string nameOf)
		{
			Negative(target, nameOf);
			Zero(target, nameOf);

			return target;
		}


		public T Lower<T>(T target, T border, string nameOf)
			where T : unmanaged, IComparable
		{
			if (target.CompareTo(border) == -1)
				throw new ArgumentOutOfRangeException(nameOf);

			return target;
		}


		public T Higher<T>(T target, T border, string nameOf)
			where T : unmanaged, IComparable
		{
			if (target.CompareTo(border) == 1)
				throw new ArgumentOutOfRangeException(nameOf);

			return target;
		}


		public T OutOfRange<T>(T target, T min, T max, string nameOf)
			where T : unmanaged, IComparable
		{
			if (target.CompareTo(min) == -1 || target.CompareTo(max) == 1)
				throw new ArgumentOutOfRangeException(nameOf);

			return target;
		}
	}


}
