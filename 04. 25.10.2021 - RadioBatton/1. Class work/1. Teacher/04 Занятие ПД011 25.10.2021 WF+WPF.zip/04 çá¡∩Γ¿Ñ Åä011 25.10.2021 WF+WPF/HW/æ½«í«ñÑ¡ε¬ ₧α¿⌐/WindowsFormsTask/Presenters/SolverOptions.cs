﻿using System;


namespace WindowsFormsTask.Presenters
{
	[Flags]
	internal enum SolverOptions
	{
		Area = 1,
		Volume = 2,
		Mass = 4
	}


	internal static class SolverOptionsExtensions
	{
		public static bool HasFlagFast(this SolverOptions value, SolverOptions flag)
		{
			return (value & flag) != 0;
		}
	}
}
