﻿
namespace WindowsFormsTask.Controls
{
	sealed partial class SphereInputControl
	{
		/// <summary> 
		/// Обязательная переменная конструктора.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary> 
		/// Освободить все используемые ресурсы.
		/// </summary>
		/// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Код, автоматически созданный конструктором компонентов

		/// <summary> 
		/// Требуемый метод для поддержки конструктора — не изменяйте 
		/// содержимое этого метода с помощью редактора кода.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			this.MainGrid = new System.Windows.Forms.TableLayoutPanel();
			this.DensityTextBox = new System.Windows.Forms.TextBox();
			this.DensityLabel = new System.Windows.Forms.Label();
			this.RadiusTextBox = new System.Windows.Forms.TextBox();
			this.RadiusLabel = new System.Windows.Forms.Label();
			this.MainErrorProvider = new System.Windows.Forms.ErrorProvider(this.components);
			this.MainGrid.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.MainErrorProvider)).BeginInit();
			this.SuspendLayout();
			// 
			// MainGrid
			// 
			this.MainGrid.ColumnCount = 2;
			this.MainGrid.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 43.20713F));
			this.MainGrid.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 56.79287F));
			this.MainGrid.Controls.Add(this.DensityTextBox, 1, 2);
			this.MainGrid.Controls.Add(this.DensityLabel, 0, 2);
			this.MainGrid.Controls.Add(this.RadiusTextBox, 1, 1);
			this.MainGrid.Controls.Add(this.RadiusLabel, 0, 1);
			this.MainGrid.Dock = System.Windows.Forms.DockStyle.Fill;
			this.MainGrid.Location = new System.Drawing.Point(0, 0);
			this.MainGrid.Name = "MainGrid";
			this.MainGrid.RowCount = 4;
			this.MainGrid.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 28.36879F));
			this.MainGrid.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 35.8156F));
			this.MainGrid.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 35.8156F));
			this.MainGrid.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
			this.MainGrid.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
			this.MainGrid.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
			this.MainGrid.Size = new System.Drawing.Size(449, 304);
			this.MainGrid.TabIndex = 1;
			// 
			// DensityTextBox
			// 
			this.DensityTextBox.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
			this.DensityTextBox.Location = new System.Drawing.Point(197, 184);
			this.DensityTextBox.Name = "DensityTextBox";
			this.DensityTextBox.Size = new System.Drawing.Size(249, 29);
			this.DensityTextBox.TabIndex = 7;
			this.DensityTextBox.Validating += new System.ComponentModel.CancelEventHandler(this.TextBox_Validating);
			// 
			// DensityLabel
			// 
			this.DensityLabel.Dock = System.Windows.Forms.DockStyle.Top;
			this.DensityLabel.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
			this.DensityLabel.Location = new System.Drawing.Point(3, 181);
			this.DensityLabel.Name = "DensityLabel";
			this.DensityLabel.Size = new System.Drawing.Size(188, 34);
			this.DensityLabel.TabIndex = 6;
			this.DensityLabel.Text = "Плотность";
			this.DensityLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// RadiusTextBox
			// 
			this.RadiusTextBox.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
			this.RadiusTextBox.Location = new System.Drawing.Point(197, 83);
			this.RadiusTextBox.Name = "RadiusTextBox";
			this.RadiusTextBox.Size = new System.Drawing.Size(249, 29);
			this.RadiusTextBox.TabIndex = 5;
			this.RadiusTextBox.Validating += new System.ComponentModel.CancelEventHandler(this.TextBox_Validating);
			// 
			// RadiusLabel
			// 
			this.RadiusLabel.Dock = System.Windows.Forms.DockStyle.Top;
			this.RadiusLabel.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
			this.RadiusLabel.Location = new System.Drawing.Point(3, 80);
			this.RadiusLabel.Name = "RadiusLabel";
			this.RadiusLabel.Size = new System.Drawing.Size(188, 34);
			this.RadiusLabel.TabIndex = 4;
			this.RadiusLabel.Text = "Радиус";
			this.RadiusLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// MainErrorProvider
			// 
			this.MainErrorProvider.ContainerControl = this;
			this.MainErrorProvider.RightToLeft = true;
			// 
			// SphereInputControl
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.Controls.Add(this.MainGrid);
			this.Name = "SphereInputControl";
			this.Size = new System.Drawing.Size(449, 304);
			this.MainGrid.ResumeLayout(false);
			this.MainGrid.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.MainErrorProvider)).EndInit();
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.TableLayoutPanel MainGrid;
		private System.Windows.Forms.TextBox DensityTextBox;
		private System.Windows.Forms.Label DensityLabel;
		private System.Windows.Forms.TextBox RadiusTextBox;
		private System.Windows.Forms.Label RadiusLabel;
		private System.Windows.Forms.ErrorProvider MainErrorProvider;
	}
}
