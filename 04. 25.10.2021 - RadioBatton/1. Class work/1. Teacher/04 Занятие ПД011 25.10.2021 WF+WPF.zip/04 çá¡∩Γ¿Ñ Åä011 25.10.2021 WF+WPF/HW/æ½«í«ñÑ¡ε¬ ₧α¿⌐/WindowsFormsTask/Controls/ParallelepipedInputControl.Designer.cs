﻿
namespace WindowsFormsTask.Controls
{
	partial class ParallelepipedInputControl
	{
		/// <summary> 
		/// Обязательная переменная конструктора.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary> 
		/// Освободить все используемые ресурсы.
		/// </summary>
		/// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Код, автоматически созданный конструктором компонентов

		/// <summary> 
		/// Требуемый метод для поддержки конструктора — не изменяйте 
		/// содержимое этого метода с помощью редактора кода.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			this.MainGrid = new System.Windows.Forms.TableLayoutPanel();
			this.DensityTextBox = new System.Windows.Forms.TextBox();
			this.DensityLabel = new System.Windows.Forms.Label();
			this.CSideTextBox = new System.Windows.Forms.TextBox();
			this.CSideLabel = new System.Windows.Forms.Label();
			this.BSideLabel = new System.Windows.Forms.Label();
			this.BSideTextBox = new System.Windows.Forms.TextBox();
			this.ASideLabel = new System.Windows.Forms.Label();
			this.ASideTextBox = new System.Windows.Forms.TextBox();
			this.MainErrorProvider = new System.Windows.Forms.ErrorProvider(this.components);
			this.MainGrid.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.MainErrorProvider)).BeginInit();
			this.SuspendLayout();
			// 
			// MainGrid
			// 
			this.MainGrid.ColumnCount = 2;
			this.MainGrid.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 43.20713F));
			this.MainGrid.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 56.79287F));
			this.MainGrid.Controls.Add(this.DensityTextBox, 1, 4);
			this.MainGrid.Controls.Add(this.DensityLabel, 0, 4);
			this.MainGrid.Controls.Add(this.CSideTextBox, 1, 3);
			this.MainGrid.Controls.Add(this.CSideLabel, 0, 3);
			this.MainGrid.Controls.Add(this.BSideLabel, 0, 2);
			this.MainGrid.Controls.Add(this.BSideTextBox, 1, 2);
			this.MainGrid.Controls.Add(this.ASideLabel, 0, 1);
			this.MainGrid.Controls.Add(this.ASideTextBox, 1, 1);
			this.MainGrid.Dock = System.Windows.Forms.DockStyle.Fill;
			this.MainGrid.Location = new System.Drawing.Point(0, 0);
			this.MainGrid.Name = "MainGrid";
			this.MainGrid.RowCount = 6;
			this.MainGrid.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 18.14947F));
			this.MainGrid.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 19.92883F));
			this.MainGrid.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 22.41993F));
			this.MainGrid.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 21.35231F));
			this.MainGrid.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 18.14947F));
			this.MainGrid.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
			this.MainGrid.Size = new System.Drawing.Size(449, 304);
			this.MainGrid.TabIndex = 1;
			// 
			// DensityTextBox
			// 
			this.DensityTextBox.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
			this.DensityTextBox.Location = new System.Drawing.Point(197, 233);
			this.DensityTextBox.Name = "DensityTextBox";
			this.DensityTextBox.Size = new System.Drawing.Size(249, 29);
			this.DensityTextBox.TabIndex = 7;
			// 
			// DensityLabel
			// 
			this.DensityLabel.Dock = System.Windows.Forms.DockStyle.Top;
			this.DensityLabel.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
			this.DensityLabel.Location = new System.Drawing.Point(3, 230);
			this.DensityLabel.Name = "DensityLabel";
			this.DensityLabel.Size = new System.Drawing.Size(188, 34);
			this.DensityLabel.TabIndex = 6;
			this.DensityLabel.Text = "Плотность";
			this.DensityLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// CSideTextBox
			// 
			this.CSideTextBox.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
			this.CSideTextBox.Location = new System.Drawing.Point(197, 173);
			this.CSideTextBox.Name = "CSideTextBox";
			this.CSideTextBox.Size = new System.Drawing.Size(249, 29);
			this.CSideTextBox.TabIndex = 5;
			// 
			// CSideLabel
			// 
			this.CSideLabel.Dock = System.Windows.Forms.DockStyle.Top;
			this.CSideLabel.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
			this.CSideLabel.Location = new System.Drawing.Point(3, 170);
			this.CSideLabel.Name = "CSideLabel";
			this.CSideLabel.Size = new System.Drawing.Size(188, 34);
			this.CSideLabel.TabIndex = 4;
			this.CSideLabel.Text = "Сторона C:";
			this.CSideLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// BSideLabel
			// 
			this.BSideLabel.Dock = System.Windows.Forms.DockStyle.Top;
			this.BSideLabel.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
			this.BSideLabel.Location = new System.Drawing.Point(3, 107);
			this.BSideLabel.Name = "BSideLabel";
			this.BSideLabel.Size = new System.Drawing.Size(188, 34);
			this.BSideLabel.TabIndex = 2;
			this.BSideLabel.Text = "Сторона B:";
			this.BSideLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// BSideTextBox
			// 
			this.BSideTextBox.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
			this.BSideTextBox.Location = new System.Drawing.Point(197, 110);
			this.BSideTextBox.Name = "BSideTextBox";
			this.BSideTextBox.Size = new System.Drawing.Size(249, 29);
			this.BSideTextBox.TabIndex = 3;
			// 
			// ASideLabel
			// 
			this.ASideLabel.Dock = System.Windows.Forms.DockStyle.Top;
			this.ASideLabel.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
			this.ASideLabel.Location = new System.Drawing.Point(3, 51);
			this.ASideLabel.Name = "ASideLabel";
			this.ASideLabel.Size = new System.Drawing.Size(188, 34);
			this.ASideLabel.TabIndex = 0;
			this.ASideLabel.Text = "Сторона А:";
			this.ASideLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// ASideTextBox
			// 
			this.ASideTextBox.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
			this.ASideTextBox.Location = new System.Drawing.Point(197, 54);
			this.ASideTextBox.Name = "ASideTextBox";
			this.ASideTextBox.Size = new System.Drawing.Size(249, 29);
			this.ASideTextBox.TabIndex = 1;
			// 
			// MainErrorProvider
			// 
			this.MainErrorProvider.ContainerControl = this;
			this.MainErrorProvider.RightToLeft = true;
			// 
			// ParallelepipedInputControl
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.Controls.Add(this.MainGrid);
			this.Name = "ParallelepipedInputControl";
			this.Size = new System.Drawing.Size(449, 304);
			this.MainGrid.ResumeLayout(false);
			this.MainGrid.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.MainErrorProvider)).EndInit();
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.TableLayoutPanel MainGrid;
		private System.Windows.Forms.TextBox DensityTextBox;
		private System.Windows.Forms.Label DensityLabel;
		private System.Windows.Forms.TextBox CSideTextBox;
		private System.Windows.Forms.Label CSideLabel;
		private System.Windows.Forms.Label BSideLabel;
		private System.Windows.Forms.TextBox BSideTextBox;
		private System.Windows.Forms.Label ASideLabel;
		private System.Windows.Forms.TextBox ASideTextBox;
		private System.Windows.Forms.ErrorProvider MainErrorProvider;
	}
}
