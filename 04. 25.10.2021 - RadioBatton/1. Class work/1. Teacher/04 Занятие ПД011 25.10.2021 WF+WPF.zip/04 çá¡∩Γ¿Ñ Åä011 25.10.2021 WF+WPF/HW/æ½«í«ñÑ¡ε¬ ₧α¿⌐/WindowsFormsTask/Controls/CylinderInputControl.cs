﻿using System.ComponentModel;
using System.Windows.Forms;
using WindowsFormsTask.Models;


namespace WindowsFormsTask.Controls
{
	public sealed partial class CylinderInputControl : UserControl
	{
		public CylinderInputControl(Cylinder cylinder)
		{
			InitializeComponent();

			HeightTextBox
				.DataBindings
				.Add("Text", cylinder, "Height");

			RadiusTextBox
				.DataBindings
				.Add("Text", cylinder, "Radius");

			DensityTextBox
				.DataBindings
				.Add("Text", cylinder, "Density");
		}


		private void TextBox_Validating(object sender, CancelEventArgs e)
		{
			OnValidating(e);

			ControlsHelpers.Validating(sender as TextBox, MainErrorProvider, e);
		}
	}
}