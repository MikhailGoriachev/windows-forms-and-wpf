﻿namespace WindowsFormsTask.Models
{
	public interface IFigure
	{
		public double Density { get; set; }

		double Area();

		double Volume();

		double Mass() => Volume() * Density;
	}
}