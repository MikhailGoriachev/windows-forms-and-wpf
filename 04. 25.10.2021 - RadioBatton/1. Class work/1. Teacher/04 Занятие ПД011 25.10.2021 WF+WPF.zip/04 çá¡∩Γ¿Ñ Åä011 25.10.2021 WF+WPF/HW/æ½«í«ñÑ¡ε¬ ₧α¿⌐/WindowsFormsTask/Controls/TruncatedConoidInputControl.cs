﻿using System;
using System.ComponentModel;
using System.Windows.Forms;
using WindowsFormsTask.Models;


namespace WindowsFormsTask.Controls
{
	public sealed partial class TruncatedConoidInputControl : UserControl
	{
		public TruncatedConoidInputControl(TruncatedConoid cone)
		{
			InitializeComponent();

			HeightTextBox
				.DataBindings
				.Add("Text", cone, "Height");

			LowerRadiusTextBox
				.DataBindings
				.Add("Text", cone, "LowerRadius");

			UpperRadiusTextBox
				.DataBindings
				.Add("Text", cone, "UpperRadius");

			DensityTextBox
				.DataBindings
				.Add("Text", cone, "Density");
		}


		private void TextBox_Validating(object sender, CancelEventArgs e)
		{
			OnValidating(e);

			ControlsHelpers.Validating(sender as TextBox, MainErrorProvider, e);
		}
	}
}