﻿using System;
using System.Windows.Forms;
using WindowsFormsTask.Presenters;


namespace WindowsFormsTask.Views
{
	public sealed partial class MenuForm : Form, IMenuFormView
	{
		private readonly MenuPresenter _presenter;


		public MenuForm()
		{
			InitializeComponent();

			_presenter = new(this);
		}


		private void TruncatedConoidButton_Click(object sender, EventArgs e) =>
			_presenter.StartTruncatedConoid();


		private void SphereButton_Click(object sender, EventArgs e) =>
			_presenter.StartSphere();


		private void CylinderButton_Click(object sender, EventArgs e) =>
			_presenter.StartCylinder();


		private void ParallelepipedButton_Click(object sender, EventArgs e) =>
			_presenter.StartParallelepiped();


		private void AboutButton_Click(object sender, EventArgs e) =>
			_presenter.StartAboutProgram();
	}
}