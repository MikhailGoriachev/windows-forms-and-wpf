﻿using System.ComponentModel;
using System.Windows.Forms;


namespace WindowsFormsTask.Controls
{
	internal static class ControlsHelpers
	{
		internal static void Validating(TextBox textBox, ErrorProvider errorProvider, CancelEventArgs e)
		{
			if (double.TryParse(textBox.Text, out double _))
			{
				errorProvider.SetError(textBox, null);
				return;
			}

			errorProvider.SetError(textBox, "Введено не вещественное число");
			e.Cancel = true;
		}
	}
}