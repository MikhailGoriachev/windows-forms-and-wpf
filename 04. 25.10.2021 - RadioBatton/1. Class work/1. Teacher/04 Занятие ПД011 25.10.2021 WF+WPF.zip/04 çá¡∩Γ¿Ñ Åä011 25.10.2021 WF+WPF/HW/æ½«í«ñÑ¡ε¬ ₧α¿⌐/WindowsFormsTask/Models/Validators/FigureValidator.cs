﻿using System;
using FluentValidation;


namespace WindowsFormsTask.Models.Validators
{
	public sealed class FigureValidator : AbstractValidator<IFigure>
	{
		internal static Func<double, bool> Positive => value => value > 0d;


		public FigureValidator() =>
			RuleFor(f => f)
				.SetInheritanceValidator(v =>
				{
					v.Add(new CylinderValidator());
					v.Add(new SphereValidator());
					v.Add(new ParallelepipedValidator());
					v.Add(new TruncatedConoidValidator());
				});


		internal static void CheckDensity<T>(AbstractValidator<T> validator)
			where T : IFigure =>
			validator.RuleFor(x => x.Density)
					 .Must(Positive)
					 .WithMessage("Плотность не может быть нулевой или отрицательной");
	}
}