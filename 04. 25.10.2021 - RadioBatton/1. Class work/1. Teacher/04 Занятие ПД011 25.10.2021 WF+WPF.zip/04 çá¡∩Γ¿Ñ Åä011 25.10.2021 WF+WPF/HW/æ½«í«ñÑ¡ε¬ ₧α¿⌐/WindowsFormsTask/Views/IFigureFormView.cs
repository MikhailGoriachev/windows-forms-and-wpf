﻿using System.Drawing;
using System.Windows.Forms;
using WindowsFormsTask.Helpers;


namespace WindowsFormsTask.Views
{
	public interface IFigureFormView
	{
		public double Area { set; }

		public double Volume { set; }

		public double Mass { set; }


		void SetFigureControl(FigureInfo figureInfo);
	}
}