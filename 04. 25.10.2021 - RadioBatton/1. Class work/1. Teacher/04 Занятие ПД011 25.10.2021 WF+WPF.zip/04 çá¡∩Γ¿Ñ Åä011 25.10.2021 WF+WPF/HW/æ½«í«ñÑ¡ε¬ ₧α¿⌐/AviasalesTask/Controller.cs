﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters;
using System.Runtime.Serialization.Formatters.Binary;
using AviasalesTask.Utilities;
using AviasalesTask.Utilities.TableFormatter;


namespace AviasalesTask
{
	public sealed class Controller
	{
		private List<Ticket> _tickets = new();
		private readonly Range<int> _sizeRange;
		private readonly string _path;


		public Controller(Range<int> sizeRange, string path)
		{
			_sizeRange = sizeRange;
			_path = path;
		}


		public void Fill()
		{
			_tickets.Clear();

			TicketFactory factory = new();

			int size = _tickets.Capacity = _sizeRange.RandomBetween;
			for (int i = 0; i < size; i++)
				_tickets.Add(factory.Create());
		}


		public void Show() => Show(_tickets);

		public void Show(IEnumerable<Ticket> tickets, Action<Ticket> coloring = null) => 
			new TableFormatter<Ticket>().Show(tickets);


		public IEnumerable<Ticket> Where(Func<Ticket, bool> predicate) => _tickets.Where(predicate);


		public void Save()
		{
			using var stream = File.Create(_path);

			new BinaryFormatter().Serialize(stream, _tickets);
		}

		private List<Ticket> LoadItems()
		{
			using var stream = File.Open(_path, FileMode.Open);

			var serializer = new BinaryFormatter();

			return (List<Ticket>)serializer.Deserialize(stream);
		}

		public void Load() => _tickets = LoadItems();


		public void Add(Ticket ticket)
		{
			_tickets.Add(ticket);

			Save();
		}


		public void Remove(string code)
		{
			_tickets.RemoveAll(t => t.Code.Equals(code, StringComparison.CurrentCulture));

			Save();
		}


		public void Replace(IEnumerable<Ticket> tickets)
		{
			_tickets = tickets as List<Ticket> ?? tickets.ToList();

			Save();
		}


		public void Clear()
		{
			_tickets.Clear();

			File.Delete(_path);
		}


		public IEnumerable<Ticket> OrderBy<TKey>(Func<Ticket, TKey> selector) => _tickets.OrderBy(selector);
	}
}