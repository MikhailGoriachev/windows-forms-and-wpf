﻿using System;
using System.Globalization;
using System.Linq;
using System.Text;
using AviasalesTask.Utilities;


namespace AviasalesTask
{
	internal class TicketFactory
	{
		private static readonly GregorianCalendar Calendar = new();


		public string CreateCode() =>
			Enumerable.Range(0, General.Rand.Next(4, 12))
					  .Aggregate(new StringBuilder(), (builder, _) =>
						  builder.Append((char)General.Rand.Next('0', '9' + 1)))
					  .ToString();


		public string CreateDestination() =>
			new[]
			{
				"Munchen", "Milano", "Roma", "Bizerte", "Jerusalem", "New Orlean",
				"Singapore", "Canberra", "Cairo", "Istanbul", "Wien", "Buenos Aires",
				"Kuala Lumpur", "Buda", "Detroit", "Luxembourg", "Arnhem", "Eindhoven"
			}.Random();


		public string CreateFlightNumber() =>
			Enumerable.Range(0, General.Rand.Next(3, 7))
					  .Aggregate(new StringBuilder(), (builder, _) =>
						  builder.Append((char)General.Rand.Next('A', 'Z' + 1)))
					  .ToString();


		public string CreateFullname() => $"{CreateFirstname()} {CreateSurname()}";


		private string CreateSurname() => new[]
		{
			"Холод", "Хорт", "Штефан", "Сокол", "Ежак", "Овчаренко",
			"Божко", "Фоменко", "Пиун", "Тищенко", "Рощенко", "Карпенко",
			"Полина", "Станислав", "Жувак", "Ващенко", "Величко", "Горбенко",
			"Ткач", "Иванченко", "Сорока", "Луговских", "Спасибо", "Добрый Вечер"
		}.Random();


		private string CreateFirstname() => new[]
		{
			"Мила", "Константин", "Арсений", "Нонна", "Филипп", "Павел",
			"Анна", "Арина", "Александр", "Илья", "Яна", "Эма",
			"Полина", "Станислав", "Егор", "Георгий", "Богдан", "Пётр",
			"Римма", "Катерина", "Валерия", "Екатерина", "Виталий", "Анна"
		}.Random();


		public DateTime CreateDate() => General.Rand.NextDate();


		public Ticket Create() => new()
		{
			Code = CreateCode(), Destination = CreateDestination(),
			FlightNumber = CreateFlightNumber(), WishfulDate = CreateDate(),
			PassengerFullName = CreateFullname()
		};
	}
}