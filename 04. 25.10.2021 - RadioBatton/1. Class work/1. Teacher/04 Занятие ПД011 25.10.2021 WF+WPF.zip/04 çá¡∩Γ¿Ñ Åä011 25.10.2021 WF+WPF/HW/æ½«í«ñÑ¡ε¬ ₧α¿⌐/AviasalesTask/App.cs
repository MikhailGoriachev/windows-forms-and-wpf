﻿using System;
using AviasalesTask.Utilities;
using AviasalesTask.Utilities.Menu;


namespace AviasalesTask
{
	public sealed class App : MenuWrapper
	{
		private static readonly string DataFile = "Tickets.dat";
		private readonly Controller _controller = new(
			new(15, 26) { RandomFunc = General.Rand.Next },
			DataFile);


		public App() =>
			Menu = new("Главное меню приложения", new[]
			{
				new MenuItem("Заполнить коллекцию билетов", Fill),
				new MenuItem("Вывод коллекции билетов", Show),
				new MenuItem("Сохранение коллекции в бинарный файл", Save),
				new MenuItem("Загрузка коллекции из бинарного файла", Load),
				new MenuItem("Выборка в еще один список заявок по заданному номеру рейса и дате вылета", Where),
				new MenuItem("Добавление заявки, сохранение в файл", Add),
				new MenuItem("Удаление заявки по номеру, сохранение в файл", Remove),
				new MenuItem("Удаление всех заявок из списка и из бинарного файла", Clear),
				new MenuItem("Упорядочивание списка по номеру рейса, сохранение в файл", OrderByCode),
				new MenuItem("Упорядочивание списка по желаемой дате", OrderByWishfulDate)
			});


		private void Fill()
		{
			_controller.Fill();

			_controller.Show();
		}


		private void Show() => _controller.Show();


		public void Save()
		{
			_controller.Save();

			Console.WriteLine($"Данные сохранены в файл {DataFile}");
		}


		public void Load()
		{
			_controller.Load();

			Console.WriteLine("Загруженные данные:\n");

			_controller.Show();
		}


		public void Where()
		{
			_controller.Show();

			Console.Write("Введите номер рейса: ");
			string flightNumber = Console.ReadLine();

			Console.Write("\n\nВведите дату вылета: ");
			DateTime wishfulDate = DateTime.Parse(Console.ReadLine());

			var selected = _controller.Where(t =>
				t.FlightNumber.Equals(flightNumber, StringComparison.CurrentCulture)
				&& wishfulDate.Equals(wishfulDate));

			_controller.Show(selected);
		}


		public void Add()
		{
			_controller.Show();

			var newTicket = new TicketFactory().Create();

			Console.WriteLine(
				$"\nБудет добавлена заявка с номером {newTicket.FlightNumber} и кодом {newTicket.Code}\n\n");
			_controller.Add(newTicket);

			_controller.Show();
		}


		public void Remove()
		{
			_controller.Show();

			Console.Write("Введите номер заявки: ");
			string code = Console.ReadLine();

			_controller.Remove(code);

			_controller.Show();
		}


		public void Clear()
		{
			_controller.Show();

			_controller.Clear();

			_controller.Show();
		}


		public void OrderByCode()
		{
			var tickets = _controller.OrderBy(t => t.Code);

			_controller.Replace(tickets);

			_controller.Show();
		}


		public void OrderByWishfulDate()
		{
			var tickets = _controller.OrderBy(t => t.WishfulDate);

			_controller.Show(tickets);
		}
	}
}