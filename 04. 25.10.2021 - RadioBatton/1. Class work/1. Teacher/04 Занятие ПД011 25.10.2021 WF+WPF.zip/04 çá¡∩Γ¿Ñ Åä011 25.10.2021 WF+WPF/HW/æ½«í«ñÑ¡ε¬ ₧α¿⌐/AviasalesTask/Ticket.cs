﻿using System;
using System.IO;
using AviasalesTask.Utilities.TableFormatter;


namespace AviasalesTask
{
	[Serializable]
	public sealed class Ticket
	{
		[TableData("Код", "{0, -14}")]
		public string Code { get; set; }

		[TableData("Пункт назначения", "{0, -20}")]
		public string Destination { get; set; }

		[TableData("Номер", "{0, -14}")]
		public string FlightNumber { get; set; }

		[TableData("Пассажир", "{0, -25}")]
		public string PassengerFullName { get; set; }

		[TableData("Дата", "{0, -14:d}")]
		public DateTime WishfulDate { get; set; }
	}
}