﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace H_W3WF
{
    public partial class FormConoid : Form
    {
        // Данные для обработки - объект класса усечённый конус
        private Conoid _cone;
        public FormConoid()
        {
            InitializeComponent();

            _cone = new Conoid();
        }

        public FormConoid(Conoid cone)
        {
            InitializeComponent();
            _cone = cone;

            // пересылка данных в элементы интерфейса
            TbxFConoidRadius.Text = $"{cone.R: n2}";
            TbxFConoidHigt.Text   = $"{cone.H: n2}";
            TbxFConoidPlotn.Text  = $"{cone.Density: n2}";
        }

        private void BtnFConoidResult_Click(object sender, EventArgs e)
        {
            try
            {
                double area;    // площадь конуса
                double volume;  // объем конус
                double massa;   // масса конуса

                // Получить исходные данные для расчета
                _cone.R = double.Parse(TbxFConoidRadius.Text);
                _cone.H = double.Parse(TbxFConoidHigt.Text);
                _cone.Density = double.Parse(TbxFConoidPlotn.Text);

                // скорректировать введенные значения
                TbxFConoidRadius.Text = $"{_cone.R:n2}";
                TbxFConoidHigt.Text = $"{_cone.H:n2}";
                TbxFConoidPlotn.Text = $"{_cone.Density:n2}";

                // Расчитать требуемые параметры и вывести на форму
                // Проверяем чекбоксы и вычисляем параметры конуса в соответствии с заданием
                // расчет площади
                if (ChbFConoidArea.Checked)
                {
                    area = _cone.Area;
                    LblFConoidArea.ForeColor = Color.ForestGreen;
                    LblFConoidArea.Text = $"Площадь конуса: {area:n3}";
                }
                else
                {
                    LblFConoidArea.ForeColor = Color.IndianRed;
                    LblFConoidArea.Text = "Площадь конуса:расчет не требуется";
                } // if

                // расчет объема
                if (ChbFConoidVolume.Checked)
                {
                    volume = _cone.Volume;
                    LblFConoidVolum.ForeColor = Color.ForestGreen;
                    LblFConoidVolum.Text = $"Объем конуса: {volume:n3}";
                }
                else
                {
                    LblFConoidVolum.ForeColor = Color.IndianRed;
                    LblFConoidVolum.Text = "Объем конуса:расчет не требуется";
                } // if

                // расчет для массы
                if (ChbFConoidMassa.Checked)
                {
                    massa = _cone.Massa;
                    LblFConoidMassa.ForeColor = Color.ForestGreen;
                    LblFConoidMassa.Text = $"Масса конуса: {massa:n3}";
                }
                else
                {
                    LblFConoidMassa.ForeColor = Color.IndianRed;
                    LblFConoidMassa.Text = "Масса конуса:расчет не требуется";
                } // if
                
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            } // try-catch
        }// BtnFConoidResult_Click

        private void BtnFConoidExit_Click(object sender, EventArgs e) => Close();
        
    }
}
