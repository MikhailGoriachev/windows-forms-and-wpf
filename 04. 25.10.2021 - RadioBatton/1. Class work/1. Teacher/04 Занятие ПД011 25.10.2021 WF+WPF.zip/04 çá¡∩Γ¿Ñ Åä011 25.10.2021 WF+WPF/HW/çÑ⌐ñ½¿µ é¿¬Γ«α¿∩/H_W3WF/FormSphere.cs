﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace H_W3WF
{
    public partial class FormSphere : Form
    {
        // Данные для обработки - объект класса сфера
        private Sphere _sphere;

        public FormSphere()
        {
            InitializeComponent();

            _sphere = new Sphere();
        }

        public FormSphere(Sphere sphere)
        {
            InitializeComponent();
            _sphere = sphere;

            // пересылка данных в элементы интерфейса
            TbxFSphereRadius.Text = $"{sphere.R: n2}";
            TbxFSpherePlotn.Text = $"{sphere.Density: n2}";
        }

        private void BtnFSphereResult_Click(object sender, EventArgs e)
        {
            try
            {
                double area;    // площадь сферы
                double volume;  // объем сферы
                double massa;   // масса сферы

                // Получить исходные данные для расчета
                _sphere.R = double.Parse(TbxFSphereRadius.Text);
                _sphere.Density = double.Parse(TbxFSpherePlotn.Text);

                // скорректировать введенные значения
                TbxFSphereRadius.Text = $"{_sphere.R:n2}";
                TbxFSpherePlotn.Text = $"{_sphere.Density:n2}";

                // Расчитать требуемые параметры и вывести на форму
                // Проверяем чекбоксы и вычисляем параметры сферы в соответствии с заданием
                // расчет площади
                if (ChbFSphereArea.Checked)
                {
                    area = _sphere.Area;
                    LblFSphereArea.ForeColor = Color.ForestGreen;
                    LblFSphereArea.Text = $"Площадь сферы: {area:n3}";
                }
                else
                {
                    LblFSphereArea.ForeColor = Color.IndianRed;
                    LblFSphereArea.Text = "Площадь сферы:расчет не требуется";
                } // if

                // расчет объема
                if (ChbFSphereVolum.Checked)
                {
                    volume = _sphere.Volume;
                    LblFSphereVolum.ForeColor = Color.ForestGreen;
                    LblFSphereVolum.Text = $"Объем сферы: {volume:n3}";
                }
                else
                {
                    LblFSphereVolum.ForeColor = Color.IndianRed;
                    LblFSphereVolum.Text = "Объем сферы:расчет не требуется";
                } // if

                // расчет для массы
                if (ChbFSphereMassa.Checked)
                {
                    massa = _sphere.Massa;
                    LblFSphereMassa.ForeColor = Color.ForestGreen;
                    LblFSphereMassa.Text = $"Масса сферы: {massa:n3}";
                }
                else
                {
                    LblFSphereMassa.ForeColor = Color.IndianRed;
                    LblFSphereMassa.Text = "Масса сферы:расчет не требуется";
                } // if

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            } // try-catch
        }

        private void BtnFSphereExit_Click(object sender, EventArgs e) => Close();

    }
}
