﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace H_W3WF
{
    public partial class MainForm : Form
    {
        // формы приложения
        private FormAboutPrgm _first;
        private FormConoid _formCone;
        private FormSphere _formSphere;
        private FormCylinder _formCylindr;

        public MainForm()
        {
            InitializeComponent();
        }

        private void BtnExit_Click(object sender, EventArgs e) => Application.Exit();

        private void BtnAboutProgm_Click(object sender, EventArgs e)
        {
            _first = new FormAboutPrgm();

            _first.SetText("Студент: Зейдлиц Виктория\nГруппа: ПД011");
            

            // Отобразить форму в модальном режиме
            DialogResult dr = _first.ShowDialog();
        }

        private void BtnConoid_Click(object sender, EventArgs e)
        {
            _formCone = new FormConoid();

            // Отобразить форму в модальном режиме
            _formCone.ShowDialog();
        }

        private void BtnSphere_Click(object sender, EventArgs e)
        {
            _formSphere = new FormSphere();
            // Отобразить форму в модальном режиме
            _formSphere.ShowDialog();
        }

        private void BtnCylinder_Click(object sender, EventArgs e)
        {
            _formCylindr = new FormCylinder();

            // Отобразить форму в модальном режиме
            _formCylindr.ShowDialog();
        }
    }
}
