﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace H_W3WF
{
    public partial class FormAboutPrgm : Form
    {
        public FormAboutPrgm()
        {
            InitializeComponent();
        }

        public string GetText() { return LblAboutPrgm.Text; }
        public void SetText(string text) {
            LblAboutPrgm.Text = text;
            TmrAboutPrgm.Enabled = true; 
        }

        private void TmrAboutPrgm_Tick(object sender, EventArgs e)
        {
            LblAboutPrgm.Text = "";
            TmrAboutPrgm.Enabled = false;
            Close();
        }
    }
}
