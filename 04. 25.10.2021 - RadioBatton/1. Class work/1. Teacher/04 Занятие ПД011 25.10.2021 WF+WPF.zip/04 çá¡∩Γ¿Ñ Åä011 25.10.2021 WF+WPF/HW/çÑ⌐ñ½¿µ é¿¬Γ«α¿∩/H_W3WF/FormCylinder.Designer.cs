﻿
namespace H_W3WF
{
    partial class FormCylinder
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.BtnFCylindrResult = new System.Windows.Forms.Button();
            this.BtnFCylindrExit = new System.Windows.Forms.Button();
            this.ChbFCylindrArea = new System.Windows.Forms.CheckBox();
            this.ChbFCylindrVolume = new System.Windows.Forms.CheckBox();
            this.ChbFCylindrMassa = new System.Windows.Forms.CheckBox();
            this.GrbFCylindrData = new System.Windows.Forms.GroupBox();
            this.GrbFCylindrResult = new System.Windows.Forms.GroupBox();
            this.LbLFCylindrRadius = new System.Windows.Forms.Label();
            this.TbxFCylindrRadius = new System.Windows.Forms.TextBox();
            this.TbxFCylindrHigt = new System.Windows.Forms.TextBox();
            this.LblFCylindrHgt = new System.Windows.Forms.Label();
            this.TbxFCylindrPlotn = new System.Windows.Forms.TextBox();
            this.LblFCylindrPlotn = new System.Windows.Forms.Label();
            this.LblFCylindrArea = new System.Windows.Forms.Label();
            this.LblFCylindrVolum = new System.Windows.Forms.Label();
            this.LblFCylindrMassa = new System.Windows.Forms.Label();
            this.GrbFCylindrData.SuspendLayout();
            this.GrbFCylindrResult.SuspendLayout();
            this.SuspendLayout();
            // 
            // BtnFCylindrResult
            // 
            this.BtnFCylindrResult.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.BtnFCylindrResult.Location = new System.Drawing.Point(351, 262);
            this.BtnFCylindrResult.Name = "BtnFCylindrResult";
            this.BtnFCylindrResult.Size = new System.Drawing.Size(161, 46);
            this.BtnFCylindrResult.TabIndex = 0;
            this.BtnFCylindrResult.Text = "Вычислить";
            this.BtnFCylindrResult.UseVisualStyleBackColor = false;
            this.BtnFCylindrResult.Click += new System.EventHandler(this.BtnFCylindrResult_Click);
            // 
            // BtnFCylindrExit
            // 
            this.BtnFCylindrExit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.BtnFCylindrExit.Location = new System.Drawing.Point(352, 352);
            this.BtnFCylindrExit.Name = "BtnFCylindrExit";
            this.BtnFCylindrExit.Size = new System.Drawing.Size(161, 46);
            this.BtnFCylindrExit.TabIndex = 1;
            this.BtnFCylindrExit.Text = "Выход";
            this.BtnFCylindrExit.UseVisualStyleBackColor = false;
            this.BtnFCylindrExit.Click += new System.EventHandler(this.BtnFCylindrExit_Click);
            // 
            // ChbFCylindrArea
            // 
            this.ChbFCylindrArea.AutoSize = true;
            this.ChbFCylindrArea.Location = new System.Drawing.Point(351, 76);
            this.ChbFCylindrArea.Name = "ChbFCylindrArea";
            this.ChbFCylindrArea.Size = new System.Drawing.Size(162, 18);
            this.ChbFCylindrArea.TabIndex = 2;
            this.ChbFCylindrArea.Text = "Расчитать площадь";
            this.ChbFCylindrArea.UseVisualStyleBackColor = true;
            // 
            // ChbFCylindrVolume
            // 
            this.ChbFCylindrVolume.AutoSize = true;
            this.ChbFCylindrVolume.Location = new System.Drawing.Point(351, 140);
            this.ChbFCylindrVolume.Name = "ChbFCylindrVolume";
            this.ChbFCylindrVolume.Size = new System.Drawing.Size(146, 18);
            this.ChbFCylindrVolume.TabIndex = 3;
            this.ChbFCylindrVolume.Text = "Расчитать объём";
            this.ChbFCylindrVolume.UseVisualStyleBackColor = true;
            // 
            // ChbFCylindrMassa
            // 
            this.ChbFCylindrMassa.AutoSize = true;
            this.ChbFCylindrMassa.Location = new System.Drawing.Point(351, 199);
            this.ChbFCylindrMassa.Name = "ChbFCylindrMassa";
            this.ChbFCylindrMassa.Size = new System.Drawing.Size(154, 18);
            this.ChbFCylindrMassa.TabIndex = 4;
            this.ChbFCylindrMassa.Text = "Расчитать массу ";
            this.ChbFCylindrMassa.UseVisualStyleBackColor = true;
            // 
            // GrbFCylindrData
            // 
            this.GrbFCylindrData.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.GrbFCylindrData.Controls.Add(this.TbxFCylindrPlotn);
            this.GrbFCylindrData.Controls.Add(this.LblFCylindrPlotn);
            this.GrbFCylindrData.Controls.Add(this.TbxFCylindrHigt);
            this.GrbFCylindrData.Controls.Add(this.LblFCylindrHgt);
            this.GrbFCylindrData.Controls.Add(this.TbxFCylindrRadius);
            this.GrbFCylindrData.Controls.Add(this.LbLFCylindrRadius);
            this.GrbFCylindrData.Location = new System.Drawing.Point(12, 22);
            this.GrbFCylindrData.Name = "GrbFCylindrData";
            this.GrbFCylindrData.Size = new System.Drawing.Size(273, 217);
            this.GrbFCylindrData.TabIndex = 5;
            this.GrbFCylindrData.TabStop = false;
            this.GrbFCylindrData.Text = " Исходные данные ";
            // 
            // GrbFCylindrResult
            // 
            this.GrbFCylindrResult.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.GrbFCylindrResult.Controls.Add(this.LblFCylindrMassa);
            this.GrbFCylindrResult.Controls.Add(this.LblFCylindrVolum);
            this.GrbFCylindrResult.Controls.Add(this.LblFCylindrArea);
            this.GrbFCylindrResult.Location = new System.Drawing.Point(12, 262);
            this.GrbFCylindrResult.Name = "GrbFCylindrResult";
            this.GrbFCylindrResult.Size = new System.Drawing.Size(273, 137);
            this.GrbFCylindrResult.TabIndex = 6;
            this.GrbFCylindrResult.TabStop = false;
            this.GrbFCylindrResult.Text = " Результаты расчёта ";
            // 
            // LbLFCylindrRadius
            // 
            this.LbLFCylindrRadius.AutoSize = true;
            this.LbLFCylindrRadius.Location = new System.Drawing.Point(15, 37);
            this.LbLFCylindrRadius.Name = "LbLFCylindrRadius";
            this.LbLFCylindrRadius.Size = new System.Drawing.Size(135, 14);
            this.LbLFCylindrRadius.TabIndex = 0;
            this.LbLFCylindrRadius.Text = "Радиус цилиндра:";
            // 
            // TbxFCylindrRadius
            // 
            this.TbxFCylindrRadius.Location = new System.Drawing.Point(15, 54);
            this.TbxFCylindrRadius.Name = "TbxFCylindrRadius";
            this.TbxFCylindrRadius.Size = new System.Drawing.Size(225, 21);
            this.TbxFCylindrRadius.TabIndex = 1;
            this.TbxFCylindrRadius.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // TbxFCylindrHigt
            // 
            this.TbxFCylindrHigt.Location = new System.Drawing.Point(15, 118);
            this.TbxFCylindrHigt.Name = "TbxFCylindrHigt";
            this.TbxFCylindrHigt.Size = new System.Drawing.Size(225, 21);
            this.TbxFCylindrHigt.TabIndex = 3;
            this.TbxFCylindrHigt.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // LblFCylindrHgt
            // 
            this.LblFCylindrHgt.AutoSize = true;
            this.LblFCylindrHgt.Location = new System.Drawing.Point(15, 101);
            this.LblFCylindrHgt.Name = "LblFCylindrHgt";
            this.LblFCylindrHgt.Size = new System.Drawing.Size(135, 14);
            this.LblFCylindrHgt.TabIndex = 2;
            this.LblFCylindrHgt.Text = "Высота цилиндра:";
            // 
            // TbxFCylindrPlotn
            // 
            this.TbxFCylindrPlotn.Location = new System.Drawing.Point(15, 177);
            this.TbxFCylindrPlotn.Name = "TbxFCylindrPlotn";
            this.TbxFCylindrPlotn.Size = new System.Drawing.Size(225, 21);
            this.TbxFCylindrPlotn.TabIndex = 5;
            this.TbxFCylindrPlotn.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // LblFCylindrPlotn
            // 
            this.LblFCylindrPlotn.AutoSize = true;
            this.LblFCylindrPlotn.Location = new System.Drawing.Point(15, 160);
            this.LblFCylindrPlotn.Name = "LblFCylindrPlotn";
            this.LblFCylindrPlotn.Size = new System.Drawing.Size(167, 14);
            this.LblFCylindrPlotn.TabIndex = 4;
            this.LblFCylindrPlotn.Text = "Плотность материала:";
            // 
            // LblFCylindrArea
            // 
            this.LblFCylindrArea.AutoSize = true;
            this.LblFCylindrArea.Location = new System.Drawing.Point(6, 36);
            this.LblFCylindrArea.Name = "LblFCylindrArea";
            this.LblFCylindrArea.Size = new System.Drawing.Size(135, 14);
            this.LblFCylindrArea.TabIndex = 0;
            this.LblFCylindrArea.Text = "Площадь цилиндра";
            // 
            // LblFCylindrVolum
            // 
            this.LblFCylindrVolum.AutoSize = true;
            this.LblFCylindrVolum.Location = new System.Drawing.Point(6, 69);
            this.LblFCylindrVolum.Name = "LblFCylindrVolum";
            this.LblFCylindrVolum.Size = new System.Drawing.Size(119, 14);
            this.LblFCylindrVolum.TabIndex = 1;
            this.LblFCylindrVolum.Text = "Объём цилиндра";
            // 
            // LblFCylindrMassa
            // 
            this.LblFCylindrMassa.AutoSize = true;
            this.LblFCylindrMassa.Location = new System.Drawing.Point(6, 107);
            this.LblFCylindrMassa.Name = "LblFCylindrMassa";
            this.LblFCylindrMassa.Size = new System.Drawing.Size(119, 14);
            this.LblFCylindrMassa.TabIndex = 2;
            this.LblFCylindrMassa.Text = "Масса цилиндра";
            // 
            // FormCylinder
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.BackColor = System.Drawing.Color.SkyBlue;
            this.ClientSize = new System.Drawing.Size(534, 411);
            this.Controls.Add(this.GrbFCylindrResult);
            this.Controls.Add(this.GrbFCylindrData);
            this.Controls.Add(this.ChbFCylindrMassa);
            this.Controls.Add(this.ChbFCylindrVolume);
            this.Controls.Add(this.ChbFCylindrArea);
            this.Controls.Add(this.BtnFCylindrExit);
            this.Controls.Add(this.BtnFCylindrResult);
            this.Font = new System.Drawing.Font("Lucida Console", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.MaximizeBox = false;
            this.Name = "FormCylinder";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Расчёт цилиндра";
            this.GrbFCylindrData.ResumeLayout(false);
            this.GrbFCylindrData.PerformLayout();
            this.GrbFCylindrResult.ResumeLayout(false);
            this.GrbFCylindrResult.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button BtnFCylindrResult;
        private System.Windows.Forms.Button BtnFCylindrExit;
        private System.Windows.Forms.CheckBox ChbFCylindrArea;
        private System.Windows.Forms.CheckBox ChbFCylindrVolume;
        private System.Windows.Forms.CheckBox ChbFCylindrMassa;
        private System.Windows.Forms.GroupBox GrbFCylindrData;
        private System.Windows.Forms.GroupBox GrbFCylindrResult;
        private System.Windows.Forms.TextBox TbxFCylindrRadius;
        private System.Windows.Forms.Label LbLFCylindrRadius;
        private System.Windows.Forms.TextBox TbxFCylindrPlotn;
        private System.Windows.Forms.Label LblFCylindrPlotn;
        private System.Windows.Forms.TextBox TbxFCylindrHigt;
        private System.Windows.Forms.Label LblFCylindrHgt;
        private System.Windows.Forms.Label LblFCylindrMassa;
        private System.Windows.Forms.Label LblFCylindrVolum;
        private System.Windows.Forms.Label LblFCylindrArea;
    }
}