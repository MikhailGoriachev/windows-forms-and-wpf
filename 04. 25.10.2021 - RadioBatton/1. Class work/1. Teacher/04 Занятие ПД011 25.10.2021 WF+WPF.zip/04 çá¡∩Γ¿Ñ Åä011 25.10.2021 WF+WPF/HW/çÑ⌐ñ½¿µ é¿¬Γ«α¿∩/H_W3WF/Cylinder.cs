﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace H_W3WF
{
    // Класс цилиндр
    public class Cylinder
    {
        private double _r;  // радиус 
        public double R
        {
            get { return _r; }
            set { if (value > 0) _r = value; }
        }

        private double _h;  // высота
        public double H
        {
            get { return _h; }
            set { if (value > 0) _h = value; }
        }


        private double _d;  // плотность
        public double Density
        {
            get => _d;
            set => _d = value <= 0d ? 1d : value;
        }

        // вычисляемое свойство для площади
        public double Area => 2d * Math.PI * _r *(_h + _r);

        // вычисляемое свойство для объема
        public double Volume => Math.PI * _r * _r * _h;

        // вычисляемое свойство для массы
        public double Massa => Volume * _d;

    }// class Cylinder
}
