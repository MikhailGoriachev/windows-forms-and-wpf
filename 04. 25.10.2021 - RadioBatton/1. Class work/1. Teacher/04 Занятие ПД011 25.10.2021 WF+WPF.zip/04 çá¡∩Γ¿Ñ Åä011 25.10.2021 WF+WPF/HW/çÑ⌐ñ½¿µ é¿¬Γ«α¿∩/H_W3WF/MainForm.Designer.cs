﻿
namespace H_W3WF
{
    partial class MainForm
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.LblTextShow = new System.Windows.Forms.Label();
            this.BtnConoid = new System.Windows.Forms.Button();
            this.BtnAboutProgm = new System.Windows.Forms.Button();
            this.BtnExit = new System.Windows.Forms.Button();
            this.BtnSphere = new System.Windows.Forms.Button();
            this.BtnCylinder = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // LblTextShow
            // 
            this.LblTextShow.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblTextShow.Location = new System.Drawing.Point(59, 33);
            this.LblTextShow.Name = "LblTextShow";
            this.LblTextShow.Size = new System.Drawing.Size(481, 23);
            this.LblTextShow.TabIndex = 0;
            this.LblTextShow.Text = "Вычисление параметров геометрических фигур.";
            this.LblTextShow.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // BtnConoid
            // 
            this.BtnConoid.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.BtnConoid.Font = new System.Drawing.Font("Lucida Console", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BtnConoid.Location = new System.Drawing.Point(208, 221);
            this.BtnConoid.Name = "BtnConoid";
            this.BtnConoid.Size = new System.Drawing.Size(192, 70);
            this.BtnConoid.TabIndex = 1;
            this.BtnConoid.Text = "Усеченный конус";
            this.BtnConoid.UseVisualStyleBackColor = false;
            this.BtnConoid.Click += new System.EventHandler(this.BtnConoid_Click);
            // 
            // BtnAboutProgm
            // 
            this.BtnAboutProgm.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.BtnAboutProgm.Font = new System.Drawing.Font("Lucida Console", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BtnAboutProgm.Location = new System.Drawing.Point(62, 331);
            this.BtnAboutProgm.Name = "BtnAboutProgm";
            this.BtnAboutProgm.Size = new System.Drawing.Size(196, 61);
            this.BtnAboutProgm.TabIndex = 2;
            this.BtnAboutProgm.Text = "О программе";
            this.BtnAboutProgm.UseVisualStyleBackColor = false;
            this.BtnAboutProgm.Click += new System.EventHandler(this.BtnAboutProgm_Click);
            // 
            // BtnExit
            // 
            this.BtnExit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.BtnExit.Font = new System.Drawing.Font("Lucida Console", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BtnExit.Location = new System.Drawing.Point(364, 331);
            this.BtnExit.Name = "BtnExit";
            this.BtnExit.Size = new System.Drawing.Size(192, 61);
            this.BtnExit.TabIndex = 3;
            this.BtnExit.Text = "Выход";
            this.BtnExit.UseVisualStyleBackColor = false;
            this.BtnExit.Click += new System.EventHandler(this.BtnExit_Click);
            // 
            // BtnSphere
            // 
            this.BtnSphere.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.BtnSphere.Font = new System.Drawing.Font("Lucida Console", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BtnSphere.Location = new System.Drawing.Point(364, 106);
            this.BtnSphere.Name = "BtnSphere";
            this.BtnSphere.Size = new System.Drawing.Size(196, 70);
            this.BtnSphere.TabIndex = 4;
            this.BtnSphere.Text = "Сфера";
            this.BtnSphere.UseVisualStyleBackColor = false;
            this.BtnSphere.Click += new System.EventHandler(this.BtnSphere_Click);
            // 
            // BtnCylinder
            // 
            this.BtnCylinder.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.BtnCylinder.Font = new System.Drawing.Font("Lucida Console", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BtnCylinder.Location = new System.Drawing.Point(62, 106);
            this.BtnCylinder.Name = "BtnCylinder";
            this.BtnCylinder.Size = new System.Drawing.Size(196, 70);
            this.BtnCylinder.TabIndex = 5;
            this.BtnCylinder.Text = "Цилиндр";
            this.BtnCylinder.UseVisualStyleBackColor = false;
            this.BtnCylinder.Click += new System.EventHandler(this.BtnCylinder_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.ClientSize = new System.Drawing.Size(624, 441);
            this.Controls.Add(this.BtnCylinder);
            this.Controls.Add(this.BtnSphere);
            this.Controls.Add(this.BtnExit);
            this.Controls.Add(this.BtnAboutProgm);
            this.Controls.Add(this.BtnConoid);
            this.Controls.Add(this.LblTextShow);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Домашняя работа №3";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label LblTextShow;
        private System.Windows.Forms.Button BtnConoid;
        private System.Windows.Forms.Button BtnAboutProgm;
        private System.Windows.Forms.Button BtnExit;
        private System.Windows.Forms.Button BtnSphere;
        private System.Windows.Forms.Button BtnCylinder;
    }
}

