﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace H_W3WF
{
    // Класс усечённый конус
    public class Conoid
    {
        private double _r;  // радиус 
        public double R
        {
            get { return _r; }
            set { if (value > 0) _r = value; }
        }

        private double _h;  // высота
        public double H
        {
            get { return _h; }
            set { if (value > 0) _h = value; }
        }


        private double _d;  // плотность
        public double Density
        {
            get => _d;
            set => _d = value <= 0d ? 1d : value;
        }

        // длина образующей
        public double L
        {
            get => Math.Sqrt(_h * _h + _r * _r);
        } // H

        // вычисляемое свойство для площади
        public double Area => Math.PI * (_r * _r + (_r +_r) * L + _r * _r);

        // вычисляемое свойство для объема
        public double Volume => Math.PI * _r * _r * _h / 3d;

        // вычисляемое свойство для массы
        public double Massa => Volume * _d;


    }// class Conoid
}
