﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace H_W3WF
{
    public partial class FormCylinder : Form
    {
        // Данные для обработки - объект класса цилиндр
        private Cylinder _cylinder;
        public FormCylinder()
        {
            InitializeComponent();

            _cylinder = new Cylinder();
        }

        public FormCylinder(Cylinder cylinder)
        {
            InitializeComponent();
            _cylinder = cylinder;

            // пересылка данных в элементы интерфейса
            TbxFCylindrRadius.Text = $"{cylinder.R: n2}";
            TbxFCylindrHigt.Text = $"{cylinder.H: n2}";
            TbxFCylindrPlotn.Text = $"{cylinder.Density: n2}";
        }

        private void BtnFCylindrResult_Click(object sender, EventArgs e)
        {
            try
            {
                double area;    // площадь конуса
                double volume;  // объем конус
                double massa;   // масса конуса

                // Получить исходные данные для расчета
                _cylinder.R = double.Parse(TbxFCylindrRadius.Text);
                _cylinder.H = double.Parse(TbxFCylindrHigt.Text);
                _cylinder.Density = double.Parse(TbxFCylindrPlotn.Text);

                // скорректировать введенные значения
                TbxFCylindrRadius.Text = $"{_cylinder.R:n2}";
                TbxFCylindrHigt.Text = $"{_cylinder.H:n2}";
                TbxFCylindrPlotn.Text = $"{_cylinder.Density:n2}";

                // Расчитать требуемые параметры и вывести на форму
                // Проверяем чекбоксы и вычисляем параметры цилиндра в соответствии с заданием
                // расчет площади
                if (ChbFCylindrArea.Checked)
                {
                    area = _cylinder.Area;
                    LblFCylindrArea.ForeColor = Color.ForestGreen;
                    LblFCylindrArea.Text = $"Площадь цилиндра: {area:n3}";
                }
                else
                {
                    LblFCylindrArea.ForeColor = Color.IndianRed;
                    LblFCylindrArea.Text = "Площадь цилиндра:расчет не требуется";
                } // if

                // расчет объема
                if (ChbFCylindrVolume.Checked)
                {
                    volume = _cylinder.Volume;
                    LblFCylindrVolum.ForeColor = Color.ForestGreen;
                    LblFCylindrVolum.Text = $"Объем цилиндра: {volume:n3}";
                }
                else
                {
                    LblFCylindrVolum.ForeColor = Color.IndianRed;
                    LblFCylindrVolum.Text = "Объем цилиндра:расчет не требуется";
                } // if

                // расчет для массы
                if (ChbFCylindrMassa.Checked)
                {
                    massa = _cylinder.Massa;
                    LblFCylindrMassa.ForeColor = Color.ForestGreen;
                    LblFCylindrMassa.Text = $"Масса цилиндра: {massa:n3}";
                }
                else
                {
                    LblFCylindrMassa.ForeColor = Color.IndianRed;
                    LblFCylindrMassa.Text = "Масса цилиндра:расчет не требуется";
                } // if

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            } // try-catch
        }// BtnFConoidResult_Click

        private void BtnFCylindrExit_Click(object sender, EventArgs e) => Close();

    }// class FormCylinder






}
