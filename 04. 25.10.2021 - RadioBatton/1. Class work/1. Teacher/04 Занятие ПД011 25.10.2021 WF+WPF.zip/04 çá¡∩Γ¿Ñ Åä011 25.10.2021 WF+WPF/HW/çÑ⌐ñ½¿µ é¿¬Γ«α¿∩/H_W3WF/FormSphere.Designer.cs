﻿
namespace H_W3WF
{
    partial class FormSphere
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.BtnFSphereResult = new System.Windows.Forms.Button();
            this.BtnFSphereExit = new System.Windows.Forms.Button();
            this.ChbFSphereArea = new System.Windows.Forms.CheckBox();
            this.GrbFSphereData = new System.Windows.Forms.GroupBox();
            this.GrbFSphereResult = new System.Windows.Forms.GroupBox();
            this.LblFSphereRadius = new System.Windows.Forms.Label();
            this.TbxFSphereRadius = new System.Windows.Forms.TextBox();
            this.TbxFSpherePlotn = new System.Windows.Forms.TextBox();
            this.LblFSpherePlotn = new System.Windows.Forms.Label();
            this.LblFSphereArea = new System.Windows.Forms.Label();
            this.LblFSphereVolum = new System.Windows.Forms.Label();
            this.LblFSphereMassa = new System.Windows.Forms.Label();
            this.ChbFSphereVolum = new System.Windows.Forms.CheckBox();
            this.ChbFSphereMassa = new System.Windows.Forms.CheckBox();
            this.GrbFSphereData.SuspendLayout();
            this.GrbFSphereResult.SuspendLayout();
            this.SuspendLayout();
            // 
            // BtnFSphereResult
            // 
            this.BtnFSphereResult.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.BtnFSphereResult.Font = new System.Drawing.Font("Lucida Console", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BtnFSphereResult.Location = new System.Drawing.Point(353, 262);
            this.BtnFSphereResult.Name = "BtnFSphereResult";
            this.BtnFSphereResult.Size = new System.Drawing.Size(161, 50);
            this.BtnFSphereResult.TabIndex = 0;
            this.BtnFSphereResult.Text = "Вычислить";
            this.BtnFSphereResult.UseVisualStyleBackColor = false;
            this.BtnFSphereResult.Click += new System.EventHandler(this.BtnFSphereResult_Click);
            // 
            // BtnFSphereExit
            // 
            this.BtnFSphereExit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.BtnFSphereExit.Font = new System.Drawing.Font("Lucida Console", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BtnFSphereExit.Location = new System.Drawing.Point(353, 335);
            this.BtnFSphereExit.Name = "BtnFSphereExit";
            this.BtnFSphereExit.Size = new System.Drawing.Size(161, 50);
            this.BtnFSphereExit.TabIndex = 1;
            this.BtnFSphereExit.Text = "Выход";
            this.BtnFSphereExit.UseVisualStyleBackColor = false;
            this.BtnFSphereExit.Click += new System.EventHandler(this.BtnFSphereExit_Click);
            // 
            // ChbFSphereArea
            // 
            this.ChbFSphereArea.AutoSize = true;
            this.ChbFSphereArea.Font = new System.Drawing.Font("Lucida Console", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ChbFSphereArea.Location = new System.Drawing.Point(360, 70);
            this.ChbFSphereArea.Name = "ChbFSphereArea";
            this.ChbFSphereArea.Size = new System.Drawing.Size(162, 18);
            this.ChbFSphereArea.TabIndex = 2;
            this.ChbFSphereArea.Text = "Расчитать площадь";
            this.ChbFSphereArea.UseVisualStyleBackColor = true;
            // 
            // GrbFSphereData
            // 
            this.GrbFSphereData.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.GrbFSphereData.Controls.Add(this.TbxFSpherePlotn);
            this.GrbFSphereData.Controls.Add(this.LblFSpherePlotn);
            this.GrbFSphereData.Controls.Add(this.TbxFSphereRadius);
            this.GrbFSphereData.Controls.Add(this.LblFSphereRadius);
            this.GrbFSphereData.Font = new System.Drawing.Font("Lucida Console", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.GrbFSphereData.Location = new System.Drawing.Point(12, 21);
            this.GrbFSphereData.Name = "GrbFSphereData";
            this.GrbFSphereData.Size = new System.Drawing.Size(273, 217);
            this.GrbFSphereData.TabIndex = 3;
            this.GrbFSphereData.TabStop = false;
            this.GrbFSphereData.Text = " Исходные данные ";
            // 
            // GrbFSphereResult
            // 
            this.GrbFSphereResult.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.GrbFSphereResult.Controls.Add(this.LblFSphereMassa);
            this.GrbFSphereResult.Controls.Add(this.LblFSphereVolum);
            this.GrbFSphereResult.Controls.Add(this.LblFSphereArea);
            this.GrbFSphereResult.Font = new System.Drawing.Font("Lucida Console", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.GrbFSphereResult.Location = new System.Drawing.Point(12, 262);
            this.GrbFSphereResult.Name = "GrbFSphereResult";
            this.GrbFSphereResult.Size = new System.Drawing.Size(273, 137);
            this.GrbFSphereResult.TabIndex = 4;
            this.GrbFSphereResult.TabStop = false;
            this.GrbFSphereResult.Text = " Результаты расчёта ";
            // 
            // LblFSphereRadius
            // 
            this.LblFSphereRadius.AutoSize = true;
            this.LblFSphereRadius.Location = new System.Drawing.Point(12, 53);
            this.LblFSphereRadius.Name = "LblFSphereRadius";
            this.LblFSphereRadius.Size = new System.Drawing.Size(111, 14);
            this.LblFSphereRadius.TabIndex = 0;
            this.LblFSphereRadius.Text = "Радиус сферы:";
            // 
            // TbxFSphereRadius
            // 
            this.TbxFSphereRadius.Location = new System.Drawing.Point(12, 70);
            this.TbxFSphereRadius.Name = "TbxFSphereRadius";
            this.TbxFSphereRadius.Size = new System.Drawing.Size(228, 21);
            this.TbxFSphereRadius.TabIndex = 1;
            this.TbxFSphereRadius.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // TbxFSpherePlotn
            // 
            this.TbxFSpherePlotn.Location = new System.Drawing.Point(12, 140);
            this.TbxFSpherePlotn.Name = "TbxFSpherePlotn";
            this.TbxFSpherePlotn.Size = new System.Drawing.Size(228, 21);
            this.TbxFSpherePlotn.TabIndex = 5;
            this.TbxFSpherePlotn.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // LblFSpherePlotn
            // 
            this.LblFSpherePlotn.AutoSize = true;
            this.LblFSpherePlotn.Location = new System.Drawing.Point(12, 123);
            this.LblFSpherePlotn.Name = "LblFSpherePlotn";
            this.LblFSpherePlotn.Size = new System.Drawing.Size(167, 14);
            this.LblFSpherePlotn.TabIndex = 4;
            this.LblFSpherePlotn.Text = "Плотность материала:";
            // 
            // LblFSphereArea
            // 
            this.LblFSphereArea.AutoSize = true;
            this.LblFSphereArea.Location = new System.Drawing.Point(23, 33);
            this.LblFSphereArea.Name = "LblFSphereArea";
            this.LblFSphereArea.Size = new System.Drawing.Size(111, 14);
            this.LblFSphereArea.TabIndex = 0;
            this.LblFSphereArea.Text = "Площадь сферы";
            // 
            // LblFSphereVolum
            // 
            this.LblFSphereVolum.AutoSize = true;
            this.LblFSphereVolum.Location = new System.Drawing.Point(23, 73);
            this.LblFSphereVolum.Name = "LblFSphereVolum";
            this.LblFSphereVolum.Size = new System.Drawing.Size(95, 14);
            this.LblFSphereVolum.TabIndex = 1;
            this.LblFSphereVolum.Text = "Объём сферы";
            // 
            // LblFSphereMassa
            // 
            this.LblFSphereMassa.AutoSize = true;
            this.LblFSphereMassa.Location = new System.Drawing.Point(23, 106);
            this.LblFSphereMassa.Name = "LblFSphereMassa";
            this.LblFSphereMassa.Size = new System.Drawing.Size(95, 14);
            this.LblFSphereMassa.TabIndex = 2;
            this.LblFSphereMassa.Text = "Масса сферы";
            // 
            // ChbFSphereVolum
            // 
            this.ChbFSphereVolum.AutoSize = true;
            this.ChbFSphereVolum.Font = new System.Drawing.Font("Lucida Console", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ChbFSphereVolum.Location = new System.Drawing.Point(360, 130);
            this.ChbFSphereVolum.Name = "ChbFSphereVolum";
            this.ChbFSphereVolum.Size = new System.Drawing.Size(146, 18);
            this.ChbFSphereVolum.TabIndex = 5;
            this.ChbFSphereVolum.Text = "Расчитать объём";
            this.ChbFSphereVolum.UseVisualStyleBackColor = true;
            // 
            // ChbFSphereMassa
            // 
            this.ChbFSphereMassa.AutoSize = true;
            this.ChbFSphereMassa.Font = new System.Drawing.Font("Lucida Console", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ChbFSphereMassa.Location = new System.Drawing.Point(360, 197);
            this.ChbFSphereMassa.Name = "ChbFSphereMassa";
            this.ChbFSphereMassa.Size = new System.Drawing.Size(154, 18);
            this.ChbFSphereMassa.TabIndex = 6;
            this.ChbFSphereMassa.Text = "Расчитать массу ";
            this.ChbFSphereMassa.UseVisualStyleBackColor = true;
            // 
            // FormSphere
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.SkyBlue;
            this.ClientSize = new System.Drawing.Size(534, 411);
            this.Controls.Add(this.ChbFSphereMassa);
            this.Controls.Add(this.ChbFSphereVolum);
            this.Controls.Add(this.GrbFSphereResult);
            this.Controls.Add(this.GrbFSphereData);
            this.Controls.Add(this.ChbFSphereArea);
            this.Controls.Add(this.BtnFSphereExit);
            this.Controls.Add(this.BtnFSphereResult);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "FormSphere";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Расчёт конуса";
            this.GrbFSphereData.ResumeLayout(false);
            this.GrbFSphereData.PerformLayout();
            this.GrbFSphereResult.ResumeLayout(false);
            this.GrbFSphereResult.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button BtnFSphereResult;
        private System.Windows.Forms.Button BtnFSphereExit;
        private System.Windows.Forms.CheckBox ChbFSphereArea;
        private System.Windows.Forms.GroupBox GrbFSphereData;
        private System.Windows.Forms.TextBox TbxFSphereRadius;
        private System.Windows.Forms.Label LblFSphereRadius;
        private System.Windows.Forms.GroupBox GrbFSphereResult;
        private System.Windows.Forms.TextBox TbxFSpherePlotn;
        private System.Windows.Forms.Label LblFSpherePlotn;
        private System.Windows.Forms.Label LblFSphereMassa;
        private System.Windows.Forms.Label LblFSphereVolum;
        private System.Windows.Forms.Label LblFSphereArea;
        private System.Windows.Forms.CheckBox ChbFSphereVolum;
        private System.Windows.Forms.CheckBox ChbFSphereMassa;
    }
}