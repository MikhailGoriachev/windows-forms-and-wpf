﻿
namespace H_W3WF
{
    partial class FormConoid
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.GrbFConoidData = new System.Windows.Forms.GroupBox();
            this.GrbFConoidResult = new System.Windows.Forms.GroupBox();
            this.LbLFConoidRadius = new System.Windows.Forms.Label();
            this.TbxFConoidRadius = new System.Windows.Forms.TextBox();
            this.ChbFConoidArea = new System.Windows.Forms.CheckBox();
            this.TbxFConoidHigt = new System.Windows.Forms.TextBox();
            this.LblFConoidHgt = new System.Windows.Forms.Label();
            this.TbxFConoidPlotn = new System.Windows.Forms.TextBox();
            this.LblFConoidPlotn = new System.Windows.Forms.Label();
            this.LblFConoidArea = new System.Windows.Forms.Label();
            this.LblFConoidVolum = new System.Windows.Forms.Label();
            this.LblFConoidMassa = new System.Windows.Forms.Label();
            this.BtnFConoidResult = new System.Windows.Forms.Button();
            this.BtnFConoidExit = new System.Windows.Forms.Button();
            this.ChbFConoidVolume = new System.Windows.Forms.CheckBox();
            this.ChbFConoidMassa = new System.Windows.Forms.CheckBox();
            this.GrbFConoidData.SuspendLayout();
            this.GrbFConoidResult.SuspendLayout();
            this.SuspendLayout();
            // 
            // GrbFConoidData
            // 
            this.GrbFConoidData.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.GrbFConoidData.Controls.Add(this.TbxFConoidPlotn);
            this.GrbFConoidData.Controls.Add(this.LblFConoidPlotn);
            this.GrbFConoidData.Controls.Add(this.TbxFConoidHigt);
            this.GrbFConoidData.Controls.Add(this.LblFConoidHgt);
            this.GrbFConoidData.Controls.Add(this.TbxFConoidRadius);
            this.GrbFConoidData.Controls.Add(this.LbLFConoidRadius);
            this.GrbFConoidData.Location = new System.Drawing.Point(12, 21);
            this.GrbFConoidData.Name = "GrbFConoidData";
            this.GrbFConoidData.Size = new System.Drawing.Size(273, 217);
            this.GrbFConoidData.TabIndex = 0;
            this.GrbFConoidData.TabStop = false;
            this.GrbFConoidData.Text = " Исходные данные ";
            // 
            // GrbFConoidResult
            // 
            this.GrbFConoidResult.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.GrbFConoidResult.Controls.Add(this.LblFConoidMassa);
            this.GrbFConoidResult.Controls.Add(this.LblFConoidVolum);
            this.GrbFConoidResult.Controls.Add(this.LblFConoidArea);
            this.GrbFConoidResult.Location = new System.Drawing.Point(12, 262);
            this.GrbFConoidResult.Name = "GrbFConoidResult";
            this.GrbFConoidResult.Size = new System.Drawing.Size(273, 137);
            this.GrbFConoidResult.TabIndex = 1;
            this.GrbFConoidResult.TabStop = false;
            this.GrbFConoidResult.Text = " Результаты расчёта ";
            // 
            // LbLFConoidRadius
            // 
            this.LbLFConoidRadius.AutoSize = true;
            this.LbLFConoidRadius.Location = new System.Drawing.Point(11, 31);
            this.LbLFConoidRadius.Name = "LbLFConoidRadius";
            this.LbLFConoidRadius.Size = new System.Drawing.Size(119, 14);
            this.LbLFConoidRadius.TabIndex = 0;
            this.LbLFConoidRadius.Text = "Радиус конуса:";
            // 
            // TbxFConoidRadius
            // 
            this.TbxFConoidRadius.Location = new System.Drawing.Point(11, 48);
            this.TbxFConoidRadius.Name = "TbxFConoidRadius";
            this.TbxFConoidRadius.Size = new System.Drawing.Size(231, 21);
            this.TbxFConoidRadius.TabIndex = 1;
            this.TbxFConoidRadius.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // ChbFConoidArea
            // 
            this.ChbFConoidArea.AutoSize = true;
            this.ChbFConoidArea.Location = new System.Drawing.Point(345, 69);
            this.ChbFConoidArea.Name = "ChbFConoidArea";
            this.ChbFConoidArea.Size = new System.Drawing.Size(162, 18);
            this.ChbFConoidArea.TabIndex = 2;
            this.ChbFConoidArea.Text = "Расчитать площадь";
            this.ChbFConoidArea.UseVisualStyleBackColor = true;
            // 
            // TbxFConoidHigt
            // 
            this.TbxFConoidHigt.Location = new System.Drawing.Point(11, 109);
            this.TbxFConoidHigt.Name = "TbxFConoidHigt";
            this.TbxFConoidHigt.Size = new System.Drawing.Size(231, 21);
            this.TbxFConoidHigt.TabIndex = 3;
            this.TbxFConoidHigt.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // LblFConoidHgt
            // 
            this.LblFConoidHgt.AutoSize = true;
            this.LblFConoidHgt.Location = new System.Drawing.Point(11, 92);
            this.LblFConoidHgt.Name = "LblFConoidHgt";
            this.LblFConoidHgt.Size = new System.Drawing.Size(119, 14);
            this.LblFConoidHgt.TabIndex = 2;
            this.LblFConoidHgt.Text = "Высота конуса:";
            // 
            // TbxFConoidPlotn
            // 
            this.TbxFConoidPlotn.Location = new System.Drawing.Point(11, 167);
            this.TbxFConoidPlotn.Name = "TbxFConoidPlotn";
            this.TbxFConoidPlotn.Size = new System.Drawing.Size(231, 21);
            this.TbxFConoidPlotn.TabIndex = 5;
            this.TbxFConoidPlotn.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // LblFConoidPlotn
            // 
            this.LblFConoidPlotn.AutoSize = true;
            this.LblFConoidPlotn.Location = new System.Drawing.Point(8, 150);
            this.LblFConoidPlotn.Name = "LblFConoidPlotn";
            this.LblFConoidPlotn.Size = new System.Drawing.Size(167, 14);
            this.LblFConoidPlotn.TabIndex = 4;
            this.LblFConoidPlotn.Text = "Плотность материала:";
            // 
            // LblFConoidArea
            // 
            this.LblFConoidArea.AutoSize = true;
            this.LblFConoidArea.Font = new System.Drawing.Font("Lucida Console", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblFConoidArea.Location = new System.Drawing.Point(11, 36);
            this.LblFConoidArea.Name = "LblFConoidArea";
            this.LblFConoidArea.Size = new System.Drawing.Size(119, 14);
            this.LblFConoidArea.TabIndex = 0;
            this.LblFConoidArea.Text = "Площадь конуса";
            // 
            // LblFConoidVolum
            // 
            this.LblFConoidVolum.AutoSize = true;
            this.LblFConoidVolum.Font = new System.Drawing.Font("Lucida Console", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblFConoidVolum.Location = new System.Drawing.Point(11, 70);
            this.LblFConoidVolum.Name = "LblFConoidVolum";
            this.LblFConoidVolum.Size = new System.Drawing.Size(103, 14);
            this.LblFConoidVolum.TabIndex = 1;
            this.LblFConoidVolum.Text = "Объём конуса";
            // 
            // LblFConoidMassa
            // 
            this.LblFConoidMassa.AutoSize = true;
            this.LblFConoidMassa.Location = new System.Drawing.Point(11, 103);
            this.LblFConoidMassa.Name = "LblFConoidMassa";
            this.LblFConoidMassa.Size = new System.Drawing.Size(103, 14);
            this.LblFConoidMassa.TabIndex = 2;
            this.LblFConoidMassa.Text = "Масса конуса";
            // 
            // BtnFConoidResult
            // 
            this.BtnFConoidResult.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.BtnFConoidResult.Location = new System.Drawing.Point(345, 262);
            this.BtnFConoidResult.Name = "BtnFConoidResult";
            this.BtnFConoidResult.Size = new System.Drawing.Size(161, 50);
            this.BtnFConoidResult.TabIndex = 3;
            this.BtnFConoidResult.Text = "Вычислить";
            this.BtnFConoidResult.UseVisualStyleBackColor = false;
            this.BtnFConoidResult.Click += new System.EventHandler(this.BtnFConoidResult_Click);
            // 
            // BtnFConoidExit
            // 
            this.BtnFConoidExit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.BtnFConoidExit.Location = new System.Drawing.Point(346, 353);
            this.BtnFConoidExit.Name = "BtnFConoidExit";
            this.BtnFConoidExit.Size = new System.Drawing.Size(161, 46);
            this.BtnFConoidExit.TabIndex = 4;
            this.BtnFConoidExit.Text = "Выход";
            this.BtnFConoidExit.UseVisualStyleBackColor = false;
            this.BtnFConoidExit.Click += new System.EventHandler(this.BtnFConoidExit_Click);
            // 
            // ChbFConoidVolume
            // 
            this.ChbFConoidVolume.AutoSize = true;
            this.ChbFConoidVolume.Location = new System.Drawing.Point(345, 130);
            this.ChbFConoidVolume.Name = "ChbFConoidVolume";
            this.ChbFConoidVolume.Size = new System.Drawing.Size(146, 18);
            this.ChbFConoidVolume.TabIndex = 5;
            this.ChbFConoidVolume.Text = "Расчитать объём";
            this.ChbFConoidVolume.UseVisualStyleBackColor = true;
            // 
            // ChbFConoidMassa
            // 
            this.ChbFConoidMassa.AutoSize = true;
            this.ChbFConoidMassa.Location = new System.Drawing.Point(345, 188);
            this.ChbFConoidMassa.Name = "ChbFConoidMassa";
            this.ChbFConoidMassa.Size = new System.Drawing.Size(154, 18);
            this.ChbFConoidMassa.TabIndex = 6;
            this.ChbFConoidMassa.Text = "Расчитать массу ";
            this.ChbFConoidMassa.UseVisualStyleBackColor = true;
            // 
            // FormConoid
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.SkyBlue;
            this.ClientSize = new System.Drawing.Size(534, 411);
            this.Controls.Add(this.ChbFConoidMassa);
            this.Controls.Add(this.ChbFConoidVolume);
            this.Controls.Add(this.BtnFConoidExit);
            this.Controls.Add(this.BtnFConoidResult);
            this.Controls.Add(this.ChbFConoidArea);
            this.Controls.Add(this.GrbFConoidResult);
            this.Controls.Add(this.GrbFConoidData);
            this.Font = new System.Drawing.Font("Lucida Console", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.MaximizeBox = false;
            this.Name = "FormConoid";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Расчёт усечённого конуса";
            this.GrbFConoidData.ResumeLayout(false);
            this.GrbFConoidData.PerformLayout();
            this.GrbFConoidResult.ResumeLayout(false);
            this.GrbFConoidResult.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox GrbFConoidData;
        private System.Windows.Forms.TextBox TbxFConoidPlotn;
        private System.Windows.Forms.Label LblFConoidPlotn;
        private System.Windows.Forms.TextBox TbxFConoidHigt;
        private System.Windows.Forms.Label LblFConoidHgt;
        private System.Windows.Forms.TextBox TbxFConoidRadius;
        private System.Windows.Forms.Label LbLFConoidRadius;
        private System.Windows.Forms.GroupBox GrbFConoidResult;
        private System.Windows.Forms.Label LblFConoidMassa;
        private System.Windows.Forms.Label LblFConoidVolum;
        private System.Windows.Forms.Label LblFConoidArea;
        private System.Windows.Forms.CheckBox ChbFConoidArea;
        private System.Windows.Forms.Button BtnFConoidResult;
        private System.Windows.Forms.Button BtnFConoidExit;
        private System.Windows.Forms.CheckBox ChbFConoidVolume;
        private System.Windows.Forms.CheckBox ChbFConoidMassa;
    }
}