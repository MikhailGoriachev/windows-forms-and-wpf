﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using ButtonsMenuForms.Models;

namespace ButtonsMenuForms.Views
{
    public partial class ConoidForm : Form
    {
        // модель для формы
        private Conoid _conoid;

        // конструктор формы
        public ConoidForm() {
            InitializeComponent();

            // создать модель для работы формы
            _conoid = new Conoid();

            // запомнить ссылки на ErrorProvider в поле Tag строк ввода
            TxbRadiusDown.Tag = ErpNumber1;
            TxbRadiusUp.Tag   = ErpNumber2;
            TxbHeight.Tag     = ErpNumber3;
            TxbDensity.Tag    = ErpNumber4;


            // начальное значение полей ввода TextBox
            TxbRadiusDown.Text = $"{_conoid.RadiusDown:f3}";
            TxbRadiusUp.Text   = $"{_conoid.RadiusUp:f3}";
            TxbHeight.Text     = $"{_conoid.Height:f3}";
            TxbDensity.Text    = $"{_conoid.Density:f3}";

            // начальное значение меток вывода результата
            LblAreaResult.Text = LblVolumeResult.Text = LblMassResult.Text = "---''---";
        } // ConoidForm


        // вычисление параметров конуса по заданию
        private void BtnCalc_Click(object sender, EventArgs e) {
            try {
                // проверка на уровне модели
                if (_conoid.RadiusDown <= _conoid.RadiusUp) 
                    throw new InvalidDataException($"Нижнее основание конуса меньше или равно верхнему");

                // получить текущие данные из полей ввода
                _conoid.RadiusDown = double.Parse(TxbRadiusDown.Text);
                _conoid.RadiusUp   = double.Parse(TxbRadiusUp.Text);
                _conoid.Height     = double.Parse(TxbHeight.Text);
                _conoid.Density    = double.Parse(TxbDensity.Text);

                // вычисление параметров, если это задано
                LblAreaResult.Text = ChbArea.Checked ? $"{_conoid.Area:n3}" : "Расчет не требуется";
                LblVolumeResult.Text = ChbVolume.Checked ? $"{_conoid.Volume:n3}" : "Расчет не требуется";
                LblMassResult.Text = ChbMass.Checked ? $"{_conoid.Mass:n3}" : "Расчет не требуется";

            } catch (Exception ex) {
                // обработка ошибки уровня модели 
                LblAreaResult.Text = LblVolumeResult.Text = LblMassResult.Text = "---''---";
                BtnCalc.Enabled = false;
                MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                
                // Передать фокус ввода на первое поле ввода
                TxbRadiusDown.Focus();
                TxbRadiusDown.SelectionLength = 0;
            } // try-catch
        } // BtnCalc_Click


        // при вводе данных очищаем элемент отображения ошибки
        // ссылка на элемент отображения ошибки должна быть записана в поле Tag
        // стоки ввода
        private void Txb_TextChanged(object sender, EventArgs e) {
            TextBox textBox = sender as TextBox;

            ErrorProvider errorProvider = (ErrorProvider) textBox.Tag;
            errorProvider.SetError(textBox, "");
            BtnCalc.Enabled = true;

            LblAreaResult.Text = LblVolumeResult.Text = LblMassResult.Text = "---''---";
        } // TxbDensity_TextChanged


        // проверяем, что в строку вводится вещественное число
        private void Txb_Validating(object sender, CancelEventArgs e) {
            TextBox textBox = sender as TextBox;
            ErrorProvider errorProvider = (ErrorProvider) textBox.Tag;

            bool result = double.TryParse(textBox.Text, out double temp);
            if (result) {
                if (temp <= 0)
                    errorProvider.SetError(textBox, "Отрицательное или нулевое значение не допустимо");
            } else {
                errorProvider.SetError(textBox, "Введено не число");
            }// if

            // очистка поля результатов при обнаружении ошибки
            if (errorProvider.GetError(textBox).Length > 0) {
                LblAreaResult.Text = LblVolumeResult.Text = LblMassResult.Text = "---''---";
                BtnCalc.Enabled = false;
            } // if
        } // Txb_Validating
    } // class ConoidForm
}
