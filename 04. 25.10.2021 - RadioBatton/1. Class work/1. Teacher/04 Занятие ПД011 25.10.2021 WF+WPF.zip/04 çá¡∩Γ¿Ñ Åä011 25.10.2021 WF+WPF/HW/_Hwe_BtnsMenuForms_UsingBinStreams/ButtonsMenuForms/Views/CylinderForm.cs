﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ButtonsMenuForms.Views
{
    public partial class CylinderForm : Form
    {
        public CylinderForm() {
            InitializeComponent();
        }

        // Предупреждение о незавершенности :)
        private void CylinderForm_Load(object sender, EventArgs e) {
            MessageBox.Show("Это не завершенная форма! Только для ознакомления!", "Предупреждение",
                MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
        } // CylinderForm_Load
    }
}
