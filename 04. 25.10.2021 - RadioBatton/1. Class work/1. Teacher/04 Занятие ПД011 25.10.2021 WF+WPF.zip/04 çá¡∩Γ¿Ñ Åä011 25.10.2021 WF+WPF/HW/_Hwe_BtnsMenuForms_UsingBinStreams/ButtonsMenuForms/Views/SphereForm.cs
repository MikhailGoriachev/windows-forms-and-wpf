﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using ButtonsMenuForms.Models;

namespace ButtonsMenuForms.Views
{
    public partial class SphereForm : Form
    {
        // модель  для работы 
        private Sphere _sphere;

        public SphereForm() {
            InitializeComponent();


            // создать модель для работы формы
            _sphere = new Sphere();

            // запомнить ссылки на ErrorProvider в поле Tag строк ввода
            TxbRadius.Tag = ErpNumber1;
            TxbDensity.Tag = ErpNumber2;

            // начальное значение полей ввода TextBox
            TxbRadius.Text = $"{_sphere.Radius:f3}";
            TxbDensity.Text = $"{_sphere.Density:f3}";

            // начальное значение меток вывода результата
            LblAreaResult.Text = LblVolumeResult.Text = LblMassResult.Text = "---''---";
        } // SphereForm


        // вычисление параметров сферы по заданию
        private void BtnCalc_Click(object sender, EventArgs e) {
            try {
                // получить текущие данные из полей ввода
                _sphere.Radius = double.Parse(TxbRadius.Text);
                _sphere.Density = double.Parse(TxbDensity.Text);

                // вычисление параметров, если это задано
                LblAreaResult.Text = ChbArea.Checked ? $"{_sphere.Area:n3}" : "Расчет не требуется";
                LblVolumeResult.Text = ChbVolume.Checked ? $"{_sphere.Volume:n3}" : "Расчет не требуется";
                LblMassResult.Text = ChbMass.Checked ? $"{_sphere.Mass:n3}" : "Расчет не требуется";

            } catch (Exception ex) {
                // обработка ошибки уровня модели 
                MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            } // try-catch
        } // BtnCalc_Click


        // при вводе данных очищаем элемент отображения ошибки
        // ссылка на элемент отображения ошибкти должна быть записана в поле Tag
        // стоки ввода
        private void Txb_TextChanged(object sender, EventArgs e) {
            TextBox textBox = sender as TextBox;
            ErrorProvider errorProvider = (ErrorProvider)textBox.Tag;
            errorProvider.SetError(textBox, "");
        } // TxbDensity_TextChanged


        // проверяем, что в строку вводится вещественное число
        private void Txb_Validating(object sender, CancelEventArgs e) {
            TextBox textBox = sender as TextBox;
            ErrorProvider errorProvider = (ErrorProvider)textBox.Tag;

            bool result = double.TryParse(textBox.Text, out double temp);
            if (result) {
                if (temp <= 0)
                    errorProvider.SetError(textBox, "Отрицательное или нулевое значение не допустимо");
            } else {
                errorProvider.SetError(textBox, "Введено не число");
            }// if
        } // Txb_Validating
    } // class SphereForm
}
