﻿namespace ButtonsMenuForms.Views
{
    partial class SphereForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SphereForm));
            this.ErpNumber2 = new System.Windows.Forms.ErrorProvider(this.components);
            this.ErpNumber1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.LblMassResult = new System.Windows.Forms.Label();
            this.LblMass = new System.Windows.Forms.Label();
            this.LblVolumeResult = new System.Windows.Forms.Label();
            this.LblVolume = new System.Windows.Forms.Label();
            this.LblAreaResult = new System.Windows.Forms.Label();
            this.LblArea = new System.Windows.Forms.Label();
            this.GrbResult = new System.Windows.Forms.GroupBox();
            this.ChbMass = new System.Windows.Forms.CheckBox();
            this.ChbVolume = new System.Windows.Forms.CheckBox();
            this.ChbArea = new System.Windows.Forms.CheckBox();
            this.TxbDensity = new System.Windows.Forms.TextBox();
            this.LblDensity = new System.Windows.Forms.Label();
            this.TxbRadius = new System.Windows.Forms.TextBox();
            this.LblRadiusDown = new System.Windows.Forms.Label();
            this.GrbCalcParams = new System.Windows.Forms.GroupBox();
            this.GrbFigureData = new System.Windows.Forms.GroupBox();
            this.BtnClose = new System.Windows.Forms.Button();
            this.BtnCalc = new System.Windows.Forms.Button();
            this.PcbFigure = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.ErpNumber2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ErpNumber1)).BeginInit();
            this.GrbResult.SuspendLayout();
            this.GrbCalcParams.SuspendLayout();
            this.GrbFigureData.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PcbFigure)).BeginInit();
            this.SuspendLayout();
            // 
            // ErpNumber2
            // 
            this.ErpNumber2.ContainerControl = this;
            // 
            // ErpNumber1
            // 
            this.ErpNumber1.ContainerControl = this;
            // 
            // LblMassResult
            // 
            this.LblMassResult.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblMassResult.Location = new System.Drawing.Point(144, 96);
            this.LblMassResult.Name = "LblMassResult";
            this.LblMassResult.Size = new System.Drawing.Size(240, 19);
            this.LblMassResult.TabIndex = 8;
            this.LblMassResult.Text = "Вычисленное значение параметра";
            // 
            // LblMass
            // 
            this.LblMass.AutoSize = true;
            this.LblMass.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblMass.Location = new System.Drawing.Point(16, 96);
            this.LblMass.Name = "LblMass";
            this.LblMass.Size = new System.Drawing.Size(57, 19);
            this.LblMass.TabIndex = 7;
            this.LblMass.Text = "Масса:";
            // 
            // LblVolumeResult
            // 
            this.LblVolumeResult.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblVolumeResult.Location = new System.Drawing.Point(144, 64);
            this.LblVolumeResult.Name = "LblVolumeResult";
            this.LblVolumeResult.Size = new System.Drawing.Size(240, 19);
            this.LblVolumeResult.TabIndex = 6;
            this.LblVolumeResult.Text = "Вычисленное значение параметра";
            // 
            // LblVolume
            // 
            this.LblVolume.AutoSize = true;
            this.LblVolume.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblVolume.Location = new System.Drawing.Point(16, 64);
            this.LblVolume.Name = "LblVolume";
            this.LblVolume.Size = new System.Drawing.Size(63, 19);
            this.LblVolume.TabIndex = 5;
            this.LblVolume.Text = "Объем:";
            // 
            // LblAreaResult
            // 
            this.LblAreaResult.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblAreaResult.Location = new System.Drawing.Point(144, 32);
            this.LblAreaResult.Name = "LblAreaResult";
            this.LblAreaResult.Size = new System.Drawing.Size(240, 19);
            this.LblAreaResult.TabIndex = 4;
            this.LblAreaResult.Text = "Вычисленное значение параметра";
            // 
            // LblArea
            // 
            this.LblArea.AutoSize = true;
            this.LblArea.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblArea.Location = new System.Drawing.Point(16, 32);
            this.LblArea.Name = "LblArea";
            this.LblArea.Size = new System.Drawing.Size(82, 19);
            this.LblArea.TabIndex = 3;
            this.LblArea.Text = "Площадь:";
            // 
            // GrbResult
            // 
            this.GrbResult.Controls.Add(this.LblMassResult);
            this.GrbResult.Controls.Add(this.LblMass);
            this.GrbResult.Controls.Add(this.LblVolumeResult);
            this.GrbResult.Controls.Add(this.LblVolume);
            this.GrbResult.Controls.Add(this.LblAreaResult);
            this.GrbResult.Controls.Add(this.LblArea);
            this.GrbResult.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.GrbResult.Location = new System.Drawing.Point(286, 250);
            this.GrbResult.Name = "GrbResult";
            this.GrbResult.Size = new System.Drawing.Size(408, 136);
            this.GrbResult.TabIndex = 14;
            this.GrbResult.TabStop = false;
            this.GrbResult.Text = "  Результаты расчета сферы: ";
            // 
            // ChbMass
            // 
            this.ChbMass.AutoSize = true;
            this.ChbMass.Location = new System.Drawing.Point(24, 96);
            this.ChbMass.Name = "ChbMass";
            this.ChbMass.Size = new System.Drawing.Size(101, 21);
            this.ChbMass.TabIndex = 5;
            this.ChbMass.Text = "Масса шара";
            this.ChbMass.UseVisualStyleBackColor = true;
            // 
            // ChbVolume
            // 
            this.ChbVolume.AutoSize = true;
            this.ChbVolume.Location = new System.Drawing.Point(24, 64);
            this.ChbVolume.Name = "ChbVolume";
            this.ChbVolume.Size = new System.Drawing.Size(115, 21);
            this.ChbVolume.TabIndex = 4;
            this.ChbVolume.Text = "Объем сферы";
            this.ChbVolume.UseVisualStyleBackColor = true;
            // 
            // ChbArea
            // 
            this.ChbArea.AutoSize = true;
            this.ChbArea.Location = new System.Drawing.Point(24, 32);
            this.ChbArea.Name = "ChbArea";
            this.ChbArea.Size = new System.Drawing.Size(174, 21);
            this.ChbArea.TabIndex = 3;
            this.ChbArea.Text = "Площадь поверхности";
            this.ChbArea.UseVisualStyleBackColor = true;
            // 
            // TxbDensity
            // 
            this.TxbDensity.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TxbDensity.Location = new System.Drawing.Point(242, 124);
            this.TxbDensity.Name = "TxbDensity";
            this.TxbDensity.Size = new System.Drawing.Size(152, 27);
            this.TxbDensity.TabIndex = 5;
            this.TxbDensity.Tag = "";
            this.TxbDensity.Text = "0";
            this.TxbDensity.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.TxbDensity.TextChanged += new System.EventHandler(this.Txb_TextChanged);
            this.TxbDensity.Validating += new System.ComponentModel.CancelEventHandler(this.Txb_Validating);
            // 
            // LblDensity
            // 
            this.LblDensity.AutoSize = true;
            this.LblDensity.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblDensity.Location = new System.Drawing.Point(16, 128);
            this.LblDensity.Name = "LblDensity";
            this.LblDensity.Size = new System.Drawing.Size(175, 19);
            this.LblDensity.TabIndex = 6;
            this.LblDensity.Text = "Плотность материала:";
            // 
            // TxbRadius
            // 
            this.TxbRadius.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TxbRadius.Location = new System.Drawing.Point(240, 60);
            this.TxbRadius.Name = "TxbRadius";
            this.TxbRadius.Size = new System.Drawing.Size(152, 27);
            this.TxbRadius.TabIndex = 0;
            this.TxbRadius.Tag = "";
            this.TxbRadius.Text = "0";
            this.TxbRadius.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.TxbRadius.TextChanged += new System.EventHandler(this.Txb_TextChanged);
            this.TxbRadius.Validating += new System.ComponentModel.CancelEventHandler(this.Txb_Validating);
            // 
            // LblRadiusDown
            // 
            this.LblRadiusDown.AutoSize = true;
            this.LblRadiusDown.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblRadiusDown.Location = new System.Drawing.Point(16, 64);
            this.LblRadiusDown.Name = "LblRadiusDown";
            this.LblRadiusDown.Size = new System.Drawing.Size(117, 19);
            this.LblRadiusDown.TabIndex = 0;
            this.LblRadiusDown.Text = "Радиус сферы:";
            // 
            // GrbCalcParams
            // 
            this.GrbCalcParams.Controls.Add(this.ChbMass);
            this.GrbCalcParams.Controls.Add(this.ChbVolume);
            this.GrbCalcParams.Controls.Add(this.ChbArea);
            this.GrbCalcParams.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.GrbCalcParams.Location = new System.Drawing.Point(30, 250);
            this.GrbCalcParams.Name = "GrbCalcParams";
            this.GrbCalcParams.Size = new System.Drawing.Size(240, 136);
            this.GrbCalcParams.TabIndex = 10;
            this.GrbCalcParams.TabStop = false;
            this.GrbCalcParams.Text = "  Что рассчитывать: ";
            // 
            // GrbFigureData
            // 
            this.GrbFigureData.Controls.Add(this.TxbDensity);
            this.GrbFigureData.Controls.Add(this.LblDensity);
            this.GrbFigureData.Controls.Add(this.TxbRadius);
            this.GrbFigureData.Controls.Add(this.LblRadiusDown);
            this.GrbFigureData.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.GrbFigureData.Location = new System.Drawing.Point(30, 26);
            this.GrbFigureData.Name = "GrbFigureData";
            this.GrbFigureData.Size = new System.Drawing.Size(408, 200);
            this.GrbFigureData.TabIndex = 9;
            this.GrbFigureData.TabStop = false;
            this.GrbFigureData.Text = " Параметры сферы ";
            // 
            // BtnClose
            // 
            this.BtnClose.BackColor = System.Drawing.Color.MidnightBlue;
            this.BtnClose.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.BtnClose.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.BtnClose.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BtnClose.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.BtnClose.Location = new System.Drawing.Point(462, 426);
            this.BtnClose.Name = "BtnClose";
            this.BtnClose.Size = new System.Drawing.Size(232, 40);
            this.BtnClose.TabIndex = 13;
            this.BtnClose.Text = "Закрыть";
            this.BtnClose.UseVisualStyleBackColor = true;
            // 
            // BtnCalc
            // 
            this.BtnCalc.BackColor = System.Drawing.Color.MidnightBlue;
            this.BtnCalc.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.BtnCalc.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BtnCalc.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.BtnCalc.Location = new System.Drawing.Point(214, 426);
            this.BtnCalc.Name = "BtnCalc";
            this.BtnCalc.Size = new System.Drawing.Size(232, 40);
            this.BtnCalc.TabIndex = 11;
            this.BtnCalc.Text = "Вычислить";
            this.BtnCalc.UseVisualStyleBackColor = true;
            this.BtnCalc.Click += new System.EventHandler(this.BtnCalc_Click);
            // 
            // PcbFigure
            // 
            this.PcbFigure.Image = global::ButtonsMenuForms.Properties.Resources.sphere;
            this.PcbFigure.Location = new System.Drawing.Point(470, 26);
            this.PcbFigure.Name = "PcbFigure";
            this.PcbFigure.Size = new System.Drawing.Size(224, 200);
            this.PcbFigure.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.PcbFigure.TabIndex = 12;
            this.PcbFigure.TabStop = false;
            // 
            // SphereForm
            // 
            this.AcceptButton = this.BtnClose;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(725, 493);
            this.Controls.Add(this.PcbFigure);
            this.Controls.Add(this.GrbResult);
            this.Controls.Add(this.GrbCalcParams);
            this.Controls.Add(this.GrbFigureData);
            this.Controls.Add(this.BtnClose);
            this.Controls.Add(this.BtnCalc);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(741, 532);
            this.MinimizeBox = false;
            this.MinimumSize = new System.Drawing.Size(741, 532);
            this.Name = "SphereForm";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Вычисление параметров сферы";
            ((System.ComponentModel.ISupportInitialize)(this.ErpNumber2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ErpNumber1)).EndInit();
            this.GrbResult.ResumeLayout(false);
            this.GrbResult.PerformLayout();
            this.GrbCalcParams.ResumeLayout(false);
            this.GrbCalcParams.PerformLayout();
            this.GrbFigureData.ResumeLayout(false);
            this.GrbFigureData.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PcbFigure)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox PcbFigure;
        private System.Windows.Forms.GroupBox GrbResult;
        private System.Windows.Forms.Label LblMassResult;
        private System.Windows.Forms.Label LblMass;
        private System.Windows.Forms.Label LblVolumeResult;
        private System.Windows.Forms.Label LblVolume;
        private System.Windows.Forms.Label LblAreaResult;
        private System.Windows.Forms.Label LblArea;
        private System.Windows.Forms.GroupBox GrbCalcParams;
        private System.Windows.Forms.CheckBox ChbMass;
        private System.Windows.Forms.CheckBox ChbVolume;
        private System.Windows.Forms.CheckBox ChbArea;
        private System.Windows.Forms.GroupBox GrbFigureData;
        private System.Windows.Forms.TextBox TxbDensity;
        private System.Windows.Forms.Label LblDensity;
        private System.Windows.Forms.TextBox TxbRadius;
        private System.Windows.Forms.Label LblRadiusDown;
        private System.Windows.Forms.Button BtnClose;
        private System.Windows.Forms.Button BtnCalc;
        private System.Windows.Forms.ErrorProvider ErpNumber2;
        private System.Windows.Forms.ErrorProvider ErpNumber1;
    }
}