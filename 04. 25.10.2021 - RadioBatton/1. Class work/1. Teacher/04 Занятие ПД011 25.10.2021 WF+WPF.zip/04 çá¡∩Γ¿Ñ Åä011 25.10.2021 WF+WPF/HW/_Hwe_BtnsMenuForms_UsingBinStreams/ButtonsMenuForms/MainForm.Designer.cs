﻿namespace ButtonsMenuForms
{
    partial class MainForm
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent() {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.LblTop = new System.Windows.Forms.Label();
            this.LblBottom = new System.Windows.Forms.Label();
            this.GrbFiguresBtnMenu = new System.Windows.Forms.GroupBox();
            this.BtnParallelepiped = new System.Windows.Forms.Button();
            this.BtnCylinder = new System.Windows.Forms.Button();
            this.BtnSphere = new System.Windows.Forms.Button();
            this.BtnConoid = new System.Windows.Forms.Button();
            this.GrbControlPanel = new System.Windows.Forms.GroupBox();
            this.BtnQuit = new System.Windows.Forms.Button();
            this.BtnAbout = new System.Windows.Forms.Button();
            this.GrbFiguresBtnMenu.SuspendLayout();
            this.GrbControlPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // LblTop
            // 
            this.LblTop.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.LblTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.LblTop.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblTop.ForeColor = System.Drawing.Color.Snow;
            this.LblTop.Location = new System.Drawing.Point(0, 0);
            this.LblTop.Name = "LblTop";
            this.LblTop.Size = new System.Drawing.Size(353, 24);
            this.LblTop.TabIndex = 1;
            this.LblTop.Text = "Кнопочное меню, формы";
            this.LblTop.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // LblBottom
            // 
            this.LblBottom.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.LblBottom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.LblBottom.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblBottom.ForeColor = System.Drawing.Color.Snow;
            this.LblBottom.Location = new System.Drawing.Point(0, 478);
            this.LblBottom.Name = "LblBottom";
            this.LblBottom.Size = new System.Drawing.Size(353, 34);
            this.LblBottom.TabIndex = 2;
            this.LblBottom.Text = "ПД011, Донецк, 2021";
            this.LblBottom.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // GrbFiguresBtnMenu
            // 
            this.GrbFiguresBtnMenu.Controls.Add(this.BtnParallelepiped);
            this.GrbFiguresBtnMenu.Controls.Add(this.BtnCylinder);
            this.GrbFiguresBtnMenu.Controls.Add(this.BtnSphere);
            this.GrbFiguresBtnMenu.Controls.Add(this.BtnConoid);
            this.GrbFiguresBtnMenu.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.GrbFiguresBtnMenu.Location = new System.Drawing.Point(32, 40);
            this.GrbFiguresBtnMenu.Name = "GrbFiguresBtnMenu";
            this.GrbFiguresBtnMenu.Size = new System.Drawing.Size(296, 256);
            this.GrbFiguresBtnMenu.TabIndex = 3;
            this.GrbFiguresBtnMenu.TabStop = false;
            this.GrbFiguresBtnMenu.Text = " Расчет фигур: ";
            // 
            // BtnParallelepiped
            // 
            this.BtnParallelepiped.BackColor = System.Drawing.Color.MidnightBlue;
            this.BtnParallelepiped.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.BtnParallelepiped.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BtnParallelepiped.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.BtnParallelepiped.Location = new System.Drawing.Point(24, 200);
            this.BtnParallelepiped.Name = "BtnParallelepiped";
            this.BtnParallelepiped.Size = new System.Drawing.Size(232, 40);
            this.BtnParallelepiped.TabIndex = 3;
            this.BtnParallelepiped.Text = "Параллелепипед";
            this.BtnParallelepiped.UseVisualStyleBackColor = true;
            // 
            // BtnCylinder
            // 
            this.BtnCylinder.BackColor = System.Drawing.Color.MidnightBlue;
            this.BtnCylinder.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.BtnCylinder.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BtnCylinder.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.BtnCylinder.Location = new System.Drawing.Point(24, 144);
            this.BtnCylinder.Name = "BtnCylinder";
            this.BtnCylinder.Size = new System.Drawing.Size(232, 40);
            this.BtnCylinder.TabIndex = 2;
            this.BtnCylinder.Text = "Цилиндр";
            this.BtnCylinder.UseVisualStyleBackColor = true;
            this.BtnCylinder.Click += new System.EventHandler(this.BtnCylinder_Click);
            // 
            // BtnSphere
            // 
            this.BtnSphere.BackColor = System.Drawing.Color.MidnightBlue;
            this.BtnSphere.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.BtnSphere.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BtnSphere.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.BtnSphere.Location = new System.Drawing.Point(24, 88);
            this.BtnSphere.Name = "BtnSphere";
            this.BtnSphere.Size = new System.Drawing.Size(232, 40);
            this.BtnSphere.TabIndex = 1;
            this.BtnSphere.Text = "Сфера";
            this.BtnSphere.UseVisualStyleBackColor = true;
            this.BtnSphere.Click += new System.EventHandler(this.BtnSphere_Click);
            // 
            // BtnConoid
            // 
            this.BtnConoid.BackColor = System.Drawing.Color.MidnightBlue;
            this.BtnConoid.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.BtnConoid.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BtnConoid.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.BtnConoid.Location = new System.Drawing.Point(24, 32);
            this.BtnConoid.Name = "BtnConoid";
            this.BtnConoid.Size = new System.Drawing.Size(232, 40);
            this.BtnConoid.TabIndex = 0;
            this.BtnConoid.Text = "Усеченный конус";
            this.BtnConoid.UseVisualStyleBackColor = true;
            this.BtnConoid.Click += new System.EventHandler(this.BtnConiod_Click);
            // 
            // GrbControlPanel
            // 
            this.GrbControlPanel.Controls.Add(this.BtnQuit);
            this.GrbControlPanel.Controls.Add(this.BtnAbout);
            this.GrbControlPanel.Location = new System.Drawing.Point(24, 320);
            this.GrbControlPanel.Name = "GrbControlPanel";
            this.GrbControlPanel.Size = new System.Drawing.Size(296, 136);
            this.GrbControlPanel.TabIndex = 4;
            this.GrbControlPanel.TabStop = false;
            // 
            // BtnQuit
            // 
            this.BtnQuit.BackColor = System.Drawing.Color.DarkMagenta;
            this.BtnQuit.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.BtnQuit.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BtnQuit.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.BtnQuit.Location = new System.Drawing.Point(32, 80);
            this.BtnQuit.Name = "BtnQuit";
            this.BtnQuit.Size = new System.Drawing.Size(232, 40);
            this.BtnQuit.TabIndex = 2;
            this.BtnQuit.Text = "Выход";
            this.BtnQuit.UseVisualStyleBackColor = false;
            this.BtnQuit.Click += new System.EventHandler(this.BtnQuit_Click);
            // 
            // BtnAbout
            // 
            this.BtnAbout.BackColor = System.Drawing.Color.MidnightBlue;
            this.BtnAbout.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.BtnAbout.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BtnAbout.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.BtnAbout.Location = new System.Drawing.Point(32, 24);
            this.BtnAbout.Name = "BtnAbout";
            this.BtnAbout.Size = new System.Drawing.Size(232, 40);
            this.BtnAbout.TabIndex = 1;
            this.BtnAbout.Text = "О программе";
            this.BtnAbout.UseVisualStyleBackColor = true;
            this.BtnAbout.Click += new System.EventHandler(this.BtnAbout_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(353, 512);
            this.Controls.Add(this.GrbControlPanel);
            this.Controls.Add(this.GrbFiguresBtnMenu);
            this.Controls.Add(this.LblBottom);
            this.Controls.Add(this.LblTop);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Задание на 25.10.2021 - кнопочное меню, дополнительные формы в приложении";
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.GrbFiguresBtnMenu.ResumeLayout(false);
            this.GrbControlPanel.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label LblTop;
        private System.Windows.Forms.Label LblBottom;
        private System.Windows.Forms.GroupBox GrbFiguresBtnMenu;
        private System.Windows.Forms.Button BtnConoid;
        private System.Windows.Forms.GroupBox GrbControlPanel;
        private System.Windows.Forms.Button BtnQuit;
        private System.Windows.Forms.Button BtnAbout;
        private System.Windows.Forms.Button BtnParallelepiped;
        private System.Windows.Forms.Button BtnCylinder;
        private System.Windows.Forms.Button BtnSphere;
    }
}

