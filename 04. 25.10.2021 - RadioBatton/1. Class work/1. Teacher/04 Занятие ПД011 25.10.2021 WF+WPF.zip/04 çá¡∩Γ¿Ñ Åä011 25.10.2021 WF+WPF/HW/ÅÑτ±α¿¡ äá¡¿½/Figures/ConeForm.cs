﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Figures
{
    public partial class ConeForm : Form
    {
        Cone cone = new Cone();
        public ConeForm()
        {
            InitializeComponent();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {
            
        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Radius_TextBox(object sender, EventArgs e)
        {
            TextBox box = (TextBox)sender;
            try
            {
                cone.Radius = double.Parse(box.Text);
                GeneralErrors.SetError(box, null);
            }
            catch(Exception)
            {
                GeneralErrors.SetError(box, "ВВедено не число !");
                
            }
            
            
        }


        private void Radius2_TextChanged(object sender, EventArgs e)
        {
            TextBox box = (TextBox)sender;
            try
            {
                cone.Radius2 = double.Parse(box.Text);
                GeneralErrors.SetError(box, null);
            }
            catch (Exception)
            {
                GeneralErrors.SetError(box, "ВВедено не число !");

            }
        }

        private void Height_TextChanged(object sender, EventArgs e)
        {
            TextBox box = (TextBox)sender;
            try
            {
                cone.Height = double.Parse(box.Text);
                GeneralErrors.SetError(box, null);
            }
            catch(Exception)
            {
                GeneralErrors.SetError(box, "ВВедено не число !");
                
            }
        }

        private void Generatrix_TextChanged(object sender, EventArgs e)
        {
            TextBox box = (TextBox)sender;
            try
            {
                cone.Generatrix = double.Parse(box.Text);
                GeneralErrors.SetError(box, null);
            }
            catch (Exception)
            {
                GeneralErrors.SetError(box, "ВВедено не число !");

            }

        }

        private void Density_TextChanged(object sender, EventArgs e)
        {
            TextBox box = (TextBox)sender;
            try
            {
                cone.Density = double.Parse(box.Text);
                GeneralErrors.SetError(box, null);
            }
            catch (Exception)
            {
                GeneralErrors.SetError(box, "ВВедено не число !");

            }

        }

        private void Area_Result(object sender, EventArgs e)
        {
            
            
        }

        private void Calculate_Click(object sender, EventArgs e)
        {
            if(Area.Checked)
            {
                Area_Textbox.Text = cone.CalcArea().ToString();
            }

            if(Volume.Checked)
            {
                Volume_textBox.Text = cone.CalcVoulume().ToString();
            }

            if(Mass.Checked)
            {
                Mass_TextBox.Text = cone.CalcMass().ToString();
            }
        }
    }
}
