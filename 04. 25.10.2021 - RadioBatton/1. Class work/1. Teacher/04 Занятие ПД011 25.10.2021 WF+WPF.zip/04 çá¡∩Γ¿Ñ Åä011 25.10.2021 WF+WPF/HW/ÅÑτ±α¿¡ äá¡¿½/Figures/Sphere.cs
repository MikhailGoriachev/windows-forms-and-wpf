﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Figures
{
    //Класс сферы, для расчетов по заданию 
    class Sphere
    {
        private double _radius;

        public double Radius
        {
            get => _radius;
            set => _radius = value <= 0d ? 1d : value;
        }

        private double _density;

        public double Density
        {
            get => _density;
            set => _density = value <= 0d ? 1d : value;

        }

        public Sphere() { }

        public Sphere(double r, double d)
        {
            Radius = r;
            Density = d;
        }

        // методы для расчета парметров сферы

        //площадь 
        public double CalcArea() => 4 * Math.PI * _radius * _radius;

        //объем
        public double CalcVolume() => 4 / 3 * Math.PI * Math.Pow(_radius, 3);

        //масса
        public double CalcMass() => _density * CalcVolume(); 



    }
}
