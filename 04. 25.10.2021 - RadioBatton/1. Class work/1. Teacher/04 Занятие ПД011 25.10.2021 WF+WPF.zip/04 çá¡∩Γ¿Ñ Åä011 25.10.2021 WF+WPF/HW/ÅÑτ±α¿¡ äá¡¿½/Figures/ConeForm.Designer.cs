﻿
namespace Figures
{
    partial class ConeForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ConeForm));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.Radius2 = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.Radius1 = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.Mass_TextBox = new System.Windows.Forms.TextBox();
            this.Volume_textBox = new System.Windows.Forms.TextBox();
            this.Area_Textbox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.Calculate = new System.Windows.Forms.Button();
            this.GeneralErrors = new System.Windows.Forms.ErrorProvider(this.components);
            this.Area = new System.Windows.Forms.CheckBox();
            this.Volume = new System.Windows.Forms.CheckBox();
            this.Mass = new System.Windows.Forms.CheckBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.GeneralErrors)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.Radius2);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.textBox4);
            this.groupBox1.Controls.Add(this.textBox3);
            this.groupBox1.Controls.Add(this.textBox2);
            this.groupBox1.Controls.Add(this.Radius1);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Location = new System.Drawing.Point(68, 82);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(480, 240);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Исходные данные";
            // 
            // Radius2
            // 
            this.Radius2.Location = new System.Drawing.Point(184, 69);
            this.Radius2.Name = "Radius2";
            this.Radius2.Size = new System.Drawing.Size(215, 26);
            this.Radius2.TabIndex = 9;
            this.Radius2.TextChanged += new System.EventHandler(this.Radius2_TextChanged);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(42, 68);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(72, 20);
            this.label8.TabIndex = 8;
            this.label8.Text = "Радиус2\r\n";
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(184, 192);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(215, 26);
            this.textBox4.TabIndex = 7;
            this.textBox4.TextChanged += new System.EventHandler(this.Density_TextChanged);
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(184, 145);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(215, 26);
            this.textBox3.TabIndex = 6;
            this.textBox3.TextChanged += new System.EventHandler(this.Generatrix_TextChanged);
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(184, 104);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(215, 26);
            this.textBox2.TabIndex = 5;
            this.textBox2.TextChanged += new System.EventHandler(this.Height_TextChanged);
            // 
            // Radius1
            // 
            this.Radius1.Location = new System.Drawing.Point(184, 36);
            this.Radius1.Name = "Radius1";
            this.Radius1.Size = new System.Drawing.Size(215, 26);
            this.Radius1.TabIndex = 4;
            this.Radius1.TextChanged += new System.EventHandler(this.Radius_TextBox);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(42, 192);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(93, 20);
            this.label7.TabIndex = 3;
            this.label7.Text = "Плотность";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(42, 145);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(106, 20);
            this.label6.TabIndex = 2;
            this.label6.Text = "Образующая";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(42, 104);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(66, 20);
            this.label5.TabIndex = 1;
            this.label5.Text = "Высота";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(42, 36);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(72, 20);
            this.label4.TabIndex = 0;
            this.label4.Text = "Радиус1";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.Mass_TextBox);
            this.groupBox2.Controls.Add(this.Volume_textBox);
            this.groupBox2.Controls.Add(this.Area_Textbox);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Location = new System.Drawing.Point(80, 383);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(448, 182);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Результаты расчета";
            // 
            // Mass_TextBox
            // 
            this.Mass_TextBox.Location = new System.Drawing.Point(246, 135);
            this.Mass_TextBox.Name = "Mass_TextBox";
            this.Mass_TextBox.Size = new System.Drawing.Size(100, 26);
            this.Mass_TextBox.TabIndex = 5;
            // 
            // Volume_textBox
            // 
            this.Volume_textBox.Location = new System.Drawing.Point(246, 90);
            this.Volume_textBox.Name = "Volume_textBox";
            this.Volume_textBox.Size = new System.Drawing.Size(100, 26);
            this.Volume_textBox.TabIndex = 4;
            // 
            // Area_Textbox
            // 
            this.Area_Textbox.Location = new System.Drawing.Point(246, 46);
            this.Area_Textbox.Name = "Area_Textbox";
            this.Area_Textbox.Size = new System.Drawing.Size(100, 26);
            this.Area_Textbox.TabIndex = 3;
            this.Area_Textbox.TextAlignChanged += new System.EventHandler(this.Area_Result);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(26, 50);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(213, 23);
            this.label1.TabIndex = 0;
            this.label1.Text = "Площадь поверхности";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(26, 90);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(72, 23);
            this.label2.TabIndex = 1;
            this.label2.Text = "Объем";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.Location = new System.Drawing.Point(26, 135);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(66, 23);
            this.label3.TabIndex = 2;
            this.label3.Text = "Масса";
            // 
            // Calculate
            // 
            this.Calculate.Location = new System.Drawing.Point(782, 517);
            this.Calculate.Name = "Calculate";
            this.Calculate.Size = new System.Drawing.Size(136, 48);
            this.Calculate.TabIndex = 2;
            this.Calculate.Text = "Вычислить\r\n";
            this.Calculate.UseVisualStyleBackColor = true;
            this.Calculate.Click += new System.EventHandler(this.Calculate_Click);
            // 
            // GeneralErrors
            // 
            this.GeneralErrors.ContainerControl = this;
            // 
            // Area
            // 
            this.Area.AutoSize = true;
            this.Area.Location = new System.Drawing.Point(723, 119);
            this.Area.Name = "Area";
            this.Area.Size = new System.Drawing.Size(163, 24);
            this.Area.TabIndex = 3;
            this.Area.Text = "Расчет площади";
            this.Area.UseVisualStyleBackColor = true;
            // 
            // Volume
            // 
            this.Volume.AutoSize = true;
            this.Volume.Location = new System.Drawing.Point(723, 165);
            this.Volume.Name = "Volume";
            this.Volume.Size = new System.Drawing.Size(151, 24);
            this.Volume.TabIndex = 4;
            this.Volume.Text = "Расчет объема";
            this.Volume.UseVisualStyleBackColor = true;
            // 
            // Mass
            // 
            this.Mass.AutoSize = true;
            this.Mass.Location = new System.Drawing.Point(723, 209);
            this.Mass.Name = "Mass";
            this.Mass.Size = new System.Drawing.Size(140, 24);
            this.Mass.TabIndex = 5;
            this.Mass.Text = "Расчет массы";
            this.Mass.UseVisualStyleBackColor = true;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Figures.Properties.Resources.cone;
            this.pictureBox1.Location = new System.Drawing.Point(723, 317);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(214, 194);
            this.pictureBox1.TabIndex = 6;
            this.pictureBox1.TabStop = false;
            // 
            // ConeForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(1109, 643);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.Mass);
            this.Controls.Add(this.Volume);
            this.Controls.Add(this.Area);
            this.Controls.Add(this.Calculate);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "ConeForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Расчет параметров конуса";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.GeneralErrors)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox Radius1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox Mass_TextBox;
        private System.Windows.Forms.TextBox Volume_textBox;
        private System.Windows.Forms.TextBox Area_Textbox;
        private System.Windows.Forms.Button Calculate;
        private System.Windows.Forms.TextBox Radius2;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ErrorProvider GeneralErrors;
        private System.Windows.Forms.CheckBox Mass;
        private System.Windows.Forms.CheckBox Volume;
        private System.Windows.Forms.CheckBox Area;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}

