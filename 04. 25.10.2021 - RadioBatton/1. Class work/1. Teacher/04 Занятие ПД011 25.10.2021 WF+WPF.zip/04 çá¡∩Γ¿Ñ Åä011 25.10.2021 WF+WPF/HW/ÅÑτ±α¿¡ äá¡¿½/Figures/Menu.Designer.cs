﻿
namespace Figures
{
    partial class Menu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Menu));
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(239, 33);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(270, 59);
            this.button1.TabIndex = 0;
            this.button1.Text = "Параллелипипед";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.Para_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(239, 135);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(270, 61);
            this.button2.TabIndex = 1;
            this.button2.Text = "Усеченый конус";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.Cone_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(239, 244);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(270, 52);
            this.button3.TabIndex = 2;
            this.button3.Text = "Сфера";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.Sphere_Click);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(239, 336);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(270, 52);
            this.button4.TabIndex = 3;
            this.button4.Text = "Цилиндер";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.Cylinder_Click);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(601, 336);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(166, 52);
            this.button5.TabIndex = 4;
            this.button5.Text = "О программе";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.About_Click);
            // 
            // Menu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Menu";
            this.Text = "Menu";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
    }
}