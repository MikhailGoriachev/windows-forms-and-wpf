﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Figures
{
    public partial class ParallelepipedForm : Form
    {
        Parallelepiped para = new Parallelepiped();
        public ParallelepipedForm()
        {
            InitializeComponent();
        }

        

        private void Density_TextChanged(object sender, EventArgs e)
        {
            TextBox box = (TextBox)sender; 
            try 
            {
                para.Density = double.Parse(box.Text);
                GeneralErrors.SetError(box, null);
            }
            catch(Exception)
            {
                GeneralErrors.SetError(box, "Не число");
            }
        }

        private void SideA_TextChanged(object sender, EventArgs e)
        {
            TextBox box = (TextBox)sender;

            try
            {
                para.A = double.Parse(box.Text);
                GeneralErrors.SetError(box, null);
            }
            catch(Exception)
            {
                GeneralErrors.SetError(box, "Не число !");
            }
        }

        private void SideB_TextChanged(object sender, EventArgs e)
        {
            TextBox box = (TextBox)sender;

            try
            {
                para.B = double.Parse(box.Text);
                GeneralErrors.SetError(box, null);
            }
            catch(Exception)
            {
                GeneralErrors.SetError(box, "Не число! ");
            }
        }

        private void SideC_TextChanged(object sender, EventArgs e)
        {
            TextBox box = (TextBox)sender;
            try
            {
                para.C = double.Parse(box.Text);
                GeneralErrors.SetError(box, null);
            }
            catch(Exception)
            {
                GeneralErrors.SetError(box, "Не число!");
            }
        }

        private void Calculate_Click(object sender, EventArgs e)
        {
            if(Area.Checked)
            {
                Area_textBox.Text = para.CalcArea().ToString();
            }

            if(Volume.Checked)
            {
                Volume_textBox.Text = para.CalcVolume().ToString();
            }

            if(Mass.Checked)
            {
                Mass_textBox.Text = para.CalcMass().ToString();
            }
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {

        }
    }
}
