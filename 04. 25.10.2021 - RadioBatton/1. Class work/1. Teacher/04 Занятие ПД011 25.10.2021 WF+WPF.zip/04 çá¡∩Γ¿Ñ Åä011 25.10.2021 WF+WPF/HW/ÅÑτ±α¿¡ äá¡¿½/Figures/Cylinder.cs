﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Figures
{
    //Класс цилиндра для расчета по заданию
    class Cylinder
    {
        private double _radius; 

        public double Radius
        {
            get => _radius;
            set => _radius = value <= 0d ? 1d : value;
        }

        private double _height;
        
        public double Height
        {
            get => _height;
            set => _height = value <= 0d ? 1d : value;
        }

        private double _density;

        public double Density
        {
            get => _density;
            set => _density = value <= 0d ? 1d : value;
        }

        public Cylinder() { }

        public Cylinder(double r, double h, double d)
        {
            Radius = r;
            Height = h;
            Density = d; 
        }

        // методы для расчета параметров цилиндра 

        // площадь
        public double CalcArea() => 2 * Math.PI * _radius * _height;

        // объем 
        public double CalcVolume() => Math.PI * _radius * _radius * _height;

        // масса 
        public double CalcMass() => _density * CalcVolume(); 
    }
}
