﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Figures
{
    // Класс усеченных конусов, используемый для работы по заданию
    public class Cone
    {
        private double _radius1; // радиус нижнего основания 

        public double Radius 
        {
            get => _radius1;
            set => _radius1 = value <= 0d ? 1d : value;
        }

        private double _radius2; // радиус верхнего основания

        public double Radius2
        {
            get => _radius2;
            set => _radius2 = value <= 0d ? 1d : value;
        }

        private double _height;
        
        public double Height
        {
            get => _height;
            set => _height = value <= 0d ? 1d : value;
        }

        private double _density;
        
        public double Density
        {
            get => _density;
            set => _density = value <= 0d ? 1d : value;
        }

        public double _generatrix;

        public double Generatrix
        {
            get => _generatrix;
            set => _generatrix = value <= 0d ? 1d : value;
        }

        public Cone() { }

        public Cone(double r, double h, double l, double d)
        {
            Radius = r;
            Height = h;
            Generatrix = l;
            Density = d;
        }

        // Методы для обработки по заданию 

        // площадь поверхности 
        public double CalcArea() => Math.PI*(_radius1 * _radius1 + (_radius1 + _radius2) * _generatrix + _radius2 * _radius2);

        // объем 
        public double CalcVoulume() => 1d / 3d * Math.PI * (_radius1 * _radius1 + _radius1 * _radius2 + _radius2 * _radius2);

        // масса 
        public double CalcMass() =>_density* CalcVoulume();
        

        

            
    }
}
