﻿
namespace Figures
{
    partial class CylinderForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CylinderForm));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.Density_textBox = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.Height_textBox = new System.Windows.Forms.TextBox();
            this.Radius_textBox = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.Mass_textBox = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.Volume_textBox = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.Area_textBox = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.Area = new System.Windows.Forms.CheckBox();
            this.Volume = new System.Windows.Forms.CheckBox();
            this.Mass = new System.Windows.Forms.CheckBox();
            this.Calculate = new System.Windows.Forms.Button();
            this.GeneralErrors = new System.Windows.Forms.ErrorProvider(this.components);
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.GeneralErrors)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.Density_textBox);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.Height_textBox);
            this.groupBox1.Controls.Add(this.Radius_textBox);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(66, 60);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(412, 206);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Исходные данные";
            // 
            // Density_textBox
            // 
            this.Density_textBox.Location = new System.Drawing.Point(222, 146);
            this.Density_textBox.Name = "Density_textBox";
            this.Density_textBox.Size = new System.Drawing.Size(144, 26);
            this.Density_textBox.TabIndex = 5;
            this.Density_textBox.TextChanged += new System.EventHandler(this.Density_TextChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(24, 149);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(93, 20);
            this.label6.TabIndex = 4;
            this.label6.Text = "Плотность";
            // 
            // Height_textBox
            // 
            this.Height_textBox.Location = new System.Drawing.Point(222, 93);
            this.Height_textBox.Name = "Height_textBox";
            this.Height_textBox.Size = new System.Drawing.Size(144, 26);
            this.Height_textBox.TabIndex = 3;
            this.Height_textBox.TextChanged += new System.EventHandler(this.Height_TextChanged);
            // 
            // Radius_textBox
            // 
            this.Radius_textBox.Location = new System.Drawing.Point(222, 38);
            this.Radius_textBox.Name = "Radius_textBox";
            this.Radius_textBox.Size = new System.Drawing.Size(144, 26);
            this.Radius_textBox.TabIndex = 2;
            this.Radius_textBox.TextChanged += new System.EventHandler(this.Radius_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(20, 99);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(66, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "Высота";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(20, 38);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(63, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Радиус";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.Mass_textBox);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.Volume_textBox);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.Area_textBox);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Location = new System.Drawing.Point(66, 390);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(398, 213);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Результаты расчета";
            // 
            // Mass_textBox
            // 
            this.Mass_textBox.Location = new System.Drawing.Point(241, 166);
            this.Mass_textBox.Name = "Mass_textBox";
            this.Mass_textBox.Size = new System.Drawing.Size(135, 26);
            this.Mass_textBox.TabIndex = 5;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label5.Location = new System.Drawing.Point(33, 156);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(61, 20);
            this.label5.TabIndex = 4;
            this.label5.Text = "Масса";
            // 
            // Volume_textBox
            // 
            this.Volume_textBox.Location = new System.Drawing.Point(241, 111);
            this.Volume_textBox.Name = "Volume_textBox";
            this.Volume_textBox.Size = new System.Drawing.Size(135, 26);
            this.Volume_textBox.TabIndex = 3;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label4.Location = new System.Drawing.Point(28, 111);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(66, 20);
            this.label4.TabIndex = 2;
            this.label4.Text = "Объем\r\n";
            // 
            // Area_textBox
            // 
            this.Area_textBox.Location = new System.Drawing.Point(241, 49);
            this.Area_textBox.Name = "Area_textBox";
            this.Area_textBox.Size = new System.Drawing.Size(135, 26);
            this.Area_textBox.TabIndex = 1;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.Location = new System.Drawing.Point(24, 55);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(201, 20);
            this.label3.TabIndex = 0;
            this.label3.Text = "Площадь поверхности\r\n";
            // 
            // Area
            // 
            this.Area.AutoSize = true;
            this.Area.Location = new System.Drawing.Point(634, 93);
            this.Area.Name = "Area";
            this.Area.Size = new System.Drawing.Size(198, 24);
            this.Area.TabIndex = 2;
            this.Area.Text = "Рассчитать площадь";
            this.Area.UseVisualStyleBackColor = true;
            // 
            // Volume
            // 
            this.Volume.AutoSize = true;
            this.Volume.Location = new System.Drawing.Point(634, 145);
            this.Volume.Name = "Volume";
            this.Volume.Size = new System.Drawing.Size(177, 24);
            this.Volume.TabIndex = 3;
            this.Volume.Text = "Рассчитать объем";
            this.Volume.UseVisualStyleBackColor = true;
            // 
            // Mass
            // 
            this.Mass.AutoSize = true;
            this.Mass.Location = new System.Drawing.Point(634, 209);
            this.Mass.Name = "Mass";
            this.Mass.Size = new System.Drawing.Size(171, 24);
            this.Mass.TabIndex = 4;
            this.Mass.Text = "Рассчитать массу";
            this.Mass.UseVisualStyleBackColor = true;
            // 
            // Calculate
            // 
            this.Calculate.Location = new System.Drawing.Point(634, 525);
            this.Calculate.Name = "Calculate";
            this.Calculate.Size = new System.Drawing.Size(177, 57);
            this.Calculate.TabIndex = 5;
            this.Calculate.Text = "Вычислить";
            this.Calculate.UseVisualStyleBackColor = true;
            this.Calculate.Click += new System.EventHandler(this.Calculate_Click);
            // 
            // GeneralErrors
            // 
            this.GeneralErrors.ContainerControl = this;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Figures.Properties.Resources.cylinder;
            this.pictureBox1.Location = new System.Drawing.Point(606, 291);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(199, 216);
            this.pictureBox1.TabIndex = 6;
            this.pictureBox1.TabStop = false;
            // 
            // CylinderForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(957, 666);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.Calculate);
            this.Controls.Add(this.Mass);
            this.Controls.Add(this.Volume);
            this.Controls.Add(this.Area);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "CylinderForm";
            this.Text = "Расчет параметров цилиндра";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.GeneralErrors)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox Height_textBox;
        private System.Windows.Forms.TextBox Radius_textBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox Mass_textBox;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox Volume_textBox;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox Area_textBox;
        private System.Windows.Forms.CheckBox Area;
        private System.Windows.Forms.CheckBox Volume;
        private System.Windows.Forms.CheckBox Mass;
        private System.Windows.Forms.Button Calculate;
        private System.Windows.Forms.ErrorProvider GeneralErrors;
        private System.Windows.Forms.TextBox Density_textBox;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}