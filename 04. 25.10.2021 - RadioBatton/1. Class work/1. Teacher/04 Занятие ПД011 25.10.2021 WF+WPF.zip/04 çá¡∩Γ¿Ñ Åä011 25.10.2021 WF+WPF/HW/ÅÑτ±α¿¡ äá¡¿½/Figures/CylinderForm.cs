﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Figures
{
    public partial class CylinderForm : Form
    {
        Cylinder cylinder = new Cylinder();
        public CylinderForm()
        {
            InitializeComponent();
        }

        private void Radius_TextChanged(object sender, EventArgs e)
        {
            TextBox box = (TextBox)sender;
            try
            {
                cylinder.Radius = double.Parse(box.Text);
                GeneralErrors.SetError(box, null);
            }
            catch(Exception)
            {
                GeneralErrors.SetError(box, "Не число !");
            }
        }

        private void Height_TextChanged(object sender, EventArgs e)
        {
            TextBox box = (TextBox)sender; 
            try 
            {
                cylinder.Height = double.Parse(box.Text);
                GeneralErrors.SetError(box, null);
            }
            catch(Exception)
            {
                GeneralErrors.SetError(box, "Не число!"); 
            }
        }

        private void Calculate_Click(object sender, EventArgs e)
        {
            if(Area.Checked)
            {
                Area_textBox.Text = cylinder.CalcArea().ToString();
            }

            if(Volume.Checked)
            {
                Volume_textBox.Text = cylinder.CalcVolume().ToString();
            }

            if(Mass.Checked)
            {
                Mass_textBox.Text = cylinder.CalcMass().ToString();
            }
        }

        private void Density_TextChanged(object sender, EventArgs e)
        {
            TextBox box = (TextBox)sender;

            try
            {
                cylinder.Density = double.Parse(box.Text);
                GeneralErrors.SetError(box, null);
            }
            catch(Exception)
            {
                GeneralErrors.SetError(box, "Не число");
            }

        }
    }
}
