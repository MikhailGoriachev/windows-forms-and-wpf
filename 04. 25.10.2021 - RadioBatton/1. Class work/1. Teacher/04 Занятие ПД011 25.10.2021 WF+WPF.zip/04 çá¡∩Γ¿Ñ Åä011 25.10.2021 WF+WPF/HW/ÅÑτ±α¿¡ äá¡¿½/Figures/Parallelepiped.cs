﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Figures
{
    class Parallelepiped
    {
        // Класс параллелепипед для расчета по заданию

        private double _a;

        public double A
        {
            get => _a;
            set => _a = value <= 0d ? 1d : value; 
        }

        private double _b; 

        public double B
        {
            get => _b;
            set => _b = value <= 0d ? 1d : value; 
        }

        private double _c; 

        public double C
        {
            get => _c;
            set => _c = value <= 0d ? 1d : value; 
        }

        private double _density;

        public double Density
        {
            get => _density;
            set => _density = value <= 0d ? 1d : value;
        }


        //площадь
        public double CalcArea() => 2 * (_a * _b + _b * _c + _a * _c);

        //объем
        public double CalcVolume() => _a * _b * _c;

        //плотность
        public double CalcMass() => _density * CalcVolume(); 
        

        


    }
}
