﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Figures
{
    public partial class Menu : Form
    {
        public Menu()
        {
            InitializeComponent();
        }

        private void Para_Click(object sender, EventArgs e)
        {
            new ParallelepipedForm().ShowDialog();
        }

        private void Cone_Click(object sender, EventArgs e)
        {
            new ConeForm().ShowDialog();
        }

        private void Sphere_Click(object sender, EventArgs e)
        {
            new SphereForms().ShowDialog(); 
        }

        private void Cylinder_Click(object sender, EventArgs e)
        {
            new CylinderForm().ShowDialog();
        }

        private void About_Click(object sender, EventArgs e)
        {
            new About().ShowDialog();
        }
    }
}
