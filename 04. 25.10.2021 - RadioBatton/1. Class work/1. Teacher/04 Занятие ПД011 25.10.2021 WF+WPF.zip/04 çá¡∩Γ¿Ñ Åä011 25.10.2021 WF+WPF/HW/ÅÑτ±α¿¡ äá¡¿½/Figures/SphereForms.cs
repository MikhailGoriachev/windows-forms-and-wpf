﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Figures
{
    public partial class SphereForms : Form
    {
        Sphere sphere = new Sphere();
        public SphereForms()
        {
            InitializeComponent();
        }

        

        private void Radius_TextChanged(object sender, EventArgs e)
        {
            TextBox box = (TextBox)sender; 
            try 
            {
                sphere.Radius = double.Parse(box.Text);
                GeneralErrors.SetError(box, null);
            }
            catch(Exception)
            {
                GeneralErrors.SetError(box, "Не число !");
            }
            

            
        }

        private void Density_TextChanged(object sender, EventArgs e)
        {
            TextBox box = (TextBox)sender;

            try
            {
                sphere.Density = double.Parse(box.Text);
                GeneralErrors.SetError(box, null);
            }
            catch(Exception)
            {
                GeneralErrors.SetError(box, "Не число");
            }
        }

        private void Calculate_Click(object sender, EventArgs e)
        {
            if(Area.Checked)
            {
                Area_textBox.Text = sphere.CalcArea().ToString();
            }

            if(Volume.Checked)
            {
                Volune_textBox.Text = sphere.CalcVolume().ToString();
            }

            if(Mass.Checked)
            {
                Mass_textBox.Text = sphere.CalcMass().ToString();
            }
        }
    }
}
