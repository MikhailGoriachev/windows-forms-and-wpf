﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HW_WF{
    public partial class MainForm : Form{

        private AboutForm _aForm;
        private FiguresForm _fForm;

        public MainForm(){
            InitializeComponent();

        } // mainForm

        private void btnAbout_Click(object sender, EventArgs e){
            _aForm = new AboutForm();

            // Отобразить форму
            _aForm.Show();

            // вызываем таймер для закрытия формы
            tmrCloseAbout.Enabled = true;
        } // btnAbout_Click

        private void tmrCloseAbout_Tick(object sender, EventArgs e){
            // закрыть форму
            _aForm.Close();
        } // tmrCloseAbout_Tick

        private void btnFigures_Click(object sender, EventArgs e){
            _fForm = new FiguresForm();

            // Отобразить форму
            _fForm.Show();

        } // btnFigures_Click
    }
}
