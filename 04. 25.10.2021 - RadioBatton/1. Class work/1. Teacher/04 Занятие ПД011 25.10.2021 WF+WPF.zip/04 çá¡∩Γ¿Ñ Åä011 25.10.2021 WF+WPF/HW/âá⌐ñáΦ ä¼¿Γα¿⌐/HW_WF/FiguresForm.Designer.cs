﻿
namespace HW_WF
{
    partial class FiguresForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnCone = new System.Windows.Forms.Button();
            this.btnCylinder = new System.Windows.Forms.Button();
            this.btnSphere = new System.Windows.Forms.Button();
            this.btnRect = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnCone
            // 
            this.btnCone.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnCone.Location = new System.Drawing.Point(32, 28);
            this.btnCone.Name = "btnCone";
            this.btnCone.Size = new System.Drawing.Size(148, 66);
            this.btnCone.TabIndex = 1;
            this.btnCone.Text = "Конус";
            this.btnCone.UseVisualStyleBackColor = true;
            this.btnCone.Click += new System.EventHandler(this.btnCone_Click);
            // 
            // btnCylinder
            // 
            this.btnCylinder.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnCylinder.Location = new System.Drawing.Point(204, 28);
            this.btnCylinder.Name = "btnCylinder";
            this.btnCylinder.Size = new System.Drawing.Size(148, 66);
            this.btnCylinder.TabIndex = 2;
            this.btnCylinder.Text = "Цилиндр";
            this.btnCylinder.UseVisualStyleBackColor = true;
            this.btnCylinder.Click += new System.EventHandler(this.btnCylinder_Click);
            // 
            // btnSphere
            // 
            this.btnSphere.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnSphere.Location = new System.Drawing.Point(32, 117);
            this.btnSphere.Name = "btnSphere";
            this.btnSphere.Size = new System.Drawing.Size(148, 66);
            this.btnSphere.TabIndex = 3;
            this.btnSphere.Text = "Сфера";
            this.btnSphere.UseVisualStyleBackColor = true;
            this.btnSphere.Click += new System.EventHandler(this.btnSphere_Click);
            // 
            // btnRect
            // 
            this.btnRect.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnRect.Location = new System.Drawing.Point(204, 117);
            this.btnRect.Name = "btnRect";
            this.btnRect.Size = new System.Drawing.Size(148, 66);
            this.btnRect.TabIndex = 4;
            this.btnRect.Text = "Параллелепипед";
            this.btnRect.UseVisualStyleBackColor = true;
            this.btnRect.Click += new System.EventHandler(this.btnRect_Click);
            // 
            // FiguresForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Firebrick;
            this.ClientSize = new System.Drawing.Size(372, 214);
            this.Controls.Add(this.btnRect);
            this.Controls.Add(this.btnSphere);
            this.Controls.Add(this.btnCylinder);
            this.Controls.Add(this.btnCone);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "FiguresForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Фигуры";
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button btnCone;
        private System.Windows.Forms.Button btnCylinder;
        private System.Windows.Forms.Button btnSphere;
        private System.Windows.Forms.Button btnRect;
    }
}