﻿
namespace HW_WF
{
    partial class RectangularParallelepipedForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.cbxMass = new System.Windows.Forms.CheckBox();
            this.cbxVolume = new System.Windows.Forms.CheckBox();
            this.cbxArea = new System.Windows.Forms.CheckBox();
            this.grbResult = new System.Windows.Forms.GroupBox();
            this.lblMass = new System.Windows.Forms.Label();
            this.lblVolume = new System.Windows.Forms.Label();
            this.lblSurfaceArea = new System.Windows.Forms.Label();
            this.btnResult = new System.Windows.Forms.Button();
            this.grbData = new System.Windows.Forms.GroupBox();
            this.lblMaterial = new System.Windows.Forms.Label();
            this.tbxSideC = new System.Windows.Forms.TextBox();
            this.lblSideC = new System.Windows.Forms.Label();
            this.tbxSideB = new System.Windows.Forms.TextBox();
            this.lblSideB = new System.Windows.Forms.Label();
            this.tbxSideA = new System.Windows.Forms.TextBox();
            this.lblSideA = new System.Windows.Forms.Label();
            this.erpSideA = new System.Windows.Forms.ErrorProvider(this.components);
            this.erpSideB = new System.Windows.Forms.ErrorProvider(this.components);
            this.erpSideC = new System.Windows.Forms.ErrorProvider(this.components);
            this.pbxRect = new System.Windows.Forms.PictureBox();
            this.grbResult.SuspendLayout();
            this.grbData.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.erpSideA)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.erpSideB)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.erpSideC)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxRect)).BeginInit();
            this.SuspendLayout();
            // 
            // cbxMass
            // 
            this.cbxMass.AutoSize = true;
            this.cbxMass.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.cbxMass.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.cbxMass.Location = new System.Drawing.Point(36, 261);
            this.cbxMass.Name = "cbxMass";
            this.cbxMass.Size = new System.Drawing.Size(137, 24);
            this.cbxMass.TabIndex = 26;
            this.cbxMass.Text = "Расчитать массу?";
            this.cbxMass.UseVisualStyleBackColor = true;
            // 
            // cbxVolume
            // 
            this.cbxVolume.AutoSize = true;
            this.cbxVolume.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.cbxVolume.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.cbxVolume.Location = new System.Drawing.Point(36, 232);
            this.cbxVolume.Name = "cbxVolume";
            this.cbxVolume.Size = new System.Drawing.Size(141, 24);
            this.cbxVolume.TabIndex = 25;
            this.cbxVolume.Text = "Расчитать объем?";
            this.cbxVolume.UseVisualStyleBackColor = true;
            // 
            // cbxArea
            // 
            this.cbxArea.AutoSize = true;
            this.cbxArea.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.cbxArea.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.cbxArea.Location = new System.Drawing.Point(36, 203);
            this.cbxArea.Name = "cbxArea";
            this.cbxArea.Size = new System.Drawing.Size(156, 24);
            this.cbxArea.TabIndex = 24;
            this.cbxArea.Text = "Расчитать площадь?";
            this.cbxArea.UseVisualStyleBackColor = true;
            // 
            // grbResult
            // 
            this.grbResult.Controls.Add(this.lblMass);
            this.grbResult.Controls.Add(this.lblVolume);
            this.grbResult.Controls.Add(this.lblSurfaceArea);
            this.grbResult.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.grbResult.Location = new System.Drawing.Point(12, 313);
            this.grbResult.Name = "grbResult";
            this.grbResult.Size = new System.Drawing.Size(386, 161);
            this.grbResult.TabIndex = 22;
            this.grbResult.TabStop = false;
            this.grbResult.Text = "Результат";
            // 
            // lblMass
            // 
            this.lblMass.AutoSize = true;
            this.lblMass.ForeColor = System.Drawing.Color.Gold;
            this.lblMass.Location = new System.Drawing.Point(20, 94);
            this.lblMass.Name = "lblMass";
            this.lblMass.Size = new System.Drawing.Size(64, 20);
            this.lblMass.TabIndex = 17;
            this.lblMass.Text = "Масса = ";
            this.lblMass.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblVolume
            // 
            this.lblVolume.AutoSize = true;
            this.lblVolume.ForeColor = System.Drawing.Color.Gold;
            this.lblVolume.Location = new System.Drawing.Point(20, 66);
            this.lblVolume.Name = "lblVolume";
            this.lblVolume.Size = new System.Drawing.Size(64, 20);
            this.lblVolume.TabIndex = 16;
            this.lblVolume.Text = "Объем =";
            this.lblVolume.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblSurfaceArea
            // 
            this.lblSurfaceArea.AutoSize = true;
            this.lblSurfaceArea.ForeColor = System.Drawing.Color.Gold;
            this.lblSurfaceArea.Location = new System.Drawing.Point(20, 35);
            this.lblSurfaceArea.Name = "lblSurfaceArea";
            this.lblSurfaceArea.Size = new System.Drawing.Size(166, 20);
            this.lblSurfaceArea.TabIndex = 15;
            this.lblSurfaceArea.Text = "Площадь поверхности = ";
            this.lblSurfaceArea.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // btnResult
            // 
            this.btnResult.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnResult.Location = new System.Drawing.Point(237, 219);
            this.btnResult.Name = "btnResult";
            this.btnResult.Size = new System.Drawing.Size(136, 66);
            this.btnResult.TabIndex = 23;
            this.btnResult.Text = "Вычислить";
            this.btnResult.UseVisualStyleBackColor = true;
            this.btnResult.Click += new System.EventHandler(this.btnResult_Click);
            // 
            // grbData
            // 
            this.grbData.Controls.Add(this.lblMaterial);
            this.grbData.Controls.Add(this.tbxSideC);
            this.grbData.Controls.Add(this.lblSideC);
            this.grbData.Controls.Add(this.tbxSideB);
            this.grbData.Controls.Add(this.lblSideB);
            this.grbData.Controls.Add(this.tbxSideA);
            this.grbData.Controls.Add(this.lblSideA);
            this.grbData.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.grbData.Location = new System.Drawing.Point(12, 12);
            this.grbData.Name = "grbData";
            this.grbData.Size = new System.Drawing.Size(386, 161);
            this.grbData.TabIndex = 21;
            this.grbData.TabStop = false;
            this.grbData.Text = "Исходные данные";
            // 
            // lblMaterial
            // 
            this.lblMaterial.AutoSize = true;
            this.lblMaterial.ForeColor = System.Drawing.Color.Gold;
            this.lblMaterial.Location = new System.Drawing.Point(21, 127);
            this.lblMaterial.Name = "lblMaterial";
            this.lblMaterial.Size = new System.Drawing.Size(223, 20);
            this.lblMaterial.TabIndex = 15;
            this.lblMaterial.Text = "Материал - алюминий (для массы)";
            this.lblMaterial.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tbxSideC
            // 
            this.tbxSideC.Location = new System.Drawing.Point(261, 96);
            this.tbxSideC.Name = "tbxSideC";
            this.tbxSideC.Size = new System.Drawing.Size(100, 26);
            this.tbxSideC.TabIndex = 14;
            this.tbxSideC.Text = "1";
            this.tbxSideC.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lblSideC
            // 
            this.lblSideC.AutoSize = true;
            this.lblSideC.ForeColor = System.Drawing.Color.Gold;
            this.lblSideC.Location = new System.Drawing.Point(20, 97);
            this.lblSideC.Name = "lblSideC";
            this.lblSideC.Size = new System.Drawing.Size(72, 20);
            this.lblSideC.TabIndex = 13;
            this.lblSideC.Text = "Сторона c";
            this.lblSideC.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tbxSideB
            // 
            this.tbxSideB.Location = new System.Drawing.Point(261, 66);
            this.tbxSideB.Name = "tbxSideB";
            this.tbxSideB.Size = new System.Drawing.Size(100, 26);
            this.tbxSideB.TabIndex = 12;
            this.tbxSideB.Text = "1";
            this.tbxSideB.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lblSideB
            // 
            this.lblSideB.AutoSize = true;
            this.lblSideB.ForeColor = System.Drawing.Color.Gold;
            this.lblSideB.Location = new System.Drawing.Point(20, 66);
            this.lblSideB.Name = "lblSideB";
            this.lblSideB.Size = new System.Drawing.Size(73, 20);
            this.lblSideB.TabIndex = 11;
            this.lblSideB.Text = "Сторона b";
            this.lblSideB.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tbxSideA
            // 
            this.tbxSideA.Location = new System.Drawing.Point(261, 35);
            this.tbxSideA.Name = "tbxSideA";
            this.tbxSideA.Size = new System.Drawing.Size(100, 26);
            this.tbxSideA.TabIndex = 10;
            this.tbxSideA.Text = "1";
            this.tbxSideA.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lblSideA
            // 
            this.lblSideA.AutoSize = true;
            this.lblSideA.ForeColor = System.Drawing.Color.Gold;
            this.lblSideA.Location = new System.Drawing.Point(20, 37);
            this.lblSideA.Name = "lblSideA";
            this.lblSideA.Size = new System.Drawing.Size(72, 20);
            this.lblSideA.TabIndex = 9;
            this.lblSideA.Text = "Сторона а";
            this.lblSideA.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // erpSideA
            // 
            this.erpSideA.ContainerControl = this;
            // 
            // erpSideB
            // 
            this.erpSideB.ContainerControl = this;
            // 
            // erpSideC
            // 
            this.erpSideC.ContainerControl = this;
            // 
            // pbxRect
            // 
            this.pbxRect.Image = global::HW_WF.Properties.Resources.Rect;
            this.pbxRect.Location = new System.Drawing.Point(437, 47);
            this.pbxRect.Name = "pbxRect";
            this.pbxRect.Size = new System.Drawing.Size(228, 365);
            this.pbxRect.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbxRect.TabIndex = 27;
            this.pbxRect.TabStop = false;
            // 
            // RectangularParallelepipedForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Firebrick;
            this.ClientSize = new System.Drawing.Size(697, 450);
            this.Controls.Add(this.pbxRect);
            this.Controls.Add(this.cbxMass);
            this.Controls.Add(this.cbxVolume);
            this.Controls.Add(this.cbxArea);
            this.Controls.Add(this.grbResult);
            this.Controls.Add(this.btnResult);
            this.Controls.Add(this.grbData);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "RectangularParallelepipedForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "RectangularParallelepipedForm";
            this.grbResult.ResumeLayout(false);
            this.grbResult.PerformLayout();
            this.grbData.ResumeLayout(false);
            this.grbData.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.erpSideA)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.erpSideB)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.erpSideC)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxRect)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.CheckBox cbxMass;
        private System.Windows.Forms.CheckBox cbxVolume;
        private System.Windows.Forms.CheckBox cbxArea;
        private System.Windows.Forms.GroupBox grbResult;
        private System.Windows.Forms.Label lblMass;
        private System.Windows.Forms.Label lblVolume;
        private System.Windows.Forms.Label lblSurfaceArea;
        private System.Windows.Forms.Button btnResult;
        private System.Windows.Forms.GroupBox grbData;
        private System.Windows.Forms.Label lblMaterial;
        private System.Windows.Forms.TextBox tbxSideC;
        private System.Windows.Forms.Label lblSideC;
        private System.Windows.Forms.TextBox tbxSideB;
        private System.Windows.Forms.Label lblSideB;
        private System.Windows.Forms.TextBox tbxSideA;
        private System.Windows.Forms.Label lblSideA;
        private System.Windows.Forms.ErrorProvider erpSideA;
        private System.Windows.Forms.ErrorProvider erpSideB;
        private System.Windows.Forms.ErrorProvider erpSideC;
        private System.Windows.Forms.PictureBox pbxRect;
    }
}