﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using HW_WF.Models;

namespace HW_WF
{
    public partial class RectangularParallelepipedForm : Form
    {

        private RectangularParallelepiped _recPar;

        public RectangularParallelepipedForm()
        {
            InitializeComponent();
            _recPar = new RectangularParallelepiped();
        }

        public RectangularParallelepipedForm(RectangularParallelepiped rectangularParallelepiped)
        {
            InitializeComponent();
            _recPar = new RectangularParallelepiped();

            // пересылка данных в элементы интерфейса
            tbxSideA.Text = $"{rectangularParallelepiped.SideA:N3}";
            tbxSideB.Text = $"{rectangularParallelepiped.SideB:N3}";
            tbxSideC.Text = $"{rectangularParallelepiped.SideC:N3}";
        } // FiguresForm
        private void btnResult_Click(object sender, EventArgs e)
        {
            #region Данные для расчета
            double area; // площадь
            double mass; // масса
            double volume; // объем
            #endregion

            #region Получаем данные для расчета
            // проверка корректности ввода данных
            bool result = double.TryParse(tbxSideA.Text, out double a);
            if (!result){
                // данные не корректны - активировать ErrorProvider 
                // на элементе, в котором возникла ошибка
                erpSideA.SetError(tbxSideA, "Недопустимый формат");
            }else{
                // данные корректны - деактивировать ErrorProvider
                // на этом элементе ввода
                erpSideA.SetError(tbxSideA, "");
            } // if
            _recPar.SideA = a;

            result = double.TryParse(tbxSideB.Text, out double b);
            if (!result){
                // данные не корректны - активировать ErrorProvider 
                // на элементе, в котором возникла ошибка
                erpSideB.SetError(tbxSideB, "Недопустимый формат");
            }else{
                // данные корректны - деактивировать ErrorProvider
                // на этом элементе ввода
                erpSideB.SetError(tbxSideB, "");
            } // if
            _recPar.SideB = b;

            result = double.TryParse(tbxSideC.Text, out double c);
            if (!result){
                // данные не корректны - активировать ErrorProvider 
                // на элементе, в котором возникла ошибка
                erpSideC.SetError(tbxSideC, "Недопустимый формат");
            }else{
                // данные корректны - деактивировать ErrorProvider
                // на этом элементе ввода
                erpSideC.SetError(tbxSideC, "");
            } // if
            _recPar.SideC = c;
            #endregion

            #region Расчеты
            // расчет для площади
            if (cbxArea.Checked)
            {
                area = _recPar.CalcArea;
                lblSurfaceArea.Text = $"Площадь параллелепипеда: {area:n3}";
            }
            else
                lblSurfaceArea.Text = "Площадь параллелепипеда: расчет не требуется";

            // расчет для объема
            if (cbxVolume.Checked)
            {
                volume = _recPar.CalcVolume;
                lblVolume.Text = $"Объем параллелепипеда: {volume:n3}";
            }
            else
                lblVolume.Text = "Объем параллелепипеда: расчет не требуется";

            // расчет для массы
            if (cbxMass.Checked)
            {
                mass = _recPar.CalcMass;
                lblMass.Text = $"Масса параллелепипеда: {mass:n3}";
            }
            else
                lblMass.Text = "Масса параллелепипеда: расчет не требуется";
            #endregion
        }
    }
}
