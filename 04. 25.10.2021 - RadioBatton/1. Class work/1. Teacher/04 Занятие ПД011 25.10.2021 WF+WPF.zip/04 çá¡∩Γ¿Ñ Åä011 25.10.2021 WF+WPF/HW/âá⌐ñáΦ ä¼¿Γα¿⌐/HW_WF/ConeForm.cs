﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using HW_WF.Models;

namespace HW_WF
{

    public partial class ConeForm : Form
    {

        private Cone _cone;


        public ConeForm(){
            InitializeComponent();
            _cone = new Cone();
        }

        public ConeForm(Cone cone){
            InitializeComponent();
            _cone = new Cone();

            // пересылка данных в элементы интерфейса
            tbxRadius1.Text = $"{cone.Radius1:N3}";
            tbxRadius2.Text = $"{cone.Radius2:N3}";
            tbxHeight.Text = $"{cone.Height:N3}";
            tbxGeneratrix.Text = $"{cone.Generatrix:N3}";
        } // FiguresForm

        private void btnResult_Click(object sender, EventArgs e){

            #region Данные для расчета
            double area; // площадь
            double mass; // масса
            double volume; // объем
            #endregion

            #region Получаем данные для расчета
            // проверка корректности ввода данных
            bool result = double.TryParse(tbxRadius1.Text, out double r1);
            if (!result){
                // данные не корректны - активировать ErrorProvider 
                // на элементе, в котором возникла ошибка
                erpRadius1.SetError(tbxRadius1, "Недопустимый формат");
            }else{
                // данные корректны - деактивировать ErrorProvider
                // на этом элементе ввода
                erpRadius1.SetError(tbxRadius1, "");
            } // if
            _cone.Radius1 = r1;

            result = double.TryParse(tbxRadius2.Text, out double r2);
            if (!result){
                // данные не корректны - активировать ErrorProvider 
                // на элементе, в котором возникла ошибка
                erpRadius2.SetError(tbxRadius2, "Недопустимый формат");
            }else{
                // данные корректны - деактивировать ErrorProvider
                // на этом элементе ввода
                erpRadius2.SetError(tbxRadius2, "");
            } // if
            _cone.Radius2 = r2;

            result = double.TryParse(tbxGeneratrix.Text, out double generatrix);
            if (!result){
                // данные не корректны - активировать ErrorProvider 
                // на элементе, в котором возникла ошибка
                erpGeneratrix.SetError(tbxGeneratrix, "Недопустимый формат");
            }else{
                // данные корректны - деактивировать ErrorProvider
                // на этом элементе ввода
                erpGeneratrix.SetError(tbxGeneratrix, "");
            } // if
            _cone.Generatrix = generatrix;

            result = double.TryParse(tbxRadius2.Text, out double height);
            if (!result){
                // данные не корректны - активировать ErrorProvider 
                // на элементе, в котором возникла ошибка
                erpHeight.SetError(tbxHeight, "Недопустимый формат");
            }else{
                // данные корректны - деактивировать ErrorProvider
                // на этом элементе ввода
                erpHeight.SetError(tbxHeight, "");
            } // if
            _cone.Height= height;
            #endregion

            #region Расчеты
            // расчет для площади
            if (cbxArea.Checked)
            {
                area = _cone.CalcArea;
                lblSurfaceArea.Text = $"Площадь конуса: {area:n3}";
            }
            else
                lblSurfaceArea.Text = "Площадь конуса: расчет не требуется";

            // расчет для объема
            if (cbxVolume.Checked)
            {
                volume = _cone.CalcVolume;
                lblVolume.Text = $"Объем конуса: {volume:n3}";
            }
            else
                lblVolume.Text = "Объем конуса: расчет не требуется";

            // расчет для массы
            if (cbxMass.Checked)
            {
                mass = _cone.CalcMass;
                lblMass.Text = $"Масса конуса: {mass:n3}";
            }
            else
                lblMass.Text = "Масса конуса: расчет не требуется";
            #endregion

        } // btnResult_Click
    }
}
