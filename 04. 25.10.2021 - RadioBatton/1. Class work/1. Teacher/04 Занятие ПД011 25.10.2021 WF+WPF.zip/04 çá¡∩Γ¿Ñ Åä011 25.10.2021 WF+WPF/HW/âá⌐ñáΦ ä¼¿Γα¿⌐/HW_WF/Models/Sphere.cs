﻿using System;

namespace HW_WF.Models{
    public class Sphere{
        private double _radius;
        public double Radius{
            get => _radius;
            set => _radius = value > 0 ? value : 1d;
        } // Radius

        public Sphere(double r = 1){
            Radius = r;
        } // Sphere

        #region Методы для работы по заданию
        // найти площадь https://www.fxyz.ru/%D1%84%D0%BE%D1%80%D0%BC%D1%83%D0%BB%D1%8B_%D0%BF%D0%BE_%D0%B3%D0%B5%D0%BE%D0%BC%D0%B5%D1%82%D1%80%D0%B8%D0%B8/%D1%84%D0%BE%D1%80%D0%BC%D1%83%D0%BB%D1%8B_%D0%BF%D0%BB%D0%BE%D1%89%D0%B0%D0%B4%D0%B8/%D0%BF%D0%BB%D0%BE%D1%89%D0%B0%D0%B4%D1%8C_%D0%BF%D0%BE%D0%B2%D0%B5%D1%80%D1%85%D0%BD%D0%BE%D1%81%D1%82%D0%B8_%D1%81%D1%84%D0%B5%D1%80%D1%8B/
        public double CalcArea =>
            4 * Math.PI * Radius * Radius;

        // найти объем https://ru.wikihow.com/%D0%B2%D1%8B%D1%87%D0%B8%D1%81%D0%BB%D0%B8%D1%82%D1%8C-%D0%BC%D0%B0%D1%81%D1%81%D1%83-%D1%88%D0%B0%D1%80%D0%B0
        public double CalcVolume =>
            4 / 3d * Math.PI * Math.Pow(Radius, 3);

        // найти массу (плотность алюминия = 2698.72)
        public double CalcMass =>
            CalcVolume * 2698.72;

        // нельзя найти массу не зная плотность материала сферы
        #endregion

    } // Sphere
}
