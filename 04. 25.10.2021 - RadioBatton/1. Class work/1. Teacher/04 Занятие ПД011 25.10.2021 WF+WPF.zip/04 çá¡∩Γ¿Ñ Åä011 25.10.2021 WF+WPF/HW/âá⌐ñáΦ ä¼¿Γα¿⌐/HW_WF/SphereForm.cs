﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using HW_WF.Models;

namespace HW_WF
{
    public partial class SphereForm : Form
    {

        private Sphere _sphere;

        public SphereForm()
        {
            InitializeComponent();
            _sphere = new Sphere();
        }

        public SphereForm(Sphere sphere)
        {
            InitializeComponent();
            _sphere = new Sphere();

            // пересылка данных в элементы интерфейса
            tbxRadius.Text = $"{sphere.Radius:N3}";
        } // FiguresForm

        private void btnResult_Click(object sender, EventArgs e){

            #region Данные для расчета
            double area; // площадь
            double mass; // масса
            double volume; // объем
            #endregion

            #region Получаем данные для расчета
            // проверка корректности ввода данных
            bool result = double.TryParse(tbxRadius.Text, out double r);
            if (!result){
                // данные не корректны - активировать ErrorProvider 
                // на элементе, в котором возникла ошибка
                erpRadius.SetError(tbxRadius, "Недопустимый формат");
            }else{
                // данные корректны - деактивировать ErrorProvider
                // на этом элементе ввода
                erpRadius.SetError(tbxRadius, "");
            } // if
            _sphere.Radius = r;
            #endregion

            #region Расчеты
            // расчет для площади
            if (cbxArea.Checked)
            {
                area = _sphere.CalcArea;
                lblSurfaceArea.Text = $"Площадь сферы: {area:n3}";
            }
            else
                lblSurfaceArea.Text = "Площадь сферы: расчет не требуется";

            // расчет для объема
            if (cbxVolume.Checked)
            {
                volume = _sphere.CalcVolume;
                lblVolume.Text = $"Объем сферы: {volume:n3}";
            }
            else
                lblVolume.Text = "Объем сферы: расчет не требуется";

            // расчет для массы
            if (cbxMass.Checked)
            {
                mass = _sphere.CalcMass;
                lblMass.Text = $"Масса сферы: {mass:n3}";
            }
            else
                lblMass.Text = "Масса сферы: расчет не требуется";
            #endregion

        }
    }
}
