﻿using System;

namespace HW_WF.Models{
    public class RectangularParallelepiped{
        private double _sideA;
        public double SideA{
            get => _sideA;
            set => _sideA = value > 0 ? value : 1d;
        } // SideA

        private double _sideB;
        public double SideB{
            get => _sideB;
            set => _sideB = value > 0 ? value : 1d;
        } // SideB

        private double _sideC;
        public double SideC{
            get => _sideC;
            set => _sideC = value > 0 ? value : 1d;
        } // SideC

        public RectangularParallelepiped(double a = 1, double b = 2,double c = 3){
            SideA = a;
            SideB = b;
            SideC = c;
        } // RectangularParallelepiped

        #region Методы для задания
        // найти площадь https://obrazovaka.ru/matematika/ploschad-poverhnosti-pryamougolnogo-parallelepipeda-formula-5-klass.html
        public double CalcArea =>
            2 * (SideA * SideB + SideA * SideC + SideB * SideC);

        // найти объем https://skysmart.ru/articles/mathematic/obem-parallelepipeda
        public double CalcVolume =>
            SideA * SideB * SideC;

        // найти массу (плотность = 2698.72)
        public double CalcMass=>
            CalcVolume* 2698.72;

        #endregion

    } // RectangularParallelepiped
}
