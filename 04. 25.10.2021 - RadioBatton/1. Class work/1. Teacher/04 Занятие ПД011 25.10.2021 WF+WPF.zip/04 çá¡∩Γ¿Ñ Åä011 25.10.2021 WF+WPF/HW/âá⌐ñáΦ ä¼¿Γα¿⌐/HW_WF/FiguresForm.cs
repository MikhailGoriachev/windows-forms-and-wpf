﻿using System;
using System.Windows.Forms;

namespace HW_WF
{
    public partial class FiguresForm : Form{

        private ConeForm _cForm;
        private SphereForm _sForm;
        private CylinderForm _cyForm;
        private RectangularParallelepipedForm _rForm;

        public FiguresForm(){
            InitializeComponent();
        } // FiguresForm

        private void btnCone_Click(object sender, EventArgs e){
            _cForm = new ConeForm();

            // Отобразить форму
            _cForm.Show();
        } // btnResult_Click

        private void btnCylinder_Click(object sender, EventArgs e){
            _cyForm = new CylinderForm();

            // Отобразить форму
            _cyForm.Show();
        } // btnCylinder_Click

        private void btnSphere_Click(object sender, EventArgs e){
            _sForm = new SphereForm();

            // Отобразить форму
            _sForm.Show();
        } // btnSphere_Click

        private void btnRect_Click(object sender, EventArgs e){
            _rForm = new RectangularParallelepipedForm();

            // Отобразить форму
            _rForm.Show();
        } // btnRect_Click
    }
}
