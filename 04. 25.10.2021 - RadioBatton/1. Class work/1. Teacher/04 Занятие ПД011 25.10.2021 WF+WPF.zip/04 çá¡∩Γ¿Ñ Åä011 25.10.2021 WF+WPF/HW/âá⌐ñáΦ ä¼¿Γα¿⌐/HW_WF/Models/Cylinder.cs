﻿using System;

namespace HW_WF.Models{
    public class Cylinder{
        private double _radius;
        public double Radius{
            get => _radius;
            set => _radius = value > 0 ? value : 1d;
        } // Radius

        private double _height;
        public double Height{
            get => _height;
            set => _height = value > 0 ? value : 1d;
        } // Height

        public Cylinder(double r = 1, double h = 1){
            Radius = r;
            Height = h;
        } // Cylinder

        #region Методы для задания
        // найти площадь https://xn----8sbanwvcjzh9e.xn--p1ai/raznoe-2/ploshhad-poverxnosti-cilindra-formula-ploshhad-poverxnosti-cilindra-formuly-i-raschety-onlajn.html
        public double CalcArea =>
                2 * Math.PI * Radius * Height;

        // найти объем https://www.calc.ru/obyem-tsilindra.html
        public double CalcVolume =>
            Math.PI * Radius * Radius * Height;

        // найти массу (плотность = 2698.72)
        public double CalcMass=>
            CalcVolume* 2698.72;

        #endregion

    } // Cylinder
}
