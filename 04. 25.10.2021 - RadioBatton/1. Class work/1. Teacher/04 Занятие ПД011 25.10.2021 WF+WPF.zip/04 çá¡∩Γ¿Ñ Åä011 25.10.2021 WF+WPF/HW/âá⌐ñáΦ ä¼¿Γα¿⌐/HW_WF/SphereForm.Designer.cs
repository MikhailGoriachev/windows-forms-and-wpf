﻿
namespace HW_WF
{
    partial class SphereForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.cbxMass = new System.Windows.Forms.CheckBox();
            this.cbxVolume = new System.Windows.Forms.CheckBox();
            this.cbxArea = new System.Windows.Forms.CheckBox();
            this.grbResult = new System.Windows.Forms.GroupBox();
            this.lblMass = new System.Windows.Forms.Label();
            this.lblVolume = new System.Windows.Forms.Label();
            this.lblSurfaceArea = new System.Windows.Forms.Label();
            this.btnResult = new System.Windows.Forms.Button();
            this.grbData = new System.Windows.Forms.GroupBox();
            this.lblMaterial = new System.Windows.Forms.Label();
            this.tbxRadius = new System.Windows.Forms.TextBox();
            this.lblRadius = new System.Windows.Forms.Label();
            this.erpRadius = new System.Windows.Forms.ErrorProvider(this.components);
            this.pbxSphere = new System.Windows.Forms.PictureBox();
            this.grbResult.SuspendLayout();
            this.grbData.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.erpRadius)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxSphere)).BeginInit();
            this.SuspendLayout();
            // 
            // cbxMass
            // 
            this.cbxMass.AutoSize = true;
            this.cbxMass.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.cbxMass.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.cbxMass.Location = new System.Drawing.Point(24, 234);
            this.cbxMass.Name = "cbxMass";
            this.cbxMass.Size = new System.Drawing.Size(137, 24);
            this.cbxMass.TabIndex = 26;
            this.cbxMass.Text = "Расчитать массу?";
            this.cbxMass.UseVisualStyleBackColor = true;
            // 
            // cbxVolume
            // 
            this.cbxVolume.AutoSize = true;
            this.cbxVolume.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.cbxVolume.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.cbxVolume.Location = new System.Drawing.Point(24, 205);
            this.cbxVolume.Name = "cbxVolume";
            this.cbxVolume.Size = new System.Drawing.Size(141, 24);
            this.cbxVolume.TabIndex = 25;
            this.cbxVolume.Text = "Расчитать объем?";
            this.cbxVolume.UseVisualStyleBackColor = true;
            // 
            // cbxArea
            // 
            this.cbxArea.AutoSize = true;
            this.cbxArea.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.cbxArea.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.cbxArea.Location = new System.Drawing.Point(24, 176);
            this.cbxArea.Name = "cbxArea";
            this.cbxArea.Size = new System.Drawing.Size(156, 24);
            this.cbxArea.TabIndex = 24;
            this.cbxArea.Text = "Расчитать площадь?";
            this.cbxArea.UseVisualStyleBackColor = true;
            // 
            // grbResult
            // 
            this.grbResult.Controls.Add(this.lblMass);
            this.grbResult.Controls.Add(this.lblVolume);
            this.grbResult.Controls.Add(this.lblSurfaceArea);
            this.grbResult.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.grbResult.Location = new System.Drawing.Point(24, 313);
            this.grbResult.Name = "grbResult";
            this.grbResult.Size = new System.Drawing.Size(367, 125);
            this.grbResult.TabIndex = 22;
            this.grbResult.TabStop = false;
            this.grbResult.Text = "Результат";
            // 
            // lblMass
            // 
            this.lblMass.AutoSize = true;
            this.lblMass.ForeColor = System.Drawing.Color.Gold;
            this.lblMass.Location = new System.Drawing.Point(20, 94);
            this.lblMass.Name = "lblMass";
            this.lblMass.Size = new System.Drawing.Size(64, 20);
            this.lblMass.TabIndex = 17;
            this.lblMass.Text = "Масса = ";
            this.lblMass.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblVolume
            // 
            this.lblVolume.AutoSize = true;
            this.lblVolume.ForeColor = System.Drawing.Color.Gold;
            this.lblVolume.Location = new System.Drawing.Point(20, 66);
            this.lblVolume.Name = "lblVolume";
            this.lblVolume.Size = new System.Drawing.Size(64, 20);
            this.lblVolume.TabIndex = 16;
            this.lblVolume.Text = "Объем =";
            this.lblVolume.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblSurfaceArea
            // 
            this.lblSurfaceArea.AutoSize = true;
            this.lblSurfaceArea.ForeColor = System.Drawing.Color.Gold;
            this.lblSurfaceArea.Location = new System.Drawing.Point(20, 35);
            this.lblSurfaceArea.Name = "lblSurfaceArea";
            this.lblSurfaceArea.Size = new System.Drawing.Size(166, 20);
            this.lblSurfaceArea.TabIndex = 15;
            this.lblSurfaceArea.Text = "Площадь поверхности = ";
            this.lblSurfaceArea.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // btnResult
            // 
            this.btnResult.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnResult.Location = new System.Drawing.Point(255, 181);
            this.btnResult.Name = "btnResult";
            this.btnResult.Size = new System.Drawing.Size(136, 66);
            this.btnResult.TabIndex = 23;
            this.btnResult.Text = "Вычислить";
            this.btnResult.UseVisualStyleBackColor = true;
            this.btnResult.Click += new System.EventHandler(this.btnResult_Click);
            // 
            // grbData
            // 
            this.grbData.Controls.Add(this.lblMaterial);
            this.grbData.Controls.Add(this.tbxRadius);
            this.grbData.Controls.Add(this.lblRadius);
            this.grbData.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.grbData.Location = new System.Drawing.Point(12, 12);
            this.grbData.Name = "grbData";
            this.grbData.Size = new System.Drawing.Size(367, 110);
            this.grbData.TabIndex = 21;
            this.grbData.TabStop = false;
            this.grbData.Text = "Исходные данные";
            // 
            // lblMaterial
            // 
            this.lblMaterial.AutoSize = true;
            this.lblMaterial.ForeColor = System.Drawing.Color.Gold;
            this.lblMaterial.Location = new System.Drawing.Point(19, 70);
            this.lblMaterial.Name = "lblMaterial";
            this.lblMaterial.Size = new System.Drawing.Size(223, 20);
            this.lblMaterial.TabIndex = 15;
            this.lblMaterial.Text = "Материал - алюминий (для массы)";
            this.lblMaterial.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tbxRadius
            // 
            this.tbxRadius.Location = new System.Drawing.Point(233, 26);
            this.tbxRadius.Name = "tbxRadius";
            this.tbxRadius.Size = new System.Drawing.Size(100, 26);
            this.tbxRadius.TabIndex = 1;
            this.tbxRadius.Text = "2";
            this.tbxRadius.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lblRadius
            // 
            this.lblRadius.AutoSize = true;
            this.lblRadius.ForeColor = System.Drawing.Color.Gold;
            this.lblRadius.Location = new System.Drawing.Point(19, 32);
            this.lblRadius.Name = "lblRadius";
            this.lblRadius.Size = new System.Drawing.Size(102, 20);
            this.lblRadius.TabIndex = 0;
            this.lblRadius.Text = "Радиус сферы";
            this.lblRadius.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // erpRadius
            // 
            this.erpRadius.ContainerControl = this;
            // 
            // pbxSphere
            // 
            this.pbxSphere.Image = global::HW_WF.Properties.Resources.Sphere;
            this.pbxSphere.Location = new System.Drawing.Point(411, 56);
            this.pbxSphere.Name = "pbxSphere";
            this.pbxSphere.Size = new System.Drawing.Size(239, 343);
            this.pbxSphere.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbxSphere.TabIndex = 27;
            this.pbxSphere.TabStop = false;
            // 
            // SphereForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Firebrick;
            this.ClientSize = new System.Drawing.Size(677, 450);
            this.Controls.Add(this.pbxSphere);
            this.Controls.Add(this.cbxMass);
            this.Controls.Add(this.cbxVolume);
            this.Controls.Add(this.cbxArea);
            this.Controls.Add(this.grbResult);
            this.Controls.Add(this.btnResult);
            this.Controls.Add(this.grbData);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "SphereForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Сфера";
            this.grbResult.ResumeLayout(false);
            this.grbResult.PerformLayout();
            this.grbData.ResumeLayout(false);
            this.grbData.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.erpRadius)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxSphere)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.CheckBox cbxMass;
        private System.Windows.Forms.CheckBox cbxVolume;
        private System.Windows.Forms.CheckBox cbxArea;
        private System.Windows.Forms.GroupBox grbResult;
        private System.Windows.Forms.Label lblMass;
        private System.Windows.Forms.Label lblVolume;
        private System.Windows.Forms.Label lblSurfaceArea;
        private System.Windows.Forms.Button btnResult;
        private System.Windows.Forms.GroupBox grbData;
        private System.Windows.Forms.Label lblMaterial;
        private System.Windows.Forms.TextBox tbxRadius;
        private System.Windows.Forms.Label lblRadius;
        private System.Windows.Forms.ErrorProvider erpRadius;
        private System.Windows.Forms.PictureBox pbxSphere;
    }
}