﻿using System;

namespace HW_WF.Models{
    public class Cone{
        private double _radius1;
        public double Radius1{
            get => _radius1;
            set => _radius1 = value > 0 ? value : 1d;
        } // Radius1

        private double _radius2;
        public double Radius2{
            get => _radius2;
            set => _radius2 = value > 0 ? value : 1d;
        } // Radius2

        private double _generatrix;
        public double Generatrix{
            get => _generatrix;
            set => _generatrix = value > 0 ? _generatrix : 1d;
        } // Generatrix

        private double _height;
        public double Height{
            get => _height;
            set => _height = value > 0 ? value : 1d;
        } // Height

        #region Конструктор
        public Cone(double r1 = 2, double r2 = 1, double g = 1, double h = 1){
            Radius1 = r1;
            Radius2 = r2;
            Generatrix = g;
            Height = h;
        } // Cone
        #endregion

        #region Методы для работы по заданию
        // расчет площади https://allcalc.ru/node/467
        public double CalcArea =>
            Math.PI * (Radius1 * Radius1 + (Radius1 + Radius2) * Generatrix + Radius2 * Radius2);

        // расчет объема https://www.fxyz.ru/%D1%84%D0%BE%D1%80%D0%BC%D1%83%D0%BB%D1%8B_%D0%BF%D0%BE_%D0%B3%D0%B5%D0%BE%D0%BC%D0%B5%D1%82%D1%80%D0%B8%D0%B8/%D1%84%D0%BE%D1%80%D0%BC%D1%83%D0%BB%D1%8B_%D0%BE%D0%B1%D1%8A%D0%B5%D0%BC%D0%B0/%D0%BE%D0%B1%D1%8A%D0%B5%D0%BC_%D1%83%D1%81%D0%B5%D1%87%D0%B5%D0%BD%D0%BD%D0%BE%D0%B3%D0%BE_%D0%BA%D0%BE%D0%BD%D1%83%D1%81%D0%B0/
        public double CalcVolume =>
             1/3d * Math.PI * Height * (Radius1 * Radius1 + Radius2 * Radius2 + Radius1 * Radius2);

        // расчет массы https://tvlad.ru/mass/massa-sploshnoy-detali.html
        public double CalcMass =>
            1 / 12d * Math.PI * Height * (Radius1 * Radius1 + Radius1 * Radius2 + Radius2 * Radius2);
        #endregion

    } // Conde
}
