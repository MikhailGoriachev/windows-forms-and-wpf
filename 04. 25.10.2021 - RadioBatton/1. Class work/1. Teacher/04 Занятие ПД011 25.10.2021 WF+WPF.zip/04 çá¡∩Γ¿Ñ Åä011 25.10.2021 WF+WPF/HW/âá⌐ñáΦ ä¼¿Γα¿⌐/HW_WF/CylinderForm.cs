﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using HW_WF.Models;

namespace HW_WF
{
    public partial class CylinderForm : Form
    {
        private Cylinder _cylinder;
        public CylinderForm()
        {
            InitializeComponent();
            _cylinder = new Cylinder();
        }


        public CylinderForm(Cylinder cylinder)
        {
            InitializeComponent();
            _cylinder = new Cylinder();

            // пересылка данных в элементы интерфейса
            tbxRadius.Text = $"{cylinder.Radius:N3}";
            tbxHeight.Text = $"{cylinder.Height:N3}";
        } // FiguresForm

        private void btnResult_Click(object sender, EventArgs e)
        {
            #region Данные для расчета
            double area; // площадь
            double mass; // масса
            double volume; // объем
            #endregion

            #region Получаем данные для расчета
            // проверка корректности ввода данных
            bool result = double.TryParse(tbxRadius.Text, out double r);
            if (!result){
                // данные не корректны - активировать ErrorProvider 
                // на элементе, в котором возникла ошибка
                erpRadius.SetError(tbxRadius, "Недопустимый формат");
            }else{
                // данные корректны - деактивировать ErrorProvider
                // на этом элементе ввода
                erpRadius.SetError(tbxRadius, "");
            } // if
            _cylinder.Radius = r;

            result = double.TryParse(tbxHeight.Text, out double height);
            if (!result)
            {
                // данные не корректны - активировать ErrorProvider 
                // на элементе, в котором возникла ошибка
                erpHeight.SetError(tbxHeight, "Недопустимый формат");
            }else{
                // данные корректны - деактивировать ErrorProvider
                // на этом элементе ввода
                erpHeight.SetError(tbxHeight, "");
            } // if
            _cylinder.Height = height;
            #endregion

            #region Расчеты
            // расчет для площади
            if (cbxArea.Checked)
            {
                area = _cylinder.CalcArea;
                lblSurfaceArea.Text = $"Площадь цилиндра: {area:n3}";
            }
            else
                lblSurfaceArea.Text = "Площадь цилиндра: расчет не требуется";

            // расчет для объема
            if (cbxVolume.Checked)
            {
                volume = _cylinder.CalcVolume;
                lblVolume.Text = $"Объем цилиндра: {volume:n3}";
            }
            else
                lblVolume.Text = "Объем цилиндра: расчет не требуется";

            // расчет для массы
            if (cbxMass.Checked)
            {
                mass = _cylinder.CalcMass;
                lblMass.Text = $"Масса цилиндра: {mass:n3}";
            }
            else
                lblMass.Text = "Масса цилиндра: расчет не требуется";
            #endregion

        }
    }
}
