﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Santas.Models
{
    public class Television
    {
        //класс для представления телевизора в ремонтной мастерской
        public string ManufactureType { get; set; } // тип и производитель телевизора

        private double _diagonal;      // диагональ телевизора

        public double Diagonal
        {
            get => _diagonal;
            set
            {
                if (value <= 0) 
                    throw new ArgumentException(" Диагональ не может быть отрицательной");
                _diagonal = value;
            }
        }

        public string Defect { get; set; } // описание дефекта 

        public string MastersSurnameNP { get; set; }  // фамилия и инициалы мастера 

        public string OwnersSurnameNP { get; set; }   // фамилия и инициалы владельца

        private int _fixPrice;                        // стоимость ремонта

        public int FixPrice
        {
            get => _fixPrice;
            set
            {
                if (value <= 0) 
                    throw new ArgumentException("Стоимость не может быть отрицательной");
                _fixPrice = value;
            }
        }
    }
}
