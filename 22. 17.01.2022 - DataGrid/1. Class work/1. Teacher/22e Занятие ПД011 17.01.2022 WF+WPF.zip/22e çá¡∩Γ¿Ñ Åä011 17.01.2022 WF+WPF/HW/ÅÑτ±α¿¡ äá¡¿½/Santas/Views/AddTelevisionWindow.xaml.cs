﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Santas.Models;
using Santas.Helpers;

namespace Santas.Views
{
    /// <summary>
    /// Interaction logic for AddTelevisionWindow.xaml
    /// </summary>
    public partial class AddTelevisionWindow : Window
    {
        Television _television;
        public Television Television
        {
            get => _television;
            set
            {
                _television = value;
                TxtMaster.Text = _television.MastersSurnameNP;
                TxbPrice.Text = $"{_television.FixPrice}";
                CmbManufacturer.Text = _television.ManufactureType;
                TxbOwner.Text = _television.OwnersSurnameNP;
                TxbDefect.Text = _television.Defect;
                CmdDiagonal.Text = $"{_television.Diagonal}";
            } // set
        }
        public AddTelevisionWindow():this("Добавление телевизора", "Добавить") {}
        public AddTelevisionWindow(string header, string button)
        {
            InitializeComponent();
            Title = header;
            BtnCancel.Content = button;

            CmbManufacturer.ItemsSource = Utils.Brands;
            CmbManufacturer.SelectedIndex = 0;

            CmdDiagonal.ItemsSource = Utils.Diagonals;
            CmdDiagonal.SelectedIndex = 0;

            Television = new Television();


        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {

        }

        private void Add_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // Получить данные от элементов управления
                Television.ManufactureType = CmbManufacturer.Text;
                Television.Defect = TxbDefect.Text;
                Television.Diagonal = double.Parse(CmdDiagonal.SelectedItem.ToString());
                Television.OwnersSurnameNP = TxbOwner.Text;
                Television.FixPrice = int.Parse(TxbPrice.Text);
                Television.MastersSurnameNP = TxtMaster.Text;
                DialogResult = true;
                Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}
