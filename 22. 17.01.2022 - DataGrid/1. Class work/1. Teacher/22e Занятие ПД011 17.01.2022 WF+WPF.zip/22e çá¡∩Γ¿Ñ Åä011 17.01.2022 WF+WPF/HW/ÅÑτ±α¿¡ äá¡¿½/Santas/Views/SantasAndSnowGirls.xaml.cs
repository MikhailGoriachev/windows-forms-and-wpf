﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Santas.Models;


namespace Santas.Views
{
    /// <summary>
    /// Interaction logic for SantasAndSnowGirls.xaml
    /// </summary>
    public partial class SantasAndSnowGirls : Window
    {
        public SantasAndSnowGirls()
        {
            InitializeComponent();

            LsvSnowGirls.ItemsSource = new List<SnowGirl>(new SnowGirl[]
            {
                new SnowGirl {Name ="Вера", Surname ="Бобкова", Patronymic = "Тихоновна", CoatColor = "синий", NumberOfVerses = 10, NumberOfGames = 12},
                new SnowGirl{Name = "Нина", Surname = "Никифорова", Patronymic = "Ивановна",CoatColor = "синий", NumberOfVerses = 12, NumberOfGames = 6},
                new SnowGirl {Name = "Анна", Surname = "Клаузман", Patronymic = "Никоноровна", CoatColor = "синий", NumberOfVerses = 13, NumberOfGames = 15},
            });

            
        }
    }
}
