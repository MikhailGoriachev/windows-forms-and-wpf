﻿using HomeWork.Helpers;
using HomeWork.Models.RepairShop;
using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace HomeWork.Views
{
    /// <summary>
    /// Логика взаимодействия для ViewRepairShopWindow.xaml
    /// </summary>
    public partial class ViewRepairShopWindow : Window
    {
        RepairShop repairShop;


        public ViewRepairShopWindow()
        {
            InitializeComponent();
            repairShop = new RepairShop() { RepairShopName = "Быстрый ремонт", RepairShopAddress = "ул.Артема 112а" };
            // привязка коллекции телевизоров к listView
            DgTVinRepairShop.ItemsSource = repairShop.TeleList;

        }

        private Dictionary<string, string> ToDictionaryRepairer() {

            Dictionary<string, string> repairNames = new Dictionary<string, string>();

            foreach (var item in repairShop.TeleList)
            {
                if(!repairNames.ContainsKey(item.RepairerName)) repairNames.Add(item.RepairerName, item.RepairerName);                
            }

            return repairNames;


        }

        private Dictionary<double, double> ToDictionaryDiagonal()
        {

            Dictionary<double, double> repairNames = new Dictionary<double, double>();

            foreach (var item in repairShop.TeleList)
            {
                if (!repairNames.ContainsKey(item.Diagonal)) repairNames.Add(item.Diagonal, item.Diagonal);
            }

            return repairNames;


        }



        // заполнение колекции
        private void Click_InitCollection(object sender, RoutedEventArgs e)
        {
            repairShop.CreateTVList(Utils.GetRandom(12, 16));
            TxbStatusCount.Text = DgTVinRepairShop.Items.Count.ToString();
            TbcTV.SelectedIndex = 0;

        }


        // добавить телевизор
        private void Click_AddTV(object sender, RoutedEventArgs e)
        {
            TbcTV.SelectedIndex = 0;

            try
            {
                CreateOrEditTVWindow editWindow = new CreateOrEditTVWindow();

                if (editWindow.ShowDialog() != true) return;

                repairShop.TeleList.Add(editWindow.GetTV());
            }
            catch (Exception ex)
            {
                Interaction.MsgBox(ex.Message, MsgBoxStyle.Critical | MsgBoxStyle.OkOnly, "Ошибка");
            }


        }

        // изменить телевизор
        private void Click_EditTV(object sender, RoutedEventArgs e)
        {
            TbcTV.SelectedIndex = 0;

            try
            {
                CreateOrEditTVWindow editWindow = new CreateOrEditTVWindow((Television)DgTVinRepairShop.SelectedItem);

                if (editWindow.ShowDialog() != true) return;

                repairShop.TeleList[DgTVinRepairShop.SelectedIndex] = editWindow.GetTV();

            }
            catch (Exception ex)
            {
                Interaction.MsgBox(ex.Message, MsgBoxStyle.Critical | MsgBoxStyle.OkOnly, "Ошибка");
            }



        }

        // удалить телевизор
        private void Click_DeleteTV(object sender, RoutedEventArgs e)
        {
            TbcTV.SelectedIndex = 0;

            try
            {
                repairShop.TeleList.RemoveAt(DgTVinRepairShop.SelectedIndex);

            }
            catch (Exception ex)
            {
                Interaction.MsgBox(ex.Message, MsgBoxStyle.Critical | MsgBoxStyle.OkOnly, "Ошибка");
            }


        }

        // сортировка
        private void Select_Sorts(object sender, RoutedEventArgs e)
        {
            MenuItem menu = (MenuItem)sender;            
            switch (menu.Tag)
            {

                case "SortByType":
                    TbcTV.SelectedIndex = 1;
                    Lbl_titleSorts.Content = "Коллекция отсортированая по типу телевизора";
                    DgSortsTV.ItemsSource = repairShop.SortByType();
                    TxbStatusCount.Text = DgSelectedTV.Items.Count.ToString();                    
                    break;

                case "SortByDiagonal":
                    TbcTV.SelectedIndex = 1;
                    Lbl_titleSorts.Content = "Коллекция отсортированая по типу телевизора";
                    DgSortsTV.ItemsSource = repairShop.SortByDiagonal();
                    TxbStatusCount.Text = DgSelectedTV.Items.Count.ToString();
                    break;

                case "SortByRepairName":
                    TbcTV.SelectedIndex = 1;
                    Lbl_titleSorts.Content = "Коллекция отсортированая по типу телевизора";
                    DgSortsTV.ItemsSource = repairShop.SortByRepairName();
                    TxbStatusCount.Text = DgSelectedTV.Items.Count.ToString();                    
                    break;

                case "SortByOwnerName":
                    TbcTV.SelectedIndex = 1;
                    Lbl_titleSorts.Content = "Коллекция отсортированая по типу телевизора";
                    DgSortsTV.ItemsSource = repairShop.SortByOwnerName();
                    TxbStatusCount.Text = DgSelectedTV.Items.Count.ToString();                    
                    break;
            }

            TxbStatusCount.Text = DgTVinRepairShop.Items.Count.ToString();


        }

        // выборки
        private void Select_selection(object sender, RoutedEventArgs e)
        {
           
            SelectedWindow selectedWindow;

            try
            {
                MenuItem menu = (MenuItem)sender;

                switch (menu.Tag)
                {

                    case "SelectMinRepairCost":
                        TbcTV.SelectedIndex = 2;
                        Lbl_titleSelected.Content = "Коллекция телевизоров с минимальной стоимостью ремонта";
                        DgSelectedTV.ItemsSource = repairShop.SelectMinRepairCost();
                        TxbStatusCount.Text = DgSelectedTV.Items.Count.ToString();
                        break;

                    case "SelectRepairName":
                        selectedWindow = new SelectedWindow(ToDictionaryRepairer());
                        selectedWindow.ShowDialog();
                        if (selectedWindow.DialogResult == true)
                        {
                            TbcTV.SelectedIndex = 2;
                            Lbl_titleSelected.Content = "Коллекция телевизоров, ремонтируемых выбранным мастером";
                            DgSelectedTV.ItemsSource = repairShop.SelectRepairName(selectedWindow.GetResult());                            
                        }
                        TxbStatusCount.Text = DgSelectedTV.Items.Count.ToString();

                        break;

                    case "SelectDiagonal":

                        selectedWindow = new SelectedWindow(ToDictionaryDiagonal());
                        selectedWindow.ShowDialog();
                        if (selectedWindow.DialogResult == true)
                        {
                            TbcTV.SelectedIndex = 2;
                            Lbl_titleSelected.Content = "Коллекция телевизоров, ремонтируемых выбранным мастером";
                            DgSelectedTV.ItemsSource = repairShop.SelectDiagonal(Double.Parse(selectedWindow.GetResult()));
                        }
                        TxbStatusCount.Text = DgSelectedTV.Items.Count.ToString();

                        break;

                }



            }
            catch (Exception ex)
            {

                Interaction.MsgBox(ex.Message, MsgBoxStyle.Critical | MsgBoxStyle.OkOnly, "Ошибка");
            }
            

        }


        
        // оичстка таблицы для выборок при переключении вкладки
        private void ChangeSelectTabItem(object sender, RoutedEventArgs e)
        {
            DgSelectedTV.ItemsSource = null;
            Lbl_titleSelected.Content = "";
            DgSortsTV.ItemsSource = null;
            Lbl_titleSorts.Content = "";

            TxbStatusCount.Text = DgTVinRepairShop.Items.Count.ToString();

        }
        // выход
        private void Click_Quit(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }

    }
}
