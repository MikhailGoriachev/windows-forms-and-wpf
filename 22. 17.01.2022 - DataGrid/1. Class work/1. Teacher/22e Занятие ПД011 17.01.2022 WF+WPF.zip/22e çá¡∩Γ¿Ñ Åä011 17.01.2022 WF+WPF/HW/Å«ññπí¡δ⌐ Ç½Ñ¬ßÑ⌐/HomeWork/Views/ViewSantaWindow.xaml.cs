﻿using HomeWork.Helpers;
using HomeWork.Models.Actors;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace HomeWork.Views
{
    /// <summary>
    /// Логика взаимодействия для ViewSantaWindow.xaml
    /// </summary>
    public partial class ViewSantaWindow : Window
    {
        public ViewSantaWindow()
        {
            InitializeComponent();

            DgSnowMaiden.ItemsSource = new List<SnowMaiden>{
                new SnowMaiden {SurName = "Ильина",         Name = "Таисия",            Patronymic = "Владимировна",        CoatColor = "Серый",         Param1 = Utils.GetRandom(5,13),         Param2 = Utils.GetRandom(2,7)},
                new SnowMaiden {SurName = "Дроздова",       Name = "Екатерина",         Patronymic = "Дмитриевна",          CoatColor = "Белый",         Param1 = Utils.GetRandom(5,13),         Param2 = Utils.GetRandom(2,7)},
                new SnowMaiden {SurName = "Белова",         Name = "Екатерина",         Patronymic = "Кирилловна",          CoatColor = "Голубой",       Param1 = Utils.GetRandom(5,13),         Param2 = Utils.GetRandom(2,7)},
                new SnowMaiden {SurName = "Быкова",         Name = "Диана",             Patronymic = "Алексеевна",          CoatColor = "Белый",         Param1 = Utils.GetRandom(5,13),         Param2 = Utils.GetRandom(2,7)},
                new SnowMaiden {SurName = "Кузнецова",      Name = "Виктория",          Patronymic = "Владимировна",        CoatColor = "Синий",         Param1 = Utils.GetRandom(5,13),         Param2 = Utils.GetRandom(2,7)},
                new SnowMaiden {SurName = "Смирнова",       Name = "Мила",              Patronymic = "Матвеевна",           CoatColor = "Серый",         Param1 = Utils.GetRandom(5,13),         Param2 = Utils.GetRandom(2,7)},
                new SnowMaiden {SurName = "Лебедева",       Name = "Софья",             Patronymic = "Марковна",            CoatColor = "Синий",         Param1 = Utils.GetRandom(5,13),         Param2 = Utils.GetRandom(2,7)},
                new SnowMaiden {SurName = "Боброва",        Name = "Арина",             Patronymic = "Сергеевна",           CoatColor = "Голубой",       Param1 = Utils.GetRandom(5,13),         Param2 = Utils.GetRandom(2,7)},
                new SnowMaiden {SurName = "Булатова",       Name = "Нина",              Patronymic = "Кирилловна",          CoatColor = "Серый",         Param1 = Utils.GetRandom(5,13),         Param2 = Utils.GetRandom(2,7)},
                new SnowMaiden {SurName = "Лаврова",        Name = "Анна",              Patronymic = "Данииловна",          CoatColor = "Белый",         Param1 = Utils.GetRandom(5,13),         Param2 = Utils.GetRandom(2,7)},
                new SnowMaiden {SurName = "Попова",         Name = "Василиса",          Patronymic = "Ильинична",           CoatColor = "Голубой",       Param1 = Utils.GetRandom(5,13),         Param2 = Utils.GetRandom(2,7)},
                new SnowMaiden {SurName = "Федотова",       Name = "Вероника",          Patronymic = "Михайловна",          CoatColor = "Серый",         Param1 = Utils.GetRandom(5,13),         Param2 = Utils.GetRandom(2,7)},
                new SnowMaiden {SurName = "Захарова",       Name = "София",             Patronymic = "Романовна",           CoatColor = "Белый",         Param1 = Utils.GetRandom(5,13),         Param2 = Utils.GetRandom(2,7)},
                new SnowMaiden {SurName = "Никулина",       Name = "Ангелина",          Patronymic = "Владиславовна",       CoatColor = "Белый",         Param1 = Utils.GetRandom(5,13),         Param2 = Utils.GetRandom(2,7)},
                new SnowMaiden {SurName = "Михайлова",      Name = "Анастасия",         Patronymic = "Ивановна",            CoatColor = "Голубой",       Param1 = Utils.GetRandom(5,13),         Param2 = Utils.GetRandom(2,7)},
                new SnowMaiden {SurName = "Рыбакова",       Name = "Алиса",             Patronymic = "Максимовна",          CoatColor = "Серый",         Param1 = Utils.GetRandom(5,13),         Param2 = Utils.GetRandom(2,7)},
                new SnowMaiden {SurName = "Краснова",       Name = "Алиса",             Patronymic = "Павловна",            CoatColor = "Синий",         Param1 = Utils.GetRandom(5,13),         Param2 = Utils.GetRandom(2,7)},
                new SnowMaiden {SurName = "Седова",         Name = "Варвара",           Patronymic = "Серафимовна",         CoatColor = "Синий",         Param1 = Utils.GetRandom(5,13),         Param2 = Utils.GetRandom(2,7)}
            };

            // удалить
           
        }
       
        // изменение в строке статус бара количсетва актеров 
        private void ChangeSelectTabItem(object sender, RoutedEventArgs e)
        {
            TabControl tabControl = sender as TabControl;
           
            if (tabControl.SelectedIndex == 0)
                TxbStatusCount.Text = DgSantas.Items.Count.ToString();
            if (tabControl.SelectedIndex == 1)
                TxbStatusCount.Text = DgSnowMaiden.Items.Count.ToString();
        }
    }
}

