﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace HomeWork.Views
{
    /// <summary>
    /// Логика взаимодействия для SelectedWindow.xaml
    /// </summary>
    public partial class SelectedWindow : Window
    {
        public SelectedWindow(Dictionary<double, double> list)
        {
            InitializeComponent();
            this.Title = "Выборка по диагонали";
            Lbl_Tittle.Content = "Выберите диагональ из списка";
            Cbx_select.ItemsSource = list.Values.OrderBy(a => a);

        }

        public SelectedWindow(Dictionary<string, string> list)
        {
            InitializeComponent();
            this.Title = "Выборка по мастеру";
            Lbl_Tittle.Content = "Выберите мастера из списка";
            Cbx_select.ItemsSource = list.Values.OrderBy( a => a);

        }

        public string GetResult()
        {
            return Cbx_select.SelectedItem.ToString();
        }

        private void Click_Close(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }
        private void Click_Ok(object sender, RoutedEventArgs e)
        {
            DialogResult = true;
            Close();
        }

    }
}
