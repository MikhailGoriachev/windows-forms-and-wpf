﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Homework.Helpers;


namespace Homework.Models.Animators
{
	/*
	 Снегурочка: 
	- фамилия,
	- имя,
	- отчество,
	- цвет полушубка,
	- количество стихотворений, которые знает актриса,
	- количество игр для детей, которые может организовать актриса.   
	 */
	public class SnowGirl : Person
	{
		// количество стихотворений, которые знает актриса,
		private int _poems;

		public int Poems
		{
			get => _poems;
			set
			{
				if (value < 0)
					throw new ArgumentOutOfRangeException($"Недопустимое значение количества стихотворений: {value}");
				_poems = value;
			}
		}

		// количество игр для детей, которые может организовать актриса.

		private int _games;
			
		public int Games
		{
			get => _games;
			set
			{
				if (value < 0)
					throw new ArgumentOutOfRangeException($"Недопустимое значение количества игр: {value}");
				_games = value;
			}
		}

	}
}
