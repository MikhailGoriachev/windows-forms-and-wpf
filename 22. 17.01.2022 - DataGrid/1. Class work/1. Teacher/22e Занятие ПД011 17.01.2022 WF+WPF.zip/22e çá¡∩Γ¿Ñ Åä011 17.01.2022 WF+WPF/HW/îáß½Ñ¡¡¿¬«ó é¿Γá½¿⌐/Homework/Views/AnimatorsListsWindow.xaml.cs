﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Homework.Helpers;
using Homework.Models.Animators;

namespace Homework.Views
{
	/// <summary>
	/// Логика взаимодействия для AnimatorsListsWindow.xaml
	/// </summary>
	public partial class AnimatorsListsWindow : Window
	{
		public AnimatorsListsWindow()
		{
			InitializeComponent();

			// количество элементов коллекции снегурочек по заданию
			int minAmountSnowGirls = 12;
			int maxAmountSnowGirls = 20;

			// данные для отображения в listView
			List<SnowGirl> snowGirls =
				SnowGirlFabric.GenerateCollection(Utils.GetRandom(minAmountSnowGirls, maxAmountSnowGirls));
			
			// привязка данных
			DgSbowGirls.ItemsSource = snowGirls;
		}
	}
}
