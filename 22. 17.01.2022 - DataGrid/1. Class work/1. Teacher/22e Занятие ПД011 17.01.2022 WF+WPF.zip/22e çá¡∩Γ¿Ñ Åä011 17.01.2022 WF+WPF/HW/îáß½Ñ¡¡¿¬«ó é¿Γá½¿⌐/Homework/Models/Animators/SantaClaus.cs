﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media;

namespace Homework.Models.Animators
{
	/*
	   Деда Мороз: 
		- string фамилия,
		- string имя, 
		- string отчество,
		- цвет полушубка,
		- int количество подарков, которые способен перенести актер.
	 */
	public class SantaClaus : Person
	{
		// кол-во подарков, которые способен перенести актер
		private int _giftsCapacity;

		public int GiftsCapacity
		{
			get => _giftsCapacity;
			set
			{
				if (value <= 0)
					throw new ArgumentOutOfRangeException($"Недопустимое значение количества переносимх подарков: {value}");
				_giftsCapacity = value;
			}
		}

		public override string ToString() =>
			$"{base.ToString()}, подарков: {_giftsCapacity},";
	}
}
