﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Homework.Views
{
	/// <summary>
	/// Логика взаимодействия для SelectingWindow.xaml
	/// </summary>
	public partial class SelectingWindow : Window
	{
		public string Choosen => CbxList.SelectedValue.ToString();

		public SelectingWindow() : this(new List<string>(), "Выбор для отчета", "Выберите из списка:")
		{
		}


		public SelectingWindow(List<string> data, string title, string label)
		{
			InitializeComponent();
			Title = title;
			LblPrompt.Content = label;

			CbxList.ItemsSource = data;
			CbxList.SelectedIndex = 0;
		}


		private void BtnOk_Click(object sender, RoutedEventArgs e) => DialogResult = true;
	}
}
