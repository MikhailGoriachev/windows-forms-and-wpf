﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Homework.Models.Animators
{
	public abstract class Person
	{
		// имя
		private string _name;

		public string Name
		{
			get => _name;
			set
			{
				if (string.IsNullOrEmpty(value))
					throw new ArgumentNullException("Пустая строка имени актёра");
				_name = value;
			}
		}

		// фамилия
		private string _surname;

		public string Surname
		{
			get => _surname;
			set
			{
				if (string.IsNullOrEmpty(value))
					throw new ArgumentNullException("Пустая строка фамилии актёра");
				_surname = value;
			}
		}

		// отчество
		private string _patronymic;

		public string Patronymic
		{
			get => _patronymic;
			set
			{
				if (string.IsNullOrEmpty(value))
					throw new ArgumentNullException("Пустая строка отчества актёра");
				_patronymic = value;
			}
		}

		// цвет полушубка
		private string _furcoatColor;

		public string FurcoatColor
		{
			get => _furcoatColor;
			set
			{
				if (string.IsNullOrEmpty(value))
					throw new ArgumentNullException("Пустая строка цвета полушубка");
				_furcoatColor = value;
			}
		}

		public override string ToString() =>
			$"{_surname} {_name} {_patronymic}, полушубок: {_furcoatColor}";
	}
}
