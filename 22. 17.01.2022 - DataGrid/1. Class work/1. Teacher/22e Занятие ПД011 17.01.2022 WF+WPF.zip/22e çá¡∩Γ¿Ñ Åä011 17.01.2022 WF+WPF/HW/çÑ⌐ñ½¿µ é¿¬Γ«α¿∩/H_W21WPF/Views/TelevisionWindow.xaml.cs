﻿using H_W21WPF.Models.RepairShop;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace H_W21WPF.Views
{
    /// <summary>
    /// Логика взаимодействия для TelevisionWindow.xaml
    /// </summary>
    public partial class TelevisionWindow : Window
    {
		private Television _tv;

		public Television Tv
		{
			get => _tv;
			set
			{
				_tv = value;

				CmbBrand.Text = _tv.TvBrand;
				TxbDefect.Text = _tv.TvDefect;
				CmbMaster.Text = _tv.FullnameMaster;
				TxbOwner.Text = _tv.FullnameOwner;
				CmbDiagonal.Text = $"{_tv.Diagonal}";
				TxbPrice.Text = _tv.CostRepair.ToString();
			}
		}// Tv

		public TelevisionWindow()
		{
			InitializeComponent();
			_tv = new Television();
		}

		public TelevisionWindow(string windowTitle, string btnTitle)
		{
			InitializeComponent();
			_tv = new Television();

			// Заголовок формы
			Title = windowTitle;
			BtnOk.Content = btnTitle;

			CmbBrand.ItemsSource = _tv.TvBrand;
			CmbBrand.SelectedIndex = 0;

			CmbMaster.ItemsSource = _tv.FullnameMaster;
			CmbMaster.SelectedIndex = 0;

			CmbDiagonal.ItemsSource = _tv.Diagonal.ToString();
		    CmbDiagonal.SelectedIndex = 0;
			_tv = new Television();
		}// TelevisionWindow

		private void BtnOk_Click(object sender, RoutedEventArgs e)
		{
			if (!Validate())
			{
				MessageBox.Show("Не все данные заполнены корректно",
					"Ошибка",
					MessageBoxButton.OK,
					MessageBoxImage.Exclamation);
				return;
			}

			_tv = new Television()
			{
				TvBrand = CmbBrand.Text,
				TvDefect = TxbDefect.Text,
				Diagonal = int.Parse(CmbDiagonal.Text),
				FullnameOwner = TxbOwner.Text,
				CostRepair = int.Parse(TxbPrice.Text),
				FullnameMaster = CmbMaster.Text
			};

			DialogResult = true;
		}// BtnOk_Click


		public bool Validate() =>
	           !string.IsNullOrWhiteSpace(CmbBrand.Text) &&
	           !string.IsNullOrWhiteSpace(TxbDefect.Text) &&
	           !string.IsNullOrWhiteSpace(TxbOwner.Text) &&
	           !string.IsNullOrWhiteSpace(CmbMaster.Text) &&
	           !string.IsNullOrWhiteSpace(CmbDiagonal.Text) &&
	           !string.IsNullOrWhiteSpace(TxbPrice.Text) &&
	           int.TryParse(TxbPrice.Text, out _);

		private void Txb_PreviewTextInput(object sender, TextCompositionEventArgs e) =>
			e.Handled = !int.TryParse(e.Text, out _);

	} // class TelevisionWindow
}
