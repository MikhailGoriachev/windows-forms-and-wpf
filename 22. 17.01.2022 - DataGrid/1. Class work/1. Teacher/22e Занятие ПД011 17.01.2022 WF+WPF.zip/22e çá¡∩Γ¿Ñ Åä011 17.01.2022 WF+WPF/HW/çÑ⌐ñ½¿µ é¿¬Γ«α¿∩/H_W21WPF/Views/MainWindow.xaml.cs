﻿using H_W21WPF.Models.NewYear;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using H_W21WPF.Controllers;
using H_W21WPF.Models.RepairShop;

namespace H_W21WPF.Views
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        // контроллер для работы с формой
        private RepairShopController _shopController;

        public MainWindow(): this(new RepairShopController()) { }
        // конструкторы формы
        public MainWindow(RepairShopController shopController)
        {
            InitializeComponent();

            _shopController = shopController;


            LblShopName.Content = _shopController.RepairShop.Name;
            LblShopAddress.Content = "Адрес: " + _shopController.RepairShop.Address;

            DgSnowMaiden.ItemsSource = new List<SnowMaiden>(new SnowMaiden[]
{
                new SnowMaiden{Surname = "Николаева", Name = "Зинаида",    Patronymic = "Романовна",   CoatColor = "голубой", AmountPoems = 5, AmountGames = 1},
                new SnowMaiden{Surname = "Денисова",  Name = "Александра", Patronymic = "Ивановна",    CoatColor = "синий",   AmountPoems = 8, AmountGames = 3},
                new SnowMaiden{Surname = "Воронина",  Name = "Василиса",   Patronymic = "Кирилловна",  CoatColor = "голубой", AmountPoems = 6, AmountGames = 5},
                new SnowMaiden{Surname = "Рыбакова",  Name = "Дарья",      Patronymic = "Григорьевна", CoatColor = "голубой", AmountPoems = 3, AmountGames = 8},
                new SnowMaiden{Surname = "Грибова",   Name = "Софья",      Patronymic = "Никитична",   CoatColor = "синий",   AmountPoems = 2, AmountGames = 12},
                new SnowMaiden{Surname = "Смирнова",  Name = "Валентина",  Patronymic = "Данииловна",  CoatColor = "голубой", AmountPoems = 7, AmountGames = 4},
                new SnowMaiden{Surname = "Гончарова", Name = "Арина",      Patronymic = "Алексеевна",  CoatColor = "синий",   AmountPoems = 5, AmountGames = 3},
                new SnowMaiden{Surname = "Грачёва",   Name = "Василиса",   Patronymic = "Романовна",   CoatColor = "голубой", AmountPoems = 3, AmountGames = 2},
                new SnowMaiden{Surname = "Морозова",  Name = "Таисия",     Patronymic = "Платоновна",  CoatColor = "голубой", AmountPoems = 5, AmountGames = 6},
                new SnowMaiden{Surname = "Семёнова",  Name = "Дарина",     Patronymic = "Марковна",    CoatColor = "синий",   AmountPoems = 9, AmountGames = 9},
                new SnowMaiden{Surname = "Васютина",  Name = "Светлана",   Patronymic = "Максимовна",  CoatColor = "голубой", AmountPoems = 5, AmountGames = 3},
                new SnowMaiden{Surname = "Жукова",    Name = "Зинаида",    Patronymic = "Витальевна",  CoatColor = "голубой", AmountPoems = 8, AmountGames = 8},
});
        }

        // Завершение приложения - команда меню
        private void Exit_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        } // Exit_Click

        // Открыть окно со сведениями о приложении и разработчике
        private void About_Click(object sender, RoutedEventArgs e) =>
            new AboutWindow().ShowDialog();


        // Обработка клика по кнопке "Ремонт телевизоров"
        private void RepairShop_Click(object sender, RoutedEventArgs e)
        {
            TbcMain.SelectedItem = TbcRepairShop;

            DgRepairShop.ItemsSource = _shopController.RepairShop.Televisions;

            // обновить строку состояния
            TbStatusBar.Text = $"Телевизоров в ремонте: {_shopController.RepairShop.Count}";
        }// RepairShop_Click


        #region Сортировка коллекции
        // сортировка коллекции телевизоров по производителю и типу
        private void OrderByBrand_Click(object sender, RoutedEventArgs e)
        {
            _shopController.OrderByBrand();

            // делаем страницу отсортированных данных текущей
            TbcMain.SelectedItem = TbcOrderBy;

            // остановить привязку
            DgOrderBy.ItemsSource = null;
            DgOrderBy.ItemsSource = _shopController.RepairShop.Televisions;

            // обновить строку состояния
            TbStatusBar.Text = $"Телевизоры отсортированы по бренду: {_shopController.RepairShop.Count}";
        }// OrderByBrand_Click


        // сортировка коллекции телевизоров по убыванию диагонали экрана
        private void OrderByDiagonalDesc_Click(object sender, RoutedEventArgs e)
        {
            _shopController.OrderByDiagonalDesc();

            // делаем страницу отсортированных данных текущей
            TbcMain.SelectedItem = TbcOrderBy;

            // остановить привязку
            DgOrderBy.ItemsSource = null;
            DgOrderBy.ItemsSource = _shopController.RepairShop.Televisions;

            // обновить строку состояния
            TbStatusBar.Text = $"Телевизоры отсортированы по убыванию диагонали: {_shopController.RepairShop.Count}";
        }// OrderByDiagonalDesc_Click


        // сортировка коллекции телевизоров по мастеру, выполняющему ремонт
        private void OrderByMaster_Click(object sender, RoutedEventArgs e)
        {
            _shopController.OrderByMaster();

            // делаем страницу отсортированных данных текущей
            TbcMain.SelectedItem = TbcOrderBy;

            // остановить привязку
            DgOrderBy.ItemsSource = null;
            DgOrderBy.ItemsSource = _shopController.RepairShop.Televisions;

            // обновить строку состояния
            TbStatusBar.Text = $"Телевизоры отсортированы по мастеру, выполняющему ремонт: {_shopController.RepairShop.Count}";
        }// OrderByMaster_Click


        // сортировка коллекции телевизоров по владельцу телевизора
        private void OrderByOwner_Click(object sender, RoutedEventArgs e)
        {
            _shopController.OrderByOwner();

            // делаем страницу отсортированных данных текущей
            TbcMain.SelectedItem = TbcOrderBy;

            // остановить привязку
            DgOrderBy.ItemsSource = null;
            DgOrderBy.ItemsSource = _shopController.RepairShop.Televisions;

            // обновить строку состояния
            TbStatusBar.Text = $"Телевизоры отсортированы по владельцу: {_shopController.RepairShop.Count}";
        }// OrderByOwner_Click

        #endregion


        #region Выборка 
        // выборка и вывод в отдельном окне коллекции телевизоров с минимальной стоимостью ремонта
        private void SelectMinPrice_Click(object sender, RoutedEventArgs e)
        {
            // делаем страницу отсортированных данных текущей
            TbcMain.SelectedItem = TbcSelected;

            List<Television> televisions = _shopController.SelectWhereMinPrice();

            //string prompt = $"Телевизоры с минимальной стоимостью ремонта:";

            BindCollection(televisions, DgSelected);

            // обновить строку состояния
            TbStatusBar.Text = $"Телевизорoв с минимальной стоимостью ремонта.";
        }// SelectMinPrice_Click

        // выборка и вывод в отдельном окне коллекции телевизоров, ремонтируемых выбранным мастером
        private void SelectByMaster_Click(object sender, RoutedEventArgs e)
        {
            // Получение списка мастеров
            List<string> repairs = _shopController.RepairShop.GetMasters;

            // Создание формы выбора мастера
            ChoiceWindow choiceWindow = new ChoiceWindow(repairs, "Выбор мастера", "Выберите мастера:");

            if (choiceWindow.ShowDialog() == false) return;

            //string prompt = $"Телевизоры, ремонтируемые мастером {choiceWindow.Choosen}:";

            // выбор мастера произведен, получим мастера, построим выборку
            SelectMaster(choiceWindow.Choosen);

            // обновить строку состояния
            TbStatusBar.Text = $"Телевизоры, ремонтируемые выбранным мастером.";
        }// SelectByMaster_Click


        // выборка и вывод в отдельном окне коллекции телевизоров, с заданной диагональю экрана 
        private void SelectByDiagonal_Click(object sender, RoutedEventArgs e)
        {
            // Получение списка диагонали
            List<string> repairs = _shopController.RepairShop.GetDiagonals;

            // Создание формы выбора мастера
            ChoiceWindow choiceWindow = new ChoiceWindow(repairs, "Выбор диагонали", "Выберите диагональ:");

            if (choiceWindow.ShowDialog() == false) return;

            //string prompt = $"Телевизоры, c диагональю {choiceWindow.Choosen}:";

            // выбор диагонали произведен, получим диагональ, построим выборку
            SelectDiagonal(choiceWindow.Choosen);
        }// SelectByDiagonal_Click


        // формирование выборки ремонтов заданного мастера
        private void SelectMaster(string master)
        {
            // выбрать ремонты заданного мастера
            List<Television> list = _shopController.SelectWhereMaster(master);

            // вывести выборку в отдельной вкладку
            BindCollection(list, DgSelected);

            // делаем страницу выбранных данных текущей
            TbcMain.SelectedItem = TbcSelected;
        } // SelectMaster


        // формирование выборки ремонтов заданного мастера
        private void SelectDiagonal(string diagonal)
        {
            // выбрать телевизоры с заданной диагональю
            int numDiagonal = int.Parse(diagonal.Replace(@"""", ""));
            List<Television> list = _shopController.SelectWhereDiagonal(numDiagonal);

            // вывести выборку в отдельной вкладку
            BindCollection(list, DgSelected);

            // делаем страницу выбранных данных текущей
            TbcMain.SelectedItem = TbcSelected;

        } // SelectDiagonal

        #endregion

        // редактирование данных телевизора в ремонте
        private void EditTelevision_Click(object sender, RoutedEventArgs e)
        {
            TbcMain.SelectedItem = TbcRepairShop;

            // индекс выбранного элемента
            int selected = DgRepairShop.SelectedIndex;
            if (selected == -1) return;

            // передача данных в форму
            TelevisionWindow televisionWindow = new TelevisionWindow("Редактировать данные о телевизоре", "Сохранить");
            televisionWindow.Tv = _shopController.RepairShop.Televisions[selected];

            if (televisionWindow.ShowDialog() == false) return;

            // редактировать телевизор 
            _shopController.RepairShop.Televisions[selected] = televisionWindow.Tv;

            // остановить привязку
            DgRepairShop.ItemsSource = null;
            DgRepairShop.ItemsSource = _shopController.RepairShop.Televisions;

            // обновить строку состояния
            TbStatusBar.Text = $"Телевизоров в ремонте: {_shopController.RepairShop.Count}";
        }// EditTelevision_Click


        // прием телевизора в ремонт
        private void AddTelevision_Click(object sender, RoutedEventArgs e)
        {
            TbcMain.SelectedItem = TbcRepairShop;

            // создать окно для ввода параметров телевизора, принимаемого в ремонт
            TelevisionWindow televisionWindow = new TelevisionWindow();
       
            if (televisionWindow.ShowDialog() == false) return;

            // добавить телевизор в коллекцию ремонтируемых телевизоров
            _shopController.RepairShop.AddTelevizion(televisionWindow.Tv);

            // остановить привязку
            DgRepairShop.ItemsSource = null;
            DgRepairShop.ItemsSource = _shopController.RepairShop.Televisions;

            // обновить строку состояния
            TbStatusBar.Text = $"Телевизоров в ремонте: {_shopController.RepairShop.Count}";
        }// AddTelevision_Click


        // выдача телевизора с ремонта
        private void RemoveAtTv_Click(object sender, RoutedEventArgs e)
        {
            TbcMain.SelectedItem = TbcRepairShop;

            // индекс выбранного элемента
            int selected = DgRepairShop.SelectedIndex;
            if (selected == -1) return;

            _shopController.RepairShop.RemoveAt(selected);

            // остановить привязку
            DgRepairShop.ItemsSource = null;
            DgRepairShop.ItemsSource = _shopController.RepairShop.Televisions;

            // обновить строку состояния
            TbStatusBar.Text = $"Телевизоров в ремонте: {_shopController.RepairShop.Count}";
        }// RemoveAtTv_Click

        // выполнение привязки коллекции
        private void BindCollection(List<Television> list, DataGrid dataGrid)
        {
            // остановить привязку
            dataGrid.ItemsSource = null;

            // задать привязку
            dataGrid.ItemsSource = list;
        } // BindCollection


    }// class MainWindow
}
