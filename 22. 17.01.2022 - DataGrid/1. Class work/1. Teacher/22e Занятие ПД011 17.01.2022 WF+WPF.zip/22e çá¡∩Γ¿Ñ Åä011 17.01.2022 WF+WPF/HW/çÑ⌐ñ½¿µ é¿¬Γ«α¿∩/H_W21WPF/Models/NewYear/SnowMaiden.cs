﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace H_W21WPF.Models.NewYear
{
    // Класс для представления данных актрисы, играющей роль Снегурочки:
    // *фамилия,
    // *имя,
    // *отчество,
    // *цвет полушубка,
    // *количество стихотворений, которые знает актриса,
    // *количество игр для детей, которые может организовать актриса
    public class SnowMaiden
    {
        // фамилия
        private string _surname;
        public string Surname
        {
            get => _surname;
            set
            {
                if (string.IsNullOrWhiteSpace(value))
                    throw new ArgumentException("SnowMaiden: Не верно задано фамилия снегурочки или задано пустой строкой");
                _surname = value;
            }
        }// Surname


        // имя
        private string _name;
        public string Name
        {
            get => _name;
            set
            {
                if (string.IsNullOrWhiteSpace(value))
                    throw new ArgumentException("SnowMaiden: Не верно задано имя снегурочки или задано пустой строкой");
                _name = value;
            }
        }// Name

        // отчество
        private string _patronymic;
        public string Patronymic
        {
            get => _patronymic;
            set
            {
                if (string.IsNullOrWhiteSpace(value))
                    throw new ArgumentException("SnowMaiden: Не верно задано отчество снегурочки или задано пустой строкой");
                _patronymic = value;
            }
        }// Patronymic


        // цвет полушубка
        private string _coatColor;
        public string CoatColor
        {
            get => _coatColor;
            set
            {
                if (string.IsNullOrWhiteSpace(value))
                    throw new ArgumentException("SnowMaiden: Не верно задан цвет полушубка или задан пустой строкой");
                _coatColor = value;
            }
        }// CoatColor


        // количество игр для детей
        private int _amountGames;
        public int AmountGames
        {
            get => _amountGames;
            set
            {
                if (value < 0)
                    throw new ArgumentException($"SnowMaiden: Недопустимое значение количества игр для детей: {value}");
                _amountGames = value;
            }
        }// AmountGames

        
        // количество стихотворений
        private int _amountPoems;
        public int AmountPoems
        {
            get => _amountPoems;
            set
            {
                if (value < 0)
                    throw new ArgumentException($"SnowMaiden: Недопустимое значение количества стихотворений: {value}");
                _amountPoems = value;
            }
        }// AmountPoems


        // конструкторы объекта класса
        public SnowMaiden(): this("Снежная", "Василиса", "Премудрая", "голубой", 8, 4) { }
        public SnowMaiden(string surname, string name, string patronymic, string color, int poems, int games)
        {
            Surname     = surname;
            Name        = name;
            Patronymic  = patronymic;
            CoatColor   = color;
            AmountPoems = poems;
            AmountGames = games;
        }// SnowMaiden

        // строковое представление снегурочки (метод ToString()) 
        public override string ToString() =>
            $"ФИО Снегурочки(актрисы): {_surname} {_name} {_patronymic}, " +
            $"в полушубке цвета {_coatColor}, " +
            $"знает стишков {_amountPoems}, " +
            $"игр {_amountGames} .";

    }// class SnowMaiden
}
