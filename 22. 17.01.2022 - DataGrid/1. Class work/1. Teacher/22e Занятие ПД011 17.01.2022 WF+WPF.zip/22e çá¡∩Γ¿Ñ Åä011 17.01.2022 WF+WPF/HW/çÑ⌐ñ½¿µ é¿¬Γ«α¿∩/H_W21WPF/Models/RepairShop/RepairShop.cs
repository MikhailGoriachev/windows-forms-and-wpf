﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace H_W21WPF.Models.RepairShop
{
    // Класс для представления ремонтной мастерской:
    // *коллекция телевизоров в ремонте,
    // *название ремонтной мастерской,
    // *адрес ремонтной мастерской
    public class RepairShop
    {
        // ссылка на коллекцию телевизоров
        private List<Television> _televisions;

        public List<Television> Televisions => _televisions;

        // название мастерской
        private string _name;

        public string Name
        {
            get => _name;
            set
            {
                if (string.IsNullOrWhiteSpace(value))
                    throw new ArgumentException("Television. Пустое название мастерской недопустимо");

                _name = value;
            } // set
        } // Name

        // адрес мастерской
        private string _address;

        public string Address
        {
            get => _address;
            set
            {
                if (string.IsNullOrWhiteSpace(value))
                    throw new ArgumentException("Television. Пустой адрес мастерской недопустим");

                _address = value;
            } // set
        } // Address

        public RepairShop() : this("Сервисный центр IQS", "ул. Университетская, 75", new List<Television>())
        {
            Inizialize();
        }

        public RepairShop(string name, string address, List<Television> televisions)
        {
            _name = name;
            _address = address;
            _televisions = televisions;
        }

        // количестово телевизоров в коллекции
        public int Count => _televisions.Count;

        public void Inizialize()
        {
            _televisions.Clear();

            _televisions = new List<Television>(new[] {
                new Television{TvBrand = "Samsung", Diagonal = 54, TvDefect = "Повреждение лампы матрицы", FullnameMaster = "Тюрин О.А.",   FullnameOwner = "Митин В.И.",  CostRepair = 970},
                new Television{TvBrand = "LG",      Diagonal = 24, TvDefect = "Проблемы со звуком",        FullnameMaster = "Воронин Л.А.", FullnameOwner = "Зорина В.Ю.", CostRepair = 580},
                new Television{TvBrand = "Philips", Diagonal = 54, TvDefect = "Поломка видеопроцессора",   FullnameMaster = "Тюрин О.А.",   FullnameOwner = "Жуков О.И.",  CostRepair = 1200},
                new Television{TvBrand = "TCL",     Diagonal = 48, TvDefect = "Неисправный пульт упр-ния", FullnameMaster = "Лужко С.Л.",   FullnameOwner = "Зубков В.Р.", CostRepair = 300},
                new Television{TvBrand = "Samsung", Diagonal = 64, TvDefect = "Поломка видеопроцессора",   FullnameMaster = "Воронин Л.А.", FullnameOwner = "Прохоров К.И.",CostRepair = 1200},
                new Television{TvBrand = "Sony",    Diagonal = 54, TvDefect = "Неисправный пульт упр-ния", FullnameMaster = "Лужко С.Л.",   FullnameOwner = "Якубин В.С.", CostRepair = 300},
                new Television{TvBrand = "Philips", Diagonal = 64, TvDefect = "Поломка ресивера",          FullnameMaster = "Ковалёв М.А.", FullnameOwner = "Дудник Д.И.", CostRepair = 300},
                new Television{TvBrand = "Hisense", Diagonal = 48, TvDefect = "Поломка видеопроцессора",   FullnameMaster = "Воронин Л.А.", FullnameOwner = "Павлова В.Л.",CostRepair = 1200},
                new Television{TvBrand = "LG",      Diagonal = 64, TvDefect = "Вертикальные полосы",       FullnameMaster = "Ковалёв М.А.", FullnameOwner = "Кулик О.И.",  CostRepair = 1000},
                new Television{TvBrand = "TCL",     Diagonal = 54, TvDefect = "Поломка ресивера",          FullnameMaster = "Лужко С.Л.",   FullnameOwner = "Ящук В.П.",   CostRepair = 300}
            });

        }// Inizialize


        // добавление телевизора в коллекцию
        public void AddTelevizion(Television tv) => _televisions.Add(tv);


        // удаление выбранного телевизора
        public void RemoveAt(int index) => _televisions.RemoveAt(index);

        public void OrderBy(Comparison<Television> comparison) => _televisions.Sort(comparison);


        // получить минимальную стоимость ремонта телевизора
        public int MinPrice()
        {
            int minPrice = _televisions[0].CostRepair;
            _televisions.ForEach(t => minPrice = t.CostRepair < minPrice ? t.CostRepair : minPrice);

            return minPrice;
        } // MinPrice

        // выборка данных из коллекции по заданному предикату
        public List<Television> Filter(Predicate<Television> predicate) =>
            _televisions.FindAll(predicate);


        // Получить список фамилий мастеров
        public List<string> GetMasters => _televisions.Select(tv => tv.FullnameMaster).Distinct().ToList();


        // Получить список диагоналей
        public List<string> GetDiagonals => _televisions.Select(tv => tv.Diagonal.ToString()).Distinct().ToList();


        // индексатор
        public Television this[int index]
        {
            get
            {
                if (index < 0 || index > Count)
                    throw new IndexOutOfRangeException("Попытка доступа к элементу вне диапазона");
                return _televisions[index];
            }
            set
            {
                if (index < 0 || index > Count)
                    throw new IndexOutOfRangeException("Попытка доступа к элементу вне диапазона");

                _televisions[index] = value;
            }
        }

    }// class RepairShop
}
