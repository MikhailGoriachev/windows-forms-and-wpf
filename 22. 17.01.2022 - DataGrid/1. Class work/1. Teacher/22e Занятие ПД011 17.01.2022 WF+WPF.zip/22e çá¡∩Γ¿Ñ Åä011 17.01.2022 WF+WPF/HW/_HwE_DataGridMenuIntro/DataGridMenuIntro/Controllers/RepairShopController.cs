﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using DataGridMenuIntro.Models;

namespace DataGridMenuIntro.Controllers
{
    /*
     * Реализация функционала приложения
     *     • Упорядочивание коллекции телевизоров
     *         o По производителю и типу
     *         o По убыванию диагонали экрана
     *         o По мастеру, выполняющему ремонт
     *         o По владельцу телевизора
     *     • Выборка в коллекцию телевизоров с минимальной стоимостью ремонта
     *     • Выборка в коллекцию телевизоров, ремонтируемых заданным мастером
     *     • Выборка в коллекцию телевизоров с заданной диагональю экрана 
     */
    public class RepairShopController
    {
        // объект для обработки
        private RepairShop _repairShop;

        public RepairShop RepairShop {
            get => _repairShop;
            private set => _repairShop = value;
        } // RepairShop


        // конструкторы
        // при создании RepairShop конструктором по умолчанию вызывается
        // метод формирования коллекции телевизоров для ремонта
        public RepairShopController():this(new RepairShop()) { }

        public RepairShopController(RepairShop repairShop) {
            _repairShop = repairShop;
        } // RepairShopController


        // Запрос на упорядочивание копии коллекции по производителю и типу
        public List<Television> OrderByBrand() => 
            _repairShop.OrderCopyBy((t1, t2) => t1.BrandModel.CompareTo(t2.BrandModel));

        // Запрос на упорядочивание копии коллекции по убыванию диагонали экрана
        public List<Television> OrderByDiagonalDesc() => 
            _repairShop.OrderCopyBy((t1, t2) => t2.Diagonal.CompareTo(t1.Diagonal));


        // Запрос на упорядочивание копии коллекции по мастеру, выполняющему ремонт
        public List<Television> OrderByArtisan()  => 
            _repairShop.OrderCopyBy((t1, t2) => t2.Diagonal.CompareTo(t1.Diagonal));


        // Запрос на упорядочивание копии коллекции по владельцу телевизора
        public List<Television> OrderByOwner() =>
            _repairShop.OrderCopyBy((t1, t2) => t1.Owner.CompareTo(t2.Owner));


        // Запрос на упорядочивание копии коллекции по стоимости ремонта
        public List<Television> OrderByPrice() =>
            _repairShop.OrderCopyBy((t1, t2) => t1.Price.CompareTo(t2.Price));


        // Запрос на выборку в коллекцию телевизоров с минимальной стоимостью ремонта
        public List<Television> SelectWhereMinPrice() =>
            _repairShop.Filter(t => t.Price == _repairShop.MinPrice);

        // Запрос на выборку в коллекцию телевизоров, ремонтируемых заданным мастером
        public List<Television> SelectWhereArtisan(string artisan) =>
            _repairShop.Filter(t => t.Artisan == artisan);

        // Запрос на выборку в коллекцию телевизоров с заданной диагональю экран
        public List<Television> SelectWhereDiagonal(double diagonal) =>
            _repairShop.Filter(t => Math.Abs(t.Diagonal - diagonal) < 1e-6);

        // Запрос на выборку в коллекцию телевизоров, принадлежащих заданному владельцу
        public List<Television> SelectWhereOwner(string owner) =>
            _repairShop.Filter(t => t.Owner == owner);


        // список мастеров из коллекции ремонтов - LINQ
        public List<string> GetArtisans() => _repairShop
            .Televisions
            .Select(t => t.Artisan)
            .Distinct()
            .ToList();


        // список владельцев телевизоров из коллекции ремонтов - LINQ
        public List<string> GetOwners() => _repairShop.Televisions
            .Select(t => t.Owner)
            .Distinct()
            .ToList();


        // создание новой ремонтной мастерской
        public void CreateNewRepairShop(string title, string address) =>
            _repairShop = new RepairShop(new List<Television>(), title, address);

    } // class RepairShopController
}
