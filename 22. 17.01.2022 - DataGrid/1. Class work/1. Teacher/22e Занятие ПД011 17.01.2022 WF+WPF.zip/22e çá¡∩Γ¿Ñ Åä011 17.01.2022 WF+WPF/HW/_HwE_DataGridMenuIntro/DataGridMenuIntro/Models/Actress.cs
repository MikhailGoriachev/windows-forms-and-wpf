﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataGridMenuIntro.Models
{
    // Разработайте класс для представления данных актрисы, играющей роль Снегурочки: 
    // фамилия, имя, отчество, цвет полушубка, количество стихотворений, которые знает
    // актриса, количество игр для детей, которые может организовать актриса
    public class Actress: Person
    {
        // количество стихотворений, которые знает актриса
        public int NumberOfPoems { get; set; }

        // количество игр для детей, которые может организовать актриса
        public int NumberOfGames { get; set; }
    } // class Actress
}
