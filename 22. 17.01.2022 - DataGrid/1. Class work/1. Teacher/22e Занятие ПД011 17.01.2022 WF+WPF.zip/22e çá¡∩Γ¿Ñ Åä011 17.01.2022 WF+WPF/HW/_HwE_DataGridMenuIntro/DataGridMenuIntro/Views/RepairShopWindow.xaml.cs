﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using DataGridMenuIntro.Controllers;
using DataGridMenuIntro.Models;

namespace DataGridMenuIntro.Views
{
    /// <summary>
    /// Логика взаимодействия для RepairShopWindow.xaml
    /// </summary>
    public partial class RepairShopWindow : Window
    {
        // контроллер для работы с ремонтной мастерской
        private RepairShopController _repairShopController;

        public RepairShopWindow():this(new RepairShopController()) {}

        public RepairShopWindow(RepairShopController repairShopController) {
            InitializeComponent();

            // внедрение зависимости
            _repairShopController = repairShopController;

            // задать данные ремонтной мастерской в строку заголовка
            TxbRepairShop.Text = "Ремонтная мастерская \"" + _repairShopController.RepairShop.Title + "\" по адресу " +
                                 _repairShopController.RepairShop.Address;

            // задать телевизоры для отображения в ListView
            DgvTelevisions.ItemsSource = _repairShopController.RepairShop.Televisions;

            // задать цвет фона полей вывода в строку состояния
            TxbStatus1.Background = TxbStatus2.Background = StbRepair.Background;

            // вывести количество телевизоров в строку состояния
            TxbStatus2.Text = $"{_repairShopController.RepairShop.Count}";
        } // RepairShopWindow


        // Формирование нового набора данных
        private void GenerateNew_Click(object sender, RoutedEventArgs e) {
            _repairShopController.CreateNewRepairShop("Отремонтируем все", "ул. Овнатаняна, 21в");
            _repairShopController.RepairShop.Initialize();

            // задать данные ремонтной мастерской в строку заголовка
            TxbRepairShop.Text = "Ремонтная мастерская \"" + _repairShopController.RepairShop.Title + "\" по адресу " +
                                 _repairShopController.RepairShop.Address;

            // задать телевизоры для отображения в DataGrid
            DgvTelevisions.ItemsSource = null;
            DgvTelevisions.ItemsSource = _repairShopController.RepairShop.Televisions;

            // вывести количество телевизоров в строку состояния
            TxbStatus2.Text = $"{_repairShopController.RepairShop.Count}";

            TbcRepairShop.SelectedItem = TbiTelevisions;
            DgvSorted.ItemsSource = null;
            DgvSorted.ItemsSource = new List<Television>();        
            
            DgvSelected.ItemsSource = null;
            DgvSelected.ItemsSource = new List<Television>();

        } // GenerateNew_Click

        // Добавление телевизра в коллекцию - черновой вариант, без формы
        private void AddTv_Click(object sender, RoutedEventArgs e) {
            // добавить телевизор в коллекцию
            _repairShopController.RepairShop.Add(Television.Generate());

            // обновить привязку коллекции к DataGrid
            DgvTelevisions.ItemsSource = null;
            DgvTelevisions.ItemsSource = _repairShopController.RepairShop.Televisions;

            // вывести новое количество телевизоров в строку состояния
            TxbStatus2.Text = $"{_repairShopController.RepairShop.Count}";

            // делаем вкладку коллекции телевизоров текущей
            TbcRepairShop.SelectedItem = TbiTelevisions;
        } // AddTv_Click

        // закрыть окно
        private void Close_Click(object sender, RoutedEventArgs e) => Close();


        // завершение работы приложения
        private void ApplicationExit_Click(object sender, RoutedEventArgs e) => 
            Application.Current.Shutdown();


        // Сортировка копии коллекции по производителю и типу
        private void OrderByBrand(object sender, RoutedEventArgs e) {
            DgvSorted.ItemsSource = null;
            DgvSorted.ItemsSource = _repairShopController.OrderByBrand();

            // делаем вкладку отсортированных данных текущей
            TbcRepairShop.SelectedItem = TbiSorted;
        } // OrderByBrand


        // Сортировка копии коллекции по убыванию диагонали экрана телевизора
        private void OrderByDiagonalDescending(object sender, RoutedEventArgs e) {
            DgvSorted.ItemsSource = null;
            DgvSorted.ItemsSource = _repairShopController.OrderByDiagonalDesc();

            // делаем вкладку отсортированных данных текущей
            TbcRepairShop.SelectedItem = TbiSorted;
        } // OrderByDiagonalDescending


        // Сортировка копии коллекции по мастеру, выполняющему ремонт
        private void OrderByArtisan(object sender, RoutedEventArgs e) {
            DgvSorted.ItemsSource = null;
            DgvSorted.ItemsSource = _repairShopController.OrderByArtisan();

            // делаем вкладку отсортированных данных текущей
            TbcRepairShop.SelectedItem = TbiSorted;
        } // OrderByArtisan


        // Сортировка копии коллекции по владельцу телевизору
        private void OrderByOwner(object sender, RoutedEventArgs e) {
            DgvSorted.ItemsSource = null;
            DgvSorted.ItemsSource = _repairShopController.OrderByOwner();

            // делаем вкладку отсортированных данных текущей
            TbcRepairShop.SelectedItem = TbiSorted;
        } // OrderByOwner


        // Выборка коллекции телевизоров с минимальной стоимостью ремонта
        private void SelectMinPrice(object sender, RoutedEventArgs e) {
            DgvSelected.ItemsSource = null;
            DgvSelected.ItemsSource = _repairShopController.SelectWhereMinPrice();
            TbcRepairShop.SelectedItem = TbiSelected;
        } // SelectMinPrice


    } // class RepairShopWindow
}
