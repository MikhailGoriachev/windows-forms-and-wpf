﻿using Homework.Helpers;
using Homework.Models.Task2;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Homework.Views
{
    /// <summary>
    /// Логика взаимодействия для TelevisionWindow.xaml
    /// </summary>
    public partial class TelevisionWindow : Window
    {
        Television _television;
        public Television Television {
            get => _television;
            set {
                _television = value;
                TxbArtisan.Text = _television.Artisan;
                TxbPrice.Text = $"{_television.Price}";
                CmbBrand.Text = _television.BrandModel;
                TxbOwner.Text = _television.Owner;
                TxbDefect.Text = _television.DefectDescription;
                CmbDiagonal.Text = $"{_television.Diagonal}";        
            } // set
        }
        public TelevisionWindow() : this("Добавление телевизора", "Добавить") { }
        public TelevisionWindow(string header, string button) {
            InitializeComponent();
            Title = header;
            BtnOK.Content = button;

            CmbBrand.ItemsSource = Utils.Brands;
            CmbBrand.SelectedIndex = 0;

            CmbDiagonal.ItemsSource = Utils.Diagonals;
            CmbDiagonal.SelectedIndex = 0;

            _television = new Television();
        } // TelevisionWindow

        #region Изменение цвета надписи на кнопке при перемещении курсора мыши на кнопку
        private void Button_MouseEnter(object sender, MouseEventArgs e)
        {
            Button btn = e.OriginalSource as Button;
            btn.Foreground = new SolidColorBrush(Color.FromArgb(255, 0, 0, 0));
        } // Button_MouseEnter

        private void Button_MouseLeave(object sender, MouseEventArgs e)
        {
            Button btn = e.OriginalSource as Button;
            btn.Foreground = new SolidColorBrush(Colors.White);
        } // Button_MouseLeave
        #endregion

        // Обработка клика по кнопке ОК - скрываем окно
        private void Add_Click(object sender, RoutedEventArgs e) {
            try {
                // Получить данные от элементов управления
                _television.Artisan           = TxbArtisan.Text;
                _television.Price             = int.Parse(TxbPrice.Text);
                _television.BrandModel        = CmbBrand.SelectedItem.ToString();
                _television.Owner             = TxbOwner.Text;
                _television.DefectDescription = TxbDefect.Text;
                _television.Diagonal          = double.Parse(CmbDiagonal.SelectedItem.ToString());
                DialogResult                  = true;
                Close();
            }
            catch (Exception ex) {
                MessageBox.Show(ex.Message, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            } // try-catch
        } // Ok_Click
    }
}
