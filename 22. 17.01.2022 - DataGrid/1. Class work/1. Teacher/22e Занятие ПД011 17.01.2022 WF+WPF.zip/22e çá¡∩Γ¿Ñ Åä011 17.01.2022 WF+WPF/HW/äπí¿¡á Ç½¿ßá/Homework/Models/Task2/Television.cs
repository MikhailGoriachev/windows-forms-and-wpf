﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Homework.Helpers;

namespace Homework.Models.Task2
{
    /*
     * Класс Television (производитель и тип телевизора, диагональ экрана,
     * строка с описанием дефекта, фамилия и инициалами мастера, фамилия
     * и инициалы владельца, стоимость ремонта).
     */
    public class Television
    {
        // производитель и тип телевизора
        private string _brandModel;
        public string BrandModel {
            get => _brandModel;
            set {
                if (string.IsNullOrWhiteSpace(value))
                    throw new ArgumentException("Televisioon. Должен быть задан адрес ремонтной мастерской");

                _brandModel = value;
            }
        } // BrandModel


        // диагональ экрана
        private double _diagonal;

        public double Diagonal {
            get => _diagonal;
            set {
                if (value < 0)
                    throw new ArgumentException("Televisioon. Задана не корректна диагональ экрана");

                _diagonal = value;
            }
        } // Diagonal


        // описание дефекта
        private string _defectDescription;
        public string DefectDescription {
            get => _defectDescription;
            set {
                if (string.IsNullOrWhiteSpace(value))
                    throw new ArgumentException("Televisioon. Должно быть задано описание дефекта");

                _defectDescription = value;
            }
        } // DefectDescription

        // фамилия и инициалами мастера
        private string _artisan;
        public string Artisan {
            get => _artisan;
            set {
                if (string.IsNullOrWhiteSpace(value))
                    throw new ArgumentException("Televisioon. Должны быть заданы фамилия и инициалы мастера");

                _artisan = value;
            }
        } // Artisan

        // фамилия и инициалами владельца
        private string _owner;
        public string Owner {
            get => _owner;
            set {
                if (string.IsNullOrWhiteSpace(value))
                    throw new ArgumentException("Televisioon. Должны быть заданы фамилия и инициалы владельца");

                _owner = value;
            }
        } // Owner


        // стоимость ремонта
        private int _price;

        public int Price {
            get => _price;
            set {
                if (value < 0)
                    throw new ArgumentException("Televisioon. Стоимсоть ремонта не может быть отрицательной");
                
                _price = value;
            }
        } // Price


        // конструкторы
        public Television(): this("Samsung", 55.5, "нет звука", 
            "Левша Р.Р.", "Ломакин И.В.", 1200) {
        } // Television

        // валидируем данные при создании объекта
        public Television(string brandModel, double diagonal, string defectDescription, 
                          string artisan, string owner, int price) {
            BrandModel = brandModel;
            Diagonal = diagonal;
            DefectDescription = defectDescription;
            Artisan = artisan;
            Owner = owner;
            Price = price;
        } // Television


        // фабричный метод для создания телевизора
        public static Television Generate() {
            // индексы из массивов данных для создания телевизора
            int indexBrand = Utils.GetRandom(0, Utils.Brands.Length - 1);
            int indexDiagonal = Utils.GetRandom(0, Utils.Diagonals.Length - 1);
            int indexArtisan = Utils.GetRandom(0, Utils.FullNames.Length - 1);
            int indexOwner = Utils.GetRandomExclude(0, Utils.FullNames.Length - 1, indexArtisan);
            int indexDefect = Utils.GetRandom(0, Utils.DefectDescriptions.Length - 1);

            // создание объекта из массивов шаблонных данных, валидация при создании не нужна
            return new Television {
                _brandModel = Utils.Brands[indexBrand], 
                _diagonal = Utils.Diagonals[indexDiagonal],
                _defectDescription = Utils.DefectDescriptions[indexDefect].Desc,
                _artisan = Utils.FullNames[indexArtisan], 
                _owner = Utils.FullNames[indexOwner],
                _price = Utils.DefectDescriptions[indexDefect].Price
            };
        } // Television


        // строковое представление объекта
        public override string ToString() =>
            $"{_brandModel}: {_diagonal}\", '{_defectDescription}', " +
            $"владелец {_owner}, мастер {_artisan}, стоимость {_price} руб.";

        // формирование строки таблицы, свойство
        public string TableRow =>
            $" {_brandModel,-22} │ {_diagonal,6:n1}       │ {_defectDescription,-26} │ " +
            $"{_owner,-18} │ {_artisan,-18} │ {_price, 11:n2}";


        // Шапка таблицы, статическое свойство
        public static string Header =>
            $"  Производитель, модель   Диагональ, \"    Описание дефекта              Владелец              Мастер          Цена, руб. ";

    } // class Television
}
